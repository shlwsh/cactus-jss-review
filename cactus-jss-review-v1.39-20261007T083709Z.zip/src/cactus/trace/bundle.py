"""Immutable RUN bundle writer and checksum verifier."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from cactus.governance.canonical import safe_relative_path


class RunBundle:
    def __init__(self, root: Path) -> None:
        self.root = root
        if self.root.exists() and (self.root / "checksums.sha256").exists():
            raise FileExistsError(f"sealed RUN already exists: {self.root}")
        self.root.mkdir(parents=True, exist_ok=True)

    def write_json(self, relative: str, value: object) -> Path:
        target = self._target(relative)
        target.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
        return target

    def write_text(self, relative: str, value: str) -> Path:
        """Write a UTF-8 evidence file before sealing the bundle."""
        target = self._target(relative)
        target.write_text(value, encoding="utf-8", newline="\n")
        return target

    def _target(self, relative: str) -> Path:
        if (self.root / "checksums.sha256").exists():
            raise RuntimeError("sealed RUN cannot be modified")
        if not safe_relative_path(relative) or relative.endswith("checksums.sha256"):
            raise ValueError("unsafe or reserved bundle path")
        target = self.root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        return target

    def seal(self) -> Path:
        checksum_lines: list[str] = []
        for path in sorted(p for p in self.root.rglob("*") if p.is_file() and p.name != "checksums.sha256"):
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            checksum_lines.append(f"{digest}  {path.relative_to(self.root).as_posix()}")
        checksums = self.root / "checksums.sha256"
        checksums.write_text("\n".join(checksum_lines) + "\n", encoding="utf-8", newline="\n")
        return checksums

    def verify(self) -> list[str]:
        checksums = self.root / "checksums.sha256"
        if not checksums.exists():
            return ["missing checksums.sha256"]
        errors: list[str] = []
        expected: set[str] = set()
        for line in checksums.read_text(encoding="utf-8").splitlines():
            digest, relative = line.split("  ", 1)
            expected.add(relative)
            path = self.root / relative
            if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                errors.append(f"checksum mismatch: {relative}")
        actual = {p.relative_to(self.root).as_posix() for p in self.root.rglob("*") if p.is_file() and p.name != "checksums.sha256"}
        errors.extend(f"unlisted file: {path}" for path in sorted(actual - expected))
        return errors
