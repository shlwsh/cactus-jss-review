"""Manifest construction for self-contained, immutable RUN bundles."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from cactus.governance.canonical import canonical_json, utc_now
from cactus.trace.bundle import RunBundle


def build_manifest(*, study_id: str, experiment_id: str, run_id: str, commit: str, config: dict[str, Any], environment: dict[str, Any], command: list[str], outputs: list[dict[str, str]] | None = None) -> dict[str, Any]:
    config_digest = hashlib.sha256(canonical_json(config).encode("utf-8")).hexdigest()
    return {
        "schema_version": "2.0", "study_id": study_id, "experiment_id": experiment_id,
        "run_id": run_id, "started_at": utc_now(), "finished_at": None, "status": "running",
        "code": {"commit": commit, "dirty": False, "patch_sha256": None},
        "configuration": {"path": "resolved_config.json", "sha256": config_digest},
        "environment": environment, "command": command, "outputs": outputs or [], "error": None,
    }


def initialize_bundle(root: Path, **kwargs: Any) -> RunBundle:
    bundle = RunBundle(root)
    manifest = build_manifest(**kwargs)
    bundle.write_json("run_manifest.json", manifest)
    bundle.write_json("resolved_config.json", kwargs["config"])
    return bundle
