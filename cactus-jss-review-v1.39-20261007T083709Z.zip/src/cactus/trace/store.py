"""Append-only JSONL trace store with monotonic sequence enforcement."""

from __future__ import annotations

import json
from pathlib import Path
from uuid import uuid4

from cactus.domain.models import TraceEvent
from cactus.governance.canonical import utc_now


class TraceStore:
    def __init__(self, path: Path, run_id: str) -> None:
        self.path = path
        self.run_id = run_id
        self._seq = self._read_last_seq()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _read_last_seq(self) -> int:
        if not self.path.exists():
            return 0
        lines = [line for line in self.path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if not lines:
            return 0
        return int(json.loads(lines[-1])["seq"])

    def append(self, event_type: str, payload: dict, parent_event_id: str | None = None) -> TraceEvent:
        if self.path.exists() and self.path.stat().st_size and self._is_sealed():
            raise RuntimeError("trace is sealed and cannot be appended")
        self._seq += 1
        event = TraceEvent(str(uuid4()), self.run_id, self._seq, utc_now(), event_type, payload, parent_event_id)
        with self.path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True) + "\n")
        return event

    def seal(self) -> None:
        marker = self.path.with_suffix(self.path.suffix + ".sealed")
        marker.write_text(utc_now() + "\n", encoding="utf-8", newline="\n")

    def _is_sealed(self) -> bool:
        return self.path.with_suffix(self.path.suffix + ".sealed").exists()

    def read(self) -> list[TraceEvent]:
        if not self.path.exists():
            return []
        events: list[TraceEvent] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            data = json.loads(line)
            events.append(TraceEvent(data["event_id"], data["run_id"], data["seq"], data["utc_ts"], data["type"], data["payload"], data.get("parent_event_id")))
        return events
