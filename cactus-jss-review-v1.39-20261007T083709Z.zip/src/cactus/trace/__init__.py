"""Append-only trace and replay primitives."""

from .store import TraceStore

__all__ = ["TraceStore"]
