"""Replay read-only event streams without contacting an Agent or provider."""

from __future__ import annotations

from collections.abc import Callable, Iterable

from cactus.domain.models import TraceEvent


def replay(events: Iterable[TraceEvent], observer: Callable[[TraceEvent], None]) -> int:
    previous = 0
    count = 0
    for event in events:
        if event.seq != previous + 1:
            raise ValueError("trace sequence is not contiguous")
        observer(event)
        previous = event.seq
        count += 1
    return count
