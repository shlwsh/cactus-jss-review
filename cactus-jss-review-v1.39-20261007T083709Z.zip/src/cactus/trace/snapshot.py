"""Immutable content snapshots for delta and provenance calculations."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class FileSnapshot:
    path: str
    sha256: str
    text: str
    captured_at: str
    capture_mode: str = "observed"


def snapshot_file(root: Path, path: Path, captured_at: str) -> FileSnapshot:
    relative = path.relative_to(root).as_posix()
    text = path.read_text(encoding="utf-8")
    return FileSnapshot(relative, hashlib.sha256(text.encode("utf-8")).hexdigest(), text, captured_at)
