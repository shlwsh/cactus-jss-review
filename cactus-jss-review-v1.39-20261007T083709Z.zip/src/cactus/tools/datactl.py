"""Offline corpus, publication admission, LaTeX, and provenance gates."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from cactus.governance.schema import validate_artifact_provenance
from cactus.governance.evidence_locations import iter_runs, resolve_source, logical_source


def verify_dual_lens(root: Path, *, no_cherry_pick: bool = False, retry_chain: bool = False, context_inherit: bool = False) -> tuple[int, list[str]]:
    """Validate dual-lens report structure; do not manufacture measured evidence."""
    report_root = root / "docs" / "dual_lens"
    required = [report_root / name for name in ("algorithm_lens.json", "evaluator_lens.json", "cross_lens.json")]
    errors = [f"missing report: {path.name}" for path in required if not path.is_file()]
    if no_cherry_pick:
        source = root / "paper" / "data" / "final_task_outcomes.csv"
        if not source.is_file():
            errors.append("frozen 500-task source is missing")
        else:
            import csv
            with source.open(encoding="utf-8", newline="") as handle:
                if len(list(csv.DictReader(handle))) != 500:
                    errors.append("final dataset does not contain exactly 500 tasks")
    if retry_chain or context_inherit:
        for path in required:
            if path.is_file():
                payload = json.loads(path.read_text(encoding="utf-8"))
                if retry_chain and payload.get("retry_chain_integrity") not in {"verified", "not_applicable"}:
                    errors.append(f"retry chain not verified: {path.name}")
                if context_inherit and payload.get("context_bundle_inherit") not in {"verified", "not_applicable"}:
                    errors.append(f"context inheritance not verified: {path.name}")
    return (2 if errors else 0), errors


def verify_provenance(root: Path) -> tuple[int, list[str]]:
    """Verify hashes for generated figures and paper tables."""
    errors: list[str] = []
    seen: set[Path] = set()
    input_digests: dict[Path, str | None] = {}
    if (root / "paper/evidence_sources.json").is_file():
        from scripts.generate_evidence_catalog import verify
        try:
            verify()
        except (OSError, ValueError, KeyError) as exc:
            errors.append(f"unified paper evidence verification failed: {exc}")
    artifact_roots = [root / "paper" / "figures" / "output", root / "docs" / "paper_tables", root / "paper" / "generated"]
    for folder in artifact_roots:
        if not folder.is_dir():
            errors.append(f"missing artifact directory: {folder.relative_to(root).as_posix()}")
            continue
        for artifact in sorted(folder.rglob("*")):
            if artifact.suffix not in {".pdf", ".png", ".svg", ".tex"}:
                continue
            sidecar = artifact.with_name(f"{artifact.name}.provenance.json")
            if not sidecar.is_file():
                sidecar = artifact.with_name(f"{artifact.stem}.provenance.json")
            if not sidecar.is_file():
                sidecar = artifact.with_name(f"{artifact.stem}_provenance.json")
            if not sidecar.is_file():
                sidecar = artifact.with_name(f"{artifact.name}.provenance.json")
            if not sidecar.is_file():
                errors.append(f"missing provenance sidecar: {artifact.name}")
                continue
            try:
                payload = json.loads(sidecar.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                errors.append(f"invalid provenance sidecar: {sidecar.name} ({exc})")
                continue
            schema_errors = validate_artifact_provenance(payload)
            if schema_errors:
                errors.extend(f"invalid provenance sidecar: {sidecar.name}: {error}" for error in schema_errors)
            digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
            if payload.get("artifact_sha256") != digest:
                errors.append(f"artifact hash mismatch: {artifact.name}")
            errors.extend(verify_sidecar(root, artifact, seen=seen, input_digests=input_digests))
            if payload.get("source_sha256") is not None and (not isinstance(payload["source_sha256"], str) or len(payload["source_sha256"]) != 64):
                errors.append(f"source hash is not full SHA-256: {sidecar.name}")
            if payload.get("generated_at") and not str(payload["generated_at"]).endswith("Z"):
                errors.append(f"generated_at is not UTC: {sidecar.name}")
    return (2 if errors else 0), errors


def scan_latex(root: Path) -> tuple[int, list[str]]:
    """Check that result macros and referenced graphics resolve locally."""
    if (root / "paper/publication_sources.json").is_file():
        from scripts.generate_publication_values import scan, verify
        try:
            verify()
            result = scan(root)
            return (2 if result["errors"] else 0), result["errors"]
        except (OSError, ValueError, KeyError) as exc:
            return 2, [f"publication numeric gate: {exc}"]
    return 2, ["unified publication_sources.json is required; legacy macro existence is not evidence"]


def validate_schemas(root: Path) -> list[str]:
    from jsonschema import Draft202012Validator
    schema_root = root / "experiments" / "schemas"
    messages: list[str] = []
    for path in sorted(schema_root.glob("*.schema.json")):
        Draft202012Validator.check_schema(json.loads(path.read_text(encoding="utf-8")))
        messages.append(f"PASS schema {path.name}")
    return messages


def all_checks(root: Path) -> int:
    failures = []
    for message in validate_schemas(root):
        print(message)
    runs = root / "experiments" / "runs"
    run_directories = [path for logical, path in iter_runs(root) if path.name.startswith("RUN-")]
    formal_runs = run_directories
    if formal_runs:
        from cactus.runner.bundle_validator import validate_bundle
        from scripts.audit_evidence_corpus import schema_errors
        bundle_failures = []
        for run in formal_runs:
            errors = validate_bundle(run)
            for name, filename in (("run_manifest", "run_manifest.json"), ("raw_result", "raw/result.json")):
                path = run / filename
                if path.is_file():
                    try:
                        errors.extend(schema_errors(root, name, json.loads(path.read_text(encoding="utf-8"))))
                    except (ValueError, OSError):
                        errors.append(f"invalid JSON: {filename}")
            if errors:
                bundle_failures.append((run, sorted(set(errors))))
        if bundle_failures:
            for run, errors in bundle_failures:
                print(f"FAIL RUN bundle {run.name}: {'; '.join(errors)}")
            failures.append(f"{len(bundle_failures)} invalid/incomplete RUN bundles")
        print(f"INFO {len(formal_runs) - len(bundle_failures)}/{len(formal_runs)} archive bundles verified; this is not publication admission")
    else:
        print("PASS no formal RUN bundles present")
    # All stages run even if archive integrity fails. No fixed PASS messages.
    if (root / "paper/publication_sources.json").is_file():
        from scripts.generate_publication_values import verify_sources
        try:
            result = verify_sources()
            print("PASS current publication source recomputation")
            if result["archive_integrity"] != "PASS":
                failures.append("archive corpus integrity remains FAIL")
        except (OSError, ValueError, KeyError) as exc:
            failures.append(f"publication source recomputation: {exc}")
    else:
        failures.append("publication source admission is not configured")
    for label, operation in (("numeric macro chain", scan_latex), ("artifact provenance", verify_provenance)):
        code, errors = operation(root)
        if code:
            failures.extend(label + ": " + error for error in errors)
        else:
            print("PASS " + label)
    matrix_path = root / "configs" / "experiments" / "matrix.template.json"
    if matrix_path.exists():
        from cactus.runner.matrix import validate_matrix
        matrix_errors = validate_matrix(json.loads(matrix_path.read_text(encoding="utf-8")))
        if matrix_errors:
            print("FAIL matrix template: " + "; ".join(matrix_errors))
            failures.extend(matrix_errors)
        else:
            print("PASS matrix template semantics")
    fixture_manifest = root / "data" / "manifests" / "fixtures_v1.json"
    if fixture_manifest.exists():
        manifest = json.loads(fixture_manifest.read_text(encoding="utf-8"))
        mismatches = []
        for fixture in manifest.get("fixtures", []):
            for item in fixture.get("files", []):
                path = root / item.get("path", "")
                if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != item.get("sha256"):
                    mismatches.append(item.get("path", "<missing>"))
        if mismatches:
            print("FAIL fixture manifest hashes: " + ", ".join(mismatches))
            failures.extend(mismatches)
        else:
            print("PASS fixture manifest hashes")
    for error in failures:
        print("FAIL " + error)
    print("FAIL" if failures else "PASS")
    return 2 if failures else 0


def verify_sidecar(root: Path, artifact: Path, *, seen: set[Path] | None = None,
                   input_digests: dict[Path, str | None] | None = None) -> list[str]:
    """Check each recorded input and generator, including nested derivatives."""
    seen = set() if seen is None else seen
    input_digests = {} if input_digests is None else input_digests
    artifact = artifact.resolve()
    if artifact in seen:
        return []
    seen.add(artifact)
    sidecar = artifact.with_name(artifact.name + ".provenance.json")
    if not sidecar.is_file():
        return [f"missing standard sidecar: {logical_source(root, artifact)}"]
    payload = json.loads(sidecar.read_text(encoding="utf-8"))
    errors = validate_artifact_provenance(payload)
    if payload.get("artifact_path") != logical_source(root, artifact):
        errors.append(f"artifact path binding mismatch: {artifact.name}")
    if payload.get("artifact_sha256") != hashlib.sha256(artifact.read_bytes()).hexdigest():
        errors.append(f"artifact hash mismatch: {artifact.name}")
    def check(relative, expected, label):
        if not isinstance(relative, str) or Path(relative).is_absolute() or ".." in Path(relative).parts or ":" in relative:
            errors.append(f"unsafe/missing {label} path: {artifact.name}")
            return None
        try:
            path = resolve_source(root, relative)
        except (OSError, ValueError, KeyError) as exc:
            errors.append(f"{label} path resolution failed: {artifact.name}: {exc}")
            return None
        if path in input_digests:
            digest = input_digests[path]
        elif path.is_dir():
            # Legacy retry sidecars record a full tree digest, using the same
            # canonical relative-path/hash map as the immutable RUN importer.
            from cactus.governance.canonical import canonical_json
            members = sorted(path.rglob("*"))
            if any(p.is_symlink() for p in members):
                errors.append(f"symlink in {label} directory: {relative}")
                return None
            digest = hashlib.sha256(canonical_json({
                p.relative_to(path).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in members if p.is_file()
            }).encode("utf-8")).hexdigest()
        elif path.is_file():
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
        else:
            digest = None
        input_digests[path] = digest
        if digest != expected:
            errors.append(f"{label} hash mismatch: {relative}")
            return None
        return path
    generator = payload.get("generator", {})
    script = generator.get("script")
    digest = generator.get("script_sha256")
    if isinstance(script, str) and isinstance(digest, str):
        path = (root / script).resolve()
        current_match = path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == digest
        if not current_match:
            # Historical generators bind their historical commit, never HEAD.
            import subprocess
            import re
            commit = generator.get("source_commit", "")
            if re.fullmatch(r"[0-9a-f]{40}", str(commit)) and not Path(script).is_absolute() and ".." not in Path(script).parts and ":" not in script:
                result = subprocess.run(["git", "show", f"{commit}:acm/{script}"], cwd=root, capture_output=True)
                if result.returncode or hashlib.sha256(result.stdout).hexdigest() != digest:
                    # A historical snapshot may have been generated from an
                    # uncommitted script whose exact bytes were committed later.
                    # Preserve that previously accepted byte binding explicitly;
                    # never rewrite its original recorded source_commit.
                    archive_index = root / "experiments/quarantine/generator_sources/index.json"
                    binding = json.loads(archive_index.read_text(encoding="utf-8")).get("bindings", {}).get(digest) if archive_index.is_file() else None
                    restored = False
                    if binding and binding.get("script") == script and re.fullmatch(r"[0-9a-f]{40}", str(binding.get("capture_commit", ""))):
                        snapshot = resolve_source(root, binding["snapshot_path"])
                        archived = subprocess.run(["git", "show", f"{binding['capture_commit']}:acm/{script}"], cwd=root, capture_output=True)
                        restored = (binding["snapshot_path"].startswith("experiments/quarantine/generator_sources/")
                                    and snapshot.is_file() and hashlib.sha256(snapshot.read_bytes()).hexdigest() == digest
                                    and not archived.returncode and hashlib.sha256(archived.stdout).hexdigest() == digest)
                    if not restored:
                        errors.append(f"historical generator binding mismatch: {artifact.name}")
            else:
                errors.append(f"generator binding mismatch: {artifact.name}")
    else:
        errors.append(f"missing generator content binding: {artifact.name}")
    if not payload.get("inputs"):
        errors.append(f"empty provenance inputs: {artifact.name}")
    for item in payload.get("inputs", []):
        path = check(item.get("path"), item.get("sha256"), "input")
        if path is not None and path.with_name(path.name + ".provenance.json").is_file():
            errors.extend(verify_sidecar(root, path, seen=seen, input_digests=input_digests))
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(prog="cactus-datactl")
    parser.add_argument("command", choices=("all", "schema-validate", "audit", "dual_lens", "gate", "provenance", "publication", "quarantine"))
    parser.add_argument("dual_action", nargs="?", choices=("verify", "check", "scan-latex"))
    parser.add_argument("--no-cherry-pick", action="store_true")
    parser.add_argument("--retry-chain", action="store_true")
    parser.add_argument("--context-inherit", action="store_true")
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[3]
    if args.command == "quarantine":
        if args.manifest is None:
            parser.error("quarantine requires --manifest")
        from scripts.quarantine_evidence import verify
        verify(args.manifest.resolve())
        return 0
    if args.command == "all":
        return all_checks(root)
    if args.command == "publication":
        from scripts.generate_publication_values import verify, verify_sources, scan
        result = {"values": verify(), "sources": verify_sources(), "latex": scan(root),
                  "chinese_latex": scan(root, entry="paper-cn/main.tex")}
        paths = [root / "paper/data/publication_values.json", root / "paper/generated/values/data_macros.tex",
                 *sorted((root / "paper/generated/values").glob("table_*.tex")),
                 root / "paper/build/main.pdf", root / "paper-cn/build/main.pdf"]
        paths.extend(root / "paper" / target for target in result["latex"]["graphics"])
        errors = list(result["latex"]["errors"])
        errors.extend(result["chinese_latex"]["errors"])
        seen = set()
        for artifact in paths:
            errors.extend(verify_sidecar(root, artifact, seen=seen))
        result["provenance_errors"] = errors
        result["status"] = "FAIL" if errors else "PASS"
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2 if errors else 0
    if args.command == "audit":
        from cactus.governance.audit import audit_project
        result = audit_project(root)
        for finding in result["findings"]:
            print(f"{finding['severity'].upper()} {finding['code']} {finding['path']}")
        print(result["status"])
        return 0 if result["status"] == "PASS" else 2
    if args.command == "dual_lens":
        code, errors = verify_dual_lens(root, no_cherry_pick=args.no_cherry_pick, retry_chain=args.retry_chain, context_inherit=args.context_inherit)
        for error in errors:
            print(f"FAIL {error}")
        if not errors:
            print("PASS dual-lens structural gate")
        return code
    if args.command == "provenance":
        code, errors = verify_provenance(root)
        for error in errors:
            print(f"FAIL {error}")
        if not errors:
            print("PASS generated artifact provenance")
        return code
    if args.command == "gate":
        if args.dual_action == "scan-latex":
            code, errors = scan_latex(root)
        else:
            code, errors = verify_dual_lens(root, no_cherry_pick=args.no_cherry_pick, retry_chain=args.retry_chain, context_inherit=args.context_inherit)
        for error in errors:
            print(f"FAIL {error}")
        if not errors:
            print("PASS gate check")
        return code
    for message in validate_schemas(root):
        print(message)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
