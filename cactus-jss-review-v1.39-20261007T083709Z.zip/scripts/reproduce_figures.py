from reproduce_review_artifact import reproduce
reproduce('figures')
