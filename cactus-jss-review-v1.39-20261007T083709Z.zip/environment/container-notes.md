# 环境范围

版本：v1.0

本包不要求 Docker；Python 与 TeX/Poppler 需要安装。包外验证使用同宿主独立目录和新 virtualenv，不等于另一宿主或容器。当前平台传递依赖闭包已冻结于 requirements-lock.txt；不声明冻结操作系统、字体或其他平台的条件依赖。
