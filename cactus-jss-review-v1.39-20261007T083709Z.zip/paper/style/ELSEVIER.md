# Elsevier 样式来源

当前 JSS 稿使用 Elsevier `elsarticle` 3.5（2026-01-09）和
`elsarticle-harv.bst`。这两个文件从已安装的 TeX Live 2026 发行版原样复制，
保留原版权及 LPPL 许可证声明，不修改出版社的样式实现。

出版管线在 `paper/publication_sources.json` 固定其完整 SHA-256。
参考：[Elsevier 官方 LaTeX 说明](https://www.elsevier.com/researcher/author/policies-and-guidelines/latex-instructions)。

历史 ACM 样式文件继续保留，仅用于旧稿档案。
