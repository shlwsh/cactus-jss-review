# CACTUS JSS 审稿复现包

这是版本化的审稿复现包。发布 URL 和旧 DOI 的版本边界见 paper/review_release.json。
本地打包不认证公开访问；下载哈希和包外运行由同版本发布报告另行记录，不声明匿名。
生产准入代码保持原样，synthetic fixtures 不代表正式授权或观察到的 repair 结果。

需要 Python 3.11+、environment/requirements.txt 中的依赖及 TeX/Poppler。
不需要模型凭据，不调用模型或 SWE-bench evaluator。已安装依赖时，以下命令离线执行：

```text
python scripts/reproduce_review_artifact.py verify
python scripts/validate_mutations.py
python scripts/reproduce_tables.py
python scripts/reproduce_figures.py
python scripts/build_paper.py
python scripts/reproduce_review_artifact.py all
```

输入 hashes 写入 artifact_manifest.json；修改输入会失败。输出是 paper/build/main.pdf 和 review_reproduction_result.json。
各命令不会调用 research-workspace 的完整历史 source admission。
包内 publication_sources 指向脱敏投影，与研究工作区的原始证据绑定分别记录。
原始 RUN、完整 source history、授权原文、模型 provider snapshot、服务器配置、计费身份和日志未打包。
完整历史准入需在原研究工作区运行 paper_pipeline.py build/validate；本包不能替代它。
expected/ 内的值与 TeX 必须重算一致；图件 PNG 检查另行记录，PDF 二进制可能受生成时间影响。
LICENSE 延续已有 Zenodo 系列记录的 CC BY 4.0，出版社样式保留自身 LPPL notice。
