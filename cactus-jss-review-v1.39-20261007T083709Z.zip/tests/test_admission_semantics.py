"""Staged admission regression tests with explicitly synthetic fixtures."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from cactus.governance.admission import evaluate_admission, valid_evaluator
from cactus.governance.canonical import canonical_json
from cactus.trace.manifest import initialize_bundle
from scripts.run_admission_semantic_suite import OPERATORS, mutate, reseal, summarize


class AdmissionSemanticsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.contract = {"experiment_id": "EXP-SYNTHETIC-TEST", "source": {"git_commit": "1"*40},
                         "workload": {"driver": "driver.py", "sha256": "2"*64},
                         "derivation": {"script": "derive.py", "sha256": "3"*64},
                         "model": {"model_version": "test-v1"},
                         "images": {"test": {"repository": "swebench/sweb.eval.x86_64.demo_1776_demo-1", "digest": "sha256:"+"4"*64}}}
        # An authorization-shaped fixture is only a test input, never owner approval.
        self.auth = {"schema_version": "1.0", "authorization_type": "session_confirmation", "status": "approved",
                     "experiment_id": "EXP-SYNTHETIC-TEST", "approved_by": "project_owner",
                     "approved_at": "2026-10-07T00:00:00Z", "confirmation_quote": "SYNTHETIC UNIT FIXTURE ONLY",
                     "scope": "not an experiment authorization",
                     "contract_sha256": hashlib.sha256(canonical_json(self.contract).encode()).hexdigest()}
        self.bundle = self.make_bundle("RUN-20261007T000000Z-ABCDEF01", "demo__demo-1", 100)
        self.donor = self.make_bundle("RUN-20261007T000000Z-ABCDEF02", "other__other-2", 200)

    def make_bundle(self, name, task, tokens):
        path = self.root/name
        bundle = initialize_bundle(path, study_id="MSCC-TEST", experiment_id="EXP-SYNTHETIC-TEST", run_id=name,
                                   commit="1"*40, config={"task": {"task_id": task}, "model": {"model_version": "test-v1"},
                                   "evaluator_image": "swebench/sweb.eval.x86_64."+task.replace('__','_1776_')+"@sha256:"+"4"*64},
                                   environment={"capture_mode": "observed"}, command=["synthetic-unit-fixture"])
        manifest = json.loads((path/'run_manifest.json').read_text()); manifest['task_id'] = task
        bundle.write_json('run_manifest.json',manifest)
        bundle.write_json('contract.json',self.contract)
        bundle.write_text('contract.sha256',self.auth['contract_sha256']+'\n')
        bundle.write_json('raw/result.json',{"schema_version":"2.0", "run_id":name, "experiment_id":"EXP-SYNTHETIC-TEST",
                          "generated_at":"2026-10-07T00:00:00Z", "data":{"task_id":task,"resolved":True,"evaluator_valid":True,
                          "input_tokens":tokens,"output_tokens":0,"verified_usd_spend":.1},
                          "evidence":{"origin_type":"measured","integrity_status":"verified"}})
        bundle.write_text('raw/prediction.jsonl',json.dumps({"instance_id":task,"model_patch":"diff --git a/a b/a\n--- a/a\n+++ b/a\n@@ -1 +1 @@\n-a\n+b\n"})+'\n')
        report = {name:0 for name in ["completed_instances","resolved_instances","unresolved_instances","error_instances",
                  "infra_failure_instances","ambiguous_failure_instances","unstopped_instances","empty_patch_instances"]}
        report.update(completed_instances=1,resolved_instances=1,completed_ids=[task],resolved_ids=[task],unresolved_ids=[])
        bundle.write_json('evaluation/result.json',report)
        bundle.write_json('billing/litellm_spend.json',{"status":"verified_cost","total_tokens":tokens,"total_spend":.1,
                          "provider_usage_reconciliation":{"status":"matched","provider_tokens":tokens,"billing_tokens":tokens}})
        bundle.seal()
        return path

    def check(self, auth=None, lookup=None):
        lookup = lookup or (lambda _root, _commit, relative: "2"*64 if relative == "driver.py" else "3"*64)
        return evaluate_admission(self.root,self.bundle,self.contract,authorization=auth or self.auth,source_lookup=lookup)

    def test_valid_control(self):
        self.assertTrue(self.check()['admitted'])

    def test_every_resealed_operator_reaches_its_semantic_rule(self):
        original = {p.relative_to(self.bundle):p.read_bytes() for p in self.bundle.rglob('*') if p.is_file()}
        for operator,reason in OPERATORS.items():
            with self.subTest(operator=operator):
                for relative,data in original.items(): (self.bundle/relative).write_bytes(data)
                auth = copy.deepcopy(self.auth)
                mutate(operator,self.bundle,self.donor,donor_commit="5"*40,driver_digest="6"*64)
                if operator == 'S07_authorization_substitution': auth['experiment_id']='EXP-OTHER-TEST'
                result = self.check(auth)
                self.assertTrue(result['integrity_passed'],result['reasons'])
                self.assertEqual(result['stage'],'semantic')
                self.assertIn(reason,result['reasons'])

    def test_unsealed_tamper_stops_before_semantics(self):
        (self.bundle/'raw/prediction.jsonl').write_text('tampered')
        result=self.check(lookup=lambda *_:self.fail('source lookup after integrity failure'))
        self.assertEqual(result['stage'],'integrity')
        self.assertFalse(result['admitted'])

    def test_resealed_driver_at_bound_revision_is_checked_independently(self):
        self.assertIn('contract_driver_source_hash_mismatch', self.check(lookup=lambda *_:"6"*64)['reasons'])

    def test_unavailable_source_fails_closed(self):
        def missing(*_): raise FileNotFoundError('missing source')
        self.assertIn('admission_evidence_unreadable',self.check(lookup=missing)['reasons'])

    def test_missing_authorization_fails_closed(self):
        self.assertIn('authorization_contract_mismatch',self.check(auth={'status':'approved'})['reasons'])

    def test_model_version_drift_is_semantic(self):
        path=self.bundle/'resolved_config.json'; data=json.loads(path.read_text()); data['model']['model_version']='test-v2'
        path.write_text(json.dumps(data)); reseal(self.bundle)
        self.assertIn('model_version_contract_mismatch',self.check()['reasons'])

    def test_evaluator_boolean_counts_are_not_integers(self):
        report=json.loads((self.bundle/'evaluation/result.json').read_text()); report['resolved_instances']=True
        self.assertFalse(valid_evaluator(report))

    def test_confusion_matrix_uses_admission_decisions(self):
        cases=[{'operator':name,'decision':{'admitted':name=='control','stage':'none' if name=='control' else 'semantic',
                'integrity_passed':True,'reasons':[] if name=='control' else [reason], 'elapsed_sec':.01}}
                for name,reason in [('control',''),*OPERATORS.items()]]
        result=summarize(cases)
        self.assertEqual((result['tp'],result['fn'],result['fp'],result['tn']),(8,0,0,1))
        cases[0]['decision']['admitted']=False
        self.assertEqual(summarize(cases)['fp'],1)


if __name__ == '__main__': unittest.main()
