"""Fresh synthetic package cases must reach each original semantic reason."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import urllib.request

from scripts import validate_packaged_semantics as validation


class PackagedSemanticValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temporary.name).resolve()
        cls.core_digest = validation.digest(validation.ROOT / 'src/cactus/governance/admission.py')
        with redirect_stdout(io.StringIO()), \
             patch.object(urllib.request, 'urlopen', side_effect=AssertionError('network in offline validation')), \
             patch.object(subprocess, 'run', side_effect=AssertionError('Git/shell lookup in capsule validation')):
            cls.report = validation.run(cls.root)

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_complete_synthetic_controls_and_mutations(self):
        self.assertEqual(self.report['verdict'], 'PASS')
        summary = self.report['summary']
        self.assertEqual((summary['tp'], summary['fn'], summary['fp'], summary['tn']), (160, 0, 0, 20))
        self.assertEqual(len(self.report['cases']), 180)
        self.assertEqual(len({case['case_id'] for case in self.report['cases']}), 180)
        self.assertEqual(len({case['task_id'] for case in self.report['cases']}), 20)
        self.assertEqual(summary['integrity_rejections'], 0)
        self.assertEqual(summary['semantic_rejections'], 160)

    def test_original_operator_definitions_reach_their_intended_rules(self):
        self.assertEqual(self.report['operators'], validation.OPERATORS)
        for operator, reason in validation.OPERATORS.items():
            group = [case for case in self.report['cases'] if case['operator'] == operator]
            self.assertEqual(len(group), 20)
            for case in group:
                self.assertTrue(case['decision']['integrity_passed'])
                self.assertEqual(case['decision']['stage'], 'semantic')
                self.assertIn(reason, case['decision']['reasons'])

    def test_all_cases_materialized_and_source_bytes_independently_pinned(self):
        for case in self.report['cases']:
            bundle = self.root / case['bundle_path']
            self.assertTrue(bundle.is_dir())
            self.assertEqual(validation.tree_hash(bundle), case['bundle_tree_sha256'])
        for name, digest in self.report['source_capsule_hashes'].items():
            self.assertEqual(validation.digest(self.root / name), digest)
        self.assertEqual(self.core_digest, validation.digest(validation.ROOT / 'src/cactus/governance/admission.py'))

    def test_generated_report_cannot_claim_observed_case_replay_or_owner_approval(self):
        self.assertEqual(self.report['origin'], 'synthetic')
        self.assertFalse(self.report['fixture_authorization_is_owner_approval'])
        self.assertIn('not replay of observed archive cases', self.report['scope'])
        self.assertTrue(all(case['origin'] == 'synthetic' for case in self.report['cases']))
        provenance = json.loads((self.root / 'synthetic_semantic_validation.json.provenance.json').read_text())
        snapshot = self.root / provenance['immutable_snapshot']
        self.assertEqual(snapshot.read_bytes(), (self.root / 'synthetic_semantic_validation.json').read_bytes())
        self.assertEqual(validation.digest(snapshot), provenance['artifact_sha256'])

    def test_skipped_operator_is_reported_as_failure_instead_of_fake_coverage(self):
        actual_mutate = validation.mutate

        def skip_billing(operator, *args, **kwargs):
            if operator != 'S05_billing_substitution':
                actual_mutate(operator, *args, **kwargs)

        with tempfile.TemporaryDirectory() as directory, redirect_stdout(io.StringIO()), \
             patch.object(validation, 'mutate', side_effect=skip_billing):
            report = validation.run(Path(directory))
        self.assertEqual(report['verdict'], 'FAIL')
        self.assertEqual(report['summary']['fn'], 20)
        self.assertEqual(report['summary']['per_operator']['S05_billing_substitution']['intended_rule_detected'], 0)
        self.assertEqual(report['validation_failures'], [f'S05_billing_substitution-{index:03d}' for index in range(1, 21)])


if __name__ == '__main__':
    unittest.main()
