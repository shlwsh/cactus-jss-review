"""Counterfactual controls and exact reference intervals without new execution."""
import json
import shutil
import unittest

from scripts.generate_publication_values import clopper_pearson, validate_near_valid_projection, verify_near_valid_resealing
from scripts.run_near_valid_controls import OPERATORS, transform, summarize
from tests import test_admission_semantics as fixtures


class NearValidControlTests(unittest.TestCase):
    def setUp(self):
        # Reuse a synthetic bundle fixture without inheriting its test methods.
        self.fixture = fixtures.AdmissionSemanticsTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)

    def test_representational_prediction_preserves_exact_task_and_patch(self):
        path = self.fixture.bundle / "raw/prediction.jsonl"
        before = json.loads(path.read_text())
        transform("N01_prediction_representation", self.fixture.bundle)
        after = json.loads(path.read_text())
        after.pop("near_valid_control_metadata")
        self.assertEqual(before, after)
        result = self.fixture.check()
        self.assertTrue(result["integrity_passed"])
        self.assertTrue(result["admitted"])

    def test_consistent_usage_is_accepted_and_inconsistent_usage_is_rejected(self):
        transform("N02_consistent_usage_variant", self.fixture.bundle)
        self.assertTrue(self.fixture.check()["admitted"])
        from scripts.run_admission_semantic_suite import reseal
        path = self.fixture.bundle / "raw/result.json"
        raw = json.loads(path.read_text()); raw["data"]["input_tokens"] += 1
        path.write_text(json.dumps(raw)); reseal(self.fixture.bundle)
        result = self.fixture.check()
        self.assertTrue(result["integrity_passed"])
        self.assertIn("billing_attempt_usage_mismatch", result["reasons"])

    def test_exact_intervals_at_boundaries_and_non_boundary(self):
        self.assertAlmostEqual(clopper_pearson(160, 160)[0], .9772082505445335)
        self.assertAlmostEqual(clopper_pearson(20, 20)[0], .8315665290169147)
        self.assertAlmostEqual(clopper_pearson(0, 20)[1], .16843347098308528)
        self.assertAlmostEqual(clopper_pearson(5, 10)[0], .1870860284473987)
        self.assertAlmostEqual(clopper_pearson(5, 10)[1], .8129139715526013)
        for successes, trials in [(True, 20), (21, 20), (-1, 20), (0, 0)]:
            with self.assertRaises(ValueError):
                clopper_pearson(successes, trials)

    def test_control_summary_counts_false_rejections(self):
        cases = [{"operator": op, "decision": {"admitted": True, "integrity_passed": True, "stage": "none"}}
                 for op in OPERATORS]
        self.assertEqual(summarize(cases, 1)["fp"], 0)
        cases[0]["decision"].update(admitted=False, stage="semantic")
        result = summarize(cases, 1)
        self.assertEqual(result["fp"], 1)
        self.assertEqual(result["specificity"], .5)
        self.assertEqual(result["per_operator"]["N01_prediction_representation"]["fp"], 1)

    def projected_study(self):
        return {"original_trees": {f"seed-{i}": "a"*64 for i in range(1, 21)},
                "cases": [{"case_id": f"{operator}-{i:03d}", "operator": operator, "seed_run_id": f"seed-{i}",
                           "expected_admitted": True, "decision": {"admitted": True, "integrity_passed": True}}
                          for i in range(1, 21) for operator in OPERATORS]}

    def test_projected_coverage_does_not_require_original_files_but_rejects_duplicate_ids(self):
        study = self.projected_study()
        validate_near_valid_projection(study)
        study["cases"][1]["case_id"] = study["cases"][0]["case_id"]
        with self.assertRaisesRegex(ValueError, "case coverage drift"):
            validate_near_valid_projection(study)

    def test_projected_decisions_reject_truthy_numbers_and_seed_index_drift(self):
        study = self.projected_study()
        study["cases"][0]["decision"]["admitted"] = 1
        with self.assertRaisesRegex(ValueError, "decision type drift"):
            validate_near_valid_projection(study)
        study = self.projected_study()
        study["cases"][0]["case_id"] = study["cases"][0]["operator"]+"-020"
        study["cases"][38]["case_id"] = study["cases"][38]["operator"]+"-001"
        with self.assertRaisesRegex(ValueError, "seed index drift"):
            validate_near_valid_projection(study)

    def test_resealed_change_to_ignored_manifest_field_is_not_a_control(self):
        target = self.fixture.root / "near-control"
        shutil.copytree(self.fixture.bundle, target)
        transform("N01_prediction_representation", target)
        study = self.projected_study()
        for case in study["cases"]:
            case.update(seed_path=self.fixture.bundle.name, bundle_path=target.name)
        verify_near_valid_resealing(study, self.fixture.root)
        path = target / "run_manifest.json"; manifest = json.loads(path.read_text())
        manifest["command"] = ["unrelated-command"]
        path.write_text(json.dumps(manifest))
        from scripts.run_admission_semantic_suite import reseal
        reseal(target)
        with self.assertRaisesRegex(ValueError, "manifest changed beyond resealing"):
            verify_near_valid_resealing(study, self.fixture.root)


if __name__ == "__main__":
    unittest.main()
