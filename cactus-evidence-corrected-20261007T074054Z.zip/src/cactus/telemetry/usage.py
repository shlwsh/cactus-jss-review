"""Provider-independent token and cost accounting."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from cactus.domain.models import ModelUsage


@dataclass(frozen=True, slots=True)
class PriceCard:
    input_per_million: float
    output_per_million: float
    version: str
    currency: str = "USD"


def load_price_card(path: Path) -> PriceCard:
    """Load a frozen local price card used for secondary reconcile checks."""
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("status") != "FROZEN":
        raise ValueError(f"price card is not frozen: {path}")
    version = str(payload["price_version"])
    currency = str(payload.get("currency", "USD"))
    if "input_per_million" in payload and "output_per_million" in payload:
        return PriceCard(float(payload["input_per_million"]), float(payload["output_per_million"]), version, currency)
    return PriceCard(
        float(payload["input_cost_per_token"]) * 1_000_000,
        float(payload["output_cost_per_token"]) * 1_000_000,
        version,
        currency,
    )


class CostLedger:
    def __init__(self, price: PriceCard | None = None) -> None:
        self.price = price
        self.calls: list[ModelUsage] = []

    def add(self, usage: ModelUsage) -> None:
        if usage.input_tokens < 0 or usage.output_tokens < 0 or usage.cached_tokens < 0:
            raise ValueError("token counts cannot be negative")
        if usage.provider_cost is not None and usage.provider_cost < 0:
            raise ValueError("provider_cost cannot be negative")
        self.calls.append(usage)

    @property
    def input_tokens(self) -> int:
        return sum(item.input_tokens for item in self.calls)

    @property
    def output_tokens(self) -> int:
        return sum(item.output_tokens for item in self.calls)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    @property
    def provider_cost(self) -> float | None:
        if not self.calls or any(item.provider_cost is None for item in self.calls):
            return None
        return sum(float(item.provider_cost or 0.0) for item in self.calls)

    @property
    def local_cost(self) -> float | None:
        if self.price is None:
            return None
        return self.input_tokens / 1_000_000 * self.price.input_per_million + self.output_tokens / 1_000_000 * self.price.output_per_million

    @property
    def cost(self) -> float | None:
        """Prefer LiteLLM-reported spend; fall back to frozen local PriceCard."""
        if self.provider_cost is not None:
            return self.provider_cost
        return self.local_cost

    def reconcile(self, provider: ModelUsage) -> dict[str, object]:
        """Compare aggregate local accounting with provider-reported usage."""
        local = ModelUsage(self.input_tokens, self.output_tokens, sum(item.cached_tokens for item in self.calls))
        deltas = {
            "input_tokens": provider.input_tokens - local.input_tokens,
            "output_tokens": provider.output_tokens - local.output_tokens,
            "cached_tokens": provider.cached_tokens - local.cached_tokens,
        }
        return {"status": "PASS" if not any(deltas.values()) else "FAIL", "local": local, "provider": provider, "deltas": deltas}

    def reconcile_cost(self, *, abs_tolerance: float = 1e-9) -> dict[str, object]:
        """Compare LiteLLM spend against the frozen local PriceCard."""
        provider = self.provider_cost
        local = self.local_cost
        if provider is None or local is None:
            return {"status": "SKIP", "provider_cost": provider, "local_cost": local, "delta": None}
        delta = provider - local
        return {
            "status": "PASS" if abs(delta) <= abs_tolerance else "FAIL",
            "provider_cost": provider,
            "local_cost": local,
            "delta": delta,
            "price_version": None if self.price is None else self.price.version,
            "currency": None if self.price is None else self.price.currency,
        }
