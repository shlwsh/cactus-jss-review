"""Provider-neutral token counting.

The fallback is explicitly labelled approximate; a provider tokenizer can be
injected later and its version must be recorded in the run manifest.
"""

from __future__ import annotations

import re
from collections.abc import Callable


class TokenCounter:
    def __init__(self, counter: Callable[[str], int] | None = None, *, tokenizer_id: str = "fallback-lexical-v1") -> None:
        self._counter = counter
        self.tokenizer_id = tokenizer_id

    @property
    def exact(self) -> bool:
        return self._counter is not None

    def count(self, text: str) -> int:
        if self._counter:
            value = self._counter(text)
            if value < 0:
                raise ValueError("tokenizer returned a negative count")
            return value
        return len(re.findall(r"\w+|[^\w\s]", text, flags=re.UNICODE))
