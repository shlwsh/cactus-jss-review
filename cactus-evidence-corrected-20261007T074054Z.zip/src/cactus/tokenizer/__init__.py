"""Tokenizer abstractions and deterministic fallback counter."""

from .counter import TokenCounter

__all__ = ["TokenCounter"]
