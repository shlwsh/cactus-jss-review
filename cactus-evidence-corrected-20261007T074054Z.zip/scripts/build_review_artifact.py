"""Create a sanitized, versioned local review artifact without publishing it."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'src')]
from scripts.artifact_provenance import write


def save(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8',newline='\n')


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def create(output: Path):
    output=output.resolve(); output.relative_to(ROOT)
    archive=output.with_name(output.name+'.zip')
    if output.exists() or archive.exists(): raise FileExistsError('refusing to overwrite review artifact')
    output.mkdir(parents=True)
    inputs=[]
    def copy(relative):
        source=ROOT/relative; target=output/relative
        target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(source,target); inputs.append(source)
    # Code is copied byte-for-byte; omit runtime credentials/configuration and logs.
    # Retain package initializers and their transitive imports, including the
    # trace/evaluation helpers imported by the exact production implementation.
    for package in ['domain','trace','evaluation','execution','failure_recovery']:
        for path in sorted((ROOT/'src/cactus'/package).glob('*.py')):
            copy(path.relative_to(ROOT).as_posix())
    for relative in ['src/cactus/__init__.py','src/cactus/governance/__init__.py','src/cactus/runner/__init__.py',
                     'src/cactus/trace/__init__.py','src/cactus/registry/__init__.py','src/cactus/tools/__init__.py',
                     'src/cactus/evaluation/__init__.py']:
        if (ROOT/relative).is_file(): copy(relative)
    for relative in ['src/cactus/governance/admission.py','src/cactus/governance/canonical.py','src/cactus/governance/schema.py',
                     'src/cactus/governance/policy.py','src/cactus/governance/evidence_locations.py',
                     'src/cactus/runner/bundle_validator.py','src/cactus/trace/manifest.py','src/cactus/trace/bundle.py',
                     'src/cactus/registry/store.py','src/cactus/evaluation/taxonomy_v2.py',
                     'src/cactus/tools/datactl.py',
                     'scripts/reproduce_review_artifact.py','scripts/generate_publication_values.py','scripts/artifact_provenance.py',
                     'scripts/verify_cited_papers.py','scripts/paper_pipeline.py','scripts/check_publication_pdf.py',
                     'scripts/audit_evidence_corpus.py','scripts/derive_p04_matched_results.py','scripts/derive_fault_injection_matrix.py',
                     'scripts/run_admission_semantic_suite.py','scripts/import_formal_run_bundles.py',
                     'scripts/aggregate_lite50_results.py','scripts/aggregate_observed_results.py',
                     'tests/test_admission_semantics.py','tests/test_review_artifact.py','paper/main.tex','paper/references.bib',
                     'paper/style/elsarticle.cls','paper/style/elsarticle-harv.bst','paper/style/ELSEVIER.md',
                     'paper/submission/highlights.txt','paper/data/publication_bibliography.bbl']:
        copy(relative)
    for directory,pattern in [('experiments/schemas','*.json'),('configs/policies','*.json'),('paper/generated/values','*.tex')]:
        for path in (ROOT/directory).glob(pattern): copy(path.relative_to(ROOT).as_posix())
    for name in ['plot_style.py','generate_admission_values.py','generate_fig_system_overview.py','generate_fig_dual_lens_workflow.py','generate_fig_failure_taxonomy.py','generate_fig_semantic_admission.py']:
        copy('paper/figures/'+name)
    for path in (ROOT/'paper/figures/output').glob('*'):
        if path.name.startswith(('fig_admission_values.','fig_system_overview.','fig_dual_lens_workflow.','fig_failure_taxonomy.','fig_semantic_admission.','fig_evidence_conflict.')) and path.suffix in {'.pdf','.png'}:
            copy(path.relative_to(ROOT).as_posix())
    config=json.loads((ROOT/'paper/publication_sources.json').read_text())
    consumed={'retry_inventory','retry_registry','retry_summary','corpus_summary','corpus_inventory','historical_admission',
              'scoring_source','marginal_source','repair_source','publication_policy','bib_source','citation_manifest',
              'bibliography_style','document_class','ablation_results','sensitivity_results','p04_matched_derived_metrics',
              'jss_source_audit','fault_injection_raw','fault_derivation_source','p04_derivation_source',
              'semantic_mutations','semantic_mutation_source','admission_core','admission_cases'}
    projected={}
    for key in sorted(consumed & config['sources'].keys()):
        binding=config['sources'][key]; relative=binding['path']; source=ROOT/relative
        inputs.append(source)
        if key=='semantic_mutations':
            data=json.loads(source.read_text())
            # Preserve observed decisions/latency, omit unredacted contracts and authorization.
            data['cases']=[{k:c[k] for k in ['case_id','operator','seed_run_id','expected_admitted','decision']} for c in data['cases']]
            data['package_role']='sanitized recorded-decision projection; cannot replay original observed cases'
            save(output/relative,data)
        elif key in {'ablation_results','sensitivity_results'}:
            data=json.loads(source.read_text()); save(output/relative,{'summaries':data['summaries'],'package_role':'summary projection only'})
        elif key=='retry_inventory':
            rows=[json.loads(line) for line in source.read_text().splitlines()]
            target=output/relative; target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in rows),encoding='utf-8')
            (output/'data').mkdir(exist_ok=True); shutil.copyfile(target,output/'data/retry_inventory_sanitized.jsonl')
        else:
            copy(relative)
        projected[key]={'path':relative,'sha256':sha(output/relative)}
    package_config={'schema_version':'1.0','policy':'packaged projections for paper regeneration; no original archive admission or full replay claim',
                    'sources':projected}
    save(output/'paper/publication_sources.json',package_config)
    citations=json.loads((ROOT/'paper/data/scholar/cited_papers_manifest.json').read_text())
    for record in citations['records']: copy(record['file_path'])
    cases=json.loads((ROOT/config['sources']['admission_cases']['path']).read_text())
    save(output/'data/evidence_chain_cases.json',cases)
    inventory=[json.loads(line) for line in (ROOT/config['sources']['retry_inventory']['path']).read_text().splitlines()]
    save(output/'data/exclusion_reasons.json',{'role':'overlapping attempt-level reasons; not disjoint task outcomes',
         'records':[{'run_id':r['run_id'],'task_id':r['task_id'],'admitted':r['admitted'],'exclusion_reasons':r['exclusion_reasons']} for r in inventory]})
    matched=json.loads((ROOT/config['sources']['p04_matched_derived_metrics']['path']).read_text())
    save(output/'data/matched_prediction_archive_metadata.json',{'role':'secondary diff-marked output endpoint; no evaluator-backed repair claims',
         'cohort_size':matched['cohort_size'],'strategies':list(matched['strategy_metrics'])})
    save(output/'admission/production_checker/implementation.json',{'path':'src/cactus/governance/admission.py','sha256':sha(output/'src/cactus/governance/admission.py'),
         'publication_caller':'scripts/import_formal_run_bundles.py','mutation_caller':'scripts/run_admission_semantic_suite.py'})
    save(output/'admission/mutation_suite/scope.json',{'regression_fixtures':'tests/test_admission_semantics.py',
         'fixture_origin':'synthetic; authorization-shaped inputs are test data, never owner approval',
         'observed_case_replay':'requires omitted original archive, source history and authorizations'})
    save(output/'publication/layout.json',{'sources':'paper/publication_sources.json','ledger_generator':'scripts/generate_publication_values.py',
         'rendering_gate':'scripts/check_publication_pdf.py','release_checks':'scripts/reproduce_review_artifact.py'})
    for command,label in [('tables','reproduce_tables'),('figures','reproduce_figures'),('mutations','validate_mutations'),('paper','build_paper')]:
        (output/'scripts'/f'{label}.py').write_text('from reproduce_review_artifact import reproduce\nreproduce('+repr(command)+')\n',encoding='utf-8')
    requirements='\n'.join(name+'=='+version(name) for name in ['jsonschema','matplotlib','numpy','pillow'])+'\n'
    (output/'environment').mkdir(); (output/'environment/requirements.txt').write_text(requirements,encoding='utf-8')
    save(output/'environment/versions.json',{'python':sys.version.split()[0],'tools':['pdflatex','bibtex','pdftotext'],
         'network':'not required by reproduction commands','credentials':'not included or required'})
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    docs={
        '证据模型': '任务、attempt、prediction、evaluator 和 admission 分开记录。hash 证明所绑定内容身份，不能证明跨对象语义一致。论文核心 checker 与 mutation harness 共用同一源码。脱敏投影保持记录决策，不升级为独立验证原始事实。',
        'Schema说明': 'experiments/schemas 为原样 schema。production checker 位于 src/cactus/governance/admission.py。它先检查 bundle 完整性，再检查冻结合同、授权、来源、任务、报告与计费。测试 fixture 是 synthetic，不是正式实验 RUN。',
        '可复现性层级': 'Level 1：包内投影重算 tables/figures/prose 并编译 PDF。Level 2：synthetic fixtures 执行共用 core；原始 180 案例重判需要保留 RUN、Git 历史及授权，不随本包公开。Level 3：完整 replay 需要单独许可、凭据和冻结运行环境，未宣称达成。公开 DOI、匿名访问验证与许可证决策仍待作者完成。',
    }
    (output/'docs').mkdir(exist_ok=True)
    for title,body in docs.items():
        (output/'docs'/f'v1.0_{stamp}_{title}.md').write_text(f'# {title}\n\n版本：v1.0\n\n时间（UTC）：{datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}\n\n{body}\n',encoding='utf-8')
    (output/'README.md').write_text('''# CACTUS JSS 本地审稿复现包候选

这是可复制运行的本地候选包，尚未公开存储或通过外部审稿人访问测试。
生产准入代码保持原样，synthetic fixtures 不代表正式授权或观察到的 repair 结果。

需要 Python 3.11+、environment/requirements.txt 中的依赖及 TeX/Poppler。
不需要模型凭据，不调用模型或 SWE-bench evaluator。已安装依赖时，以下命令离线执行：

```text
python scripts/reproduce_review_artifact.py verify
python scripts/validate_mutations.py
python scripts/reproduce_tables.py
python scripts/reproduce_figures.py
python scripts/build_paper.py
python scripts/reproduce_review_artifact.py all
```

输入 hashes 写入 artifact_manifest.json；修改输入会失败。输出是 paper/build/main.pdf 和 review_reproduction_result.json。
各命令不会调用 research-workspace 的完整历史 source admission。
包内 publication_sources 指向脱敏投影，与研究工作区的原始证据绑定分别记录。
原始 RUN、完整 source history、授权原文、模型 provider snapshot、服务器配置、计费身份和日志未打包。
完整历史准入需在原研究工作区运行 paper_pipeline.py build/validate；本包不能替代它。
LICENSE 记录当前未分配公开许可证，出版社样式保留自身 LPPL notice。
''',encoding='utf-8')
    (output/'LICENSE').write_text('CACTUS-origin material: no public distribution license has been assigned in the inspected repository.\nThis is a local review artifact candidate, not a licensed public release.\nThe authors must select distribution terms before deposit or external redistribution.\nThird-party material retains its original notices; Elsevier styles use LPPL (see paper/style/ELSEVIER.md).\n',encoding='utf-8')
    for path in output.rglob('*'):
        if path.is_file() and path.suffix in {'.json','.jsonl','.py','.tex','.md','.txt'}:
            text=path.read_text(encoding='utf-8',errors='replace')
            # Do not emit any matching sensitive values in error messages.
            if re.search(r'https?://(?:127\.0\.0\.1|10\.\d+\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+|192\.168\.\d+\.\d+)(?::\d+)?',text):
                raise ValueError('private endpoint in review artifact: '+path.relative_to(output).as_posix())
            if re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bsk-[A-Za-z0-9_-]{20,}',text):
                raise ValueError('credential-shaped content in review artifact: '+path.relative_to(output).as_posix())
    manifest={'schema_version':'1.0','generated_at':datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
              'role':'local review artifact candidate; public access and license pending',
              'reproducibility_levels':{'paper_regeneration':'packaged projections','admission':'synthetic fixtures; original replay requires retained archive',
                                        'full_replay':'not asserted'},
              'input_hashes':{p.relative_to(output).as_posix():sha(p) for p in sorted(output.rglob('*')) if p.is_file()
                              and not p.relative_to(output).as_posix().startswith(('paper/generated/','paper/figures/output/'))}}
    save(output/'artifact_manifest.json',manifest)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(output.rglob('*')):
            if path.is_file(): z.write(path,path.relative_to(output).as_posix())
    write(archive,[*set(inputs),Path(__file__)],Path(__file__),transform={'role':manifest['role'],
          'activity':'package exact code plus explicitly projected evidence; no publishing', 'reproducibility_levels':manifest['reproducibility_levels']},kind='derived_dataset')
    print(json.dumps({'directory':output.relative_to(ROOT).as_posix(),'archive':archive.relative_to(ROOT).as_posix(),'sha256':sha(archive)},indent=2))
    return archive


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,required=True)
    create(parser.parse_args().output)
