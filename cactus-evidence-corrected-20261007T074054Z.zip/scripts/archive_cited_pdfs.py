"""Archive genuine primary/author PDFs; verify local bytes and identity offline.

Metadata snapshots and document-only references are reported separately from
PDF coverage. Network access is opt-in and uses the caller's proxy settings.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
import sys
import unicodedata
import urllib.error
import urllib.request

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.verify_cited_papers import ROOT, BIB, TEX, MANIFEST, Metadata, cited, entries, sha

PDF_MANIFEST = ROOT / 'paper/data/scholar/cited_pdf_manifest.json'


def normalize(text):
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode()
    return re.sub(r'[^a-z0-9]', '', text.lower())


def inspect_pdf(path, title, first_author):
    if not path.read_bytes().startswith(b'%PDF-'):
        raise ValueError('response is not a PDF')
    info = subprocess.run(['pdfinfo', str(path)], capture_output=True, check=True, timeout=30)
    match = re.search(rb'Pages:\s*(\d+)', info.stdout)
    if not match or int(match[1]) < 1: raise ValueError('no readable PDF pages')
    pages = int(match[1])
    result = subprocess.run(['pdftotext', '-f', '1', '-l', str(min(pages, 2)), '-enc', 'UTF-8', str(path), '-'],
                            capture_output=True, check=True, timeout=30)
    text = result.stdout.decode('utf-8', errors='replace')
    normalized = normalize(text)
    # A title and first-author match near the front prevents an unrelated valid
    # PDF or a references-list hit from masquerading as the cited paper.
    title_pos = normalized.find(normalize(title))
    if not normalize(title) or not 0 <= title_pos < 2200:
        raise ValueError('PDF front-matter title does not match the cited metadata')
    if not normalize(first_author) or normalize(first_author) not in normalized[:3500]:
        raise ValueError('PDF first author does not match the cited metadata')
    return {'pages': pages, 'identity_check': 'normalized front-matter title and first author',
            'first_pages_text_sha256': hashlib.sha256(result.stdout).hexdigest()}


def download(plan_path, reuse_verified=False, capture_missing=True):
    from scripts.artifact_provenance import write
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    directory = ROOT / 'paper/data/papers' / ('pdf_archive_' + stamp)
    directory.mkdir(exist_ok=False)
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    bib = entries(BIB.read_text(encoding='utf-8'))
    metadata = {r['citation_key']: r for r in json.loads(MANIFEST.read_text(encoding='utf-8'))['records']}
    keys = cited()
    cached = {}
    if reuse_verified and PDF_MANIFEST.is_file():
        previous = json.loads(PDF_MANIFEST.read_text(encoding='utf-8'))
        if (previous['bib_sha256'], previous['tex_sha256'], previous['citation_manifest_sha256']) != (sha(BIB), sha(TEX), sha(MANIFEST)):
            raise ValueError('cannot reuse PDFs after source binding drift')
        cached = {r['citation_key']: r for r in previous['records'] if r['pdf_status'] == 'pdf_verified' or not capture_missing}
    def capture(key):
        fields = bib[key]['fields']; snapshot = metadata[key]
        if key in cached:
            record = dict(cached[key])
            if record['pdf_status'] != 'pdf_verified': return record
            path = (ROOT / record['file_path']).resolve(); path.relative_to(ROOT)
            if sha(path) != record['sha256']: raise ValueError('cached PDF bytes drift')
            inspect_pdf(path, fields['title'], fields['author'].split(' and ')[0].split(',')[0])
            target = directory / (key + '.pdf')
            shutil.copyfile(path, target)
            record.update(file_path=target.relative_to(ROOT).as_posix(), copied_from=path.relative_to(ROOT).as_posix(),
                          copy_verified_at=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'))
            write(target, [path, ROOT/snapshot['file_path'], plan_path, BIB], Path(__file__),
                  transform={'activity': 'copy and reverify retained primary PDF; original retrieval time preserved',
                             'source_url': record['source_url'], 'original_retrieved_at': record['retrieved_at']}, kind='derived_dataset')
            print(key, 'reused verified PDF', flush=True)
            return record
        base = {'citation_key': key, 'title': fields['title'], 'author': fields['author'],
                'year': fields['year'], 'doi': fields.get('doi'), 'metadata_file': snapshot['file_path'],
                'metadata_sha256': snapshot['sha256'], 'attempts': []}
        if key in plan['documentation_keys']:
            base['pdf_status'] = 'documentation_snapshot'
            return base
        urls = list(plan['sources'].get(key, []))
        if 'arxiv.org/abs/' in snapshot['url']:
            parser = Metadata(); parser.feed((ROOT / snapshot['file_path']).read_text(encoding='utf-8'))
            pdf_urls = parser.values.get('citation_pdf_url', [])
            urls = pdf_urls + urls
            if not urls: urls = [snapshot['url'].replace('/abs/', '/pdf/')]
        for url in dict.fromkeys(urls):
            trial = {'url': url}
            temporary = directory / (key + '.part')
            try:
                for attempt in range(3):
                    try:
                        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'CACTUS-citation-verification/1.0'}), timeout=45) as response:
                            data = response.read(80 * 1024 * 1024 + 1)
                            trial.update(final_url=response.url, content_type=response.headers.get('Content-Type'))
                        break
                    except urllib.error.HTTPError as exc:
                        if exc.code not in (429, 502, 503, 504) or attempt == 2: raise
                        time.sleep(3 * (attempt+1))
                    except urllib.error.URLError as exc:
                        # Retry transient TLS EOF/connection errors; never bypass
                        # certificate verification for a persistent trust error.
                        if 'CERTIFICATE_VERIFY_FAILED' in str(exc) or attempt == 2: raise
                        time.sleep(3 * (attempt+1))
                if len(data) > 80 * 1024 * 1024: raise ValueError('PDF download exceeds size bound')
                temporary.write_bytes(data)
                identity = inspect_pdf(temporary, fields['title'], fields['author'].split(' and ')[0].split(',')[0])
                path = directory / (key + '.pdf'); temporary.rename(path)
                trial['status'] = 'accepted'
                base.update(pdf_status='pdf_verified', source_url=url, final_url=trial['final_url'],
                            retrieved_at=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
                            file_path=path.relative_to(ROOT).as_posix(), sha256=sha(path),
                            file_size_bytes=path.stat().st_size, **identity)
                base['attempts'].append(trial)
                write(path, [ROOT / snapshot['file_path'], plan_path, BIB], Path(__file__),
                      transform={'activity': 'primary or author PDF capture', 'url': url, 'final_url': trial['final_url'], **identity}, kind='derived_dataset')
                print(key, 'PDF', identity['pages'], flush=True)
                return base
            except Exception as exc:
                trial.update(status='rejected', reason=type(exc).__name__ + ': ' + str(exc))
                base['attempts'].append(trial)
                if temporary.exists(): temporary.unlink()
        base['pdf_status'] = 'metadata_snapshot_only'
        print(key, base['pdf_status'], flush=True)
        return base
    with ThreadPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(capture, keys))
    manifest = {'schema_version': '1.0', 'generated_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
                'scope': 'actual manuscript citations; PDFs are local research copies, not redistribution rights',
                'bib_sha256': sha(BIB), 'tex_sha256': sha(TEX), 'citation_manifest_sha256': sha(MANIFEST),
                'source_plan_path': plan_path.relative_to(ROOT).as_posix(), 'source_plan_sha256': sha(plan_path),
                'generator_sha256': sha(Path(__file__)), 'records': records}
    data = json.dumps(manifest, ensure_ascii=False, indent=2)+'\n'
    immutable = directory / 'cited_pdf_manifest.json'
    immutable.write_text(data, encoding='utf-8', newline='\n')
    PDF_MANIFEST.write_text(data, encoding='utf-8', newline='\n')
    write(PDF_MANIFEST, [BIB, TEX, MANIFEST, plan_path, *[ROOT/r['file_path'] for r in records if r['pdf_status']=='pdf_verified']],
          Path(__file__), transform={'activity': 'archive and verify actual cited PDFs', 'historical_snapshot': immutable.relative_to(ROOT).as_posix()}, kind='derived_dataset')
    return verify()


def verify():
    data = json.loads(PDF_MANIFEST.read_text(encoding='utf-8'))
    if data['bib_sha256'] != sha(BIB) or data['tex_sha256'] != sha(TEX) or data['citation_manifest_sha256'] != sha(MANIFEST):
        raise ValueError('PDF manifest source bindings drifted')
    if data['generator_sha256'] != sha(Path(__file__)): raise ValueError('PDF verifier source drifted')
    plan = (ROOT/data['source_plan_path']).resolve(); plan.relative_to(ROOT)
    if sha(plan) != data['source_plan_sha256']: raise ValueError('PDF source plan drifted')
    keys = [r['citation_key'] for r in data['records']]
    if len(set(keys)) != len(keys) or set(keys) != set(cited()): raise ValueError('PDF manifest cited coverage drifted')
    bib = entries(BIB.read_text(encoding='utf-8'))
    meta = {r['citation_key']:r for r in json.loads(MANIFEST.read_text(encoding='utf-8'))['records']}
    counts = {}
    for record in data['records']:
        key = record['citation_key']; fields = bib[key]['fields']
        for field in ('title','author','year'):
            if fields[field] != record[field]: raise ValueError('PDF metadata drift: '+key)
        if record['metadata_sha256'] != meta[key]['sha256'] or record['metadata_file'] != meta[key]['file_path']:
            raise ValueError('PDF official metadata binding drift: '+key)
        path = (ROOT/record['metadata_file']).resolve(); path.relative_to(ROOT)
        if sha(path) != record['metadata_sha256']: raise ValueError('official metadata bytes drift: '+key)
        status = record['pdf_status']; counts[status] = counts.get(status, 0)+1
        if status == 'pdf_verified':
            path = (ROOT/record['file_path']).resolve(); path.relative_to(ROOT)
            if sha(path) != record['sha256'] or path.stat().st_size != record['file_size_bytes']:
                raise ValueError('PDF bytes drift: '+key)
            identity = inspect_pdf(path, fields['title'], fields['author'].split(' and ')[0].split(',')[0])
            if any(record[k] != v for k,v in identity.items()): raise ValueError('PDF identity drift: '+key)
        elif status not in ('documentation_snapshot', 'metadata_snapshot_only'):
            raise ValueError('unknown PDF status: '+key)
    report = {'status':'pass', 'total_cited':len(keys), 'counts':counts, 'manifest_sha256':sha(PDF_MANIFEST)}
    print(json.dumps(report)); return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--plan', type=Path)
    parser.add_argument('--reuse-verified', action='store_true')
    parser.add_argument('--consolidate', action='store_true', help='offline: copy and reverify the current archive without fetching missing PDFs')
    args = parser.parse_args()
    if args.download or args.consolidate:
        if args.download and args.consolidate: parser.error('choose download or offline consolidation')
        if args.plan is None: parser.error('--download requires --plan')
        plan = args.plan.resolve(); plan.relative_to(ROOT)
        download(plan, args.reuse_verified or args.consolidate, not args.consolidate)
    else: verify()
