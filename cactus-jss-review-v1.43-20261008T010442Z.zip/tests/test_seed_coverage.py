"""Complete per-seed coverage cannot be inferred from aggregate rejection counts."""
import copy
import unittest
from scripts.generate_publication_values import seed_coverage


class SeedCoverageTests(unittest.TestCase):
    def study(self):
        return {'original_trees': {'a': 'hash-a', 'b': 'hash-b'}, 'cases': [
            {'seed_run_id': seed, 'operator': op, 'decision': {
                'integrity_passed': True, 'admitted': op == 'control',
                'stage': 'none' if op == 'control' else 'semantic',
                'reasons': [] if op == 'control' else [op + '_reason']}}
            for seed in ('a', 'b') for op in ('control', 'x', 'y')]}

    def test_complete_projection_and_wrong_reason(self):
        study = self.study()
        operators = {'x': 'x_reason', 'y': 'y_reason'}
        self.assertEqual(seed_coverage(study, operators, semantic=True), {'total': 2, 'all_passed': 2})
        study['cases'][1]['decision']['reasons'] = ['different_reason']
        self.assertEqual(seed_coverage(study, operators, semantic=True)['all_passed'], 1)

    def test_missing_duplicate_or_unknown_pairs_fail(self):
        study = self.study()
        for cases in (study['cases'][:-1], study['cases'] + [study['cases'][0]],
                      study['cases'][:-1] + [dict(study['cases'][-1], seed_run_id='other')]):
            with self.assertRaisesRegex(ValueError, 'coverage drift'):
                seed_coverage(dict(study, cases=cases), {'x': 'x_reason', 'y': 'y_reason'}, semantic=True)

    def test_integrity_failure_does_not_count_as_semantic_success(self):
        study = self.study()
        study['cases'][1]['decision']['integrity_passed'] = False
        self.assertEqual(seed_coverage(study, {'x': 'x_reason', 'y': 'y_reason'}, semantic=True)['all_passed'], 1)

    def test_near_valid_requires_both_variants(self):
        study = self.study()
        study['cases'] = [case for case in study['cases'] if case['operator'] != 'control']
        for case in study['cases']:
            case['decision'].update(admitted=True, stage='none', reasons=[])
        operators = {'x': 'description x', 'y': 'description y'}
        self.assertEqual(seed_coverage(study, operators, semantic=False)['all_passed'], 2)
        study['cases'][0]['decision'].update(admitted=False, reasons=['reason'])
        self.assertEqual(seed_coverage(study, operators, semantic=False)['all_passed'], 1)


if __name__ == '__main__':
    unittest.main()
