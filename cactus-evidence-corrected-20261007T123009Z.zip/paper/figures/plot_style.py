"""Shared publication plotting style for the CACTUS/FACO manuscript figures."""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
from matplotlib import pyplot as plt

# Nature publication standard palette
PALETTE = {
    "blue_main": "#0F4D92",        # Primary method / brand blue
    "blue_secondary": "#3775BA",   # Secondary / sub-method
    "green_1": "#DDF3DE",
    "green_2": "#AADCA9",
    "green_3": "#27AE60",          # Success / resolved (clean Nature green)
    "red_1": "#F6CFCB",
    "red_2": "#E9A6A1",
    "red_strong": "#B64342",       # Unresolved / failure / warning
    "neutral_light": "#EFEFEF",
    "neutral_mid": "#767676",      # Evaluator error / neutral annotation
    "neutral_dark": "#4D4D4D",
    "neutral_black": "#272727",
    "gold": "#E28E2C",
    "teal": "#2E7D7E",             # Baselines / alternative methods
    "violet": "#7C6CCF",
    "grid": "#F2F2F2",
}

COLORS = {
    "method": PALETTE["blue_main"],
    "method_light": PALETTE["blue_secondary"],
    "baseline": PALETTE["teal"],
    "resolved": PALETTE["green_3"],
    "unresolved": PALETTE["red_strong"],
    "error": PALETTE["neutral_mid"],
    "accent": PALETTE["gold"],
    "grid": PALETTE["grid"],
    "text": PALETTE["neutral_black"],
    "subtext": PALETTE["neutral_dark"],
}

FONT = "Arial"
FONT_FAMILY = ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"]
FONT_SIZES = {
    "base": 7.5,
    "small": 7.0,
    "caption": 6.5,
    "label": 7.5,
    "title": 8.0,
    "pending": 12.0,
}


def apply_style() -> None:
    mpl.rcParams.update({
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "font.family": "sans-serif",
        "font.sans-serif": FONT_FAMILY,
        "font.size": FONT_SIZES["base"],
        "axes.labelsize": FONT_SIZES["label"],
        "axes.titlesize": FONT_SIZES["title"],
        "xtick.labelsize": FONT_SIZES["small"],
        "ytick.labelsize": FONT_SIZES["small"],
        "legend.fontsize": FONT_SIZES["small"],
        "legend.frameon": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.8,
        "axes.edgecolor": PALETTE["neutral_dark"],
        "text.color": PALETTE["neutral_black"],
        "axes.labelcolor": PALETTE["neutral_black"],
        "xtick.color": PALETTE["neutral_dark"],
        "ytick.color": PALETTE["neutral_dark"],
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
    })


def style_axis(axis) -> None:
    axis.tick_params(labelsize=FONT_SIZES["small"], color=PALETTE["neutral_dark"])
    axis.grid(axis="y", color=COLORS["grid"], linewidth=0.6, linestyle="-", zorder=0)
    axis.set_axisbelow(True)


def save(figure, output: Path, stem: str) -> None:
    output.mkdir(parents=True, exist_ok=True)
    figure.savefig(output / f"{stem}.pdf", bbox_inches="tight")
    figure.savefig(output / f"{stem}.svg", bbox_inches="tight")
    figure.savefig(output / f"{stem}.png", dpi=300, bbox_inches="tight")


# Threshold above which a categorical bar chart is re-rendered as horizontal
# bars with anonymised "task-XX" labels and an "n=k deduplicated tasks"
# subtitle. The previous version plotted every task ID on the x-axis, which
# produced the unreadable black block noted in the editor's review of fig5/6.
BAR_COUNT_THRESHOLD = 4


def auto_orient_bars(ax, names: list[str], values: list[float], *, orientation: str = "auto", color=None, width: float = 0.55):
    """Render a bar chart that auto-switches to horizontal bars past
    ``BAR_COUNT_THRESHOLD`` categories.

    Parameters
    ----------
    ax : matplotlib axis
        Target axis.
    names : list[str]
        Category labels (will be anonymised to ``task-XX`` past the threshold
        to avoid axis overflow).
    values : list[float]
        Bar magnitudes.
    orientation : str
        ``"auto"`` (default), ``"vertical"`` or ``"horizontal"``.
    color : optional
        Bar colour (defaults to ``COLORS["method"]``).
    width : float
        Bar width for vertical orientation.
    """
    import numpy as np
    from .plot_style import COLORS  # type: ignore  # late import to avoid cycle

    color = color or COLORS["method"]
    if orientation == "auto":
        orientation = "horizontal" if len(names) >= BAR_COUNT_THRESHOLD else "vertical"
    if orientation == "horizontal":
        labels = names if len(names) < BAR_COUNT_THRESHOLD else [f"task-{i + 1:02d}" for i in range(len(names))]
        bars = ax.barh(labels, values, color=color, edgecolor="none", zorder=2)
        ax.invert_yaxis()
        return bars
    bars = ax.bar(names, values, color=color, width=width, edgecolor="none", zorder=2)
    return bars
