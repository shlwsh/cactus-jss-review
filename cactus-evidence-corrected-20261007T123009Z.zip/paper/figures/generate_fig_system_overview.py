"""Generate a source-bound conceptual evaluation diagram (no empirical claims)."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import FancyBboxPatch
from plot_style import apply_style, COLORS
from scripts.artifact_provenance import write


def generate_figure():
    apply_style()
    fig, ax = plt.subplots(figsize=(7.0, 2.6))
    ax.set_xlim(0, 10); ax.set_ylim(0, 4); ax.axis("off")
    def box(x, y, width, label, color):
        ax.add_patch(FancyBboxPatch((x,y), width, 1.15, boxstyle="round,pad=0.08", facecolor="white", edgecolor=color, linewidth=1.5))
        ax.text(x+width/2, y+.575, label, ha="center", va="center", fontsize=11, color=COLORS["text"])
    def arrow(x1,y1,x2,y2):
        ax.annotate("", (x2,y2), (x1,y1), arrowprops={"arrowstyle":"->", "color":COLORS["subtext"], "lw":1.4})

    box(.2, 2.1, 2.7, "Retained evidence\nPrediction / evaluator\nRaw runner result", COLORS["method"])
    box(3.65, 2.1, 2.7, "Evidence admission\nIntegrity / semantic\nbindings", COLORS["baseline"])
    box(7.1, 2.1, 2.7, "Publication gate\nValue ledger\nRendered PDF", COLORS["accent"])
    arrow(2.98,2.675,3.55,2.675); arrow(6.43,2.675,7.0,2.675)
    box(3.65,.25,2.7,"Independent bindings\nContract / source\nAuthorization",COLORS["accent"])
    arrow(5.0,1.48,5.0,2.0)
    ax.text(.3,.8,"Context / edit component\nSupplies prediction evidence",fontsize=11,color=COLORS["subtext"])
    identifiers = ["weight.total", "marginal.relevance", "marginal.coverage_alpha"]
    stem = "fig_system_overview"

    source=ROOT/"paper/data/publication_values.json"
    out=ROOT/"paper/figures/output"
    fig.tight_layout()
    for suffix in ["pdf","png"]:
        path=out/(stem+"."+suffix)
        fig.savefig(path,dpi=300,bbox_inches="tight")
        write(path,[source,Path(__file__).with_name("plot_style.py")],Path(__file__), transform={"value_ids":identifiers,"numeric_annotations":"none; conceptual diagram"},kind="figure")
    plt.close(fig)

if __name__=="__main__":
    generate_figure()
