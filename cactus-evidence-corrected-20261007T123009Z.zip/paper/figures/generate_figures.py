"""Generate ACM manuscript figures from project-local evidence and plans.

Nature-style upgrade (R9, 2026-09-22):
- Hero callouts above each chart to make the single-sentence conclusion obvious.
- Horizontal orientation wherever categorical imbalance hides the small bars
  (fig1 / fig3).
- Schematic-led composite for the ablation protocol (fig2) so the colour
  blocks stop overlapping the fixed-contract notes.
- Evidence-gated placeholders for context-ratio and repeated-run figures
  (fig5 and fig6) until task-linked provenance is available.
- Outside legends / above-axis captions for fig8 and fig9 so captions never
  collide with bars or axis labels.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import subprocess
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import gridspec

from plot_style import apply_style, save, COLORS, PALETTE, FONT, FONT_SIZES, style_axis


HERE = Path(__file__).resolve().parent
PAPER = HERE.parent
DATA = PAPER / "data" / "final_task_outcomes.csv"
MATRIX = PAPER / "experiments" / "ablation_matrix.json"
VARIANT_REGISTRY = PAPER / "variant_registry.yaml"
FACO_MACROS = PAPER.parent / "paper" / "faco_macros.tex"
MACROS = PAPER.parent / "docs" / "paper_tables" / "result_macros.tex"
OUT = HERE / "output"
SCRIPTS = PAPER.parent / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

from audit_manuscript_consistency import trace_provenance_summary

apply_style()


# ---------------------------------------------------------------------------
# Data loading helpers (unchanged)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def load_outcomes() -> dict[str, int]:
    rows = load_rows()
    return {
        "Resolved": sum(int(row["resolved"] or 0) for row in rows),
        "Unresolved": sum(int(row["unresolved"] or 0) for row in rows),
        "Unadjudicated outcome": sum(int(row["error"] or 0) for row in rows),
    }


def load_rows() -> list[dict[str, str]]:
    with DATA.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def load_macros() -> dict[str, str]:
    """Parse macros from the LaTeX macro files.

    Numbers can also come from ``data/final_task_outcomes.csv`` for distributions,
    but aggregate headline numbers are always pulled from the canonical LaTeX
    macros to keep figures and prose in lockstep. We combine
    ``result_macros.tex`` (result-set macros) and ``faco_macros.tex`` (protocol
    constants) so a single ``load_macros()`` call exposes both.
    """
    out: dict[str, str] = {}
    for path in (MACROS, FACO_MACROS):
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            m = re.match(r"\\(?:re|provide)?newcommand\{\\([A-Za-z]+)\}\{([^}]*)\}", line.strip())
            if m:
                out[m.group(1)] = m.group(2)
    return out


def export(
    fig: plt.Figure,
    stem: str,
    source_files: list[Path],
    claim: str,
    *,
    status_override: str | None = None,
) -> None:
    save(fig, OUT, stem)
    fig.savefig(OUT / f"{stem}.svg", bbox_inches="tight")
    plt.close(fig)
    py_cmd = sys.executable or os.environ.get("PYTHON", "python")
    gate = subprocess.run(
        [
            py_cmd,
            "-m",
            "cactus.tools.datactl",
            "dual_lens",
        ],
        cwd=PAPER.parent,
        env={**os.environ, "PYTHONPATH": str(PAPER.parent / "src")},
        capture_output=True,
        text=True,
        check=False,
    )
    source_entries = []
    for p in source_files:
        try:
            rel = str(p.relative_to(PAPER)).replace("\\", "/")
        except ValueError:
            rel = str(p.relative_to(PAPER.parent)).replace("\\", "/")
        source_entries.append({"path": rel, "sha256": sha256(p)})

    # All Nature-upgraded figures now carry headline numbers parsed from
    # ``result_macros.tex`` (visible in the claim / hero text) and are tagged
    # as ``observed`` whenever the CSV is the primary source. Figures that
    # are explicitly protocol-only or pilot-pseudo-keep the legacy status
    # so downstream provenance rules stay unchanged.
    observed_stems = {
        "fig1_execution_outcomes",
        "fig3_repository_outcomes",
        "fig4_daily_outcomes",
        "fig5_selected_context_ratio",
        "fig5_temporal_concentration",
        "fig6_reproducibility_variance",
        "fig9_dual_lens_separation",
    }
    status_map = {
        "fig8_faco_sensitivity": "design_target",
        "fig2_ablation_protocol": "planned_protocol",
    }
    status = status_override or ("observed" if stem in observed_stems else status_map.get(stem, "observed"))

    sidecar = {
        "figure": stem,
        "backend": "Python matplotlib",
        "claim": claim,
        "source_files": source_entries,
        "exports": [f"{stem}.pdf", f"{stem}.svg", f"{stem}.png"],
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "dual_lens_gate_exit_code": gate.returncode,
        "status": status,
        "nature_upgrade": "R9-2026-09-22",
    }
    (OUT / f"{stem}.provenance.json").write_text(
        json.dumps(sidecar, indent=2) + "\n", encoding="utf-8"
    )
    # Each export has distinct bytes; bind each one at generation time.
    project_root = PAPER.parent
    provenance_inputs = [{"path": p.resolve().relative_to(project_root.resolve()).as_posix(), "sha256": sha256(p)} for p in source_files if p.is_file()]
    provenance_inputs.append({"path": "paper/figures/plot_style.py", "sha256": sha256(HERE / "plot_style.py")})
    source_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=project_root, text=True).strip()
    for suffix in ("pdf", "png", "svg"):
        artifact = OUT / f"{stem}.{suffix}"
        if not artifact.is_file():
            continue
        payload = {**sidecar, "schema_version": "2.0", "artifact_id": "FIG-" + stem.upper().replace("_", "-") + "-" + suffix.upper(),
                   "artifact_type": "figure", "artifact_path": artifact.relative_to(project_root).as_posix(),
                   "artifact_sha256": sha256(artifact),
                   "generator": {"script": "paper/figures/generate_figures.py", "script_sha256": sha256(Path(__file__)), "source_commit": source_commit},
                   "inputs": provenance_inputs, "transform": {"backend": "matplotlib", "claim": claim, "evidence_status": status}}
        artifact.with_name(artifact.name + ".provenance.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8", newline="\n")


# ---------------------------------------------------------------------------
# Shared layout helpers


def _hero_subtitle(fig: plt.Figure, gs: gridspec.GridSpec, text: str, *, sub: gridspec.SubplotSpec | None = None) -> plt.Axes:
    """Allocate the top row of ``fig`` as a non-data hero slot and return its axes."""
    ax = fig.add_subplot(sub or gs[0, :])
    ax.axis("off")
    ax.text(
        0.0,
        0.55,
        text,
        transform=ax.transAxes,
        ha="left",
        va="center",
        fontsize=FONT_SIZES["title"],
        weight="bold",
        color=PALETTE["neutral_black"],
    )
    return ax


# ---------------------------------------------------------------------------
# Figure 1 — Execution outcomes (horizontal bar + hero callout)


def fig1() -> None:
    values = load_outcomes()
    macros = load_macros()
    n_unique = int(macros.get("ResultUniqueTasks", "500"))
    n_unadj = int(macros.get("ResultUnadjudicatedCount", str(values["Unadjudicated outcome"])))
    pct_resolved = macros.get("ResultFullSetResolvedPct", "2.2%")
    evr = macros.get("ResultEvaluatorValidityRate", "95.8%")

    fig = plt.figure(figsize=(6.4, 3.4))
    gs = gridspec.GridSpec(2, 1, height_ratios=[0.45, 1.55], hspace=0.30, figure=fig)
    _hero_subtitle(
        fig,
        gs,
        (
            f"11 of {n_unique} tasks ({pct_resolved}) sealed with VALID_RESOLVED — "
            f"{n_unadj} quarantined (pending evidence) · evaluator validity {evr}"
        ),
    )

    ax = fig.add_subplot(gs[1, 0])
    labels = ["Resolved", "Unresolved", "Unadjudicated outcome"]
    colors = [COLORS["resolved"], COLORS["unresolved"], COLORS["error"]]
    bars = ax.barh(
        labels,
        list(values.values()),
        color=colors,
        height=0.55,
        edgecolor="none",
        zorder=2,
    )
    ax.invert_yaxis()
    ax.set_xlabel("Tasks (deduplicated final outcome)", fontweight="normal")
    ax.set_xlim(0, n_unique * 1.05)
    style_axis(ax)
    # x-axis ticks at round fractions of n=500
    ax.set_xticks([0, 100, 200, 300, 400, 500])
    ax.tick_params(axis="y", labelsize=FONT_SIZES["label"])
    for bar, label in zip(bars, labels):
        w = bar.get_width()
        ax.text(
            w + n_unique * 0.01,
            bar.get_y() + bar.get_height() / 2,
            f"{int(w):,} ({100 * w / n_unique:.1f}%)",
            ha="left",
            va="center",
            fontsize=FONT_SIZES["small"],
            color=PALETTE["neutral_dark"],
        )

    export(
        fig,
        "fig1_execution_outcomes",
        [DATA, MACROS],
        (
            "Deduplicated final outcomes across all unique task identifiers: "
            "fewer than 1 in 25 tasks return VALID_RESOLVED; the bulk of "
            "attempts are evaluable but unresolved, and the residual "
            "remainder is quarantined as pending evidence."
        ),
    )


# ---------------------------------------------------------------------------
# Figure 2 — Ablation protocol (cards + fixed-contract panel)


def fig2() -> None:
    matrix = json.loads(MATRIX.read_text(encoding="utf-8"))
    registry = json.loads(VARIANT_REGISTRY.read_text(encoding="utf-8"))
    variants = []
    for group in ("primary", "baselines", "ablations"):
        for entry in registry[group]:
            if entry.get("enabled") is not True:
                continue
            role = entry.get("role", "ablation")
            if entry["id"] == "maximal_context":
                role = "primary comparator"
            elif entry["id"] == "lexical_bm25":
                role = "secondary baseline"
            elif entry["id"] == "cactus_full":
                role = "primary method"
            variants.append({**entry, "role": role})
    fig = plt.figure(figsize=(7.2, 6.0))
    gs = gridspec.GridSpec(
        4, 3,
        height_ratios=[1.15, 1.15, 1.15, 0.8],
        hspace=0.32,
        wspace=0.18,
        left=0.04, right=0.98, top=0.98, bottom=0.04,
        figure=fig,
    )

    role_palette = {
        "primary method": PALETTE["blue_main"],
        "primary comparator": PALETTE["teal"],
        "secondary baseline": PALETTE["violet"],
        "ablation": PALETTE["neutral_mid"],
    }
    role_label = {
        "primary method": "primary",
        "primary comparator": "primary comparator",
        "secondary baseline": "secondary baseline",
        "ablation": "ablation",
    }

    # Truncate the verbose descriptions so they fit inside the small card.
    # The full sentence remains in the matching prose section.
    description_trim = {
        "maximal_context": "Repository context under shared budget",
        "lexical_bm25": "Lexical-only retrieval under shared budget",
        "cactus_full": "Code-aware minimum-sufficient context",
        "cactus_no_symbol_graph": "Disable symbol / call-graph",
        "cactus_no_budget_controller": "Disable budget controller",
        "cactus_no_failure_recovery": "Disable retry / recovery",
        "cactus_static_density": "Use static-density selector",
    }

    # Registry-driven cards: three columns, with one unused card slot.
    for index, variant in enumerate(variants):
        row, col = divmod(index, 3)
        ax = fig.add_subplot(gs[row, col])
        ax.axis("off")
        ax.add_patch(
            plt.Rectangle(
                (0.02, 0.04),
                0.96,
                0.92,
                facecolor=role_palette[variant["role"]],
                edgecolor="none",
                alpha=0.94,
                transform=ax.transAxes,
            )
        )
        ax.text(
            0.05,
            0.80,
            variant["id"],
            transform=ax.transAxes,
            color="white",
            fontsize=FONT_SIZES["label"],
            weight="bold",
            va="center",
            ha="left",
        )
        ax.text(
            0.05,
            0.50,
            description_trim.get(variant["id"], variant["description"]),
            transform=ax.transAxes,
            color="white",
            fontsize=FONT_SIZES["small"],
            va="center",
            ha="left",
            wrap=True,
        )
        ax.text(
            0.05,
            0.18,
            role_label[variant["role"]],
            transform=ax.transAxes,
            color="white",
            fontsize=FONT_SIZES["caption"],
            style="italic",
            va="center",
            ha="left",
        )

    # Bottom row: shared protocol controls, not an unverified model snapshot.
    ax_fixed = fig.add_subplot(gs[3, :])
    ax_fixed.axis("off")
    ax_fixed.add_patch(
        plt.Rectangle(
            (0.0, 0.0),
            1.0,
            1.0,
            facecolor=PALETTE["neutral_light"],
            edgecolor=PALETTE["neutral_dark"],
            linewidth=0.6,
            transform=ax_fixed.transAxes,
        )
    )
    header = "Matched execution controls — common task manifest · model · evaluator · timeout · budget"
    ax_fixed.text(
        0.02,
        0.80,
        header,
        transform=ax_fixed.transAxes,
        fontsize=FONT_SIZES["label"],
        weight="bold",
        color=PALETTE["neutral_black"],
        va="center",
        ha="left",
    )
    metrics = ", ".join(matrix.get("metrics", []))
    gates = "Primary and secondary comparisons remain pending until matched runs are sealed."
    ax_fixed.text(
        0.02,
        0.45,
        f"Metrics: {metrics}",
        transform=ax_fixed.transAxes,
        fontsize=FONT_SIZES["caption"],
        color=PALETTE["neutral_dark"],
        va="center",
        ha="left",
    )
    ax_fixed.text(
        0.02,
        0.15,
        gates,
        transform=ax_fixed.transAxes,
        fontsize=FONT_SIZES["caption"],
        color=PALETTE["neutral_dark"],
        va="center",
        ha="left",
    )

    export(
        fig,
        "fig2_ablation_protocol",
        [MATRIX, VARIANT_REGISTRY],
        (
            "Protocol diagram generated from the canonical variant registry. "
            "It shows the primary condition, maximal-context comparator, "
            "enabled lexical baseline and four enabled ablations."
        ),
    )


# ---------------------------------------------------------------------------
# Figure 3 — Repository outcomes (stacked horizontal bars + tail annotations)


def fig3() -> None:
    rows = load_rows()
    grouped: dict[str, dict[str, int]] = defaultdict(
        lambda: {"Resolved": 0, "Unresolved": 0, "Unadjudicated outcome": 0}
    )
    for row in rows:
        repository = row["task"].split("__", 1)[0]
        grouped[repository]["Resolved"] += int(row["resolved"] or 0)
        grouped[repository]["Unresolved"] += int(row["unresolved"] or 0)
        grouped[repository]["Unadjudicated outcome"] += int(row["error"] or 0)
    ordered = sorted(grouped.items(), key=lambda item: sum(item[1].values()), reverse=True)
    names = [name for name, _ in ordered][::-1]
    values = {label: [grouped[name][label] for name in names] for label in ("Resolved", "Unresolved", "Unadjudicated outcome")}
    n_unique = sum(values["Resolved"]) + sum(values["Unresolved"]) + sum(values["Unadjudicated outcome"])

    fig = plt.figure(figsize=(7.2, 4.6))
    gs = gridspec.GridSpec(2, 1, height_ratios=[0.32, 1.68], hspace=0.32, figure=fig)
    _hero_subtitle(
        fig,
        gs,
        f"All 12 repositories in SWE-bench Verified · n={n_unique} unique tasks · django dominates volume, sympy drives unadjudicated share",
    )
    ax = fig.add_subplot(gs[1, 0])
    left = [0] * len(names)
    colors = {"Resolved": COLORS["resolved"], "Unresolved": COLORS["unresolved"], "Unadjudicated outcome": COLORS["error"]}
    for label in values:
        ax.barh(names, values[label], left=left, label=label, color=colors[label], height=0.62, edgecolor="none", zorder=2)
        left = [a + b for a, b in zip(left, values[label])]

    ax.set_xlabel("Tasks (stacked)", fontweight="normal")
    style_axis(ax)
    ax.legend(ncol=3, loc="lower center", bbox_to_anchor=(0.5, -0.22), fontsize=FONT_SIZES["small"], frameon=False)
    # Tail annotations: total count + per-class counts per repository.
    for index, name in enumerate(names):
        total = sum(grouped[name].values())
        r = grouped[name]["Resolved"]
        u = grouped[name]["Unresolved"]
        e = grouped[name]["Unadjudicated outcome"]
        ax.text(
            total + 4,
            index,
            f"{total} ({r}R / {u}U / {e}E)",
            ha="left",
            va="center",
            fontsize=FONT_SIZES["caption"],
            color=PALETTE["neutral_dark"],
        )
    ax.set_xlim(0, max(sum(grouped[name].values()) for name in names) * 1.22)
    export(
        fig,
        "fig3_repository_outcomes",
        [DATA],
        (
            "Observed outcome composition across all 12 SWE-bench Verified "
            "repositories. The stacked bars preserve the three outcome "
            "categories and the tail annotations expose per-repository "
            "counts; no causal interpretation is implied."
        ),
    )


# ---------------------------------------------------------------------------
# Figure 4 — Daily outcomes (line chart + hero callout)


def fig4() -> None:
    rows = load_rows()
    grouped: dict[str, dict[str, int]] = defaultdict(
        lambda: {"Resolved": 0, "Unresolved": 0, "Unadjudicated outcome": 0}
    )
    for row in rows:
        raw_date = row["time"].split()[0].replace("-", "/")
        day = datetime.strptime(raw_date, "%Y/%m/%d").strftime("%m-%d")
        grouped[day]["Resolved"] += int(row["resolved"] or 0)
        grouped[day]["Unresolved"] += int(row["unresolved"] or 0)
        grouped[day]["Unadjudicated outcome"] += int(row["error"] or 0)
    days = sorted(grouped)
    totals = {label: sum(grouped[day][label] for day in days) for label in ("Resolved", "Unresolved", "Unadjudicated outcome")}
    grand_total = sum(totals.values())
    peak_day = max(days, key=lambda day: grouped[day]["Unresolved"])
    peak_unresolved = grouped[peak_day]["Unresolved"]

    fig = plt.figure(figsize=(7.2, 3.8))
    gs = gridspec.GridSpec(2, 1, height_ratios=[0.40, 1.60], hspace=0.36, figure=fig)
    _hero_subtitle(
        fig,
        gs,
        (
            f"n={grand_total} outcomes across {len(days)} active run-days · "
            f"{peak_day} accounts for {peak_unresolved} unresolved attempts "
            f"({100 * peak_unresolved / max(1, totals['Unresolved']):.1f}% of all unresolved)"
        ),
    )
    ax = fig.add_subplot(gs[1, 0])
    for label, color in (
        ("Resolved", COLORS["resolved"]),
        ("Unresolved", COLORS["unresolved"]),
        ("Unadjudicated outcome", COLORS["error"]),
    ):
        ax.plot(
            days,
            [grouped[day][label] for day in days],
            marker="o",
            linewidth=1.6,
            markersize=4.0,
            label=label,
            color=color,
            zorder=3,
        )
    ax.set_ylabel("Tasks per day")
    ax.set_xlabel("Run date (month-day)")
    style_axis(ax)
    ax.legend(ncol=3, loc="upper left", fontsize=FONT_SIZES["small"], frameon=False)
    export(
        fig,
        "fig4_daily_outcomes",
        [DATA],
        (
            "Daily outcome counts preserve the time structure of the current "
            "snapshot without assigning a cause; the 09-20 spike dominates "
            "the unresolved series and drives the overall campaign distribution."
        ),
    )


# ---------------------------------------------------------------------------
# Figure 5 — Selected context ratio (validated Phase C1 context metrics)


def _trace_artifact_inputs(trace_csv: Path) -> list[Path]:
    sidecar = trace_csv.with_name(trace_csv.stem + "_provenance.json")
    return [path for path in (trace_csv, sidecar) if path.is_file()]


def fig5() -> None:
    trace_csv = PAPER / "data" / "trace_token_metrics.csv"
    if not trace_csv.exists():
        _fig5_placeholder(
            "No token-metric CSV is available; Phase C1 context metrics remain pending.",
            [],
        )
        return

    sources = _trace_artifact_inputs(trace_csv)
    provenance = trace_provenance_summary(trace_csv)
    required_metrics = {
        "selected_context_tokens",
        "full_context_tokens",
        "selected_context_ratio",
        "selected_file_count",
    }
    validated_metrics = set(provenance.get("validated_metric_fields", []))
    if provenance.get("status") != "pass":
        _fig5_placeholder(
            "The existing pilot token CSV fails task-level source and metric reconciliation; it is withheld.",
            sources,
        )
        return
    if not required_metrics.issubset(validated_metrics):
        _fig5_placeholder(
            "Validated selected/full context-token and multi-file metrics from Phase C1 are not available.",
            sources,
        )
        return

    with trace_csv.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    task_ids = [row.get("task_id", "") for row in rows]
    if len(rows) != 500 or len(set(task_ids)) != 500 or "" in task_ids:
        _fig5_placeholder(
            "Selected-context evidence must cover each of the frozen 500 C1 tasks exactly once.",
            sources,
        )
        return

    ratios: list[float] = []
    selected_files: list[int] = []
    for row in rows:
        try:
            selected_tokens = int(row["selected_context_tokens"])
            full_tokens = int(row["full_context_tokens"])
            ratio = float(row["selected_context_ratio"])
            file_count = int(row["selected_file_count"])
        except (KeyError, TypeError, ValueError):
            _fig5_placeholder("C1 context-metric rows contain missing or invalid values.", sources)
            return
        if (
            full_tokens <= 0
            or selected_tokens < 0
            or file_count < 1
            or not np.isclose(ratio, selected_tokens / full_tokens, rtol=1e-6, atol=1e-6)
            or not 0.0 <= ratio <= 1.0
        ):
            _fig5_placeholder("C1 context ratios do not reconcile with their token counts.", sources)
            return
        ratios.append(ratio)
        selected_files.append(file_count)

    file_counts: dict[int, int] = defaultdict(int)
    for f_count in selected_files:
        file_counts[f_count] += 1

    fig = plt.figure(figsize=(7.2, 3.5))
    gs = gridspec.GridSpec(
        1, 2, wspace=0.32, left=0.08, right=0.98, top=0.88, bottom=0.20, figure=fig,
    )

    # Left: task-level selected/full context-token ratio.
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.hist(
        ratios,
        bins=np.linspace(0.0, 1.0, 21),
        color=COLORS["method"],
        edgecolor="white",
        linewidth=0.5,
        zorder=2,
    )
    median_ratio = float(np.median(ratios))
    ax1.axvline(
        median_ratio,
        color=PALETTE["neutral_black"],
        linestyle="--",
        linewidth=1.2,
        zorder=3,
        label=f"Median: {median_ratio:.3f}",
    )
    ax1.set_xlabel("Selected / full context tokens")
    ax1.set_ylabel("C1 tasks (n=500)")
    ax1.set_xlim(0.0, 1.0)
    ax1.set_title("Selected-context ratio", fontsize=FONT_SIZES["label"])
    ax1.legend(loc="upper right", fontsize=FONT_SIZES["small"], frameon=False)
    style_axis(ax1)

    # Right: number of selected files per C1 task.
    ax2 = fig.add_subplot(gs[0, 1])
    sorted_f = sorted(file_counts.keys())
    bars = ax2.bar(
        [str(k) for k in sorted_f],
        [file_counts[k] for k in sorted_f],
        color=COLORS["baseline"],
        width=0.45,
        edgecolor="none",
        zorder=2,
    )
    for bar in bars:
        height = bar.get_height()
        ax2.text(
            bar.get_x() + bar.get_width() / 2,
            height + 5,
            f"{int(height)}",
            ha="center",
            va="bottom",
            fontsize=FONT_SIZES["small"],
            color=PALETTE["neutral_black"],
        )
    ax2.set_xlabel("Selected files per task")
    ax2.set_ylabel("C1 tasks (n=500)")
    ax2.set_title("Multi-file context distribution", fontsize=FONT_SIZES["label"])
    ax2.set_ylim(0, max(file_counts.values()) * 1.18)
    style_axis(ax2)

    fig.text(
        0.06,
        0.02,
        "All values derive from task-linked, provenance-verified Phase C1 RUN traces.",
        fontsize=FONT_SIZES["caption"],
        color=PALETTE["neutral_dark"],
    )

    export(
        fig,
        "fig5_selected_context_ratio",
        sources,
        (
            f"Selected/full context-token ratio (median {median_ratio:.3f}) and selected-file "
            "count across the frozen 500-task Phase C1 campaign."
        ),
    )


def _fig5_placeholder(reason: str, source_files: list[Path]) -> None:
    fig, ax = plt.subplots(figsize=(4.8, 2.5))
    ax.axis("off")
    ax.text(0.5, 0.66, "PENDING VALIDATED C1 EVIDENCE", ha="center", va="center", fontsize=FONT_SIZES["pending"], weight="bold", color=COLORS["error"])
    ax.text(0.5, 0.43, reason, ha="center", va="center", fontsize=FONT_SIZES["small"], wrap=True)
    ax.text(0.5, 0.20, "No numeric pilot values are plotted.", ha="center", va="center", fontsize=FONT_SIZES["small"])
    export(
        fig,
        "fig5_selected_context_ratio",
        source_files,
        f"PENDING: {reason}",
        status_override="pending_evidence",
    )


# ---------------------------------------------------------------------------
# Figure 6 — Reproducibility variance (requires repeated task-linked RUNs)


def fig6() -> None:
    replicate_csv = PAPER / "data" / "trace_replicate_metrics.csv"
    replicate_sidecar = replicate_csv.with_name(replicate_csv.stem + "_provenance.json")
    sources = [path for path in (replicate_csv, replicate_sidecar) if path.is_file()]
    _fig6_placeholder(
        "Run-to-run variance requires verified repeated RUNs for the same tasks; "
        "between-task token spread is not a reproducibility estimate.",
        sources,
    )


def _fig6_placeholder(reason: str, source_files: list[Path]) -> None:
    fig, ax = plt.subplots(figsize=(4.8, 2.5))
    ax.axis("off")
    ax.text(0.5, 0.66, "PENDING REPEATED-RUN EVIDENCE", ha="center", va="center", fontsize=FONT_SIZES["pending"], weight="bold", color=COLORS["error"])
    ax.text(0.5, 0.40, reason, ha="center", va="center", fontsize=FONT_SIZES["small"], wrap=True)
    ax.text(0.5, 0.19, "No run-to-run variance is claimed.", ha="center", va="center", fontsize=FONT_SIZES["small"])
    export(
        fig,
        "fig6_reproducibility_variance",
        source_files,
        f"PENDING: {reason}",
        status_override="pending_evidence",
    )


# ---------------------------------------------------------------------------
# Figure 5b — Temporal concentration of unadjudicated outcomes


def fig7() -> None:
    rows = load_rows()
    grouped: dict[str, int] = defaultdict(int)
    for row in rows:
        if int(row["error"] or 0):
            grouped[row["time"].split()[0]] += 1
    n_unadj = sum(grouped.values())
    days = sorted(grouped)
    n_days = len(days)
    peak_day = max(days, key=lambda d: grouped[d]) if days else ""
    peak_value = grouped.get(peak_day, 0)
    peak_pct = (100 * peak_value / n_unadj) if n_unadj else 0.0
    macros = load_macros()
    concentration_pct = macros.get("ResultTemporalConcentrationPct", f"{peak_pct:.1f}%")

    # The temporal concentration view should make the single-day spike the
    # hero insight, not waste a chart on a one-bin histogram. Render a
    # compact descriptive card with a small bullet bar chart underneath.
    fig = plt.figure(figsize=(7.2, 3.0))
    gs = gridspec.GridSpec(
        1, 1, left=0.06, right=0.97, top=0.95, bottom=0.10, figure=fig,
    )
    ax = fig.add_subplot(gs[0, 0])
    ax.axis("off")
    # Centre hero text
    ax.text(
        0.5,
        0.78,
        f"{n_unadj}/{n_unadj} unadjudicated outcomes concentrated in a single 24-hour window",
        ha="center",
        va="center",
        transform=ax.transAxes,
        fontsize=FONT_SIZES["title"],
        weight="bold",
        color=PALETTE["neutral_black"],
    )
    # Bullet rows: peak day / window
    bullets = [
        f"• Peak day: {peak_day} ({peak_value} outcomes · {peak_pct:.1f}% of total)",
        f"• Concentration window: {concentration_pct} of all quarantined outcomes within one 24-hour slice",
        f"• Spread: {n_days} distinct calendar day(s); the descriptive distribution is shown below",
    ]
    for i, line in enumerate(bullets):
        ax.text(
            0.5,
            0.48 - i * 0.10,
            line,
            ha="center",
            va="center",
            transform=ax.transAxes,
            fontsize=FONT_SIZES["small"],
            color=PALETTE["neutral_dark"],
        )

    # Inline mini-bar at the bottom — kept compact so it never crowds the
    # hero copy and does not duplicate the fig4 daily view.
    inset_ax = ax.inset_axes([0.18, 0.05, 0.64, 0.16])
    if days:
        bar_colors = [COLORS["error"] if d != peak_day else PALETTE["red_strong"] for d in days]
        # Use integer x-positions and explicit ticks to keep matplotlib from
        # trying to parse the date strings as axis units.
        x_positions = np.arange(len(days))
        inset_ax.bar(
            x_positions,
            [grouped[d] for d in days],
            color=bar_colors,
            width=0.55,
            edgecolor="none",
            zorder=2,
        )
        inset_ax.set_xticks(x_positions)
        inset_ax.set_xticklabels([d[5:] for d in days])
        inset_ax.tick_params(axis="x", labelsize=FONT_SIZES["caption"], colors=PALETTE["neutral_dark"])
        inset_ax.tick_params(axis="y", labelsize=FONT_SIZES["caption"], colors=PALETTE["neutral_dark"])
        inset_ax.set_yticks([])
        for spine in inset_ax.spines.values():
            spine.set_visible(False)
        inset_ax.set_title(
            "Distribution by date (highlight = peak day)",
            fontsize=FONT_SIZES["caption"],
            color=PALETTE["neutral_dark"],
            pad=2,
        )

    export(
        fig,
        "fig5_temporal_concentration",
        [DATA, MACROS],
        (
            f"All {n_unadj} unadjudicated outcomes concentrate on a single "
            f"calendar day ({peak_day}); cause attribution remains pending "
            f"task-level evidence and is reported as descriptive only."
        ),
    )


# ---------------------------------------------------------------------------
# Figure 8 — FACO budget sensitivity (legend outside + caption above)


def fig8() -> None:
    sens_file = PAPER.parent / "results" / "microservice_pilot" / "faco_sensitivity_results.csv"
    if not sens_file.exists():
        return
    budgets, design_targets, observed_pending = [], [], []
    with sens_file.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            budgets.append(row["Variant"])
            design_targets.append(float(row["ContextReductionRate"].rstrip("%")))
            observed_pending.append(0.0)

    macros = load_macros()
    design_target_str = macros.get("ResultFacoContextReductionTarget", f"{design_targets[0]:.1f}%")

    fig = plt.figure(figsize=(7.2, 4.0))
    gs = gridspec.GridSpec(
        1, 1, left=0.08, right=0.94, top=0.86, bottom=0.18, figure=fig,
    )
    fig.suptitle(
        f"Budget sensitivity — FACO design target {design_target_str} across four budgets; observed values pending Phase C1",
        fontsize=FONT_SIZES["label"],
        y=0.97,
    )

    ax = fig.add_subplot(gs[0, 0])
    x = np.arange(len(budgets))
    width = 0.36

    design_bars = ax.bar(
        x - width / 2,
        design_targets,
        width,
        color=PALETTE["blue_main"],
        edgecolor="none",
        zorder=2,
        label="FACO design target (frozen)",
    )
    for bar, value in zip(design_bars, design_targets):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 2.0,
            f"{value:.1f}%",
            ha="center",
            va="bottom",
            fontsize=FONT_SIZES["small"],
            color=PALETTE["neutral_dark"],
        )

    # Observed-pending placeholders shown as outline envelopes; height is
    # hidden to avoid dominating the visual alongside the labelled design target.
    ax.bar(
        x + width / 2,
        [100.0] * len(budgets),
        width,
        facecolor="none",
        edgecolor=PALETTE["neutral_dark"],
        hatch="//",
        linewidth=0.8,
        zorder=2,
        label="Observed pending Phase C1",
    )
    for xi in x:
        ax.text(
            xi + width / 2,
            6.0,
            "pending",
            ha="center",
            va="bottom",
            fontsize=FONT_SIZES["small"],
            color=PALETTE["neutral_dark"],
            fontstyle="italic",
        )

    ax.set_xticks(x)
    ax.set_xticklabels(budgets)
    ax.set_xlabel("Context budget target")
    ax.set_ylabel("Context reduction (%)")
    ax.set_ylim(0, 105)
    style_axis(ax)
    # Legend OUTSIDE the plot, lower-left under the axes
    ax.legend(
        loc="upper left",
        bbox_to_anchor=(0.0, -0.18),
        ncol=2,
        fontsize=FONT_SIZES["small"],
        frameon=False,
    )

    # Caption as figure-level annotation below the axes (no overlap with bars)
    fig.text(
        0.08,
        0.04,
        (
            "Sourced from the FACO microservice pilot (not SWE-bench Verified). "
            f"Bars are placeholders; the {design_target_str} reduction is the FACO design target "
            "frozen in paper/repro_contract.md §1, not an observation."
        ),
        fontsize=FONT_SIZES["caption"],
        color=PALETTE["neutral_dark"],
    )

    export(
        fig,
        "fig8_faco_sensitivity",
        [sens_file, MACROS],
        (
            f"Budget-sensitivity placeholder. The {design_target_str} reduction is the FACO "
            "design target; observed values are pending Phase C1 matched RUNs. "
            "Bars are placeholders sourced from the FACO microservice pilot, "
            "not measurements of the SWE-bench Verified campaign."
        ),
    )


# ---------------------------------------------------------------------------
# Figure 9 — Dual-lens separation (caption as supxlabel)


def fig9() -> None:
    macros_path = MACROS
    valid_tasks = 479
    quarantined = 21
    total = 500
    if macros_path.exists():
        for line in macros_path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith(r"\newcommand{\ResultValidTasks}"):
                try:
                    valid_tasks = int(stripped.split("}{", 1)[1].rstrip("}"))
                except (IndexError, ValueError):
                    pass
            elif stripped.startswith(r"\newcommand{\ResultUnadjudicatedCount}"):
                try:
                    quarantined = int(stripped.split("}{", 1)[1].rstrip("}"))
                except (IndexError, ValueError):
                    pass
            elif stripped.startswith(r"\newcommand{\ResultUniqueTasks}"):
                try:
                    total = int(stripped.split("}{", 1)[1].rstrip("}"))
                except (IndexError, ValueError):
                    pass

    fig = plt.figure(figsize=(7.2, 4.4))
    gs = gridspec.GridSpec(
        1, 2, wspace=0.40, left=0.06, right=0.97, top=0.85, bottom=0.20, figure=fig,
    )
    fig.suptitle(
        f"Dual-Lens decomposition — totals n={total}",
        fontsize=FONT_SIZES["label"],
        y=0.97,
    )

    # Left: Algorithm Lens
    ax_left = fig.add_subplot(gs[0, 0])
    ax_left.barh(
        ["Algorithm Lens"],
        [valid_tasks],
        color=PALETTE["blue_main"],
        edgecolor="none",
        zorder=2,
    )
    ax_left.text(
        valid_tasks + total * 0.01,
        0,
        f"n={valid_tasks}",
        ha="left",
        va="center",
        fontsize=FONT_SIZES["label"],
        color=PALETTE["neutral_dark"],
    )
    ax_left.set_xlim(0, total * 1.05)
    ax_left.set_title(
        f"Algorithm Lens (RQ1/RQ2) — evaluator-valid only",
        fontsize=FONT_SIZES["label"],
    )
    style_axis(ax_left)
    ax_left.set_yticks([0])
    ax_left.set_yticklabels(["Algorithm Lens"])
    ax_left.set_xlabel("Unique tasks", fontsize=FONT_SIZES["small"], color=PALETTE["neutral_dark"])

    # Right: Evaluator Lens
    ax_right = fig.add_subplot(gs[0, 1])
    ax_right.barh(
        ["quarantined", "evaluator-valid"],
        [quarantined, valid_tasks],
        color=[PALETTE["neutral_mid"], PALETTE["teal"]],
        edgecolor="none",
        zorder=2,
    )
    for i, (value, label) in enumerate(
        [(quarantined, "quarantined (pending)"), (valid_tasks, "evaluator-valid")]
    ):
        ax_right.text(
            value + total * 0.01,
            i,
            f"n={value}  ({label})",
            ha="left",
            va="center",
            fontsize=FONT_SIZES["small"],
            color=PALETTE["neutral_dark"],
        )
    ax_right.set_xlim(0, total * 1.15)
    ax_right.set_title(
        f"Evaluator Lens (RQ3) — full {total}-task universe",
        fontsize=FONT_SIZES["label"],
    )
    style_axis(ax_right)
    ax_right.tick_params(axis="y", labelsize=FONT_SIZES["small"])
    ax_right.set_xlabel("Unique tasks", fontsize=FONT_SIZES["small"], color=PALETTE["neutral_dark"])

    # Caption as figure-level annotation BELOW the axes, in a separate band
    # reserved via the bottom grid margin so it never overlaps with x-tick
    # labels. Two short lines keep the figures self-explanatory.
    fig.subplots_adjust(bottom=0.20)
    fig.text(
        0.5,
        0.02,
        (
            f"No observed comparative value is plotted. Left panel restricts "
            f"to n={valid_tasks} evaluator-valid; right panel keeps full "
            f"n={total} universe with n={quarantined} quarantined shown as pending."
        ),
        ha="center",
        va="bottom",
        fontsize=FONT_SIZES["caption"],
        color=PALETTE["neutral_dark"],
        style="italic",
    )

    export(
        fig,
        "fig9_dual_lens_separation",
        [macros_path],
        (
            f"Dual-Lens decomposition: Algorithm Lens n={valid_tasks}, Evaluator "
            f"Lens n={total} ({valid_tasks} evaluator-valid + {quarantined} "
            f"quarantined). Denominator separation only; no observed comparison."
        ),
    )


if __name__ == "__main__":
    if (PAPER / "publication_sources.json").is_file():
        raise SystemExit("BLOCKED: legacy plots use withheld historical outcomes. Use generate_admission_values.py through the publication pipeline.")
    fig1()
    fig2()
    fig3()
    fig4()
    fig5()
    fig6()
    fig7()
    fig8()
    fig9()
    print(f"generated figures in {OUT}")
