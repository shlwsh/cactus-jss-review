"""Generate a source-bound conceptual evaluation diagram (no empirical claims)."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import FancyBboxPatch
from plot_style import apply_style, COLORS
from scripts.artifact_provenance import write


def generate_figure():
    apply_style()
    fig, ax = plt.subplots(figsize=(7.0, 2.6))
    ax.set_xlim(0, 10); ax.set_ylim(0, 4); ax.axis("off")
    def box(x, y, width, label, color):
        ax.add_patch(FancyBboxPatch((x,y), width, 1.15, boxstyle="round,pad=0.08", facecolor="white", edgecolor=color, linewidth=1.5))
        ax.text(x+width/2, y+.575, label, ha="center", va="center", fontsize=11, color=COLORS["text"])
    def arrow(x1,y1,x2,y2):
        ax.annotate("", (x2,y2), (x1,y1), arrowprops={"arrowstyle":"->", "color":COLORS["subtext"], "lw":1.4})

    box(.2, 2.1, 2.7, "Algorithm lens\nPatch + source identity", COLORS["baseline"])
    box(.2, .25, 2.7, "Evaluator lens\nValidity + repair outcome", COLORS["method"])
    box(3.65, 1.15, 2.7, "Evidence admission\nIndependent consistency", COLORS["accent"])
    box(7.1, 2.1, 2.7, "Admitted observation\nResolved or unresolved", COLORS["resolved"])
    box(7.1, .25, 2.7, "Excluded evidence\nRetain for investigation", COLORS["unresolved"])
    arrow(2.98,2.675,3.55,1.95); arrow(2.98,.825,3.55,1.5)
    arrow(6.43,1.95,7.0,2.675); arrow(6.43,1.5,7.0,.825)
    identifiers = ["retry.archived", "retry.admitted"]
    stem = "fig_dual_lens_workflow"

    source=ROOT/"paper/data/publication_values.json"
    out=ROOT/"paper/figures/output"
    fig.tight_layout()
    for suffix in ["pdf","png"]:
        path=out/(stem+"."+suffix)
        fig.savefig(path,dpi=300,bbox_inches="tight")
        write(path,[source,Path(__file__).with_name("plot_style.py")],Path(__file__), transform={"value_ids":identifiers,"numeric_annotations":"none; conceptual diagram"},kind="figure")
    plt.close(fig)

if __name__=="__main__":
    generate_figure()
