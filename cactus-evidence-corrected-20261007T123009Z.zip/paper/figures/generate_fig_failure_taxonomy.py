"""Draw conceptual task layers and verified attempt-level exclusion counts."""
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/"src")]
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from plot_style import apply_style,COLORS
from scripts.artifact_provenance import write


def generate():
    apply_style()
    source=ROOT/"paper/data/publication_values.json"
    values=json.loads(source.read_text(encoding="utf-8"))["values"]
    ids=["exclude.no_valid_official_evaluator","exclude.raw_evaluator_result_mismatch","exclude.contract_driver_source_hash_mismatch","exclude.billing_not_reconciled"]
    counts=[values[i]["value"] for i in ids]
    fig,(left,right)=plt.subplots(1,2,figsize=(7.1,2.8),gridspec_kw={"width_ratios":[1,1.35]})
    left.axis("off")
    left.text(.02,.97,"Task-level repair model",fontsize=11,fontweight="bold",va="top")
    left.text(.02,.72,"A: Prediction / generation\nUndefined names; rejected edits",fontsize=11,va="top")
    left.text(.02,.44,"B: Execution / functional\nIncorrect repair; regressions",fontsize=11,va="top")
    left.text(.02,.14,"Unverified task counts withheld",fontsize=11,color=COLORS["unresolved"])
    labels=["C: No valid report","C: Outcome disagreement","D: Source conflict","D: Billing mismatch"]
    right.barh(range(4),counts,color=[COLORS["method"],COLORS["method_light"],COLORS["accent"],COLORS["unresolved"]])
    right.set_yticks(range(4),labels,fontsize=11)
    right.invert_yaxis();right.set_xlim(0,max(counts)*1.2);right.set_xticks([])
    right.set_title("Attempt-level exclusions",fontsize=11,fontweight="bold")
    for y,ident,count in zip(range(4),ids,counts):
        right.text(count+.5,y,values[ident]["display"],va="center",fontsize=11)
    right.set_xlabel("Overlapping reasons / "+values["retry.archived"]["display"]+" archived attempts",fontsize=11)
    right.spines[["top","right","left","bottom"]].set_visible(False)
    right.tick_params(axis="y",length=0)
    fig.tight_layout(pad=1.2,w_pad=2)
    out=ROOT/"paper/figures/output"
    for suffix in ["pdf","png"]:
        path=out/("fig_failure_taxonomy."+suffix)
        fig.savefig(path,dpi=300,bbox_inches="tight")
        write(path,[source,Path(__file__).with_name("plot_style.py")],Path(__file__),transform={"value_ids":ids+["retry.archived"],"numeric_ticks":"none","numeric_annotations":"ledger.display"},kind="figure")
    plt.close(fig)

if __name__=="__main__":
    generate()
