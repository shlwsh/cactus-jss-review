"""Render the staged semantic-validation design from its bound implementation."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from matplotlib.patches import FancyBboxPatch
from plot_style import apply_style, COLORS
from scripts.artifact_provenance import write


def generate_figure():
    apply_style()
    fig, ax = plt.subplots(figsize=(7, 3.35))
    ax.set_xlim(0, 10); ax.set_ylim(0, 5); ax.axis('off')

    def box(x, y, label, color, height=1.15):
        ax.add_patch(FancyBboxPatch((x, y), 2.7, height,
                     boxstyle='round,pad=0.08', facecolor='white',
                     edgecolor=color, linewidth=1.5))
        ax.text(x+1.35, y+height/2, label, ha='center', va='center', fontsize=10.5)

    def arrow(start, end):
        ax.annotate('', end, start, arrowprops={'arrowstyle':'->',
                    'color':COLORS['subtext'], 'lw':1.4})

    box(.2, 3.4, 'Mutate isolated copies\nRecompute hashes / seal', COLORS['method'])
    box(3.65, 3.4, 'Bundle integrity\nChecksums / manifest', COLORS['baseline'])
    box(3.65, .45, 'Production semantic gate\nTask / source / contract\nEvaluator / raw / billing\nAuthorization / versions', COLORS['accent'], 2)
    box(7.1, 2.8, 'Reject mutated evidence\nRecord semantic reasons', COLORS['unresolved'])
    box(7.1, .55, 'Admit intact controls\nRetain separate decisions', COLORS['resolved'])
    arrow((2.99,3.975),(3.54,3.975))
    arrow((5,3.3),(5,2.55))
    ax.text(5.16,2.9,'pass',fontsize=10.5,va='center')
    arrow((6.44,1.95),(7.0,3.35))
    arrow((6.44,1.05),(7.0,1.125))
    ax.text(.2,1.6,'Original RUNs preserved\nIndependent frozen inputs\nSame checker as publication',fontsize=10.5,va='center')
    fig.tight_layout()
    out=ROOT/'paper/figures/output'; out.mkdir(parents=True,exist_ok=True)
    for suffix in ('pdf','png'):
        path=out/('fig_semantic_admission.'+suffix)
        fig.savefig(path,dpi=300,bbox_inches='tight')
        write(path,[ROOT/'paper/data/publication_values.json',
                    ROOT/'src/cactus/governance/admission.py',
                    Path(__file__).with_name('plot_style.py')],Path(__file__),
              transform={'numeric_annotations':'none; staged validation design',
                         'value_ids':['semantic.fault_count','semantic.control_count']},kind='figure')
    plt.close(fig)


def generate_conflict_figure():
    """Show the decision chain common to both retained case observations."""
    source=ROOT/'paper/data/publication_values.json'
    values=json.loads(source.read_text(encoding='utf-8'))['values']
    identifiers=[]
    for case in ('case.1.','case.2.'):
        identifiers.extend(case+key for key in ('evaluator_valid','raw_resolved','admitted','declared_driver_sha256','source_driver_sha256'))
        if (values[case+'evaluator_valid']['value'] is not True
                or values[case+'raw_resolved']['value'] is not False
                or values[case+'admitted']['value'] is not False
                or values[case+'declared_driver_sha256']['value']==values[case+'source_driver_sha256']['value']):
            raise ValueError('observed evidence-chain figure no longer matches cases')
    apply_style()
    fig,ax=plt.subplots(figsize=(7,3.1)); ax.set_xlim(0,10); ax.set_ylim(0,4); ax.axis('off')
    def box(x,y,label,color):
        ax.add_patch(FancyBboxPatch((x,y),2.7,1.15,boxstyle='round,pad=0.08',
                     facecolor='white',edgecolor=color,linewidth=1.5))
        ax.text(x+1.35,y+.575,label,ha='center',va='center',fontsize=11)
    def arrow(start,end):
        ax.annotate('',end,start,arrowprops={'arrowstyle':'->','color':COLORS['subtext'],'lw':1.4})
    box(.2,2.3,'Frozen contract\nDeclared driver digest',COLORS['method'])
    box(.2,.35,'Bound source revision\nActual driver bytes',COLORS['baseline'])
    box(3.65,2.3,'Admission comparison\nDriver digests disagree',COLORS['accent'])
    box(3.65,.35,'Retained evaluation\nValid / unresolved',COLORS['method'])
    box(7.1,2.3,'Evidence excluded\nSource / driver conflict',COLORS['unresolved'])
    arrow((2.99,2.875),(3.54,2.875)); arrow((2.99,.925),(3.54,2.48))
    arrow((5,1.58),(5,2.18)); arrow((6.44,2.875),(7,2.875))
    ax.text(7.15,.925,'Both real observations\nremain unchanged',fontsize=11,va='center')
    fig.tight_layout()
    for suffix in ('pdf','png'):
        path=ROOT/'paper/figures/output'/('fig_evidence_conflict.'+suffix)
        fig.savefig(path,dpi=300,bbox_inches='tight')
        write(path,[source,Path(__file__).with_name('plot_style.py')],Path(__file__),
              transform={'value_ids':identifiers,'numeric_annotations':'none; observed case-chain predicates'},kind='figure')
    plt.close(fig)


if __name__=='__main__':
    generate_figure()
    generate_conflict_figure()
