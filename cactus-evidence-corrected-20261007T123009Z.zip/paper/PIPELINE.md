# JSS 论文构建与数据准入管线

## 唯一出版入口

`publication_sources.json` 固定完整 SHA-256；`data/publication_values.json` 从这些来源及实现源码确定性生成。历史 `final_task_outcomes.csv`、`evidence_sources.json`、`data/evidence_catalog.json`、旧 result macros 和旧图表保留为档案，本稿不使用它们作为有效性结论。

统一链路：真实 RUN/官方 evaluator/源码 → 严格准入与全库核验快照 → 固定来源 → 数值账本 → `\DataValue{stable.id}`、表、图 → 当前英文 PDF → 版本 PDF。

## 命令

在仓库根目录执行 `bun run buildpdf`，即可使用项目 `acm/.venv` 编译当前英文论文，并自动递增版本输出到 `acm/pdf/`。参数会转交 Python 构建脚本，例如 `bun run buildpdf --version 1.25`。入口明确选择 Windows 或 POSIX 虚拟环境解释器，不依赖系统的 `python` 别名；首次使用先按项目说明运行 `bun run venv:setup`。

`buildpdf` 与兼容入口 `buildpdf:full` 均执行完整 `scripts/build_pdf.cjs` 流水线：重验引用快照与固定来源，重建 BibTeX、数值账本、表、图和英文稿，再通过出版校验与 PDF 来源链检查。仅在全部成功后发布新的版本 PDF，同时更新 `CACTUS_latest.pdf` 和 `CACTUS_JSS_latest.pdf` 及各自 provenance。默认命令不再使用简化编译脚本；版本递增同时识别历史 `CACTUS_v*` 和当前 `CACTUS_JSS_v*` 文件，不覆盖历史版本。

在 `acm/` 目录设置 `PYTHONPATH=src` 并将本机 TeX 引擎加入 PATH：

```powershell
python -m cactus.tools.datactl publication
python -m cactus.tools.datactl gate scan-latex
python scripts/paper_pipeline.py build
python scripts/paper_pipeline.py validate
python scripts/paper_pipeline.py audit
python scripts/audit_manuscript_consistency.py --strict
python scripts/build_pdf.py --version 1.36
python scripts/paper_pipeline.py package
```

`build` 实际重验官方文献快照、重试准入与历史核验快照，执行 BibTeX，生成账本/宏/表/图，并执行 pdflatex 编译当前英文稿。研究数值禁止直接写入正文、标题、表格或图；未知宏 ID 直接失败。自动章节/页码、排版尺寸及作者元数据不属于实验量。全部引用文献的排版内容也经过账本宏。

`publication` 核验中英文稿、可达 TeX、图与 PDF 的完整来源链。`datactl all` 与 `audit` 仍覆盖损坏历史档案，真实失败不得被局部出版 PASS 替代。

## 正文引用与本地 PDF

`scripts/verify_cited_papers.py` 仅覆盖当前正文实际引用的键。官方元数据快照记录题名、作者、年份及来源；新 DOI 条目同时核对 DOI 与发表场所。快照归档不代表已经取得论文 PDF。

本地 PDF 使用独立索引 `data/scholar/cited_pdf_manifest.json`，区分 `pdf_verified`、`documentation_snapshot` 和 `metadata_snapshot_only`。索引绑定当前正文、BibTeX 和官方元数据清单；每份 PDF 记录来源 URL、最终 URL、UTC 获取时间、完整 SHA-256、页数及首页题名/第一作者检查。历史目录不覆盖。

```powershell
# 离线检查当前引用和已归档 PDF，不请求网络。
python scripts/verify_cited_papers.py
python scripts/archive_cited_pdfs.py

# 按已核验的来源计划下载；运行前按项目规则配置并检查网络代理。
python scripts/archive_cited_pdfs.py --download --plan paper/data/scholar/pdf_source_plan_v3.json
```

PDF 核验拒绝 HTML 登录页、不可解析文件及题名/作者不符的有效 PDF；下载失败保留原因并使用已验证的元数据快照。引用修改后必须重新生成绑定，不能手工修改清单哈希。论文流水线的引用门禁核验元数据快照；上述 PDF 核验是另一个本地检查。审稿包保留官方元数据与论文重建输入，不打包第三方论文全文。

当前独立 retry 数据仅作失败任务重试的 supporting 观察，不汇入历史 500 题解决率，不支持 matched baseline、消融、成本改善或统计优越性主张。

旧 CSV 同步、宏/表与图生成入口在当前配置存在时阻断，禁止通过跳过 datactl 恢复旧数字。恢复历史结果须取得原始证据，生成新快照、重新绑定来源并完整重建。

## 交付范围

版本 PDF 与可变 latest 别名均有同次复制活动的 provenance，输入绑定编译 PDF 及其 sidecar。版本文件不得覆盖。

当前目标为 Journal of Systems and Software，使用固定的 Elsevier `elsarticle` 3.5 类文件、`preprint,12pt,authoryear` 单栏稿及 `elsarticle-harv` 作者—年份参考文献样式。类文件与 BST 的完整 SHA-256 固定于 `publication_sources.json`，构建检查正文实际样式与固定配置一致。来源与许可证见 `style/ELSEVIER.md`。

输出为 `acm/pdf/CACTUS_JSS_v<版本>_<UTC秒级时间戳>.pdf`，并更新 `CACTUS_latest.pdf` 和 `CACTUS_JSS_latest.pdf`。Highlights 单独保存在 `submission/highlights.txt`。作者贡献、资助与利益冲突声明须由作者确认；排版编译通过不等于研究证据齐备或已经完成投稿。

`package` 输出带 UTC 时间戳的 `cactus-evidence-corrected-*.zip`，保留本稿源码、宏、图、来源及生成脚本。原始全库 RUN 和 Git 历史不打包；完整准入复核仍需要它们，包内说明不能宣称独立完成实验重放。

该 ZIP 为带目录的本地出版源包。Editorial Manager 的上传源文件需另行扁平化整理，不将本地源包标记为已核验的投稿上传包。

文献默认离线核验已有官方 capture；新增文献需要按文献技能另行捕获与核验。本文未发起新的付费实验。

## JSS 审计修订的范围

当前构建与发布以 `paper/main.tex` 英文稿为入口；历史中文稿不参与本次发布，不将旧 `paper-cn/build/main.pdf` 复制成新版本。

`build` 同次重建实际引用的全部图件与标准 provenance sidecar，不再只修改旧图的账本哈希。最终 PDF 通过 Poppler 文本、页面边界及 TeX overfull/未定义引用检查；还需查看渲染页面。

100 题预测档案的 endpoint 为非空且含 diff 标记的预测输出，不是 evaluator-confirmed repair；patch length 为字符数。故障注入从逐案例记录重算混淆矩阵和平均/中位时延，严格区分 bundle 完整性拒绝与语义准入检测。任务级分类汇总因源内冲突撤回。完整独立人工编码、不可变模型 provider 快照和公开 DOI 尚未建立。

新增证据核查入口：`scripts/audit_jss_sources.py`（离线；输出必须是新文件）。它会验证完整匹配任务覆盖、推理 manifest 无 gold patch、预测统计可重算与测试日志一致性。保留 CRLF 字节哈希和原 manifest 声明值，不以规范化替代内容身份。

## v1.35 语义准入与本地审查包

生产准入、publication importer 和 mutation harness 共用 `src/cactus/governance/admission.py`。
`run_admission_semantic_suite.py` 仅创建新的离线 validation 目录，复制、变异并重新 seal；保留原 RUN 及旧 suite。
逐案例报告记录 integrity passage、semantic reason、TP/FN/FP/TN、每 operator 的 latency。
出版 source gate 会重判全部语义案例并核验原 seeds 和 case tree hashes，重判不重写已记录 latency。
`paper_pipeline.py audit` 现在执行完整 publication validation，再检查稿件路径独立性；不再仅检查工作站路径。

本地审查包由 `scripts/build_review_artifact.py --output <新版本目录>` 产生，拒绝覆盖已有目录。
解压后通过 `python scripts/reproduce_review_artifact.py all` 验证固定输入、synthetic 准入测试、投影重算、图表及 PDF。
包内 `scripts/reproduce_tables.py`、`reproduce_figures.py`、`validate_mutations.py`、`build_paper.py` 是同一路径的独立入口。
包内投影与研究工作区原始 RUN/source admission 的范围不同，前者不能证明后者。
匿名托管、外部访问验证、许可证与 DOI 仍待完成；本地候选包不等于公开发布。

## v1.40 修订与投稿候选包

以上 v1.35 段落是历史范围说明。v1.39 已公开发布，版本 DOI 为
`10.5281/zenodo.23207699`，系列 concept DOI 为
`10.5281/zenodo.23205936`。v1.40 当前为本地候选，新的 version DOI
和公开下载复验尚待完成；不能把系列或 v1.39 DOI 当作 v1.40 DOI。
`review_release.json` 的 `version_doi`、`release_status` 记录这一区别，
候选包的 `CITATION.cff` 不将 concept DOI 写入版本 DOI 字段。

`generate_publication_values.py` 从保留的逐案决策生成 seed-level 汇总和
operator × reason 覆盖表，要求每个 seed/operator 对唯一且完整，并要求
语义拒绝同时通过 integrity、达到 semantic stage 和 intended reason。
near-valid 控制必须与原语义 suite 使用同一组原 seed tree hashes。
没有增加 seeds、修改旧 suite 或重写原时延。

仅修改引用 note 时，可用旧 BibTeX 的完整字节作为显式输入重新验证：

```powershell
python scripts/archive_cited_pdfs.py --refresh-bindings --previous-bibliography <旧BibTeX快照>
```

正式出版版本迁移先执行官方元数据捕获与引用核验，再显式添加
`--migrate-versions`。迁移会重新检查旧 PDF 与官方快照，将正式版元数据
单列，并把旧预印本保存在 `retained_prior_capture`；没有取得正式版全文时
保持 `metadata_snapshot_only`，不把旧 PDF 改称正式版 PDF。默认 refresh
继续拒绝未经明确核验的 BibTeX 变化。

独立 review 包运行 `python scripts/reproduce_review_artifact.py all`，
同时检查 seed 汇总的缺案、重复案和错误 reason。投稿上传源由
`build_jss_submission_bundle.py` 扁平化、重新解压并隔离编译。
`build_jss_submission_materials.py --output <新版本目录>` 使用含
`python-docx` 的文档运行时准备 Highlights DOCX、利益声明草稿、
一页投稿信与 Artifact README PDF；研究构建环境无需该附加依赖。
DOCX 必须经实际渲染检查，声明草稿不得视为作者批准。

`check_jss_submission.py` 分开报告 technical、author 和 release 缺项。
正文声明即使没有占位符，也必须确认并与最终稿的 SHA-256 绑定。
完整构建和包外复现 PASS 不替代作者邮寄地址、贡献、利益关系、
资助/企业资源、AI 人类复核、原创性及两位作者批准，也不替代新的公开
制品核验或任何正式实验授权。
