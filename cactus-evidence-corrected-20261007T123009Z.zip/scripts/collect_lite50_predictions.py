"""Collect LITE50 prediction patches for official SWE-bench Evaluator.

Finds the best (longest valid patch) for each task across all runs,
then exports in SWE-bench format: {"instance_id": "...", "model_patch": "..."}

Usage:
    python scripts/collect_lite50_predictions.py [--output PREDICTIONS_PATH]
"""
import json
import sys
from pathlib import Path
from collections import defaultdict

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"
MANIFEST = PROJECT_ROOT / "data/manifests/swebench_lite50_b0dde109_test_inference_safe.jsonl"

# Priority order of runs (best → fallback)
RUN_PRIORITY = [
    "FACO-FULL-LITE50-STABLE",
    "FACO-FULL-LITE50-FINAL",
    "FACO-FULL-LITE50-POSTFIX",
    "FACO-FULL-LITE50-RESUME",
    "FACO-FULL-LITE50-20261003",
    "FACO-LITE50-",
    "ABLATION-FACO-20261003",
    "ABLATION-CACTUS_FULL",
    "DJ11019-FIXED",
]

def load_manifest():
    tasks = {}
    with open(MANIFEST, encoding="utf-8") as f:
        for line in f:
            t = json.loads(line)
            tasks[t["instance_id"]] = t
    return tasks

def best_run_for_task(task_id):
    """Return the best run directory for a task."""
    task_dirs = list(RUNS_DIR.glob(f"*/{task_id}/prediction.jsonl"))
    if not task_dirs:
        return None
    
    best_patch = ""
    best_source = ""
    for pred_path in task_dirs:
        try:
            with open(pred_path, encoding="utf-8") as f:
                data = json.loads(f.readline())
            patch = data.get("model_patch", "")
            if len(patch) > len(best_patch) and patch.strip():
                best_patch = patch
                best_source = pred_path.parent.parent.name
        except Exception:
            pass
    return best_patch, best_source if best_patch.strip() else (None, None)

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="experiments/derived/lite50_predictions_for_eval.jsonl")
    args = parser.parse_args()
    
    tasks = load_manifest()
    task_ids = list(tasks.keys())
    print(f"Total tasks: {len(task_ids)}")
    
    predictions = []
    found = 0
    missing = []
    
    for task_id in sorted(task_ids):
        patch, source = best_run_for_task(task_id)
        if patch:
            predictions.append({
                "instance_id": task_id,
                "model_name_or_path": "deepseek-coder",
                "model_patch": patch,
            })
            found += 1
            print(f"  {task_id}: {len(patch)} chars from {source}")
        else:
            missing.append(task_id)
            print(f"  {task_id}: NO PATCH FOUND")
    
    output_path = PROJECT_ROOT / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        for pred in predictions:
            f.write(json.dumps(pred, ensure_ascii=False) + "\n")
    
    print(f"\nCollected: {found}/{len(task_ids)}")
    if missing:
        print(f"Missing: {missing}")
    print(f"Output: {output_path}")

if __name__ == "__main__":
    main()
