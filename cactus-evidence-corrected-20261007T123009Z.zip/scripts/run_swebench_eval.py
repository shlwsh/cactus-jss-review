"""Run official SWE-bench Evaluator on collected LITE50 predictions.

Usage:
    python scripts/run_swebench_eval.py [--max-workers N] [--timeout SECONDS]
"""
import sys
import json
from pathlib import Path

# Add swebench to path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
PREDICTIONS = PROJECT_ROOT / "experiments/derived/lite50_predictions_for_eval.jsonl"

# Load instance IDs
instance_ids = []
with open(PREDICTIONS, encoding="utf-8") as f:
    for line in f:
        data = json.loads(line)
        instance_ids.append(data["instance_id"])

print(f"Loaded {len(instance_ids)} instances")
print(f"Predictions: {PREDICTIONS}")

# CRITICAL: Install LF-only Path.write_text before SWE-bench harness runs.
# On Windows, Path.write_text defaults to CRLF, which breaks Bash.
# The install_lf_write_text() patches it to use LF by default.
import importlib.util
_swebench_eval_lf_path = str(PROJECT_ROOT / "scripts" / "swebench_eval_lf.py")
_spec = importlib.util.spec_from_file_location("swebench_eval_lf", _swebench_eval_lf_path)
_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_module)
_module.install_lf_write_text()

# Run evaluation - use new report dir to avoid cache conflicts
from swebench.harness.run_evaluation import main

report_dir = PROJECT_ROOT / "experiments/derived/swebench_eval_reports_v2"

print(f"\nRunning official SWE-bench Evaluator (LF-fixed)...")
print(f"Report dir: {report_dir}")
result = main(
    dataset_name="SWE-bench_Lite",
    split="test",
    instance_ids=instance_ids,
    predictions_path=str(PREDICTIONS),
    max_workers=2,
    open_file_limit=1024,
    run_id="CACTUS-v1.31",
    timeout=1800,
    rewrite_reports=False,
    modal=False,
    report_dir=str(report_dir),
    task_repo=None,
)
print(f"\nEvaluation result: {result}")
