"""Prepare a consistent, planning-only matrix for the 50-task Pilot."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PLAN = ROOT / "artifacts" / "phase_c_pilot50_plan.json"
DEFAULT_OBSERVATION = ROOT / "artifacts" / "pilot50_image_digest_observation.json"
DEFAULT_CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-PILOT-V2.json"
DEFAULT_MODEL = ROOT / "configs" / "models" / "litellm_local.json"
DEFAULT_VARIANTS = ROOT / "config" / "variants"
DEFAULT_OUTPUT = ROOT / "artifacts" / "phase_c_pilot50_matrix.json"

PRIMARY = ("maximal_context", "lexical_bm25", "cactus_full")
ABLATIONS = ("cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density")
_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _read(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON input must be an object: {path}")
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _variant_path(directory: Path, variant: str) -> Path:
    candidates = [directory / f"{variant}.json"]
    if variant.startswith("cactus_"):
        candidates.append(directory / f"{variant.removeprefix('cactus_')}.json")
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError(variant)


def _worktree_dirty() -> bool:
    result = subprocess.run(["git", "status", "--porcelain"], cwd=ROOT, capture_output=True, text=True, check=False)
    return bool(result.stdout.strip())


def prepare(
    plan_path: Path = DEFAULT_PLAN,
    observation_path: Path = DEFAULT_OBSERVATION,
    contract_path: Path = DEFAULT_CONTRACT,
    model_path: Path = DEFAULT_MODEL,
    variant_dir: Path = DEFAULT_VARIANTS,
    output: Path = DEFAULT_OUTPUT,
) -> dict[str, Any]:
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes.decode("utf-8"))
    if not isinstance(plan, dict):
        raise ValueError("Pilot plan must be an object")
    contract = _read(contract_path)
    model = _read(model_path)
    execution = contract.get("execution") if isinstance(contract.get("execution"), dict) else {}
    contract_model = contract.get("model") if isinstance(contract.get("model"), dict) else {}
    images = plan.get("evaluator_images") if isinstance(plan.get("evaluator_images"), list) else []
    observation = _read(observation_path) if observation_path.is_file() else {}
    observed_images = observation.get("images") if isinstance(observation.get("images"), list) else []
    observed_by_ref = {str(item.get("image_ref")): item for item in observed_images if isinstance(item, dict)}

    variants: list[dict[str, Any]] = []
    missing_variants: list[str] = []
    for variant in PRIMARY + ABLATIONS:
        try:
            path = _variant_path(variant_dir, variant).resolve()
        except FileNotFoundError:
            missing_variants.append(variant)
            continue
        config = _read(path)
        variants.append(
            {
                "id": variant,
                "config": path.relative_to(ROOT).as_posix(),
                "config_sha256": _sha256(path),
                "context": config.get("context", {}),
                "role": "primary" if variant in PRIMARY else "ablation",
            }
        )

    task_count = int(plan.get("task_count", 0) or 0)
    image_records: list[dict[str, Any]] = []
    for item in images:
        if not isinstance(item, dict):
            continue
        image_ref = str(item.get("image", ""))
        observed = observed_by_ref.get(image_ref, {})
        digest = observed.get("candidate_digest")
        image_records.append(
            {
                "image_ref": image_ref,
                "digest": digest if isinstance(digest, str) and _IMAGE_DIGEST.fullmatch(digest) else None,
                "status": "OBSERVED" if isinstance(digest, str) and _IMAGE_DIGEST.fullmatch(digest) else "PENDING_OBSERVATION",
            }
        )

    gate_reasons: list[str] = []
    if task_count != 50:
        gate_reasons.append(f"Pilot matrix requires exactly 50 tasks, found {task_count}")
    if missing_variants:
        gate_reasons.append("missing variant configs: " + ", ".join(missing_variants))
    if len(image_records) != 50:
        gate_reasons.append(f"Pilot matrix requires 50 evaluator images, found {len(image_records)}")
    observed_count = sum(item["digest"] is not None for item in image_records)
    if observed_count != len(image_records):
        gate_reasons.append(f"complete evaluator image digests observed for {observed_count}/{len(image_records)} images")
    if int(execution.get("task_count", 0) or 0) != 50:
        gate_reasons.append("existing source contract is the 3-task Pilot contract; a reviewed 50-task contract is required")
    if not observation.get("approval_marker_created", False):
        gate_reasons.append("50-task contract and session authorization are not approved")
    if _worktree_dirty():
        gate_reasons.append("formal execution requires a clean worktree")

    payload = {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "execution_mode": "planning_only",
        "execution_performed": False,
        "model_calls": 0,
        "experiment_id": "EXP-CACTUS-PILOT50-CANDIDATE",
        "source_plan": plan_path.as_posix(),
        "source_plan_sha256": hashlib.sha256(plan_bytes).hexdigest(),
        "task_count": task_count,
        "task_ids": plan.get("task_ids", []),
        "task_manifest": {
            "path": plan.get("selected_manifest"),
            "sha256": plan.get("selected_manifest_sha256"),
        },
        "primary_variants": list(PRIMARY),
        "ablation_variants": list(ABLATIONS),
        "repetitions_per_task": 3,
        "budget_sweep": [0.25, 0.50, 0.75, 1.0],
        "shared_factors": {
            "model_id": contract_model.get("model_id", model.get("model_id")),
            "model_version": contract_model.get("model_version", model.get("model_version")),
            "evaluator": (contract.get("agent") or {}).get("evaluation_wrapper") if isinstance(contract.get("agent"), dict) else None,
            "timeout_sec": execution.get("task_timeout_sec"),
            "agent_turn_budget_tokens": execution.get("agent_turn_budget_tokens"),
            "concurrency": execution.get("concurrency"),
            "billing_key_alias": contract_model.get("billing_key_alias"),
        },
        "variants": variants,
        "evaluator_images": image_records,
        "image_observation": {
            "path": observation_path.as_posix(),
            "sha256": _sha256(observation_path) if observation_path.is_file() else None,
            "observed_count": observed_count,
        },
        "contract": {
            "source_path": contract_path.as_posix(),
            "source_sha256": _sha256(contract_path),
            "source_task_count": execution.get("task_count"),
            "candidate_status": "not_generated",
        },
        "gate": {"status": "READY" if not gate_reasons else "BLOCKED", "reasons": gate_reasons},
        "results_written": False,
        "status": "planning_only",
        "next_action": "Complete image observation, create and review a 50-task contract, then session-confirm it before formal preflight.",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return payload


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--observation", type=Path, default=DEFAULT_OBSERVATION)
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--model-config", type=Path, default=DEFAULT_MODEL)
    parser.add_argument("--variant-dir", type=Path, default=DEFAULT_VARIANTS)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    result = prepare(args.plan, args.observation, args.contract, args.model_config, args.variant_dir, args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["gate"]["status"] == "READY" else 2


if __name__ == "__main__":
    raise SystemExit(main())
