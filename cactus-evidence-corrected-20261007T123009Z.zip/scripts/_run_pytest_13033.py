"""Run pytest on the patched astropy to see why 13033 doesn't resolve."""
from pathlib import Path
import tempfile
import subprocess
import sys

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest = list(load_manifest(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"))
task = next(t for t in manifest if t.task_id == "astropy__astropy-13033")
ws = Path(tempfile.mkdtemp(prefix="cactus-pytest-"))
repo = checkout_base_commit(task, cache_root=Path(r"E:\cactus-data\repo-cache"), workspace_root=ws, allow_network_fetch=True)
print(f"repo: {repo}")

# Apply the model's patch using EXACT text from prediction.jsonl
import json
pred = json.loads((ROOT / "experiments" / "runs" / "RUN-20260926T144756Z-F3A607BD" / "raw" / "prediction.jsonl").read_text(encoding="utf-8"))
patch_text = pred["model_patch"]
print(f"Patch length: {len(patch_text)}")
print(f"Patch:\n{patch_text}")

# Write to file and apply
patch_file = ws / "model.patch"
patch_file.write_bytes(patch_text.encode("utf-8"))

result = subprocess.run(
    ["git", "-C", str(repo), "apply", "--whitespace=nowarn"],
    input=patch_text, capture_output=True, text=True,
)
print(f"\ngit apply: rc={result.returncode} stderr={result.stderr.strip()}")

# Apply the test_patch (gold's test_patch adds the new test case)
test_patch_file = ws / "test.patch"
test_patch_file.write_text(
    "diff --git a/astropy/timeseries/tests/test_sampled.py b/astropy/timeseries/tests/test_sampled.py\n"
    "--- a/astropy/timeseries/tests/test_sampled.py\n"
    "+++ b/astropy/timeseries/tests/test_sampled.py\n"
    "@@ -395,6 +395,14 @@ def test_required_columns():\n"
    "     assert exc.value.args[0] == (\"TimeSeries object is invalid - expected \"\n"
    "                                  \"'time' as the first column but found 'banana'\")\n"
    " \n"
    "+    # https://github.com/astropy/astropy/issues/13009\n"
    "+    ts_2cols_required = ts.copy()\n"
    "+    ts_2cols_required._required_columns = ['time', 'a']\n"
    "+    with pytest.raises(ValueError) as exc:\n"
    "+        ts_2cols_required.remove_column('a')\n"
    "+    assert exc.value.args[0] == (\"TimeSeries object is invalid - expected \"\n"
    "+                                 \"['time', 'a'] as the first columns but found ['time', 'b']\")\n"
    "+\n"
    " \n"
    " @pytest.mark.parametrize('cls', [BoxLeastSquares, LombScargle])\n"
    " def test_periodogram(cls):\n",
    encoding="utf-8",
)
result = subprocess.run(
    ["git", "-C", str(repo), "apply", "--whitespace=nowarn", str(test_patch_file)],
    capture_output=True, text=True,
)
print(f"test_patch apply: rc={result.returncode} stderr={result.stderr.strip()}")

# Now run the test
print("\n=== Running pytest test_required_columns ===")
result = subprocess.run(
    [str(ROOT / ".venv" / "Scripts" / "python.exe"), "-c",
     "import subprocess; r = subprocess.run(['pytest', "
     "'astropy/timeseries/tests/test_sampled.py::test_required_columns', "
     "'-xvs', '--tb=short', '--no-header'], "
     f"cwd=r'{str(repo).replace(chr(92), chr(92)+chr(92))}', capture_output=True, text=True, timeout=120); "
     "print('STDOUT:'); print(r.stdout); print('STDERR:'); print(r.stderr)"
    ],
    capture_output=True, text=True, timeout=180,
    cwd=str(repo),
    env={**__import__('os').environ, "PYTHONPATH": "."},
)
print("--- stdout ---")
print(result.stdout[:6000])
print("--- stderr ---")
print(result.stderr[:3000])