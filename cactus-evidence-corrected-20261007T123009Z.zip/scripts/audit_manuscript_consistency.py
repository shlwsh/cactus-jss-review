#!/usr/bin/env python3
"""Audit v1.21 manuscript claims against canonical repository artifacts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

from analyze_traces import parse_trace
from generate_repository_counts import generate as generate_repository_counts
from generate_task_status_crosstab import build as build_crosstab
from lint_figure_table_labels import scan as scan_captions
from render_variant_registry import load_registry, validate_registry
from audit_run_accounting import audit as audit_run_scope
from generate_evidence_catalog import verify as verify_evidence_catalog


ROOT = Path(__file__).resolve().parents[1]
OUTCOMES = ROOT / "paper" / "data" / "final_task_outcomes.csv"
TRACES = ROOT / "paper" / "data" / "trace_token_metrics.csv"
MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
RUNS = ROOT / "experiments" / "runs"
MANUSCRIPT = ROOT / "paper" / "main.tex"
REGISTRY = ROOT / "paper" / "variant_registry.yaml"
CONFIG_DIR = ROOT / "config" / "variants"
REPORT = ROOT / "docs" / "audit" / "manuscript_consistency.json"
GENERATED = ROOT / "paper" / "generated"


def read_outcomes(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows or len({row.get("task", "") for row in rows}) != len(rows):
        raise ValueError("outcome CSV must contain unique task IDs")
    return rows


def count_outcomes(rows: list[dict[str, str]]) -> dict[str, int | str]:
    resolved = sum(row.get("resolved") == "1" for row in rows)
    unresolved = sum(row.get("unresolved") == "1" for row in rows)
    unadjudicated = sum(row.get("error") == "1" for row in rows)
    by_repo: dict[str, int] = {}
    for row in rows:
        if row.get("error") == "1":
            repo = row["task"].split("__", 1)[0]
            by_repo[repo] = by_repo.get(repo, 0) + 1
    top_repo, top_count = max(by_repo.items(), key=lambda item: item[1])
    return {
        "total": len(rows),
        "total_tasks": len(rows),
        "evidence_task_records": len(rows),
        "resolved": resolved,
        "unresolved": unresolved,
        "unadjudicated": unadjudicated,
        "evaluator_valid": resolved + unresolved,
        "completed_task_records": sum(row.get("status") == "completed" for row in rows),
        "failed_task_records": sum(row.get("status") == "failed" for row in rows),
        "top_unadjudicated_repo": top_repo,
        "top_unadjudicated_count": top_count,
        "top_unadjudicated_repository": top_repo,
        "top_unadjudicated_repository_count": top_count,
        "full_denominator_resolved_rate": round(100 * resolved / len(rows), 1),
        "evaluator_valid_resolved_rate": round(100 * resolved / (resolved + unresolved), 2),
        "top_unadjudicated_repository_share": round(100 * top_count / unadjudicated, 1) if unadjudicated else 0.0,
    }


def trace_summary(path: Path) -> dict[str, object]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    task_ids = [row.get("task_id", "") for row in rows]
    selected_files: dict[str, int] = {}
    for row in rows:
        value = row.get("selected_files", "")
        selected_files[value] = selected_files.get(value, 0) + 1
    return {
        "row_count": len(rows),
        "unique_task_count": len(set(task_ids)),
        "selected_files_counts": dict(sorted(selected_files.items())),
    }


def trace_provenance_summary(path: Path, *, project_root: Path = ROOT) -> dict[str, object]:
    """Verify trace CSV rows against the exact hashed RUN traces in its sidecar."""
    summary = trace_summary(path)
    sidecar_path = path.with_name(path.stem + "_provenance.json")
    failures: list[str] = []
    try:
        sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {
            "status": "fail",
            "sidecar_path": sidecar_path.as_posix(),
            "source_input_count": 0,
            "source_hashes_verified": 0,
            "failures": [f"cannot read trace provenance sidecar: {exc}"],
        }
    if not isinstance(sidecar, dict):
        return {
            "status": "fail",
            "sidecar_path": sidecar_path.as_posix(),
            "source_input_count": 0,
            "source_hashes_verified": 0,
            "failures": ["trace provenance sidecar must contain a JSON object"],
        }

    artifact_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    artifact_hash_matches = sidecar.get("artifact_sha256") == artifact_hash
    if not artifact_hash_matches:
        failures.append("trace CSV SHA-256 does not match its provenance sidecar")

    transform = sidecar.get("transform", {})
    parameters = transform.get("parameters", {}) if isinstance(transform, dict) else {}
    declared_task_count = parameters.get("task_count") if isinstance(parameters, dict) else None
    row_count = int(summary["row_count"])
    unique_task_count = int(summary["unique_task_count"])
    if declared_task_count != row_count:
        failures.append(
            f"trace provenance task_count={declared_task_count!r} does not match CSV row_count={row_count}"
        )

    inputs = sidecar.get("inputs")
    if not isinstance(inputs, list):
        inputs = []
        failures.append("trace provenance inputs must be an array")
    if len(inputs) < unique_task_count:
        failures.append(
            f"trace provenance has {len(inputs)} source input(s) for {unique_task_count} unique task row(s)"
        )

    root = project_root.resolve()
    verified = 0
    seen_sources: set[Path] = set()
    source_rows: dict[str, dict[str, object]] = {}
    duplicate_source_tasks = 0
    for index, item in enumerate(inputs):
        if not isinstance(item, dict) or not isinstance(item.get("source"), str):
            failures.append(f"trace provenance input {index} has no source path")
            continue
        source = Path(item["source"])
        source_path = (source if source.is_absolute() else root / source).resolve()
        if not source_path.is_relative_to(root):
            failures.append(f"trace provenance input {index} escapes the project root")
            continue
        if source_path in seen_sources:
            failures.append(f"trace provenance input {index} duplicates an earlier source path")
            continue
        seen_sources.add(source_path)
        expected_hash = item.get("sha256")
        if not isinstance(expected_hash, str) or re.fullmatch(r"[0-9a-f]{64}", expected_hash) is None:
            failures.append(f"trace provenance input {index} has no full SHA-256")
            continue
        try:
            observed_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
        except OSError:
            failures.append(f"trace provenance input {index} is unavailable")
            continue
        if observed_hash != expected_hash:
            failures.append(f"trace provenance input {index} SHA-256 mismatch")
            continue
        verified += 1
        try:
            metrics = parse_trace(source_path)
        except (OSError, UnicodeError, ValueError):
            metrics = None
        task_id = str(metrics.get("task_id", "")) if isinstance(metrics, dict) else ""
        if not task_id:
            failures.append(f"trace provenance input {index} does not yield a task ID")
            continue
        if task_id in source_rows:
            duplicate_source_tasks += 1
            failures.append("trace provenance maps multiple source traces to the same task ID")
            continue
        source_rows[task_id] = metrics

    with path.open(encoding="utf-8-sig", newline="") as handle:
        csv_rows = list(csv.DictReader(handle))
    csv_task_counts = Counter(row.get("task_id", "") for row in csv_rows)
    source_task_ids = set(source_rows)
    csv_task_ids = {task_id for task_id in csv_task_counts if task_id}
    missing_source_ids = csv_task_ids - source_task_ids
    extra_source_ids = source_task_ids - csv_task_ids
    if missing_source_ids or extra_source_ids or "" in csv_task_counts:
        failures.append(
            "trace source task IDs do not exactly match CSV task IDs "
            f"(missing_sources={len(missing_source_ids)}, extra_sources={len(extra_source_ids)}, "
            f"empty_csv_ids={csv_task_counts.get('', 0)})"
        )
    duplicate_csv_ids = sum(count - 1 for count in csv_task_counts.values() if count > 1)
    if duplicate_csv_ids:
        failures.append(f"trace CSV contains {duplicate_csv_ids} duplicate task row(s)")

    metric_fields = ("input_tokens", "output_tokens", "selected_files", "context_budget")
    metric_mismatch_count = 0
    for row in csv_rows:
        task_id = row.get("task_id", "")
        source_metrics = source_rows.get(task_id)
        if source_metrics is None:
            continue
        for field in metric_fields:
            try:
                csv_value = int(row.get(field, ""))
                source_value = int(source_metrics[field])
            except (KeyError, TypeError, ValueError):
                metric_mismatch_count += 1
                continue
            if csv_value != source_value:
                metric_mismatch_count += 1
    if metric_mismatch_count:
        failures.append(
            f"trace CSV has {metric_mismatch_count} metric value(s) that do not match their source traces"
        )

    return {
        "status": "pass" if not failures else "fail",
        "validation_scope": "CSV hash and row count, hashed source traces, exact task-ID coverage, and per-task token/context metric reconciliation",
        "sidecar_path": sidecar_path.as_posix(),
        "artifact_hash_matches": artifact_hash_matches,
        "row_count": row_count,
        "unique_task_count": unique_task_count,
        "declared_task_count": declared_task_count,
        "source_input_count": len(inputs),
        "source_hashes_verified": verified,
        "source_task_count": len(source_rows),
        "duplicate_source_task_count": duplicate_source_tasks,
        "matched_task_count": len(csv_task_ids & source_task_ids),
        "metric_mismatch_count": metric_mismatch_count,
        "failures": failures,
    }


def write_macros(counts: dict[str, int | str], repo_counts: dict[str, object]) -> Path:
    total = int(counts["total"])
    resolved = int(counts["resolved"])
    valid = int(counts["evaluator_valid"])
    unadjudicated = int(counts["unadjudicated"])
    top_count = int(counts["top_unadjudicated_count"])
    lines = [
        "% Generated by scripts/audit_manuscript_consistency.py; do not hand-edit.",
        f"\\newcommand{{\\CactusTaskTotal}}{{{total}}}",
        f"\\newcommand{{\\CactusResolvedCount}}{{{resolved}}}",
        f"\\newcommand{{\\CactusUnresolvedCount}}{{{counts['unresolved']}}}",
        f"\\newcommand{{\\CactusUnadjudicatedCount}}{{{unadjudicated}}}",
        f"\\newcommand{{\\CactusEvaluatorValidCount}}{{{valid}}}",
        f"\\newcommand{{\\CactusEvaluatorValidRate}}{{{100 * valid / total:.1f}\\%}}",
        f"\\newcommand{{\\CactusResolvedFullRate}}{{{100 * resolved / total:.1f}\\%}}",
        f"\\newcommand{{\\CactusResolvedValidRate}}{{{100 * resolved / valid:.1f}\\%}}",
        f"\\newcommand{{\\CactusLargestRepository}}{{{repo_counts['largest_repository']}}}",
        f"\\newcommand{{\\CactusLargestRepositoryCount}}{{{repo_counts['largest_repository_count']}}}",
        f"\\newcommand{{\\CactusQuarantineRepository}}{{{counts['top_unadjudicated_repo']}}}",
        f"\\newcommand{{\\CactusQuarantineRepositoryCount}}{{{top_count}}}",
        f"\\newcommand{{\\CactusQuarantineRepositoryShare}}{{{100 * top_count / unadjudicated:.1f}\\%}}",
    ]
    GENERATED.mkdir(parents=True, exist_ok=True)
    path = GENERATED / "campaign_macros.tex"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    from artifact_provenance import write
    write(path, [OUTCOMES, MANIFEST], Path(__file__), transform={"scope": "frozen_task_snapshot"})
    return path


def audit(args: argparse.Namespace) -> dict[str, object]:
    if (ROOT / "paper/publication_sources.json").is_file():
        # The old fixed expected totals cannot certify historical outcomes.
        # Audit the actual active source graph and admission instead.
        import sys
        sys.path.insert(0, str(ROOT))
        sys.path.insert(0, str(ROOT / "src"))
        from scripts.generate_publication_values import verify, verify_sources, scan
        from cactus.tools.datactl import verify_sidecar
        failures = []
        report = {"schema_version": "2.0", "scope": "current admitted publication; historical totals withdrawn"}
        try:
            report["values"] = verify()
            report["sources"] = verify_sources()
            report["latex"] = scan()
            report["chinese_latex"] = scan(entry="paper-cn/main.tex")
            failures.extend(report["latex"]["errors"] + report["chinese_latex"]["errors"])
            seen = set()
            for path in [ROOT / "paper/build/main.pdf", ROOT / "paper-cn/build/main.pdf"]:
                failures.extend(verify_sidecar(ROOT, path, seen=seen))
        except (OSError, ValueError, KeyError) as exc:
            failures.append(str(exc))
        report["failures"] = failures
        report["status"] = "fail" if failures else "pass"
        target = args.report
        if target == REPORT:
            target = ROOT / "paper/build/manuscript_consistency_current.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
        return report
    rows = read_outcomes(args.outcomes)
    counts = count_outcomes(rows)
    repo_counts = generate_repository_counts(args.manifest, GENERATED)
    registry = load_registry(args.registry)
    registry_errors = validate_registry(registry, args.config_dir)
    manuscript = args.manuscript.read_text(encoding="utf-8")
    stale_patterns = {
        "old_full_denominator_rate": r"(?<![0-9])2\\?\.8%",
        "old_conditional_rate": r"(?<![0-9])10\\?\.2%",
        "stale_algorithm_lens_size": r"137[- ]task|n=137|137 evaluator-valid",
        "stale_max_stratum": r"max stratum n=75 for .?sympy|stratum.*75.*sympy",
        "legacy_variant_taxonomy": r"5 paradigms|5 baselines / 4 ablations|Standard RAG|Static Utility",
        "stale_phase_b": r"pending Phase B|after Phase B RUN|Phase B will provide",
        "unscoped_django_concentration": r"(?:django.*71\\?\.4%|71\\?\.4%.*django)",
        "ambiguous_phase_c": r"Phase(?:~| )C(?![01])",
        "private_gateway_endpoint": r"172\.19\.50\.70|localhost:[0-9]{2,5}/v1",
    }
    stale_hits = {name: re.findall(pattern, manuscript, flags=re.IGNORECASE) for name, pattern in stale_patterns.items()}
    stale_hits = {name: hits for name, hits in stale_hits.items() if hits}
    caption_report = scan_captions([args.manuscript])
    crosstab = build_crosstab(args.outcomes)
    traces = trace_summary(args.traces)
    trace_provenance = trace_provenance_summary(args.traces)
    run_scope = audit_run_scope(args.runs, args.outcomes)
    run_accounting = {
        key: value
        for key, value in run_scope.items()
        if key not in {"records", "tasks_with_multiple_completed_runs", "tasks_with_policy_retries", "tasks_with_nonpolicy_retries"}
    }
    run_accounting["distinct_run_tasks"] = run_scope["formal_distinct_tasks"]
    run_accounting["completed_run_bundle_count"] = run_scope["formal_completed_runs"]
    run_accounting["failed_run_bundle_count"] = run_scope["formal_failed_runs"]
    failures: list[str] = []
    expected = {"total": 500, "resolved": 11, "unresolved": 468, "unadjudicated": 21, "evaluator_valid": 479}
    try:
        evidence_catalog = verify_evidence_catalog()
    except (OSError, ValueError, KeyError) as exc:
        evidence_catalog = {"status": "fail", "error": str(exc)}
        failures.append("unified paper evidence: " + str(exc))
    for key, value in expected.items():
        if counts[key] != value:
            failures.append(f"{key}={counts[key]} != expected {value}")
    if int(counts["resolved"]) + int(counts["unresolved"]) + int(counts["unadjudicated"]) != int(counts["total"]):
        failures.append("task outcome categories do not conserve the task total")
    if repo_counts["largest_repository"] != "django" or repo_counts["largest_repository_count"] != 231:
        failures.append("repository stratum does not confirm django=231 as largest")
    if int(repo_counts["counts"].get("sympy", 0)) != 75:
        failures.append("repository stratum does not confirm sympy=75")
    if stale_hits:
        failures.append("stale manuscript patterns: " + ", ".join(sorted(stale_hits)))
    if caption_report["failures"]:
        failures.append("caption evidence-state labels are incomplete")
    if registry_errors:
        failures.extend("registry: " + error for error in registry_errors)
    if trace_provenance["failures"]:
        failures.extend("trace provenance: " + error for error in trace_provenance["failures"])
    report = {
        "schema_version": "1.0",
        "counts": counts,
        "evidence_catalog": evidence_catalog,
        "trace": traces,
        "trace_provenance": trace_provenance,
        "run_accounting": run_accounting,
        "repository_counts": repo_counts,
        "registry": {"version": registry.get("registry_version"), "active_ids": [item["id"] for item in registry["entries"] if item.get("enabled") is True]},
        "crosstab": crosstab,
        "stale_hits": stale_hits,
        "caption_report": caption_report,
        "failures": failures,
        "status": "fail" if failures else "pass",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write_macros(counts, repo_counts)
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outcomes", type=Path, default=OUTCOMES)
    parser.add_argument("--traces", type=Path, default=TRACES)
    parser.add_argument("--runs", type=Path, default=RUNS)
    parser.add_argument("--manifest", type=Path, default=MANIFEST)
    parser.add_argument("--manuscript", type=Path, default=MANUSCRIPT)
    parser.add_argument("--registry", type=Path, default=REGISTRY)
    parser.add_argument("--config-dir", type=Path, default=CONFIG_DIR)
    parser.add_argument("--report", type=Path, default=REPORT)
    parser.add_argument("--strict", action="store_true")
    return parser


if __name__ == "__main__":
    args = build_parser().parse_args()
    try:
        result = audit(args)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"AUDIT FAILED: {exc}", file=sys.stderr)
        raise SystemExit(2)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(2 if args.strict and result["failures"] else 0)
