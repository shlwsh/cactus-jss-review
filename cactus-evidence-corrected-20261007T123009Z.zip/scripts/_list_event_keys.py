import json, sys
fn = sys.argv[1]
with open(fn, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]
# 列各事件的 key 名
for i, e in enumerate(events):
    p = e.get('payload', {})
    print(f'seq={e.get("seq"):3d} type={e.get("type"):40s} keys={list(p.keys())[:6]}')
