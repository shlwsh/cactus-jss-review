"""Debug helper: trace why _misleading_exception_template_patch returns None."""
from __future__ import annotations

import ast
import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT))

spec = importlib.util.spec_from_file_location("cactus_swebench_predict", str(ROOT / "scripts" / "cactus_swebench_predict.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

from cactus.adapters.benchmark import load_manifest  # type: ignore

manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
task = next(t for t in load_manifest(manifest) if t.task_id == "astropy__astropy-13033")
print("archetype =", mod._classify_issue_type(task.issue_text))

ws = Path(tempfile.mkdtemp(prefix="dbg_"))
checkout = ws / "repository"
mirror = ROOT / "experiments" / "repo_cache" / "astropy__astropy.git"
print(f"mirror = {mirror}")
subprocess.run(["git", "clone", "--no-checkout", str(mirror), str(checkout)], cwd=str(ws), check=True, capture_output=True)
subprocess.run(["git", "-C", str(checkout), "checkout", "--detach", task.base_commit], cwd=str(ws), check=True, capture_output=True)
print("HEAD =", subprocess.run(["git", "-C", str(checkout), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip())

rel = "astropy/timeseries/core.py"
src = (checkout / rel).read_text(encoding="utf-8")

print("\n[A] AST scan for `_check_*` methods:")
tree = ast.parse(src)
for cls in ast.walk(tree):
    if not isinstance(cls, ast.ClassDef):
        continue
    for child in cls.body:
        if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        low = child.name.lower()
        if not any(tok in low for tok in ("_check_", "_validate_", "_verify_", "_assert_", "_require_")):
            continue
        print(f"  {cls.name}.{child.name} at line {child.lineno}")
        for sub in ast.walk(child):
            if not isinstance(sub, ast.Raise) or sub.exc is None:
                continue
            print(f"    raise at line {sub.lineno}")
            if isinstance(sub.exc, ast.Call):
                if sub.exc.args:
                    first_arg = sub.exc.args[0]
                    print(f"      first arg type: {type(first_arg).__name__}")
                    if isinstance(first_arg, ast.Call) and isinstance(first_arg.func, ast.Attribute):
                        print(f"      first arg is .format() call with attr={first_arg.func.attr!r}")
                        for ai, a in enumerate(first_arg.args):
                            print(f"        arg[{ai}] = {ast.dump(a)[:120]}")
                            if isinstance(a, ast.Subscript) and isinstance(a.slice, ast.Constant):
                                print(f"          -> subscript index {a.slice.value}")
                else:
                    print(f"      no args in exc call")
                print(f"      exc.func type: {type(sub.exc.func).__name__}")
                if isinstance(sub.exc.func, ast.Attribute):
                    print(f"      exc.func.attr = {sub.exc.func.attr!r}")
            else:
                print(f"    raise.exc type: {type(sub.exc).__name__}")

print("\n[B] _find_misleading_raise_nodes result:")
candidates = mod._find_misleading_raise_nodes(src, rel)
print(f"candidates = {len(candidates)}")
for c in candidates:
    print(f"  method={c[0].name} raise_line={c[1].lineno} format_call_line={c[2].lineno}")

print("\n[C] calling _misleading_exception_template_patch ...")
import contextlib, io
buf = io.StringIO()
with contextlib.redirect_stderr(buf):
    patch = mod._misleading_exception_template_patch(task, checkout)
print(f"   returned patch: {bool(patch)}")
print(f"   stderr:\n{buf.getvalue().strip()}")
