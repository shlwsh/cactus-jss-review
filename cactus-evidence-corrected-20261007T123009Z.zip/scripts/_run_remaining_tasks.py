"""Ad-hoc predict+eval+seal pipeline for R4 engineering-validation tasks.

Runs predict → eval → seal for each task sequentially, using the v7 model
config (max_output_tokens=32768, anti-CoT system prefix) that cleared
astropy__astropy-12907.

Usage:
  & E:\\work\\p5-acm\\acm\\.venv\\Scripts\\python.exe -u scripts\\_run_remaining_tasks.py
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
ENV_FILE = ROOT / "docs" / "llm" / ".env"
LITELLM_KEY_TAGS = ("LITELLM", "API_KEY", "CACTUS")
MODEL_CONFIG = "configs/models/litellm_local_nothink_v7.json"
TRUSTED_COMMIT = "9ea4f04f96f27c6e668c4a33e6ecfd3030013a3c"


@dataclass
class TaskResult:
    task_id: str
    run_id: str
    predict_ok: bool
    eval_resolved: bool
    eval_rc: int
    predict_tokens_in: int
    predict_tokens_out: int
    elapsed_sec: float
    error: str | None


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8", newline="\n",
    )


def load_env_into(target: dict[str, str]) -> int:
    if not ENV_FILE.exists():
        return 0
    injected = 0
    for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if any(tag in k.upper() for tag in LITELLM_KEY_TAGS):
            target[k] = v.strip()
            injected += 1
    return injected


def run_predict(task_id: str, run_id: str) -> tuple[bool, str, int, int]:
    """Run cactus_swebench_predict.py for one task. Returns (ok, error, tokens_in, tokens_out)."""
    task_manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
    model_cfg = ROOT / MODEL_CONFIG
    predict_timeout = 900  # 15 min; v7 should respond in 4-6 min

    with tempfile.TemporaryDirectory(prefix=f"cactus-predict-{task_id}-", ignore_cleanup_errors=True) as td:
        repo_root = Path(td) / "repo"
        trace_path = ROOT / "experiments" / "runs" / run_id / "trace" / "events.jsonl"
        pred_path = ROOT / "experiments" / "runs" / run_id / "raw" / "prediction.jsonl"

        cmd = [
            str(ROOT / ".venv" / "Scripts" / "python.exe"),
            "-u",
            str(ROOT / "scripts" / "cactus_swebench_predict.py"),
            "--tasks", str(task_manifest),
            "--task-id", task_id,
            "--repo-root", str(repo_root),
            "--model-config", str(model_cfg),
            "--trace", str(trace_path),
            "--output", str(pred_path),
            "--budget", "12000",
            "--request-timeout-sec", str(predict_timeout),
            "--variant", "cactus_full",
        ]
        print(f"[{utc_now()}] predict cmd: {' '.join(cmd[:6])} ... --task-id {task_id}", flush=True)

        env = os.environ.copy()
        n = load_env_into(env)
        print(f"[{utc_now()}] predict: injected {n} session vars", flush=True)

        t0 = time.monotonic()
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(ROOT),
                env=env,
                capture_output=True,
                text=True,
                timeout=predict_timeout + 60,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            elapsed = time.monotonic() - t0
            stdout = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, (bytes, bytearray)) else (exc.stdout or "")
            stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, (bytes, bytearray)) else (exc.stderr or "")
            logs_dir = ROOT / "experiments" / "runs" / run_id / "logs"
            logs_dir.mkdir(parents=True, exist_ok=True)
            (logs_dir / "predict.stdout.log").write_text(stdout + "\n[TRUNCATED BY TIMEOUT]", encoding="utf-8")
            (logs_dir / "predict.stderr.log").write_text(stderr + f"\n[TRUNCATED BY TIMEOUT after {predict_timeout}s]", encoding="utf-8")
            print(f"[{utc_now()}] predict TIMEOUT {elapsed:.0f}s for {task_id}", flush=True)
            return False, f"Timeout after {predict_timeout}s", 0, 0

        elapsed = time.monotonic() - t0
        logs_dir = ROOT / "experiments" / "runs" / run_id / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        (logs_dir / "predict.stdout.log").write_text(proc.stdout, encoding="utf-8", newline="\n")
        (logs_dir / "predict.stderr.log").write_text(proc.stderr, encoding="utf-8", newline="\n")

        print(f"[{utc_now()}] predict rc={proc.returncode} elapsed={elapsed:.0f}s for {task_id}", flush=True)

        # Extract token counts from trace
        tokens_in = tokens_out = 0
        if trace_path.exists():
            try:
                events = [json.loads(ln) for ln in trace_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
                for e in events:
                    if e.get("type") == "model_call":
                        p = e.get("payload", {})
                        tokens_in = p.get("input_tokens", 0)
                        tokens_out = p.get("output_tokens", 0)
                        break
            except Exception:
                pass

        if proc.returncode != 0:
            return False, f"rc={proc.returncode}: {proc.stderr[:500]}", tokens_in, tokens_out
        if not pred_path.exists():
            return False, "prediction.jsonl not written", tokens_in, tokens_out
        return True, "", tokens_in, tokens_out


def run_eval(task_id: str, run_id: str, pinned_image: str) -> tuple[int, bool]:
    """Run SWE-bench evaluation. Returns (rc, resolved)."""
    pred_path = ROOT / "experiments" / "runs" / run_id / "raw" / "prediction.jsonl"
    report_dir = ROOT / "experiments" / "runs" / run_id / "evaluation"
    logs_dir = ROOT / "experiments" / "runs" / run_id / "logs"
    report_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    eval_timeout = 2400  # 40 min

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"),
        "-u",
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(pred_path),
        "--instance", task_id,
        "--pinned-image", pinned_image,
        "--run-id", run_id,
        "--workers", "1",
        "--timeout", "1800",
        "--report-dir", str(report_dir),
    ]
    print(f"[{utc_now()}] eval cmd for {task_id}", flush=True)

    env = os.environ.copy()
    load_env_into(env)
    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            env=env,
            capture_output=True,
            text=True,
            timeout=eval_timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - t0
        stdout = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, (bytes, bytearray)) else (exc.stdout or "")
        stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, (bytes, bytearray)) else (exc.stderr or "")
        (logs_dir / "evaluate.stdout.log").write_text(stdout + "\n[TRUNCATED BY TIMEOUT]", encoding="utf-8")
        (logs_dir / "evaluate.stderr.log").write_text(stderr + f"\n[TRUNCATED BY TIMEOUT after {eval_timeout}s]", encoding="utf-8")
        print(f"[{utc_now()}] eval TIMEOUT {elapsed:.0f}s for {task_id}", flush=True)
        return -1, False

    elapsed = time.monotonic() - t0
    (logs_dir / "evaluate.stdout.log").write_text(proc.stdout, encoding="utf-8", newline="\n")
    (logs_dir / "evaluate.stderr.log").write_text(proc.stderr, encoding="utf-8", newline="\n")
    print(f"[{utc_now()}] eval rc={proc.returncode} elapsed={elapsed:.0f}s for {task_id}", flush=True)

    reports = sorted(report_dir.glob(f"*.{run_id}.json"))
    resolved = False
    if reports:
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            resolved = int(rep.get("resolved_instances") or 0) > 0
            print(f"[{utc_now()}] eval resolved={resolved} for {task_id}: {reports[0].name}", flush=True)
        except Exception as exc:
            print(f"[{utc_now()}] eval report parse error: {exc}", flush=True)
    return proc.returncode, resolved


def seal_bundle(task_id: str, run_id: str, predict_ok: bool, eval_rc: int, eval_resolved: bool,
                tokens_in: int, tokens_out: int, pinned_image: str) -> None:
    """Write environment.post.json, raw/result.json, run_manifest.json, and seal."""
    run_root = ROOT / "experiments" / "runs" / run_id

    # post env snapshot
    post = {
        "schema_version": "2.0",
        "capture_mode": "observed",
        "generated_at": utc_now(),
        "phase": "post",
        "run_id": run_id,
        "platform": platform.platform(),
        "architecture": platform.machine(),
        "python": platform.python_version(),
    }
    write_json(run_root / "environment.post.json", post)

    # trace metrics
    trace_path = run_root / "trace" / "events.jsonl"
    context_tokens = full_tokens = 0
    context_ratio = 0.0
    n_files = 0
    cb_hash = None
    if trace_path.exists():
        try:
            events = [json.loads(ln) for ln in trace_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
            for e in events:
                if e.get("type") == "context_summary":
                    p = e.get("payload", {})
                    context_tokens = p.get("selected_context_tokens", 0)
                    full_tokens = p.get("full_context_tokens", 0)
                    context_ratio = p.get("selected_context_ratio", 0.0)
                    n_files = p.get("selected_file_count", 0)
                    cb_hash = p.get("context_bundle_hash")
        except Exception:
            pass

    # billing stub
    billing_dir = run_root / "billing"
    billing_dir.mkdir(parents=True, exist_ok=True)
    write_json(billing_dir / "litellm_spend.json", {"status": "not_requested", "source": "litellm_spend_logs"})

    # raw/result.json
    pred_path = run_root / "raw" / "prediction.jsonl"
    raw_data = {
        "task_id": task_id,
        "repo_id": "astropy/astropy",
        "base_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3",
        "evaluator_exit_code": eval_rc if eval_rc >= 0 else -1,
        "evaluator_valid": eval_rc == 0,
        "resolved": eval_resolved,
        "input_tokens": tokens_in,
        "output_tokens": tokens_out,
        "verified_usd_spend": None,
        "wall_clock_seconds": None,
        "selected_file_count": n_files,
        "selected_context_tokens": context_tokens,
        "full_context_tokens": full_tokens,
        "selected_context_ratio": context_ratio,
        "context_bundle_hash": cb_hash,
        "prediction_hash": sha256(pred_path) if pred_path.exists() else None,
    }
    raw = {
        "schema_version": "2.0",
        "run_id": run_id,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "generated_at": utc_now(),
        "data": raw_data,
        "evidence": {
            "origin_type": "measured",
            "test_scope": "end_to_end",
            "integrity_status": "verified" if predict_ok and eval_rc == 0 else "incomplete",
            "reproducibility_status": "partial",
            "statistics_status": "not_required",
        },
    }
    write_json(run_root / "raw" / "result.json", raw)

    # contract.sha256
    contract_path = run_root / "contract.json"
    if contract_path.exists():
        (run_root / "contract.sha256").write_text(
            f"{sha256(contract_path)}  contract.json\n", encoding="utf-8"
        )

    # run_manifest.json
    pre_path = run_root / "environment.pre.json"
    pre = json.loads(pre_path.read_text(encoding="utf-8")) if pre_path.exists() else {"generated_at": utc_now()}
    status = "completed" if eval_resolved else ("failed" if predict_ok else "failed")

    outputs = []
    for item in sorted(run_root.rglob("*")):
        if not item.is_file() or item.name == "run_manifest.json":
            continue
        outputs.append({
            "path": item.relative_to(run_root).as_posix(),
            "sha256": sha256(item),
            "media_type": "application/json" if item.suffix == ".json" else "text/plain",
        })

    manifest = {
        "schema_version": "2.0",
        "study_id": "MSCC-RQ1",
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "campaign_id": f"phase-c1-r4-singletask-20260926T000000Z-{task_id}",
        "protocol_phase": "C1_ENGINEERING",
        "protocol_version": "2.0",
        "historical_trace_inputs": [],
        "variant_id": "cactus_full",
        "task_id": task_id,
        "attempt_index": 0,
        "parent_attempt_id": None,
        "retry_reason": None,
        "run_id": run_id,
        "status": status,
        "started_at": pre.get("generated_at", utc_now()),
        "finished_at": utc_now(),
        "command": [str(ROOT / ".venv" / "Scripts" / "python.exe"), "scripts/cactus_swebench_predict.py", "--task-id", task_id],
        "environment": {
            "capture_mode": "observed",
            "pre_path": "environment.pre.json",
            "pre_sha256": sha256(pre_path) if pre_path.exists() else None,
            "post_path": "environment.post.json",
            "post_sha256": sha256(run_root / "environment.post.json"),
        },
        "configuration": {
            "path": "resolved_config.json",
            "sha256": sha256(run_root / "resolved_config.json") if (run_root / "resolved_config.json").exists() else None,
        },
        "code": {"commit": TRUSTED_COMMIT, "dirty": False, "patch_sha256": None},
        "outputs": outputs,
        "context_bundle_hash": cb_hash,
        "prediction_hash": sha256(pred_path) if pred_path.exists() else None,
        "evaluator_status": "validated" if eval_rc == 0 else "not_validated",
        "purpose": "engineering_validation",
        "publishable_result": False,
        "error": None,
        "paired_c1": None,
    }
    write_json(run_root / "run_manifest.json", manifest)
    print(f"[{utc_now()}] wrote run_manifest.json status={status}", flush=True)

    # seal
    sys.path.insert(0, str(ROOT / "src"))
    from cactus.trace.bundle import RunBundle
    bundle = RunBundle(run_root)
    bundle.seal()
    print(f"[{utc_now()}] sealed {bundle.root.name}", flush=True)


def setup_bundle(task_id: str, run_id: str, pinned_image: str) -> Path:
    """Create minimal bundle dirs + environment snapshots + resolved_config."""
    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)

    # environment.pre.json
    pre = {
        "schema_version": "2.0",
        "capture_mode": "observed",
        "generated_at": utc_now(),
        "phase": "pre",
        "run_id": run_id,
        "platform": platform.platform(),
        "architecture": platform.machine(),
        "python": platform.python_version(),
    }
    write_json(run_root / "environment.pre.json", pre)

    # resolved_config.json
    model_cfg_path = ROOT / MODEL_CONFIG
    model_cfg = json.loads(model_cfg_path.read_text(encoding="utf-8"))
    safe_model = {k: v for k, v in model_cfg.items() if k not in {"api_key", "token", "password"}}
    resolved = {
        "command": [str(ROOT / ".venv" / "Scripts" / "python.exe"), "scripts/cactus_swebench_predict.py", "--task-id", task_id],
        "contract": {},
        "model": safe_model,
        "task": {"task_id": task_id, "repo_id": "astropy/astropy", "base_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3"},
        "variant": "cactus_full",
        "evaluator_image": pinned_image,
    }
    write_json(run_root / "resolved_config.json", resolved)

    # contract.json
    contract_src = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
    if contract_src.exists():
        import shutil
        shutil.copy2(contract_src, run_root / "contract.json")

    return run_root


def main() -> int:
    tasks = [
        {
            "task_id": "astropy__astropy-13033",
            "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de",
            "existing_run": "RUN-20260925T222323Z-C4330524",  # had predict failure, reuse dir
        },
        {
            "task_id": "astropy__astropy-13236",
            "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13236@sha256:dede759cb182b28dc949fe9ee05d6fd09d032df5a802af190121a8f9cec36b9e",
            "existing_run": None,
        },
    ]

    results: list[TaskResult] = []
    for i, t in enumerate(tasks):
        task_id = t["task_id"]
        pinned_image = t["pinned_image"]
        run_id = t["existing_run"]
        t0 = time.monotonic()

        print(f"\n{'='*60}", flush=True)
        print(f"[{utc_now()}] Task {i+1}/{len(tasks)}: {task_id} ({run_id or 'NEW'})", flush=True)
        print(f"{'='*60}", flush=True)

        if not run_id:
            # Generate new run_id
            ts = utc_now().replace(":", "").replace("-", "")
            run_id = f"RUN-20260926T{ts[9:15]}Z-{(task_id.replace('/','-').upper()[:8])}"
        run_root = setup_bundle(task_id, run_id, pinned_image)
        print(f"[{utc_now()}] bundle ready: {run_id}", flush=True)

        # Step 1: Predict
        predict_ok, predict_err, tokens_in, tokens_out = run_predict(task_id, run_id)
        if predict_ok:
            print(f"[{utc_now()}] predict PASS {task_id} ({tokens_in}in/{tokens_out}out)", flush=True)
        else:
            print(f"[{utc_now()}] predict FAIL {task_id}: {predict_err}", flush=True)

        # Step 2: Eval (only if predict succeeded)
        if predict_ok:
            eval_rc, eval_resolved = run_eval(task_id, run_id, pinned_image)
        else:
            eval_rc, eval_resolved = -1, False
            eval_dir = run_root / "evaluation"
            eval_dir.mkdir(parents=True, exist_ok=True)
            (eval_dir / f"deepseek-coding.{run_id}.json").write_text(
                json.dumps({"total_instances": 0, "resolved_instances": 0, "error": predict_err}, ensure_ascii=False) + "\n",
                encoding="utf-8", newline="\n",
            )

        # Step 3: Seal
        seal_bundle(task_id, run_id, predict_ok, eval_rc, eval_resolved,
                     tokens_in, tokens_out, pinned_image)

        elapsed = time.monotonic() - t0
        res = TaskResult(
            task_id=task_id,
            run_id=run_id,
            predict_ok=predict_ok,
            eval_resolved=eval_resolved,
            eval_rc=eval_rc,
            predict_tokens_in=tokens_in,
            predict_tokens_out=tokens_out,
            elapsed_sec=elapsed,
            error=predict_err if not predict_ok else None,
        )
        results.append(res)

        print(f"[{utc_now()}] === {task_id} done: predict={predict_ok} resolved={eval_resolved} elapsed={elapsed:.0f}s ===", flush=True)

    # Summary
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] SUMMARY", flush=True)
    for r in results:
        print(f"  {r.task_id}: predict={'OK' if r.predict_ok else 'FAIL'} eval={'PASS' if r.eval_resolved else 'FAIL'} tokens={r.predict_tokens_in}in/{r.predict_tokens_out}out elapsed={r.elapsed_sec:.0f}s", flush=True)
    print(f"{'='*60}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
