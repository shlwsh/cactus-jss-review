"""Validate 12125 prediction against the SWE-bench test set.

The prediction modifies django/db/migrations/state.py to populate real_models
from a list comprehension. The expected fix targets django/db/migrations/writer.py
to use qualified class paths for nested classes. This script tests whether the
existing prediction passes the FAIL_TO_PASS tests.
"""
import json
from pathlib import Path

# Load the 12125 task details.
fpath = r'E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl'
task = None
with open(fpath, encoding='utf-8') as f:
    for line in f:
        d = json.loads(line)
        if d.get('task_id') == 'django__django-12125':
            task = d
            break

print('Task:', task['task_id'])
print('Base commit:', task['base_commit'])
print('FAIL_TO_PASS:', task['FAIL_TO_PASS'])
print()

# Read the existing prediction
pred_path = Path('experiments/runs/ITER3-12125-20261004T065000Z/django__django-12125/prediction.jsonl')
pred = json.loads(pred_path.read_text(encoding='utf-8'))
print('Predicted file:')
print('  instance_id:', pred['instance_id'])
print('  model_name:', pred['model_name_or_path'])
print('Patch:')
print(pred['model_patch'])
