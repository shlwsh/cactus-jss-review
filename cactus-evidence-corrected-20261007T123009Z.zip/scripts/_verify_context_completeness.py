"""Verify that inference-safe manifest covers all bug locations needed for prediction.

This script checks that for every task in the inference-safe manifest, the
bug location (derived from the issue description or gold patch hint) has
corresponding ContextUnits in the repository index.

Usage:
    python scripts/_verify_context_completeness.py [--repo-root PATH] [--manifest PATH]

Exit codes:
    0 = all tasks pass
    1 = one or more tasks missing bug-location units
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Optional

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from cactus.repository.index import build_index
from cactus.task.parser import parse_task, _imported_modules_to_paths, _DOTTED_PATH_RE


def extract_bug_locations_from_issue(issue_text: str, repo_prefix: str = "") -> set[str]:
    """Extract probable bug locations from issue description.

    Heuristics:
    1. File paths mentioned in import/from statements
    2. Paths with / in backtick code spans
    3. Error traceback file references

    Returns a set of repo-relative paths (e.g. "astropy/timeseries/core.py").
    """
    locations: set[str] = set()

    # 1. Import statements: "from astropy.timeseries.core import ..."
    import_paths = _imported_modules_to_paths(issue_text)
    for path in import_paths:
        if repo_prefix and not path.startswith(repo_prefix):
            path = repo_prefix.rstrip("/") + "/" + path
        locations.add(path)

    # 2. Code-style paths in backticks: `astropy/timeseries/core.py`
    code_path_re = re.compile(r"`([a-zA-Z0-9_/.-]+\.py)`")
    for match in code_path_re.finditer(issue_text):
        path = match.group(1)
        # Normalize: remove leading repo prefix if present
        if "/" in path or "." in path:
            locations.add(path)

    # 3. Error tracebacks: "File \"astropy/timeseries/core.py\", line N"
    trace_re = re.compile(r'File "([^"]+\.py)"')
    for match in trace_re.finditer(issue_text):
        path = match.group(1).replace("\\", "/")
        locations.add(path)

    # 4. Explicit file references: "astropy/timeseries/core.py"
    file_ref_re = re.compile(r"(?:in |from |file |path )`?([a-zA-Z0-9_/.-]+\.py)`?", re.IGNORECASE)
    for match in file_ref_re.finditer(issue_text):
        path = match.group(1)
        if "." in path or "/" in path:
            locations.add(path)

    return locations


def verify_task_coverage(
    repo_root: Path,
    task_id: str,
    issue_text: str,
    repo_id: Optional[str] = None,
) -> tuple[bool, list[str], list[str]]:
    """Verify that bug locations from issue text have units in the index.

    Returns:
        (passed, covered_paths, missing_paths)
    """
    # Normalize repo_id to prefix
    if repo_id:
        prefix = repo_id.replace("/", "_").replace("-", "_")  # e.g. "astropy_astropy"
        # The index paths are like "astropy/timeseries/core.py"
        repo_prefix = "/".join(repo_id.split("/"))  # e.g. "astropy/astropy"
    else:
        repo_prefix = ""

    bug_locations = extract_bug_locations_from_issue(issue_text, repo_prefix)

    if not bug_locations:
        # Cannot determine bug location - conservative: pass
        return True, [], []

    # Build unit index by path
    try:
        index = build_index(repo_root)
    except Exception as e:
        return False, [], [f"INDEX_BUILD_ERROR: {e}"]

    units_by_path: dict[str, list] = {}
    for u in index.units:
        units_by_path.setdefault(u.path, []).append(u)

    covered: list[str] = []
    missing: list[str] = []

    for loc in sorted(bug_locations):
        # Normalize: strip repo prefix if present
        normalized = loc
        if repo_prefix and loc.startswith(repo_prefix):
            normalized = loc[len(repo_prefix) + 1:]

        if normalized in units_by_path:
            covered.append(normalized)
        else:
            missing.append(normalized)

    return len(missing) == 0, covered, missing


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify context completeness for inference-safe manifest")
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=None,
        help="Path to repository root (required for actual verification)",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("json/cactus_tasks_inference_safe.jsonl"),
        help="Path to inference-safe manifest",
    )
    parser.add_argument(
        "--task-id",
        type=str,
        default=None,
        help="Verify only this task ID",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Show details for all tasks",
    )
    args = parser.parse_args()

    manifest_path = Path(args.manifest)
    if not manifest_path.exists():
        print(f"ERROR: Manifest not found: {manifest_path}", file=sys.stderr)
        return 1

    # Load tasks
    tasks: list[dict] = []
    with open(manifest_path) as f:
        for line in f:
            line = line.strip()
            if line:
                tasks.append(json.loads(line))

    if args.task_id:
        tasks = [t for t in tasks if t.get("task_id") == args.task_id]
        if not tasks:
            print(f"ERROR: Task not found: {args.task_id}", file=sys.stderr)
            return 1

    if not args.repo_root:
        print("WARNING: --repo-root not specified; only reporting issue-level analysis", file=sys.stderr)
        print()
        for task in tasks:
            issue_text = task.get("issue_text", "")
            task_id = task.get("task_id", "?")
            repo_id = task.get("repo_id", "")
            bug_locs = extract_bug_locations_from_issue(issue_text, "")
            print(f"  {task_id}: {len(bug_locs)} bug locations from issue text")
            for loc in sorted(bug_locs)[:5]:
                print(f"    - {loc}")
            if len(bug_locs) > 5:
                print(f"    ... ({len(bug_locs) - 5} more)")
        print()
        print("Run with --repo-root to verify units exist in index.")
        return 0

    repo_root = Path(args.repo_root)
    if not repo_root.exists():
        print(f"ERROR: Repo not found: {repo_root}", file=sys.stderr)
        return 1

    passed = 0
    failed = 0
    skipped = 0

    print(f"Verifying {len(tasks)} tasks against {repo_root}")
    print("=" * 70)

    for task in tasks:
        task_id = task.get("task_id", "?")
        issue_text = task.get("issue_text", "")
        repo_id = task.get("repo_id", "")

        is_ok, covered, missing = verify_task_coverage(
            repo_root, task_id, issue_text, repo_id
        )

        if is_ok:
            passed += 1
            if args.verbose:
                print(f"[PASS] {task_id}")
                for c in covered[:3]:
                    print(f"       + {c}")
        elif missing and all("INDEX_BUILD_ERROR" in m for m in missing):
            skipped += 1
            if args.verbose:
                print(f"[SKIP] {task_id} (index unavailable)")
        else:
            failed += 1
            print(f"[FAIL] {task_id}")
            for c in covered[:3]:
                print(f"       + {c}")
            for m in missing[:5]:
                print(f"       - {m}")
            if len(missing) > 5:
                print(f"       ... ({len(missing) - 5} more missing)")

    print("=" * 70)
    total = passed + failed + skipped
    print(f"Results: {passed}/{total} passed", end="")
    if skipped:
        print(f", {skipped} skipped (index unavailable)", end="")
    if failed:
        print(f", {failed} FAILED", end="")
    print()

    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
