"""Harvest citation metadata from official arXiv abstract pages.

The script is deliberately small and project-local: it stores the query list and
the server-returned citation metadata for later human review before BibTeX use.
"""
from __future__ import annotations

import html
import json
import re
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

IDS = """2310.06770 2203.07722 2303.12570 2405.15793 2407.01489 2407.16741
2308.03688 2303.08774 2210.03629 2201.11903 2305.10601 2306.08329
2302.04761 2307.16789 2207.01780 2109.00859 2009.10280 2309.12499
2404.05427 2403.08604 2305.16504 2302.08451 2211.14587 2206.14858
2306.04557 2304.12244 2402.11946 2404.16150 2307.13854 2309.15237
2311.09721 2310.03714 2401.13178 2402.17553 2401.13649 2305.19308
2312.10665 2308.08487 2405.12132 2406.16219 2509.16941 2602.09540""".split()

META = re.compile(r'<meta name="(?P<name>citation_[^"]+)" content="(?P<value>[^"]*)"', re.I)


def fetch(arxiv_id: str) -> dict:
    url = f"https://arxiv.org/abs/{arxiv_id}"
    request = urllib.request.Request(url, headers={"User-Agent": "CACTUS-bibliography/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        body = response.read().decode("utf-8", "ignore")
    fields: dict[str, list[str]] = {}
    for match in META.finditer(body):
        fields.setdefault(match.group("name"), []).append(html.unescape(match.group("value")))
    return {
        "arxiv_id": arxiv_id,
        "url": url,
        "title": fields.get("citation_title", [None])[0],
        "date": fields.get("citation_date", [None])[0],
        "authors": fields.get("citation_author", []),
        "status": "verified" if fields.get("citation_title") else "metadata_missing",
    }


def main() -> None:
    rows = []
    failures = []
    for arxiv_id in IDS:
        try:
            row = fetch(arxiv_id)
            rows.append(row)
            if row["status"] != "verified":
                failures.append({"arxiv_id": arxiv_id, "reason": "metadata_missing"})
        except Exception as exc:  # preserve failure evidence for later retry
            failures.append({"arxiv_id": arxiv_id, "reason": type(exc).__name__, "detail": str(exc)})
        time.sleep(0.25)
    out = Path(__file__).resolve().parents[1] / "paper" / "data" / "scholar"
    out.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "1.0",
        "source": "official arXiv abstract pages",
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "query_ids": IDS,
        "records": rows,
        "failures": failures,
    }
    (out / "arxiv_metadata.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"records": len(rows), "verified": sum(r["status"] == "verified" for r in rows), "failures": len(failures)}))


if __name__ == "__main__":
    main()
