"""Trace the meaningful-change test to find what's rejecting it."""
import sys, os, json, tempfile, subprocess
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

import importlib.util
spec = importlib.util.spec_from_file_location("cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

source = (
    "class C:\n"
    "    def m(self, cols):\n"
    "        raise ValueError(\"expected '{}'\".format(cols[0]))\n"
)

response = json.dumps({"edits": [{
    "path": "core.py",
    "symbol": "C.m",
    "old_statement": "raise ValueError(\"expected '{}'\".format(cols[0]))",
    "replacement": "raise ValueError(\"expected {}\".format(', '.join(cols)))",
}]})

with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    subprocess.run(["git", "init", "-q", str(root)], check=True)
    subprocess.run(["git", "-C", str(root), "config", "core.autocrlf", "false"], check=True)
    (root / "core.py").write_bytes(source.encode("utf-8"))
    try:
        patch_text = mod._statement_edit_to_patch(response, root, allowed_paths={"core.py"})
        print("PATCH:")
        print(patch_text)
        # Apply
        checked = subprocess.run(["git", "apply", "--check"], input=patch_text.encode(), cwd=root, capture_output=True)
        print(f"apply check rc={checked.returncode}")
        if checked.returncode != 0:
            print(f"stderr: {checked.stderr.decode()}")
        else:
            subprocess.run(["git", "apply"], input=patch_text.encode(), cwd=root, check=True)
            print(f"updated file: {(root/'core.py').read_text(encoding='utf-8')!r}")
    except Exception as e:
        import traceback
        print(f"FAILED: {type(e).__name__}: {e}")
        traceback.print_exc()
