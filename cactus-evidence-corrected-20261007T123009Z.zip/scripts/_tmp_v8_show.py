"""Show full stderr + model_call response for v8 RUN."""
import json
from pathlib import Path

stderr = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260925T222323Z-C4330524\logs\predict.stderr.log")
print("=== predict.stderr.log (FULL) ===")
print(stderr.read_text(encoding="utf-8"))
print("\n=== events.jsonl: model_call + prediction_rejected/exhausted ===")
events_path = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260925T222323Z-C4330524\trace\events.jsonl")
for line in events_path.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    e = json.loads(line)
    t = e.get("type")
    if t in ("model_call", "prediction_rejected", "prediction_exhausted"):
        pl = e.get("payload", {}) or {}
        print(f"\n--- {t} @ {e.get('utc_ts')} ---")
        if t == "model_call":
            print(f"  finish_reason: {pl.get('finish_reason')}")
            print(f"  input_tokens: {pl.get('input_tokens')}")
            print(f"  output_tokens: {pl.get('output_tokens')}")
            print(f"  resp_chars: {len(pl.get('response_text') or '')}")
            rt = (pl.get('response_text') or '')
            print(f"  RESP[0:800]: {rt[:800]!r}")
        elif t == "prediction_rejected":
            print(f"  class: {pl.get('reason_class')}")
            print(f"  reason: {(pl.get('reason') or '')[:300]}")
            print(f"  finish_reason: {pl.get('finish_reason')}")
        elif t == "prediction_exhausted":
            print(f"  attempts: {pl.get('attempts')}")
            print(f"  final: {(pl.get('final_rejection') or '')[:300]}")
