"""Produce fail-closed error-analysis artifacts from the current evidence set."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


def run(source: Path, output_dir: Path) -> dict[str, object]:
    with source.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    output_dir.mkdir(parents=True, exist_ok=True)
    fields = ["instance_id", "attempt_id", "date", "repo", "error_code", "error_stage", "exception_type", "message_hash", "retryable", "canonical_outcome", "status"]
    taxonomy = []
    # The input is the deduplicated 500-task outcome table; audit only the
    # evaluator-error rows and never relabel resolved/unresolved tasks.
    rows = [row for row in rows if row.get("error") == "1"]
    for row in rows:
        taxonomy.append({"instance_id": row.get("task", ""), "attempt_id": "", "date": row.get("time", ""), "repo": row.get("task", "").split("__", 1)[0], "error_code": "E14_UNKNOWN", "error_stage": "pending_evidence", "exception_type": "pending_evidence", "message_hash": "", "retryable": "", "canonical_outcome": "pending", "status": "pending_evidence"})
    with (output_dir / "error_taxonomy.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader(); writer.writerows(taxonomy)
    clusters = [{"cluster_id": "pending_evidence", "error_code": "E14_UNKNOWN", "task_count": len(taxonomy), "status": "pending_evidence"}]
    with (output_dir / "error_clusters.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(clusters[0]), lineterminator="\n")
        writer.writeheader(); writer.writerows(clusters)
    repo_counts = Counter(row["repo"] for row in taxonomy)
    with (output_dir / "repo_failure_analysis.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["repo", "task_count", "error_code", "status"], lineterminator="\n")
        writer.writeheader(); writer.writerows({"repo": repo, "task_count": count, "error_code": "E14_UNKNOWN", "status": "pending_evidence"} for repo, count in sorted(repo_counts.items()))
    temporal_counts = Counter(row["date"].split()[0] if row["date"] else "unknown" for row in taxonomy)
    with (output_dir / "temporal_failure_analysis.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["date", "task_count", "error_code", "status"], lineterminator="\n")
        writer.writeheader(); writer.writerows({"date": date, "task_count": count, "error_code": "E14_UNKNOWN", "status": "pending_evidence"} for date, count in sorted(temporal_counts.items()))
    source_digest = hashlib.sha256(source.read_bytes()).hexdigest()
    summary = {
        "source": source.as_posix(),
        "source_sha256": source_digest,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "error_rows": len(taxonomy),
        "classified_rows": 0,
        "pending_evidence": len(taxonomy),
        "evidence_status": "no_task_level_evidence",
        "status": "pending_evidence",
    }
    (output_dir / "error_analysis_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.source, args.output_dir), ensure_ascii=False))
