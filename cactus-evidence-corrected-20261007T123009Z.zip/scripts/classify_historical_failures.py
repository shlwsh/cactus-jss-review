"""Classify task-level failure evidence without upgrading aggregate history."""

from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cactus.evaluation.taxonomy_v2 import FailureClassification, classify_text, generate_signature


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RUNS = ROOT / "experiments" / "runs"
DEFAULT_OUTPUT = ROOT / "analysis"


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _display_path(path: Path, *, base: Path = ROOT) -> str:
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return f"external/{path.name}"


def _manifest(bundle: Path) -> dict[str, object]:
    for name in ("run_manifest.json", "manifest.json"):
        path = bundle / name
        if path.is_file():
            try:
                value = json.loads(_read(path))
                return value if isinstance(value, dict) else {}
            except json.JSONDecodeError:
                return {}
    return {}


def _bundle_candidates(root: Path) -> list[Path]:
    candidates: set[Path] = set()
    for path in root.rglob("*"):
        if not path.is_dir():
            continue
        if any((path / name).is_file() for name in ("run_manifest.json", "manifest.json")):
            candidates.add(path)
    return sorted(candidates)


def _historical_error_ids() -> set[str]:
    path = ROOT / "paper" / "data" / "final_task_outcomes.csv"
    if not path.is_file():
        return set()
    with path.open(encoding="utf-8", newline="") as handle:
        return {row.get("task", "") for row in csv.DictReader(handle) if row.get("error") == "1" and row.get("task")}


def _evidence(bundle: Path) -> tuple[str, list[str]]:
    patterns = ("evaluator_report.*", "evaluation/*.json", "evaluator/*.json", "logs/*.log", "prediction/*.diff", "raw/*.json", "raw/*.jsonl")
    paths: list[Path] = []
    for pattern in patterns:
        paths.extend(bundle.glob(pattern))
    paths = sorted({path for path in paths if path.is_file()})
    text = "\n".join(_read(path) for path in paths)
    return text, [path.relative_to(bundle).as_posix() for path in paths]


def _row(bundle: Path) -> dict[str, object]:
    manifest = _manifest(bundle)
    text, source_files = _evidence(bundle)
    classification: FailureClassification = classify_text(text) if text else classify_text("")
    timestamp = str(manifest.get("started_at", manifest.get("start_time", "")))
    normalized = re.sub(r"\s+", " ", text).strip().lower()
    signature_hash = generate_signature({
        "stage": manifest.get("stage", "unknown"),
        "exception_class": manifest.get("exception_class", classification.failure_code.value),
        "normalized_msg": normalized[:4000],
        "top_frame": manifest.get("top_frame", "unknown"),
    })
    return {
        "instance_id": manifest.get("instance_id", manifest.get("task_id", bundle.name)),
        "attempt_id": manifest.get("attempt_id", manifest.get("run_id", bundle.name)),
        "date": timestamp,
        "repo": manifest.get("repo", manifest.get("repo_id", "")),
        "failure_family": classification.failure_family.value,
        "failure_code": classification.failure_code.value,
        "stage": manifest.get("stage", "evidence"),
        "signature_hash": signature_hash,
        "confidence": classification.confidence,
        "retryable": classification.retryable,
        "replayable": classification.replayable,
        "needs_manual_review": classification.needs_manual_review,
        "evidence_status": "observed_bundle" if text else "pending_evidence",
        "source_files": ";".join(source_files),
    }


def classify(root: Path = DEFAULT_RUNS, output_dir: Path = DEFAULT_OUTPUT) -> dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = [_row(bundle) for bundle in _bundle_candidates(root)]
    observed_ids = {str(row["instance_id"]) for row in rows if row["evidence_status"] == "observed_bundle"}
    for task_id in sorted(_historical_error_ids() - observed_ids):
        rows.append({
            "instance_id": task_id,
            "attempt_id": "",
            "date": "",
            "repo": task_id.split("__", 1)[0],
            "failure_family": "E",
            "failure_code": "E06_UNKNOWN_EVALUATOR",
            "stage": "pending_evidence",
            "signature_hash": "",
            "confidence": 0.0,
            "retryable": False,
            "replayable": False,
            "needs_manual_review": True,
            "evidence_status": "pending_evidence",
            "source_files": "",
        })
    fields = ["instance_id", "attempt_id", "date", "repo", "failure_family", "failure_code", "stage", "signature_hash", "confidence", "retryable", "replayable", "needs_manual_review", "evidence_status", "source_files"]
    with (output_dir / "historical_failure_taxonomy.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    clusters: Counter[str] = Counter(str(row["signature_hash"]) for row in rows if row["evidence_status"] == "observed_bundle")
    cluster_rows: list[dict[str, object]] = []
    cumulative = 0
    observed_count = sum(clusters.values())
    for index, (signature, count) in enumerate(clusters.most_common(10), start=1):
        cumulative += count
        cluster_rows.append({"rank": index, "signature_hash": signature, "task_count": count, "cumulative_task_count": cumulative, "cumulative_coverage_rate": round(cumulative / max(1, observed_count), 6), "reaches_80pct": cumulative / max(1, observed_count) >= 0.80})
    with (output_dir / "failure_clusters.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["rank", "signature_hash", "task_count", "cumulative_task_count", "cumulative_coverage_rate", "reaches_80pct"], lineterminator="\n")
        writer.writeheader()
        writer.writerows(cluster_rows)
    temporal: Counter[str] = Counter(str(row["date"])[:10] or "unknown" for row in rows if row["evidence_status"] == "observed_bundle")
    temporal_rows = [{"date": date, "task_count": count} for date, count in sorted(temporal.items())]
    for filename in ("temporal_failure_clusters.csv", "temporal_failure_analysis.csv"):
        with (output_dir / filename).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=["date", "task_count"], lineterminator="\n")
            writer.writeheader()
            writer.writerows(temporal_rows)
    summary = {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_runs": _display_path(root),
        "bundle_count": len(_bundle_candidates(root)),
        "classified_bundle_count": sum(row["evidence_status"] == "observed_bundle" for row in rows),
        "pending_evidence_bundle_count": sum(row["evidence_status"] != "observed_bundle" for row in rows),
        "historical_error_count": len(_historical_error_ids()),
        "historical_error_pending_evidence_count": sum(row["instance_id"] in _historical_error_ids() and row["evidence_status"] != "observed_bundle" for row in rows),
        "observed_evidence_task_count": observed_count,
        "top10_cluster_count": len(cluster_rows),
        "top10_cumulative_task_count": cumulative,
        "top10_cumulative_coverage_rate": round(cumulative / max(1, observed_count), 6),
        "top10_reaches_80pct": cumulative / max(1, observed_count) >= 0.80,
        "status": "ready" if rows and all(row["evidence_status"] == "observed_bundle" for row in rows) else "pending_evidence",
    }
    (output_dir / "historical_failure_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, default=DEFAULT_RUNS)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    print(json.dumps(classify(args.runs, args.output_dir), ensure_ascii=False))
