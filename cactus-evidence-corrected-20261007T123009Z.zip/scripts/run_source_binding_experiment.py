"""P1.4 Source-bound Editing Effect Experiment: cactus_full vs no_source_binding.

Compare the effect of source-owned repair sites on patch generation:
  - cactus_full: source-bound editing ENABLED (baseline)
  - no_source_binding: source-bound editing DISABLED (fallback to unified_diff)

Runs the 10-task ablation cohort with both variants.

Usage:
    python scripts/run_source_binding_experiment.py [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"
MANIFEST = PROJECT_ROOT / "data/manifests/swebench_lite50_b0dde109_test_inference_safe.jsonl"

# 10-task ablation cohort
ABLATION_10_TASKS = [
    "astropy__astropy-12907", "astropy__astropy-14182", "astropy__astropy-14365",
    "astropy__astropy-14995", "astropy__astropy-6938",  "astropy__astropy-7746",
    "django__django-10914",    "django__django-10924",   "django__django-11001",
    "django__django-11019",
]

VARIANTS = [
    ("cactus_full",       "Source-bound ENABLED (baseline)"),
    ("no_source_binding",  "Source-bound DISABLED (unified_diff fallback)"),
]


def get_best_patch(run_dir: Path, task_id: str) -> tuple[bool, int, str | None]:
    best_len = 0
    best_run = None
    for run_name in sorted(run_dir.iterdir()):
        if not run_name.is_dir():
            continue
        pred_path = run_name / task_id / "prediction.jsonl"
        if pred_path.exists():
            try:
                with open(pred_path, encoding="utf-8") as f:
                    data = json.loads(f.readline())
                patch = data.get("model_patch", "")
                if patch and patch.strip() and len(patch) > best_len:
                    best_len = len(patch)
                    best_run = run_name.name
            except Exception:
                pass
    return best_len > 0, best_len, best_run


def run_one(task_id: str, variant: str, validation_id: str, dry_run: bool) -> dict:
    output_dir = RUNS_DIR / validation_id / task_id
    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_single_task_predict.py"),
        "--task-id", task_id,
        "--variant", variant,
        "--validation-id", validation_id,
    ]

    if dry_run:
        print(f"  [DRY RUN] {' '.join(cmd)}")
        return {"task_id": task_id, "variant": variant, "status": "dry_run", "duration": 0}

    started = time.time()
    try:
        env = subprocess.os.environ.copy()
        env["PYTHONPATH"] = str(PROJECT_ROOT)
        result = subprocess.run(
            cmd,
            cwd=str(PROJECT_ROOT),
            env=env,
            capture_output=True,
            text=True,
            timeout=1800,
        )
        duration = time.time() - started
        success = result.returncode == 0
        has_patch = False
        patch_len = 0
        if success:
            has_patch, patch_len, _ = get_best_patch(RUNS_DIR, task_id)
        return {
            "task_id": task_id,
            "variant": variant,
            "status": "PASS" if has_patch else "FAIL",
            "patch_len": patch_len,
            "duration": round(duration, 1),
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        duration = time.time() - started
        return {"task_id": task_id, "variant": variant, "status": "TIMEOUT", "duration": round(duration, 1), "returncode": -1}
    except Exception as e:
        duration = time.time() - started
        return {"task_id": task_id, "variant": variant, "status": "ERROR", "error": str(e), "duration": round(duration, 1), "returncode": -2}


def run_variant(variant: str, desc: str, tasks: list[str], dry_run: bool) -> list[dict]:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    validation_id = f"SOURCEBINDING-{variant.upper()}-{ts}"
    print(f"\n=== Variant: {variant} [{desc}] ===")
    print(f"Validation ID: {validation_id}")
    results = []
    for i, task_id in enumerate(tasks):
        print(f"  [{i+1}/{len(tasks)}] {task_id}...", end=" ", flush=True)
        result = run_one(task_id, variant, validation_id, dry_run)
        results.append(result)
        print(f"{result['status']} ({result.get('duration', 0):.0f}s)")
        if not dry_run:
            time.sleep(2)
    return results


def summarize(results: list[dict], variant: str) -> dict:
    total = len(results)
    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    timeout = sum(1 for r in results if r["status"] == "TIMEOUT")
    error = sum(1 for r in results if r["status"] == "ERROR")
    durations = [r["duration"] for r in results if r.get("duration")]
    avg_dur = sum(durations) / len(durations) if durations else 0
    return {
        "variant": variant, "total": total, "passed": passed,
        "failed": failed, "timeout": timeout, "error": error,
        "pass_rate": f"{passed}/{total}", "avg_duration": round(avg_dur, 1),
    }


def print_table(summaries: list[dict]):
    print("\n" + "=" * 80)
    print("Source-bound Editing Effect Results (10-task cohort)")
    print("=" * 80)
    print(f"{'Variant':<30} {'Description':<40} {'PASS':>6} {'Avg Time':>10}")
    print("-" * 80)
    for s in summaries:
        print(f"{s['variant']:<30} {'':40} {s['pass_rate']:>6} {s['avg_duration']:>9.1f}s")
    print("=" * 80)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    all_results = []
    all_summaries = []

    for variant, desc in VARIANTS:
        results = run_variant(variant, desc, ABLATION_10_TASKS, args.dry_run)
        summary = summarize(results, variant)
        all_results.extend(results)
        all_summaries.append(summary)

    print_table(all_summaries)

    if not args.dry_run:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        output_file = PROJECT_ROOT / "experiments" / "derived" / f"source_binding_results_{ts}.json"
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output = {
            "summaries": {s["variant"]: s for s in all_summaries},
            "detailed": all_results,
            "generated_at": ts,
        }
        output_file.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"\nResults saved to: {output_file}")


if __name__ == "__main__":
    main()
