"""查 ITER4 模型调用统计"""
import json

for task in ['django__django-11910', 'django__django-12125']:
    tid = task.split('django-')[1]
    p = f'experiments/runs/ITER4-{tid}/{task}/events.jsonl'
    import os
    print('checking', p, 'exists?', os.path.exists(p))
    with open(p, encoding='utf-8') as f:
        events = [json.loads(l) for l in f]
    model_calls = sum(1 for e in events if e.get('type') == 'model_call')
    print(f'{task}: events={len(events)} model_calls={model_calls}')
    for e in events:
        if e.get('type') == 'model_call':
            p2 = e.get('payload', {})
            in_tok = p2.get('input_tokens', 0)
            out_tok = p2.get('output_tokens', 0)
            seq = e.get('seq', '?')
            print(f'  seq={seq} in={in_tok} out={out_tok}')