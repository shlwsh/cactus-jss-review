from pathlib import Path
if (Path(__file__).resolve().parents[1] / 'paper/publication_sources.json').is_file():
    raise SystemExit('BLOCKED: legacy snapshot claims withdrawn; use scripts/generate_integrity_handoff.py')
from datetime import datetime, timezone, timedelta
import hashlib, json, subprocess, re

root=Path(__file__).resolve().parents[1]
now=datetime.now(timezone.utc).replace(microsecond=0)
stamp=now.astimezone(timezone(timedelta(hours=8))).strftime('%Y%m%d-%H%M%S')
output=root/'docs/50tasks'/f'v1.1_{stamp}_统一数据源更新与论文v1.23交接质量报告.md'
machine=output.with_suffix('.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=json.loads((root/'paper/data/evidence_catalog.json').read_text())
manifest=json.loads((root/'paper/data/scholar/cited_papers_manifest.json').read_text())
global_result=json.loads((root/'paper/build/current_validation/global_final.json').read_text())
all_log=(root/'paper/build/current_validation/datactl_all_final.log').read_text(errors='replace').splitlines()
audit_log=(root/'paper/build/current_validation/datactl_audit_final.log').read_text(errors='replace').splitlines()
pdf=Path((root/'paper/build/current_validation/release_path.txt').read_text())
claims=Path((root/'paper/build/current_validation/claims_path.txt').read_text())
audit=json.loads((root/'paper/build/manuscript_consistency_current.json').read_text())
log=(root/'paper/build/main.log').read_text(errors='replace')
old_count=len(re.findall('FAIL RUN bundle', '\n'.join(all_log)))
critical=sum(x.startswith('CRITICAL') for x in audit_log)
findings=len(audit_log)-1
tracked_changes=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert not any(p.startswith('acm/experiments/runs/') for p in tracked_changes)
assert 'acm/paper/data/final_task_outcomes.csv' not in tracked_changes
inputs=[root/'paper/evidence_sources.json',root/'paper/data/evidence_catalog.json',root/'paper/data/admitted_retry_results.csv',
        root/'paper/main.tex',root/'paper/references.bib',root/'paper/data/scholar/cited_papers_manifest.json',
        root/'paper/build/manuscript_consistency_current.json',root/'paper/build/current_validation/global_final.json',
        root/'paper/dist/cactus-acm-submission.zip',pdf]
inventory_root=root/'experiments/derived/lite50_retry_integration_20261002T225306Z'
inputs.extend([inventory_root/name for name in ('integration_summary.json','run_inventory.jsonl','result_registry.jsonl')])
summary={
 'schema_version':'1.0','generated_at':now.strftime('%Y-%m-%dT%H:%M:%SZ'),
 'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'working_tree_changes':True,'paper_version':'1.23','paper_path':pdf.relative_to(root).as_posix(),
 'cohorts':[c['counts'] for c in catalog['cohorts']],
 'checks':{'retry_full_admission':'PASS','unified_catalog':'PASS','artifact_table':'PASS','artifact_provenance':'PASS',
           'manuscript_consistency':audit['status'],'pipeline_independence':'PASS','cited_snapshots':'PASS',
           'isolated_package_rebuild':'PASS','syntax_compile':'PASS','diff_check':'PASS',
           'datactl_all':'FAIL','datactl_audit':'FAIL'},
 'historical_bad_bundle_count':old_count,'global_audit_findings':findings,'global_critical_findings':critical,
 'citations':{'cited_keys':manifest['total_cited'],'snapshots':len(manifest['records']),'metadata_corrections':len(manifest['metadata_changes'])},
 'latex':{'pages':int(re.search(r'Output written.*?\((\d+) pages',log).group(1)),
          'undefined':log.count('undefined'),'overfull_hbox':log.count('Overfull \\hbox'),'overfull_vbox':log.count('Overfull \\vbox'),
          'bib_warnings':(root/'paper/build/main.blg').read_text().count('Warning--')},
 'visual_review_pages':[1,3,5,10,11,14,16],
 'artifact_hashes':{p.relative_to(root).as_posix():sha(p) for p in inputs},
 'bounds':['separate_cohorts','supporting_retries_only','no_best_of_retries_estimate','no_comparative_effectiveness_claim',
           'historical_global_failures_not_cleared','raw_RUNs_not_modified','frozen_task_CSV_not_modified']}
machine.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
artifact_lines='\n'.join(f'| `{p}` | `{digest}` |' for p,digest in summary['artifact_hashes'].items())
content=f'''# 统一数据源更新与论文 v1.23 交接质量报告

- 版本：v1.1
- 生成时间（UTC）：{summary['generated_at']}
- 文件名时间：{stamp}，Asia/Shanghai；实验与来源 sidecar 均使用 UTC 秒级时间。
- 工作分支：acm0920
- 来源 HEAD：`{summary['source_commit']}`；本次修改尚在工作树，输入与生成器另以完整 SHA-256 绑定。
- 论文：`{pdf.relative_to(root).as_posix()}`（16 页）

## 1. 完成内容与可用结论

已完成统一证据目录、生成消费链、正文引用核验、创新点与方法表达修订、论文重编、版本 PDF 和离线投稿包。
本次数据源更新保留 cohort、合同与代码版本；不把失败筛选任务的多次重试并入原冻结快照的任务解决率。

| 证据范围 | 结果 | 允许用途 |
|---|---|---|
| 冻结 Verified 快照 | 500 唯一任务；11 resolved、468 unresolved、21 未裁定；479 evaluator-valid | 描述性历史快照；不等于当前全库来源准入认证 |
| Lite 失败队列重试 | 30 唯一任务、71 归档 RUN，71 bundle 通过、45 严格官方 evaluator 有效 | 分阶段、按合同审计 |
| 完整准入的重试 | 24 RUN、20 唯一任务；3 resolved RUN/3 resolved 任务 | 政策计算的 supporting；不用于版本改善或基线优越性主张 |
| 全归档观察 | 6 resolved RUN/5 不同任务 | 仅说明排除与重复计数，不能替代准入结果 |

准入 resolved 任务：`astropy__astropy-6938`、`django__django-11001`、`django__django-11049`。
归档还观察到 11039、12286 resolved；11049 两次 resolved 不能增加唯一任务数。

R10 的 28 RUN 中 18 evaluator-valid、3 observed resolved，但全批准入为 0。
原因是合同 driver 摘要与绑定提交中的实际文件不一致。包括 11019 R5/R6/R7/R9 在内，共 32 RUN 存在该缺陷。
本次保留历史合同、授权和 RUN；未通过改写历史摘要使其进入有效 registry。

## 2. 统一数据源与可执行生成链

1. `paper/evidence_sources.json`：固定四个机器输入的完整摘要，作为项目论文证据的统一入口。
2. `paper/data/evidence_catalog.json`：两个 cohort、逐合同/来源提交分组、完整排除原因与用途边界。
3. `paper/data/admitted_retry_records.json`：由准入 registry 导出的记录数组。
4. `paper/data/admitted_retry_results.csv` / `.md`：经项目 `cactus.cli artifact-table` 生成；逐记录核对 value、policy、ID 和源记录摘要。
5. `paper/generated/evidence_macros.tex` 与三张重试表：由同一目录生成；摘要和正文通过宏引用新数值。
6. `paper_pipeline.py` 显式消费冻结 CSV，生成前检查 pinned 来源；论文审计接入目录校验。

冻结 `final_task_outcomes.csv` 与重试原始 registry/inventory 的字节未变。
生成 sidecar 与生成动作同时执行；图表 PDF/PNG/SVG 各自绑定实际字节，避免共用一个摘要。
新旧图表、注册条件、交叉表、RUN 盘点和 pending 表格均通过生成器重建，没有手填观测结果。

在 `acm/` 执行：

```powershell
$env:PYTHONPATH='src'
python -m scripts.import_formal_run_bundles --verify --output experiments/derived/lite50_retry_integration_20261002T225306Z
python scripts/generate_evidence_catalog.py
python scripts/generate_evidence_catalog.py --verify
python scripts/audit_manuscript_consistency.py --strict --report paper/build/manuscript_consistency_current.json
python scripts/verify_cited_papers.py
python -m cactus.tools.datactl provenance verify
python -m cactus.tools.datactl gate scan-latex
python scripts/paper_pipeline.py build
python scripts/paper_pipeline.py package
```

完整 RUN 准入核验需要本地保存的 RUN、合同、授权；投稿包的离线重编不重新认证这些 RUN。

## 3. 创新点、方法与引用修订

论文贡献现在对应实际实现：预算约束选择与源码绑定编辑的集成、依赖敏感事务验证、evaluator/完整准入分层、可复核的 cohort 目录。
事务机制明确了候选保留、依赖变化后凭据失效、闭包校验、原子提交与停滞停止。语义义务目前只覆盖支持的 sequence-ordering 结构，11019 未解决；没有写成通用语义修复成功。

修正旧稿评分公式：当前代码是五项归一化静态相关性，冗余/覆盖/碎片在边际选择阶段处理一次。
旧稿的 embedding 项、六项公式及历史信号映射不再当作当前实现。
不同来源提交的运行不被追溯标为一个相同 selector。

正文引用 31 条，全部保存官方 HTML/Crossref 元数据快照，修正 16 处标题/作者/年份差异。
新增 PROV-DM 引用用于来源设计；与 Agentless、AutoCodeRover、RepoCoder、Agent Retrieval Bench 区分研究范围，不宣称结构检索或分阶段修复本身为首次发明。
Agent Retrieval Bench 的标题、作者和 arXiv 标识经官方来源确认。
SWE-bench Lite 使用官方页面并区分官方 300 题与本地 Lite-50。
arXiv 文献按预印本类型排版，没有虚构卷号或页码来消除 BibTeX 警告。

官方核验来源示例：[PROV-DM](https://www.w3.org/TR/2013/REC-prov-dm-20130430/)、[SWE-bench Lite](https://www.swebench.com/lite.html)、[Agent Retrieval Bench](https://arxiv.org/abs/2607.24882)、[AutoCodeRover](https://arxiv.org/abs/2404.05427)。

本轮新快照没有宣称新增 PDF 归档；原有历史论文 PDF 均保留。
现行引用索引为 `paper/data/scholar/cited_papers_manifest.json`，每次绑定更新另存 UTC 命名历史索引。
完整主张矩阵：`{claims.relative_to(root).as_posix()}`。

主要降级/修正：

- 删除依据少量 evaluator 成功推断整个 Lite 流水线可靠、构成 patch quality 下界的文字。
- 历史 13033 对照缺少正式准入必需项，改为诊断例证；不再当作合格控制实验或最终模型归因。
- R10 observed resolved 与 admitted resolved 分开。
- 摘要、引言、方法、结果、讨论、局限、结论均同步；主张“提高解决率/降低成本/组件归因”保持待匹配实验。

## 4. 质量检查与交付物

| 检查 | 状态 | 说明 |
|---|---|---|
| 71 RUN 完整准入与冻结来源复核 | PASS | 复核后仍为 24 supporting，不提升历史排除项 |
| 统一目录/记录/表/宏/来源摘要 | PASS | 8 个新数据与表宏产物；原始输入摘要固定 |
| 严格 manuscript consistency | PASS | 冻结快照与新目录分别核对；报告放 build，原有未提交审计文件未被覆盖 |
| 项目 artifact provenance | PASS | 实际 PDF/PNG/SVG/TeX 字节与 sidecar 相符 |
| 独立管线审计、LaTeX gate | PASS | 这是项目独立性/宏输入检查，不替代完整 cited 核验 |
| 31 条 cited 官方来源索引 | PASS | 覆盖与元数据/文件哈希核对，16 处更正 |
| LaTeX/BibTeX | PASS | 16 页，0 undefined、0 overfull hbox、0 BibTeX warning |
| 页面目检 | PASS（所检页） | 1/3/5/10/11/14/16 页，摘要、评分式、事务方法、重试表、结论、引用可读；保留审稿行号 |
| 投稿包独立离线重编 | PASS | F 盘解压 370 文件；无 .git/原始 RUN 仍可重编，来源 commit 记 null 而非猜测 |
| 语法编译与 diff whitespace | PASS | compileall；git diff --check；未新增或运行单元测试 |
| 全库 datactl all | FAIL（历史问题） | {old_count} 个历史坏 bundle，未因本次论文重编清除 |
| 全库 datactl audit | FAIL（历史问题） | {findings} findings / {critical} critical；证据保持原状 |

排版还存在 1 个 `Overfull \\vbox`，约 1.326pt，位于参考文献输出阶段；未出现横向越界、截断或未定义引用，不能表述为“完全零警告”。
独立离线 PDF 不要求字节相同，因为编译时间等元数据会变化；固定源数据摘要和生成表宏通过检查。

PDF：`{pdf.relative_to(root).as_posix()}`；投稿包：`paper/dist/cactus-acm-submission.zip`。
PDF 带同次编译 provenance，绑定源码、Bib、宏、表、图、样式和统一目录。
旧 PDF/报告保留。F 盘临时重编与目检目录为本轮工作资料，非新增正式实验。

## 5. 来源摘要

| 文件 | SHA-256 |
|---|---|
{artifact_lines}

机器质量摘要：`{machine.relative_to(root).as_posix()}`。
全库最后核验的时间及日志：`paper/build/current_validation/global_final.json`，记录时间 `{global_result['generated_at']}`。

## 6. 交接边界与下一步

本次完成用户要求的数据源联动、引用/创新表达更新和新版论文输出，不启动新的付费模型或 evaluator 实验。
论文修订与生成器变化仍在工作树，尚未针对本轮另行提交/推送；上轮原有审计时间差异和 fixture cache 保留。

下一轮若需要效果主张，应以新的 reviewed contract 和 source/driver 字节绑定执行 matched baseline/ablation；不能补写历史合同让 R10 入表。
另需单独处置全库历史坏 bundle、审计 critical 与冻结 Verified 快照来源认证；当前局部 PASS 不代表全库 PASS。
'''
output.write_text(content,encoding='utf-8',newline='\n')
for path,kind in ((machine,'derived_dataset'),(output,'appendix')):
 payload={'schema_version':'2.0','artifact_id':'DATA-HANDOFF-'+hashlib.sha256(path.name.encode()).hexdigest().upper(),
          'artifact_type':kind,'artifact_path':path.relative_to(root).as_posix(),'artifact_sha256':sha(path),
          'generated_at':summary['generated_at'],'generator':{'script':'scripts/generate_publication_update_handoff.py','script_sha256':sha(Path(__file__)),
          'source_commit':summary['source_commit']},'inputs':[{'path':p.relative_to(root).as_posix(),'sha256':sha(p)} for p in inputs],
          'transform':{'scope':'current_publication_update_quality_summary','no_effectiveness_promotion':True}}
 path.with_name(path.name+'.provenance.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'paper/build/current_validation/handoff_path.txt').write_text(str(output),encoding='utf-8')
print(output)
print({'historical_bad_bundles':old_count,'findings':findings,'critical':critical,'PDF_sha256':sha(pdf)})
