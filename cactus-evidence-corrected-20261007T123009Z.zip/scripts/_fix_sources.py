#!/usr/bin/env python3
"""Check and update mismatched SHA256 in publication_sources.json."""
import json
import hashlib
from pathlib import Path

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

sources_file = Path('paper/publication_sources.json')
sources = json.loads(sources_file.read_text(encoding='utf-8'))

updates_needed = []
for name, src in sources['sources'].items():
    actual_path = Path(src['path'])
    if actual_path.exists():
        actual_sha = sha256(actual_path)
        stored_sha = src['sha256']
        if actual_sha != stored_sha:
            updates_needed.append((name, src['path'], stored_sha, actual_sha))
            print(f'UPDATING {name}:')
            print(f'  file: {src["path"]}')
            print(f'  stored: {stored_sha}')
            print(f'  actual: {actual_sha}')
            src['sha256'] = actual_sha

if updates_needed:
    sources_file.write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'\nUpdated {len(updates_needed)} entries')
else:
    print('No updates needed')
