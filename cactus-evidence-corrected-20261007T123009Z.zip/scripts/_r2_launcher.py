"""Bootstrap: runs the campaign CLI as a module from the acm/ parent directory."""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Working dir must be the acm/ parent (e.g. E:/work/p5-acm/),
# then 'python -m scripts.run_swebench_campaign' resolves cactus and scripts.*

# Ensure we are running from acm/ parent
_acm_dir = Path(__file__).parent  # acm/scripts/
_repo_root = _acm_dir.parent      # repo root (e.g. E:/work/p5-acm/)

os.chdir(_repo_root)
os.environ["PYTHONPATH"] = str(_acm_dir / "src") + os.pathsep + str(_acm_dir)

if __name__ == "__main__":
    # Delegate via subprocess so sys.path / cwd are set correctly
    import subprocess
    argv = sys.argv[1:]
    result = subprocess.run(
        [sys.executable, "-m", "scripts.run_swebench_campaign", *argv],
        cwd=str(_repo_root),
        env={**os.environ, "PYTHONPATH": str(_acm_dir / "src") + os.pathsep + str(_acm_dir)},
    )
    raise SystemExit(result.returncode)

