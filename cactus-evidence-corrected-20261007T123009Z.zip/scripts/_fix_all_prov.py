#!/usr/bin/env python3
"""Fix all provenance files in governance_20261004T093000Z with correct paths."""
import json
from pathlib import Path

def fix_provenance_file(prov_path):
    """Fix path references in a single provenance file."""
    try:
        prov = json.loads(prov_path.read_text(encoding='utf-8'))
    except Exception as e:
        print(f"  Error reading {prov_path}: {e}")
        return False
    
    path_mappings = {
        'experiments/derived/final_task_outcomes.csv': 'paper/data/final_task_outcomes.csv',
        'experiments/derived/lite50_v2_runtimeid_20260929T095818Z.json': 'experiments/derived/archived_unreferenced/lite50_v2_runtimeid_20260929T095818Z.json',
        'experiments/derived/result_registry_v2.jsonl': 'experiments/derived/archived_unreferenced/result_registry_v2.jsonl',
    }
    
    updated = False
    for inp in prov.get('inputs', []):
        old_path = inp.get('path', '')
        if old_path in path_mappings:
            new_path = ROOT / path_mappings[old_path]
            if new_path.exists():
                inp['path'] = path_mappings[old_path]
                import hashlib
                inp['sha256'] = hashlib.sha256(new_path.read_bytes()).hexdigest()
                updated = True
    
    if updated:
        prov_path.write_text(json.dumps(prov, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return True
    return False

ROOT = Path('.')
gov_dir = ROOT / 'experiments/derived/governance_20261004T093000Z'

print(f"Checking provenance files in {gov_dir}")
fixed_count = 0
for prov_file in gov_dir.glob('*.provenance.json'):
    if fix_provenance_file(prov_file):
        print(f"  Fixed: {prov_file.name}")
        fixed_count += 1

print(f"\nTotal fixed: {fixed_count}")
