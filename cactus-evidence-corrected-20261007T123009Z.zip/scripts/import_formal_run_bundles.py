"""Import immutable RUNs and derive a separate, auditable retry result registry.

Example (run from acm with PYTHONPATH=src):
    python -m scripts.import_formal_run_bundles --source <archive> \
        --contract-glob 'experiments/contracts/EXP-*.json' \
        --output experiments/derived/<unique-import-id>

The original study/task outcome tables are never updated by this command.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from typing import Any

from cactus.governance.canonical import canonical_json
from cactus.governance.admission import evaluate_admission, source_hash
from cactus.governance.policy import derive_claim_status
from cactus.governance.schema import validate_artifact_provenance, validate_session_authorization
from cactus.registry.store import Registry
from cactus.runner.bundle_validator import validate_bundle
from scripts.aggregate_lite50_results import _valid_evaluator, _valid_patch
from scripts.aggregate_observed_results import aggregate


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files(root: Path) -> dict[str, str]:
    return {p.relative_to(root).as_posix(): sha256(p)
            for p in sorted(root.rglob("*")) if p.is_file()}


def tree_hash(root: Path) -> str:
    return hashlib.sha256(canonical_json(files(root)).encode("utf-8")).hexdigest()


def git(root: Path, *args: str) -> str:
    result = subprocess.run(["git", *args], cwd=root, capture_output=True, check=True)
    return result.stdout.decode("utf-8").strip()


def contracts(root: Path, patterns: list[str]) -> dict[str, tuple[Path, dict[str, Any]]]:
    result = {}
    for pattern in patterns:
        for path in sorted(root.glob(pattern)):
            data = read_json(path)
            identifier = data.get("experiment_id")
            if path.name != f"{identifier}.json":
                continue
            digest = hashlib.sha256(canonical_json(data).encode("utf-8")).hexdigest()
            auth_path = path.with_name(f"{identifier}.session_authorization.json")
            auth = read_json(auth_path)
            errors = validate_session_authorization(auth)
            if errors or auth.get("experiment_id") != identifier or auth.get("contract_sha256") != digest:
                raise ValueError(f"invalid frozen authorization binding: {path.name}: {errors}")
            source_commit = data["source"]["git_commit"]
            git(root, "cat-file", "-e", f"{source_commit}^{{commit}}")
            result[str(identifier)] = path, data
    if not result:
        raise ValueError("no authorized contracts selected")
    return result


def inventory_row(root: Path, run: Path, contract_path: Path, contract: dict[str, Any]) -> dict[str, Any]:
    auth_path = contract_path.with_name(contract_path.stem + ".session_authorization.json")
    decision = evaluate_admission(root, run, contract, authorization=read_json(auth_path))
    if not decision["integrity_passed"]:
        raise ValueError(f"invalid immutable bundle {run.name}: {decision['reasons']}")
    manifest = read_json(run / "run_manifest.json")
    raw = read_json(run / "raw/result.json")
    data, evidence = raw["data"], raw["evidence"]
    billing = read_json(run / "billing/litellm_spend.json")
    reconciliation = billing.get("provider_usage_reconciliation", {})
    evaluator_valid, resolved = decision["evaluator_valid"], decision["resolved"]
    driver_hash, derivation_hash = decision["source_driver_sha256"], decision["source_derivation_sha256"]
    reasons = decision["reasons"]
    return {
        "run_id": run.name, "experiment_id": manifest["experiment_id"],
        "task_id": data["task_id"], "run_path": f"experiments/runs/{run.name}",
        "contract_path": contract_path.relative_to(root).as_posix(),
        "contract_sha256": sha256(contract_path),
        "source_commit": manifest["code"]["commit"],
        "declared_driver_sha256": contract["workload"]["sha256"], "source_driver_sha256": driver_hash,
        "declared_derivation_sha256": contract["derivation"]["sha256"], "source_derivation_sha256": derivation_hash,
        "bundle_tree_sha256": tree_hash(run), "checksums_sha256": sha256(run / "checksums.sha256"),
        "bundle_valid": True, "evaluator_valid": evaluator_valid, "resolved": resolved,
        "billing_status": billing.get("status"), "billing_reconciliation": reconciliation.get("status"),
        "provider_tokens": reconciliation.get("provider_tokens"), "billing_tokens": billing.get("total_tokens"),
        "reported_spend_usd": billing.get("total_spend"),
        "evidence": evidence, "capture_mode": manifest["environment"]["capture_mode"],
        "admitted": not reasons, "exclusion_reasons": reasons,
    }


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    admitted = [r for r in rows if r["admitted"]]
    return {
        "sealed_run_count": len(rows), "bundle_valid_count": len(rows),
        "evaluator_valid_count": sum(r["evaluator_valid"] for r in rows),
        "admitted_run_count": len(admitted), "excluded_run_count": len(rows) - len(admitted),
        "resolved_run_count": sum(r["resolved"] for r in admitted),
        "observed_resolved_run_count": sum(r["resolved"] for r in rows),
        "unique_task_count": len({r["task_id"] for r in rows}),
        "resolved_task_ids": sorted({r["task_id"] for r in admitted if r["resolved"]}),
        "observed_resolved_task_ids": sorted({r["task_id"] for r in rows if r["resolved"]}),
        "exclusion_reason_counts": dict(sorted(Counter(reason for r in rows for reason in r["exclusion_reasons"]).items())),
    }


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")


def import_runs(root: Path, sources: list[Path], patterns: list[str], output: Path) -> dict[str, Any]:
    if output.exists():
        raise FileExistsError(f"refusing to overwrite derived evidence: {output}")
    output.relative_to(root)
    bindings = contracts(root, patterns)
    selected: dict[str, Path] = {}
    for source in sources:
        if not source.is_dir():
            raise FileNotFoundError(source)
        for run in sorted(source.glob("RUN-*")):
            if not (run / "run_manifest.json").is_file():
                continue
            identifier = read_json(run / "run_manifest.json").get("experiment_id")
            if identifier not in bindings:
                continue
            inventory_row(root, run, *bindings[identifier])
            if run.name in selected and tree_hash(selected[run.name]) != tree_hash(run):
                raise ValueError(f"conflicting source copies: {run.name}")
            selected[run.name] = run
    if not selected:
        raise ValueError("no matching sealed RUNs")
    destination = root / "experiments" / "runs"
    destination.mkdir(parents=True, exist_ok=True)
    for name, source in selected.items():
        target = destination / name
        if target.exists() and files(target) != files(source):
            raise FileExistsError(f"refusing to overwrite existing RUN: {name}")
    copied = 0
    for name, source in selected.items():
        target = destination / name
        if not target.exists():
            shutil.copytree(source, target)
            copied += 1
        if files(target) != files(source) or validate_bundle(target):
            raise ValueError(f"imported RUN differs from source: {name}")
    rows = [inventory_row(root, destination / name,
                          *bindings[read_json(destination / name / "run_manifest.json")["experiment_id"]])
            for name in sorted(selected)]
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    summary = {"schema_version": "1.0", "generated_at": generated_at,
               "analysis_scope": "failure_selected_retry_attempts",
               "aggregation_policy": "preserve_each_RUN_and_each_contract; no_primary_table_replacement; no_best_of_retries_estimate",
               "source_branch_commit": git(root, "rev-parse", "HEAD"),
               "copied_run_count": copied, "existing_identical_run_count": len(rows) - copied,
               **summarize(rows), "experiments": {}}
    output.mkdir(parents=True)
    ledger = output / "run_inventory.jsonl"
    ledger.write_text("".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n" for r in rows), encoding="utf-8", newline="\n")
    registry = Registry(output / "result_registry.jsonl")
    for row in rows:
        if not row["admitted"]:
            continue
        record = {
            "schema_version": "2.0", "result_id": "RQ1_RETRY_" + row["run_id"].replace("-", "_"),
            "study_id": "MSCC-LITE50", "metric_id": "resolved", "value": int(row["resolved"]), "unit": "indicator",
            "evidence": {**row["evidence"], "capture_mode": row["capture_mode"]},
            "provenance": {key: row[key] for key in ("run_id", "task_id", "experiment_id", "run_path", "bundle_tree_sha256", "source_commit", "contract_sha256")},
            "qualifier": "Failure-selected retry; descriptive supporting evidence; each RUN retained independently.",
        }
        registry.add(record, requested_status="supporting")
    # Persist an empty registry too when every attempt is excluded.
    if not registry.path.exists():
        registry.path.write_text("", encoding="utf-8")
    for identifier in sorted(bindings):
        group = [r for r in rows if r["experiment_id"] == identifier]
        if not group:
            summary["experiments"][identifier] = {"sealed_run_count": 0}
            continue
        aggregate(Path("experiments/runs"), output / "by_experiment" / identifier, experiment_id=identifier)
        summary["experiments"][identifier] = summarize(group)
    write_json(output / "integration_summary.json", summary)
    inputs = [{"path": row["run_path"], "sha256": row["bundle_tree_sha256"]} for row in rows]
    for artifact in sorted(p for p in output.rglob("*") if p.is_file()):
        payload = {"schema_version": "2.0", "artifact_id": "DATA-RETRY-" + hashlib.sha256(artifact.relative_to(root).as_posix().encode()).hexdigest().upper(),
                   "artifact_type": "derived_dataset", "artifact_path": artifact.relative_to(root).as_posix(),
                   "artifact_sha256": sha256(artifact), "generated_at": generated_at,
                   "generator": {"script": "scripts/import_formal_run_bundles.py", "script_sha256": sha256(Path(__file__)), "source_commit": summary["source_branch_commit"]},
                   "inputs": inputs, "transform": {"scope": summary["analysis_scope"], "admission": "verified_bundle_source_contract_billing_patch_and_official_evaluator"}}
        errors = validate_artifact_provenance(payload)
        if errors:
            raise ValueError(errors)
        write_json(artifact.with_name(artifact.name + ".provenance.json"), payload)
    return summary


def verify(root: Path, output: Path) -> dict[str, Any]:
    from cactus.governance.evidence_locations import resolve_source
    summary = read_json(output / "integration_summary.json")
    rows = [json.loads(line) for line in (output / "run_inventory.jsonl").read_text(encoding="utf-8").splitlines()]
    contracts(root, sorted({r["contract_path"] for r in rows}))
    for row in rows:
        run = resolve_source(root, row["run_path"])
        path = root / row["contract_path"]
        if inventory_row(root, run, path, read_json(path)) != row:
            raise ValueError(f"inventory drift: {row['run_id']}")
    if any(summary[key] != value for key, value in summarize(rows).items()):
        raise ValueError("derived summary drift")
    records = Registry(output / "result_registry.jsonl").read()
    if {r["provenance"]["run_id"] for r in records} != {r["run_id"] for r in rows if r["admitted"]}:
        raise ValueError("registry admission drift")
    if len(records) != sum(r["admitted"] for r in rows) or len({r["result_id"] for r in records}) != len(records):
        raise ValueError("duplicate registry records")
    by_run = {r["run_id"]: r for r in rows}
    schema = read_json(root / "experiments" / "schemas" / "result_record.schema.json")
    for record in records:
        if any(field not in record for field in schema["required"]):
            raise ValueError("missing result schema field")
        if record["schema_version"] != schema["properties"]["schema_version"]["const"]:
            raise ValueError("result schema version mismatch")
        for field in ("result_id", "study_id"):
            if not isinstance(record[field], str) or not re.fullmatch(schema["properties"][field]["pattern"], record[field]):
                raise ValueError(f"invalid result schema identifier: {field}")
        row = by_run[record["provenance"]["run_id"]]
        status, reasons = derive_claim_status(record["evidence"], requested="supporting")
        if (record["value"] != int(row["resolved"]) or record["unit"] != "indicator"
                or record["metric_id"] != "resolved"
                or record["publication"]["claim_status"] != status
                or record["publication"]["policy_reasons"] != reasons
                or record["evidence"] != {**row["evidence"], "capture_mode": row["capture_mode"]}):
            raise ValueError(f"registry evidence/value/policy drift: {row['run_id']}")
    for artifact in sorted(p for p in output.rglob("*") if p.is_file() and not p.name.endswith(".provenance.json")):
        payload = read_json(artifact.with_name(artifact.name + ".provenance.json"))
        if validate_artifact_provenance(payload) or payload["artifact_sha256"] != sha256(artifact):
            raise ValueError(f"artifact provenance mismatch: {artifact.name}")
        generator = payload["generator"]
        if source_hash(root, generator["source_commit"], generator["script"]) != generator["script_sha256"]:
            raise ValueError(f"generator source provenance mismatch: {artifact.name}")
    return {"status": "PASS", **summarize(rows)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", action="append", type=Path, default=[])
    parser.add_argument("--contract-glob", action="append", default=[])
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    root = Path.cwd().resolve()
    output = args.output.resolve()
    if not args.verify and (not args.source or not args.contract_glob):
        parser.error("import requires --source and --contract-glob")
    result = verify(root, output) if args.verify else import_runs(root, [s.resolve() for s in args.source], args.contract_glob, output)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
