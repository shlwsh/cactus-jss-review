#!/usr/bin/env python3
"""Check that empirical manuscript captions carry an evidence-state label."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
STATES = ("Observed:", "Pilot:", "Planned:", "Placeholder:", "Pending:")


def scan(paths: list[Path]) -> dict[str, object]:
    failures: list[dict[str, object]] = []
    caption = re.compile(r"\\caption\{([^}]*)")
    for path in paths:
        if not path.is_file():
            continue
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            match = caption.search(line)
            if match and not match.group(1).lstrip().startswith(STATES):
                failures.append({"file": path.relative_to(ROOT).as_posix(), "line": line_number, "caption": match.group(1).strip()})
    return {"status": "fail" if failures else "pass", "files": [path.relative_to(ROOT).as_posix() for path in paths], "failures": failures}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="*", type=Path, default=[ROOT / "paper" / "main.tex"])
    args = parser.parse_args()
    result = scan([path if path.is_absolute() else ROOT / path for path in args.paths])
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(2 if result["failures"] else 0)
