#!/usr/bin/env python3
"""Fail-closed checks for publication claims and evidence labels."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "paper"
FORBIDDEN = {
    "revision-process wording": re.compile(r"editor feedback|editor response|earlier draft|previous draft|draft redistribution", re.I),
    "stale C1 denominator": re.compile(r"same\s+\\ResultValidTasks\{\}.*(?:matched|C1)|(?:matched|C1).*479\s+(?:evaluator-valid|tasks)", re.I),
    "active legacy comparator": re.compile(r"(?:active|primary|vs\.?|compared? (?:to|with))\s+(?:the\s+)?(?:full[_-]context)(?:\s+(?:baseline|comparator))?", re.I),
}


def audit(main_tex: Path = PAPER / "main.tex", registry_path: Path = PAPER / "claim_registry.yaml") -> dict[str, object]:
    text = main_tex.read_text(encoding="utf-8")
    errors = [f"{label}: {match.group(0)}" for label, pattern in FORBIDDEN.items() for match in pattern.finditer(text)]
    figures = re.findall(r"\\begin\{figure\*?\}.*?\\end\{figure\*?\}", text, flags=re.S)
    for figure in figures:
        if re.search(r"\\caption\{\s*(?:pending|placeholder):", figure, flags=re.I):
            errors.append("placeholder figure caption remains")
    if "VALID\\_BOTH" not in text:
        errors.append("C1 primary denominator VALID_BOTH is not stated in the manuscript")
    if "TELEMETRY\\_BOTH" not in text:
        errors.append("RQ2 telemetry denominator TELEMETRY_BOTH is not stated in the manuscript")
    if "Phase~C0 descriptive" not in text:
        errors.append("C0 observations are not clearly labeled descriptive")
    if "Algorithm retryable" not in text or "Evaluator replayable" not in text:
        errors.append("retryability/replayability distinction is not described in the paper")
    try:
        import yaml

        claims = yaml.safe_load(registry_path.read_text(encoding="utf-8")) or {}
        entries = claims.get("claims", [])
        if not entries:
            errors.append("claim registry is empty")
        for entry in entries:
            if entry.get("id") in {"C1-PRIMARY-EFFICACY", "RQ2-PRIMARY-EFFICIENCY", "PHASE-D-RECOVERY", "RQ4-BUDGET-SENSITIVITY"} and entry.get("status", "").startswith("observed"):
                errors.append(f"future-phase claim {entry['id']} is incorrectly marked observed")
    except (ImportError, OSError, ValueError) as exc:
        errors.append(f"claim registry could not be validated: {exc}")
    return {"status": "pass" if not errors else "fail", "checked": str(main_tex.relative_to(ROOT)), "errors": errors}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = audit()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if args.strict and result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
