"""Build a review-only, inference-safe task manifest from an E6 screen report."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cactus.adapters.benchmark import load_manifest

ROOT = Path(__file__).resolve().parents[1]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _portable_path(path: Path) -> str:
    resolved = path.resolve()
    if resolved.is_relative_to(ROOT):
        return resolved.relative_to(ROOT).as_posix()
    return "external-materialized-benchmark/" + path.name


def build_manifest(
    source_manifest: Path,
    selection_report: Path,
    output: Path,
    *,
    expected_count: int = 10,
) -> tuple[list[str], Path]:
    """Write a selected task subset and provenance without gold fields.

    This materializes a screening candidate only. The report must remain
    explicitly unapproved and every selected task must have a usable test-aware
    treatment according to the base-commit source scan.
    """
    provenance_path = output.with_suffix(output.suffix + ".provenance.json")
    if output.exists() or provenance_path.exists():
        raise FileExistsError(f"refusing to overwrite E6 candidate artifacts: {output}")
    if expected_count < 1:
        raise ValueError("expected_count must be positive")

    report: dict[str, Any] = json.loads(selection_report.read_text(encoding="utf-8"))
    if report.get("gold_patch_fields_read") is not False:
        raise ValueError("selection report does not prove that gold patch fields were excluded")
    if report.get("human_review_required") is not True:
        raise ValueError("E6 selection report must retain the human review gate")
    if report.get("selection_status") != "minimum_eligibility_met" or report.get("base_test_sources_checked") is not True:
        raise ValueError("E6 selection report is not a completed base-test screening")
    if report.get("plan_similarity_status") != "minimum_similarity_met":
        raise ValueError("E6 selection report does not meet the 13033-like cohort similarity threshold")
    if report.get("task_manifest_sha256") != _sha256(source_manifest):
        raise ValueError("selection report is bound to a different inference-safe task manifest")

    selected = report.get("selected")
    if not isinstance(selected, list) or len(selected) != expected_count:
        raise ValueError(f"selection report must contain exactly {expected_count} selected tasks")
    task_ids: list[str] = []
    for row in selected:
        if not isinstance(row, dict) or row.get("screening_only") is not True:
            raise ValueError("selection rows must remain marked screening_only")
        if row.get("test_aware_treatment_available") is not True:
            raise ValueError("every selected E6 task must have test-aware treatment available")
        if row.get("plan_similarity_qualified") is not True:
            raise ValueError("every selected E6 task must match all three plan similarity signals")
        task_id = row.get("task_id")
        if not isinstance(task_id, str) or not task_id:
            raise ValueError("selected task is missing task_id")
        task_ids.append(task_id)
    if len(set(task_ids)) != len(task_ids):
        raise ValueError("selection report contains duplicate task IDs")

    source_rows: dict[str, dict[str, Any]] = {}
    for line_number, line in enumerate(source_manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        row = json.loads(line)
        if not isinstance(row, dict):
            raise ValueError(f"source manifest row {line_number} is not an object")
        if {"patch", "test_patch"} & row.keys():
            raise ValueError(f"gold patch field found in source manifest row {line_number}")
        task_id = row.get("task_id")
        if not isinstance(task_id, str) or task_id in source_rows:
            raise ValueError(f"source manifest task_id is missing or duplicated at row {line_number}")
        source_rows[task_id] = row
    load_manifest(source_manifest)
    missing = [task_id for task_id in task_ids if task_id not in source_rows]
    if missing:
        raise ValueError("selected tasks are missing from the inference-safe manifest: " + ", ".join(missing))

    rows = [source_rows[task_id] for task_id in task_ids]
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows),
        encoding="utf-8",
        newline="\n",
    )
    provenance = {
        "schema_version": 1,
        "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "artifact_type": "e6_screening_candidate_task_manifest",
        "approved_for_execution": False,
        "human_review_required": True,
        "plan_similarity_status": report["plan_similarity_status"],
        "gold_patch_fields_read": False,
        "generator_path": "scripts/build_e6_task_manifest.py",
        "generator_sha256": _sha256(Path(__file__).resolve()),
        "source_task_manifest_path": _portable_path(source_manifest),
        "selection_report_path": _portable_path(selection_report),
        "source_task_manifest_sha256": _sha256(source_manifest),
        "selection_report_sha256": _sha256(selection_report),
        "output_manifest_sha256": _sha256(output),
        "task_count": len(rows),
        "task_ids": task_ids,
    }
    provenance_path.write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return task_ids, provenance_path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", type=Path, required=True, help="Fixed inference-safe task manifest")
    parser.add_argument("--selection", type=Path, required=True, help="E6 screening report")
    parser.add_argument("--output", type=Path, required=True, help="New candidate JSONL destination")
    parser.add_argument("--expected-count", type=int, default=10)
    args = parser.parse_args()
    task_ids, provenance = build_manifest(args.tasks, args.selection, args.output, expected_count=args.expected_count)
    print(json.dumps({"candidate_tasks": len(task_ids), "approved_for_execution": False, "output": str(args.output), "provenance": str(provenance)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
