"""Debug _misleading_exception_template_patch returning None — direct instrumentation."""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

# Load module fresh
spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

import ast

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]

ws = Path(tempfile.mkdtemp(prefix="cactus-diag-dbg3-"))
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)
print(f"repo_path={repo_path}", flush=True)

source = (repo_path / "astropy" / "timeseries" / "core.py").read_text(encoding="utf-8")

# Walk like the function does
issue_text = getattr(task, "issue_text", "") or ""
print(f"issue_type={mod._classify_issue_type(issue_text)}", flush=True)

py_files = sorted(repo_path.rglob("*.py"))
target = None
for py_path in py_files:
    rel = py_path.relative_to(repo_path).as_posix()
    if not rel.endswith("core.py"):
        continue
    raw_bytes = py_path.read_bytes()
    source = raw_bytes.decode("utf-8", errors="replace")
    candidates = mod._find_misleading_raise_nodes(source, rel)
    print(f"candidates in {rel}: {len(candidates)}", flush=True)
    for m, r, fc in candidates:
        print(f"  - method={m.name} raise @ line {r.lineno} fc @ {fc.lineno}:{fc.col_offset}", flush=True)
    target = (rel, source, candidates)
    break

if target is None:
    print("no target", flush=True)
    sys.exit(1)

rel, source, candidates = target

# Score and pick best candidate like the function does
def _candidate_score(candidate):
    _method, _raise_node, _format_call = candidate
    idx0_count = sum(
        1 for a in _format_call.args
        if isinstance(a, ast.Subscript)
        and isinstance(a.slice, ast.Constant)
        and a.slice.value == 0
    )
    has_fmt_str = any(
        isinstance(a, ast.Constant) and isinstance(a.value, str) and "{}" in a.value
        for a in _format_call.args
    )
    return idx0_count * 10 + (1 if has_fmt_str else 0)

candidates = sorted(candidates, key=_candidate_score, reverse=True)
print(f"sorted candidates:", flush=True)
for m, r, fc in candidates:
    print(f"  - raise @ {r.lineno} score={_candidate_score((m, r, fc))}", flush=True)

for method, raise_node, format_call in candidates:
    fresh_tree = ast.parse(source)
    class_name = None
    method_id = (method.lineno, int(getattr(method, "end_lineno", method.lineno)))
    for cls in ast.walk(fresh_tree):
        if not isinstance(cls, ast.ClassDef): continue
        for child in ast.iter_child_nodes(cls):
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)): continue
            child_id = (child.lineno, int(getattr(child, "end_lineno", child.lineno)))
            if child_id == method_id and child.name == method.name:
                class_name = cls.name
                break
        if class_name: break
    symbol = f"{class_name}.{method.name}" if class_name else method.name
    print(f"\n[try] symbol={symbol} raise @ {raise_node.lineno}", flush=True)

    helper_edit = mod._build_template_edit_for_helper_insert(source, method, "as_scalar_or_list_str")
    if helper_edit is None:
        print(f"  helper_edit returned None", flush=True)
        continue
    raise_edit = mod._build_template_edit_for_raise(source, method, raise_node, format_call)
    if raise_edit is None:
        print(f"  raise_edit returned None", flush=True)
        continue
    print(f"  helper_edit old_st: {helper_edit['old_statement']!r}", flush=True)
    print(f"  raise_edit old_st: {raise_edit['old_statement']!r}", flush=True)
    print(f"  raise_edit repl: {raise_edit['replacement']!r}", flush=True)
    break

import shutil
shutil.rmtree(ws, ignore_errors=True)
