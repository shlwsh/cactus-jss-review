"""Run remaining 50-task prediction with corrected config (prediction_max_attempts=3).

Re-run only tasks that FAILED in the first attempt.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"

# Tasks that need re-running (failed in first pass with max_attempts=5)
RETRY_TASKS = [
    "django__django-11099",
    "django__django-11133",
    "django__django-11179",
    "django__django-11283",
    "django__django-11422",
    "django__django-11564",
    "django__django-11583",
    "django__django-11620",
    "django__django-11630",
    "django__django-11742",
    "django__django-11797",
    "django__django-11815",
    "django__django-11848",
    "django__django-11905",
    "django__django-11910",
    "django__django-11964",
    "django__django-11999",
    "django__django-12113",
    "django__django-12125",
    "django__django-12184",
    "django__django-12284",
    "django__django-12286",
    "django__django-12308",
    "django__django-12453",
    "django__django-12470",
    "django__django-12497",
    "django__django-12589",
    "django__django-12700",
    "django__django-12708",
    "django__django-12747",
    "django__django-12856",
    "django__django-12908",
    "django__django-12915",
    "django__django-12983",
    "django__django-13028",
    "django__django-13033",
    "django__django-13158",
    "django__django-13220",
]

# Tasks already confirmed PASS in first pass
ALREADY_PASS = {
    "astropy__astropy-12907",
    "astropy__astropy-14182",
    "astropy__astropy-14365",
    "astropy__astropy-14995",
    "astropy__astropy-6938",
    "astropy__astropy-7746",
    "django__django-10914",
    "django__django-10924",
    "django__django-11001",
    "django__django-11019",
    "django__django-11039",
    "django__django-11049",
}


def run_one(task_id: str, validation_id: str, variant: str, dry_run: bool, verbose: bool) -> dict:
    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_single_task_predict.py"),
        "--task-id", task_id,
        "--validation-id", validation_id,
        "--variant", variant,
    ]
    started = datetime.utcnow().isoformat() + "Z"
    if dry_run:
        print(f"DRY-RUN: {' '.join(cmd)}")
        return {"task_id": task_id, "status": "dry", "cmd": cmd}
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(PROJECT_ROOT),
            capture_output=True,
            text=True,
            timeout=900,
        )
        stdout = proc.stdout
        stderr = proc.stderr
        rc = proc.returncode
        passed = "PASS prediction written" in stdout
        failed = "FAIL:" in stderr or "FAIL:" in stdout
        result = {
            "task_id": task_id,
            "status": "PASS" if passed else ("FAIL" if failed else "UNKNOWN"),
            "returncode": rc,
            "started": started,
            "finished": datetime.utcnow().isoformat() + "Z",
        }
        if verbose or not passed:
            print(f"[{'PASS' if passed else 'FAIL'}] {task_id}")
            if stderr:
                for line in stderr.strip().split("\n")[-3:]:
                    print(f"  STDERR: {line}")
        return result
    except subprocess.TimeoutExpired:
        return {
            "task_id": task_id,
            "status": "TIMEOUT",
            "timeout_sec": 900,
            "started": started,
            "finished": datetime.utcnow().isoformat() + "Z",
        }
    except Exception as e:
        return {
            "task_id": task_id,
            "status": "ERROR",
            "error": str(e),
            "traceback": traceback.format_exc(),
            "started": started,
            "finished": datetime.utcnow().isoformat() + "Z",
        }


def main():
    parser = argparse.ArgumentParser(description="Run remaining 50-task prediction with fixed config")
    parser.add_argument("--validation-id", required=True, help="Validation run ID")
    parser.add_argument("--variant", default="cactus_full", help="Variant name")
    parser.add_argument("--dry-run", action="store_true", help="Print commands only")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    args = parser.parse_args()

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

    results = []
    for task_id in RETRY_TASKS:
        print(f"Running: {task_id}...")
        result = run_one(task_id, args.validation_id, args.variant, args.dry_run, args.verbose)
        results.append(result)
        print(f"{result['status']}: {task_id}")

    # Summary
    passed = [r for r in results if r["status"] == "PASS"]
    failed = [r for r in results if r["status"] == "FAIL"]
    print()
    print("=" * 60)
    print(f"Retried: {len(results)} tasks")
    print(f"PASS:  {len(passed)}")
    print(f"FAIL:  {len(failed)}")
    if failed:
        print("Failed tasks:")
        for r in failed:
            print(f"  - {r['task_id']}")

    # Save results
    out_path = RUNS_DIR / f"_full50_retry_{ts}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({
            "validation_id": args.validation_id,
            "timestamp": ts,
            "summary": {
                "total": len(results),
                "passed": len(passed),
                "failed": len(failed),
            },
            "already_pass": sorted(ALREADY_PASS),
            "results": results,
        }, f, indent=2, ensure_ascii=False)
    print(f"\nResults saved to: {out_path}")


if __name__ == "__main__":
    main()
