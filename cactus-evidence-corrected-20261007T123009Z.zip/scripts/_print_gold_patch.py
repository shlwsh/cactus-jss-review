from datasets import load_dataset
import sys
ds = load_dataset('princeton-nlp/SWE-bench_Verified', split='test')
target = sys.argv[1] if len(sys.argv) > 1 else 'django__django-11910'
for x in ds:
    if x['instance_id'] == target:
        print('===', x['instance_id'], '===')
        print(x['patch'])
        break
else:
    print('NOT FOUND')
