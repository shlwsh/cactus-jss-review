"""Windows-safe local SWE-bench evaluation wrapper.

SWE-bench 5.x writes its in-container ``eval.sh`` through ``Path.write_text``.
On Windows that defaults to CRLF, which Bash interprets as malformed commands.
This wrapper scopes an LF-only patch to the official harness invocation without
modifying the installed third-party package.
"""

from __future__ import annotations

import argparse
import re
import os
import shutil
from pathlib import Path


def pin_test_spec_images(evaluation_module, *, instance_ids: list[str], image_ref: str, image_id: str | None = None) -> None:
    """Use the contract-pinned digest or its manifest-verified local image ID."""
    if len(instance_ids) != 1 or not re.fullmatch(r"[^\s@]+@sha256:[0-9a-f]{64}", image_ref):
        raise ValueError("pinned evaluation requires one instance and a repository@sha256 image reference")
    if image_id is not None and not re.fullmatch(r"sha256:[0-9a-f]{64}", image_id):
        raise ValueError("pinned local image id must be a complete sha256 identifier")
    original = evaluation_module.make_test_spec

    def make_pinned_test_spec(instance):
        spec = original(instance)
        if spec.instance_id == instance_ids[0]:
            spec.image = image_id or image_ref
        return spec

    evaluation_module.make_test_spec = make_pinned_test_spec


def install_lf_write_text() -> None:
    original = Path.write_text

    def write_text_lf(self: Path, data: str, encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> int:
        return original(self, data, encoding=encoding, errors=errors, newline="\n" if newline is None else newline)

    Path.write_text = write_text_lf  # type: ignore[method-assign]


def configure_docker_cli(explicit: str | None = None) -> str:
    """Make the Docker CLI visible to SWE-bench's subprocess cleanup code."""
    candidates = [explicit, os.environ.get("CACTUS_DOCKER_BIN"), shutil.which("docker")]
    if os.name == "nt":
        candidates.extend([
            r"D:\Docker Desktop\resources\bin\docker.exe",
            r"C:\Program Files\Docker\Docker\resources\bin\docker.exe",
        ])
    for candidate in candidates:
        if not candidate:
            continue
        resolved = Path(candidate).resolve()
        if resolved.is_file():
            os.environ["PATH"] = str(resolved.parent) + os.pathsep + os.environ.get("PATH", "")
            return str(resolved)
    raise RuntimeError("Docker CLI not found; set CACTUS_DOCKER_BIN to docker.exe")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset")
    parser.add_argument("--gold", action="store_true")
    parser.add_argument("--predictions")
    parser.add_argument("--instance", action="append", dest="instances")
    parser.add_argument("--pinned-image", help="Contract-pinned repository@sha256 digest; never pull a mutable tag")
    parser.add_argument("--pinned-image-id", help="Local image ID already verified against the read-only cache manifest")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--report-dir", required=True)
    parser.add_argument("--task-repo")
    parser.add_argument("--docker-bin")
    args = parser.parse_args()
    if args.gold == bool(args.predictions):
        raise SystemExit("supply exactly one of --gold or --predictions")
    if args.pinned_image and (not args.instances or len(args.instances) != 1):
        raise SystemExit("--pinned-image requires exactly one --instance")
    configure_docker_cli(args.docker_bin)
    install_lf_write_text()
    from swebench.harness import run_evaluation
    if args.pinned_image:
        pin_test_spec_images(run_evaluation, instance_ids=args.instances, image_ref=args.pinned_image, image_id=args.pinned_image_id)
    evaluate = run_evaluation.main
    evaluate(
        dataset_name=args.dataset,
        split="test",
        instance_ids=args.instances,
        predictions_path="gold" if args.gold else args.predictions,
        max_workers=args.workers,
        open_file_limit=4096,
        run_id=args.run_id,
        timeout=args.timeout,
        rewrite_reports=False,
        modal=False,
        report_dir=args.report_dir,
        task_repo=args.task_repo,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
