"""Check the Phase C Pilot Gate from sealed RUN bundles, without execution."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from cactus.evaluation.phase_gate import evaluate_pilot


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, default=Path("experiments/runs"))
    parser.add_argument("--expected-task-count", type=int, required=True)
    parser.add_argument("--experiment-id")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    summary = evaluate_pilot(args.runs, expected_task_count=args.expected_task_count, experiment_id=args.experiment_id).as_dict()
    payload = json.dumps(summary, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0 if summary["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
