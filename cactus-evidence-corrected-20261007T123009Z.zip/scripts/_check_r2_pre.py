import glob
import json

from cactus.governance.schema import validate_environment_snapshot

files = sorted(glob.glob("experiments/snapshots/C1-pre-r2-*_pending_dacl.json"))
p = files[-1] if files else None
if not p:
    print("no snapshot found")
    raise SystemExit(2)
print("checking:", p)
data = json.loads(open(p, "rb").read())
errors = validate_environment_snapshot(data)
print("errors =", errors)
print("schema_version =", data.get("schema_version"))
print("capture_mode =", data.get("capture_mode"))
print("generated_at =", data.get("generated_at"))
print("dacl_status (extra) =", data.get("extra", {}).get("dacl_status"))
print("read_only per root:")
for k, v in (data.get("data_roots") or {}).items():
    print(f"  {k}: read_only={v.get('read_only')} readable={v.get('readable')}")
print("session_variable_presence:")
for k, v in (data.get("session_variable_presence") or {}).items():
    print(f"  {k}: {v} (type={type(v).__name__})")