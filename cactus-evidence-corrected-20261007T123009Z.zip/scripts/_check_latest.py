"""Quick check of latest prediction output."""
import json
from pathlib import Path

run_dir = Path("E:/work/p5-acm/acm/experiments/runs")

# Find all R4 verify runs sorted by mtime
out = sorted(
    [d for d in run_dir.iterdir() if d.is_dir() and d.name.startswith("r4_verify")],
    key=lambda d: d.stat().st_mtime,
    reverse=True,
)
if not out:
    print("No output dirs found")
    exit(1)

latest = out[0]
print(f"Output: {latest.name}")
print(f"Modified: {latest.stat().st_mtime}")

trace = latest / "trace.jsonl"
stderr = latest / "predict.stderr.log"
stdout = latest / "predict.stdout.log"

if trace.exists():
    events = []
    with open(trace) as f:
        for line in f:
            if line.strip() and not line.startswith("#"):
                try:
                    events.append(json.loads(line))
                except Exception:
                    pass
    print(f"Events: {len(events)}")

    for e in events:
        name = e.get("event", e.get("type", ""))
        p = e.get("payload", {})
        if name == "symbol_propagation_anchors":
            total = p.get("total_propagated", 0)
            prefixes = p.get("module_prefixes", [])[:2]
            anchors = p.get("import_module_anchors", [])
            print(f"  [propagation] total={total} prefixes={prefixes}")
            print(f"    import_module_anchors count: {len(anchors)}")
        if name == "context_candidates_pruned":
            print(f"  [pruned] candidates={p.get('candidate_units')} protected={p.get('protected_units')} literals={p.get('literal_anchor_units')}")
        if name == "context_selected":
            sel = p.get("selected", [])
            count = len(sel) if isinstance(sel, list) else "?"
            print(f"  [selected] status={p.get('status')} count={count} tokens={p.get('tokens')}")
        if name == "context_summary":
            print(f"  [summary] selected_tokens={p.get('selected_context_tokens')} files={p.get('selected_file_count')}")

if stderr.exists():
    text = stderr.read_text(encoding="utf-8", errors="replace")
    lines = [l for l in text.split("\n") if l.strip()]
    print(f"\nstderr: {len(lines)} lines, {stderr.stat().st_size} bytes")
    if lines:
        tail = lines[-1][:150]
        print(f"  tail: {tail}")

if stdout.exists():
    text = stdout.read_text(encoding="utf-8", errors="replace")
    lines = [l for l in text.split("\n") if l.strip()]
    print(f"\nstdout: {len(lines)} lines")
    if lines:
        tail = lines[-1][:150]
        print(f"  tail: {tail}")
