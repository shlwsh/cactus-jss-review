"""Debug _misleading_exception_template_patch returning None — full walk."""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

import ast
import subprocess

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]

ws = Path(tempfile.mkdtemp(prefix="cactus-diag-dbg-"))
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)

# Monkey-patch _statement_edit_to_patch to print errors loudly
orig_se = mod._statement_edit_to_patch
def loud_se(*args, **kwargs):
    try:
        return orig_se(*args, **kwargs)
    except Exception as e:
        print(f"[LOUD] _statement_edit_to_patch raised: {type(e).__name__}: {e}", flush=True)
        raise
mod._statement_edit_to_patch = loud_se

# Monkey-patch subprocess.run to catch apply errors
import subprocess as sp
orig_run = sp.run
def loud_run(*args, **kwargs):
    res = orig_run(*args, **kwargs)
    if "apply" in str(args):
        if res.returncode != 0:
            stderr = (res.stderr or b"" if isinstance(res.stderr, (bytes, bytearray)) else res.stderr)
            stdout = (res.stdout or b"" if isinstance(res.stdout, (bytes, bytearray)) else res.stdout)
            print(f"[LOUD] apply failed rc={res.returncode}", flush=True)
            print(f"  args={args[:2]}", flush=True)
            print(f"  stderr={stderr!r}", flush=True)
            print(f"  stdout={stdout!r}", flush=True)
    return res
sp.run = loud_run

try:
    result = mod._misleading_exception_template_patch(task, repo_path)
finally:
    sp.run = orig_run
    mod._statement_edit_to_patch = orig_se

print(f"\nFINAL: result is None: {result is None}", flush=True)

import shutil
shutil.rmtree(ws, ignore_errors=True)
