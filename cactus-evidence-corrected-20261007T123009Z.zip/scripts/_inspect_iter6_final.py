"""查 ITER6 final 11910 / 12125 摘要"""
import json
import os

for task in ['django__django-11910', 'django__django-12125']:
    tid = task.split('django-')[1]
    p = f'experiments/runs/ITER6-{tid}/{task}/events.jsonl'
    with open(p, encoding='utf-8') as f:
        events = [json.loads(l) for l in f]
    print(f'{task}: events={len(events)} model_calls={sum(1 for e in events if e.get("type") == "model_call")}')
    for e in events:
        if e.get('type') in ('prediction_sites_rejected', 'prediction_rejected'):
            p2 = e.get('payload', {})
            print(f'  [{e.get("type")}] attempt={p2.get("attempt")} reason={p2.get("reason", "")[:140]}')
    print()