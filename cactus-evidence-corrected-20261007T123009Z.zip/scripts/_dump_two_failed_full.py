"""详查 11910 / 12125 在 POSTFIX 与 ITER1-3 中的失败模式"""

import json
import sys


def load_events(path):
    try:
        with open(path, encoding='utf-8') as f:
            return [json.loads(l) for l in f]
    except FileNotFoundError:
        return None


def summarize(label, events):
    if events is None:
        print(f'\n==== {label}: NO FILE ====')
        return
    print(f'\n==== {label} ({len(events)} events) ====')
    # 站点选择尝试
    site_attempts = []
    rep_attempts = []
    for e in events:
        t = e.get('type', '')
        p = e.get('payload', {})
        if t == 'prediction_sites_rejected':
            site_attempts.append({
                'attempt': p.get('attempt'),
                'stage': p.get('stage'),
                'reason': p.get('reason', '')[:150],
                'site_ids': p.get('site_ids'),
                'excluded_count': len(p.get('excluded_site_ids', [])),
            })
        elif t == 'prediction_rejected':
            rep_attempts.append({
                'attempt': p.get('attempt'),
                'reason': p.get('reason', '')[:200],
                'site_ids': p.get('site_ids'),
            })
    print(f'  Site rejections ({len(site_attempts)}):')
    for a in site_attempts:
        print(f'    attempt={a["attempt"]} stage={a["stage"]} excl={a["excluded_count"]}')
        print(f'      reason: {a["reason"]}')
    print(f'  Replacement rejections ({len(rep_attempts)}):')
    for a in rep_attempts:
        print(f'    attempt={a["attempt"]}')
        print(f'      reason: {a["reason"]}')


tasks = ['django__django-11910', 'django__django-12125']
tid_map = {'django__django-11910': '11910', 'django__django-12125': '12125'}
for task in tasks:
    tid = tid_map[task]
    print(f'\n###### {task} ######')
    summarize('POSTFIX3',
              load_events(f'experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/{task}/events.jsonl'))
    summarize('ITER2',
              load_events(f'experiments/runs/ITER2-{tid}-20261004T064000Z/{task}/events.jsonl') if tid in {'11910','12125'} else None)
    summarize('ITER3',
              load_events(f'experiments/runs/ITER3-{tid}-20261004T065000Z/{task}/events.jsonl') if tid in {'11910','12125'} else None)
    summarize('ITER4',
              load_events(f'experiments/runs/ITER4-{tid}/{task}/events.jsonl') if tid in {'11910','12125'} else None)