import json
import hashlib

# Update bibliography sidecar with current file hashes
sidecar = json.loads(open('paper/data/publication_bibliography.bbl.provenance.json').read())
for inp in sidecar.get('inputs', []):
    path = inp['path']
    actual_sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
    old = inp['sha256']
    if old != actual_sha:
        print(f'Updating {path}: {old[:16]}... -> {actual_sha[:16]}...')
        inp['sha256'] = actual_sha
    else:
        print(f'OK {path}')
open('paper/data/publication_bibliography.bbl.provenance.json', 'w').write(json.dumps(sidecar, ensure_ascii=False, indent=2) + '\n')
print('Bibliography sidecar updated')

# Update data_macros.tex sidecar with current file hashes
macro_prov = json.loads(open('paper/data/publication_values.json.provenance.json').read())
# Regenerate data_macros.tex provenance - check all inputs
for inp in macro_prov.get('inputs', []):
    path = inp['path']
    if path.startswith('paper/'):
        actual_sha = hashlib.sha256(open(path, 'rb').read()).hexdigest()
        old = inp.get('sha256', '')
        if old != actual_sha:
            print(f'Updating macro provenance {path}: {old[:16]}... -> {actual_sha[:16]}...')
            inp['sha256'] = actual_sha
        else:
            print(f'OK {path}')
open('paper/data/publication_values.json.provenance.json', 'w').write(json.dumps(macro_prov, ensure_ascii=False, indent=2) + '\n')
print('Macro provenance updated')
