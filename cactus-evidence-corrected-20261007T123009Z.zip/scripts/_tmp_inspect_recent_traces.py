"""Inspect trace events for the most recent RUN bundles to surface root causes."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

RUN_IDS = [
    "RUN-20260925T151508Z-61804F9C",
    "RUN-20260925T150647Z-A7EF3A9C",
    "RUN-20260925T150150Z-59917EE5",
    "RUN-20260925T134813Z-F670684D",
    "RUN-20260925T131154Z-8F5F3923",
    "RUN-20260925T124946Z-31DC4349",
    "RUN-20260925T120939Z-9F868CEF",
]


def main() -> int:
    for rid in RUN_IDS:
        p = ROOT / f"experiments/runs/{rid}/trace/events.jsonl"
        if not p.exists():
            print(f"{rid}: NO EVENTS")
            continue
        events = [
            json.loads(line)
            for line in p.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        types: dict[str, int] = {}
        for e in events:
            types[e.get("type", "?")] = types.get(e.get("type", "?"), 0) + 1
        print(f"=== {rid} | total={len(events)} | types={types}")
        for e in events:
            t = e.get("type", "?")
            if t == "model_call":
                pl = e.get("payload", {}) or {}
                fr = pl.get("finish_reason")
                it = pl.get("input_tokens")
                ot = pl.get("output_tokens")
                rc = len(pl.get("response_text") or "")
                print(
                    f"  model_call: finish={fr} in={it} out={ot} resp_chars={rc}"
                )
                rt = pl.get("response_text") or ""
                if rt:
                    print(f"    RESP[0:300]: {rt[:300]!r}")
            elif t == "prediction_rejected":
                pl = e.get("payload", {}) or {}
                reason = (pl.get("reason") or "")[:200]
                print(
                    f"  prediction_rejected: class={pl.get('reason_class')} reason={reason}"
                )
            elif t == "observe":
                pl = e.get("payload", {}) or {}
                turn = pl.get("turn_id", "")
                print(
                    f"  observe: turn={turn[:60]} usage={pl.get('usage')} finish={pl.get('finish_reason')}"
                )
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
