"""Run remaining Lite50 prediction with fully reverted stable config.

Config: temperature=0.0, prediction_max_attempts=3, self_correction.max_attempts=3.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"

# All 50 tasks
ALL_TASKS = [
    "astropy__astropy-12907",
    "astropy__astropy-14182",
    "astropy__astropy-14365",
    "astropy__astropy-14995",
    "astropy__astropy-6938",
    "astropy__astropy-7746",
    "django__django-10914",
    "django__django-10924",
    "django__django-11001",
    "django__django-11019",
    "django__django-11039",
    "django__django-11049",
    "django__django-11099",
    "django__django-11133",
    "django__django-11179",
    "django__django-11283",
    "django__django-11422",
    "django__django-11564",
    "django__django-11583",
    "django__django-11620",
    "django__django-11630",
    "django__django-11742",
    "django__django-11797",
    "django__django-11815",
    "django__django-11848",
    "django__django-11905",
    "django__django-11910",
    "django__django-11964",
    "django__django-11999",
    "django__django-12113",
    "django__django-12125",
    "django__django-12184",
    "django__django-12284",
    "django__django-12286",
    "django__django-12308",
    "django__django-12453",
    "django__django-12470",
    "django__django-12497",
    "django__django-12589",
    "django__django-12700",
    "django__django-12708",
    "django__django-12747",
    "django__django-12856",
    "django__django-12908",
    "django__django-12915",
    "django__django-12983",
    "django__django-13028",
    "django__django-13033",
    "django__django-13158",
    "django__django-13220",
]


def check_status(task_id: str, run_dir: Path) -> str | None:
    """Check if task already has a PASS prediction. Returns status or None if not done."""
    log_path = run_dir / "predict.log"
    pred_path = run_dir / "prediction.jsonl"
    if log_path.exists():
        content = log_path.read_text(encoding="utf-8", errors="replace")
        if "PASS prediction written" in content:
            return "PASS"
        if "FAIL:" in content:
            return "FAIL"
        if pred_path.exists():
            return "OK"
    return None


def run_one(task_id: str, validation_id: str, variant: str, dry_run: bool, verbose: bool) -> dict:
    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_single_task_predict.py"),
        "--task-id", task_id,
        "--validation-id", validation_id,
        "--variant", variant,
    ]
    started = datetime.utcnow().isoformat() + "Z"
    if dry_run:
        print(f"DRY-RUN: {' '.join(cmd)}")
        return {"task_id": task_id, "status": "dry", "cmd": cmd}
    try:
        proc = subprocess.run(
            cmd, cwd=str(PROJECT_ROOT), capture_output=True, text=True, timeout=900,
        )
        stdout = proc.stdout
        stderr = proc.stderr
        passed = "PASS prediction written" in stdout
        failed = "FAIL:" in stderr or "FAIL:" in stdout
        result = {
            "task_id": task_id,
            "status": "PASS" if passed else ("FAIL" if failed else "UNKNOWN"),
            "returncode": proc.returncode,
            "started": started,
            "finished": datetime.utcnow().isoformat() + "Z",
        }
        if verbose or not passed:
            print(f"[{'PASS' if passed else 'FAIL'}] {task_id}")
            if stderr:
                for line in stderr.strip().split("\n")[-3:]:
                    print(f"  STDERR: {line}")
        return result
    except subprocess.TimeoutExpired:
        return {"task_id": task_id, "status": "TIMEOUT", "started": started, "finished": datetime.utcnow().isoformat() + "Z"}
    except Exception as e:
        return {"task_id": task_id, "status": "ERROR", "error": str(e), "started": started, "finished": datetime.utcnow().isoformat() + "Z"}


def main():
    parser = argparse.ArgumentParser(description="Run Lite50 with stable config")
    parser.add_argument("--validation-id", required=True)
    parser.add_argument("--variant", default="cactus_full")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--resume-dir", default=None, help="Check existing results from this dir")
    args = parser.parse_args()

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    base_dir = RUNS_DIR / args.validation_id
    base_dir.mkdir(parents=True, exist_ok=True)

    # Check existing results if resume-dir specified
    skip_status = {}
    if args.resume_dir:
        resume_path = Path(args.resume_dir)
        for task_id in ALL_TASKS:
            status = check_status(task_id, resume_path / task_id)
            if status:
                skip_status[task_id] = status
                print(f"SKIP {task_id}: {status} (from resume)")

    results = []
    for task_id in ALL_TASKS:
        if task_id in skip_status:
            continue
        print(f"Running: {task_id}...")
        result = run_one(task_id, args.validation_id, args.variant, args.dry_run, args.verbose)
        results.append(result)
        print(f"  => {result['status']}")

    # Summary
    passed = [r for r in results if r["status"] == "PASS"]
    failed = [r for r in results if r["status"] == "FAIL"]
    already_pass = {k: v for k, v in skip_status.items() if v == "PASS"}
    already_fail = {k: v for k, v in skip_status.items() if v in ("FAIL", "OK")}

    print()
    print("=" * 60)
    print(f"Total: {len(results) + len(skip_status)} tasks")
    print(f"Already PASS: {len(already_pass)}")
    print(f"Already FAIL/OK: {len(already_fail)}")
    print(f"Ran PASS: {len(passed)}")
    print(f"Ran FAIL: {len(failed)}")
    total_pass = len(already_pass) + len(passed)
    print(f"Total PASS: {total_pass}/{len(ALL_TASKS)}")
    if failed:
        print("Failed tasks:")
        for r in failed:
            print(f"  - {r['task_id']}")

    # Save
    out_path = RUNS_DIR / f"_full50_stable_{ts}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({
            "validation_id": args.validation_id,
            "timestamp": ts,
            "total": len(ALL_TASKS),
            "already_pass": already_pass,
            "already_fail": already_fail,
            "ran_pass": [r["task_id"] for r in passed],
            "ran_fail": [r for r in results if r["status"] == "FAIL"],
            "summary": {
                "total_pass": len(already_pass) + len(passed),
                "total_fail": len(failed),
            }
        }, f, indent=2, ensure_ascii=False)
    print(f"\nResults: {out_path}")


if __name__ == "__main__":
    main()
