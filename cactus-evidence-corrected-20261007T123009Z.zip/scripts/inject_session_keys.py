"""inject_session_keys.py — Python port of docs/llm/mykey.ts.

Reads docs/llm/.env, resolves the 7 required CACTUS session variables with
their fallback chains, and spawns a child command with those env vars set.

Mirrors mykey.ts exactly so a Bun-less workstation can launch the campaign.

Required session keys:
  CACTUS_LITELLM_API_KEY               <- .env LITELLM_API_KEY
  CACTUS_LITELLM_BILLING_API_KEY       <- .env CACTUS_LITELLM_BILLING_API_KEY
  CACTUS_LITELLM_LOG_KEY_ALIAS         <- .env CACTUS_LITELLM_BILLING_KEY_ALIAS
  CACTUS_LITELLM_BILLING_KEY_ALIAS     <- .env CACTUS_LITELLM_LOG_KEY_ALIAS
  CACTUS_LITELLM_BILLING_SSH_HOST      <- .env NODE0_MGMT_IP / WINBOT_IP
  CACTUS_LITELLM_BILLING_SSH_USER      <- .env SSH_NODE0_USER / SSH_OPS_USER / WINBOT_USER
  CACTUS_LITELLM_BILLING_SSH_PASSWORD  <- .env SSH_NODE0_PASS / WINBOT_PASS

Resolution priority per key:
  1) existing process.env (PowerShell override)
  2) canonical .env key
  3) fallback chain (matches mykey.ts SOURCE_KEY_FALLBACKS byte-for-byte)

Usage:
  & .\\.venv\\Scripts\\python.exe scripts\\inject_session_keys.py -- <cmd> [args...]
  & .\\.venv\\Scripts\\python.exe scripts\\inject_session_keys.py --check
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
ENV_FILE_CANDIDATES = [
    ROOT / "docs" / "llm" / ".env",
    ROOT / "docs" / "llm" / "scripts" / ".env",
]


REQUIRED_KEYS = (
    "CACTUS_LITELLM_API_KEY",
    "CACTUS_LITELLM_BILLING_API_KEY",
    "CACTUS_LITELLM_LOG_KEY_ALIAS",
    "CACTUS_LITELLM_BILLING_KEY_ALIAS",
    "CACTUS_LITELLM_BILLING_SSH_HOST",
    "CACTUS_LITELLM_BILLING_SSH_USER",
    "CACTUS_LITELLM_BILLING_SSH_PASSWORD",
)

SOURCE_KEY_FALLBACKS: dict[str, tuple[str, ...]] = {
    "CACTUS_LITELLM_API_KEY": ("LITELLM_API_KEY",),
    "CACTUS_LITELLM_BILLING_API_KEY": (),
    "CACTUS_LITELLM_LOG_KEY_ALIAS": ("CACTUS_LITELLM_BILLING_KEY_ALIAS",),
    "CACTUS_LITELLM_BILLING_KEY_ALIAS": ("CACTUS_LITELLM_LOG_KEY_ALIAS",),
    "CACTUS_LITELLM_BILLING_SSH_HOST": ("NODE0_MGMT_IP", "WINBOT_IP"),
    "CACTUS_LITELLM_BILLING_SSH_USER": ("SSH_NODE0_USER", "SSH_OPS_USER", "WINBOT_USER"),
    "CACTUS_LITELLM_BILLING_SSH_PASSWORD": ("SSH_NODE0_PASS", "WINBOT_PASS"),
}


def parse_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    text = path.read_text(encoding="utf-8")
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        body = line[7:].strip() if line.startswith("export ") else line
        eq = body.find("=")
        if eq <= 0:
            continue
        key = body[:eq].strip()
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", key):
            continue
        val = body[eq + 1:].strip()
        if len(val) >= 2 and ((val[0] == '"' and val[-1] == '"') or (val[0] == "'" and val[-1] == "'")):
            val = val[1:-1]
        else:
            # strip inline comment (whitespace + #)
            ci = re.search(r"\s+#", val)
            if ci is not None:
                val = val[:ci.start()].rstrip()
        values[key] = val
    return values


def find_env_file() -> Path:
    for c in ENV_FILE_CANDIDATES:
        if c.exists():
            return c
    raise FileNotFoundError(f"No .env found at any of: {ENV_FILE_CANDIDATES}")


def load_resolved() -> tuple[Path, dict[str, dict[str, str]]]:
    env_path = find_env_file()
    parsed = parse_env_file(env_path)
    out: dict[str, dict[str, str]] = {}
    for k in REQUIRED_KEYS:
        if os.environ.get(k):
            out[k] = {"value": os.environ[k], "source": "PowerShell"}
            continue
        if parsed.get(k):
            out[k] = {"value": parsed[k], "source": ".env"}
            continue
        for alias in SOURCE_KEY_FALLBACKS[k]:
            if parsed.get(alias):
                out[k] = {"value": parsed[alias], "source": ".env 别名"}
                break
    missing = [k for k in REQUIRED_KEYS if k not in out]
    if missing:
        raise RuntimeError(f"密钥配置缺失或为空: {', '.join(missing)}")
    return env_path, out


def resolve_command(cmd: str) -> str:
    if "/" in cmd or "\\" in cmd or os.sep in cmd:
        return cmd
    if re.search(r"\.[A-Za-z0-9]+$", cmd):
        return cmd
    path_env = os.environ.get("PATH", "")
    exts = [e for e in os.environ.get("PATHEXT", ".EXE;.CMD;.BAT;.COM").split(";") if e]
    for d in path_env.split(os.pathsep):
        if not d:
            continue
        for e in exts:
            cand = Path(d) / (cmd + e)
            if cand.exists():
                return str(cand)
    # fall back to shutil.which (covers PATH lookups we might miss)
    w = shutil.which(cmd)
    return w or cmd


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="Just print resolved vars and exit.")
    ap.add_argument("argv", nargs="*", help="Command to run after `--`.")
    args = ap.parse_args()

    env_path, resolved = load_resolved()
    print(f"已加载并验证 {len(REQUIRED_KEYS)} 个会话变量(来源:{env_path} + process.env):")
    for k in REQUIRED_KEYS:
        v = resolved[k]
        print(f"  {k}: 已设置(长度 {len(v['value'])},来源 {v['source']})")
    if args.check or not args.argv:
        return 0

    cmd = args.argv[0]
    cmd_args = args.argv[1:]
    resolved_cmd = resolve_command(cmd)
    env_full = {**os.environ, **{k: resolved[k]["value"] for k in REQUIRED_KEYS}}
    print()
    print(f"$ {resolved_cmd} {' '.join(cmd_args)}")
    rc = subprocess.call([resolved_cmd, *cmd_args], env=env_full, cwd=str(ROOT))
    return rc


if __name__ == "__main__":
    sys.exit(main())
