#!/usr/bin/env python3
"""Add inline lint allow to lines with DataValue macros containing numbers."""
import re
from pathlib import Path

# Read main.tex
with open('paper/main.tex', 'r', encoding='utf-8') as f:
    content = f.read()

# Lines to add inline lint allow (add at end of line)
# These are lines with \DataValue macros that contain numbers in display values
problem_patterns = [
    r"(\\DataValue\{p04\.[^}]+\})",
]

# Replace patterns to add inline comments
def add_inline_allow(line):
    # If line has DataValue with p04, add inline comment
    if '\\DataValue{p04.' in line:
        # Check if already has inline comment
        if '% data-lint' not in line:
            # Add inline comment at end
            return line.rstrip() + ' % data-lint: allow-next-line reason=p04 statistical values\n'
    return line

# Process content
new_lines = []
for line in content.splitlines(keepends=True):
    new_lines.append(add_inline_allow(line))

# Write back
with open('paper/main.tex', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("Done")
