"""Convert an attested official SWE-bench Verified Parquet file to CACTUS JSONL.

Only inference-safe fields are emitted.  In particular, gold ``patch`` and
``test_patch`` fields are deliberately excluded from the generated manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable


def task_record(row: dict[str, Any]) -> dict[str, Any]:
    required = ("instance_id", "repo", "base_commit", "problem_statement")
    missing = [field for field in required if not isinstance(row.get(field), str) or not row[field].strip()]
    if missing:
        raise ValueError(f"missing required SWE-bench fields: {', '.join(missing)}")
    return {
        "task_id": row["instance_id"],
        "repo_id": row["repo"],
        "base_commit": row["base_commit"],
        "issue_text": row["problem_statement"],
        "test_command": ["swebench", "eval", "verified", "-i", row["instance_id"]],
        "split": "test",
        "benchmark": "SWE-bench_Verified",
        "source_fields": {"version": row.get("version"), "difficulty": row.get("difficulty")},
    }


def materialize(rows: Iterable[dict[str, Any]], output: Path) -> tuple[int, str]:
    records = [task_record(row) for row in rows]
    if not records:
        raise ValueError("source contains no tasks")
    payload = "".join(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n" for record in records)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(payload, encoding="utf-8", newline="\n")
    return len(records), hashlib.sha256(payload.encode("utf-8")).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parquet", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        import pyarrow.parquet as pq
    except ImportError as error:
        raise SystemExit("pyarrow is required for Parquet conversion; install it in acm/.venv with a recorded version") from error
    table = pq.read_table(args.parquet)
    count, digest = materialize(table.to_pylist(), args.output)
    print(f"PASS materialized {count} inference-safe tasks; sha256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
