"""Digest-pinned, local Docker image lifecycle for CACTUS evaluation tasks.

All Docker mutations are explicit method calls. Importing this module and
auditing cache manifests never starts, removes, or retags an image.
"""

from __future__ import annotations

import json
import hashlib
import re
import subprocess
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable, Sequence


_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
DEFAULT_CACHE_ROOT = Path("E:/docker-bak/cactus/pilot50")


@dataclass(frozen=True, slots=True)
class ImageSpec:
    task_id: str
    image_ref: str
    expected_digest: str
    archive_path: Path
    local_image_id: str | None = None
    pinned_ref: str | None = None
    runtime_image_id: str | None = None
    loaded_from_archive: bool = False


def resolve_image_spec(
    task_id: str,
    cache_root: Path = DEFAULT_CACHE_ROOT,
    *,
    contract_digest: str | None = None,
    contract_image_id: str | None = None,
    contract_archive_path: str | Path | None = None,
    contract_archive_sha256: str | None = None,
    contract_archive_size_bytes: int | None = None,
    contract_repository: str | None = None,
    contract_tag: str | None = None,
) -> ImageSpec:
    """Resolve one task image, using a frozen contract digest when supplied.

    A cache manifest may lack its candidate digest even though a reviewed
    contract binds the task image to a complete digest. In that case the
    contract digest is authoritative and Docker is inspected by the immutable
    ``repository@sha256:...`` reference. Without a contract digest, a missing
    cache-manifest digest remains a hard error.
    """
    category, separator, instance_id = task_id.partition("__")
    if not separator or not category or not instance_id:
        raise ValueError(f"invalid SWE-bench task id: {task_id}")
    manifest_path = cache_root / category / "local-manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    matches = [
        row for row in manifest.get("entries", [])
        if isinstance(row, dict) and row.get("image_ref", "").endswith(f"_{instance_id}:latest")
    ]
    contract_local_only = False
    if len(matches) == 1:
        row = matches[0]
    elif (
        not matches
        and isinstance(contract_repository, str) and contract_repository
        and isinstance(contract_tag, str) and contract_tag
        and contract_digest is not None and contract_image_id is not None
    ):
        # The fixed contract can still prove an already-local image even if an
        # immutable pilot cache manifest predates this task. Never synthesize an
        # archive fallback: a missing local ID remains a hard failure below.
        row = {
            "image_ref": f"{contract_repository}:{contract_tag}",
            "local_image_id": contract_image_id,
            "candidate_digest": contract_digest,
        }
        contract_local_only = True
    else:
        raise ValueError(f"expected exactly one local image entry for {task_id}; found {len(matches)}")
    manifest_digest = row.get("candidate_digest")
    if contract_digest is not None and (not isinstance(contract_digest, str) or not _DIGEST.fullmatch(contract_digest)):
        raise ValueError(f"contract image for {task_id} has no complete SHA-256 digest")
    if isinstance(manifest_digest, str) and manifest_digest:
        if not _DIGEST.fullmatch(manifest_digest):
            raise ValueError(f"local image for {task_id} has a malformed candidate digest")
        if contract_digest is not None and manifest_digest != contract_digest:
            raise ValueError(f"local image digest for {task_id} conflicts with the frozen contract")
    elif contract_digest is None:
        raise ValueError(f"local image for {task_id} has no complete candidate digest")
    digest = contract_digest or manifest_digest
    local_image_id = row.get("local_image_id")
    if contract_image_id is not None:
        if not isinstance(contract_image_id, str) or not _DIGEST.fullmatch(contract_image_id):
            raise ValueError(f"contract image ID for {task_id} is not a complete SHA-256 identifier")
        if local_image_id != contract_image_id:
            raise ValueError(f"local image ID for {task_id} conflicts with the frozen contract")
    image_ref = row.get("image_ref")
    if not isinstance(image_ref, str) or not image_ref or any(char.isspace() for char in image_ref) or ":" not in image_ref.rsplit("/", 1)[-1]:
        raise ValueError(f"local image reference for {task_id} is malformed")
    repository = image_ref.rsplit(":", 1)[0]
    pinned_ref = f"{repository}@{digest}"
    root = cache_root.resolve()
    if contract_local_only:
        archive_path = None
    elif contract_archive_path is None:
        if contract_archive_sha256 is not None or contract_archive_size_bytes is not None:
            raise ValueError(f"contract archive binding for {task_id} is incomplete")
        shared_archive = manifest.get("shared_archive")
        if not isinstance(shared_archive, str) or not shared_archive:
            raise ValueError(f"image manifest for {task_id} has no shared archive path")
        archive_path = (manifest_path.parent / shared_archive).resolve()
    else:
        if (
            not isinstance(contract_archive_sha256, str)
            or not re.fullmatch(r"[0-9a-f]{64}", contract_archive_sha256)
        ):
            raise ValueError(f"contract archive for {task_id} must declare a complete SHA-256")
        archive_path = Path(contract_archive_path).resolve()
        if not archive_path.is_file():
            raise ValueError(f"contract archive for {task_id} is missing")
        archive_hasher = hashlib.sha256()
        with archive_path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
                archive_hasher.update(chunk)
        if archive_hasher.hexdigest() != contract_archive_sha256:
            raise ValueError(f"contract archive SHA-256 mismatch for {task_id}")
        if contract_archive_size_bytes is not None and (
            not isinstance(contract_archive_size_bytes, int)
            or contract_archive_size_bytes <= 0
            or archive_path.stat().st_size != contract_archive_size_bytes
        ):
            raise ValueError(f"contract archive size mismatch for {task_id}")
    if archive_path is not None and (root not in archive_path.parents or not archive_path.is_file()):
        raise ValueError(f"image archive is missing or outside the configured cache for {task_id}")
    return ImageSpec(
        task_id=task_id,
        image_ref=image_ref,
        expected_digest=digest,
        archive_path=archive_path,
        local_image_id=local_image_id,
        pinned_ref=pinned_ref,
    )


class ImageLifecycle:
    """Explicit image loading and idle cleanup; never operates on unpinned refs."""

    def __init__(
        self,
        cache_root: Path = DEFAULT_CACHE_ROOT,
        *,
        docker_binary: str = "docker",
        runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
        idle_seconds: int = 60,
        keep_recent: int = 2,
    ) -> None:
        self.cache_root = cache_root
        self.docker_binary = docker_binary
        self.runner = runner
        self.idle_seconds = idle_seconds
        self.keep_recent = keep_recent
        self._lock = threading.RLock()
        self._last_used: dict[str, float] = {}
        self._expected_digests: dict[str, str] = {}
        self._pinned_refs: dict[str, str] = {}

    def _inspect_digest(self, image_ref: str) -> set[str]:
        result = self.runner(
            [self.docker_binary, "image", "inspect", image_ref],
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return set()
        try:
            images = json.loads(result.stdout)
        except json.JSONDecodeError:
            return set()
        digests: set[str] = set()
        for image in images if isinstance(images, list) else []:
            for reference in image.get("RepoDigests", []):
                if "@" in reference:
                    digests.add(reference.rsplit("@", 1)[1])
        return digests

    def _inspect_image_id(self, image_ref: str) -> str | None:
        result = self.runner(
            [self.docker_binary, "image", "inspect", image_ref, "--format={{.Id}}"],
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return None
        image_id = result.stdout.strip()
        return image_id if _DIGEST.fullmatch(image_id) else None

    def pre_task(
        self,
        task_id: str,
        contract_digest: str,
        *,
        contract_image_id: str | None = None,
        contract_archive_path: str | Path | None = None,
        contract_archive_sha256: str | None = None,
        contract_archive_size_bytes: int | None = None,
        contract_repository: str | None = None,
        contract_tag: str | None = None,
    ) -> ImageSpec:
        """Load on demand after contract/catalog digest equality is established."""
        spec = resolve_image_spec(
            task_id,
            self.cache_root,
            contract_digest=contract_digest,
            contract_image_id=contract_image_id,
            contract_archive_path=contract_archive_path,
            contract_archive_sha256=contract_archive_sha256,
            contract_archive_size_bytes=contract_archive_size_bytes,
            contract_repository=contract_repository,
            contract_tag=contract_tag,
        )
        if contract_digest != spec.expected_digest:
            raise ValueError(f"image digest for {task_id} does not match the frozen contract")
        with self._lock:
            inspect_ref = spec.pinned_ref or spec.image_ref
            digests = self._inspect_digest(inspect_ref)
            loaded_from_archive = False
            runtime_image_id = None
            if spec.expected_digest not in digests:
                local_image_id = spec.local_image_id
                observed_image_id = self._inspect_image_id(spec.image_ref)
                if local_image_id and (
                    observed_image_id == local_image_id
                    or self._inspect_image_id(local_image_id) == local_image_id
                ):
                    # The read-only cache manifest binds this exact Docker image ID
                    # to the contract digest. Use the content-addressed ID directly
                    # so the evaluator does not need a RepoDigest tag or a bulk load.
                    runtime_image_id = local_image_id
                    if observed_image_id != local_image_id:
                        self.runner(
                            [self.docker_binary, "tag", local_image_id, spec.image_ref],
                            check=False,
                            capture_output=True,
                            text=True,
                        )
                else:
                    if spec.archive_path is None:
                        raise RuntimeError(f"local contract-pinned image is unavailable for {task_id}")
                    loaded_from_archive = True
                    loaded = self.runner(
                        [self.docker_binary, "load", "--input", str(spec.archive_path)],
                        check=False,
                        capture_output=True,
                        text=True,
                    )
                    if loaded.returncode != 0:
                        raise RuntimeError(f"Docker image load failed for {task_id} (exit={loaded.returncode})")
                    # Docker Desktop on Windows can return from ``docker load``
                    # before the daemon has committed the final image record.
                    # Poll only local metadata; never pull or resolve a mutable
                    # registry tag.  This closes that short registration race
                    # without weakening the immutable digest/ID binding.
                    visible = False
                    deadline = time.monotonic() + 30.0
                    while True:
                        digests = self._inspect_digest(inspect_ref)
                        if spec.expected_digest in digests:
                            visible = True
                            break
                        observed_image_id = self._inspect_image_id(spec.image_ref)
                        if spec.local_image_id and (
                            observed_image_id == spec.local_image_id
                            or self._inspect_image_id(spec.local_image_id) == spec.local_image_id
                        ):
                            # Some Docker-save archives have no RepoDigest metadata.
                            # The frozen archive hash and contract/cache-bound image
                            # ID still identify the exact image content.
                            runtime_image_id = spec.local_image_id
                            if observed_image_id != spec.local_image_id:
                                self.runner(
                                    [self.docker_binary, "tag", spec.local_image_id, spec.image_ref],
                                    check=False,
                                    capture_output=True,
                                    text=True,
                                    )
                            visible = True
                            break
                        if time.monotonic() >= deadline:
                            break
                        time.sleep(0.5)
                    if not visible:
                        raise RuntimeError(f"loaded image digest verification failed for {task_id}")
            self._last_used[spec.image_ref] = time.monotonic()
            self._expected_digests[spec.image_ref] = spec.expected_digest
            self._pinned_refs[spec.image_ref] = runtime_image_id or inspect_ref
        return replace(spec, runtime_image_id=runtime_image_id, loaded_from_archive=loaded_from_archive)

    def release(self, spec: ImageSpec) -> None:
        """Record task completion; image cleanup is handled separately."""
        with self._lock:
            self._last_used[spec.image_ref] = time.monotonic()

    def cleanup_expired(self, *, next_needed_refs: Sequence[str] = (), now: float | None = None) -> list[str]:
        """Remove only digest-verified, idle images outside the two-entry cache."""
        instant = time.monotonic() if now is None else now
        next_refs = set(next_needed_refs)
        with self._lock:
            ranked = sorted(self._last_used.items(), key=lambda item: item[1], reverse=True)
            retained = {ref for ref, _ in ranked[: self.keep_recent]}
            retained.update(
                ref
                for ref, _ in ranked
                if ref in next_refs or self._pinned_refs.get(ref) in next_refs
            )
            removed: list[str] = []
            for image_ref, last_used in ranked:
                if image_ref in retained or instant - last_used < self.idle_seconds:
                    continue
                expected_digest = self._expected_digests.get(image_ref)
                pinned_ref = self._pinned_refs.get(image_ref, image_ref)
                refs_to_remove: list[str] = []
                runtime_image_id = self._inspect_image_id(pinned_ref) if pinned_ref.startswith("sha256:") else None
                if runtime_image_id and runtime_image_id == pinned_ref:
                    refs_to_remove.append(runtime_image_id)
                tag_digests = self._inspect_digest(image_ref)
                if expected_digest in tag_digests and image_ref not in refs_to_remove:
                    refs_to_remove.append(image_ref)
                pinned_digests = self._inspect_digest(pinned_ref) if pinned_ref != image_ref and not runtime_image_id else tag_digests
                if pinned_ref != image_ref and not runtime_image_id and expected_digest in pinned_digests:
                    refs_to_remove.append(pinned_ref)
                if not refs_to_remove:
                    continue
                all_removed = True
                for reference in refs_to_remove:
                    result = self.runner(
                        [self.docker_binary, "image", "rm", reference],
                        check=False,
                        capture_output=True,
                        text=True,
                    )
                    if result.returncode == 0:
                        removed.append(reference)
                    else:
                        all_removed = False
                if all_removed:
                    self._last_used.pop(image_ref, None)
                    self._expected_digests.pop(image_ref, None)
                    self._pinned_refs.pop(image_ref, None)
            return removed


class TaskWarmupPool:
    """Bounded look-ahead executor; callers provide the explicit warmup action."""

    def __init__(self, *, lookahead: int = 2, workers: int = 2) -> None:
        if lookahead < 1 or workers < 1:
            raise ValueError("lookahead and workers must be positive")
        self.lookahead = lookahead
        self._executor = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="cactus-warmup")
        self._inflight: dict[str, Future[object]] = {}

    def schedule(self, task_id: str, warmup: Callable[[str], object]) -> None:
        if task_id not in self._inflight:
            self._inflight[task_id] = self._executor.submit(warmup, task_id)

    def schedule_ahead(self, task_ids: Sequence[str], current_index: int, warmup: Callable[[str], object]) -> None:
        """Queue at most ``lookahead`` following task IDs (zero-based index)."""
        for task_id in task_ids[current_index + 1 : current_index + 1 + self.lookahead]:
            self.schedule(task_id, warmup)

    def block_for(self, task_id: str, *, timeout: float = 120) -> object | None:
        future = self._inflight.pop(task_id, None)
        return future.result(timeout=timeout) if future is not None else None

    def close(self) -> None:
        self._executor.shutdown(wait=True, cancel_futures=False)
