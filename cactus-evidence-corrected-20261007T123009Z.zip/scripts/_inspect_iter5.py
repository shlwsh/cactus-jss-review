"""查 ITER5 模型调用统计"""
import json
import os

for task in ['django__django-11910', 'django__django-12125']:
    tid = task.split('django-')[1]
    p = f'experiments/runs/ITER5-{tid}/{task}/events.jsonl'
    if not os.path.exists(p):
        print(task, ': NO FILE')
        continue
    with open(p, encoding='utf-8') as f:
        events = [json.loads(l) for l in f]
    print(f'{task}: events={len(events)} model_calls={sum(1 for e in events if e.get("type") == "model_call")}')
    for e in events:
        if e.get('type') == 'model_call':
            p2 = e.get('payload', {})
            in_tok = p2.get('input_tokens', 0)
            out_tok = p2.get('output_tokens', 0)
            seq = e.get('seq', '?')
            print(f'  seq={seq} in={in_tok} out={out_tok}')
    # Site / replacement rejections
    for e in events:
        t = e.get('type', '')
        if t in ('prediction_sites_rejected', 'prediction_rejected'):
            p2 = e.get('payload', {})
            print(f'  [{t}] attempt={p2.get("attempt")} reason={p2.get("reason", "")[:120]}')