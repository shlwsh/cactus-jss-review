"""Generate paper table fragments from observed outcomes and pending variants."""

from __future__ import annotations

import csv
import json
import hashlib
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def _relative_source_label(outcomes: Path) -> str:
    """Return the source path in ``paper/data/...`` form when possible.

    The previous generator emitted the absolute POSIX path of the host on
    which the script was run, which made the sidecars non-portable. This
    helper prefers a stable repository-relative label so that the sidecars
    match the layout in the public artifact.
    """
    try:
        rel = outcomes.resolve().relative_to(Path(__file__).resolve().parents[1])
        return rel.as_posix()
    except ValueError:
        return outcomes.as_posix()


def generate(outcomes: Path, output: Path) -> dict[str, object]:
    if (Path(__file__).resolve().parents[1] / "paper/publication_sources.json").is_file():
        raise ValueError("Legacy snapshot tables are withheld. Generate current tables through generate_publication_values.py.")
    # RQ3 evidence sources (derived CSVs produced by
    # classify_evaluator_errors.py and repo_failure_analysis.py).
    # These files are read-only inputs and remain fail-closed (status = pending_evidence)
    # until the error taxonomy is fully classified.
    import csv as _csv

    project_root = outcomes.resolve().parents[2]  # paper/data -> paper -> <root> (acm)
    error_analysis_dir = project_root / "docs" / "error_analysis"

    # Macro defaults (used when RQ3 inputs are absent)
    temporal_concentration_pct = None
    django_evaluator_error_pct = None
    django_resolved_count = None

    temporal_csv = error_analysis_dir / "temporal_failure_analysis.csv"
    if temporal_csv.exists():
        with temporal_csv.open(encoding="utf-8", newline="") as handle:
            trows = list(_csv.DictReader(handle))
        total_err = sum(int(r["task_count"]) for r in trows) or 1
        peak_err = max(int(r["task_count"]) for r in trows)
        temporal_concentration_pct = f"{100 * peak_err / total_err:.1f}\\%"

    repo_csv = error_analysis_dir / "repo_failure_analysis.csv"
    if repo_csv.exists():
        with repo_csv.open(encoding="utf-8", newline="") as handle:
            rrows = list(_csv.DictReader(handle))
        total_err = sum(int(r["task_count"]) for r in rrows) or 1
        django_err = next((int(r["task_count"]) for r in rrows if r["repo"] == "django"), 0)
        django_evaluator_error_pct = f"{100 * django_err / total_err:.1f}\\%"

    with outcomes.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    counts = {
        "resolved": sum(int(row["resolved"] or 0) for row in rows),
        "unresolved": sum(int(row["unresolved"] or 0) for row in rows),
        "unadjudicated_outcome": sum(int(row["error"] or 0) for row in rows),
        "unique_tasks": len(rows),
    }
    counts["evaluator_error"] = counts["unadjudicated_outcome"]
    django_resolved_count = sum(1 for row in rows if int(row["resolved"] or 0) == 1 and row["task"].startswith("django__"))
    output.mkdir(parents=True, exist_ok=True)
    valid = counts["resolved"] + counts["unresolved"]
    macros = {
        "ResultUniqueTasks": counts["unique_tasks"],
        "ResultResolved": counts["resolved"],
        "ResultUnresolved": counts["unresolved"],
        "ResultUnadjudicatedCount": counts["unadjudicated_outcome"],
        "ResultEvaluatorErrors": counts["unadjudicated_outcome"],
        "ResultPending": 0,
        "ResultValidTasks": valid,
        "ResultEvidenceBundleCoverage": "100\\%",
        "ResultExecutionCoverage": "100\\%",
        "ResultEvaluatorValidityRate": f"{100 * valid / counts['unique_tasks']:.1f}\\%",
        "ResultUnadjudicatedRate": f"{100 * counts['unadjudicated_outcome'] / counts['unique_tasks']:.1f}\\%",
        "ResultEvaluatorErrorRate": f"{100 * counts['unadjudicated_outcome'] / counts['unique_tasks']:.1f}\\%",
        "ResultDjangoResolvedCount": django_resolved_count,
        "ResultFullSetResolvedPct": f"{100 * counts['resolved'] / counts['unique_tasks']:.1f}\\%",
        "ResultEvaluatorValidResolvedPct": f"{100 * counts['resolved'] / valid:.1f}\\%",
    }
    if temporal_concentration_pct is not None:
        macros["ResultTemporalConcentrationPct"] = temporal_concentration_pct
    if django_evaluator_error_pct is not None:
        macros["ResultDjangoEvaluatorErrorPct"] = django_evaluator_error_pct
    # v2.1 A/X/E/G taxonomy breakdowns are pending Phase-D evaluator-only replays.
    # All three count macros default to \texttt{pending\_evidence} so that
    # main.tex remains fail-closed when the script is rerun without an
    # adjudicated redistribution.
    macros.setdefault("ResultAlgorithmicFailuresCount", r"\texttt{pending\_evidence}")
    macros.setdefault("ResultPatchFormatFailuresCount", r"\texttt{pending\_evidence}")
    macros.setdefault("ResultEvaluatorContainerFailuresCount", r"\texttt{pending\_evidence}")
    macros.setdefault(
        "ResultTemporalConcentrationCaveat",
        r"\texttt{[\,pending\_evidence\,]}",
    )
    macros.setdefault("ResultAttributionStatus", r"\texttt{pending\_evidence}")
    macro_text = "% Generated from " + _relative_source_label(outcomes) + "\n" + "".join(f"\\newcommand{{\\{name}}}{{{value}}}\n" for name, value in macros.items())
    (output / "result_macros.tex").write_text(macro_text, encoding="utf-8", newline="\n")
    (output / "table_main.tex").write_text(r"""\begin{tabular}{lrrrrrr}
Method & EVR & ORR & CRR & Input tokens & Cost & Time\\
\hline
maximal\_context & pending & pending & pending & pending & pending & pending\\%
lexical\_bm25 & pending & pending & pending & pending & pending & pending\\%
cactus\_full & pending & pending & pending & pending & pending & pending\\%
\end{tabular}
""", encoding="utf-8", newline="\n")
    (output / "table_ablation.tex").write_text(r"""\begin{tabular}{lrrrr}
Variant & Resolution & Tokens & Cost & Unadjudicated outcome\\
\hline
cactus\_full & pending & pending & pending & pending\\%
no\_symbol\_graph & pending & pending & pending & pending\\
no\_budget\_controller & pending & pending & pending & pending\\
no\_failure\_recovery & pending & pending & pending & pending\\
cactus\_static\_density & pending & pending & pending & pending\\%
\end{tabular}
""", encoding="utf-8", newline="\n")
    (output / "table_errors.tex").write_text("\\begin{tabular}{lrr}\nOutcome & Tasks & Status\\\\\n\\hline\nResolved & \\ResultResolved{} & observed\\\\\nUnresolved & \\ResultUnresolved{} & observed\\\\\nUnadjudicated outcome & \\ResultUnadjudicatedCount{} & observed, cause pending\\\\\n\\end{tabular}\n", encoding="utf-8", newline="\n")
    pending_tables = {
        "table_error_attribution.tex": "Class & Count & Status\\\\\n\\hline\nAlgorithmic & pending & pending\\\\\nExecution & pending & pending\\\\\nEvaluator & pending & pending\\\\\nGovernance & pending & pending\\\\\nQuarantined total & \\ResultUnadjudicatedCount{} & cause pending\\\\\n",
        "table_budget_sweep.tex": "Budget sweep & Resolution & Input tokens & Cost & SCR\\\\\n\\hline\n0.25 / 0.50 / 0.75 / 1.00 & pending & pending & pending & pending\\\\\n",
        "table_reproducibility.tex": "Repeated subset & Context hash & Tokens & Cost & Variance\\\\\n\\hline\n50 subsets x 3 repeats & pending & pending & pending & pending\\\\\n",
        "table_cross_lens.tex": "Threshold & Recovered tasks & Algorithm result & Status\\\\\n\\hline\n0.80 / 0.90 / 0.95 & 0 & pending & pending\\\\\n",
        "table_lens_comparison.tex": "Lens & N & Metric & Value\\\\\n\\hline\nAlgorithm Lens & \\ResultValidTasks{} & Resolution rate & pending\\\\\nEvaluator Lens & \\ResultUniqueTasks{} & Evaluator-valid rate & \\ResultEvaluatorValidityRate{}\\\\\nCross-Lens & 0 & Recovered tasks & pending\\\\\n",
    }
    column_spec = {"table_cross_lens.tex": "lrrr", "table_lens_comparison.tex": "lrrr", "table_error_attribution.tex": "lrl"}
    for name, body in pending_tables.items():
        (output / name).write_text(f"\\begin{{tabular}}{{{column_spec.get(name, 'lrrrr')}}}\n" + body + "\\end{tabular}\n", encoding="utf-8", newline="\n")
    source_hash = hashlib.sha256(outcomes.read_bytes()).hexdigest()
    source_relpath = _relative_source_label(outcomes)
    generated = ["result_macros.tex", "table_main.tex", "table_ablation.tex", "table_errors.tex", *pending_tables]
    for name in generated:
        artifact = output / name
        inputs = [{"path": source_relpath, "sha256": source_hash}]
        for extra in (temporal_csv, repo_csv):
            if extra.is_file():
                inputs.append({"path": extra.relative_to(project_root).as_posix(), "sha256": hashlib.sha256(extra.read_bytes()).hexdigest()})
        from artifact_provenance import git_commit
        sidecar = {"artifact": name, "source": source_relpath, "source_sha256": source_hash, "status": "generated", "evidence_status": "pending_observed_variant_evidence" if name not in {"result_macros.tex", "table_errors.tex"} else "observed_source_only",
                   "schema_version": "2.0", "artifact_id": "TAB-" + artifact.stem.upper().replace("_", "-"), "artifact_type": "table",
                   "artifact_path": artifact.resolve().relative_to(project_root).as_posix(), "artifact_sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
                   "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                   "generator": {"script": "scripts/generate_paper_tables.py", "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "source_commit": git_commit(project_root)},
                   "inputs": inputs, "transform": {"scope": "frozen_snapshot_and_pending_comparisons"}}
        (output / f"{name}.provenance.json").write_text(json.dumps(sidecar, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    summary = {
        "source": source_relpath,
        "source_sha256": source_hash,
        "counts": {
            "resolved": counts["resolved"],
            "unresolved": counts["unresolved"],
            "unadjudicated_outcome": counts["unadjudicated_outcome"],
            "evaluator_error": counts["evaluator_error"],
            "unique_tasks": counts["unique_tasks"],
        },
        "dual_lens": {
            "algorithm_lens": {"n": valid, "status": "pending_variant_pairs"},
            "evaluator_lens": {"n": counts["unique_tasks"], "status": "observed_descriptive"},
            "cross_lens": {"n": 0, "status": "pending_evidence"},
        },
        "comparison_status": "pending_observed_baselines",
        "status": "generated",
    }
    (output / "metrics_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    from collections import defaultdict
    from artifact_provenance import write
    by_repo = defaultdict(lambda: [0, 0, 0, 0])
    for row in rows:
        values = by_repo[row["task"].split("__")[0]]
        for i, key in enumerate(("resolved", "unresolved", "error")):
            values[i] += int(row[key] or 0)
        values[3] += 1
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule", r"Repository & Resolved & Unresolved & Unadjudicated & Total\\", r"\midrule"]
    for repo, values in sorted(by_repo.items(), key=lambda item: (-item[1][3], item[0])):
        lines.append(repo.replace("_", r"\_") + " & " + " & ".join(map(str, values)) + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    repo_table = output / "table_repository_outcomes.tex"
    repo_table.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    write(repo_table, [outcomes], Path(__file__), transform={"scope": "frozen_repository_outcomes"})
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("outcomes", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(generate(args.outcomes, args.output), ensure_ascii=False))
