"""Check environment readiness for Pilot execution."""
import os
import sys
import importlib

print('=== Python environment ===')
print('python:', sys.version.split()[0])

print()
print('=== CACTUS_LITELLM_API_KEY ===')
key = os.environ.get('CACTUS_LITELLM_API_KEY')
if key:
    print('  [OK] present (length:', len(key), ')')
else:
    print('  [MISSING] CACTUS_LITELLM_API_KEY not set in environment')

print()
print('=== Required Python packages ===')
for pkg, desc in [
    ('swebench', 'SWE-bench 5.0.2 evaluation harness'),
    ('pyarrow', 'parquet support for LiteLLM billing trace'),
    ('litellm', 'LiteLLM client'),
]:
    try:
        m = importlib.import_module(pkg)
        ver = getattr(m, '__version__', 'unknown')
        print(f'  [OK] {pkg}=={ver} ({desc})')
    except ImportError as e:
        print(f'  [MISSING] {pkg}: {e}')

print()
print('=== CACTUS internal modules ===')
sys.path.insert(0, '.')
for mod_name in [
    'cactus.runner.swebench_campaign',
    'cactus.runner.formal',
    'cactus.adapters.benchmark',
    'cactus.adapters.litellm',
    'cactus.evaluation.derive',
]:
    try:
        importlib.import_module(mod_name)
        print(f'  [OK] {mod_name}')
    except ImportError as e:
        print(f'  [MISSING] {mod_name}: {e}')

print()
print('=== Pilot contract SHA-256 (workload + derivation) ===')
import hashlib
from pathlib import Path
for path in [
    'scripts/cactus_swebench_predict.py',
    'scripts/swebench_eval_lf.py',
    'src/cactus/evaluation/derive.py',
]:
    if Path(path).exists():
        sha = hashlib.sha256(Path(path).read_bytes()).hexdigest()
        print(f'  {path}: sha256={sha}')
    else:
        print(f'  [MISSING] {path}')
