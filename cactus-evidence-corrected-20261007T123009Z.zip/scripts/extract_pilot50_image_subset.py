"""Extract selected image tags from a shared Docker save archive."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import tarfile
from pathlib import Path
from typing import Any


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def extract_subset(source_path: Path, output_path: Path, requested_refs: set[str]) -> dict[str, Any]:
    """Write a Docker-loadable archive containing only requested RepoTags."""
    if not requested_refs:
        raise ValueError("at least one image reference is required")
    if output_path.exists():
        output_path.unlink()
    with tarfile.open(source_path, mode="r") as source:
        manifest_member = source.getmember("manifest.json")
        manifest_handle = source.extractfile(manifest_member)
        if manifest_handle is None:
            raise ValueError("shared archive has no readable manifest.json")
        entries = json.load(manifest_handle)
        selected = [entry for entry in entries if requested_refs.intersection(entry.get("RepoTags", []))]
        selected_tags = {tag for entry in selected for tag in entry.get("RepoTags", [])}
        missing = sorted(requested_refs - selected_tags)
        if missing:
            raise ValueError("requested refs are absent from archive: " + ", ".join(missing))
        required_blobs = {
            blob
            for entry in selected
            for blob in [entry["Config"], *entry["Layers"]]
        }
        with tarfile.open(output_path, mode="w") as target:
            copied: set[str] = set()
            for member in source:
                if not member.isfile() or member.name not in required_blobs:
                    continue
                handle = source.extractfile(member)
                if handle is None:
                    raise ValueError(f"archive member is not readable: {member.name}")
                target.addfile(member, handle)
                copied.add(member.name)
            if copied != required_blobs:
                raise ValueError(f"archive is missing {len(required_blobs - copied)} required blobs")
            manifest_bytes = json.dumps(selected, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            info = tarfile.TarInfo("manifest.json")
            info.size = len(manifest_bytes)
            info.mode = 0o644
            target.addfile(info, io.BytesIO(manifest_bytes))
    return {
        "archive": output_path.as_posix(),
        "archive_size_bytes": output_path.stat().st_size,
        "archive_sha256": _sha256(output_path),
        "selected_entry_count": len(selected),
        "selected_tag_count": len(selected_tags),
        "blob_count": len(required_blobs),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--ref", action="append", required=True)
    args = parser.parse_args()
    print(json.dumps(extract_subset(args.source, args.output, set(args.ref)), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
