"""Check manifest fields."""
import json
fpath = 'data/manifests/swebench_lite50_b0dde109_test_inference_safe.jsonl'
with open(fpath, encoding='utf-8-sig') as f:
    line = f.readline()
d = json.loads(line)
print('keys:', list(d.keys()))
print('has FAIL_TO_PASS:', 'FAIL_TO_PASS' in d)
print('has fail_to_pass:', 'fail_to_pass' in d)
print('test_id:', d.get('task_id'))
print('repo_id:', d.get('repo_id'))

# count tasks
total = 0
with_pass = 0
with open(fpath, encoding='utf-8-sig') as f:
    for line in f:
        d = json.loads(line)
        total += 1
        if d.get('FAIL_TO_PASS'):
            with_pass += 1
print(f'total={total}, with FAIL_TO_PASS={with_pass}')
