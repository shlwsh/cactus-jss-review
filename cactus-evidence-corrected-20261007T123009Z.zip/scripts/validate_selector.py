"""Validate selector determinism and fragmentation on the independent dev set."""

from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from cactus.domain.models import ContextUnit
from cactus.retrieval.marginal_utility import select_marginal_utility
from cactus.retrieval.static_density import select_static_density


ROOT = Path(__file__).resolve().parents[1]
DEV_SET = ROOT / "data" / "fixtures" / "dev_set" / "tasks.jsonl"
OUTPUT = ROOT / "analysis"


def _units(record: dict[str, object]) -> tuple[ContextUnit, ...]:
    normalized = []
    for raw in record["units"]:
        payload = dict(raw)
        provenance = dict(payload.pop("provenance", {}))
        for key in ("lexical_score", "coverage_keys", "parent_unit_id"):
            if key in payload:
                provenance[key] = payload.pop(key)
        payload["provenance"] = provenance
        normalized.append(ContextUnit(**payload))
    return tuple(normalized)


def _load(path: Path) -> list[dict[str, object]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _select(units: tuple[ContextUnit, ...], scores: dict[str, float], *, budget: int, weights: dict[str, float] | None = None):
    return select_marginal_utility(units, scores, budget=max(0, budget), weights=weights)


def validate(dev_set: Path = DEV_SET, output_dir: Path = OUTPUT, *, budget: int = 180) -> dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    before_after = []
    sensitivity = []
    for record in _load(dev_set):
        units = _units(record)
        scores = {unit.unit_id: float(unit.provenance.get("lexical_score", 0.0)) for unit in units}
        marginal = _select(units, scores, budget=budget)
        repeat = _select(units, scores, budget=budget)
        static = select_static_density(units, scores, budget=budget)
        rows.append({"task_id": record["task_id"], "category": record["category"], "selector": "marginal_utility", "budget": budget, "selected_tokens": marginal.total_tokens, "selected_files": marginal.selected_files, "selected_chunks": marginal.selected_chunks, "fragmentation_index": marginal.fragmentation_index, "bundle_hash": marginal.bundle_hash, "stable": marginal.bundle_hash == repeat.bundle_hash})
        before_after.append({"task_id": record["task_id"], "static_density_index": static.fragmentation_index, "marginal_utility_index": marginal.fragmentation_index, "static_bundle_hash": static.bundle_hash, "marginal_bundle_hash": marginal.bundle_hash, "marginal_stable": marginal.bundle_hash == repeat.bundle_hash})
        scenarios = (
            ("budget_minus_20pct", max(1, round(budget * 0.80)), {}),
            ("frozen", budget, {}),
            ("budget_plus_20pct", max(1, round(budget * 1.20)), {}),
            ("coverage_alpha_minus_20pct", budget, {"coverage_alpha": 0.16}),
            ("coverage_alpha_plus_20pct", budget, {"coverage_alpha": 0.24}),
            ("redundancy_beta_minus_20pct", budget, {"redundancy_beta": 0.12}),
            ("redundancy_beta_plus_20pct", budget, {"redundancy_beta": 0.18}),
        )
        for scenario, scenario_budget, weights in scenarios:
            selected = _select(units, scores, budget=scenario_budget, weights=weights)
            sensitivity.append({"task_id": record["task_id"], "scenario": scenario, "budget": scenario_budget, "selected_tokens": selected.total_tokens, "selected_files": selected.selected_files, "selected_chunks": selected.selected_chunks, "fragmentation_index": selected.fragmentation_index, "bundle_hash": selected.bundle_hash, "status": selected.status})
    fields = list(rows[0]) if rows else ["task_id"]
    with (output_dir / "context_selector_validation.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)
    fields = list(before_after[0]) if before_after else ["task_id"]
    with (output_dir / "fragmentation_before_after.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader(); writer.writerows(before_after)
    fields = list(sensitivity[0]) if sensitivity else ["task_id"]
    with (output_dir / "context_selector_sensitivity.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader(); writer.writerows(sensitivity)
    stable = bool(rows) and all(bool(row["stable"]) for row in rows)
    sensitivity_status = "pass" if sensitivity and all(row["status"] == "ok" for row in sensitivity) else "pending"
    summary = {"schema_version": "2.1", "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "dev_set": dev_set.relative_to(ROOT).as_posix(), "task_count": len(rows), "stable_count": sum(bool(row["stable"]) for row in rows), "all_stable": stable, "sensitivity_rows": len(sensitivity), "sensitivity_scenarios": sorted({str(row["scenario"]) for row in sensitivity}), "sensitivity_status": sensitivity_status, "source_sha256": hashlib.sha256(dev_set.read_bytes()).hexdigest(), "uses_resolution_labels": False, "status": "pass" if stable and sensitivity_status == "pass" else "pending"}
    (output_dir / "context_selector_validation.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--dev-set", type=Path, default=DEV_SET)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT)
    parser.add_argument("--budget", type=int, default=180)
    args = parser.parse_args()
    print(json.dumps(validate(args.dev_set, args.output_dir, budget=args.budget), ensure_ascii=False))
