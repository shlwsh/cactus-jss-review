"""launch_r4_v3.py — R4 v3 single-task launch with NO-THINK model config.

Key changes vs launch_r4_single.py:
  - Uses litellm_local_nothink.json (thinking=false, max_output_tokens=8192)
  - Passes --max-output-tokens / --request-timeout-sec overrides via the runner
  - Generates fresh RUN ID with timestamp so we don't reuse any failed RUN
  - Saves a copy of the model config alongside the RUN for audit
"""

from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

from inject_session_keys import REQUIRED_KEYS, load_resolved  # noqa: E402

CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
APPROVAL = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
PLAN = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json"
MODEL_CONFIG = ROOT / "configs" / "models" / "litellm_local_nothink.json"
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
OUTPUT_ROOT = ROOT / "experiments" / "runs"
REPO_CACHE = ROOT / "experiments" / "repo_cache"
DATASET = Path(r"E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
CAMPAIGN_ID = "phase-c1-engineering-validation-r4-v3-nothink-20260925"

RUNNER = ROOT / "scripts" / "run_swebench_campaign.py"
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"


def main() -> int:
    env_path, resolved = load_resolved()
    env = {**os.environ, **{k: resolved[k]["value"] for k in REQUIRED_KEYS}}
    for required in (CONTRACT, APPROVAL, PLAN, MODEL_CONFIG, TASK_MANIFEST, RUNNER, DATASET):
        if not required.exists():
            print(f"ERROR: required path missing: {required}", file=sys.stderr)
            return 2

    log_path = OUTPUT_ROOT / f"_r4_v3_launch_{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    cmd = [
        str(PYTHON),
        "-m", "scripts.run_swebench_campaign",
        "--contract", str(CONTRACT),
        "--approval", str(APPROVAL),
        "--model-config", str(MODEL_CONFIG),
        "--tasks", str(TASK_MANIFEST),
        "--output-root", str(OUTPUT_ROOT),
        "--repo-cache", str(REPO_CACHE),
        "--evaluator-dataset", str(DATASET),
        "--project-root", str(ROOT),
        "--pair-plan", str(PLAN),
        "--campaign-id", CAMPAIGN_ID,
        "--task-id", "astropy__astropy-12907",
        "--limit", "1",
    ]

    print("=" * 70)
    print("R4 v3 NO-THINK SINGLE-TASK LAUNCH")
    print("=" * 70)
    print(f"contract    : {CONTRACT}")
    print(f"plan        : {PLAN}")
    print(f"model_cfg   : {MODEL_CONFIG}")
    print(f"  thinking        = False   ← KEY FIX (was True)")
    print(f"  max_output_tokens= 8192   ← tighter (was 32768)")
    print(f"  temperature      = 0.1    ← was 0.2")
    print(f"  repetition_penalty=1.12  ← was 1.08")
    print(f"campaign    : {CAMPAIGN_ID}")
    print(f"log         : {log_path}")
    print()
    print("$ " + " ".join(cmd))
    print("=" * 70)

    with log_path.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"# R4 v3 no-think single-task launch log\n# started: {dt.datetime.now(dt.timezone.utc).isoformat()}\n")
        fh.write("# cmd: " + " ".join(cmd) + "\n")
        fh.write("# model_config: " + str(MODEL_CONFIG) + "\n")
        cfg = json.loads(MODEL_CONFIG.read_text(encoding="utf-8"))
        fh.write("# thinking = " + str(cfg.get("thinking")) + "\n")
        fh.write("# max_output_tokens = " + str(cfg.get("max_output_tokens")) + "\n")
        fh.write("# temperature = " + str(cfg.get("temperature")) + "\n\n")
        fh.flush()
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT.parent),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            fh.write(line)
            fh.flush()
        rc = proc.wait()
        fh.write(f"\n# finished: {dt.datetime.now(dt.timezone.utc).isoformat()}  exit={rc}\n")

    print()
    print("=" * 70)
    print(f"R4 v3 single finished with exit code {rc}")
    print(f"log: {log_path}")
    print("=" * 70)
    return rc


if __name__ == "__main__":
    sys.exit(main())
