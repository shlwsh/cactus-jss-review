"""Prepare the frozen Phase C experiment matrix without launching workloads."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-PILOT-V2.json"
DEFAULT_MODEL = ROOT / "configs" / "models" / "litellm_local.json"
DEFAULT_VARIANTS = ROOT / "config" / "variants"
DEFAULT_OUTPUT = ROOT / "artifacts" / "phase_c_matrix.json"

PRIMARY = ("maximal_context", "lexical_bm25", "cactus_full")
ABLATIONS = ("cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density")
ALL_VARIANTS = PRIMARY + ABLATIONS
_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _read(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid JSON input {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"JSON input must be an object: {path}")
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _variant_path(directory: Path, variant: str) -> Path:
    candidates = [directory / f"{variant}.json"]
    if variant.startswith("cactus_"):
        candidates.append(directory / f"{variant.removeprefix('cactus_')}.json")
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError(f"variant config missing for {variant}: {', '.join(path.name for path in candidates)}")


def prepare(contract_path: Path = DEFAULT_CONTRACT, model_path: Path = DEFAULT_MODEL, variant_dir: Path = DEFAULT_VARIANTS, output: Path = DEFAULT_OUTPUT) -> dict[str, object]:
    contract = _read(contract_path)
    model = _read(model_path)
    execution = contract.get("execution") if isinstance(contract.get("execution"), dict) else {}
    contract_model = contract.get("model") if isinstance(contract.get("model"), dict) else {}
    shared = {
        "task_manifest": (contract.get("workload") or {}).get("task_manifest", {}) if isinstance(contract.get("workload"), dict) else {},
        "task_count": execution.get("task_count"),
        "model_id": contract_model.get("model_id", model.get("model_id")),
        "model_version": contract_model.get("model_version", model.get("model_version")),
        "evaluator": (contract.get("agent") or {}).get("evaluation_wrapper") if isinstance(contract.get("agent"), dict) else None,
        "timeout_sec": execution.get("task_timeout_sec"),
        "agent_turn_budget_tokens": execution.get("agent_turn_budget_tokens"),
        "max_retries": execution.get("max_retries"),
        "concurrency": execution.get("concurrency"),
        "cost_budget": execution.get("cost_budget"),
        "billing_key_alias": contract_model.get("billing_key_alias"),
    }
    variants: list[dict[str, object]] = []
    missing: list[str] = []
    for variant in ALL_VARIANTS:
        try:
            path = _variant_path(variant_dir, variant)
        except FileNotFoundError:
            missing.append(variant)
            continue
        config = _read(path)
        variants.append({"id": variant, "config": path.relative_to(ROOT).as_posix(), "config_sha256": _sha256(path), "context": config.get("context", {}), "role": "primary" if variant in PRIMARY else "ablation"})
    gate_reasons: list[str] = []
    if missing:
        gate_reasons.append("missing variant configs: " + ", ".join(missing))
    if shared["task_count"] != 3:
        gate_reasons.append("matrix preparation expects the authorized 3-task Pilot contract")
    contract_billing_source = str(contract_model.get("billing_source", "")).strip()
    model_billing_source = str(model.get("billing_source", "litellm_spend_logs")).strip()
    if contract_billing_source and contract_billing_source != model_billing_source:
        gate_reasons.append(f"contract/model billing source mismatch: {contract_billing_source} != {model_billing_source}")
    if shared["billing_key_alias"] and model.get("billing_key_alias") and shared["billing_key_alias"] != model.get("billing_key_alias"):
        gate_reasons.append("contract/model billing key alias mismatch")
    images = contract.get("images") if isinstance(contract.get("images"), dict) else {}
    for image_name, image in sorted(images.items()):
        digest = image.get("digest") if isinstance(image, dict) else None
        if not isinstance(digest, str) or not _IMAGE_DIGEST.fullmatch(digest):
            gate_reasons.append(f"image digest is not a complete sha256 for {image_name}")
    payload = {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "execution_mode": "planning_only",
        "experiment_id": contract.get("experiment_id"),
        "primary_variants": list(PRIMARY),
        "ablation_variants": list(ABLATIONS),
        "budget_sweep": [0.25, 0.50, 0.75, 1.0],
        "reproducibility": {"task_count": 50, "repetitions_per_task": 3},
        "shared_factors": shared,
        "variants": variants,
        "contract_sha256": _sha256(contract_path),
        "model_config_sha256": _sha256(model_path),
        "gate": {"status": "READY" if not gate_reasons else "BLOCKED", "reasons": gate_reasons},
        "results_written": False,
        "status": "planning_only",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return payload


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--model-config", type=Path, default=DEFAULT_MODEL)
    parser.add_argument("--variant-dir", type=Path, default=DEFAULT_VARIANTS)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    print(json.dumps(prepare(args.contract, args.model_config, args.variant_dir, args.output), ensure_ascii=False))
