"""Regenerate bibliography after main.tex changes."""
from __future__ import annotations
import hashlib
import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[0]
PAPER = ROOT / "paper"

from scripts.verify_cited_papers import cited
from scripts.artifact_provenance import write

keys = cited()
print("Cited keys:", keys)

source = PAPER / "data/publication_bibtex_input.aux"
source.write_text(
    "\\relax\n\\citation{" + ",".join(keys) + "}\n\\bibstyle{style/ACM-Reference-Format}\n\\bibdata{references}\n",
    encoding="utf-8", newline="\n"
)

bib = PAPER / "references.bib"
manifest = PAPER / "data/scholar/cited_papers_manifest.json"
style = PAPER / "style/ACM-Reference-Format.bst"
parser = ROOT / "scripts/verify_cited_papers.py"

# Run bibtex
env = {**os.environ, "PYTHONIOENCODING": "utf-8",
       "PYTHONPATH": os.pathsep.join([str(ROOT), str(ROOT / "src")])}
bibtex_dir = PAPER / "build"
bibtex_dir.mkdir(parents=True, exist_ok=True)

result = subprocess.run(
    ["bibtex", "publication_refs"],
    cwd=str(bibtex_dir),
    env=env,
    capture_output=True
)
print("bibtex returncode:", result.returncode)
if result.returncode != 0:
    print("bibtex stderr:", result.stderr.decode("utf-8", errors="replace")[:500])

# Copy bbl to paper/data/
raw = PAPER / "data/publication_bibliography.bbl"
build_bbl = bibtex_dir / "publication_refs.bbl"
if build_bbl.exists():
    shutil.copyfile(build_bbl, raw)
    print("Copied bbl to paper/data/")

    # Update provenance
    executable = Path(shutil.which("bibtex") or "")
    write(raw, [source, bib, manifest, style, parser],
          Path("scripts/paper_pipeline.py"),
          transform={"activity": "actual BibTeX execution",
                     "citation_keys": keys,
                     "tool_sha256": hashlib.sha256(executable.read_bytes()).hexdigest()
                     if executable.exists() else ""},
          kind="derived_dataset")
    print("Updated provenance")
else:
    print("bbl not found at:", build_bbl)
