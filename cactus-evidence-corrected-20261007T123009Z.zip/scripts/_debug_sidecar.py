#!/usr/bin/env python3
"""Debug verify_sidecar failures."""
import json
import hashlib
from pathlib import Path

ROOT = Path('.')
def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

# 检查 paper/data/publication_bibliography.bbl 的 provenance
bbl = ROOT / 'paper/data/publication_bibliography.bbl'
bbl_prov = bbl.with_name(bbl.name + '.provenance.json')
payload = json.loads(bbl_prov.read_text(encoding='utf-8'))

print('=== publication_bibliography.bbl ===')
print(f'artifact_sha256 in sidecar: {payload["artifact_sha256"]}')
print(f'actual artifact SHA256: {sha256(bbl)}')

print('\n=== Inputs ===')
for inp in payload.get('inputs', []):
    path = ROOT / inp['path']
    if path.exists():
        actual = sha256(path)
        stored = inp['sha256']
        if actual != stored:
            print(f'MISMATCH: {inp["path"]}')
            print(f'  stored: {stored}')
            print(f'  actual: {actual}')
        else:
            print(f'OK: {inp["path"]}')
    else:
        print(f'MISSING: {inp["path"]}')
