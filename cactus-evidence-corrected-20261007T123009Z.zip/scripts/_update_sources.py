#!/usr/bin/env python3
"""Update publication_sources.json with new governance snapshot."""
import json
import hashlib
from pathlib import Path

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

ROOT = Path('.')
sources_file = ROOT / 'paper/publication_sources.json'
sources = json.loads(sources_file.read_text(encoding='utf-8'))

# 新快照目录
new_dir = 'governance_20261006T082437Z'

# 更新 corpus 相关条目
for key in ['corpus_summary', 'corpus_inventory']:
    old_path = sources['sources'][key]['path']
    new_path = 'experiments/derived/' + new_dir + '/' + old_path.split('/')[-1]
    new_full_path = ROOT / new_path
    sources['sources'][key]['path'] = new_path
    sources['sources'][key]['sha256'] = sha256(new_full_path)
    print(f'Updated {key}:')
    print(f'  path: {new_path}')
    print(f'  sha256: {sources["sources"][key]["sha256"]}')

sources_file.write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('\nUpdated publication_sources.json')
