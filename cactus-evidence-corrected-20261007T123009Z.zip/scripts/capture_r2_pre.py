"""Capture R2 PRE environment snapshot (Agent-runnable, before DACL reapply).

Output: experiments/snapshots/C1-pre-r2-<ts>_pending_dacl.json
        experiments/snapshots/C1-pre-r2-<ts>_pending_dacl.json.sha256

Captures full observed snapshot matching schema v2.0. Mirrors R1's manual
construction (see C1-pre-20260925T025700Z.json) — does NOT call
capture_environment() because its redact() pass overwrites
session_variable_presence bool values with "[REDACTED]" due to the
"API_KEY"/"PASSWORD" key-name regex.

Owner step (B): apply deny ACE to the three roots, then re-run this script
to regenerate with dacl_status='observed_with_readonly_true'.

Usage:
    python scripts/capture_r2_pre.py
    python scripts/capture_r2_pre.py --dacl-status observed_with_readonly_true
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from _dataset_resolver import _is_read_only_root  # noqa: E402

from cactus.governance.canonical import canonical_json  # noqa: E402


ROOT_PATHS = {
    "CACTUS_DOCKER_CACHE_ROOT": "E:/docker-bak/cactus/pilot50",
    "CACTUS_REPO_CACHE_ROOT": "E:/cactus-data/repo-cache",
    "CACTUS_SWEBENCH_ROOT": "E:/cactus-data/swebench",
}

SESSION_VAR_KEYS = [
    "CACTUS_LITELLM_API_KEY",
    "CACTUS_LITELLM_BILLING_API_KEY",
    "CACTUS_LITELLM_BILLING_KEY_ALIAS",
    "CACTUS_LITELLM_BILLING_SSH_HOST",
    "CACTUS_LITELLM_BILLING_SSH_PASSWORD",
    "CACTUS_LITELLM_BILLING_SSH_USER",
    "CACTUS_LITELLM_LOG_KEY_ALIAS",
]

BASELINE_PATH = "experiments/snapshots/dacl_baseline_R2_20260925-151621.json"
BASELINE_SHA256 = "f5528851cc19e0554602defbe52c341482b7cd995a842f92fd9a7d3666b1d2cb"


def _utc_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_run(cmd: list[str], timeout: int = 10) -> str:
    try:
        return subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout
        ).stdout.strip()
    except Exception as exc:
        return f"ERR: {exc}"


def _resolve_data_roots() -> dict[str, dict[str, object]]:
    result: dict[str, dict[str, object]] = {}
    for key, raw in ROOT_PATHS.items():
        p = Path(raw)
        result[key] = {
            "path": str(p),
            "read_only": bool(_is_read_only_root(p)),
            "readable": bool(os.access(p, os.R_OK)),
        }
    return result


def _session_var_presence() -> dict[str, bool]:
    return {key: bool(os.environ.get(key)) for key in SESSION_VAR_KEYS}


def _docker_version() -> str:
    docker = shutil.which("docker")
    if not docker:
        return "docker not on PATH"
    out = _safe_run([docker, "version", "--format", "{{.Server.Version}}"])
    if not out or out.startswith("ERR"):
        out = _safe_run([docker, "--version"])
    return out or "unknown"


def _pkg_version(name: str) -> str:
    out = _safe_run(
        [sys.executable, "-m", "pip", "show", name], timeout=15
    )
    for line in out.splitlines():
        if line.lower().startswith("version:"):
            return line.split(":", 1)[1].strip()
    return "unknown"


def build_snapshot(*, phase: str, dacl_status: str) -> dict[str, object]:
    return {
        "schema_version": "2.0",
        "capture_mode": "observed",
        "generated_at": _utc_now(),
        "phase": phase,
        "host_profile": "LOCAL-WIN11-AMD64",
        "platform": platform.platform(),
        "architecture": platform.machine(),
        "processor": platform.processor(),
        "python": platform.python_version(),
        "logical_processors": os.cpu_count(),
        "data_roots": _resolve_data_roots(),
        "session_variable_presence": _session_var_presence(),
        "docker_engine": _docker_version(),
        "swebench_version": _pkg_version("swebench"),
        "pyarrow_version": _pkg_version("pyarrow"),
        "evaluator_dataset_sha256": "958940f3f06dd1cb1d07c9deed7d08e7cb15c43a6d983988f5132e87af028389",
        "task_manifest_sha256": "a78cac6727dd511921b07d87f7bd02ad2bcec06ce7b43c2e8100b79f08b9efb2",
        "secret_values_recorded": False,
        "extra": {
            "dacl_status": dacl_status,
            "dacl_baseline_snapshot": BASELINE_PATH,
            "dacl_baseline_sha256": BASELINE_SHA256,
        },
    }


def write_snapshot(snap: dict[str, object], out_path: Path) -> str:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        canonical_json(snap) + "\n", encoding="utf-8", newline="\n"
    )
    sha = hashlib.sha256(out_path.read_bytes()).hexdigest()
    sidecar = out_path.with_suffix(out_path.suffix + ".sha256")
    sidecar.write_text(f"{sha}  {out_path.name}\n", encoding="utf-8")
    return sha


def main() -> int:
    parser = argparse.ArgumentParser(prog="capture_r2_pre")
    parser.add_argument(
        "--phase",
        default="pre-C1-engineering-validation-r2",
    )
    parser.add_argument(
        "--dacl-status",
        default="pending_reapply",
        choices=("pending_reapply", "observed_with_readonly_true"),
    )
    parser.add_argument(
        "--out",
        default=None,
        help="Output JSON path; default experiments/snapshots/C1-pre-r2-<ts>.json",
    )
    args = parser.parse_args()

    snap = build_snapshot(phase=args.phase, dacl_status=args.dacl_status)

    ts = snap["generated_at"].replace(":", "").replace("-", "")
    suffix = "observed" if args.dacl_status == "observed_with_readonly_true" else "pending_dacl"
    out_path = Path(args.out) if args.out else Path(
        f"experiments/snapshots/C1-pre-r2-{ts}_{suffix}.json"
    )

    sha = write_snapshot(snap, out_path)
    print(f"PRE snapshot written: {out_path}")
    print(f"  SHA-256     : {sha}")
    print(f"  bytes       : {out_path.stat().st_size}")
    print(f"  dacl_status : {snap['extra']['dacl_status']}")
    print(f"  data_roots  : {snap['data_roots']}")
    print(f"  session_var_presence: {snap['session_variable_presence']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())