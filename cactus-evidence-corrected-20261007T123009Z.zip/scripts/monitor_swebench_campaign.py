"""Periodic, append-only monitor for CACTUS SWE-bench RUN bundles."""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path


def snapshot(runs_root: Path) -> dict[str, object]:
    sealed = completed = failed = in_progress = verified = no_records = 0
    for directory in runs_root.glob("RUN-*"):
        manifest = directory / "run_manifest.json"
        if not manifest.exists():
            in_progress += 1
            continue
        sealed += 1
        data = json.loads(manifest.read_text(encoding="utf-8"))
        if data.get("status") == "completed":
            completed += 1
        elif data.get("status") == "failed":
            failed += 1
        billing = directory / "billing" / "litellm_spend.json"
        if billing.exists():
            status = json.loads(billing.read_text(encoding="utf-8")).get("status")
            verified += status == "verified_cost"
            no_records += status == "no_records"
    return {
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "sealed": sealed,
        "completed": completed,
        "failed": failed,
        "in_progress": in_progress,
        "verified_cost": verified,
        "no_records": no_records,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--interval", type=int, default=60)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    args.log.parent.mkdir(parents=True, exist_ok=True)
    while True:
        state = snapshot(args.runs)
        with args.log.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(state, ensure_ascii=False) + "\n")
        print(json.dumps(state, ensure_ascii=False), flush=True)
        if args.once:
            return 0
        time.sleep(max(5, args.interval))


if __name__ == "__main__":
    raise SystemExit(main())
