"""Resolve configured local data roots with explicit mutability policy."""

from __future__ import annotations

import os
import json
import shutil
import subprocess
import csv
import re
from pathlib import Path, PurePosixPath
from collections.abc import Mapping, Sequence


WINDOWS_DEFAULTS = {
    "CACTUS_REPO_CACHE_ROOT": Path("E:/cactus-data/repo-cache"),
    "CACTUS_SWEBENCH_ROOT": Path("E:/cactus-data/swebench"),
    "CACTUS_DOCKER_CACHE_ROOT": Path("E:/docker-bak/cactus/pilot50"),
}
POSIX_DEFAULTS = {
    "CACTUS_REPO_CACHE_ROOT": Path("/workspace/repo-cache"),
    "CACTUS_SWEBENCH_ROOT": Path("/workspace/swebench"),
    "CACTUS_DOCKER_CACHE_ROOT": Path("/workspace/docker-cache"),
}
# ``Modify`` denies object writes and deletes.  Delete-child is omitted because
# the deny ACE is inheritable to the data-root contents and denies DELETE there.
_WINDOWS_MUTATING_RIGHTS = {"WD", "AD", "WEA", "WA", "DE"}


def _defaults_for_platform(platform: str | None = None) -> dict[str, Path]:
    return WINDOWS_DEFAULTS if (platform or os.name) == "nt" else POSIX_DEFAULTS


def _unescape_mount_field(value: str) -> str:
    return value.replace("\\040", " ").replace("\\011", "\t").replace("\\012", "\n").replace("\\134", "\\")


def _mount_is_read_only(path: Path, mountinfo: str) -> bool:
    """Return whether the longest matching Linux mount is explicitly read-only."""
    target = PurePosixPath(path.as_posix()).as_posix().rstrip("/") or "/"
    matches: list[tuple[int, bool]] = []
    for line in mountinfo.splitlines():
        fields = line.split()
        try:
            separator = fields.index("-")
            mountpoint = _unescape_mount_field(fields[4]).rstrip("/") or "/"
            options = set(fields[5].split(","))
            options.update(fields[separator + 3].split(","))
        except (IndexError, ValueError):
            continue
        if mountpoint == "/" or target == mountpoint or target.startswith(mountpoint.rstrip("/") + "/"):
            matches.append((len(mountpoint), "ro" in options))
    return max(matches, default=(0, False))[1]


def _acl_denies_mutation(token_identities: set[str], entries: Sequence[Mapping[str, object]]) -> bool:
    """Recognize a deny ACE covering file creation, writes, and deletion."""
    for entry in entries:
        identity = str(entry.get("identity", "")).casefold()
        if identity not in token_identities or str(entry.get("type", "")).lower() != "deny":
            continue
        rights = entry.get("rights", [])
        if isinstance(rights, str):
            rights = re.split(r"[,\s]+", rights)
        if not isinstance(rights, (list, tuple, set)):
            continue
        if _WINDOWS_MUTATING_RIGHTS.issubset({str(right).upper() for right in rights}):
            return True
    return False


def _windows_acl_denies_mutation(path: Path) -> bool:
    """Check the current token against Windows deny ACEs when os.access is inconclusive."""
    whoami = shutil.which("whoami.exe") or shutil.which("whoami")
    icacls = shutil.which("icacls.exe") or shutil.which("icacls")
    if not whoami or not icacls:
        return False
    try:
        groups = subprocess.run(
            [whoami, "/groups", "/fo", "csv", "/nh"],
            check=False,
            capture_output=True,
            text=True,
            timeout=15,
        )
        acl = subprocess.run(
            [icacls, str(path)],
            check=False,
            capture_output=True,
            text=True,
            timeout=15,
        )
        if groups.returncode != 0 or acl.returncode != 0:
            return False
    except (OSError, subprocess.TimeoutExpired):
        return False
    token_identities: set[str] = set()
    for row in csv.reader(groups.stdout.splitlines()):
        if len(row) >= 3:
            token_identities.add(row[0].strip().casefold())
            token_identities.add(row[2].strip().casefold())
    entries: list[dict[str, object]] = []
    for line in acl.stdout.splitlines():
        candidate = line.strip()
        if candidate.casefold().startswith(str(path).casefold()):
            candidate = candidate[len(str(path)) :].strip()
        if ":(" not in candidate:
            continue
        identity, raw_rights = candidate.split(":(", 1)
        flag_groups = re.findall(r"\(([^)]*)\)", "(" + raw_rights)
        flags = {flag.strip().upper() for group in flag_groups for flag in group.split(",")}
        entries.append({"identity": identity.strip(), "type": "deny" if "DENY" in flags else "allow", "rights": flags})
    return _acl_denies_mutation(token_identities, entries)


def _is_read_only_root(path: Path) -> bool:
    """Check effective ACLs on Windows or mount flags on Linux."""
    if os.name == "nt":
        return not os.access(path, os.W_OK) or _windows_acl_denies_mutation(path)
    try:
        mountinfo = Path("/proc/self/mountinfo").read_text(encoding="utf-8")
    except OSError:
        return False
    return _mount_is_read_only(path, mountinfo)


def resolve_data_roots(
    environ: Mapping[str, str] | None = None,
    *,
    require_all: bool = False,
    writable_keys: frozenset[str] = frozenset(),
) -> dict[str, Path]:
    """Return existing readable directories under the declared mutability policy.

    Repository and benchmark inputs normally remain OS-read-only.  A Docker
    archive root may be explicitly declared writable when it lives on a
    filesystem without ACL support (for example, an exFAT backup disk).  That
    exception affects only this access-control check: runtime archive SHA-256,
    image-ID, and frozen digest verification remain mandatory.
    """
    source = os.environ if environ is None else environ
    unknown_writable = set(writable_keys) - set(_defaults_for_platform())
    if unknown_writable:
        raise ValueError("unknown writable data root(s): " + ", ".join(sorted(unknown_writable)))
    resolved: dict[str, Path] = {}
    missing: list[str] = []
    for key, default in _defaults_for_platform().items():
        candidate = Path(source.get(key, str(default))).expanduser()
        if not candidate.is_dir() or not os.access(candidate, os.R_OK):
            missing.append(key)
            continue
        if key not in writable_keys and not _is_read_only_root(candidate.resolve()):
            raise PermissionError(
                f"Configured data root must be mounted or permissioned read-only: {key}"
            )
        resolved[key] = candidate.resolve()
    if require_all and missing:
        raise FileNotFoundError(
            "Required read-only data roots are unavailable: " + ", ".join(missing)
        )
    return resolved


def export_data_roots(
    environ: dict[str, str] | None = None,
    *,
    require_all: bool = False,
    writable_keys: frozenset[str] = frozenset(),
) -> dict[str, str]:
    """Set validated data roots for a child process and return their paths."""
    target = os.environ if environ is None else environ
    resolved = resolve_data_roots(target, require_all=require_all, writable_keys=writable_keys)
    exported = {key: str(path) for key, path in resolved.items()}
    target.update(exported)
    return exported
