"""Archive actual validation outputs and write the Chinese integrity handoff."""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
VALIDATION = ROOT / "paper/build/current_validation"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def generate():
    from scripts.artifact_provenance import write
    instant = datetime.now(timezone.utc)
    stamp = instant.astimezone(timezone(timedelta(hours=8))).strftime("%Y%m%d-%H%M%S")
    generated = instant.strftime("%Y-%m-%dT%H:%M:%SZ")
    base = ROOT / "docs/50tasks" / ("v2.0_" + stamp + "_历史证据核验与论文v1.24质量交接报告")
    machine = base.parent / (base.name + ".json")
    markdown = base.parent / (base.name + ".md")
    archive = base.parent / ("v2.0_" + stamp + "_门禁证据")
    if machine.exists() or archive.exists():
        raise FileExistsError("refusing to overwrite a handoff")
    gates = {}
    for name, output_name in {"publication_gate": "publication_gate_final", "scan_latex": "scan_latex",
                             "schema_validate": "schema_validate", "compileall": "compileall",
                             "version_build": "version_build", "manuscript_audit": "manuscript_audit",
                             "datactl_all": "datactl_all_optimized", "datactl_audit": "datactl_audit_independent"}.items():
        exit_file = VALIDATION / (output_name + "_exit.txt")
        if not exit_file.is_file():
            raise ValueError("validation not finished: " + name)
        code = int(exit_file.read_text(encoding="utf-8-sig").strip())
        gates[name] = {"exit_code": code, "status": "PASS" if code == 0 else "FAIL", "output_prefix": output_name}
    pub = load(VALIDATION / "publication_gate_final.json")
    if pub["status"] != "PASS" or gates["version_build"]["status"] != "PASS":
        raise ValueError("current publication must pass before handoff")
    config_path = ROOT / "paper/publication_sources.json"
    config = load(config_path)
    corpus_path = ROOT / config["sources"]["corpus_summary"]["path"]
    retry_path = ROOT / config["sources"]["retry_summary"]["path"]
    corpus = load(corpus_path)
    retry = load(retry_path)
    ledger = ROOT / "paper/data/publication_values.json"
    corpus_exclusions = corpus["historical_snapshot_exclusion_counts"]
    inventory = [json.loads(line) for line in (ROOT / config["sources"]["retry_inventory"]["path"]).read_text(encoding="utf-8").splitlines()]
    admitted_tasks = {row["task_id"] for row in inventory if row["admitted"]}
    resolved_tasks = ", ".join(retry["resolved_task_ids"])
    registry_source = ROOT / "experiments/derived/result_registry_v2.jsonl"
    old_registry_count = len(registry_source.read_text(encoding="utf-8").splitlines())
    registry_error_count = sum(item.get("count", 0) for item in corpus["registry_issues"])
    citations = load(ROOT / config["sources"]["citation_manifest"]["path"])
    branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=ROOT, text=True).strip()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    if branch != "acm0920":
        raise ValueError("unexpected branch")
    pdfs = [max((ROOT / "pdf").glob(pattern), key=lambda p: p.name)
            for pattern in ("CACTUS_v1.24_*.pdf", "CACTUS_CN_v1.24_*.pdf")]
    from cactus.governance.schema import validate_artifact_provenance
    for version_pdf, compiled in zip(pdfs, (ROOT / "paper/build/main.pdf", ROOT / "paper-cn/build/main.pdf")):
        copy_provenance = load(version_pdf.with_name(version_pdf.name + ".provenance.json"))
        if (validate_artifact_provenance(copy_provenance) or sha(version_pdf) != sha(compiled)
                or copy_provenance["artifact_sha256"] != sha(version_pdf)
                or copy_provenance["generator"]["script_sha256"] != sha(ROOT / "scripts/build_pdf.py")
                or any(sha(ROOT / item["path"]) != item["sha256"] for item in copy_provenance["inputs"])):
            raise ValueError("version PDF copy provenance failed")
    gates["version_copy"] = {"status": "PASS", "exit_code": 0, "scope": "PDF identity, inputs and generator hashes"}
    # Save complete logs at report generation; do not claim a new execution.
    archive.mkdir()
    evidence = []
    for source in sorted(VALIDATION.iterdir()):
        if source.is_file() and source.suffix in {".log", ".json", ".txt"}:
            target = archive / source.name
            shutil.copyfile(source, target)
            write(target, [source], Path(__file__), transform={"activity": "archive actual validation output"}, kind="derived_dataset")
            evidence.append(target)
    for source, name in ((ROOT / "paper/build/main.log", "english_latex.log"),
                         (ROOT / "paper-cn/build/main.log", "chinese_latex.log"),
                         (ROOT / "paper/build/publication_refs.blg", "bibliography.log")):
        target = archive / name
        shutil.copyfile(source, target)
        write(target, [source], Path(__file__), transform={"activity": "archive actual successful build log"}, kind="derived_dataset")
        evidence.append(target)
    audit_lines = (VALIDATION / "datactl_audit_independent.log").read_text(encoding="utf-8", errors="replace").splitlines()
    audit_codes = Counter(line.split()[1] for line in audit_lines if line.startswith(("CRITICAL ", "WARNING ")))
    latex = {}
    for lang, folder in (("en", "paper"), ("cn", "paper-cn")):
        log = (ROOT / folder / "build/main.log").read_text(encoding="utf-8", errors="replace")
        pages = re.search(r"Output written.*?\((\d+) pages?", log)
        latex[lang] = {"pages": int(pages.group(1)) if pages else None,
                       "overfull": log.count("Overfull"), "undefined": len(re.findall(r"(?:Reference|Citation).*undefined", log)),
                       "warnings": [line for line in log.splitlines() if "Warning" in line]}
    implementation_paths = [ROOT / path for path in (
        "src/cactus/tools/datactl.py", "src/cactus/governance/audit.py", "src/cactus/governance/policy.py",
        "src/cactus/runner/bundle_validator.py", "scripts/audit_evidence_corpus.py", "scripts/generate_publication_values.py",
        "scripts/import_formal_run_bundles.py", "scripts/aggregate_lite50_results.py", "scripts/sync_phase_c_to_paper_data.py",
        "scripts/paper_pipeline.py", "scripts/build_pdf.py", "scripts/audit_manuscript_consistency.py")]
    inputs = [config_path, ledger, corpus_path, retry_path, *pdfs, *implementation_paths, *evidence]
    summary = {"schema_version": "2.0", "generated_at": generated, "report_version": "2.0",
               "branch": branch, "head": head, "workspace": "E:/work/p5-acm", "worktree_switched": False,
               "working_tree_changes": True, "committed_or_pushed_this_round": False,
               "publication_status": pub["status"], "archive_integrity": corpus["archive_integrity"],
               "audit_findings": len([line for line in audit_lines if line.startswith(("CRITICAL ", "WARNING "))]),
               "audit_critical": sum(line.startswith("CRITICAL ") for line in audit_lines),
               "audit_warnings": sum(line.startswith("WARNING ") for line in audit_lines),
               "audit_sensitive_findings": audit_codes.get("DQ-SENSITIVE-001", 0),
               "corpus": corpus, "retry": retry, "gates": gates, "audit_code_counts": dict(sorted(audit_codes.items())),
               "latex": latex, "visual_review": {"en_pages": [1,2,3,4,5], "cn_pages": [1,2], "result": "no clipping or overlap observed"},
               "artifact_hashes": {p.relative_to(ROOT).as_posix(): sha(p) for p in inputs},
               "bounds": ["historical_effectiveness_withdrawn", "retry_supporting_only", "no_best_of_retries_rate",
                          "raw_RUNs_and_frozen_CSV_not_modified", "no_new_paid_experiment", "unit_tests_not_run"]}
    machine.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    table = "\n".join(f"| {name} | {row['status']} | {row['exit_code']} |" for name,row in gates.items())
    bindings = "\n".join(f"| `{p}` | `{digest}` |" for p,digest in summary["artifact_hashes"].items() if not p.startswith("docs/50tasks/"))
    text = f'''# 历史证据核验与论文 v1.24 质量交接报告

- 版本：v2.0
- 生成时间（UTC）：{generated}
- 文件名时间：{stamp}（Asia/Shanghai）；机器来源与 sidecar 使用 UTC 秒级。
- 工作目录：E:/work/p5-acm；分支：{branch}；HEAD：`{head}`。
- 本轮没有新建或切换 worktree，没有启动新付费实验，没有提交或推送。本轮改动保留在当前工作目录。

## 1. 当前结论

当前出版数据来源门禁为 **{pub['status']}**，历史档案完整性为 **{corpus['archive_integrity']}**。二者不能互相替代。新版中英文论文已编译，研究数值全部通过统一账本宏引用；未满足准入的旧效果数据已撤回。不能报告“全库已完全修复通过”。

全库实际读取 {corpus['run_directory_count']} 个目录，其中 {corpus['canonical_run_count']} 个名称以 RUN- 开头；{corpus['verified_bundle_count']} 个通过当前完整性与完整 schema 核验，{corpus['invalid_directory_count']} 个损坏、未完成或为不能正式准入的诊断目录。原始文件保持不变。

旧冻结快照 {corpus['historical_snapshot_rows']} 行没有验证的终止尝试链及当前准入记录，准入 {corpus['historical_snapshot_admitted_rows']} 行。此数表示证据准入状态，不能解释成实际 resolved 数为零。旧 resolved、evaluator-valid 和解决率主张全部撤回；旧 CSV 保留完整 hash 与原值。

独立 retry 的实际结果与全部分组详见本报告 JSON 中 retry 字段；当前准入 {retry['admitted_run_count']} RUN、{len(admitted_tasks)} 唯一任务，其中 {retry['resolved_run_count']} resolved RUN/{len(retry['resolved_task_ids'])} 任务。任务为 {resolved_tasks}。仅作失败任务重试的 supporting 观察，不汇入旧 500 题解决率，不计算最佳重试率。

## 2. 根因与实施修正

1. 旧同步把 completed 且非 resolved 直接推断为 unresolved。逐行关联真实 progress 与官方 evaluator 后，{corpus_exclusions['completed_was_conflated_with_unresolved']} 行存在这一问题，{corpus_exclusions['no_matching_completed_progress_record']} 行没有匹配的 completed 记录；原因有交集，不能相加为全体分类。同步器现在只能写入新 reconciliation 目录，不能覆盖冻结 CSV。
2. 完整 schema 以前未实际执行，旧 registry {old_registry_count} 个记录产生 {registry_error_count} 个字段错误。现在完整校验；不补猜缺字段，不升级证据类型，不改 owner 决策。
3. supporting 曾存在请求即放行的路径；现在从政策推导，缺少 measured/verified/可复现及统计状态时阻断。准入同时核验 source/driver、合同/授权、账单、patch、官方 evaluator 与 raw 一致性。
4. evaluator 分类检查严格整数计数、任务 ID、completed/resolved/unresolved 守恒；拒绝 error、infra、ambiguous、empty patch 及未停止容器。
5. 全库 gate 不再因早期失败跳过其余阶段，也不再固定打印“无 registry/无伪造”PASS。manifest 身份、输出、环境及 checksum 安全路径均检查。
6. 旧重试 sidecar 绑定目录树摘要。验证器现按导入器原有 canonical relative-path/hash map 实际重算，不将目录错误当作文件，也不豁免摘要验证；同一门禁内缓存重复输入摘要以避免重复全库读取。
7. 凭据扫描使用语法与值判断，消除 os.getenv 表达式、类型声明和明确 anonymous FTP 公共占位值的误报；不忽略整个目录或隐藏真实历史 bundle 问题。
8. 旧 CSV 宏/表/图出版路径及旧报告/主张入口已阻断。README、REPRODUCIBILITY、PIPELINE 与项目配置同步当前入口；历史手册明确标为过期，不作当前事实源。

## 3. 数值与创新表述来源矩阵

| 内容 | 真正来源 | 当前使用边界 |
|---|---|---|
| 静态相关性权重、边际效用与 edit-site 上限 | 当前源码 AST 与完整 SHA-256 | 实现参数，不宣称实验最优 |
| retry 数量、排除原因及合同分组 | 固定 inventory、registry、summary；实际重验原 RUN | supporting 描述；排除原因重叠 |
| 全库目录与历史准入状态 | governance 快照及全部原始文件摘要；实际重算 | 历史证据质量描述，不是独立实验样本 |
| 文献及年份/标识 | 已捕获官方页面与 metadata、实际 cited keys、BibTeX 输出 | {citations['total_cited']} 个现用引用；非 arXiv capture 不宣称全部字段都已核验 |
| 表、图、正文研究数值 | publication_values.json → DataValue 宏与同源图生成器 | 未知 ID 编译失败；所有 artifact 有生成时 sidecar |
| 机制整合的贡献 | source-owned edits、supported transactions、admission 链源码 | 描述已实现机制；比较效果、消融与成本优势仍待新证据 |

中英文稿正文、公式、表格、图及参考文献排版内容使用同一宏账本。自动页码/章节号、排版尺寸和作者元数据属于排版语法，不当作实验数据。论文不主张 matched baseline 优势、统计显著性、通用语义检查正确性或普遍解决率提升。

## 4. 实际门禁与论文质量

| 检查 | 状态 | exit code |
|---|---|---|
{table}

英文 {latex['en']['pages']} 页、中文 {latex['cn']['pages']} 页；overfull 数分别为 {latex['en']['overfull']}、{latex['cn']['overfull']}，未定义引用数分别为 {latex['en']['undefined']}、{latex['cn']['undefined']}。已目检全部页面，未见截断/重叠。class 名称及中文 balance 警告保留在 JSON，不能称完全无警告。本轮未运行或新增单元测试；以上为实际数据校验和编译结果。

门禁完整日志与其复制活动 sidecar 保存在同时间戳“门禁证据”目录，报告 JSON 保存各文件完整 SHA-256。审计告警按 code 汇总见 JSON；历史坏 bundle 的 critical 不降级。

## 5. 难点、恢复条件与交接步骤

- 损坏 checksum、缺 manifest/raw、未完成记录及终止尝试链缺失无法由当前目录推测恢复。可恢复时须从原始可信归档取得字节一致证据，另生成新审计/迁移记录；无法恢复则保留 blocked。禁止修改原 RUN、重写旧 checksum 或用猜测填充测量。
- driver/source 不一致的 retry 不进入结果，R10 当前全部不准入。有效 evaluator 只证明评测执行有效，不能代替合同与算法身份验证。
- 对旧 500 题先建立独立、无成功选择偏差的终止尝试链，再完成官方 evaluator、bundle、source、授权、账单与政策准入。缺证据任务不能通过改状态恢复。
- 如需新实验，另行冻结准确 source/合同/授权/镜像/预算与干净 Git 工作目录，通过正式执行门禁；本报告不提供实验授权。用户禁止切换 worktree，任何新建或切换必须先申请。
- 历史图表与旧 provenance 仍可能造成全库 artifact gate 失败。它们未进入当前论文；保留档案后，通过新的生成目录恢复，不覆写历史证据。本轮不把旧手册全量重写为未经证实的新结论。
- 后续先运行 publication、严格 manuscript audit 和完整全库门禁，再更新完整绑定、重建中英文 PDF。当前代码尚未提交，复现必须保留本次源码字节及 artifact sidecar，不能仅使用 HEAD。

## 6. 主要交付与完整摘要

| 文件 | SHA-256 |
|---|---|
{bindings}

原 v1.23 报告保留历史，但其冻结快照效果数字与旧门禁结论已由本报告撤回。本报告及 publication_sources.json 是当前交接入口。
'''
    markdown.write_text(text, encoding="utf-8", newline="\n")
    write(machine, inputs, Path(__file__), transform={"scope": "actual current gates; historical archive failures retained"}, kind="derived_dataset")
    write(markdown, [machine], Path(__file__), transform={"activity": "Chinese handoff from actual machine report"}, kind="derived_dataset")
    print(markdown)
    return summary


if __name__ == "__main__":
    generate()
