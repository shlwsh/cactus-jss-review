"""Background launcher for monitor_r4_live.py.

Used by ``launch_r4_singletask.py`` when an operator wants to inspect the
model stream in real time. Outputs ``[monitor]`` lines to a sidecar log so
they can be tailed from another terminal without flooding the main campaign
stdout.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
log_path = ROOT / "experiments" / "runs" / "_r4_live_monitor_current.log"
log_path.parent.mkdir(parents=True, exist_ok=True)
out = log_path.open("a", encoding="utf-8", buffering=1)
proc = subprocess.Popen(
    [
        str(ROOT / ".venv" / "Scripts" / "python.exe"),
        "-u",
        str(ROOT / "scripts" / "monitor_r4_live.py"),
        "--runs", str(ROOT / "experiments" / "runs"),
        "--interval", "2.0",
        "--log", str(log_path),
    ],
    cwd=str(ROOT),
    stdout=out,
    stderr=subprocess.STDOUT,
    text=True,
)
print(f"monitor started: pid={proc.pid} log={log_path}")
