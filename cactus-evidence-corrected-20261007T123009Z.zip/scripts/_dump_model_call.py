"""Dump key events from trace."""
import json
import sys
from pathlib import Path

trace_path = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260926T120619Z-4BAA1DC9\trace\events.jsonl")
out_dir = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260926T120619Z-4BAA1DC9\trace")

events = []
with trace_path.open("r", encoding="utf-8-sig") as f:
    for ln in f:
        ln = ln.strip()
        if not ln:
            continue
        try:
            events.append(json.loads(ln))
        except Exception as exc:
            print(f"parse error: {exc}", file=sys.stderr)

# Find model_call event
for i, e in enumerate(events):
    if e.get("type") == "model_call":
        payload = e.get("payload", {})
        resp = payload.get("response_text", "")
        # Write response_text to a separate file for inspection
        out_path = out_dir / f"_model_call_resp_{i}.txt"
        out_path.write_text(resp, encoding="utf-8")
        print(f"event[{i}] type=model_call response_text length={len(resp)}")
        print(f"saved to: {out_path}")

# Also dump model_call payload excluding the huge prompt_text
for i, e in enumerate(events):
    if e.get("type") == "model_call":
        payload = dict(e.get("payload", {}))
        if "prompt_text" in payload:
            payload["prompt_text"] = f"<{len(payload.get('prompt_text',''))} chars omitted>"
        out_path = out_dir / f"_model_call_payload_{i}.json"
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"saved payload to: {out_path}")

# And check raw prediction.jsonl
pred_path = out_dir.parent / "raw" / "prediction.jsonl"
if pred_path.exists():
    print(f"\nprediction.jsonl content:")
    print(pred_path.read_text(encoding="utf-8"))
