"""Quick eval using SWE-bench gold patch (ground truth) for engineering-validation tasks.

This bypasses the context-selection + prediction pipeline entirely and directly tests
whether the SWE-bench harness resolves with the gold patch. This verifies:
  1. The Docker image + harness is correctly set up
  2. The task is actually resolvable
  3. No environmental blockers remain

Usage:
  & E:\\work\\p5-acm\\acm\\.venv\\Scripts\\python.exe -u scripts\\_run_gold_eval.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\test-00000-of-00001.parquet")
ENV_FILE = ROOT / "docs" / "llm" / ".env"

TASKS = [
    {
        "task_id": "astropy__astropy-13033",
        "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de",
    },
    {
        "task_id": "astropy__astropy-13236",
        "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13236@sha256:dede759cb182b28dc949fe9ee05d6fd09d032df5a802af190121a8f9cec36b9e",
    },
]
EVAL_TIMEOUT = 1800
TRUSTED_COMMIT = "9ea4f04f96f27c6e668c4a33e6ecfd3030013a3c"


@dataclass
class Result:
    task_id: str
    run_id: str
    resolved: bool
    eval_rc: int
    elapsed: float
    error: str = ""


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(p: Path) -> str:
    import hashlib
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _write_json(p: Path, data: dict) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8", newline="\n",
    )


def _load_env() -> tuple[dict, int]:
    env = os.environ.copy()
    n = 0
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            if "LITELLM" in k.upper() or "API_KEY" in k.upper():
                env[k] = v.strip()
                n += 1
    return env, n


def load_gold_patch(task_id: str) -> str | None:
    """Load the gold patch from the SWE-bench parquet dataset."""
    try:
        import pyarrow.parquet as pq
        table = pq.read_table(str(DATASET))
        for i in range(len(table)):
            row = {col: table.column(col)[i].as_py() for col in table.column_names}
            if row.get("instance_id", "") == task_id:
                return (row.get("patch") or "").strip()
        return None
    except Exception as exc:
        print(f"[gold] Failed to load from parquet: {exc}")
        return None


def run_eval(task_id: str, run_id: str, pinned_image: str) -> Result:
    gold_patch = load_gold_patch(task_id)
    if not gold_patch:
        return Result(task_id, run_id, False, -1, 0, "gold patch not found in dataset")

    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)

    # Write gold patch as prediction.jsonl (single-line JSON per SWE-bench harness spec)
    pred_record = {
        "instance_id": task_id,
        "model_name_or_path": "GOLD_PATCH",
        "model_patch": gold_patch,
    }
    pred_path = run_root / "raw" / "prediction.jsonl"
    pred_path.parent.mkdir(parents=True, exist_ok=True)
    pred_path.write_text(json.dumps(pred_record, ensure_ascii=False) + "\n", encoding="utf-8")

    # Write environment snapshots
    import platform
    now = utc_now()
    pre = {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "pre", "run_id": run_id,
        "platform": platform.platform(), "architecture": platform.machine(),
        "python": platform.python_version(),
    }
    _write_json(run_root / "environment.pre.json", pre)
    _write_json(run_root / "environment.post.json", {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "post", "run_id": run_id,
        "platform": platform.platform(), "architecture": platform.machine(),
        "python": platform.python_version(),
    })

    # Run evaluation
    logs_dir = run_root / "logs"
    eval_dir = run_root / "evaluation"
    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(pred_path),
        "--instance", task_id,
        "--pinned-image", pinned_image,
        "--run-id", run_id,
        "--workers", "1",
        "--timeout", "1800",
        "--report-dir", str(eval_dir),
    ]
    print(f"[eval:{task_id}] starting gold patch eval", flush=True)

    env, _ = _load_env()
    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd, cwd=str(ROOT), env=env,
            capture_output=True, text=True,
            timeout=EVAL_TIMEOUT, check=False,
        )
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - t0
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace")
        stderr = (exc.stderr or b"").decode("utf-8", errors="replace")
        (logs_dir / "evaluate.stdout.log").write_text(stdout + "\n[__TIMEOUT__]", encoding="utf-8")
        (logs_dir / "evaluate.stderr.log").write_text(stderr + f"\n[__TIMEOUT__ after {EVAL_TIMEOUT}s]", encoding="utf-8")
        return Result(task_id, run_id, False, -1, elapsed, f"Timeout after {EVAL_TIMEOUT}s")

    elapsed = time.monotonic() - t0
    (logs_dir / "evaluate.stdout.log").write_text(proc.stdout, encoding="utf-8")
    (logs_dir / "evaluate.stderr.log").write_text(proc.stderr, encoding="utf-8")

    # Check result
    reports = sorted(eval_dir.glob(f"*.{run_id}.json"))
    resolved = False
    if reports:
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            resolved = int(rep.get("resolved_instances", 0)) > 0
            print(f"[eval:{task_id}] resolved={resolved} ({elapsed:.0f}s): {reports[0].name}", flush=True)
        except Exception as exc:
            print(f"[eval:{task_id}] report parse error: {exc}", flush=True)

    # Write result.json and manifest
    raw_data = {
        "task_id": task_id,
        "repo_id": "astropy/astropy",
        "base_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3",
        "evaluator_exit_code": proc.returncode,
        "evaluator_valid": proc.returncode == 0,
        "resolved": resolved,
        "prediction_hash": _sha256(pred_path),
        "source": "gold_patch",
    }
    raw = {
        "schema_version": "2.0", "run_id": run_id,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "generated_at": now, "data": raw_data,
        "evidence": {
            "origin_type": "measured", "test_scope": "end_to_end",
            "integrity_status": "verified" if resolved else "incomplete",
            "reproducibility_status": "partial", "statistics_status": "not_required",
        },
    }
    _write_json(run_root / "raw" / "result.json", raw)
    _write_json(run_root / "billing" / "litellm_spend.json",
                {"status": "gold_patch_evaluation", "source": "no_api_call"})

    # Run manifest
    outputs = []
    for item in sorted(run_root.rglob("*")):
        if item.is_file() and item.name != "run_manifest.json":
            outputs.append({
                "path": item.relative_to(run_root).as_posix(),
                "sha256": _sha256(item),
                "media_type": "application/json" if item.suffix == ".json" else "text/plain",
            })
    manifest = {
        "schema_version": "2.0", "study_id": "MSCC-RQ1",
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "campaign_id": f"phase-c1-r4-gold-eval-{utc_now()[:10].replace('-','')}T000000Z-{task_id}",
        "protocol_phase": "C1_ENGINEERING", "protocol_version": "2.0",
        "task_id": task_id, "attempt_index": 0,
        "run_id": run_id,
        "status": "completed" if resolved else "failed",
        "started_at": now, "finished_at": now,
        "code": {"commit": TRUSTED_COMMIT, "dirty": False, "patch_sha256": None},
        "outputs": outputs,
        "evaluator_status": "validated" if proc.returncode == 0 else "not_validated",
        "purpose": "engineering_validation",
        "publishable_result": False,
        "error": None,
        "paired_c1": None,
    }
    _write_json(run_root / "run_manifest.json", manifest)

    # Seal
    sys.path.insert(0, str(ROOT / "src"))
    try:
        from cactus.trace.bundle import RunBundle
        RunBundle(run_root).seal()
        print(f"[seal:{task_id}] sealed", flush=True)
    except Exception as exc:
        print(f"[seal:{task_id}] seal failed: {exc}", flush=True)

    return Result(task_id, run_id, resolved, proc.returncode, elapsed)


def main() -> int:
    import uuid
    ts = utc_now().replace(":", "").replace("-", "")[:15]
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] Gold Patch Eval — {len(TASKS)} tasks", flush=True)
    print(f"{'='*60}", flush=True)

    results: list[Result] = []
    for i, cfg in enumerate(TASKS):
        task_id = cfg["task_id"]
        run_id = f"RUN-{ts}Z-{uuid.uuid4().hex[:8].upper()}"
        print(f"\n[Task {i+1}/{len(TASKS)}] {task_id}", flush=True)
        print(f"  Image: {cfg['pinned_image']}", flush=True)
        res = run_eval(task_id, run_id, cfg["pinned_image"])
        results.append(res)
        print(f"  Result: resolved={res.resolved} rc={res.eval_rc} elapsed={res.elapsed:.0f}s", flush=True)

    # Summary
    n_ok = sum(1 for r in results if r.resolved)
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] GOLD EVAL: {n_ok}/{len(results)} resolved", flush=True)
    for r in results:
        icon = "PASS" if r.resolved else "FAIL"
        print(f"  [{icon}] {r.task_id}: resolved={r.resolved} rc={r.eval_rc} {r.elapsed:.0f}s", flush=True)
    print(f"{'='*60}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
