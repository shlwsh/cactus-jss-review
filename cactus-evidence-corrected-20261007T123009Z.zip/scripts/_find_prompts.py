"""Find prompt templates in cactus_swebench_predict.py."""
import re
src = open('scripts/cactus_swebench_predict.py', encoding='utf-8').read()
# lines with PROMPT or template strings
lines = src.splitlines()
for i, ln in enumerate(lines, 1):
    if re.search(r'PROMPT|REPLACE_FALLBACK|_build_prompt|template\s*=|f["\']SITES|f["\']REPLACE', ln):
        print(f'{i}: {ln.strip()[:140]}')
print('---')
# locate the "replacement must contain exactly one complete Python statement" string
hits = []
for i, ln in enumerate(lines, 1):
    if 'replacement must contain' in ln or 'no_op_edit' in ln or 'overlap' in ln or 'invalid site' in ln:
        hits.append((i, ln.strip()[:140]))
for i, h in hits[:30]:
    print(f'{i}: {h}')