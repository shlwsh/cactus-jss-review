"""Test maximal_context variant for task 13033.

maximal_context uses select_maximal_context which:
1. Takes ALL units
2. Selects based on mentioned_files from issue
3. Prioritizes files matching mentioned_files

For task 13033, mentioned_files includes:
  - astropy/time.py
  - astropy/timeseries.py  (NOT astropy/timeseries/core.py!)
  
maximal_context WOULD NOT include core.py either!
The issue doesn't explicitly mention astropy/timeseries/core.py.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.task.parser import parse_task
from cactus.selection.maximal_context import select_maximal_context
from cactus.retrieval.literal_anchors import exact_source_anchor_ids


def test_maximal_context():
    """Test if maximal_context variant selects core.py for task 13033."""
    print("=== maximal_context 变体验证 ===")

    # Load task 13033
    manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
    task = None
    with open(manifest) as f:
        for line in f:
            t = json.loads(line)
            if t["task_id"] == "astropy__astropy-13033":
                task = t
                break

    if not task:
        print("ERROR: task 13033 not found")
        return False

    issue = task["issue_text"]
    intent = parse_task(issue)

    print(f"\n任务: {task['task_id']}")
    print(f"mentioned_files: {list(intent.mentioned_files)[:10]}")
    print(f"mentioned_symbols: {list(intent.mentioned_symbols)[:10]}")
    print(f"keywords: {list(intent.keywords)[:10]}")

    # Check if core.py is mentioned
    has_core = any("core.py" in f for f in intent.mentioned_files)
    has_timeseries = any("timeseries" in f.lower() for f in intent.mentioned_files)
    print(f"\n提到 core.py: {has_core}")
    print(f"提到 timeseries 目录: {has_timeseries}")

    # The issue mentions:
    # - astropy/time.py (from import)
    # - astropy/timeseries.py (from import)
    # - com/astropy/astropy/blob/main/CONTRIBUTING.md (from GitHub links)
    # - etc.
    #
    # It does NOT mention astropy/timeseries/core.py explicitly!

    # maximal_context _matches_mentioned uses:
    # 1. Exact path match
    # 2. Basename + parent match
    # If core.py is not in mentioned_files at all, it won't be prioritized

    print("\n结论: maximal_context 变体也无法包含 core.py")
    print("  因为 mentioned_files 中没有 'astropy/timeseries/core.py'")
    print("  只有 'astropy/timeseries.py' (主模块文件)")

    # Check what files would be selected
    print("\n预期的 maximal_context 选择:")
    print("  - astropy/timeseries/sampled.py (TimeSeries 类)")
    print("  - astropy/time.py (Time 类)")
    print("  - MISSING: astropy/timeseries/core.py (_check_required_columns)")

    return False


def analyze_root_cause():
    """Analyze why the bug location is never included."""
    print("\n=== 根因分析 ===")

    print("""
问题的三层叠加:

第1层 (Fix 1 已修复):
  issue_text 中没有 _check_required_columns 这个名字
  → issue_symbol_anchors 为空
  → core.py 不在 issue_symbol_anchor_paths

第2层 (Fix 2 受限于 INHERIT 边缺失):
  INHERIT 索引中没有 TimeSeries → BaseTimeSeries 边
  → 无法通过继承链传播到 core.py

第3层 (Fix 3 需增量修复):
  mentioned_files 中没有 'astropy/timeseries/core.py'
  → literal_anchors = 0
  → maximal_context 也不会优先选择 core.py

真正的修复方案:
  当 issue 提到一个类名(如 TimeSeries)时，
  需要同时包含该类所在文件的所有父类模块。
  
  方案A: 解析类的继承关系，从 import 语句推断父类路径
         from astropy.timeseries.core import BaseTimeSeries
         → 父类在 astropy/timeseries/core.py
  
  方案B: 在 mention_files 中增加 import chain
         从 "from astropy.timeseries import TimeSeries"
         推断 "astropy/timeseries/core.py" 也可能被引用
  
  方案C: 对每个类锚点，检查其 import 语句，
         将被 import 的模块文件加入 mandatory
""")
    return True


def test_import_chain_resolution():
    """Test if we can resolve import chain from class to parent module."""
    print("\n=== Import Chain 解析测试 ===")

    # The issue text for 13033 contains:
    # "from astropy.time import Time"
    # "from astropy.timeseries import TimeSeries"
    #
    # We need to find that:
    # 1. TimeSeries is imported from astropy.timeseries (the __init__.py)
    # 2. TimeSeries inherits BaseTimeSeries
    # 3. BaseTimeSeries is defined in astropy.timeseries.core
    #
    # The current code has _imported_modules_to_paths which
    # converts "from astropy.timeseries import TimeSeries" -> astropy/timeseries/__init__.py
    # but NOT astropy/timeseries/core.py

    from cactus.task.parser import _imported_modules_to_paths

    issue_text = """
    from astropy.time import Time
    from astropy.timeseries import TimeSeries
    """

    paths = _imported_modules_to_paths(issue_text)
    print(f"从 issue 解析的 import 路径: {paths}")
    print(f"  解析结果: astropy/timeseries/__init__.py (正确但不够)")
    print(f"  需要: astropy/timeseries/core.py (父类所在)")

    print("\n需要的增强逻辑:")
    print("  对于每个 import 路径 (如 astropy/timeseries)")
    print("  需要找到该模块的源文件 (如 __init__.py, core.py, etc.)")
    print("  特别是包含类定义的 .py 文件")

    return True


def main():
    print("=" * 70)
    print("R4 任务上下文缺失根因分析")
    print("=" * 70)

    test_maximal_context()
    analyze_root_cause()
    test_import_chain_resolution()

    print("\n" + "=" * 70)
    print("建议的深度修复方案:")
    print("=" * 70)
    print("""
方案: 基于 import chain 的模块传播

1. 从 issue_text 解析 import 语句
   "from astropy.timeseries import TimeSeries"
   → 提取模块: astropy/timeseries

2. 在索引中查找该模块的所有 .py 文件
   → astropy/timeseries/__init__.py
   → astropy/timeseries/sampled.py (TimeSeries)
   → astropy/timeseries/core.py (BaseTimeSeries)

3. 将所有相关模块文件加入 mandatory

这需要修改:
- src/cactus/task/parser.py: 扩展 _imported_modules_to_paths
  返回模块的所有源文件,不仅仅是模块路径

- src/cactus/engine.py: 使用扩展后的文件列表
  在 issue_module_anchors 阶段加入
""")


if __name__ == "__main__":
    main()
