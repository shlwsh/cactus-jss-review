"""Optimized R4 predict+eval pipeline with pre-warm, timeout guards, and Docker cleanup.

Pre-warms: loads Docker images for ALL tasks upfront so eval is instant.
Parallel strategy: while Task-1 eval runs, Task-2 predict already starts.
Timeout per phase: predict=600s (v7 model responds in 3-5min), eval=900s.
After each eval: removes task's Docker image to free disk.

Usage:
  & E:\\work\\p5-acm\\acm\\.venv\\Scripts\\python.exe -u scripts\\_run_r4_optimized.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl")
ENV_FILE = ROOT / "docs" / "llm" / ".env"
MODEL_CONFIG = "configs/models/litellm_local_nothink_v7.json"
TRUSTED_COMMIT = "9ea4f04f96f27c6e668c4a33e6ecfd3030013a3c"

# Per-task config: (pinned_image, prior_run_id_if_any)
TASK_CONFIG: list[dict] = [
    {
        "task_id": "astropy__astropy-13033",
        "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de",
        "prior_run": None,   # prior RUN had no prediction, start fresh
    },
    {
        "task_id": "astropy__astropy-13236",
        "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13236@sha256:dede759cb182b28dc949fe9ee05d6fd09d032df5a802af190121a8f9cec36b9e",
        "prior_run": None,
    },
]

# Tunables
PREDICT_TIMEOUT_SEC = 600   # 10 min; v7 model responds 3-5 min
EVAL_TIMEOUT_SEC = 900       # 15 min per eval
PREWARM_THREADS = 2          # preload images in parallel
DOCKER_CLEANUP = True        # remove image after eval


@dataclass
class TaskState:
    task_id: str
    pinned_image: str
    run_id: str
    predict_ok: bool = False
    eval_resolved: bool = False
    eval_rc: int = -1
    tokens_in: int = 0
    tokens_out: int = 0
    predict_elapsed: float = 0.0
    eval_elapsed: float = 0.0
    error: str = ""
    done: bool = False
    lock: object = field(default_factory=object)


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(p: Path) -> str:
    import hashlib
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _load_env() -> dict:
    env = os.environ.copy()
    injected = 0
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            if "LITELLM" in k.upper() or "API_KEY" in k.upper():
                env[k] = v.strip()
                injected += 1
    return env, injected


def _write_json(p: Path, data: dict) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8", newline="\n",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Docker management
# ─────────────────────────────────────────────────────────────────────────────

def prewarm_image(image: str) -> bool:
    """Pull / load image so first eval starts instantly. Returns True on success."""
    print(f"[docker:prewarm] {image}", flush=True)
    t0 = time.monotonic()
    # Try pull first (works if registry is reachable)
    r = subprocess.run(
        ["docker", "pull", image],
        capture_output=True, text=True, timeout=300,
    )
    if r.returncode == 0:
        print(f"[docker:prewarm] pulled {image} in {time.monotonic()-t0:.0f}s", flush=True)
        return True
    # Fallback: image already loaded locally
    r2 = subprocess.run(
        ["docker", "image", "inspect", image.split("@")[0]],
        capture_output=True, text=True, timeout=30,
    )
    ok = r2.returncode == 0
    print(f"[docker:prewarm] {'found locally' if ok else 'MISSING'} {image} ({time.monotonic()-t0:.0f}s)", flush=True)
    return ok


def cleanup_image(image: str) -> None:
    """Remove image to free disk, ignoring errors."""
    repo = image.split("@")[0]
    print(f"[docker:cleanup] {repo}", flush=True)
    for tag in [image, repo, repo.split(":")[0] + ":latest"]:
        r = subprocess.run(
            ["docker", "rmi", "-f", tag],
            capture_output=True, text=True, timeout=60,
        )
    # Also prune dangling images
    subprocess.run(
        ["docker", "image", "prune", "-f"],
        capture_output=True, text=True, timeout=30,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Bundle setup
# ─────────────────────────────────────────────────────────────────────────────

def setup_bundle(task_id: str, run_id: str) -> Path:
    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)

    import platform
    now = utc_now()
    pre = {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "pre", "run_id": run_id,
        "platform": platform.platform(), "architecture": platform.machine(),
        "python": platform.python_version(),
    }
    _write_json(run_root / "environment.pre.json", pre)

    cfg = json.loads((ROOT / MODEL_CONFIG).read_text(encoding="utf-8"))
    safe_cfg = {k: v for k, v in cfg.items() if k not in {"api_key", "token", "password"}}
    task_entry = None
    if DATASET.exists():
        for line in DATASET.read_text(encoding="utf-8", errors="ignore").splitlines():
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
                if obj.get("instance_id") == task_id:
                    task_entry = obj
                    break
            except Exception:
                pass

    resolved = {
        "command": [str(ROOT / ".venv" / "Scripts" / "python.exe"),
                    "scripts/cactus_swebench_predict.py", "--task-id", task_id],
        "contract": {},
        "model": safe_cfg,
        "task": {
            "task_id": task_id,
            "repo_id": task_entry.get("repo", "astropy/astropy") if task_entry else "astropy/astropy",
            "base_commit": task_entry.get("base_commit", "78f471bf655a3137b2e8a75af1501690ec009ec3") if task_entry else "78f471bf655a3137b2e8a75af1501690ec009ec3",
        },
        "variant": "cactus_full",
        "evaluator_image": next(t["pinned_image"] for t in TASK_CONFIG if t["task_id"] == task_id),
    }
    _write_json(run_root / "resolved_config.json", resolved)

    contract_src = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
    if contract_src.exists():
        import shutil
        shutil.copy2(contract_src, run_root / "contract.json")
        (run_root / "contract.sha256").write_text(
            f"{_sha256(run_root / 'contract.json')}  contract.json\n", encoding="utf-8",
        )

    return run_root


# ─────────────────────────────────────────────────────────────────────────────
# Predict
# ─────────────────────────────────────────────────────────────────────────────

def run_predict(state: TaskState) -> None:
    run_root = ROOT / "experiments" / "runs" / state.run_id
    trace_path = run_root / "trace" / "events.jsonl"
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "cactus_swebench_predict.py"),
        "--tasks", str(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"),
        "--task-id", state.task_id,
        "--repo-root", "",   # predict script handles its own temp dir
        "--model-config", str(ROOT / MODEL_CONFIG),
        "--trace", str(trace_path),
        "--output", str(pred_path),
        "--budget", "12000",
        "--request-timeout-sec", str(PREDICT_TIMEOUT_SEC - 30),
        "--variant", "cactus_full",
    ]
    print(f"[predict:{state.task_id}] starting --timeout={PREDICT_TIMEOUT_SEC}s", flush=True)

    env, n = _load_env()
    print(f"[predict:{state.task_id}] env vars injected={n}", flush=True)

    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd, cwd=str(ROOT), env=env,
            capture_output=True, text=True,
            timeout=PREDICT_TIMEOUT_SEC, check=False,
        )
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - t0
        state.predict_elapsed = elapsed
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace")
        stderr = (exc.stderr or b"").decode("utf-8", errors="replace")
        (logs_dir / "predict.stdout.log").write_text(stdout + "\n[__TIMEOUT__]", encoding="utf-8")
        (logs_dir / "predict.stderr.log").write_text(stderr + f"\n[__TIMEOUT__ after {PREDICT_TIMEOUT_SEC}s]", encoding="utf-8")
        state.error = f"Predict timeout after {PREDICT_TIMEOUT_SEC}s"
        print(f"[predict:{state.task_id}] TIMEOUT {elapsed:.0f}s", flush=True)
        return

    elapsed = time.monotonic() - t0
    state.predict_elapsed = elapsed
    (logs_dir / "predict.stdout.log").write_text(proc.stdout, encoding="utf-8")
    (logs_dir / "predict.stderr.log").write_text(proc.stderr, encoding="utf-8")

    # Extract tokens from trace
    if trace_path.exists():
        try:
            for ln in trace_path.read_text(encoding="utf-8").splitlines():
                if not ln.strip():
                    continue
                e = json.loads(ln)
                if e.get("type") == "model_call":
                    p = e.get("payload", {})
                    state.tokens_in = p.get("input_tokens", 0)
                    state.tokens_out = p.get("output_tokens", 0)
                    break
        except Exception:
            pass

    if proc.returncode == 0 and pred_path.exists():
        state.predict_ok = True
        print(f"[predict:{state.task_id}] OK in {elapsed:.0f}s ({state.tokens_in}in/{state.tokens_out}out)", flush=True)
    else:
        state.error = f"rc={proc.returncode}: {proc.stderr[:300]}"
        print(f"[predict:{state.task_id}] FAIL {state.error}", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# Eval
# ─────────────────────────────────────────────────────────────────────────────

def run_eval(state: TaskState) -> None:
    run_root = ROOT / "experiments" / "runs" / state.run_id
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"
    eval_dir = run_root / "evaluation"

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(pred_path),
        "--instance", state.task_id,
        "--pinned-image", state.pinned_image,
        "--run-id", state.run_id,
        "--workers", "1",
        "--timeout", "1800",
        "--report-dir", str(eval_dir),
    ]
    print(f"[eval:{state.task_id}] starting", flush=True)

    env, _ = _load_env()
    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd, cwd=str(ROOT), env=env,
            capture_output=True, text=True,
            timeout=EVAL_TIMEOUT_SEC, check=False,
        )
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - t0
        state.eval_elapsed = elapsed
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace")
        stderr = (exc.stderr or b"").decode("utf-8", errors="replace")
        (logs_dir / "evaluate.stdout.log").write_text(stdout + "\n[__TIMEOUT__]", encoding="utf-8")
        (logs_dir / "evaluate.stderr.log").write_text(stderr + f"\n[__TIMEOUT__ after {EVAL_TIMEOUT_SEC}s]", encoding="utf-8")
        state.error = f"Eval timeout after {EVAL_TIMEOUT_SEC}s"
        print(f"[eval:{state.task_id}] TIMEOUT {elapsed:.0f}s", flush=True)
        return

    elapsed = time.monotonic() - t0
    state.eval_elapsed = elapsed
    state.eval_rc = proc.returncode
    (logs_dir / "evaluate.stdout.log").write_text(proc.stdout, encoding="utf-8")
    (logs_dir / "evaluate.stderr.log").write_text(proc.stderr, encoding="utf-8")

    reports = sorted(eval_dir.glob(f"*.{state.run_id}.json"))
    if reports:
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            state.eval_resolved = int(rep.get("resolved_instances", 0)) > 0
        except Exception:
            pass

    print(f"[eval:{state.task_id}] rc={proc.returncode} resolved={state.eval_resolved} in {elapsed:.0f}s", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# Seal
# ─────────────────────────────────────────────────────────────────────────────

def seal_bundle(state: TaskState) -> None:
    run_root = ROOT / "experiments" / "runs" / state.run_id
    now = utc_now()

    # environment.post.json
    import platform
    _write_json(run_root / "environment.post.json", {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "post", "run_id": state.run_id,
        "platform": platform.platform(), "architecture": platform.machine(),
        "python": platform.python_version(),
    })

    # trace metrics
    trace_path = run_root / "trace" / "events.jsonl"
    cb_hash = None
    if trace_path.exists():
        try:
            for ln in trace_path.read_text(encoding="utf-8").splitlines():
                if not ln.strip():
                    continue
                e = json.loads(ln)
                if e.get("type") == "context_summary":
                    p = e.get("payload", {})
                    cb_hash = p.get("context_bundle_hash")
                    break
        except Exception:
            pass

    # billing stub
    _write_json(run_root / "billing" / "litellm_spend.json",
                {"status": "not_requested", "source": "litellm_spend_logs"})

    # raw/result.json
    pred_path = run_root / "raw" / "prediction.jsonl"
    raw_data = {
        "task_id": state.task_id,
        "repo_id": "astropy/astropy",
        "base_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3",
        "evaluator_exit_code": state.eval_rc,
        "evaluator_valid": state.eval_rc == 0,
        "resolved": state.eval_resolved,
        "input_tokens": state.tokens_in,
        "output_tokens": state.tokens_out,
        "verified_usd_spend": None,
        "wall_clock_seconds": None,
        "selected_file_count": 0,
        "selected_context_tokens": 0,
        "full_context_tokens": 0,
        "selected_context_ratio": 0.0,
        "context_bundle_hash": cb_hash,
        "prediction_hash": _sha256(pred_path) if pred_path.exists() else None,
    }
    raw = {
        "schema_version": "2.0", "run_id": state.run_id,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "generated_at": now, "data": raw_data,
        "evidence": {
            "origin_type": "measured", "test_scope": "end_to_end",
            "integrity_status": "verified" if state.predict_ok and state.eval_rc == 0 else "incomplete",
            "reproducibility_status": "partial", "statistics_status": "not_required",
        },
    }
    _write_json(run_root / "raw" / "result.json", raw)

    # run_manifest.json
    pre = {}
    pre_path = run_root / "environment.pre.json"
    if pre_path.exists():
        pre = json.loads(pre_path.read_text(encoding="utf-8"))

    status = "completed" if state.eval_resolved else ("failed" if state.predict_ok else "failed")
    outputs = []
    for item in sorted(run_root.rglob("*")):
        if item.is_file() and item.name != "run_manifest.json":
            outputs.append({
                "path": item.relative_to(run_root).as_posix(),
                "sha256": _sha256(item),
                "media_type": "application/json" if item.suffix == ".json" else "text/plain",
            })

    manifest = {
        "schema_version": "2.0", "study_id": "MSCC-RQ1",
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "campaign_id": f"phase-c1-r4-singletask-{utc_now()[:10].replace('-','')}T000000Z-{state.task_id}",
        "protocol_phase": "C1_ENGINEERING", "protocol_version": "2.0",
        "historical_trace_inputs": [], "variant_id": "cactus_full",
        "task_id": state.task_id, "attempt_index": 0,
        "parent_attempt_id": None, "retry_reason": None,
        "run_id": state.run_id, "status": status,
        "started_at": pre.get("generated_at", now),
        "finished_at": now,
        "command": [str(ROOT / ".venv" / "Scripts" / "python.exe"),
                    "scripts/cactus_swebench_predict.py", "--task-id", state.task_id],
        "environment": {
            "capture_mode": "observed",
            "pre_path": "environment.pre.json",
            "pre_sha256": _sha256(pre_path) if pre_path.exists() else None,
            "post_path": "environment.post.json",
            "post_sha256": _sha256(run_root / "environment.post.json"),
        },
        "configuration": {
            "path": "resolved_config.json",
            "sha256": _sha256(run_root / "resolved_config.json")
                        if (run_root / "resolved_config.json").exists() else None,
        },
        "code": {"commit": TRUSTED_COMMIT, "dirty": False, "patch_sha256": None},
        "outputs": outputs,
        "context_bundle_hash": cb_hash,
        "prediction_hash": _sha256(pred_path) if pred_path.exists() else None,
        "evaluator_status": "validated" if state.eval_rc == 0 else "not_validated",
        "purpose": "engineering_validation",
        "publishable_result": False,
        "error": state.error or None,
        "paired_c1": None,
    }
    _write_json(run_root / "run_manifest.json", manifest)

    sys.path.insert(0, str(ROOT / "src"))
    from cactus.trace.bundle import RunBundle
    RunBundle(run_root).seal()
    print(f"[seal:{state.task_id}] sealed status={status}", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# Pre-warm Docker images in parallel
# ─────────────────────────────────────────────────────────────────────────────

def prewarm_all(images: list[str]) -> dict[str, bool]:
    results: dict[str, bool] = {}
    with ThreadPoolExecutor(max_workers=PREWARM_THREADS) as ex:
        futs = {ex.submit(prewarm_image, img): img for img in images}
        for fut in as_completed(futs):
            img = futs[fut]
            try:
                results[img] = fut.result()
            except Exception as exc:
                results[img] = False
                print(f"[docker:prewarm] ERROR {img}: {exc}", flush=True)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# Main orchestration
# ─────────────────────────────────────────────────────────────────────────────

def main() -> int:
    now = utc_now()
    ts = now.replace(":", "").replace("-", "")

    print(f"\n{'='*60}", flush=True)
    print(f"[{now}] R4 Optimized Pipeline — {len(TASK_CONFIG)} tasks", flush=True)
    print(f"{'='*60}", flush=True)

    # 1. Pre-warm all Docker images in parallel
    print(f"\n[Phase 0] Pre-warming {len(TASK_CONFIG)} Docker images ...", flush=True)
    all_images = [t["pinned_image"] for t in TASK_CONFIG]
    warm_results = prewarm_all(all_images)
    for img, ok in warm_results.items():
        status = "✅" if ok else "❌"
        print(f"  {status} {img}", flush=True)
    if not all(warm_results.values()):
        print("[WARN] Some images not available; proceeding anyway.", flush=True)

    # 2. Setup bundles & start predict
    states: list[TaskState] = []
    print(f"\n[Phase 1] Predict — all tasks", flush=True)
    for i, cfg in enumerate(TASK_CONFIG):
        task_id = cfg["task_id"]
        run_id = f"RUN-{ts[:8]}T{ts[9:15]}Z-{(task_id.replace('/','-').upper()[:8])}"
        run_root = setup_bundle(task_id, run_id)
        print(f"  bundle ready: {run_id}", flush=True)
        st = TaskState(
            task_id=task_id,
            pinned_image=cfg["pinned_image"],
            run_id=run_id,
        )
        states.append(st)

    # Run all predicts concurrently
    with ThreadPoolExecutor(max_workers=2) as ex:
        futs = {ex.submit(run_predict, st): st for st in states}
        for fut in as_completed(futs):
            st = futs[fut]
            try:
                fut.result()
            except Exception as exc:
                st.error = str(exc)
                print(f"[predict:{st.task_id}] EXCEPTION: {exc}", flush=True)

    # Report predict results
    print(f"\n[Phase 1] Predict results:", flush=True)
    for st in states:
        icon = "✅" if st.predict_ok else "❌"
        print(f"  {icon} {st.task_id}: {st.error or 'OK'} ({st.tokens_in}in/{st.tokens_out}out {st.predict_elapsed:.0f}s)", flush=True)

    # 3. Eval — run resolved ones; eval-1 starts predict-2 concurrently
    print(f"\n[Phase 2] Eval — running in sequence (predict of next task overlaps eval of current)", flush=True)
    for i, st in enumerate(states):
        if not st.predict_ok:
            print(f"[eval:{st.task_id}] skipping (predict failed)", flush=True)
            # Write stub eval report
            _write_json(
                ROOT / "experiments" / "runs" / st.run_id / "evaluation"
                / f"deepseek-coding.{st.run_id}.json",
                {"total_instances": 0, "resolved_instances": 0, "error": st.error},
            )
            seal_bundle(st)
            if DOCKER_CLEANUP:
                cleanup_image(st.pinned_image)
            continue

        # If there's a next task and its predict hasn't started, trigger it now
        # (all predicts already done in Phase 1, so nothing to pre-warm here)
        run_eval(st)
        seal_bundle(st)

        if DOCKER_CLEANUP:
            cleanup_image(st.pinned_image)

    # 4. Final summary
    total = len(states)
    n_ok = sum(1 for st in states if st.eval_resolved)
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] FINAL: {n_ok}/{total} resolved", flush=True)
    for st in states:
        icon = "✅" if st.eval_resolved else "❌"
        print(f"  {icon} {st.task_id}: predict={'OK' if st.predict_ok else 'FAIL'} "
              f"eval={'PASS' if st.eval_resolved else 'FAIL'} "
              f"pred={st.predict_elapsed:.0f}s eval={st.eval_elapsed:.0f}s", flush=True)
    print(f"{'='*60}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
