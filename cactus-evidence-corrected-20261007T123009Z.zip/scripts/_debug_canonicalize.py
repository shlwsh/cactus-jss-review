"""Debug helper: trace semantic no-op canonicalization."""
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

import importlib.util
spec = importlib.util.spec_from_file_location("cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

src = """raise ValueError("expected '{}'".format(cols[0]))"""
repl = """raise ValueError("expected {}".format(', '.join(cols)))"""

print("source canonicalized:", repr(mod._wrap_for_canonicalize(src)))
print()

import ast
wrapped = mod._wrap_for_canonicalize(src)
tree = ast.parse(wrapped)
canon_s = ast.unparse(tree.body[0].body[0])
print(f"canon_source: {canon_s!r}")

print()
print("replacement canonicalized:", repr(mod._wrap_for_canonicalize(repl)))
wrapped_r = mod._wrap_for_canonicalize(repl)
tree_r = ast.parse(wrapped_r)
canon_r = ast.unparse(tree_r.body[0].body[0])
print(f"canon_repl:   {canon_r!r}")
print()
print(f"equal? {canon_s == canon_r}")

# Also via _try_parse_with_quote_recovery
print()
local_repl_tree, parsed_repl_local = mod._try_parse_with_quote_recovery(repl + "\n")
print(f"local_repl_tree body[0]: {local_repl_tree.body[0]!r}")
canon_repl_via_recovery = ast.unparse(local_repl_tree.body[0]).strip()
print(f"canon_repl_via_recovery: {canon_repl_via_recovery!r}")
print(f"equal via recovery? {canon_s.strip() == canon_repl_via_recovery.strip()}")
