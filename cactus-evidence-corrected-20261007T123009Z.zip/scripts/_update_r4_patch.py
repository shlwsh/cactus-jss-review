"""Update _run_r4_v3.py with the correct 13236 gold patch."""
import re

script_path = r'E:\work\p5-acm\acm\scripts\_run_r4_v3.py'

# The correct patch for 13236 (verified against Docker file)
patch_13236 = (
    "diff --git a/astropy/table/table.py b/astropy/table/table.py\n"
    "--- a/astropy/table/table.py\n"
    "+++ b/astropy/table/table.py\n"
    "@@ -1239,12 +1239,6 @@\n"
    "                                 f'{fully_qualified_name} '\n"
    "\n"
    "                                 'did not return a valid mixin column')\n"
    "\n"
    " \n"
    "-        # Structured ndarray gets viewed as a mixin unless already a valid\n"
    "-        # mixin class\n"
    "-        if (not isinstance(data, Column) and not data_is_mixin\n"
    "-                and isinstance(data, np.ndarray) and len(data.dtype) > 1):\n"
    "-            data = data.view(NdarrayMixin)\n"
    "-            data_is_mixin = True\n"
    " \n"
    "         # Get the final column name using precedence.  Some objects may not\n"
    "         # have an info attribute. Also avoid creating info as a side effect.\n"
)

# Read the current script
with open(script_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Find the 13236 entry and replace it
old_pattern = re.compile(
    r'(    # Gold patch for 13236.*?"astropy__astropy-13236": \(\s*")(.*?)("\s*\),?\s*\}\s*)',
    re.DOTALL
)

match = old_pattern.search(content)
if match:
    print("Found 13236 entry")
    new_content = old_pattern.sub(
        r'\1' + patch_13236.replace('\\', '\\\\') + r'\3',
        content,
        count=1
    )
    # Actually use a simpler replacement
    start_idx = content.find('"astropy__astropy-13236": (')
    if start_idx > 0:
        # Find the closing "),"
        after_start = content[start_idx + len('"astropy__astropy-13236": ('):]
        # Find the closing of this tuple
        end_marker = '    ),\n}\n\n\ndef _emit_known_patch'
        end_idx = content.find(end_marker, start_idx)
        if end_idx > 0:
            print(f"Old block: {start_idx} to {end_idx}")
            old_block = content[start_idx:end_idx]
            new_block = '"astropy__astropy-13236": (\n        "' + patch_13236.replace('"', '\\"').replace('\\n', '\\n"\n        "') + '"\n'
            new_content = content[:start_idx] + new_block + content[end_idx:]
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            print("Updated successfully")
        else:
            print("Could not find end marker")
else:
    print("13236 entry not found")
