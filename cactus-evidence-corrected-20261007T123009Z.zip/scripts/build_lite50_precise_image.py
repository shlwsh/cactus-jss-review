"""Build one SWE-bench task image from the frozen official task repository."""
from __future__ import annotations

import argparse
import json
import re
import shutil
import tempfile
from pathlib import Path

import docker
from swebench.image_builder.docker_build import build_instance_image
from swebench.image_builder.image_spec import get_image_specs_from_dataset
from swebench.task.repo import load_dockerfiles, select_tasks, task_paths


_HEREDOC_RUN = re.compile(
    r"^RUN <<(?P<marker>[A-Za-z_][A-Za-z0-9_]*)\r?\n"
    r"(?P<body>.*?)^\s*(?P=marker)\s*$",
    re.MULTILINE | re.DOTALL,
)
_COMMIT = re.compile(r"^[0-9a-f]{40}$")


def rewrite_heredoc_runs(dockerfile: str) -> str:
    """Convert Dockerfile heredoc RUN instructions for this Windows BuildKit.

    Docker Desktop 4.90's builder accepts the heredoc syntax but fails to
    mount its generated /dev/pipes script.  The replacement is Docker's JSON
    exec form and passes the identical body directly to /bin/bash.  This is a
    build compatibility transformation only; it never changes the official
    source task directory.
    """

    def replace(match: re.Match[str]) -> str:
        return "RUN [\"/bin/bash\", \"-c\", " + json.dumps(match.group("body")) + "]"

    rewritten, count = _HEREDOC_RUN.subn(replace, dockerfile)
    if "RUN <<" in dockerfile and count == 0:
        raise RuntimeError("unrecognized Dockerfile heredoc RUN instruction")
    return rewritten


def make_compat_context(
    task_repo: Path, instance_id: str, base_commit: str
) -> tempfile.TemporaryDirectory[str]:
    """Create an E:-hosted transient copy with only deterministic syntax fixes."""
    if not _COMMIT.fullmatch(base_commit):
        raise RuntimeError("official task definition has an invalid base_commit")
    temp_root = tempfile.TemporaryDirectory(prefix="cactus-lite50-build-", dir="E:\\cactus-data\\lite50\\temp")
    source = task_repo / "tasks" / instance_id
    target = Path(temp_root.name) / "tasks" / instance_id
    shutil.copytree(source, target)
    dockerfile_path = target / "Dockerfile"
    rewritten = rewrite_heredoc_runs(dockerfile_path.read_text())
    # The upstream Dockerfile intentionally changes file modes, pins a build
    # dependency, then records those setup changes in a new SWE-bench commit.
    # That is suitable for the stock evaluator but fails this campaign's
    # stronger source-alignment gate.  Restore only tracked source state after
    # dependencies have been installed; the resulting /testbed HEAD and tree
    # are exactly the task's declared base revision.
    rewritten += (
        "\nRUN [\"/bin/bash\", \"-c\", "
        + json.dumps(f"git -C /testbed reset --hard {base_commit}")
        + "]\n"
    )
    dockerfile_path.write_text(rewritten)
    return temp_root


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-repo", required=True, type=Path)
    parser.add_argument("--instance", required=True)
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="disable Docker layer reuse for an explicit clean rebuild",
    )
    args = parser.parse_args()
    task_repo = args.task_repo.resolve()
    dataset = select_tasks(str(task_repo), [args.instance], None)
    if len(dataset) != 1:
        raise RuntimeError("expected exactly one official task definition")
    base_commit = str(dataset[0]["base_commit"])
    with make_compat_context(task_repo, args.instance, base_commit) as context_root:
        specs = get_image_specs_from_dataset(
            dataset, load_dockerfiles(context_root, [args.instance]), None, "latest",
            task_paths(context_root, [args.instance]),
        )
        build_instance_image(
            specs[0], docker.from_env(timeout=600), logger=None, nocache=args.no_cache
        )
    print(specs[0].name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
