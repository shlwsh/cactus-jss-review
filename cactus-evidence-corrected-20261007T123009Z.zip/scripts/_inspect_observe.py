import json
with open('experiments/runs/RUN-20260925T124946Z-31DC4349/trace/events.jsonl', encoding='utf-8') as f:
    events = [json.loads(l) for l in f if l.strip()]
for i, e in enumerate(events[:3]):
    print(f'#{i}: type={e["type"]}')
    p = e['payload']
    print(f'  payload keys: {list(p.keys())}')
    for k, v in p.items():
        vs = str(v)
        if len(vs) > 200:
            print(f'    {k}: <len={len(vs)}> {vs[:150]}...')
        else:
            print(f'    {k}: {vs}')
