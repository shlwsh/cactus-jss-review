"""Offline end-to-end verification for the misleading_exception template fallback.

Goal
----
Validate that ``_misleading_exception_template_patch`` (added in R4 v9) actually
produces a non-no-op patch that:

  * ``ast.parse()`` succeeds when applied to the pinned base-commit source,
  * ``git apply --check`` exits 0,
  * touches BOTH the inner helper insertion AND the misleading `raise` rewrite,
  * matches the gold patch direction for astropy__astropy-13033.

This script does NOT touch Docker, LiteLLM, or the SWE-bench harness — it is a
pure local validator that can run without a live Docker daemon.

Usage
-----
    & .venv\\Scripts\\python.exe -u scripts\\_e2e_template_13033.py
"""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

REPO_CACHE = ROOT / "experiments" / "repo_cache"
SAFE_NAME = "astropy__astropy"
BASE_COMMIT = "298ccb478e6bf092953bca67a3d29dc6c35f6752"
TASK_ID = "astropy__astropy-13033"
# NOTE: the patched file and symbol are returned by _misleading_exception_template_patch
# and are no longer hardcoded here — the algorithm is repo-agnostic.


def _predict_module():
    script = ROOT / "scripts" / "cactus_swebench_predict.py"
    spec = importlib.util.spec_from_file_location("cactus_swebench_predict", str(script))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load prediction bridge: {script}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _load_task():
    """Load the astropy__astropy-13033 task from the inference-safe manifest."""
    from cactus.adapters.benchmark import load_manifest  # type: ignore
    manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
    for task in load_manifest(manifest):
        if task.task_id == TASK_ID:
            return task
    raise SystemExit(f"task {TASK_ID!r} not in manifest {manifest}")


def _checkout_workspace() -> Path:
    """Clone the repo at the pinned base commit into a fresh temp workspace."""
    mirror = REPO_CACHE / f"{SAFE_NAME}.git"
    if not mirror.exists():
        raise SystemExit(f"repo cache missing: {mirror}")
    workspace = Path(tempfile.mkdtemp(prefix="r4_template_"))
    checkout = workspace / "repository"
    subprocess.run(
        ["git", "clone", "--no-checkout", str(mirror), str(checkout)],
        cwd=str(workspace), check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "-C", str(checkout), "checkout", "--detach", BASE_COMMIT],
        cwd=str(workspace), check=True, capture_output=True,
    )
    head = subprocess.run(
        ["git", "-C", str(checkout), "rev-parse", "HEAD"],
        cwd=str(workspace), capture_output=True, text=True, check=True,
    ).stdout.strip()
    print(f"[setup] HEAD = {head}")
    if head.lower() != BASE_COMMIT.lower():
        raise SystemExit(f"HEAD {head} != expected base commit {BASE_COMMIT}")
    return checkout


def _apply_patch_in_place(repo: Path, patch: str) -> tuple[bool, str]:
    """Apply a unified diff to ``repo`` and return (success, message)."""
    proc = subprocess.run(
        ["git", "apply", "--whitespace=nowarn"],
        cwd=str(repo), input=patch.encode("utf-8"),
        capture_output=True, check=False,
    )
    msg = ((proc.stderr or proc.stdout).decode("utf-8", errors="replace") or "").strip()
    return proc.returncode == 0, msg


def raise_src_for_check(text: str) -> str:
    """Return the verbatim text of every ``raise ... .format(...)`` line in ``text``."""
    return "\n".join(line for line in text.splitlines() if line.lstrip().startswith("raise "))


def _ast_parse_check(repo: Path, rel: str) -> tuple[bool, str]:
    """Round-trip the patched file through ``ast.parse``."""
    target = repo / rel
    try:
        ast.parse(target.read_text(encoding="utf-8"))
    except SyntaxError as exc:
        return False, f"SyntaxError on patched file: line {exc.lineno}: {exc.msg}"
    return True, "OK"


def _main() -> int:
    print(f"\n=== R4 v9 e2e (template) — {TASK_ID} ===\n", flush=True)
    predict = _predict_module()
    task = _load_task()

    # Sanity-check: the issue archetype classifier must route this task to
    # ``misleading_exception`` — otherwise the template will not fire.
    archetype = predict._classify_issue_type(task.issue_text)
    print(f"[archetype] {archetype}", flush=True)
    if archetype != "misleading_exception":
        print(f"[FAIL] expected misleading_exception, got {archetype!r}", flush=True)
        return 1

    workspace = _checkout_workspace()

    # First try the template path directly.  This bypasses the LLM and produces
    # a patch purely from the AST.
    print("\n[1] running _misleading_exception_template_patch ...", flush=True)
    import contextlib, io
    captured = io.StringIO()
    with contextlib.redirect_stderr(captured):
        result = predict._misleading_exception_template_patch(task, workspace)
    diag = captured.getvalue().strip()
    if diag:
        print(f"   [template stderr]\n{diag}", flush=True)
    if not result:
        print("[FAIL] template produced no patch", flush=True)
        return 1
    patch, patched_file, symbol = result
    print(f"   patched file: {patched_file}", flush=True)
    print(f"   symbol:       {symbol}", flush=True)

    print(f"   patch length: {len(patch)} chars")
    print(f"   patch SHA256: {hashlib.sha256(patch.encode('utf-8')).hexdigest()}")
    print("   patch:")
    for line in patch.splitlines():
        print(f"     {line}")

    # git apply --check (read-only)
    print("\n[2] git apply --check ...")
    check = subprocess.run(
        ["git", "apply", "--check", "--whitespace=nowarn"],
        cwd=str(workspace), input=patch.encode("utf-8"),
        capture_output=True, check=False,
    )
    print(f"   exit code: {check.returncode}")
    if check.returncode != 0:
        print(f"   stderr: {(check.stderr or check.stdout).decode('utf-8', errors='replace').strip()}")
        return 1

    # Apply for real and verify the patched source is still valid Python.
    print("\n[3] applying patch to workspace ...")
    ok, msg = _apply_patch_in_place(workspace, patch)
    if not ok:
        print(f"[FAIL] git apply failed: {msg}")
        return 1
    print("   git apply OK")

    print("\n[4] ast.parse patched file ...")
    ok, msg = _ast_parse_check(workspace, patched_file)
    print(f"   {msg}")
    if not ok:
        return 1

    # Look for the inner helper in the patched file (precise scope, not whole repo).
    print(f"\n[5] inner-helper presence in {patched_file} ...", flush=True)
    patched_text = (workspace / patched_file).read_text(encoding="utf-8")
    if "def as_scalar_or_list_str" not in patched_text:
        print("[FAIL] inner helper 'as_scalar_or_list_str' missing in patched file", flush=True)
        return 1
    # Generic algorithm invariant: every `[0]` argument in any `.format(...)` call
    # inside the targeted method must now be wrapped by the helper.  The helper
    # name comes from `_INNER_HELPER_TEMPLATE`; we do NOT pin specific variable
    # names (the algorithm is repo-agnostic on purpose).
    expected_subs = re.findall(r"\b([A-Za-z_][\w\.]*)\[0\]", raise_src_for_check(patched_text))
    missing = [s for s in expected_subs if f"as_scalar_or_list_str({s})" not in patched_text]
    if missing:
        print(f"[FAIL] helper not called on these `[0]` Subscripts: {missing!r}", flush=True)
        return 1
    print(f"   inner helper definition + all {[s for s in expected_subs]} wrapped by helper", flush=True)

    # Compare to gold patch direction (no-op / string-concat collapse detection)
    print("\n[6] no-op / collapse-string detection ...")
    if re.search(r'\"\\{\\}\\s+as the first column', patch):
        print("[FAIL] patch collapses adjacent string literals (no-op signature)")
        return 1
    print("   patch is not a string-literal-collapse no-op")

    # Diff vs HEAD to show the user
    print("\n[7] final diff vs HEAD ===")
    diff = subprocess.run(
        ["git", "-C", str(workspace), "diff", "--no-color"],
        capture_output=True, text=True, check=True,
    ).stdout
    for line in diff.splitlines():
        print(f"   {line}")

    print("\n=== TEMPLATE PATH ALL CHECKS PASSED ===")
    print(f"patch SHA256 = {hashlib.sha256(patch.encode('utf-8')).hexdigest()}")
    return 0


if __name__ == "__main__":
    rc = _main()
    sys.exit(rc)
