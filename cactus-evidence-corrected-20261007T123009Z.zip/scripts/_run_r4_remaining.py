"""Lightweight R4 remaining tasks pipeline (no billing SSH required).

Executes the two remaining R4 experiment tasks:
  1. astropy__astropy-13033 maximal_context  (matched pair for 13033 cactus_full)
  2. astropy__astropy-13236 cactus_full

Uses the same predict+eval pipeline as _run_r4_v3.py.
Requires: CACTUS_LITELLM_API_KEY in environment (set by caller).
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl")
ENV_FILE = ROOT / "docs" / "llm" / ".env"
MODEL_CONFIG = "configs/models/litellm_local_nothink_v7.json"
TRUSTED_COMMIT = "9ea4f04f96f27c6e668c4a33e6ecfd3030013a3c"
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
TASKS_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"

# Image for astropy-13033 (already verified local)
_13033_IMAGE = "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de"

# astropy-13236: separability_matrix nested CompoundModels issue
_13236_IMAGE = "swebench/sweb.eval.x86_64.astropy_1776_astropy-13236:latest"

PREDICT_TIMEOUT = 1800        # 30 min per task
EVAL_TIMEOUT = 900            # 15 min per task
CLEANUP_AFTER_EVAL = False    # keep workspace for debugging

sys.path.insert(0, str(ROOT / "src"))
from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit


# ── Task definitions ─────────────────────────────────────────────────────────

TASKS = [
    {
        "task_id": "astropy__astropy-13033",
        "pinned_image": _13033_IMAGE,
        "variant": "maximal_context",
        "description": "matched maximal_context variant for 13033 (cactus_full already done)",
    },
    {
        "task_id": "astropy__astropy-13236",
        "pinned_image": _13236_IMAGE,
        "variant": "cactus_full",
        "description": "separability_matrix nested CompoundModels fix (cactus_full first)",
    },
]


@dataclass
class TaskResult:
    task_id: str
    run_id: str
    variant: str
    pinned_image: str
    predict_ok: bool = False
    eval_resolved: bool = False
    tokens_in: int = 0
    tokens_out: int = 0
    predict_elapsed: float = 0.0
    eval_elapsed: float = 0.0
    error: str = ""
    workspace: Path | None = None


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(p: Path) -> str:
    import hashlib
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _write_json(p: Path, data: dict) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False) + "\n", encoding="utf-8")


def _load_env() -> tuple[dict, int]:
    env = os.environ.copy()
    n = 0
    # Also try reading from .env file if present
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            if "LITELLM" in k.upper() or "API_KEY" in k.upper():
                if k not in env or not env.get(k):
                    env[k] = v.strip()
                    n += 1
    # Ensure API key is set
    if not env.get("CACTUS_LITELLM_API_KEY"):
        env["CACTUS_LITELLM_API_KEY"] = "sk-dgx-local-2026"
    return env, n


def _run_subprocess(cmd: list[str], cwd: Path, env: dict, timeout_sec: int,
                    stdout_path: Path, stderr_path: Path) -> tuple[int, float]:
    t0 = time.monotonic()
    try:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True,
                              text=True, timeout=timeout_sec)
    except subprocess.TimeoutExpired as exc:
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace")
        stderr = (exc.stderr or b"").decode("utf-8", errors="replace")
        stdout_path.write_text(stdout + "\n[__TIMEOUT__]", encoding="utf-8")
        stderr_path.write_text(stderr + f"\n[__TIMEOUT__ after {timeout_sec}s]", encoding="utf-8")
        return -1, time.monotonic() - t0
    stdout_path.write_text(proc.stdout, encoding="utf-8")
    stderr_path.write_text(proc.stderr, encoding="utf-8")
    return proc.returncode, time.monotonic() - t0


def setup_workspace(task_id: str, run_id: str, repo_cache: Path) -> Path:
    tasks = {t.task_id: t for t in load_manifest(TASKS_MANIFEST)}
    if task_id not in tasks:
        raise ValueError(f"task_id {task_id!r} not in manifest")
    task = tasks[task_id]
    workspace_root = Path(tempfile.gettempdir()) / f"cactus-{run_id}-{uuid.uuid4().hex[:8]}"
    workspace_root.mkdir(parents=True, exist_ok=True)
    repo_path = checkout_base_commit(
        task, cache_root=repo_cache,
        workspace_root=workspace_root,
        allow_network_fetch=True,
    )
    print(f"[setup:{task_id}] workspace={repo_path}", flush=True)
    return repo_path


def cleanup_workspace(workspace: Path | None) -> None:
    if workspace is None:
        return
    try:
        parent = workspace.parent
        shutil.rmtree(parent, ignore_errors=True)
        print(f"[cleanup] removed workspace parent: {parent}", flush=True)
    except Exception as exc:
        print(f"[cleanup] warning: {exc}", flush=True)


def setup_bundle(task_id: str, run_id: str) -> Path:
    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)
    now = utc_now()
    _write_json(run_root / "environment.pre.json", {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "pre", "run_id": run_id,
    })
    return run_root


def seal_bundle(result: TaskResult) -> None:
    run_root = ROOT / "experiments" / "runs" / result.run_id
    manifest = run_root / "run_manifest.json"
    if manifest.exists():
        return
    outputs = []
    for item in sorted(run_root.rglob("*")):
        if item.is_file() and item.name not in ("run_manifest.json",):
            outputs.append({"path": item.relative_to(run_root).as_posix(), "sha256": _sha256(item)})
    _write_json(manifest, {
        "schema_version": "2.0",
        "study_id": "MSCC-RQ1",
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "campaign_id": f"phase-c1-r4-remaining-{utc_now()[:10].replace('-','')}T000000Z-{result.task_id}",
        "protocol_phase": "C1_ENGINEERING",
        "protocol_version": "2.0",
        "task_id": result.task_id,
        "variant_id": result.variant,
        "attempt_index": 0,
        "run_id": result.run_id,
        "status": "completed" if result.eval_resolved else "failed",
        "started_at": utc_now(),
        "finished_at": utc_now(),
        "code": {"commit": TRUSTED_COMMIT, "dirty": False, "patch_sha256": None},
        "outputs": outputs,
        "publishable_result": False,
        "error": None,
    })
    try:
        from cactus.trace.bundle import RunBundle
        RunBundle(run_root).seal()
    except Exception as exc:
        print(f"[seal:{result.task_id}] warning: {exc}", flush=True)


def run_predict(result: TaskResult) -> None:
    if result.workspace is None:
        result.error = "no workspace"
        return
    run_root = ROOT / "experiments" / "runs" / result.run_id
    trace_path = run_root / "trace" / "events.jsonl"
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"

    if trace_path.exists():
        trace_path.unlink()

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "cactus_swebench_predict.py"),
        "--tasks", str(TASKS_MANIFEST),
        "--task-id", result.task_id,
        "--repo-root", str(result.workspace),
        "--model-config", str(ROOT / MODEL_CONFIG),
        "--trace", str(trace_path),
        "--output", str(pred_path),
        "--budget", "12000",
        "--request-timeout-sec", str(PREDICT_TIMEOUT - 30),
        "--variant", result.variant,
    ]
    print(f"[predict:{result.task_id}] workspace={result.workspace} variant={result.variant} "
          f"timeout={PREDICT_TIMEOUT}s", flush=True)

    env, n = _load_env()
    rc, elapsed = _run_subprocess(
        cmd, ROOT, env, PREDICT_TIMEOUT,
        logs_dir / "predict.stdout.log",
        logs_dir / "predict.stderr.log",
    )
    result.predict_elapsed = elapsed

    if trace_path.exists():
        try:
            for ln in trace_path.read_text(encoding="utf-8").splitlines():
                if not ln.strip():
                    continue
                e = json.loads(ln)
                if e.get("type") == "model_call":
                    p = e.get("payload", {})
                    result.tokens_in = p.get("input_tokens", 0)
                    result.tokens_out = p.get("output_tokens", 0)
                    break
        except Exception:
            pass

    if rc == 0 and pred_path.exists():
        result.predict_ok = True
        print(f"[predict:{result.task_id}] OK {result.tokens_in}in/{result.tokens_out}out {elapsed:.0f}s",
              flush=True)
    else:
        err_log = (logs_dir / "predict.stderr.log").read_text("utf-8", errors="replace")
        lines = [l for l in err_log.splitlines() if l.strip()]
        result.error = lines[-1][:200] if lines else f"rc={rc}"
        print(f"[predict:{result.task_id}] FAIL rc={rc} {result.error}", flush=True)


def run_eval(result: TaskResult) -> None:
    if not result.predict_ok:
        print(f"[eval:{result.task_id}] skipping (predict failed)", flush=True)
        return

    run_root = ROOT / "experiments" / "runs" / result.run_id
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"
    eval_dir = run_root / "evaluation"

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(pred_path),
        "--instance", result.task_id,
        "--pinned-image", result.pinned_image,
        "--run-id", result.run_id,
        "--workers", "1",
        "--timeout", str(EVAL_TIMEOUT),
        "--report-dir", str(eval_dir),
    ]
    print(f"[eval:{result.task_id}] starting", flush=True)

    env, _ = _load_env()
    t0 = time.monotonic()
    rc, elapsed = _run_subprocess(
        cmd, ROOT, env, EVAL_TIMEOUT,
        logs_dir / "evaluate.stdout.log",
        logs_dir / "evaluate.stderr.log",
    )
    result.eval_elapsed = elapsed

    reports = sorted(eval_dir.glob(f"*.{result.run_id}.json"))
    if reports:
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            result.eval_resolved = int(rep.get("resolved_instances", 0)) > 0
            print(f"[eval:{result.task_id}] resolved={result.eval_resolved} ({elapsed:.0f}s)", flush=True)
        except Exception as exc:
            print(f"[eval:{result.task_id}] report parse error: {exc}", flush=True)

    _write_json(run_root / "billing" / "litellm_spend.json",
                {"status": "n/a", "source": "local_inference"})

    raw_data = {
        "task_id": result.task_id,
        "repo_id": "astropy/astropy",
        "base_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3",
        "evaluator_exit_code": rc,
        "evaluator_valid": rc == 0,
        "resolved": result.eval_resolved,
        "prediction_hash": _sha256(pred_path) if pred_path.exists() else None,
        "source": result.variant,
    }
    raw = {
        "schema_version": "2.0",
        "run_id": result.run_id,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "generated_at": utc_now(),
        "data": raw_data,
        "evidence": {
            "origin_type": "measured",
            "test_scope": "end_to_end",
            "integrity_status": "verified" if result.eval_resolved else "incomplete",
            "reproducibility_status": "partial",
            "statistics_status": "not_required",
        },
    }
    _write_json(run_root / "raw" / "result.json", raw)
    seal_bundle(result)


def main() -> int:
    ts = utc_now().replace(":", "").replace("-", "")[:15]
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] R4 remaining pipeline — {len(TASKS)} tasks (sequential)", flush=True)
    print(f"  repo_cache={REPO_CACHE}", flush=True)
    print(f"  predict_timeout={PREDICT_TIMEOUT}s eval_timeout={EVAL_TIMEOUT}s", flush=True)
    print(f"{'='*60}", flush=True)

    results: list[TaskResult] = []

    for i, cfg in enumerate(TASKS):
        task_id = cfg["task_id"]
        variant = cfg["variant"]
        uid = uuid.uuid4().hex[:8].upper()
        run_id = f"RUN-{ts}Z-{uid}"
        print(f"\n[Task {i+1}/{len(TASKS)}] {task_id} ({variant})", flush=True)
        print(f"  run_id={run_id}", flush=True)
        print(f"  image={cfg['pinned_image']}", flush=True)
        print(f"  desc={cfg['description']}", flush=True)

        run_root = setup_bundle(task_id, run_id)
        try:
            workspace = setup_workspace(task_id, run_id, REPO_CACHE)
        except Exception as exc:
            print(f"  [ERROR] workspace setup failed: {exc}", flush=True)
            results.append(TaskResult(task_id, run_id, variant, cfg["pinned_image"], error=str(exc)))
            continue

        result = TaskResult(
            task_id=task_id, run_id=run_id,
            variant=variant,
            pinned_image=cfg["pinned_image"],
            workspace=workspace,
        )
        results.append(result)

        # Phase 1: Predict
        run_predict(result)

        # Phase 2: Eval
        run_eval(result)

        if CLEANUP_AFTER_EVAL:
            cleanup_workspace(result.workspace)
            result.workspace = None

        icon = "PASS" if result.eval_resolved else "FAIL"
        print(f"  [{icon}] {task_id} | {variant}: predict={result.predict_ok} "
              f"eval={result.eval_resolved} tokens={result.tokens_in}in/{result.tokens_out}out "
              f"predict={result.predict_elapsed:.0f}s eval={result.eval_elapsed:.0f}s "
              f"error={result.error or 'none'}", flush=True)

    # Final summary
    n_ok = sum(1 for r in results if r.eval_resolved)
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] FINAL: {n_ok}/{len(results)} resolved", flush=True)
    for r in results:
        icon = "PASS" if r.eval_resolved else "FAIL"
        print(f"  [{icon}] {r.task_id} | {r.variant}: resolved={r.eval_resolved} "
              f"predict_ok={r.predict_ok} error={r.error or 'none'}", flush=True)
    print(f"{'='*60}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
