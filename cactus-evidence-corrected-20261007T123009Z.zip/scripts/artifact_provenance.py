"""Record provenance immediately after an artifact is generated."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def git_commit(root: Path = ROOT) -> str | None:
    result = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True)
    return result.stdout.strip() if result.returncode == 0 else None


def write(path: Path, inputs: list[Path], generator: Path, *, transform: dict, kind: str = "table") -> None:
    from cactus.governance.evidence_locations import resolve_source, logical_source
    path = path.resolve(); generator = generator.resolve()
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    rel = path.relative_to(ROOT).as_posix()
    payload = {"schema_version": "2.0", "artifact_id": ("TAB" if kind == "table" else "DATA") + "-HASH-" + hashlib.sha256(rel.encode()).hexdigest().upper(),
               "artifact_type": kind, "artifact_path": rel, "artifact_sha256": digest(path),
               "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
               "generator": {"script": generator.relative_to(ROOT).as_posix(), "script_sha256": digest(generator),
                             "helper_sha256": digest(Path(__file__)),
                             "source_commit": git_commit()},
               "inputs": [{"path": logical_source(ROOT, p), "sha256": digest(resolve_source(ROOT, logical_source(ROOT, p)))} for p in inputs],
               "transform": transform}
    path.with_name(path.name + ".provenance.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8", newline="\n")
