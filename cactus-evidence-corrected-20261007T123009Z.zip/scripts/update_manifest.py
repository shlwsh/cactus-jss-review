#!/usr/bin/env python3
"""Add 6 new papers to cited_papers_manifest.json."""
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]  # acm/
PAPER = ROOT / "paper"
PAPERS_DIR = ROOT / "data" / "papers"  # acm/data/papers/
MANIFEST_PATH = PAPER / "data" / "scholar" / "cited_papers_manifest.json"
TEX_PATH = PAPER / "main.tex"
BIB_PATH = PAPER / "references.bib"

NEW_PAPERS = [
    {
        "citation_key": "swe_rebench",
        "arxiv_id": "2505.20411",
        "title": "SWE-rebench: An Automated Pipeline for Task Collection and Decontaminated Evaluation of Software Engineering Agents",
        "authors": "Golubev, Alexander and Tien, Nicholas",
        "year": "2025",
        "url": "https://arxiv.org/abs/2505.20411",
        "file": "swe_rebench.pdf",
        "archive_status": "ok",
    },
    {
        "citation_key": "reiter2024apr",
        "arxiv_id": "2405.05455",
        "title": "Automated Program Repair: Emerging Trends Pose and Expose Problems for Benchmarks",
        "authors": "Reiter, Pemma",
        "year": "2024",
        "url": "https://arxiv.org/abs/2405.05455",
        "file": "reiter2024apr.pdf",
        "archive_status": "ok",
    },
    {
        "citation_key": "ceka2026apr",
        "arxiv_id": "2506.08311",
        "title": "Understanding Automated Program Repair Agents Through the Lens of Traceability: An Empirical Study",
        "authors": "Ceka, Ira",
        "year": "2026",
        "url": "https://arxiv.org/abs/2506.08311",
        "file": "ceka2026apr.pdf",
        "archive_status": "ok",
    },
    {
        "citation_key": "li2026contextbench",
        "arxiv_id": "2602.05892",
        "title": "ContextBench: A Benchmark for Context Retrieval in Coding Agents",
        "authors": "Li, Han",
        "year": "2026",
        "url": "https://arxiv.org/abs/2602.05892",
        "file": "li2026contextbench.pdf",
        "archive_status": "ok",
    },
    {
        "citation_key": "malka2026docker",
        "arxiv_id": "2601.12811",
        "title": "Docker Does Not Guarantee Reproducibility",
        "authors": "Malka, Julien",
        "year": "2026",
        "url": "https://arxiv.org/abs/2601.12811",
        "file": "malka2026docker.pdf",
        "archive_status": "ok",
    },
    {
        "citation_key": "siddiq2025repro",
        "arxiv_id": "2512.00651",
        "title": "Large Language Models for Software Engineering: A Reproducibility Crisis",
        "authors": "Siddiq, Mohammed Latif",
        "year": "2025",
        "url": "https://arxiv.org/abs/2512.00651",
        "file": "siddiq2025repro.pdf",
        "archive_status": "ok",
    },
]

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

# Load manifest
manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))

# Remove old metadata_changes that refer to old bib entries
# (not strictly needed but cleaner)

# Add new records
for paper in NEW_PAPERS:
    pdf_path = PAPERS_DIR / paper["file"]
    if not pdf_path.exists():
        print(f"WARNING: {pdf_path} not found, skipping")
        continue
    file_sha = sha256(pdf_path)
    record = {
        "citation_key": paper["citation_key"],
        "url": paper["url"],
        "final_url": paper["url"],
        "official_metadata": {
            "title": paper["title"],
            "author": paper["authors"],
            "year": paper["year"],
            "arxiv_id": paper["arxiv_id"],
        },
        "archive_status": paper["archive_status"],
        "metadata_status": "official_source_captured",
        "file_path": "data/papers/" + paper["file"],
        "sha256": file_sha,
        "file_size_bytes": pdf_path.stat().st_size,
    }
    manifest["records"].append(record)
    print(f"Added {paper['citation_key']}")

# Update total_cited
manifest["total_cited"] = len(manifest["records"])

# Update hashes
manifest["bib_sha256"] = sha256(BIB_PATH)
manifest["tex_sha256"] = sha256(TEX_PATH)

# Update generated_at
manifest["generated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# Write back
MANIFEST_PATH.write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8"
)
print(f"\nUpdated manifest: {MANIFEST_PATH}")
print(f"Total records: {manifest['total_cited']}")
print(f"New bib_sha256: {manifest['bib_sha256']}")
print(f"New tex_sha256: {manifest['tex_sha256']}")
