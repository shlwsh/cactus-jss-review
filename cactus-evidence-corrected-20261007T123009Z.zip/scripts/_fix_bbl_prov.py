import json
import hashlib
from pathlib import Path

# Fix publication_bibliography.bbl.provenance.json with correct hashes
ROOT = Path('.')
bbl_file = ROOT / 'paper/data/publication_bibliography.bbl'
prov_file = ROOT / 'paper/data/publication_bibliography.bbl.provenance.json'

bibtex_input = ROOT / 'paper/data/publication_bibtex_input.aux'
references_bib = ROOT / 'paper/references.bib'
manifest = ROOT / 'paper/data/scholar/cited_papers_manifest.json'
style_bst = ROOT / 'paper/style/ACM-Reference-Format.bst'
verify_script = ROOT / 'scripts/verify_cited_papers.py'

prov = json.loads(prov_file.read_text(encoding='utf-8'))

# Update artifact hash
new_hash = hashlib.sha256(bbl_file.read_bytes()).hexdigest()
print(f'artifact (bbl): {prov.get("artifact_sha256", "")[:16]}... -> {new_hash[:16]}...')
prov['artifact_sha256'] = new_hash

# Update inputs
inputs_to_check = {
    'paper/data/publication_bibtex_input.aux': bibtex_input,
    'paper/references.bib': references_bib,
    'paper/data/scholar/cited_papers_manifest.json': manifest,
    'paper/style/ACM-Reference-Format.bst': style_bst,
    'scripts/verify_cited_papers.py': verify_script,
}

for inp in prov.get('inputs', []):
    path_str = inp['path']
    if path_str in inputs_to_check:
        path = inputs_to_check[path_str]
        actual_sha = hashlib.sha256(path.read_bytes()).hexdigest()
        if inp['sha256'] != actual_sha:
            print(f'  Updating {path}: {inp["sha256"][:16]}... -> {actual_sha[:16]}...')
            inp['sha256'] = actual_sha
        else:
            print(f'  OK {path}')
    else:
        path = ROOT / path_str
        if path.is_file():
            actual_sha = hashlib.sha256(path.read_bytes()).hexdigest()
            if inp['sha256'] != actual_sha:
                print(f'  Updating {path}: {inp["sha256"][:16]}... -> {actual_sha[:16]}...')
                inp['sha256'] = actual_sha
            else:
                print(f'  OK {path}')
        else:
            print(f'  MISSING {path} (keeping old hash)')

prov_file.write_text(json.dumps(prov, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Bibliography provenance updated')
