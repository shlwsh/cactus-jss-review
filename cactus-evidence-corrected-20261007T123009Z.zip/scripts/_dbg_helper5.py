"""Direct test of _statement_edit_to_patch with template edits_json."""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

import ast

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]

ws = Path(tempfile.mkdtemp(prefix="cactus-diag-se-"))
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)

source = (repo_path / "astropy" / "timeseries" / "core.py").read_text(encoding="utf-8")

# Find target via the same logic as _misleading_exception_template_patch
rel = "astropy/timeseries/core.py"
candidates = mod._find_misleading_raise_nodes(source, rel)
print(f"candidates: {len(candidates)}", flush=True)

# Pick best
def _score(c):
    m, r, fc = c
    idx0_count = sum(1 for a in fc.args if isinstance(a, ast.Subscript) and isinstance(a.slice, ast.Constant) and a.slice.value == 0)
    has_fmt = any(isinstance(a, ast.Constant) and isinstance(a.value, str) and "{}" in a.value for a in fc.args)
    return idx0_count * 10 + (1 if has_fmt else 0)
candidates = sorted(candidates, key=_score, reverse=True)

method, raise_node, format_call = candidates[0]
print(f"picked: method={method.name} raise @ {raise_node.lineno}", flush=True)

helper_edit = mod._build_template_edit_for_helper_insert(source, method, "as_scalar_or_list_str")
raise_edit = mod._build_template_edit_for_raise(source, method, raise_node, format_call)
print(f"helper_edit = {helper_edit is not None}", flush=True)
print(f"raise_edit = {raise_edit is not None}", flush=True)

# Build edits_json with edits sorted: raise first, then helper (matches function)
edits_json = {
    "edits": [
        {
            "path": rel,
            "symbol": "BaseTimeSeries._check_required_columns",
            "old_statement": raise_edit["old_statement"],
            "replacement": raise_edit["replacement"],
        },
        {
            "path": rel,
            "symbol": "BaseTimeSeries._check_required_columns",
            "old_statement": helper_edit["old_statement"],
            "replacement": helper_edit["replacement"],
        },
    ]
}

payload = json.dumps(edits_json, ensure_ascii=False)
print(f"\n=== payload (first 500 chars) ===\n{payload[:500]}", flush=True)

print(f"\n=== _statement_edit_to_patch ===", flush=True)
try:
    p = mod._statement_edit_to_patch(payload, repo_path)
    print(f"OK len={len(p)}", flush=True)
    print(p[:1500], flush=True)
except Exception as e:
    print(f"FAIL: {type(e).__name__}: {e}", flush=True)
    import traceback
    traceback.print_exc()

import shutil
shutil.rmtree(ws, ignore_errors=True)
