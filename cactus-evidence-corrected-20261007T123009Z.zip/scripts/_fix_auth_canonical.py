"""Fix auth.contract_sha256 to match canonical_json(actual_contract_file)."""

import hashlib
import json

from cactus.governance.canonical import canonical_json

AUTH = "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.session_authorization.json"
CONTRACT = "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"

contract = json.loads(open(CONTRACT).read())
canonical = canonical_json(contract)
canonical_sha = hashlib.sha256(canonical.encode()).hexdigest()

auth = json.loads(open(AUTH).read())
current = auth["contract_sha256"]

print("canonical_json(contract file) SHA:", canonical_sha)
print("current auth.contract_sha256    :", current)
print("match:", canonical_sha == current)

if canonical_sha != current:
    print("REBINDING needed...")
    auth["contract_sha256"] = canonical_sha
    auth["_metadata"]["rebinding_reason"] = (
        "Fix: canonical SHA must match canonical_json(actual_contract_file) exactly; "
        "previously computed from in-memory dict with finalized compose_sha256 "
        "but file was written with intermediate SHA."
    )
    auth["_metadata"]["rebinding_at"] = "2026-09-25T07:53:00Z"
    out = (
        json.dumps(auth, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8")
        + b"\n"
    )
    open(AUTH, "wb").write(out)
    print("written. new auth.contract_sha256:", auth["contract_sha256"])

    # Verify
    auth2 = json.loads(open(AUTH).read())
    canonical2 = canonical_json(json.loads(open(CONTRACT).read()))
    match = (
        hashlib.sha256(canonical2.encode()).hexdigest()
        == auth2["contract_sha256"]
    )
    print("verify match:", match)

    # Also run formal_execution_errors to confirm gate still passes
    from cactus.runner.formal import formal_execution_errors
    import tempfile, os
    from pathlib import Path

    approval = open(AUTH).read()
    with tempfile.NamedTemporaryFile(
        "w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        f.write(approval)
        tmp = f.name
    try:
        errors = formal_execution_errors(
            contract, project_root=Path("."), approval_path=Path(tmp)
        )
        print()
        print("=== formal_execution_errors ===")
        if not errors:
            print("  PASS — no formal execution errors")
        else:
            for e in errors:
                print(f"  FAIL {e}")
    finally:
        os.unlink(tmp)
else:
    print("no rebind needed")
