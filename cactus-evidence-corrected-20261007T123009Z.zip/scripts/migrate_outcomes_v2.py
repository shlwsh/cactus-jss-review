"""Migration script for historical task evidence attribution (v2).

Implements Section 5 & Phase 1 (TASK-003) of CACTUS Rectification Plan v2.
Strictly read-only: reads experiments/runs/RUN-*, never modifies original bundles.
Outputs derived registry to experiments/derived/result_registry_v2.jsonl.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

# Ensure src is on sys.path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cactus.failure_recovery.legacy_mapping import classify_text_v2
from cactus.failure_recovery.taxonomy import (
    EvaluatorStatus,
    ExecutionStatus,
    FailureCode,
    FailureFamily,
    GenerationStatus,
    PatchApplyStatus,
    PatchParseStatus,
    RepairStatus,
    TaskOutcomeV2,
)


def _safe_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _sha256_str(content: str | None) -> str | None:
    if content is None:
        return None
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _sha256_file(path: Path) -> str | None:
    if not path.is_file():
        return None
    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def parse_run_bundle(bundle_dir: Path) -> dict[str, Any]:
    """Inspect all artifacts in a sealed RUN-* directory without modifying it."""
    manifest_data: dict[str, Any] = {}
    for mname in ("run_manifest.json", "manifest.json"):
        mpath = bundle_dir / mname
        if mpath.is_file():
            try:
                manifest_data = json.loads(_safe_read(mpath))
                break
            except Exception:
                pass

    eval_reports: list[dict[str, Any]] = []
    eval_raw_texts: list[str] = []
    eval_report_hashes: list[str] = []
    eval_dir = bundle_dir / "evaluation"
    if eval_dir.is_dir():
        for ef in sorted(eval_dir.glob("*.json")):
            text = _safe_read(ef)
            eval_raw_texts.append(text)
            eval_report_hashes.append(_sha256_str(text) or "")
            try:
                eval_reports.append(json.loads(text))
            except Exception:
                pass

    log_texts: list[str] = []
    logs_dir = bundle_dir / "logs"
    if logs_dir.is_dir():
        for lf in sorted(logs_dir.glob("*")):
            if lf.is_file():
                log_texts.append(_safe_read(lf))

    trace_texts: list[str] = []
    trace_dir = bundle_dir / "trace"
    if trace_dir.is_dir():
        for tf in sorted(trace_dir.glob("*")):
            if tf.is_file():
                trace_texts.append(_safe_read(tf))

    # Prediction / Patch files
    raw_patch_text: str | None = None
    pred_dir = bundle_dir / "prediction"
    if pred_dir.is_dir():
        diffs = list(pred_dir.glob("*.diff"))
        if diffs:
            raw_patch_text = _safe_read(diffs[0])

    # Raw model generation
    raw_model_output: str | None = None
    raw_dir = bundle_dir / "raw"
    if raw_dir.is_dir():
        raw_files = list(raw_dir.glob("*.json")) + list(raw_dir.glob("*.jsonl"))
        if raw_files:
            raw_model_output = _safe_read(raw_files[0])

    # Context bundle hash from resolved_config or manifest
    context_hash = ""
    res_cfg = bundle_dir / "resolved_config.json"
    if res_cfg.is_file():
        context_hash = _sha256_file(res_cfg) or ""
    if not context_hash:
        context_hash = _sha256_str(bundle_dir.name) or ""

    return {
        "bundle_name": bundle_dir.name,
        "manifest": manifest_data,
        "eval_reports": eval_reports,
        "eval_report_hash": eval_report_hashes[0] if eval_report_hashes else None,
        "eval_raw_texts": eval_raw_texts,
        "log_texts": log_texts,
        "trace_texts": trace_texts,
        "raw_patch_text": raw_patch_text,
        "raw_model_output": raw_model_output,
        "context_bundle_hash": context_hash,
    }


def classify_bundle_v2(bundle_info: dict[str, Any]) -> TaskOutcomeV2:
    """Classify a single run bundle strictly following the priority order:

    GOV -> EXE -> ALG -> PAT -> EVA -> RESOLVED / UNRESOLVED
    """
    manifest = bundle_info["manifest"]
    eval_reports = bundle_info["eval_reports"]
    eval_texts = "\n".join(bundle_info["eval_raw_texts"])
    log_texts = "\n".join(bundle_info["log_texts"])
    trace_texts = "\n".join(bundle_info["trace_texts"])
    all_evidence = f"{eval_texts}\n{log_texts}\n{trace_texts}"

    # Extract task instance id
    task_id = manifest.get("task_id") or manifest.get("instance_id")
    if not task_id:
        cmd = manifest.get("command", [])
        if isinstance(cmd, list) and "--task-id" in cmd:
            idx = cmd.index("--task-id")
            if idx + 1 < len(cmd):
                task_id = cmd[idx + 1]
    if not task_id:
        # Fallback from bundle directory name
        bname = bundle_info["bundle_name"]
        parts = bname.split("-")
        task_id = "-".join(parts[2:]) if len(parts) > 2 else bname

    attempt_id = manifest.get("run_id", bundle_info["bundle_name"])
    raw_patch = bundle_info["raw_patch_text"]
    raw_patch_hash = _sha256_str(raw_patch)
    context_bundle_hash = bundle_info["context_bundle_hash"]
    eval_report_hash = bundle_info["eval_report_hash"]

    # Check for empty patch reported in eval_reports
    is_empty_patch = False
    is_resolved = False
    is_unresolved = False
    eval_ran = bool(eval_reports)

    for rep in eval_reports:
        if rep.get("empty_patch_instances", 0) > 0 or (rep.get("empty_patch_ids") and task_id in rep.get("empty_patch_ids", [])):
            is_empty_patch = True
        if rep.get("resolved_instances", 0) > 0 or (rep.get("resolved_ids") and task_id in rep.get("resolved_ids", [])):
            is_resolved = True
        if rep.get("unresolved_instances", 0) > 0 or (rep.get("unresolved_ids") and task_id in rep.get("unresolved_ids", [])):
            is_unresolved = True

    # Check for empty patch evidence in logs
    if "empty patch" in all_evidence.lower() or "patch is empty" in all_evidence.lower():
        is_empty_patch = True

    # 1. GOV checks
    code_info = manifest.get("code", {})
    if code_info.get("dirty") is True:
        return TaskOutcomeV2(
            task_id=task_id,
            attempt_id=attempt_id,
            generation_status=GenerationStatus.NON_EMPTY.value if raw_patch else GenerationStatus.EMPTY.value,
            patch_parse_status=PatchParseStatus.PARSED.value if raw_patch else PatchParseStatus.NO_DIFF_FOUND.value,
            patch_apply_status=PatchApplyStatus.NOT_ATTEMPTED.value,
            execution_status=ExecutionStatus.OK.value,
            evaluator_status=EvaluatorStatus.NOT_RUN.value,
            repair_status=RepairStatus.UNKNOWN.value,
            failure_family=FailureFamily.GOV.value,
            failure_code=FailureCode.GOV002_DIRTY_SOURCE.value,
            raw_patch_hash=raw_patch_hash,
            normalized_patch_hash=raw_patch_hash,
            context_bundle_hash=context_bundle_hash,
            evaluator_report_hash=eval_report_hash,
            is_algorithm_valid=False,
            is_evaluator_valid=False,
            is_primary_analysis_eligible=False,
        )

    # 2. EXE checks (Infrastructure / Container / Gateway)
    for needle, code in (
        ("repository mirror down", FailureCode.EXE003_REPOSITORY_MIRROR_DOWN),
        ("cannot connect to docker daemon", FailureCode.EXE004_CONTAINER_DAEMON_DOWN),
        ("docker daemon down", FailureCode.EXE004_CONTAINER_DAEMON_DOWN),
        ("gateway timeout", FailureCode.EXE001_GATEWAY_TIMEOUT),
        ("rate limit", FailureCode.EXE002_RATE_LIMITED),
    ):
        if needle in all_evidence.lower():
            return TaskOutcomeV2(
                task_id=task_id,
                attempt_id=attempt_id,
                generation_status=GenerationStatus.MODEL_ERROR.value,
                patch_parse_status=PatchParseStatus.NO_DIFF_FOUND.value,
                patch_apply_status=PatchApplyStatus.NOT_ATTEMPTED.value,
                execution_status=ExecutionStatus.CONTAINER_UNAVAILABLE.value if "docker" in needle else ExecutionStatus.MODEL_GATEWAY_TIMEOUT.value,
                evaluator_status=EvaluatorStatus.NOT_RUN.value,
                repair_status=RepairStatus.UNKNOWN.value,
                failure_family=FailureFamily.EXE.value,
                failure_code=code.value,
                raw_patch_hash=raw_patch_hash,
                normalized_patch_hash=raw_patch_hash,
                context_bundle_hash=context_bundle_hash,
                evaluator_report_hash=eval_report_hash,
                is_algorithm_valid=False,
                is_evaluator_valid=False,
                is_primary_analysis_eligible=False,
            )

    # 3. ALG checks (Empty output / Malformed diff)
    if is_empty_patch or not raw_patch or raw_patch.strip() == "":
        return TaskOutcomeV2(
            task_id=task_id,
            attempt_id=attempt_id,
            generation_status=GenerationStatus.EMPTY.value,
            patch_parse_status=PatchParseStatus.NO_DIFF_FOUND.value,
            patch_apply_status=PatchApplyStatus.NOT_ATTEMPTED.value,
            execution_status=ExecutionStatus.OK.value,
            evaluator_status=EvaluatorStatus.NOT_RUN.value,
            repair_status=RepairStatus.UNRESOLVED.value,
            failure_family=FailureFamily.ALG.value,
            failure_code=FailureCode.ALG001_EMPTY_OUTPUT.value,
            raw_patch_hash=None,
            normalized_patch_hash=None,
            context_bundle_hash=context_bundle_hash,
            evaluator_report_hash=eval_report_hash,
            is_algorithm_valid=False,
            is_evaluator_valid=False,
            is_primary_analysis_eligible=True,
            secondary_events=("empty_model_generation",),
        )

    # 4. PAT checks (Patch apply / Alignment)
    for needle, code in (
        ("rejected hunk", FailureCode.PAT001_APPLY_FAILED),
        ("patch apply failed", FailureCode.PAT001_APPLY_FAILED),
        ("git apply failed", FailureCode.PAT001_APPLY_FAILED),
        ("ambiguous alignment", FailureCode.PAT002_ALIGNMENT_AMBIGUOUS),
    ):
        if needle in all_evidence.lower():
            return TaskOutcomeV2(
                task_id=task_id,
                attempt_id=attempt_id,
                generation_status=GenerationStatus.NON_EMPTY.value,
                patch_parse_status=PatchParseStatus.PARSED.value,
                patch_apply_status=PatchApplyStatus.APPLY_FAILED.value,
                execution_status=ExecutionStatus.OK.value,
                evaluator_status=EvaluatorStatus.NOT_RUN.value,
                repair_status=RepairStatus.UNRESOLVED.value,
                failure_family=FailureFamily.PAT.value,
                failure_code=code.value,
                raw_patch_hash=raw_patch_hash,
                normalized_patch_hash=raw_patch_hash,
                context_bundle_hash=context_bundle_hash,
                evaluator_report_hash=eval_report_hash,
                is_algorithm_valid=True,
                is_evaluator_valid=False,
                is_primary_analysis_eligible=True,
                secondary_events=("patch_rejected_before_eval",),
            )

    # 5. EVA checks (Evaluator timeout / crash / OOM)
    for needle, code in (
        ("evaluation timed out", FailureCode.EVA001_TIMEOUT),
        ("evaluator timeout", FailureCode.EVA001_TIMEOUT),
        ("test run timed out", FailureCode.EVA001_TIMEOUT),
        ("out of memory", FailureCode.EVA002_OOM),
        ("oom", FailureCode.EVA002_OOM),
        ("test discovery failed", FailureCode.EVA005_TEST_DISCOVERY_FAILED),
        ("malformed result", FailureCode.EVA004_MALFORMED_RESULT),
    ):
        if needle in all_evidence.lower():
            return TaskOutcomeV2(
                task_id=task_id,
                attempt_id=attempt_id,
                generation_status=GenerationStatus.NON_EMPTY.value,
                patch_parse_status=PatchParseStatus.PARSED.value,
                patch_apply_status=PatchApplyStatus.APPLIED.value,
                execution_status=ExecutionStatus.OK.value,
                evaluator_status=EvaluatorStatus.TIMEOUT.value if "timed out" in needle else EvaluatorStatus.CRASH.value,
                repair_status=RepairStatus.UNKNOWN.value,
                failure_family=FailureFamily.EVA.value,
                failure_code=code.value,
                raw_patch_hash=raw_patch_hash,
                normalized_patch_hash=raw_patch_hash,
                context_bundle_hash=context_bundle_hash,
                evaluator_report_hash=eval_report_hash,
                is_algorithm_valid=True,
                is_evaluator_valid=False,
                is_primary_analysis_eligible=True,
            )

    # 6. Final resolution evaluation (clean evaluator result)
    if is_resolved:
        return TaskOutcomeV2(
            task_id=task_id,
            attempt_id=attempt_id,
            generation_status=GenerationStatus.NON_EMPTY.value,
            patch_parse_status=PatchParseStatus.PARSED.value,
            patch_apply_status=PatchApplyStatus.APPLIED.value,
            execution_status=ExecutionStatus.OK.value,
            evaluator_status=EvaluatorStatus.VALID.value,
            repair_status=RepairStatus.RESOLVED.value,
            failure_family=None,
            failure_code=None,
            raw_patch_hash=raw_patch_hash,
            normalized_patch_hash=raw_patch_hash,
            context_bundle_hash=context_bundle_hash,
            evaluator_report_hash=eval_report_hash,
            is_algorithm_valid=True,
            is_evaluator_valid=True,
            is_primary_analysis_eligible=True,
        )

    # Clean unresolved
    return TaskOutcomeV2(
        task_id=task_id,
        attempt_id=attempt_id,
        generation_status=GenerationStatus.NON_EMPTY.value,
        patch_parse_status=PatchParseStatus.PARSED.value,
        patch_apply_status=PatchApplyStatus.APPLIED.value,
        execution_status=ExecutionStatus.OK.value,
        evaluator_status=EvaluatorStatus.VALID.value if eval_ran else EvaluatorStatus.NOT_RUN.value,
        repair_status=RepairStatus.UNRESOLVED.value,
        failure_family=None if eval_ran else FailureFamily.EVA.value,
        failure_code=None if eval_ran else FailureCode.EVA003_CRASH.value,
        raw_patch_hash=raw_patch_hash,
        normalized_patch_hash=raw_patch_hash,
        context_bundle_hash=context_bundle_hash,
        evaluator_report_hash=eval_report_hash,
        is_algorithm_valid=True,
        is_evaluator_valid=eval_ran,
        is_primary_analysis_eligible=True,
    )


def migrate_history(
    runs_dir: Path,
    output_file: Path,
    *,
    dry_run: bool = False,
) -> list[TaskOutcomeV2]:
    """Migrate all sealed historical bundles into TaskOutcomeV2 records."""
    if not runs_dir.is_dir():
        raise FileNotFoundError(f"Runs directory does not exist: {runs_dir}")

    outcomes: list[TaskOutcomeV2] = []
    bundle_paths = sorted([d for d in runs_dir.iterdir() if d.is_dir() and d.name.startswith("RUN-")])

    for bpath in bundle_paths:
        info = parse_run_bundle(bpath)
        outcome = classify_bundle_v2(info)
        outcomes.append(outcome)

    if not dry_run:
        output_file.parent.mkdir(parents=True, exist_ok=True)
        with output_file.open("w", encoding="utf-8") as f:
            for outcome in outcomes:
                record = outcome.to_dict()
                record["source_registry_version"] = "v1"
                record["classifier_version"] = "v2.0"
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

    return outcomes


def main() -> None:
    parser = argparse.ArgumentParser(description="Migrate historical task evidence into v2 outcome registry.")
    parser.add_argument("--runs-dir", type=Path, default=ROOT / "experiments" / "runs", help="Path to experiments/runs")
    parser.add_argument("--output", type=Path, default=ROOT / "experiments" / "derived" / "result_registry_v2.jsonl", help="Output path for v2 registry")
    parser.add_argument("--dry-run", action="store_true", help="Perform classification without writing file")
    args = parser.parse_args()

    print(f"[MIGRATE] Scanning {args.runs_dir} ...")
    outcomes = migrate_history(args.runs_dir, args.output, dry_run=args.dry_run)
    print(f"[MIGRATE] Processed {len(outcomes)} sealed run bundles.")

    from collections import Counter
    fam_counts = Counter(o.failure_family or "SUCCESS" for o in outcomes)
    rep_counts = Counter(o.repair_status for o in outcomes)
    print(f"[MIGRATE] Failure families: {dict(fam_counts)}")
    print(f"[MIGRATE] Repair status: {dict(rep_counts)}")
    if not args.dry_run:
        print(f"[MIGRATE] Derived registry written to: {args.output}")


if __name__ == "__main__":
    main()
