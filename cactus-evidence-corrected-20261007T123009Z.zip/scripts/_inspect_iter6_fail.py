"""查 ITER6 11910 失败详情"""
import json

p = 'experiments/runs/ITER6-11910/django__django-11910/events.jsonl'
with open(p, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]

print(f'Events: {len(events)}')
print(f'Model calls: {sum(1 for e in events if e.get("type") == "model_call")}')
print()
print('Site/Replacement rejections:')
for e in events:
    t = e.get('type', '')
    if t in ('prediction_sites_rejected', 'prediction_rejected'):
        p2 = e.get('payload', {})
        print(f'  [{t}] attempt={p2.get("attempt")} reason={p2.get("reason", "")[:200]}')
print()
print('Sequence:')
for e in events:
    t = e.get('type', '')
    if t in ('v3_dual_insurance_result',):
        p2 = e.get('payload', {})
        seq = e.get('seq', '?')
        print(f'  seq={seq} {t} attempt={p2.get("attempt")} success={p2.get("success")} corrections={p2.get("correction_rounds")}')