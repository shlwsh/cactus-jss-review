"""Create a non-approved experiment contract and approval request record."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def create(task_manifest: Path, workload: Path, derivation: Path, source_attestation: Path, contract_output: Path, approval_output: Path, experiment_id: str, study_id: str, result_ids: list[str]) -> None:
    source = json.loads(source_attestation.read_text(encoding="utf-8"))
    if not source.get("license") or not source.get("sha256") or not source.get("execution_authorized", False):
        raise ValueError("source attestation must include verified license/hash and execution_authorized=true")
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    contract = {
        "schema_version": "2.0", "experiment_id": experiment_id, "study_id": study_id,
        "purpose": "paper_primary", "source": {"git_commit": commit, "require_clean_tree": True},
        "workload": {"driver": workload.as_posix(), "sha256": sha256(workload), "warmup_sec": 60, "measure_sec": 180, "repetitions": 5, "seed": 1, "task_manifest": {"path": task_manifest.as_posix(), "sha256": sha256(task_manifest), "source_attestation": source_attestation.as_posix()}},
        "derivation": {"script": derivation.as_posix(), "sha256": sha256(derivation)},
        "result_ids": result_ids, "host_profile": "LOCAL-WIN11-AMD64", "tolerance_policy": "PENDING_REVIEW",
    }
    contract_output.parent.mkdir(parents=True, exist_ok=True)
    contract_output.write_text(json.dumps(contract, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    approval = {"schema_version": "1.0", "status": "pending_review", "experiment_id": experiment_id, "approved_by": "", "approved_at": "", "review_notes": "由评审人确认任务集许可、预算、矩阵和统计功效后填写；此记录不可直接启动实验。"}
    approval_output.parent.mkdir(parents=True, exist_ok=True)
    approval_output.write_text(json.dumps(approval, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    for name in ("task_manifest", "workload", "derivation", "source_attestation", "contract_output", "approval_output"):
        parser.add_argument(f"--{name.replace('_', '-')}", type=Path, required=True)
    parser.add_argument("--experiment-id", required=True)
    parser.add_argument("--study-id", required=True)
    parser.add_argument("--result-id", action="append", dest="result_ids", required=True)
    args = parser.parse_args()
    create(args.task_manifest, args.workload, args.derivation, args.source_attestation, args.contract_output, args.approval_output, args.experiment_id, args.study_id, args.result_ids)
    print(f"PASS draft records written: {args.contract_output}, {args.approval_output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
