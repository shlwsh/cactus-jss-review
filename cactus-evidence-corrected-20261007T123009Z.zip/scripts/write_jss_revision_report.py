"""Write the Chinese item-by-item handoff after validation has finished."""
from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]


def write_report(evidence: Path):
    evidence = evidence.resolve()
    evidence.relative_to(ROOT)
    release = json.loads((evidence / "release_result.json").read_text(encoding="utf-8"))
    rendering = json.loads((evidence / "render_validation.json").read_text(encoding="utf-8"))
    validation = json.loads((ROOT / "paper/build/data_summary.json").read_text(encoding="utf-8"))
    test_text = (evidence / "unittest.log").read_text(encoding="utf-8", errors="replace")
    match = re.search(r"Ran (\d+) tests in ([\d.]+)s", test_text)
    if not match:
        raise ValueError("full test run has not finished")
    all_text = (evidence / "datactl_all_final.log").read_text(encoding="utf-8", errors="replace")
    if all_text.rstrip().splitlines()[-1] not in ["PASS", "FAIL"]:
        raise ValueError("final datactl all has not finished")
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%d-%H%M%S")
    timestamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    output = ROOT / "docs/jss" / f"v1.1_{stamp}_JSS审计逐条核查与新版论文交付报告.md"
    pdf = ROOT / release["pdf"]
    package = ROOT / release["source_package"]
    audit = ROOT / "docs/jss/audit-20261006-2108.md"
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    failures = re.findall(r"^(?:FAIL|ERROR): ([^\r\n]+)", test_text, re.MULTILINE)
    checks = [
        ("最终英文 build", "PASS", "build_release.log"),
        ("publication validate 与 PDF provenance", release['status'], "release_validation.log / paper/build/data_summary.json"),
        ("独立 pipeline audit", "PASS", "pipeline_audit.log"),
        ("PDF 渲染与逐页复核", rendering['status'], "render_validation.json / render_final/"),
        ("新增渲染回归测试", "3/3 PASS", "rendering_regression_tests.log"),
        ("完整 unittest discover", "FAIL" if failures else "PASS", f"unittest.log：{match.group(1)} tests，{match.group(2)} 秒"),
        ("validate-schemas", "PASS", "validate_schemas.log；exit 0"),
        ("compileall src scripts tests", "PASS", "compileall.log；exit 0"),
        ("最终 datactl all", all_text.rstrip().splitlines()[-1], "datactl_all_final.log"),
        ("datactl audit", "FAIL", "datactl_audit.log；exit 2"),
    ]
    rows = [
        ("P0-01 数值与 PDF 渲染", "已修正", "宏输出改为纯标量；补齐 df 的宏调用；差值/CI 明确使用百分点；修复宏分支及 abstract 多余闭括号；最终 PDF 零泄漏、零 overfull、零未定义引用。"),
        ("P0-02 Figure 3 旧图", "已重建并收窄", "左侧为任务级概念分类、不显示未核实计数；右侧读取可靠尝试级排除子类，避免将单个子类当作整层总数。所有引用图件同次生成 provenance。"),
        ("P0-03 Astropy 4/6", "已撤回冲突结论", "来源内同时存在 Astropy resolved 任务和全部失败的描述，不能直接把 4 改成 6。正文、表和图撤回不可核实的 repository disparity，不宣称验证了 6/6。"),
        ("P0-04 task/attempt 混用", "已拆表；任务计数仍未建立", "Table 1 为无经验计数的 A/B 概念分类；Table 2 只列 C/D 尝试级排除数；Table 3 明确可信分母。没有伪造完整 50-task disposition 或交集。"),
        ("P0-05 RQ3 failure profiles", "已按证据收窄", "RQ3 只问 retained matched archive 中预测输出格式比例。未经编码的 failure profiles 已删除；无官方 evaluator 的结果不再写作 repair outcomes。"),
        ("P0-06 RQ4", "已删除", "静态 checker 的 TP/FP、时延和 evaluator compute saving 未测量。候选静态预检仅保留为未来工作；fault validation 并入 RQ2，不借改名维持未回答的 RQ。"),
        ("P0-07 fault injection", "已纳入方法与结果；限制已说明", "新增 §5.5、Table 7：20 个 seed、10 个 operator×20、20 controls、TP=200/FN=0/FP=0/TN=20。F01 达到 test admission checker；其他 9 类由 bundle integrity 拦截，不能证明所有语义规则。"),
        ("P1-08 inter-rater reliability", "尚未完成", "未提供真实第二编码者、盲法标签、κ/α 或 adjudication。准备了未填写 JSON 工作表与操作说明；它们不能计作实验结果。taxonomy 主张改为 conceptual。"),
        ("P1-09 evaluator-valid patch rate", "已纠正实际指标", "原派生脚本只检查非空 model_patch 与 diff 标记。改名 prediction-output/format rate；明确不等于有效评估或修复成功。patch 长度由 tokens 改为 characters。"),
        ("P1-10 matched reproducibility", "说明已补；历史快照仍缺", "报告 deterministic sampling ratio、rank quartiles、repository round-robin、无 gold patch、configured alias/provider/温度/重试/输出上限。current config 不能证明历史 immutable provider snapshot，撤回 frozen causal 修复效果主张。"),
        ("P1-11 Open Science", "本地源包已生成；公开链接未完成", "提供带哈希的本地 source package；没有可核实的公开 DOI/anonymous URL。明确源包不能独立通过需原始 RUN 和历史 source 的 admission gate。未向外发布。"),
        ("增强项：multiple comparisons", "已补充", "三项 FACO 比较从 discordant counts 重算 exact p，再做 Holm step-down。MAXIMAL 0.0091、STRUCTURAL 0.0077、BM25 1.0000；bootstrap CI 为 marginal、非 simultaneous。"),
    ]
    text = f"""# CACTUS JSS 审计逐条核查与新版论文交付报告

版本：v1.1  
生成时间（UTC）：{timestamp}  
对应论文：v1.32，英文，{rendering['pages']} 页  
输入审计：`docs/jss/audit-20261006-2108.md`  
范围：JSS 内容与生成一致性整改；保留项目配置的 acmart 模板，未宣称符合全部 JSS 投稿格式要求。

## 结论

旧修复记录没有完成审计要求的全部逐条修正，也没有生成可核验的 v1.32 版本 PDF。此次已完成可由现有证据支持的内容、图表、宏、统计呈现和发布链修订，并生成新版论文。不能宣称所有研究要求已经完成，亦不能给出 GO for submission。

尚未完成的实质项目是：真实独立人工编码及一致性统计、完整历史模型/实验绑定、公开 artifact DOI/匿名链接、可核验的任务级完整 disposition，以及 evaluator-confirmed matched repair study。静态预检与 compute-saving 研究按审计允许的方案删除 RQ4。

## 逐条核查

| 审计条目 | 本次状态 | 修订与边界 |
|---|---|---|
"""
    text += '\n'.join('| '+' | '.join(row)+' |' for row in rows)
    text += """

## 新发现及实证复核

1. 原 `Q=Q` / `p=p` 的直接原因包括 display 已带 Q/p 前缀而正文重复添加，不能用“末尾换行造成数学模式结束”解释。宏现在输出数值，正文统一负责符号与单位；未知 ID 的真实 TeX 编译必须失败。
2. 100×4 预测目录覆盖完整，37/36/23/20 和配对统计能从原 prediction 文件重算；但目录中没有 official evaluator 报告，派生代码只做 diff 字符串检测。保留预测输出分析，撤回修复效果推断。
3. 任务级分类源宣称 7 个 resolved，却只列出 3 个 task，其中含 Astropy；repository 段又声称 Astropy 0 resolved。此内部冲突阻止将 50/43/12/26 当作已核实任务处置。未修改原 JSON。
4. fault 日志的 36.46 ms 是均值；中位数为 35.89 ms。病例结果重算与原记录一致。9 类变异首先触发完整性拒绝，不能用于验证下游每条语义规则；也不能宣称缺 evaluator/billing 的条件全部可在 evaluator 运行前检查。
5. cohort manifest 声明的 SHA-256 对应 LF-normalized 内容；保留文件实际为 CRLF。核查记录实际字节哈希并保留原声明，不修改原始 manifest 来修绿。
6. `build_pdf.py` 原先可把未重建的旧中文 PDF 再次盖上新版本。本次仅发布实际重建的英文稿，历史中文版本保持原有身份。

方法、领域、统计、编辑与研究伦理复核均以这些边界为前提：算法方法说明保留；task/attempt 和 valid/resolved/admitted 分离；配对检验解释限制于实际 endpoint；图表实物通过检查；不补造数据、编码者、provider snapshot 或 DOI。

## 验证结果

| 检查 | 状态 | 证据 |
|---|---|---|
"""
    text += '\n'.join('| '+' | '.join(row)+' |' for row in checks)
    text += '\n\n完整测试的失败项：\n\n' + '\n'.join('- `'+name+'`' for name in failures)
    intervention = evidence / 'test_environment_intervention.json'
    if intervention.is_file():
        text += '\n\n测试环境干预：旧共享镜像缓存测试虽然 mock 了 runner，仍通过 `_inspect_local` 调用了真实 Docker 查询且无超时。两个只读 `docker image inspect` 客户端挂起后被单独结束，测试主进程保留并继续完成。因此完整测试记录包含环境干预，不能描述为无干预的纯离线通过。细节见 `test_environment_intervention.json` 与 `test_environment_intervention_second.log`。\n'
    text += """

本次局部出版链通过不代表全库通过。全库检查保留历史损坏/未完成 RUN、旧派生产物/provenance 以及原有质量门禁的 FAIL；日志完整保留，没有删除坏证据、改写 raw 或放宽质量策略来取得 PASS。完整测试中涉及全库状态、旧 canonical accounting 与 registry policy 的失败亦如实归档，不能称“测试全绿”。

最终 PDF 已检查全部 9 页。6/8/9 页以最终渲染重新查看，其他页与已查看的预览 PNG 字节哈希相同。图表没有裁切或越界。机器 gate 检查 DataValue、Q=Q、p=p、重复百分号、P0 内部标签、未定义引用、overfull 及 page boundary；排版实物检查补充机器检查的局限。

## 交付物及完整哈希

"""
    for path in [pdf, package, ROOT/'paper/main.tex', ROOT/'paper/publication_sources.json', ROOT/'paper/data/publication_values.json', audit]:
        text += f"- `{path.relative_to(ROOT).as_posix()}`  \n  SHA-256：`{digest(path)}`\n"
    text += f"""

证据目录：`{evidence.relative_to(ROOT).as_posix()}`。其中保留改动前源码、离线 source audit、检查日志、最终渲染、机器 gate 结果、未填写人工工作表和操作说明。旧报告及原 RUN 不覆盖。

当前 publication scope 为英文稿的可核验出版链；archive integrity 在源门禁中仍报告 `{validation['source_admission']['archive_integrity']}`。新源包为本地交付，并非公开 artifact、完整独立重放包或正式实验授权。

## 准确的继续条件

- 由真实独立编码者完成冻结 codebook 下的盲法标签、agreement、分歧和裁决；先建立完整任务选择链，不能从本次 30-task retry 模板推断原声称的 50-task 终态。
- 获得不可变 provider/model snapshot 与每 treatment 的 source/driver/prompt/container/authorization/billing 绑定。需要新的模型或 evaluator 执行时，重新满足正式 contract 与授权门禁；本次论文整改不提供实验授权。
- 建立官方 evaluator 确认的 matched repair endpoint 后，才可恢复“修复效果”比较；预测输出率不能自动改名 resolved rate。
- 完成经作者确认的公开/匿名 artifact 存放并填入实际 DOI/URL，再按目标期刊配置检查模板与投稿附件。
"""
    with output.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
    from scripts.artifact_provenance import write
    inputs = [audit, pdf, package, ROOT/'paper/main.tex', ROOT/'paper/publication_sources.json', ROOT/'paper/data/publication_values.json',
              ROOT/'paper/build/data_summary.json', *(evidence/name for name in ['release_result.json','render_validation.json','verified_source_audit.json','unittest.log','datactl_all_final.log','datactl_audit.log','rendering_regression_tests.log'])]
    inputs.extend(path for path in [intervention, evidence/'test_environment_intervention_second.log'] if path.is_file())
    write(output, inputs, Path(__file__), transform={'activity':'item-by-item audit and bounded revision handoff','version':'1.1'}, kind='derived_dataset')
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    print(write_report(parser.parse_args().evidence))
