"""Copy, verify and externally quarantine exactly a frozen evidence plan.

prepare: leaves all originals in place; execute: checks publication before
removing originals; verify: checks retained bytes, archive coverage and claims;
rollback: restores originals from independently hash-verified copies.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone, timedelta
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

from cactus.governance.evidence_locations import (
    confined, fingerprint, sha256, no_links, EvidenceLocations, location_config_path,
)
from scripts.artifact_provenance import write

ROOT = Path(__file__).resolve().parents[1]
POLICY = "immutable_quarantine; blocked_until_readmission; no_historical_integrity_upgrade"


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def save(path, payload, *, exclusive=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if exclusive:
        with path.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
    else:
        temporary = path.with_name(path.name + ".tmp")
        with temporary.open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(path)


def journal(storage, event, run_id=None):
    with (storage / "migration_events.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({"timestamp": now(), "event": event, "run_id": run_id}, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def assert_idle():
    if os.name != "nt":
        return
    # Emit only a count, never process commands or session credentials.
    command = "$blocked = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'python|bash|wsl|docker' -and $_.CommandLine -match 'run_swebench_campaign|run_lite50_precise_image_batch|swebench.harness.run_evaluation|run_campaign.ps1' }); $blocked.Count"
    result = subprocess.run(["powershell", "-NoProfile", "-Command", command], capture_output=True, text=True)
    if result.returncode or result.stdout.strip() != "0":
        raise ValueError("cannot establish that experiment/evaluator processes are idle")


def protected_bindings():
    config_path = ROOT / "paper/publication_sources.json"
    config = load(config_path)
    for source in config["sources"].values():
        if sha256(ROOT / source["path"]) != source["sha256"]:
            raise ValueError("frozen publication source drift")
    retry = rows(ROOT / config["sources"]["retry_inventory"]["path"])
    admitted = {r["run_id"] for r in retry if r["admitted"]}
    return config, admitted


def prepare(plan: Path, storage: Path):
    plan = plan.resolve()
    plan.relative_to(ROOT / "docs/50tasks")
    from cactus.tools.datactl import verify_sidecar
    errors = verify_sidecar(ROOT, plan / "quarantine_candidates.jsonl")
    errors += verify_sidecar(ROOT, plan / "retained_archive.jsonl")
    if errors:
        raise ValueError(errors)
    config, admitted = protected_bindings()
    candidates = rows(plan / "quarantine_candidates.jsonl")
    retained = rows(plan / "retained_archive.jsonl")
    inventory = rows(ROOT / config["sources"]["corpus_inventory"]["path"])
    by_run = {r["run_id"]: r for r in inventory}
    if ({r["run_id"] for r in candidates} != {r["run_id"] for r in inventory if r["integrity_errors"]}
            or {r["run_id"] for r in retained} != {r["run_id"] for r in inventory if not r["integrity_errors"]}
            or len(candidates) != len({r["run_id"] for r in candidates})
            or admitted & {r["run_id"] for r in candidates}):
        raise ValueError("plan coverage/admission safety mismatch")
    if {p.name for p in (ROOT / "experiments/runs").iterdir() if p.is_dir()} != set(by_run):
        raise ValueError("active directory inventory drift")
    assert_idle()
    storage = storage.absolute()
    if not storage.is_absolute() or storage.resolve() == Path(storage.anchor) or storage.resolve().is_relative_to(ROOT.parent):
        raise ValueError("storage must be a dedicated directory outside the project")
    for path in [*reversed(storage.parents), storage]:
        no_links(path)
    if storage.exists():
        raise FileExistsError("new quarantine batch requires an unused destination")
    required = sum(r["bytes"] for r in candidates)
    if shutil.disk_usage(storage.anchor).free < required + 100 * 1024 * 1024:
        raise ValueError("insufficient quarantine storage")
    captured = []
    for row in candidates:
        source = confined(ROOT, row["original_path"])
        if source.parent != (ROOT / "experiments/runs").resolve() or source.name != row["run_id"]:
            raise ValueError("source is not an immediate child of the authorized runs root")
        actual = fingerprint(source)
        if any(actual[key] != row[key] for key in ("content_sha256", "file_hashes_relative_to_directory", "file_count", "bytes")):
            raise ValueError("source changed since approved plan: " + row["run_id"])
        captured.append({"run_id": row["run_id"], "original_path": row["original_path"],
                         "storage_relative_path": row["run_id"], **actual,
                         "original_integrity_errors": row["original_integrity_errors"], "claim_status": "blocked",
                         "required_recovery": row["required_recovery"], "reentry_requirements": row["reentry_requirements"]})
    instant = datetime.now(timezone.utc)
    batch = instant.strftime("%Y%m%dT%H%M%SZ")
    storage_id = "quarantine-" + batch
    manifest_dir = ROOT / "experiments/quarantine" / batch
    if manifest_dir.exists():
        raise FileExistsError(manifest_dir)
    storage.mkdir(parents=True)
    journal(storage, "prepare_started")
    for index, row in enumerate(captured, 1):
        source = confined(ROOT, row["original_path"])
        target = confined(storage, row["storage_relative_path"])
        shutil.copytree(source, target, copy_function=shutil.copy2)
        actual = fingerprint(target)
        if any(actual[key] != row[key] for key in actual):
            raise ValueError("copy verification failed: " + row["run_id"])
        journal(storage, "copy_verified", row["run_id"])
        if index % 20 == 0 or index == len(captured):
            print(json.dumps({"copied_verified": index, "total": len(captured)}), flush=True)
    manifest = {"schema_version": "1.0", "generated_at": now(), "storage_id": storage_id,
                "source_plan": {"path": (plan / "quarantine_candidates.jsonl").relative_to(ROOT).as_posix(),
                                "sha256": sha256(plan / "quarantine_candidates.jsonl")},
                "entries": captured, "policy": POLICY}
    manifest_path = manifest_dir / "manifest.json"
    save(manifest_path, manifest, exclusive=True)
    generator_snapshot = manifest_dir / "generator_snapshot.py"
    shutil.copy2(Path(__file__), generator_snapshot)
    write(manifest_path, [plan / "quarantine_candidates.jsonl", plan / "retained_archive.jsonl",
                         ROOT / "paper/publication_sources.json", ROOT / "src/cactus/governance/evidence_locations.py"], generator_snapshot,
          transform={"activity": "verified_external_copy_manifest", "originals_removed": False}, kind="derived_dataset")
    shutil.copy2(manifest_path, storage / "manifest.json")
    catalog_path = ROOT / "experiments/quarantine/catalog.json"
    catalog = load(catalog_path) if catalog_path.exists() else {"schema_version": "1.0", "batches": []}
    catalog["batches"].append({"manifest_path": manifest_path.relative_to(ROOT).as_posix(),
                             "manifest_sha256": sha256(manifest_path), "storage_id": storage_id})
    local_path = location_config_path()
    local = load(local_path) if local_path.exists() else {"schema_version": "1.0", "storage_roots": {}}
    if storage_id in local["storage_roots"]:
        raise ValueError("duplicate storage identity")
    local["storage_roots"][storage_id] = storage.as_posix()
    save(local_path, local)
    save(catalog_path, catalog)
    EvidenceLocations(ROOT)  # Fail closed before allowing original removal.
    journal(storage, "location_mapping_registered")
    print(json.dumps({"stage": "prepared_originals_retained", "manifest": manifest_path.relative_to(ROOT).as_posix(),
                      "storage": storage.as_posix(), "copies": len(captured)}, ensure_ascii=False), flush=True)


def batch_state(manifest_path):
    manifest_path = manifest_path.resolve()
    manifest_path.relative_to(ROOT / "experiments/quarantine")
    manifest = load(manifest_path)
    catalog = load(ROOT / "experiments/quarantine/catalog.json")
    binding = [b for b in catalog["batches"] if b["manifest_path"] == manifest_path.relative_to(ROOT).as_posix()]
    if len(binding) != 1 or binding[0]["manifest_sha256"] != sha256(manifest_path):
        raise ValueError("migration manifest is not bound in the catalog")
    storage = Path(load(location_config_path())["storage_roots"][manifest["storage_id"]])
    if sha256(storage / "manifest.json") != sha256(manifest_path):
        raise ValueError("external/project manifest copies differ")
    EvidenceLocations(ROOT)
    return manifest, storage


def publication_gate():
    result = subprocess.run([os.sys.executable, "-m", "cactus.tools.datactl", "publication"], cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
    if result.returncode:
        raise ValueError("publication gate failed before removal: " + result.stdout[-5000:])
    return json.loads(result.stdout)


def remove_verified_original(source, target, row):
    source = confined(ROOT, row["original_path"])
    if source.parent != (ROOT / "experiments/runs").resolve():
        raise ValueError("removal target escaped the authorized runs root")
    source_actual = fingerprint(source)
    target_actual = fingerprint(target)
    if source_actual != target_actual or any(target_actual[key] != row[key] for key in target_actual):
        raise ValueError("source/copy drift immediately before removal")
    # One Python filesystem API end to end, no generated shell deletion strings.
    for relative in source_actual["file_hashes_relative_to_directory"]:
        path = confined(source, relative)
        try:
            path.unlink()
        except PermissionError:
            path.chmod(stat.S_IWRITE | stat.S_IREAD)
            path.unlink()
    for relative in sorted(source_actual["directories"], key=lambda s: (len(s.split("/")), s), reverse=True):
        confined(source, relative).rmdir()
    source.rmdir()


def execute(manifest_path):
    manifest, storage = batch_state(manifest_path)
    assert_idle()
    publication = publication_gate()
    save(storage / ("publication_before_removal_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + ".json"), publication, exclusive=True)
    journal(storage, "publication_pass_before_removal")
    for index, row in enumerate(manifest["entries"], 1):
        source = confined(ROOT, row["original_path"])
        target = confined(storage, row["storage_relative_path"])
        if source.exists():
            journal(storage, "original_removal_started", row["run_id"])
            remove_verified_original(source, target, row)
            journal(storage, "original_removed_copy_preserved", row["run_id"])
        if index % 20 == 0 or index == len(manifest["entries"]):
            print(json.dumps({"migrated": index, "total": len(manifest["entries"])}), flush=True)
    journal(storage, "migration_completed")


def verify(manifest_path):
    manifest, storage = batch_state(manifest_path)
    config, admitted = protected_bindings()
    retry = rows(ROOT / config["sources"]["retry_inventory"]["path"])
    admitted_rows = [row for row in retry if row["admitted"]]
    inventory = rows(ROOT / config["sources"]["corpus_inventory"]["path"])
    quarantined = {r["run_id"] for r in manifest["entries"]}
    active = {p.name for p in (ROOT / "experiments/runs").iterdir() if p.is_dir()}
    expected = {r["run_id"] for r in inventory}
    if active & quarantined or active | quarantined != expected or admitted & quarantined:
        raise ValueError("active/quarantine coverage or admission preservation failed")
    from scripts.audit_evidence_corpus import schema_errors
    from cactus.runner.bundle_validator import validate_bundle
    errors = []
    for index, row in enumerate(inventory, 1):
        if row["run_id"] not in active:
            continue
        physical = confined(ROOT, row["path"])
        actual = fingerprint(physical)
        logical_hashes = {row["path"] + "/" + key: value for key, value in actual["file_hashes_relative_to_directory"].items()}
        if logical_hashes != row["file_hashes"]:
            errors.append("retained bytes drift: " + row["run_id"])
        issues = validate_bundle(physical)
        for name, filename in (("run_manifest", "run_manifest.json"), ("raw_result", "raw/result.json")):
            file = physical / filename
            if file.is_file():
                issues.extend(schema_errors(ROOT, name, load(file)))
        if load(physical / "run_manifest.json").get("status") == "running":
            issues.append("unsealed_running_state")
        errors.extend(row["run_id"] + ": " + issue for issue in issues)
        if index % 500 == 0:
            print(json.dumps({"retained_verification_progress": index, "corpus": len(inventory)}), flush=True)
    if errors:
        raise ValueError(errors)
    publication = publication_gate()
    result = {"schema_version": "1.0", "generated_at": now(), "status": "PASS",
              "active_integrity": "PASS", "quarantine_coverage": "PASS", "current_publication": publication["status"],
              "historical_integrity": publication["sources"]["archive_integrity"],
              "active_directories": len(active), "quarantined_directories": len(quarantined),
              "total_historical_directories": len(expected), "admitted_runs_preserved": len(admitted),
              "admitted_tasks_preserved": len({row["task_id"] for row in admitted_rows}),
              "admitted_resolved_runs_preserved": sum(row["resolved"] for row in admitted_rows),
              "quarantine_files": sum(r["file_count"] for r in manifest["entries"]),
              "quarantine_bytes": sum(r["bytes"] for r in manifest["entries"]),
              "retained_bytes_verified": True, "originals_remaining": 0,
              "manifest": {"path": manifest_path.relative_to(ROOT).as_posix(), "sha256": sha256(manifest_path)},
              "policy": POLICY}
    instant = datetime.now(timezone.utc)
    stamp = instant.astimezone(timezone(timedelta(hours=8))).strftime("%Y%m%d-%H%M%S")
    output = ROOT / "docs/50tasks" / ("v1.1_" + stamp + "_历史问题目录隔离迁移验收报告")
    output.mkdir()
    generator_snapshot = output / "generator_snapshot.py"
    shutil.copy2(Path(__file__), generator_snapshot)
    result_path = output / "verification.json"
    save(result_path, result, exclusive=True)
    inputs = [manifest_path, ROOT / "paper/publication_sources.json", ROOT / config["sources"]["corpus_inventory"]["path"],
              ROOT / "src/cactus/governance/evidence_locations.py"]
    write(result_path, inputs, generator_snapshot, transform={"activity": "post_migration_full_retained_and_quarantine_verification"}, kind="derived_dataset")
    publication_path = output / "publication.json"
    save(publication_path, publication, exclusive=True)
    write(publication_path, inputs, generator_snapshot, transform={"activity": "post_migration_publication_gate"}, kind="derived_dataset")
    document = output / (output.name + ".md")
    document.write_text(f'''# 历史问题目录隔离迁移验收报告

- 版本：v1.1；时间（UTC）：{result['generated_at']}；文件名时间：{stamp}（Asia/Shanghai）。
- 工作目录与分支保持不变；本次只迁移档案，没有启动正式实验或修改原始结果。

## 迁移结果

{len(quarantined)} 个问题目录已移出活跃库，完整副本封存于外部 F 盘；每文件 SHA-256、目录集合、文件数量与字节数核验通过。
活跃库保留 {len(active)} 个目录，全部与冻结快照逐文件核对一致，并通过 bundle/完整 schema 检查。
隔离区含 {result['quarantine_files']} 个文件、{result['quarantine_bytes']} 字节；原位置剩余 0 个问题目录。
{len(admitted)} 个准入 RUN/{result['admitted_tasks_preserved']} 个任务及 {result['admitted_resolved_runs_preserved']} 个准入 resolved RUN 保持原值与证据，不与隔离集合相交。

## 门禁与使用边界

- 活跃库完整性：PASS；隔离完整覆盖与副本字节校验：PASS；当前中英文论文出版引用链：PASS。
- 全历史（活跃库 + 隔离区）完整性：{result['historical_integrity']}，保留原 {len(quarantined)} 个问题及原因。隔离不能升级证据准入。
- 旧 500 题尝试链、旧 registry 与旧图表的既有问题仍保留；本次迁移不构成其修复。
- 唯一出版入口和账本/宏/表/图/PDF没有重写；来源核查可按原逻辑路径访问受控隔离副本。

## 追溯与恢复

不可变清单：`{manifest_path.relative_to(ROOT).as_posix()}`；完整摘要 `{sha256(manifest_path)}`。
清单含原逻辑路径、外部存储相对路径、逐文件摘要、原始阻断原因、恢复要求与重新准入条件。
机器存储根绑定位于项目外的本地 `CACTUS/evidence_locations.json`；迁移日志与同摘要 manifest 副本保存在隔离根目录。
在新机器上须配置同 storage_id 的外部存储根；缺失副本、摘要不符、路径逃逸或冲突均阻断验证。
隔离原件不用于原地修复；补证据另外封存。补充实验使用新 RUN-ID，并关联原问题；重入库须新准入快照。
可用 `python -m scripts.quarantine_evidence rollback --manifest <上述清单>` 恢复原位置；恢复前重新核验隔离副本，拒绝覆盖冲突文件。

机器验收详见 verification.json；论文引用门禁详见 publication.json。源清单、旧计划及历史档案完整保留。
''', encoding="utf-8", newline="\n")
    write(document, [result_path, publication_path, manifest_path], generator_snapshot, transform={"activity": "Chinese_migration_acceptance_report"}, kind="derived_dataset")
    journal(storage, "post_migration_verification_pass")
    print(json.dumps({**result, "report": document.relative_to(ROOT).as_posix()}, ensure_ascii=False), flush=True)


def rollback(manifest_path):
    # Read catalog/manifest bindings without requiring partially removed sources
    # to match: a crash during unlink must remain recoverable.
    manifest = load(manifest_path)
    catalog = load(ROOT / "experiments/quarantine/catalog.json")
    if not any(b["manifest_path"] == manifest_path.relative_to(ROOT).as_posix() and b["manifest_sha256"] == sha256(manifest_path) for b in catalog["batches"]):
        raise ValueError("unbound rollback manifest")
    storage = Path(load(location_config_path())["storage_roots"][manifest["storage_id"]])
    assert_idle()
    for row in manifest["entries"]:
        target = confined(storage, row["storage_relative_path"])
        actual = fingerprint(target)
        if any(actual[key] != row[key] for key in actual):
            raise ValueError("rollback copy drift")
        original = confined(ROOT, row["original_path"])
        if original.exists():
            partial = fingerprint(original)
            if any(row["file_hashes_relative_to_directory"].get(k) != v for k, v in partial["file_hashes_relative_to_directory"].items()):
                raise ValueError("conflicting original prevents rollback")
            shutil.copytree(target, original, dirs_exist_ok=True)
        else:
            shutil.copytree(target, original)
        if fingerprint(original) != actual:
            raise ValueError("rollback byte verification failed")
        journal(storage, "original_restored", row["run_id"])
    print(json.dumps({"status": "PASS", "restored": len(manifest["entries"])}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "execute", "verify", "rollback"))
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--storage", type=Path)
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    if args.action == "prepare":
        if args.plan is None or args.storage is None:
            parser.error("prepare requires --plan and --storage")
        prepare(args.plan, args.storage)
    else:
        if args.manifest is None:
            parser.error("action requires --manifest")
        globals()[args.action](args.manifest.resolve())


if __name__ == "__main__":
    main()
