"""Derive descriptive Lite-50 pipeline metrics from immutable CACTUS bundles."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

from cactus.runner.bundle_validator import validate_bundle
from cactus.governance.admission import valid_evaluator as _valid_evaluator, valid_patch as _valid_patch
from cactus.evaluation.taxonomy_v2 import classify_text


def _json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _report(bundle: Path) -> dict[str, Any]:
    reports = sorted((bundle / "evaluation").glob("*.json")) if (bundle / "evaluation").is_dir() else []
    return _json(reports[0]) if len(reports) == 1 else {}


def _wilson(successes: int, total: int) -> dict[str, float | None]:
    if total == 0:
        return {"estimate": None, "lower": None, "upper": None}
    z = 1.959963984540054
    p = successes / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return {"estimate": p, "lower": max(0.0, center - margin), "upper": min(1.0, center + margin)}


def aggregate(runs: Path, manifest: Path, output: Path, *, experiment_id: str) -> dict[str, Any]:
    expected = [json.loads(line)["task_id"] for line in manifest.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(expected) != 50 or len(set(expected)) != 50:
        raise ValueError("Lite-50 manifest must contain exactly 50 unique task IDs")
    by_task: dict[str, Path] = {}
    for bundle in sorted(runs.glob("RUN-*")):
        record = _json(bundle / "run_manifest.json")
        if record.get("experiment_id") != experiment_id:
            continue
        task_id = str(record.get("task_id", ""))
        if task_id in by_task:
            raise ValueError(f"multiple Lite-50 bundles for task {task_id}")
        by_task[task_id] = bundle
    rows: list[dict[str, Any]] = []
    for task_id in expected:
        bundle = by_task.get(task_id)
        if bundle is None:
            rows.append({"task_id": task_id, "run_id": None, "evaluator_valid": False, "resolved": False, "pipeline_complete": False, "patch_format_valid": False, "failure_family": "G", "failure_code": "G06_APPROVAL_MISSING"})
            continue
        run = _json(bundle / "run_manifest.json")
        report = _report(bundle)
        evaluator_valid = _valid_evaluator(report)
        patch_valid = _valid_patch(bundle, task_id)
        billing = _json(bundle / "billing" / "litellm_spend.json")
        errors = validate_bundle(bundle)
        text = " ".join(str(item) for item in (run.get("error"), billing.get("status"), report.get("error"), errors) if item)
        classification = classify_text(text) if text else None
        rows.append({"task_id": task_id, "run_id": run.get("run_id", bundle.name), "evaluator_valid": evaluator_valid, "resolved": evaluator_valid and int(report.get("resolved_instances", 0) or 0) == 1, "pipeline_complete": evaluator_valid and patch_valid and billing.get("status") == "verified_cost" and not errors, "patch_format_valid": patch_valid, "failure_family": str(classification.failure_family) if classification else "A", "failure_code": str(classification.failure_code) if classification else "VALID_EVALUATION"})
    valid = sum(row["evaluator_valid"] for row in rows)
    resolved = sum(row["resolved"] for row in rows)
    summary = {"schema_version": "1.0", "evidence_status": "observed" if len(by_task) == 50 else "incomplete", "experiment_id": experiment_id, "task_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(), "expected_task_count": 50, "observed_bundle_count": len(by_task), "metrics": {"evaluator_valid_rate": _wilson(valid, 50), "resolved_rate_all": _wilson(resolved, 50), "resolved_rate_given_evaluator_valid": _wilson(resolved, valid), "pipeline_complete_rate": _wilson(sum(row["pipeline_complete"] for row in rows), 50), "patch_format_validity": _wilson(sum(row["patch_format_valid"] for row in rows), 50)}, "failure_family_counts": {family: sum(row["failure_family"] == family for row in rows) for family in ("A", "X", "E", "G")}, "tasks": rows}
    if output.exists():
        raise FileExistsError(f"refusing to overwrite derived evidence: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=Path("experiments/runs"))
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--experiment-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(aggregate(args.runs, args.manifest, args.output, experiment_id=args.experiment_id), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
