"""Retained offline near-valid controls; no original RUN or authorization changes.

Prediction controls preserve exact model_patch bytes and task identity while
changing JSON representation. Billing controls are explicit synthetic matched
usage counterfactuals. Neither constitutes a new repair, invoice or evaluation.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from cactus.governance.admission import evaluate_admission, read_json
from cactus.governance.evidence_locations import resolve_source
from scripts.artifact_provenance import write
from scripts.import_formal_run_bundles import files, tree_hash
from scripts.run_admission_semantic_suite import reseal, save, sha

OPERATORS = {
    "N01_prediction_representation": "same task and exact model_patch; extra JSON metadata and changed field order",
    "N02_consistent_usage_variant": "synthetic input token +1; raw, provider and billing totals changed consistently; spend unchanged",
}
EVIDENCE_KIND = "offline counterfactual controls on copied observed archive; not new measured billing, repair or evaluation"


def transform(operator: str, target: Path) -> None:
    if operator == "N01_prediction_representation":
        path = target / "raw/prediction.jsonl"
        records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        for record in records:
            record["near_valid_control_metadata"] = {"purpose": "representation-only offline admission control"}
        path.write_text("\n".join(json.dumps(dict(reversed(list(record.items()))), ensure_ascii=False)
                                  for record in records)+"\n", encoding="utf-8", newline="\n")
    elif operator == "N02_consistent_usage_variant":
        raw = read_json(target / "raw/result.json")
        billing = read_json(target / "billing/litellm_spend.json")
        raw["data"]["input_tokens"] += 1
        billing["total_tokens"] += 1
        for key in ["provider_tokens", "billing_tokens"]:
            billing["provider_usage_reconciliation"][key] += 1
        save(target / "raw/result.json", raw)
        save(target / "billing/litellm_spend.json", billing)
    else:
        raise ValueError("unknown near-valid operator")
    reseal(target)


def summarize(cases: list[dict], seed_count: int) -> dict:
    admitted = sum(case["decision"]["admitted"] for case in cases)
    per_operator = {}
    for operator in OPERATORS:
        group = [case for case in cases if case["operator"] == operator]
        accepted = sum(case["decision"]["admitted"] for case in group)
        per_operator[operator] = {"cases": len(group), "admitted": accepted, "fp": len(group)-accepted,
                                  "integrity_passed": sum(case["decision"]["integrity_passed"] for case in group)}
    return {"control_count": len(cases), "seed_count": seed_count, "operator_count": len(OPERATORS),
            "admitted": admitted, "fp": len(cases)-admitted,
            "integrity_passed": sum(case["decision"]["integrity_passed"] for case in cases),
            "specificity": admitted/len(cases), "fpr": (len(cases)-admitted)/len(cases),
            "stages": dict(Counter(case["decision"]["stage"] for case in cases)), "per_operator": per_operator}


def run(output: Path) -> dict:
    config = read_json(ROOT / "paper/publication_sources.json")
    inventory = ROOT / config["sources"]["retry_inventory"]["path"]
    semantic = ROOT / config["sources"]["semantic_mutations"]["path"]
    prior = read_json(semantic)
    rows = {row["run_id"]: row for row in (json.loads(line) for line in inventory.read_text(encoding="utf-8").splitlines())}
    names = [case["seed_run_id"] for case in prior["cases"] if case["operator"] == "control"]
    if len(names) != 20 or len(set(names)) != 20:
        raise ValueError("expected the unchanged twenty original semantic-study seeds")
    output = output.resolve(); output.relative_to(ROOT)
    if output.exists():
        raise FileExistsError("refusing to overwrite near-valid control evidence")
    originals = {name: tree_hash(resolve_source(ROOT, rows[name]["run_path"])) for name in names}
    if originals != prior["original_trees"] or any(not rows[name]["admitted"] for name in names):
        raise ValueError("seed binding differs from original semantic study")
    output.mkdir(parents=True)
    cases = []
    inputs = [inventory, semantic, ROOT / "src/cactus/governance/admission.py",
              ROOT / "src/cactus/runner/bundle_validator.py", ROOT / "scripts/run_admission_semantic_suite.py"]
    for index, name in enumerate(names, 1):
        row = rows[name]
        baseline = resolve_source(ROOT, row["run_path"])
        contract_path = ROOT / row["contract_path"]
        auth_path = contract_path.with_name(contract_path.stem+".session_authorization.json")
        contract, authorization = read_json(contract_path), read_json(auth_path)
        inputs += [contract_path, auth_path]
        original = evaluate_admission(ROOT, baseline, contract, authorization=authorization)
        if not original["admitted"]:
            raise ValueError("original seed is no longer admitted: "+name)
        for operator in OPERATORS:
            case_id = f"{operator}-{index:03d}"
            target = output / "cases" / case_id / name
            shutil.copytree(baseline, target)
            transform(operator, target)
            decision = evaluate_admission(ROOT, target, contract, authorization=authorization)
            cases.append({"case_id": case_id, "operator": operator, "seed_run_id": name,
                          "seed_tree_sha256": originals[name], "seed_path": row["run_path"],
                          "contract_path": row["contract_path"], "contract_sha256": sha(contract_path),
                          "authorization_path": auth_path.relative_to(ROOT).as_posix(), "authorization_sha256": sha(auth_path),
                          "bundle_path": target.relative_to(ROOT).as_posix(), "bundle_tree_sha256": tree_hash(target),
                          "expected_admitted": True, "decision": decision})
    if {name: tree_hash(resolve_source(ROOT, rows[name]["run_path"])) for name in names} != originals:
        raise ValueError("original seed evidence changed")
    summary = summarize(cases, len(names))
    result = {"schema_version": "1.0", "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
              "evidence_kind": EVIDENCE_KIND, "verdict": "PASS" if summary["admitted"] == summary["integrity_passed"] == 40 else "FAIL",
              "admission_implementation": "src/cactus/governance/admission.py", "admission_sha256": sha(ROOT / "src/cactus/governance/admission.py"),
              "generator_sha256": sha(Path(__file__)), "resealing_source_sha256": sha(ROOT / "scripts/run_admission_semantic_suite.py"),
              "prior_semantic_report": {"path": semantic.relative_to(ROOT).as_posix(), "sha256": sha(semantic)},
              "operators": OPERATORS, "original_trees": originals, "summary": summary, "cases": cases,
              "limitations": "two variants reuse each of twenty seeds; not independent samples; no patch applicability, new evaluator outcome or provider invoice verification"}
    path = output / "near_valid_controls.json"; save(path, result)
    write(path, list(dict.fromkeys(inputs)), Path(__file__),
          transform={"operators": OPERATORS, "origin": EVIDENCE_KIND, "original_trees": originals}, kind="derived_dataset")
    return result


def verify_report(path: Path) -> dict:
    """Rejudge production decisions against independent seeds/contracts/approvals."""
    result = read_json(path)
    if result["generator_sha256"] != sha(Path(__file__)) or result["admission_sha256"] != sha(ROOT / result["admission_implementation"]):
        raise ValueError("near-valid implementation drift")
    if result["resealing_source_sha256"] != sha(ROOT / "scripts/run_admission_semantic_suite.py"):
        raise ValueError("near-valid resealing source drift")
    prior = result["prior_semantic_report"]
    if sha(ROOT / prior["path"]) != prior["sha256"] or read_json(ROOT / prior["path"])["original_trees"] != result["original_trees"]:
        raise ValueError("prior semantic report binding drift")
    if result["operators"] != OPERATORS or result["evidence_kind"] != EVIDENCE_KIND:
        raise ValueError("near-valid scope drift")
    keys = [(case["seed_run_id"], case["operator"]) for case in result["cases"]]
    if (len(keys) != 40 or len(set(keys)) != 40
            or set(keys) != {(name, op) for name in result["original_trees"] for op in OPERATORS}):
        raise ValueError("near-valid case coverage drift")
    for case in result["cases"]:
        seed = resolve_source(ROOT, case["seed_path"])
        if tree_hash(seed) != case["seed_tree_sha256"] or case["seed_tree_sha256"] != result["original_trees"][case["seed_run_id"]]:
            raise ValueError("original near-valid seed tree drift")
        contract_path, auth_path = ROOT / case["contract_path"], ROOT / case["authorization_path"]
        if sha(contract_path) != case["contract_sha256"] or sha(auth_path) != case["authorization_sha256"]:
            raise ValueError("independent contract or authorization drift")
        bundle = (ROOT / case["bundle_path"]).resolve(); bundle.relative_to(ROOT)
        if tree_hash(bundle) != case["bundle_tree_sha256"]:
            raise ValueError("near-valid case tree drift")
        # All files except the precisely defined operator and resealing outputs
        # must remain byte-identical, including the evaluator and frozen contract.
        allowed = {"run_manifest.json", "checksums.sha256", "raw/result.json", "contract.sha256"}
        allowed.add("raw/prediction.jsonl" if case["operator"] == "N01_prediction_representation" else "billing/litellm_spend.json")
        before, after = files(seed), files(bundle)
        if set(before) != set(after) or any(before[key] != after[key] for key in before.keys()-allowed):
            raise ValueError("near-valid unexpected file modification")
        if case["operator"] == "N01_prediction_representation":
            before_records = [json.loads(line) for line in (seed/"raw/prediction.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
            after_records = [json.loads(line) for line in (bundle/"raw/prediction.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
            for record in after_records:
                if record.pop("near_valid_control_metadata", None) != {"purpose": "representation-only offline admission control"}:
                    raise ValueError("prediction control metadata drift")
            if before_records != after_records:
                raise ValueError("prediction control changed task or model_patch")
            raw_expected = read_json(seed / "raw/result.json")
            raw_expected["data"]["prediction_hash"] = sha(bundle / "raw/prediction.jsonl")
            if read_json(bundle / "raw/result.json") != raw_expected:
                raise ValueError("prediction control changed raw outcome")
        else:
            expected = read_json(seed / "billing/litellm_spend.json")
            expected["total_tokens"] += 1
            for key in ["provider_tokens", "billing_tokens"]:
                expected["provider_usage_reconciliation"][key] += 1
            raw_expected = read_json(seed / "raw/result.json"); raw_expected["data"]["input_tokens"] += 1
            if expected != read_json(bundle / "billing/litellm_spend.json") or raw_expected != read_json(bundle / "raw/result.json"):
                raise ValueError("billing control transformation drift")
        actual = evaluate_admission(ROOT, bundle, read_json(contract_path), authorization=read_json(auth_path))
        expected_decision = dict(case["decision"])
        actual.pop("elapsed_sec"); expected_decision.pop("elapsed_sec")
        if actual != expected_decision or not case["expected_admitted"]:
            raise ValueError("near-valid admission decision drift")
    summary = summarize(result["cases"], len(result["original_trees"]))
    if summary != result["summary"] or result["verdict"] != ("PASS" if summary["admitted"] == summary["integrity_passed"] == 40 else "FAIL"):
        raise ValueError("near-valid summary drift")
    return {"status": "PASS", "cases": len(result["cases"]), "scope": result["evidence_kind"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--output", type=Path)
    group.add_argument("--verify", type=Path)
    args = parser.parse_args()
    report = verify_report(args.verify) if args.verify else run(args.output)
    print(json.dumps({key: report[key] for key in ["status"] if key in report} or
                     {"verdict": report["verdict"], "summary": report["summary"]}, indent=2))
    raise SystemExit(0 if report.get("status", report.get("verdict")) == "PASS" else 2)
