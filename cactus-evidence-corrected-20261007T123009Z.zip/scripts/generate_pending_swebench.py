"""Generate a reproducible pending-task manifest from sealed campaign RUNs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def task_id_from_manifest(path: Path) -> str | None:
    data = json.loads(path.read_text(encoding="utf-8"))
    command = data.get("command", [])
    for index, value in enumerate(command[:-1]):
        if value == "--task-id":
            return str(command[index + 1])
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tasks", type=Path, required=True)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    completed: set[str] = set()
    failed: set[str] = set()
    for manifest in args.runs.glob("RUN-*/run_manifest.json"):
        data = json.loads(manifest.read_text(encoding="utf-8"))
        task_id = task_id_from_manifest(manifest)
        if not task_id:
            continue
        if data.get("status") == "completed":
            completed.add(task_id)
        elif data.get("status") == "failed":
            failed.add(task_id)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    pending = []
    for line in args.tasks.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        task_id = record["task_id"]
        if task_id not in completed:
            pending.append(record)
    args.output.write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in pending), encoding="utf-8")
    summary = {
        "source_task_count": sum(1 for line in args.tasks.read_text(encoding="utf-8").splitlines() if line.strip()),
        "completed_task_count": len(completed),
        "failed_task_count": len(failed),
        "pending_task_count": len(pending),
        "policy": "exclude_completed_reinclude_failed",
        "output": str(args.output),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
