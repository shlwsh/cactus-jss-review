#!/usr/bin/env python3
"""Fail-closed C1 trace-corpus and leakage metadata audit."""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / "experiments/runs"
SHA256 = re.compile(r"^[0-9a-f]{64}$")


def audit(runs_root: Path = RUNS) -> dict[str, Any]:
    failures: list[str] = []
    checked = 0
    pairs: dict[tuple[str, str], list[tuple[Path, dict[str, Any]]]] = defaultdict(list)
    for path in sorted(runs_root.glob("RUN-*/run_manifest.json")):
        try:
            manifest = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(manifest, dict):
            continue
        phase = str(manifest.get("protocol_phase", "")).upper()
        claims_formal_c1 = phase == "C1" or manifest.get("purpose") == "formal_phase_c1"
        if not claims_formal_c1:
            continue
        checked += 1
        if phase != "C1":
            failures.append(f"{path}: formal C1 purpose is missing protocol_phase=C1")
        if manifest.get("publishable_result") is not True:
            failures.append(f"{path}: formal C1 run must set publishable_result=true")
        if not isinstance(manifest.get("paired_c1"), dict):
            failures.append(f"{path}: formal C1 run is missing matched-pair metadata")
        else:
            pair = manifest["paired_c1"]
            for key in ("pair_id", "block_id", "order_digest", "protocol_seed_sha256", "max_pair_gap_minutes", "variant_order", "variant_position"):
                if key not in pair:
                    failures.append(f"{path}: paired_c1 missing {key}")
            if manifest.get("task_id") and pair.get("pair_id"):
                pairs[(str(manifest.get("experiment_id", "")), str(pair["pair_id"]))].append((path, manifest))
        for key in ("trace_corpus_id", "trace_corpus_hash", "trace_corpus_freeze_timestamp"):
            if not manifest.get(key):
                failures.append(f"{path}: missing {key}")
        digest = manifest.get("trace_corpus_hash")
        if digest and not SHA256.fullmatch(str(digest)):
            failures.append(f"{path}: trace_corpus_hash is not full SHA-256")
        inputs = manifest.get("historical_trace_inputs")
        if not isinstance(inputs, list):
            failures.append(f"{path}: historical_trace_inputs must be present as a list")
            continue
        for index, record in enumerate(inputs):
            if not isinstance(record, dict):
                failures.append(f"{path}: historical_trace_inputs[{index}] is not an object")
                continue
            for key in ("trace_corpus_id", "trace_timestamp", "source_path", "source_sha256", "trace_task_id"):
                if not record.get(key):
                    failures.append(f"{path}: historical_trace_inputs[{index}] missing {key}")
            source_hash = record.get("source_sha256")
            if source_hash and not SHA256.fullmatch(str(source_hash)):
                failures.append(f"{path}: historical_trace_inputs[{index}] source_sha256 is invalid")
            if manifest.get("task_id") and record.get("trace_task_id") == manifest.get("task_id"):
                failures.append(f"{path}: same-task historical trace is forbidden")
            for flag in ("phase_c0_outcome_derived", "task_order_dependent", "same_issue_history"):
                if record.get(flag) is True:
                    failures.append(f"{path}: forbidden trace flag {flag}=true")
    for (_, pair_id), members in sorted(pairs.items()):
        if len(members) != 2:
            failures.append(f"{pair_id}: expected exactly two sealed variant RUNs, found {len(members)}")
            continue
        try:
            manifests = [manifest for _, manifest in sorted(members, key=lambda item: int(item[1]["paired_c1"]["variant_position"]))]
            first, second = manifests
            left, right = (manifest["paired_c1"] for manifest in manifests)
            if first.get("task_id") != second.get("task_id"):
                failures.append(f"{pair_id}: paired RUNs have different task IDs")
            if first.get("variant_id") == second.get("variant_id"):
                failures.append(f"{pair_id}: paired RUNs use the same variant")
            if [left.get("variant_position"), right.get("variant_position")] != [0, 1]:
                failures.append(f"{pair_id}: variant positions are not ordered 0,1")
            order = left.get("variant_order")
            if order not in (["cactus_full", "maximal_context"], ["maximal_context", "cactus_full"]):
                failures.append(f"{pair_id}: frozen variant order is invalid")
            elif [first.get("variant_id"), second.get("variant_id")] != order:
                failures.append(f"{pair_id}: manifest variant IDs disagree with frozen variant order")
            for key in ("block_id", "order_digest", "protocol_seed_sha256", "max_pair_gap_minutes", "variant_order"):
                if left.get(key) != right.get(key):
                    failures.append(f"{pair_id}: paired RUNs disagree on {key}")
            if right.get("first_variant_started_at") != first.get("started_at"):
                failures.append(f"{pair_id}: second RUN does not bind the first start timestamp")
            max_gap = int(right.get("max_pair_gap_minutes", 0))
            first_at = datetime.strptime(first["started_at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            second_at = datetime.strptime(second["started_at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            gap = (second_at - first_at).total_seconds()
            if max_gap <= 0 or gap < 0 or gap > max_gap * 60 + 1:
                failures.append(f"{pair_id}: pair gap {gap:.3f}s exceeds frozen limit {max_gap} minutes")
        except (KeyError, TypeError, ValueError) as exc:
            failures.append(f"{pair_id}: invalid pair timing or metadata ({type(exc).__name__})")
    return {"status": "fail" if failures else "pass", "primary_c1_runs_checked": checked, "paired_task_count": len(pairs), "failures": failures}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=RUNS)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = audit(args.runs)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if args.strict and result["failures"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
