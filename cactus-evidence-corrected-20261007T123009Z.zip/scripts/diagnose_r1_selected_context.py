"""Offline diagnostic for the R1 dry-run path-selection failure.

Reproduces the OfflineAgentLoop selection phase for
``astropy__astropy-12907`` (variant=``maximal_context``) **without** invoking
any language model.  The script:

1. Loads the R1 trace from
   ``acm/experiments/runs/RUN-20260925T030818Z-F8B5701A``.
2. Rebuilds the parsed issue text, the generated ``ContextUnit`` set, and the
   selection plan that ``maximal_context`` would have produced given the same
   12 000-token budget the R1 contract pinned.
3. Prints (and writes to a JSON sidecar) the selected ``unit.path`` set, the
   full path set produced by the parser's ``mentioned_files`` field, and the
   token count of the ``astropy/modeling/separable.py`` file unit when it
   exists in the repository snapshot.
4. Compares the selected paths with the model output path
   ``astropy/modeling/separable.py`` and reports the exact reason the patch
   validation rejected the candidate.

This script never reads ``CACTUS_LITELLM_API_KEY`` and never opens a network
connection.  It is safe to run on the host without invoking the production
execution path.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from cactus.repository.index import build_index
from cactus.selection.maximal_context import select_maximal_context
from cactus.task.parser import parse_task

# ``scripts/`` is a flat directory without an ``__init__.py``; the package is
# reached by ensuring ``<repo>/acm`` is on ``sys.path`` and importing the
# sibling module under its dotted ``scripts`` namespace.
if str(Path(__file__).resolve().parent.parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scripts.cactus_swebench_predict import _path_matches_allowed

REPO_DEFAULT = Path(r"E:\cactus-data\swebench\_index-bench-astropy\astropy")
RUN_DEFAULT = Path(
    r"E:\work\p5-acm\acm\experiments\runs\RUN-20260925T030818Z-F8B5701A"
)
MODEL_PATH = "astropy/modeling/separable.py"


@dataclass(frozen=True)
class DiagnosticFinding:
    issue_id: str
    variant: str
    budget: int
    mentioned_files: tuple[str, ...]
    units_total: int
    separable_token_count: int | None
    separable_in_units: bool
    selected_paths: tuple[str, ...]
    selected_token_count: int
    selected_count: int
    model_path: str
    model_path_in_selected: bool
    model_path_basename_in_selected: bool
    verdict: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "issue_id": self.issue_id,
            "variant": self.variant,
            "budget": self.budget,
            "mentioned_files": list(self.mentioned_files),
            "units_total": self.units_total,
            "separable_token_count": self.separable_token_count,
            "separable_in_units": self.separable_in_units,
            "selected_paths": list(self.selected_paths),
            "selected_token_count": self.selected_token_count,
            "selected_count": self.selected_count,
            "model_path": self.model_path,
            "model_path_in_selected": self.model_path_in_selected,
            "model_path_basename_in_selected": self.model_path_basename_in_selected,
            "verdict": self.verdict,
        }


def load_issue_text(run_dir: Path) -> tuple[str, str]:
    events_path = run_dir / "trace" / "events.jsonl"
    if not events_path.is_file():
        raise FileNotFoundError(f"missing trace file: {events_path}")
    issue_id = "astropy__astropy-12907"
    prompt_text = ""
    issue_body = ""
    with events_path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            event = json.loads(line)
            payload = event.get("payload", {})
            if event.get("type") == "observe" and payload.get("turn_id", "").endswith(issue_id):
                prompt_text = str(payload.get("task", ""))
                if prompt_text:
                    break
    if not prompt_text:
        raise RuntimeError(f"could not extract issue text from {events_path}")
    # ``engine.propose`` receives the clean issue body that follows the
    # ``SWE-bench issue to solve:`` marker.  Reconstruct that slice so the
    # diagnostic mirrors what ``parse_task`` saw during R1.
    marker = "SWE-bench issue to solve:"
    start = prompt_text.find(marker)
    if start >= 0:
        body = prompt_text[start + len(marker):]
        cut = body.find("Return only statement edit JSON")
        if cut < 0:
            cut = body.find("Return one JSON object")
        if cut >= 0:
            body = body[:cut]
        issue_body = body.strip()
    else:
        issue_body = prompt_text
    return issue_id, issue_body


def diagnose(
    repo_root: Path,
    run_dir: Path,
    budget: int,
    variant: str,
    output_path: Path,
) -> DiagnosticFinding:
    issue_id, task_text = load_issue_text(run_dir)
    intent = parse_task(task_text)
    mentioned = intent.mentioned_files
    index = build_index(repo_root)
    units = index.units
    selected_ids = select_maximal_context(
        units, budget=budget, mentioned_files=mentioned
    )
    selected_units = [u for u in units if u.unit_id in selected_ids]
    selected_paths = tuple(sorted({u.path for u in selected_units}))
    selected_tokens = sum(u.token_count for u in selected_units)
    separable_units = [u for u in units if u.path == "modeling/separable.py" and u.kind == "file"]
    separable_in_units = bool(separable_units)
    separable_token_count = (
        sum(u.token_count for u in separable_units) if separable_in_units else None
    )
    model_path_in_selected = any(u.path == MODEL_PATH for u in selected_units)
    model_path_basename_in_selected = _path_matches_allowed(
        MODEL_PATH, set(selected_paths)
    )
    if not separable_in_units:
        verdict = (
            f"REPO_MISSING: modeling/separable.py not found under {repo_root}; "
            "cannot evaluate whether maximal_context would have selected it."
        )
    elif model_path_in_selected:
        verdict = (
            "PATH_EXACT_OK: the selected unit set contains a path that "
            "exactly matches the model output ('astropy/modeling/separable.py')."
        )
    elif model_path_basename_in_selected:
        verdict = (
            "BASENAME_OK: the selected unit set contains a path with basename "
            "'separable.py' (e.g. 'modeling/separable.py'); the validator fix "
            "(_path_matches_allowed) accepts the model output via the "
            "basename alias. Fix-B selected the right unit; Fix-A lets the "
            "validator accept the leading 'astropy/' prefix the model emits."
        )
    else:
        verdict = (
            f"NOT_SELECTED: modeling/separable.py is in the unit set "
            f"(tokens={separable_token_count}) but maximal_context did not "
            f"include it. Mentioned files were {mentioned}."
        )
    finding = DiagnosticFinding(
        issue_id=issue_id,
        variant=variant,
        budget=budget,
        mentioned_files=mentioned,
        units_total=len(units),
        separable_token_count=separable_token_count,
        separable_in_units=separable_in_units,
        selected_paths=selected_paths,
        selected_token_count=selected_tokens,
        selected_count=len(selected_units),
        model_path=MODEL_PATH,
        model_path_in_selected=model_path_in_selected,
        model_path_basename_in_selected=model_path_basename_in_selected,
        verdict=verdict,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(finding.to_dict(), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return finding


def render_summary(finding: DiagnosticFinding) -> str:
    lines = [
        "===== R1 selected-context diagnostic =====",
        f"issue_id                      : {finding.issue_id}",
        f"variant                       : {finding.variant}",
        f"budget                        : {finding.budget} tokens",
        f"mentioned_files               : {len(finding.mentioned_files)} entries",
        f"  - {finding.mentioned_files}",
        f"units in repo                 : {finding.units_total}",
        f"separable.py in units         : {finding.separable_in_units}",
        f"separable.py tokens           : {finding.separable_token_count}",
        f"selected units                : {finding.selected_count} (tokens={finding.selected_token_count})",
        f"model output path             : {finding.model_path}",
        f"path exact match in selected  : {finding.model_path_in_selected}",
        f"basename alias match          : {finding.model_path_basename_in_selected}",
        f"verdict                       : {finding.verdict}",
        "==========================================",
    ]
    return "\n".join(lines)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=REPO_DEFAULT)
    parser.add_argument("--run-dir", type=Path, default=RUN_DEFAULT)
    parser.add_argument("--budget", type=int, default=12000)
    parser.add_argument("--variant", default="maximal_context")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(
            r"E:\work\p5-acm\acm\experiments\runs\RUN-20260925T030818Z-F8B5701A\raw\selected_context_diagnostic.json"
        ),
    )
    args = parser.parse_args(argv)
    finding = diagnose(
        repo_root=args.repo_root,
        run_dir=args.run_dir,
        budget=args.budget,
        variant=args.variant,
        output_path=args.output,
    )
    print(render_summary(finding))
    print(f"diagnostic sidecar            : {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
