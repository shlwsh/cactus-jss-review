"""Extract token and context statistics from RUN bundle traces.

Architecture:
  - Reads trace/events.jsonl from each RUN bundle
  - Extracts: task_id, input_tokens, output_tokens, selected_files, context_budget
  - Computes: SCR (Selected Context Ratio) when full_context_tokens available
  - Outputs: per-task and per-repository aggregate statistics

SCR definition:
  SCR = selected_context_tokens / full_context_tokens
  - selected_context_tokens: tokens in CACTUS-selected files (from context_selected event)
  - full_context_tokens: tokens in full repository (requires Phase B full-context baseline run)

Provenance:
  Each output artifact includes:
    - schema_version, artifact_id
    - artifact_sha256 (of output CSV/JSON)
    - generated_at (UTC ISO 8601)
    - generator: path, commit, version, arguments
    - inputs: result_id, source path, sha256, role (directed_value / measured / baseline)
    - transform: transform_id, parameters

Usage:
  python scripts/analyze_traces.py --bundles-dir experiments/runs --output paper/data/
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def sha256_str(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()


def parse_trace(trace_path: Path) -> dict | None:
    """Parse trace/events.jsonl and extract token metrics.

    Returns dict with keys:
      - task_id: str
      - input_tokens: int
      - output_tokens: int
      - selected_files: int
      - context_budget: int
      - model_id: str
      - utc_ts: str
    Returns None if trace cannot be parsed.
    """
    if not trace_path.exists():
        return None
    events = {}
    with open(trace_path, encoding="utf-8") as f:
        for line in f:
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            etype = e.get("type")
            if etype in events:
                continue  # keep first occurrence
            events[etype] = e

    # Extract task from observe event
    observe = events.get("observe", {})
    payload = observe.get("payload", {})
    task_text: str = payload.get("task", "")
    turn_id: str = payload.get("turn_id", "")
    task_id = ""
    if task_text:
        # task_id is embedded in turn_id: "predict-{repo__{instance}}"
        task_id = turn_id.replace("predict-", "") if turn_id else ""
    elif "run_id" in observe:
        task_id = observe["run_id"].replace("PRED-", "")

    ctx_sel = events.get("context_selected", {})
    ctx_payload = ctx_sel.get("payload", {})
    model_call = events.get("model_call", {})
    mc_payload = model_call.get("payload", {})

    return {
        "task_id": task_id,
        "repository": task_id.split("__")[0] if "__" in task_id else task_id,
        "input_tokens": mc_payload.get("input_tokens") or 0,
        "output_tokens": mc_payload.get("output_tokens") or 0,
        "selected_files": len(ctx_payload.get("selected", [])),
        "context_budget": ctx_payload.get("tokens") or 0,
        "model_id": mc_payload.get("model_id", "unknown"),
        "utc_ts": observe.get("utc_ts", ""),
    }


def aggregate_by_repository(rows: list[dict]) -> dict[str, dict]:
    """Aggregate token metrics by repository."""
    from collections import defaultdict

    repos: dict[str, dict] = defaultdict(
        lambda: {
            "tasks": 0,
            "input_tokens_sum": 0,
            "input_tokens_list": [],
            "output_tokens_sum": 0,
            "selected_files_sum": 0,
            "context_budget_sum": 0,
            "input_tokens_mean": 0.0,
            "input_tokens_median": 0.0,
        }
    )
    for row in rows:
        repo = row["repository"]
        repos[repo]["tasks"] += 1
        repos[repo]["input_tokens_sum"] += row["input_tokens"]
        repos[repo]["input_tokens_list"].append(row["input_tokens"])
        repos[repo]["output_tokens_sum"] += row["output_tokens"]
        repos[repo]["selected_files_sum"] += row["selected_files"]
        repos[repo]["context_budget_sum"] += row["context_budget"]

    for repo, stats in repos.items():
        lst = stats["input_tokens_list"]
        stats["input_tokens_mean"] = sum(lst) / len(lst) if lst else 0
        sorted_lst = sorted(lst)
        n = len(sorted_lst)
        stats["input_tokens_median"] = (
            sorted_lst[n // 2] if n % 2 == 1 else (sorted_lst[n // 2 - 1] + sorted_lst[n // 2]) / 2
        )

    return dict(repos)


def write_provenance(
    output_path: Path,
    source_files: list[Path],
    artifact_id: str,
    transform_id: str,
    transform_params: dict,
    status: str,
    note: str,
) -> None:
    """Write provenance JSON sidecar."""
    # Use POSIX-style relative path from project root (e:\work\p5-acm\acm)
    try:
        project_root = Path(__file__).resolve().parent.parent  # acm/scripts -> acm
        rel_path = output_path.resolve().relative_to(project_root)
    except ValueError:
        rel_path = output_path
    sidecar = {
        "schema_version": "2.0",
        "artifact_id": artifact_id,
        "artifact_type": "table",
        "artifact_path": str(rel_path).replace("\\", "/"),
        "artifact_sha256": sha256_file(output_path),
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "generator": {
            "path": "scripts/analyze_traces.py",
            "commit": None,  # filled by caller if available
            "version": "1.0.0",
            "arguments": [],
        },
        "inputs": [
            {
                "result_id": None,
                "source": str(sf).replace("\\", "/"),
                "role": "measured",
                "sha256": sha256_file(sf),
                "note": f"RUN bundle trace: {sf.name}",
            }
            for sf in source_files
        ],
        "transform": {
            "transform_id": transform_id,
            "parameters": transform_params,
        },
        "status": status,
        "note": note,
    }
    sidecar_path = output_path.with_name(output_path.stem + "_provenance.json")
    sidecar_path.write_text(json.dumps(sidecar, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract token metrics from RUN bundle traces")
    parser.add_argument(
        "--bundles-dir",
        type=Path,
        default=Path("experiments/runs"),
        help="Directory containing RUN-* bundles",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("paper/data"),
        help="Output directory for CSV and provenance",
    )
    parser.add_argument(
        "--full-context-csv",
        type=Path,
        default=None,
        help="Optional CSV with full-context baseline: task_id,full_context_tokens",
    )
    args = parser.parse_args()

    bundles_dir = Path(args.bundles_dir)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Collect all RUN bundles with traces
    bundles: list[tuple[Path, dict]] = []
    for bundle_dir in sorted(bundles_dir.iterdir()):
        if not bundle_dir.name.startswith("RUN-"):
            continue
        trace_path = bundle_dir / "trace" / "events.jsonl"
        if not trace_path.exists():
            continue
        metrics = parse_trace(trace_path)
        if metrics and metrics.get("task_id"):
            bundles.append((bundle_dir, metrics))

    if not bundles:
        print("No trace bundles found.")
        return

    rows = [metrics for _, metrics in bundles]

    # Write per-task CSV
    task_csv = output_dir / "trace_token_metrics.csv"
    fieldnames = ["task_id", "repository", "input_tokens", "output_tokens", "selected_files", "context_budget", "model_id", "utc_ts"]
    with open(task_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {task_csv} ({len(rows)} tasks)")

    # Write provenance
    source_files = [bundle_dir / "trace" / "events.jsonl" for bundle_dir, _ in bundles]
    write_provenance(
        task_csv,
        source_files,
        "trace_token_metrics",
        "extract_from_traces",
        {"bundles_dir": str(bundles_dir), "task_count": len(bundles)},
        "preliminary_pilot",
        f"Extracted from {len(bundles)} pilot RUN bundle traces. SCR computation pending Phase B full-context baseline.",
    )

    # Per-repository aggregates
    repo_aggs = aggregate_by_repository(rows)
    repo_csv = output_dir / "trace_repo_aggregates.csv"
    with open(repo_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["repository", "tasks", "input_tokens_sum", "input_tokens_mean", "input_tokens_median", "output_tokens_sum", "selected_files_sum", "context_budget_sum"])
        writer.writeheader()
        for repo, stats in sorted(repo_aggs.items(), key=lambda x: -x[1]["tasks"]):
            writer.writerow({
                "repository": repo,
                "tasks": stats["tasks"],
                "input_tokens_sum": stats["input_tokens_sum"],
                "input_tokens_mean": round(stats["input_tokens_mean"], 1),
                "input_tokens_median": round(stats["input_tokens_median"], 1),
                "output_tokens_sum": stats["output_tokens_sum"],
                "selected_files_sum": stats["selected_files_sum"],
                "context_budget_sum": stats["context_budget_sum"],
            })
    print(f"Wrote {repo_csv} ({len(repo_aggs)} repositories)")

    # Print summary
    print()
    print("=== Pilot Token Summary ===")
    for row in rows:
        print(f"  {row['task_id']}: input={row['input_tokens']} output={row['output_tokens']} files={row['selected_files']} budget={row['context_budget']}")
    print()
    print("Status: preliminary pilot data. SCR requires Phase B full-context baseline run.")
    print(f"Total bundles: {len(bundles)}")


if __name__ == "__main__":
    main()
