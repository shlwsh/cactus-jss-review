"""FACO Ablation Experiment: Compare cactus_full vs lexical_bm25 vs maximal_context.

Runs each of the 50 Lite50 tasks with each variant, collects patch success rates,
and outputs a comparison table.

Usage:
    python scripts/run_ablation_experiment.py [--variant cactus_full|lexical_bm25|maximal_context]
                                             [--limit N] [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"
MANIFEST = PROJECT_ROOT / "data/manifests/swebench_lite50_b0dde109_test_inference_safe.jsonl"
MODEL_CONFIG = PROJECT_ROOT / "configs/models/lite50_v3_dual_insurance.json"

VARIANTS = ["cactus_full", "lexical_bm25", "maximal_context"]

ALL_TASKS = [
    "astropy__astropy-12907", "astropy__astropy-14182", "astropy__astropy-14365",
    "astropy__astropy-14995", "astropy__astropy-6938", "astropy__astropy-7746",
    "django__django-10914", "django__django-10924", "django__django-11001",
    "django__django-11019", "django__django-11039", "django__django-11049",
    "django__django-11099", "django__django-11133", "django__django-11179",
    "django__django-11283", "django__django-11422", "django__django-11564",
    "django__django-11583", "django__django-11620", "django__django-11630",
    "django__django-11742", "django__django-11797", "django__django-11815",
    "django__django-11848", "django__django-11905", "django__django-11910",
    "django__django-11964", "django__django-11999", "django__django-12113",
    "django__django-12125", "django__django-12184", "django__django-12284",
    "django__django-12286", "django__django-12308", "django__django-12453",
    "django__django-12470", "django__django-12497", "django__django-12589",
    "django__django-12700", "django__django-12708", "django__django-12747",
    "django__django-12856", "django__django-12908", "django__django-12915",
    "django__django-12983", "django__django-13028", "django__django-13033",
    "django__django-13158", "django__django-13220",
]


def get_best_patch(run_dir: Path, task_id: str) -> tuple[bool, int, str | None]:
    """Return (has_patch, patch_len, run_name) for the best patch across runs."""
    best_len = 0
    best_run = None
    for run_name in sorted(run_dir.iterdir()):
        if not run_name.is_dir():
            continue
        pred_path = run_name / task_id / "prediction.jsonl"
        if pred_path.exists():
            try:
                with open(pred_path, encoding="utf-8") as f:
                    data = json.loads(f.readline())
                patch = data.get("model_patch", "")
                if patch and patch.strip() and len(patch) > best_len:
                    best_len = len(patch)
                    best_run = run_name.name
            except Exception:
                pass
    return best_len > 0, best_len, best_run


def run_one(task_id: str, variant: str, validation_id: str, dry_run: bool) -> dict:
    """Run a single task prediction."""
    output_dir = RUNS_DIR / validation_id / task_id
    output_dir.mkdir(parents=True, exist_ok=True)
    trace_path = output_dir / "trace.jsonl"

    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_single_task_predict.py"),
        "--task-id", task_id,
        "--variant", variant,
        "--validation-id", validation_id,
    ]

    if dry_run:
        print(f"  [DRY RUN] {' '.join(cmd)}")
        return {"task_id": task_id, "variant": variant, "status": "dry_run", "duration": 0}

    started = time.time()
    try:
        result = subprocess.run(
            cmd,
            cwd=str(PROJECT_ROOT),
            env={**subprocess.os.environ, "PYTHONPATH": str(PROJECT_ROOT)},
            capture_output=True,
            text=True,
            timeout=900,
        )
        duration = time.time() - started
        success = result.returncode == 0
        has_patch = False
        patch_len = 0
        if success:
            has_patch, patch_len, _ = get_best_patch(RUNS_DIR, task_id)
        return {
            "task_id": task_id,
            "variant": variant,
            "status": "PASS" if has_patch else "FAIL",
            "patch_len": patch_len,
            "duration": round(duration, 1),
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        duration = time.time() - started
        return {
            "task_id": task_id,
            "variant": variant,
            "status": "TIMEOUT",
            "duration": round(duration, 1),
            "returncode": -1,
        }
    except Exception as e:
        duration = time.time() - started
        return {
            "task_id": task_id,
            "variant": variant,
            "status": "ERROR",
            "error": str(e),
            "duration": round(duration, 1),
            "returncode": -2,
        }


def run_variant(variant: str, tasks: list[str], limit: int | None, dry_run: bool) -> list[dict]:
    """Run all tasks for a given variant."""
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    validation_id = f"ABLATION-{variant.upper()}-{ts}"
    print(f"\n=== Variant: {variant} ===")
    print(f"Validation ID: {validation_id}")
    print(f"Tasks: {len(tasks)}")

    results = []
    for i, task_id in enumerate(tasks):
        if limit and i >= limit:
            break
        print(f"  [{i+1}/{len(tasks)}] {task_id}...", end=" ", flush=True)
        result = run_one(task_id, variant, validation_id, dry_run)
        results.append(result)
        print(f"{result['status']} ({result.get('duration', 0):.0f}s)")
        if not dry_run:
            time.sleep(2)  # Rate limiting

    return results


def summarize(results: list[dict], variant: str) -> dict:
    """Summarize results for a variant."""
    total = len(results)
    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    timeout = sum(1 for r in results if r["status"] == "TIMEOUT")
    error = sum(1 for r in results if r["status"] == "ERROR")
    durations = [r["duration"] for r in results if r.get("duration")]
    avg_duration = sum(durations) / len(durations) if durations else 0
    return {
        "variant": variant,
        "total": total,
        "passed": passed,
        "failed": failed,
        "timeout": timeout,
        "error": error,
        "pass_rate": f"{passed}/{total}" if total else "0/0",
        "avg_duration": round(avg_duration, 1),
    }


def main():
    parser = argparse.ArgumentParser(description="FACO Ablation Experiment")
    parser.add_argument("--variant", choices=VARIANTS, default=None,
                        help="Run a single variant (default: all)")
    parser.add_argument("--limit", type=int, default=None,
                        help="Limit number of tasks per variant (for testing)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show commands without executing")
    args = parser.parse_args()

    variants_to_run = [args.variant] if args.variant else VARIANTS
    all_results = {}

    for variant in variants_to_run:
        tasks = ALL_TASKS[:args.limit] if args.limit else ALL_TASKS
        results = run_variant(variant, tasks, args.limit, args.dry_run)
        all_results[variant] = results

    if args.dry_run:
        print("\n[Dry run - no actual execution]")
        return

    # Print summary table
    print("\n" + "=" * 70)
    print("ABLATION EXPERIMENT SUMMARY")
    print("=" * 70)
    print(f"{'Variant':<20} {'Total':>8} {'PASS':>8} {'FAIL':>8} {'Rate':>10} {'Avg(s)':>10}")
    print("-" * 70)

    summaries = {}
    for variant, results in all_results.items():
        s = summarize(results, variant)
        summaries[variant] = s
        print(f"{variant:<20} {s['total']:>8} {s['passed']:>8} "
              f"{s['failed']:>8} {s['pass_rate']:>10} {s['avg_duration']:>10.1f}")

    # Save results
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_path = PROJECT_ROOT / "experiments" / "derived" / f"ablation_results_{ts}.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({"summaries": summaries, "detailed": all_results,
                   "generated_at": ts}, f, ensure_ascii=False, indent=2)
    print(f"\nResults saved: {output_path}")
    print("=" * 70)


if __name__ == "__main__":
    main()
