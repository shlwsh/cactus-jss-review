"""Analyze the patch bytes in prediction.jsonl."""
import json

with open(r'E:\work\p5-acm\acm\experiments\runs\RUN-20260926T234704Z-9FBDF2BD\raw\prediction.jsonl', 'rb') as f:
    content = f.read()

print('Total bytes:', len(content))

# Parse JSON
data = json.loads(content)
patch = data['model_patch']
print('Patch length (chars):', len(patch))
print('Patch repr:', repr(patch))
print()

# Check line endings
print('Lines in patch:')
for i, line in enumerate(patch.split('\n')):
    print(f'  {i+1:2d}: {line!r}')
