"""launch_r4.py — Launch the R4 engineering-validation campaign.

This is a one-shot bootstrap that:
  1. Resolves the 7 required CACTUS session keys via inject_session_keys logic.
  2. Spawns scripts.run_swebench_campaign with the R4 contract / approval /
     plan / model-config / task-manifest, matching the prior R3 invocation
     surface so audit logs line up.
  3. Streams output to a timestamped log under experiments/runs/.

Usage:
  & .\\.venv\\Scripts\\python.exe scripts\\launch_r4.py
"""

from __future__ import annotations

import datetime as dt
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

from inject_session_keys import REQUIRED_KEYS, load_resolved  # noqa: E402

CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
APPROVAL = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
PLAN = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json"
# NOTE: The contract mandates model.config = "configs/models/litellm_local_nothink_v7.json".
# We pass the resolved absolute path so the campaign runner's path-equality check passes.
MODEL_CONFIG = (ROOT / "configs" / "models" / "litellm_local_nothink_v7.json").resolve()
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
OUTPUT_ROOT = ROOT / "experiments" / "runs"
REPO_CACHE = ROOT / "experiments" / "repo_cache"
DATASET = Path(r"E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
CAMPAIGN_ID = "phase-c1-engineering-validation-r4-20260925"

RUNNER = ROOT / "scripts" / "run_swebench_campaign.py"
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"


def main() -> int:
    env_path, resolved = load_resolved()
    env = {**os.environ, **{k: resolved[k]["value"] for k in REQUIRED_KEYS}}

    for required in (CONTRACT, APPROVAL, PLAN, MODEL_CONFIG, TASK_MANIFEST, RUNNER, DATASET):
        if not required.exists():
            print(f"ERROR: required path missing: {required}", file=sys.stderr)
            return 2

    log_path = OUTPUT_ROOT / f"_r4_launch_{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    cmd = [
        str(PYTHON),
        "-m", "scripts.run_swebench_campaign",
        "--contract", str(CONTRACT),
        "--approval", str(APPROVAL),
        "--model-config", str(MODEL_CONFIG),
        "--tasks", str(TASK_MANIFEST),
        "--output-root", str(OUTPUT_ROOT),
        "--repo-cache", str(REPO_CACHE),
        "--evaluator-dataset", str(DATASET),
        "--project-root", str(ROOT),
        "--pair-plan", str(PLAN),
        "--campaign-id", CAMPAIGN_ID,
        "--limit", "3",
    ]

    print("=" * 70)
    print("R4 LAUNCH")
    print("=" * 70)
    print(f"env source : {env_path}")
    print(f"contract   : {CONTRACT}")
    print(f"approval   : {APPROVAL}")
    print(f"plan       : {PLAN}")
    print(f"model_cfg  : {MODEL_CONFIG}")
    print(f"tasks      : {TASK_MANIFEST}")
    print(f"output     : {OUTPUT_ROOT}")
    print(f"repo_cache : {REPO_CACHE}")
    print(f"dataset    : {DATASET}")
    print(f"campaign   : {CAMPAIGN_ID}")
    print(f"log        : {log_path}")
    print()
    print("$ " + " ".join(cmd))
    print()
    print("=" * 70)

    with log_path.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"# R4 launch log\n# cmd: {' '.join(cmd)}\n# env: {env_path}\n# started: {dt.datetime.now(dt.timezone.utc).isoformat()}\n\n")
        fh.flush()
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT.parent),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            fh.write(line)
            fh.flush()
        rc = proc.wait()
        fh.write(f"\n# finished: {dt.datetime.now(dt.timezone.utc).isoformat()}  exit={rc}\n")

    print()
    print("=" * 70)
    print(f"R4 launch finished with exit code {rc}")
    print(f"log: {log_path}")
    print("=" * 70)
    return rc


if __name__ == "__main__":
    sys.exit(main())
