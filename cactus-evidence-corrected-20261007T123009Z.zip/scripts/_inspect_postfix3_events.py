"""Inspect events for one task."""
import json, sys
from pathlib import Path

names = sys.argv[1:] or [
    'django__django-11910',
    'django__django-12125',
]
base_dir = Path('experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z')
for name in names:
    base = base_dir / name
    evs = base / 'events.jsonl'
    plog = base / 'predict.log'
    print(f'=== {name} ===')
    if plog.exists():
        print(f'predict.log: {plog.read_text(encoding="utf-8",errors="ignore").strip()[-300:]}')
    if not evs.exists():
        print('  (no events.jsonl)'); continue
    keys_of_interest = (
        'MODEL_OUTPUT', 'SITES_SELECTED', 'PREDICTION_REJECTED',
        'SITES_CANDIDATES', 'token_reservation_settled',
        'context_override', 'PREDICTION_RESULT',
        'prediction_rejected', 'prediction_sites_rejected',
        'prediction_exhausted',
    )
    for line in evs.read_text(encoding='utf-8', errors='ignore').splitlines():
        try:
            e = json.loads(line)
            et = e.get('type', '?')
            if et in keys_of_interest:
                ts = e.get('ts', '')[:19]
                msg = str(e.get('message', ''))[:120]
                data = e.get('data', {})
                ds = json.dumps(data, ensure_ascii=False)[:300] if isinstance(data, dict) else str(data)[:200]
                print(f'  {ts} {et:<28} {msg}')
                print(f'      data: {ds}')
        except Exception:
            pass
    print()