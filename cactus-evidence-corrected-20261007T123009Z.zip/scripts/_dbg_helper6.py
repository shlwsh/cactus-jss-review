"""Debug _build_template_edit_for_raise to find why it returns None."""
from __future__ import annotations

import importlib.util
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

import ast

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]

ws = Path(tempfile.mkdtemp(prefix="cactus-diag-br-"))
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)

source = (repo_path / "astropy" / "timeseries" / "core.py").read_text(encoding="utf-8")

candidates = mod._find_misleading_raise_nodes(source, "astropy/timeseries/core.py")
print(f"candidates: {len(candidates)}", flush=True)

# Look at the candidate scoring
def _score(c):
    m, r, fc = c
    idx0_count = sum(1 for a in fc.args if isinstance(a, ast.Subscript) and isinstance(a.slice, ast.Constant) and a.slice.value == 0)
    has_fmt = any(isinstance(a, ast.Constant) and isinstance(a.value, str) and "{}" in a.value for a in fc.args)
    return idx0_count * 10 + (1 if has_fmt else 0)

candidates_sorted = sorted(candidates, key=_score, reverse=True)
print(f"sorted by score: {[(c[1].lineno, _score(c), c[2].lineno) for c in candidates_sorted]}", flush=True)

method, raise_node, format_call = candidates_sorted[0]
print(f"\npicked: raise @ line {raise_node.lineno}", flush=True)
print(f"raise_node.col_offset = {raise_node.col_offset}", flush=True)
print(f"format_call.lineno = {format_call.lineno}", flush=True)
print(f"format_call.col_offset = {format_call.col_offset}", flush=True)
print(f"format_call.end_lineno = {getattr(format_call, 'end_lineno', None)}", flush=True)
print(f"format_call.end_col_offset = {getattr(format_call, 'end_col_offset', None)}", flush=True)
print(f"format_call.args:", flush=True)
for i, a in enumerate(format_call.args):
    print(f"  [{i}] {type(a).__name__} = {ast.unparse(a)!r}", flush=True)
    if isinstance(a, ast.Subscript):
        print(f"    slice = {ast.unparse(a.slice)!r} (value={getattr(a.slice, 'value', '?') if isinstance(a.slice, ast.Constant) else '?'})", flush=True)

# Now call _build_template_edit_for_raise and observe
print(f"\ncalling _build_template_edit_for_raise...", flush=True)
raise_edit = mod._build_template_edit_for_raise(source, method, raise_node, format_call)
print(f"result: {raise_edit!r}", flush=True)

import shutil
shutil.rmtree(ws, ignore_errors=True)
