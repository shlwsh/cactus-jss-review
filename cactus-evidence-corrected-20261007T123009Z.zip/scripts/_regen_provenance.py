#!/usr/bin/env python3
"""Regenerate cited_papers_manifest.json provenance."""
import sys
sys.path.insert(0, 'src')
sys.path.insert(0, '.')

from scripts.artifact_provenance import write
from pathlib import Path
import json
import hashlib

ROOT = Path('.')
MANIFEST = ROOT / 'paper/data/scholar/cited_papers_manifest.json'
BIB = ROOT / 'paper/references.bib'
TEX = ROOT / 'paper/main.tex'

manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))

# 生成新的 provenance
print('Generating provenance...')
write(MANIFEST, [BIB, TEX, *(ROOT / r['file_path'] for r in manifest['records'])], Path('scripts/verify_cited_papers.py'),
      transform={'scope': 'actual_cited_keys_official_snapshots', 'PDF_archival_asserted': False}, kind='derived_dataset')

# 验证
new_sha = hashlib.sha256(MANIFEST.read_bytes()).hexdigest()
prov_path = MANIFEST.with_name(MANIFEST.name + '.provenance.json')
prov = json.loads(prov_path.read_text(encoding='utf-8'))
print(f'New artifact_sha256: {new_sha[:16]}...')
print(f'Provenance artifact_sha256: {prov["artifact_sha256"][:16]}...')
print('Done!')
