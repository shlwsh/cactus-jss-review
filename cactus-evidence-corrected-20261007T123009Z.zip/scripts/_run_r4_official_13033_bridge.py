"""R4 official-API end-to-end (bridge-bypassed variant) — 13033.

Pipeline:
  1. Skip CACTUS predict entirely (the model output is already known; the
     bridge fails on statement_edit matcher ambiguity for 13033's elif body).
  2. Hand-craft the model's retry-2 intent (missing_columns check + fallthrough
     raise) as a unified diff.
  3. Inject the diff as `model_patch` in prediction.jsonl (bypass CACTUS bridge).
  4. Run the same Docker eval that RUN-20260926T121326Z used for the gold patch,
     on the same pinned image.

This isolates the experiment to "official API's intent + Docker eval", removing
the CACTUS bridge as a confounding variable.

Output:
  experiments/runs/RUN-<ts>-<uid>/...
  raw/prediction.jsonl       ← contains model's intent patch
  raw/result.json            ← resolved to status
  logs/evaluate.stdout.log
  logs/evaluate.stderr.log
  evaluation/*.json          ← SWE-bench eval report
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl")
ENV_FILE = ROOT / "docs" / "llm" / ".env"
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
TASKS_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"

# Pinned image — same digest as RUN-20260926T121326Z (verified PASS with gold patch)
PINNED_IMAGE = "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de"
TASK_ID = "astropy__astropy-13033"

# The hand-crafted diff from the official API's retry-2 intent
DIFF_PATH = ROOT / "scratch" / "_13033_official_api_intent.diff"

PREDICT_TIMEOUT = 300
EVAL_TIMEOUT = 900

sys.path.insert(0, str(ROOT / "src"))
from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _write_json(p: Path, data: dict) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False) + "\n", encoding="utf-8")


def _load_env() -> tuple[dict, int]:
    env = os.environ.copy()
    n = 0
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k] = v.strip()
            n += 1
    return env, n


def _run_subprocess(cmd: list[str], cwd: Path, env: dict, timeout_sec: int, stdout_path: Path, stderr_path: Path) -> tuple[int, float]:
    t0 = time.monotonic()
    try:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True, text=True, timeout=timeout_sec)
    except subprocess.TimeoutExpired as exc:
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace")
        stderr = (exc.stderr or b"").decode("utf-8", errors="replace")
        stdout_path.write_text(stdout + "\n[__TIMEOUT__]", encoding="utf-8")
        stderr_path.write_text(stderr + f"\n[__TIMEOUT__ after {timeout_sec}s]", encoding="utf-8")
        return -1, time.monotonic() - t0
    stdout_path.write_text(proc.stdout, encoding="utf-8")
    stderr_path.write_text(proc.stderr, encoding="utf-8")
    return proc.returncode, time.monotonic() - t0


def setup_workspace(task_id: str, run_id: str, repo_cache: Path) -> Path:
    tasks = {t.task_id: t for t in load_manifest(TASKS_MANIFEST)}
    if task_id not in tasks:
        raise ValueError(f"task_id {task_id!r} not in manifest")
    task = tasks[task_id]
    workspace_root = Path(tempfile.gettempdir()) / f"cactus-bridge-{run_id}-{uuid.uuid4().hex[:8]}"
    workspace_root.mkdir(parents=True, exist_ok=True)
    repo_path = checkout_base_commit(
        task, cache_root=repo_cache, workspace_root=workspace_root,
        allow_network_fetch=True,
    )
    print(f"[setup:{task_id}] workspace={repo_path}", flush=True)
    return repo_path


def emit_known_patch(run_id: str, diff_path: Path) -> None:
    """Inject the hand-crafted unified diff as the SWE-bench prediction."""
    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)

    patch = diff_path.read_text(encoding="utf-8")
    pred = {
        "instance_id": TASK_ID,
        "model_name_or_path": "cactus-official-api-intent-bridge",
        "model_patch": patch,
    }
    pred_path = run_root / "raw" / "prediction.jsonl"
    pred_path.write_text(json.dumps(pred, ensure_ascii=False) + "\n", encoding="utf-8")

    trace_event = {
        "type": "model_call",
        "schema_version": "2.0",
        "payload": {
            "finish_reason": "stop",
            "input_tokens": 0,
            "output_tokens": 0,
            "prompt_chars": 0,
            "prompt_sha256": "0" * 64,
            "response_chars": len(patch),
            "response_text": f"<bridge-injected: hand-converted from deepseek-flash retry-2 intent; source={diff_path.name}>",
            "temperature": 0.0,
            "turn_id": f"predict-bridge-{TASK_ID}",
            "usage_source": "bridge_injection",
            "model_name_or_path": "cactus-official-api-intent-bridge",
            "request_timeout_sec": 0,
        },
        "ts": utc_now(),
    }
    (run_root / "trace" / "events.jsonl").write_text(
        json.dumps(trace_event, ensure_ascii=False) + "\n", encoding="utf-8",
    )
    (run_root / "logs" / "predict.stdout.log").write_text(
        f"[bridge] injected official-API intent from {diff_path.name} ({len(patch)} bytes)\n",
        encoding="utf-8",
    )
    (run_root / "logs" / "predict.stderr.log").write_text("", encoding="utf-8")
    print(f"[predict-bridge:{TASK_ID}] OK injected {len(patch)}-byte patch", flush=True)


def run_eval(run_id: str) -> bool:
    run_root = ROOT / "experiments" / "runs" / run_id
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"
    eval_dir = run_root / "evaluation"

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(pred_path),
        "--instance", TASK_ID,
        "--pinned-image", PINNED_IMAGE,
        "--run-id", run_id,
        "--workers", "1",
        "--timeout", str(EVAL_TIMEOUT),
        "--report-dir", str(eval_dir),
    ]
    print(f"[eval:{TASK_ID}] starting", flush=True)

    env, _ = _load_env()
    t0 = time.monotonic()
    rc, elapsed = _run_subprocess(
        cmd, ROOT, env, EVAL_TIMEOUT,
        logs_dir / "evaluate.stdout.log",
        logs_dir / "evaluate.stderr.log",
    )
    print(f"[eval:{TASK_ID}] rc={rc} elapsed={elapsed:.0f}s", flush=True)

    resolved = False
    reports = sorted(eval_dir.glob(f"*.{run_id}.json"))
    if reports:
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            resolved = int(rep.get("resolved_instances", 0)) > 0
            print(f"[eval:{TASK_ID}] resolved={resolved} report={reports[0].name}", flush=True)
        except Exception as exc:
            print(f"[eval:{TASK_ID}] report parse error: {exc}", flush=True)
    else:
        print(f"[eval:{TASK_ID}] no report file found in {eval_dir}", flush=True)

    raw_data = {
        "task_id": TASK_ID,
        "repo_id": "astropy/astropy",
        "base_commit": "298ccb478e6bf092953bca67a3d29dc6c35f6752",
        "evaluator_exit_code": rc,
        "evaluator_valid": rc == 0,
        "resolved": resolved,
        "prediction_hash": _sha256(pred_path) if pred_path.exists() else None,
        "source": "official_api_intent_bridge_v1",
        "patch_source": str(DIFF_PATH.relative_to(ROOT)),
        "patch_sha256": _sha256(DIFF_PATH),
        "pinned_image": PINNED_IMAGE,
    }
    raw = {
        "schema_version": "2.0", "run_id": run_id,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-OFFICIAL-BRIDGE-20260927",
        "generated_at": utc_now(), "data": raw_data,
        "evidence": {
            "origin_type": "measured", "test_scope": "end_to_end",
            "integrity_status": "verified" if resolved else "incomplete",
            "reproducibility_status": "partial",
            "statistics_status": "not_required",
        },
    }
    _write_json(run_root / "raw" / "result.json", raw)
    return resolved


def setup_bundle(run_id: str) -> Path:
    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)
    now = utc_now()
    _write_json(run_root / "environment.pre.json", {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "pre", "run_id": run_id,
        "official_api_intent_bridge": True,
        "official_api_intent_source": str(DIFF_PATH.relative_to(ROOT)),
        "official_api_intent_sha256": _sha256(DIFF_PATH),
        "pinned_image": PINNED_IMAGE,
    })
    return run_root


def main() -> int:
    ts = utc_now().replace(":", "").replace("-", "")[:15]
    uid = uuid.uuid4().hex[:8].upper()
    run_id = f"RUN-{ts}Z-{uid}"

    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] Official-API intent bridge run — task={TASK_ID}", flush=True)
    print(f"  run_id    = {run_id}", flush=True)
    print(f"  diff      = {DIFF_PATH}", flush=True)
    print(f"  diff_sha  = {_sha256(DIFF_PATH)}", flush=True)
    print(f"  image     = {PINNED_IMAGE}", flush=True)
    print(f"{'='*60}", flush=True)

    setup_bundle(run_id)
    try:
        workspace = setup_workspace(TASK_ID, run_id, REPO_CACHE)
    except Exception as exc:
        print(f"  [ERROR] workspace setup failed: {exc}", flush=True)
        return 1

    emit_known_patch(run_id, DIFF_PATH)
    resolved = run_eval(run_id)

    icon = "PASS" if resolved else "FAIL"
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] FINAL [{icon}] {TASK_ID}: resolved={resolved}", flush=True)
    print(f"  run_id = {run_id}", flush=True)
    print(f"{'='*60}", flush=True)

    try:
        shutil.rmtree(workspace.parent, ignore_errors=True)
        print(f"[cleanup] removed workspace parent: {workspace.parent}", flush=True)
    except Exception as exc:
        print(f"[cleanup] warning: {exc}", flush=True)

    return 0 if resolved else 2


if __name__ == "__main__":
    raise SystemExit(main())