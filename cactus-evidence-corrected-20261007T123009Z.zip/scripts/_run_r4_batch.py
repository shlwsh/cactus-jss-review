"""Sequential re-run for R4 failed task+variant combinations (fixed).

Key fix: litellm.py sends thinking=false via chat_template_kwargs.
Contract model.config: litellm_local_nothink_v7.json

Tasks to re-run:
  1. astropy__astropy-12907  + maximal_context
  2. astropy__astropy-13033  + cactus_full
  3. astropy__astropy-13236  + cactus_full
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
import threading
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENV_PY = ROOT / ".venv" / "Scripts" / "python.exe"

CONTRACT = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
APPROVAL = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
TASKS_MANIFEST = ROOT / "json/cactus_tasks_inference_safe.jsonl"
REPO_CACHE = ROOT / "experiments/repo_cache"
OUTPUT_ROOT = ROOT / "experiments/runs"
EVALUATOR = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
MODEL_CONFIG = ROOT / "configs/models/litellm_local_nothink_v7.json"

# Verify model config matches contract
with open(CONTRACT, encoding="utf-8") as f:
    contract_obj = json.load(f)
    contract_model = contract_obj.get("model", {}).get("config", "")
contract_path = str(MODEL_CONFIG.relative_to(ROOT)).replace("\\", "/")
print(f"Contract model.config: {contract_model}")
print(f"Using model.config:    {contract_path}")
assert contract_path == contract_model, f"Mismatch: contract={contract_model}, actual={contract_path}"
print("Model config verified against contract: OK")

ENV_FILE = ROOT / "docs/llm/.env"
KEY_TAGS = ("LITELLM", "API_KEY", "CACTUS")
PER_TASK_TIMEOUT = 1800  # 30 min


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def load_env() -> dict:
    env = {}
    if not ENV_FILE.exists():
        return env
    for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if any(tag in k.upper() for tag in KEY_TAGS):
            env[k] = v.strip()
    return env


TASKS_TO_RUN = [
    ("astropy__astropy-12907", "maximal_context"),
    ("astropy__astropy-13033", "cactus_full"),
    ("astropy__astropy-13236", "cactus_full"),
]


def check_r4_completed(task_id: str, variant: str) -> Path | None:
    """Check if an R4-specific completed run (post-20260925) with prediction exists."""
    R4_CUTOFF = "20260925"
    runs = sorted(
        [d for d in OUTPUT_ROOT.iterdir() if d.is_dir() and d.name.startswith("RUN-")],
        key=lambda x: x.name, reverse=True
    )
    for d in runs:
        if R4_CUTOFF not in d.name:
            continue
        manifest = d / "run_manifest.json"
        if not manifest.exists():
            continue
        try:
            m = json.loads(manifest.read_text(encoding="utf-8"))
        except Exception:
            continue
        if m.get("task_id") != task_id:
            continue
        if m.get("variant_id") != variant:
            continue
        if m.get("status") == "completed":
            pred = d / "raw/prediction.jsonl"
            if pred.exists():
                content = pred.read_text(encoding="utf-8").strip()
                if content:
                    try:
                        first_obj = json.loads(content.split("\n")[0])
                        patch = first_obj.get("model_patch", "")
                        if patch and len(patch) > 10:
                            return d
                    except Exception:
                        pass
    return None


def stream_output(proc: subprocess.Popen, lines: list):
    """Background thread: stream stdout to parent stdout."""
    try:
        for line in iter(proc.stdout.readline, ""):
            if line:
                sys.stdout.write(line)
                sys.stdout.flush()
                lines.append(line)
    except Exception:
        pass


def run_task(task_id: str, variant: str) -> tuple[int, str, float, list]:
    campaign_id = f"phase-c1-r4-retry-{utc_now()}-{task_id.replace('__', '-')}"

    cmd = [
        str(VENV_PY),
        "-u",
        "-m",
        "scripts.run_swebench_campaign",
        "--contract", str(CONTRACT),
        "--approval", str(APPROVAL),
        "--model-config", str(MODEL_CONFIG),
        "--tasks", str(TASKS_MANIFEST),
        "--output-root", str(OUTPUT_ROOT),
        "--repo-cache", str(REPO_CACHE),
        "--evaluator-dataset", str(EVALUATOR),
        "--project-root", str(ROOT),
        "--campaign-id", campaign_id,
        "--task-id", task_id,
        "--variant", variant,
        "--limit", "1",
    ]

    env = os.environ.copy()
    env.update(load_env())

    print(f"\n{'='*70}")
    print(f"STARTING: {task_id} | {variant}")
    print(f"Campaign: {campaign_id}")
    print(f"Model:    {MODEL_CONFIG.relative_to(ROOT)}")
    print(f"Timeout:  {PER_TASK_TIMEOUT}s")
    print(f"{'='*70}\n")
    sys.stdout.flush()

    t0 = time.time()
    proc = subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    output_lines = []
    t = threading.Thread(target=stream_output, args=(proc, output_lines), daemon=True)
    t.start()

    deadline = t0 + PER_TASK_TIMEOUT

    while True:
        rc = proc.poll()
        if rc is not None:
            # Drain remaining
            remaining = proc.stdout.read()
            if remaining:
                sys.stdout.write(remaining)
                sys.stdout.flush()
                output_lines.append(remaining)
            break

        if time.time() > deadline:
            print(f"\n[TIMEOUT] {PER_TASK_TIMEOUT}s; killing {proc.pid}", flush=True)
            proc.kill()
            proc.wait()
            remaining = proc.stdout.read()
            if remaining:
                sys.stdout.write(remaining)
                sys.stdout.flush()
            elapsed = time.time() - t0
            return -1, "", elapsed, output_lines

        time.sleep(2.0)

    elapsed = time.time() - t0

    # Extract run_id from output
    output_text = "".join(output_lines)
    found_id = ""
    for line in output_text.split("\n"):
        if "run_id" in line.lower() or "run-" in line.lower():
            ids = re.findall(r"RUN-\d{8}T\d{6}Z-[A-F0-9]+", line)
            if ids:
                found_id = ids[-1]
                break

    return rc, found_id, elapsed, output_lines


def verify_prediction(run_id: str, task_id: str, variant: str) -> str:
    """Verify the prediction is usable."""
    if not run_id:
        return "no_run_id"
    run_dir = OUTPUT_ROOT / run_id
    if not run_dir.exists():
        return f"run_dir_not_found: {run_id}"

    manifest = run_dir / "run_manifest.json"
    if manifest.exists():
        try:
            m = json.loads(manifest.read_text(encoding="utf-8"))
            if m.get("status") != "completed":
                return f"status={m.get('status')}"
        except Exception as ex:
            return f"manifest_parse_error: {ex}"
    else:
        return "no_manifest"

    pred = run_dir / "raw/prediction.jsonl"
    if not pred.exists():
        return "no_prediction_file"

    content = pred.read_text(encoding="utf-8").strip()
    if not content:
        return "empty_prediction"

    try:
        first_obj = json.loads(content.split("\n")[0])
        patch = first_obj.get("model_patch", "")
        if patch and len(patch) > 10:
            return f"OK patch_len={len(patch)}"
        else:
            return f"no_patch patch_len={len(patch)}"
    except Exception as ex:
        return f"prediction_parse_error: {ex}"


def main() -> int:
    results = []

    for i, (task_id, variant) in enumerate(TASKS_TO_RUN, 1):
        existing = check_r4_completed(task_id, variant)
        if existing:
            print(f"\nSKIP [{i}/{len(TASKS_TO_RUN)}]: {task_id} | {variant} already completed in R4 at {existing.name}")
            results.append({
                "task_id": task_id, "variant": variant,
                "status": "skipped_existing", "run_id": existing.name,
                "elapsed": 0, "rc": 0, "verification": "existing"
            })
            continue

        print(f"\n\n{'#'*70}")
        print(f"[{i}/{len(TASKS_TO_RUN)}] Running: {task_id} | {variant}")
        print(f"{'#'*70}")
        sys.stdout.flush()

        rc, run_id, elapsed, output = run_task(task_id, variant)
        verification = verify_prediction(run_id, task_id, variant)

        if rc == 0 and verification.startswith("OK"):
            status = "success"
        elif rc == -1:
            status = "timeout"
        elif rc == 0 and not verification.startswith("OK"):
            status = f"campaign_ok_but_{verification}"
        else:
            status = f"failed_rc_{rc}"

        results.append({
            "task_id": task_id, "variant": variant,
            "status": status, "run_id": run_id,
            "elapsed": elapsed, "rc": rc,
            "verification": verification
        })

        print(f"\n{'='*70}")
        print(f"RESULT [{i}/{len(TASKS_TO_RUN)}]: {task_id} | {variant}")
        print(f"  Status:     {status}")
        print(f"  Run ID:     {run_id}")
        print(f"  Elapsed:    {elapsed:.0f}s")
        print(f"  RC:         {rc}")
        print(f"  Verify:     {verification}")
        print(f"{'='*70}")
        sys.stdout.flush()

    # Summary
    print(f"\n\n{'#'*70}")
    print("FINAL SUMMARY")
    print(f"{'#'*70}")
    success_count = sum(1 for r in results if r["status"] == "success")
    for r in results:
        icon = "OK" if r["status"] == "success" else ("SKIP" if r["status"].startswith("skip") else "FAIL")
        print(f"  [{icon}] {r['task_id']} | {r['variant']} | {r['status']} | {r['run_id']} | {r['elapsed']:.0f}s")
    print(f"\nTotal: {len(results)} | Success: {success_count}/{len(results)}")
    print(f"{'#'*70}")

    results_file = OUTPUT_ROOT / f"_r4_retry_results_{utc_now()}.json"
    results_file.write_text(json.dumps({
        "timestamp": utc_now(),
        "tasks": TASKS_TO_RUN,
        "results": results,
        "model_config": str(MODEL_CONFIG.relative_to(ROOT))
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nResults saved to: {results_file}")

    return 0 if success_count == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
