"""Plan or apply cleanup of historical SWE-bench Docker images.

The default scope is deliberately narrow: only images under the SWE-bench
evaluator repository namespace are considered, and all current Pilot50 refs
are protected.  The canonical cache is one shared archive under ``shared/``;
legacy per-category archives are reported separately.  Use --apply only after
the canonical archive has been verified.
"""

from __future__ import annotations

import argparse
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PLAN = ROOT / "artifacts" / "phase_c_pilot50_plan.json"
DEFAULT_OUTPUT = ROOT / "artifacts" / "pilot50_historical_image_cleanup.json"
DEFAULT_CACHE_ROOT = Path("E:/docker-bak/cactus/pilot50")
IMAGE_NAMESPACE = "swebench/sweb.eval.x86_64."


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _list_images(command_runner=subprocess.run) -> list[dict[str, Any]]:
    result = command_runner(["docker", "image", "ls", "--no-trunc", "--format", "{{.ID}}\t{{.Repository}}:{{.Tag}}\t{{.Size}}"], capture_output=True, text=True, check=False, timeout=60)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "docker image ls failed").strip())
    rows = []
    for line in result.stdout.splitlines():
        parts = line.split("\t", 2)
        if len(parts) >= 2 and parts[0] and parts[1]:
            rows.append({"image_id": parts[0], "ref": parts[1], "size": parts[2] if len(parts) == 3 else ""})
    return rows


def plan_cleanup(plan_path: Path = DEFAULT_PLAN, output: Path = DEFAULT_OUTPUT, cache_root: Path = DEFAULT_CACHE_ROOT, apply: bool = False, command_runner=subprocess.run) -> dict[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    protected_refs = {str(item.get("image")) for item in plan.get("evaluator_images", []) if isinstance(item, dict) and item.get("image")}
    rows = _list_images(command_runner)
    by_id: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        if row["ref"].startswith(IMAGE_NAMESPACE):
            by_id.setdefault(row["image_id"], []).append(row)
    candidates = []
    for image_id, refs in sorted(by_id.items()):
        refs_set = {row["ref"] for row in refs}
        if refs_set & protected_refs:
            continue
        candidates.append({"image_id": image_id, "refs": sorted(refs_set), "sizes": sorted({row["size"] for row in refs})})
    removed: list[dict[str, Any]] = []
    if apply:
        for item in candidates:
            result = command_runner(["docker", "image", "rm", item["image_id"]], capture_output=True, text=True, check=False, timeout=120)
            removed.append({**item, "returncode": result.returncode, "message": ((result.stdout or "") + "\n" + (result.stderr or "")).strip()[-1000:]})
    canonical_archives = sorted(str(path) for path in cache_root.glob("shared/base-images.docker.tar") if path.is_file())
    legacy_archives = sorted(str(path) for path in cache_root.glob("*/images.docker.tar") if path.is_file())
    cache_archives = canonical_archives + legacy_archives
    result = {
        "schema_version": "1.0",
        "generated_at": _utc_now(),
        "scope": IMAGE_NAMESPACE,
        "plan": plan_path.as_posix(),
        "protected_ref_count": len(protected_refs),
        "cache_root": cache_root.as_posix(),
        "cache_archive_count": len(cache_archives),
        "cache_archives": cache_archives,
        "canonical_cache_archive_count": len(canonical_archives),
        "canonical_cache_archives": canonical_archives,
        "legacy_category_archive_count": len(legacy_archives),
        "legacy_category_archives": legacy_archives,
        "apply_requested": apply,
        "cleanup_performed": apply,
        "candidate_image_count": len(candidates),
        "candidates": candidates,
        "removed": removed,
        "removed_success_count": sum(item.get("returncode") == 0 for item in removed),
        "status": "complete" if not apply or all(item.get("returncode") == 0 for item in removed) else "partial_failure",
        "next_action": "Review candidates and rerun with --apply after cache archive verification." if not apply else "Re-run without --apply to verify no unprotected historical images remain.",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--cache-root", type=Path, default=DEFAULT_CACHE_ROOT)
    parser.add_argument("--apply", action="store_true", help="Remove only unprotected historical SWE-bench image IDs")
    args = parser.parse_args()
    result = plan_cleanup(args.plan, args.output, args.cache_root, args.apply)
    print(json.dumps({key: result[key] for key in ("status", "candidate_image_count", "removed_success_count", "cache_archive_count")}, ensure_ascii=False))
    return 0 if result["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
