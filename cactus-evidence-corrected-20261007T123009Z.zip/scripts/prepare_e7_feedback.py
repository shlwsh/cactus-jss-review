"""Prepare a frozen E7 retry manifest from A/B-classified failed RUN bundles."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

from cactus.governance.provenance import write_sidecar
from cactus.runner.bundle_validator import validate_bundle


def _read(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def _safe_feedback(bundle: Path) -> str:
    parts: list[str] = []
    for path in sorted((bundle / "evaluation").rglob("*.json")):
        report = _read(path)
        if report is not None:
            summary = {key: report.get(key) for key in ("resolved_instances", "unresolved_instances", "error_instances", "infra_failure_instances", "ambiguous_failure_instances") if key in report}
            parts.append("Official evaluator summary: " + json.dumps(summary, sort_keys=True))
    for name in ("evaluate.stdout.log", "evaluate.stderr.log"):
        path = bundle / "logs" / name
        if path.is_file():
            parts.append(f"{name} tail:\n" + path.read_text(encoding="utf-8", errors="replace")[-3000:])
    feedback = "\n\n".join(parts).strip()
    feedback = re.sub(r"(?i)(api[_-]?key|authorization|token)(\s*[:=]\s*)[^\s,;]+", r"\1\2[REDACTED]", feedback)
    return feedback[:8000]


def prepare(runs_root: Path, forensics_path: Path) -> list[dict[str, str]]:
    classifications = [json.loads(line) for line in forensics_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    rows: list[dict[str, str]] = []
    for finding in classifications:
        if finding.get("category") not in {"A", "B"}:
            continue
        run_id = str(finding.get("run_id", ""))
        task_id = finding.get("task_id")
        if not isinstance(task_id, str) or not task_id or not re.fullmatch(r"RUN-[A-Za-z0-9-]{1,80}", run_id):
            continue
        bundle = runs_root / run_id
        manifest = _read(bundle / "run_manifest.json") or {}
        result = _read(bundle / "raw" / "result.json") or {}
        data = result.get("data") if isinstance(result.get("data"), dict) else {}
        if (manifest.get("status") != "completed" or manifest.get("variant_id") != "cactus_test_aware"
                or manifest.get("task_id") != task_id or manifest.get("attempt_index", 0) != 0
                or data.get("evaluator_valid") is not True or data.get("resolved") is not False):
            continue
        if validate_bundle(bundle):
            continue
        feedback = _safe_feedback(bundle)
        if not feedback:
            continue
        rows.append({"task_id": task_id, "parent_run_id": run_id, "category": str(finding["category"]), "feedback": feedback})
    rows.sort(key=lambda row: row["task_id"])
    duplicates = sorted(task_id for task_id, count in Counter(row["task_id"] for row in rows).items() if count > 1)
    if duplicates:
        raise ValueError("multiple valid E7 parent RUNs found for task(s): " + ", ".join(duplicates))
    return rows


def _provenance_inputs(runs_root: Path, forensics_path: Path, rows: list[dict[str, str]]) -> list[dict[str, str]]:
    paths = {forensics_path.resolve()}
    for row in rows:
        bundle = runs_root / row["parent_run_id"]
        for relative in ("run_manifest.json", "raw/result.json"):
            path = bundle / relative
            if path.is_file():
                paths.add(path.resolve())
        for directory in (bundle / "evaluation",):
            if directory.is_dir():
                paths.update(path.resolve() for path in directory.rglob("*.json") if path.is_file())
        for name in ("evaluate.stdout.log", "evaluate.stderr.log"):
            path = bundle / "logs" / name
            if path.is_file():
                paths.add(path.resolve())
    return [
        {"path": path.as_posix(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        for path in sorted(paths, key=lambda item: item.as_posix())
    ]


def write_feedback_manifest(output: Path, runs_root: Path, forensics_path: Path, rows: list[dict[str, str]]) -> str:
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8", newline="\n")
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    write_sidecar(
        output,
        artifact_id=f"DATA-E7-RETRY-{digest[:12].upper()}",
        artifact_type="derived_dataset",
        generator_path="scripts/prepare_e7_feedback.py",
        inputs=_provenance_inputs(runs_root, forensics_path, rows),
        transform_id="e7_feedback_from_reviewed_ab_failures",
    )
    return digest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--forensics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.output.exists() and not args.overwrite:
        parser.error(f"output exists; pass --overwrite to replace it: {args.output}")
    rows = prepare(args.runs, args.forensics)
    if not rows:
        parser.error("no evaluator-valid unresolved A/B tasks with usable feedback were found")
    digest = write_feedback_manifest(args.output, args.runs, args.forensics, rows)
    print(json.dumps({"retry_tasks": len(rows), "feedback_manifest_sha256": digest, "output": str(args.output)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
