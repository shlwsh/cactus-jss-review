"""Aggregate paired experiment records without imputing evaluator errors."""

from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path


def _lens_summary(rows: list[dict[str, str]]) -> dict[str, object]:
    valid = [row for row in rows if row.get("canonical_outcome") in {"VALID_RESOLVED", "VALID_UNRESOLVED"}]
    outcomes = Counter(row.get("canonical_outcome", "pending_evidence") for row in rows)
    resolved = sum(row.get("canonical_outcome") == "VALID_RESOLVED" for row in valid)
    resolution_rate = resolved / len(valid) if valid else None
    return {
        "n_total": len(rows),
        "n_valid": len(valid),
        "n_invalid_evaluation": outcomes.get("INVALID_EVALUATION", 0),
        "valid_resolution_rate": resolution_rate,
        "conditional_resolution_rate": resolution_rate,
        "evaluator_validity_rate": len(valid) / len(rows) if rows else None,
        "evaluator_error_rate": outcomes.get("INVALID_EVALUATION", 0) / len(rows) if rows else None,
        "selected_context_ratio": None,
        "input_tokens": None,
        "output_tokens": None,
        "verified_cost": None,
        "wall_clock_time": None,
        "retry_recovery_rate": None,
        "temporal_concentration": None,
        "repo_concentration": None,
        "outcomes": dict(sorted(outcomes.items())),
    }


def _normalize_row(row: dict[str, str]) -> dict[str, str]:
    """Normalize the frozen legacy outcome CSV into the canonical vocabulary."""
    if row.get("canonical_outcome"):
        return row
    if row.get("resolved") == "1":
        return {**row, "canonical_outcome": "VALID_RESOLVED"}
    if row.get("unresolved") == "1":
        return {**row, "canonical_outcome": "VALID_UNRESOLVED"}
    if row.get("error") == "1":
        return {**row, "canonical_outcome": "INVALID_EVALUATION"}
    return {**row, "canonical_outcome": "pending_evidence"}


def aggregate_dual_lens(rows: list[dict[str, str]]) -> dict[str, object]:
    """Build all three lenses without imputing missing evaluator evidence."""
    algorithm_rows = [row for row in rows if row.get("canonical_outcome") in {"VALID_RESOLVED", "VALID_UNRESOLVED"}]
    evaluator = _lens_summary(rows)
    algorithm = _lens_summary(algorithm_rows)
    return {
        "algorithm_lens": {**algorithm, "status": "observed" if algorithm["n_valid"] else "pending_evidence"},
        "evaluator_lens": {**evaluator, "status": "observed" if rows else "pending_evidence"},
        "cross_lens": {
            "status": "pending_evidence",
            "n_recovered": 0,
            "sensitivity_to_threshold": [{"threshold": threshold, "status": "pending_evidence", "n_recovered": 0} for threshold in (0.80, 0.90, 0.95)],
            "reason": "no evaluator replay evidence",
        },
    }


def aggregate(source: Path, output: Path, *, dual_lens: bool = False) -> dict[str, object]:
    with source.open(encoding="utf-8", newline="") as handle:
        rows = [_normalize_row(row) for row in csv.DictReader(handle)]
    counts = Counter(row.get("canonical_outcome", "pending_evidence") for row in rows)
    summary = {"source": source.as_posix(), "records": len(rows), "outcomes": dict(sorted(counts.items())), "status": "observed" if rows else "pending_evidence"}
    if dual_lens:
        summary["lenses"] = aggregate_dual_lens(rows)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


def aggregate_runs(runs: Path, output: Path, *, dual_lens: bool = False) -> dict[str, object]:
    """Aggregate sealed run CSV evidence without imputing missing outcomes.

    The directory form is intentionally conservative: only CSV files that
    expose ``canonical_outcome`` are included.  Selection plans and manifests
    therefore cannot be mistaken for measured task results.
    """
    candidates: list[Path] = []
    for path in sorted(runs.rglob("*.csv")):
        try:
            with path.open(encoding="utf-8", newline="") as handle:
                fieldnames = csv.DictReader(handle).fieldnames or []
        except OSError:
            continue
        if "canonical_outcome" in fieldnames:
            candidates.append(path)
    rows: list[dict[str, str]] = []
    sources: list[str] = []
    for source in candidates:
        with source.open(encoding="utf-8", newline="") as handle:
            rows.extend(_normalize_row(row) for row in csv.DictReader(handle))
        sources.append(source.as_posix())
    # A formal RUN normally stores task evidence as JSON rather than CSV.
    # Only an explicit canonical outcome is admissible; incomplete bundles
    # remain visible as pending evidence instead of being classified here.
    for manifest in sorted(runs.rglob("run_manifest.json")):
        raw = manifest.parent / "raw" / "result.json"
        if not raw.is_file():
            continue
        try:
            payload = json.loads(raw.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, dict) or "canonical_outcome" not in data:
            continue
        rows.append({
            "instance_id": str(data.get("task_id", manifest.parent.name)),
            "canonical_outcome": str(data["canonical_outcome"]),
        })
        sources.append(raw.as_posix())
    counts = Counter(row.get("canonical_outcome", "pending_evidence") for row in rows)
    summary = {
        "source_root": runs.as_posix(),
        "source_files": sources,
        "records": len(rows),
        "outcomes": dict(sorted(counts.items())),
        "status": "observed" if rows else "pending_evidence",
    }
    if dual_lens:
        summary["lenses"] = aggregate_dual_lens(rows)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path, nargs="?")
    parser.add_argument("output", type=Path, nargs="?")
    parser.add_argument("--runs", type=Path, help="recursively aggregate measured CSV evidence")
    parser.add_argument("--output", dest="output_flag", type=Path, help="summary JSON destination for --runs")
    parser.add_argument("--dual-lens", action="store_true", help="include Algorithm/Evaluator/Cross-Lens summaries")
    args = parser.parse_args()
    if args.runs:
        destination = args.output_flag or args.output
        if destination is None:
            parser.error("--runs requires --output")
        print(json.dumps(aggregate_runs(args.runs, destination, dual_lens=args.dual_lens), ensure_ascii=False))
    elif args.source and args.output:
        print(json.dumps(aggregate(args.source, args.output, dual_lens=args.dual_lens), ensure_ascii=False))
    else:
        parser.error("provide source and output, or --runs and --output")
