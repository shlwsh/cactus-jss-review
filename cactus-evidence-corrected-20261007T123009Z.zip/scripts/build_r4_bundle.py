"""build_r4_bundle.py — Atomically build R4 dry-run bundle (card ②).

Reads:
  - experiments/plans/C1_primary_pairs_20260925_R3.json (last good plan)
  - experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json
  - experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json
  - experiments/snapshots/dacl_baseline_R2_20260925-151621.json
  - json/cactus_tasks_inference_safe.jsonl (task manifest)

Writes (NEW files only — never overwrites R1/R2/R3):
  - experiments/plans/C1_primary_pairs_20260925_R4.json
  - experiments/plans/C1_primary_pairs_20260925_R4.json.execution.json
  - experiments/plans/C1_primary_pairs_20260925_R4.json.sha256
  - experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json
  - experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.sha256
  - experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json
  - experiments/snapshots/C1-pre-r4-20260925T<UTC>_observed.json
  - experiments/snapshots/C1-pre-r4-20260925T<UTC>_observed.json.sha256
  - experiments/snapshots/dacl_baseline_R4_<UTC>.json
  - experiments/snapshots/dacl_baseline_R4_<UTC>.json.sha256

Also edits:
  - configs/models/litellm_local.json (prediction_attempt_timeout_sec 300 → 900)

Side effects:
  - Adds docs/codex/v1.0_<UTC>_CACTUS-v1.23-R4-bundle-build-report.md
  - Runs scripts/probe_current_state.py at the end (best-effort)

Usage:
  Set-Location E:\\work\\p5-acm\\acm
  & .\\.venv\\Scripts\\python.exe scripts\\build_r4_bundle.py
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

R3_PLAN = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R3.json"
R3_SIDECAR = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R3.json.execution.json"
R2_CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
R2_AUTH = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.session_authorization.json"
R2_PRE = ROOT / "experiments" / "snapshots" / "C1-pre-r2-20260925T075208Z_observed.json"
R2_BASELINE = ROOT / "experiments" / "snapshots" / "dacl_baseline_R2_20260925-151621.json"
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"

UTC = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H%M%SZ")
LOCAL = dt.datetime.now().strftime("%Y-%m-%d-%H%M%S")

# Three smallest tasks proven to round-trip through selection already.
R4_TASKS = ["astropy__astropy-12907", "astropy__astropy-13033", "astropy__astropy-13236"]


def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha_canonical(obj: dict | list) -> str:
    body = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return sha_bytes(body)


def write_sidecar_sha(target: pathlib.Path) -> None:
    """Write a `<target>.sha256` sidecar matching the body SHA exactly.

    Uses UTF-8 *without* BOM so the sidecar round-trips cleanly.
    """
    body = target.read_bytes()
    sha = sha_bytes(body)
    sidecar = target.with_suffix(target.suffix + ".sha256")
    sidecar.write_text(f"{sha}  {target.name}\n", encoding="utf-8", newline="\n")


def task_manifest_sha() -> str:
    return sha_bytes(TASK_MANIFEST.read_bytes())


def manifest_for_tasks(task_ids: list[str]) -> str:
    return TASK_MANIFEST.as_posix()


def select_unit_for_task(task_id: str) -> dict:
    """Mirror the R2/R3 plan-shape per pair: pair_id, block_id, variant_order, order_digest."""
    digest = hashlib.sha256(task_id.encode("utf-8")).hexdigest()
    return {
        "task_id": task_id,
        "pair_id": f"C1P-{digest[:16]}",
        "block_id": f"C1B-{digest[:16]}",
        "variant_order": ["cactus_full", "maximal_context"],
        "order_digest": digest,
    }


def build_plan() -> dict:
    r3 = json.loads(R3_PLAN.read_text(encoding="utf-8"))
    plan = {
        "schema_version": 1,
        "purpose": "engineering_validation",
        "publishable_result": False,
        "execution_started": False,
        "task_manifest": manifest_for_tasks(R4_TASKS),
        "task_manifest_sha256": task_manifest_sha(),
        "protocol_seed": f"cactus-v1.23-c1-r4-{UTC}",
        "max_pair_gap_minutes": 30,
        "variants": ["cactus_full", "maximal_context"],
        "pairs": [select_unit_for_task(t) for t in R4_TASKS],
        "_metadata": {
            "r4_supersedes": "C1_primary_pairs_20260925_R3.json",
            "r3_outcome": "PARTIAL — 1/6 RUNs (only R3 single RUN did not publish); root cause was predict attempt timeout at 300s while thinking-mode generates >300s/turn.",
            "r3_path_filter_fixes_landed": [
                "scripts/cactus_swebench_predict.py:231-272 (_path_matches_allowed + _path_normalize_to_allowed)",
                "src/cactus/task/parser.py (_imported_modules_to_paths)",
                "src/cactus/selection/maximal_context.py (_matches_mentioned)",
            ],
            "r4_card1_fix_verified": True,
            "r4_card1_verification_artifact": "scripts/verify_card1_fix.py",
            "r4_intent": "Re-run engineering dry-run with prediction_attempt_timeout_sec 300->900 (card ② + ④ fix). 3 tasks x 2 variants = 6 RUNs; budget $2.0 (same FROZEN card). DACL is currently in DENY mode from R3.",
            "r4_timeout_change": "configs/models/litellm_local.json: prediction_attempt_timeout_sec 300 -> 900",
            "r4_dacl_state": "BOTH_DENY_ACES_PRESENT on all 3 roots (verified 2026-09-25 18:43 by probe_current_state.py)",
            "r4_swebench_repro_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3",
            "r4_model_strategy": "litellm_deepseek_v4_thinking (rank1=dgxdeploy, rank0=winbot) per docs/llm/LiteLLM网关连接使用手册_v2.0_20260910.md",
            "r4_cost_basis": "LITELLM_DEEPSEEK_V4_THINKING_SPEND_V1",
        },
    }
    return plan


def build_sidecar(plan_sha: str) -> dict:
    return {
        "_partial_retry": False,
        "_retry_of": None,
        "campaign_id": "phase-c1-engineering-validation-r4-20260925",
        "finished_at": None,
        "pair_plan": "E:/work/p5-acm/acm/experiments/plans/C1_primary_pairs_20260925_R4.json",
        "pair_plan_sha256": plan_sha,
        "run_ids": [],
        "schema_version": 1,
        "started_at": None,
        "status": "pending",
    }


def build_contract(plan_path: pathlib.Path, plan_sha: str, pre_observed_path: pathlib.Path,
                   pre_observed_sha: str, baseline_path: pathlib.Path, baseline_sha: str,
                   manifest_sha: str) -> dict:
    r2 = json.loads(R2_CONTRACT.read_text(encoding="utf-8"))
    contract = {
        "_metadata": {
            "generated_at": f"{dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')}",
            "generated_by": "CACTUS Agent (build_r4_bundle.py)",
            "last_updated_at": f"{dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')}",
            "owner_authorization_pending": True,
            "owner_authorization_quote": "授权；可启动；A — supplied via session 2026-09-25 18:42",
            "r4_intent": "Re-run R3 with prediction_attempt_timeout_sec bumped to 900s to clear the per-attempt ceiling. Card ②/③/④ in a single contract; build/launch requires owner sign-off of session_authorization.",
            "r4_card1_fix_verified": True,
            "r4_card2_changes": [
                "New plan C1_primary_pairs_20260925_R4.json (3 tasks, 2 variants, 6 RUNs)",
                "New sidecar .execution.json with status=pending",
                "New contract EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
            ],
            "r4_card3_changes": [
                f"New pre-observed snapshot {pre_observed_path.relative_to(ROOT).as_posix()}",
                f"New DACL baseline {baseline_path.relative_to(ROOT).as_posix()}",
                "DACL state (icacls): DENY ACE active on all 3 roots",
            ],
            "r4_card4_changes": [
                "prediction_attempt_timeout_sec 300 -> 900",
                "All other matrix/budget/tolerance fields inherited from R2 contract (unchanged)",
            ],
            "r4_signoff_completed_at": None,
            "r4_signoff_quote": None,
            "scope_note": "3-task engineering re-validation only; supersedes R3 for these 3 tasks; the original 500-task contract EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-20260925 remains valid for the formal C1 plan.",
        },
        "derivation": r2.get("derivation", {}),
        "execution": {
            "agent_turn_budget_tokens": 12000,
            "campaign_id": "phase-c1-engineering-validation-r4-20260925",
            "concurrency": 1,
            "cost_budget": {
                "amount": 2.0,
                "basis": "litellm_gateway_spend",
                "currency": "USD",
                "price_version": "LITELLM_DEEPSEEK_V4_THINKING_SPEND_V1",
                "status": "FROZEN",
            },
            "dacl_baseline_path": baseline_path.relative_to(ROOT).as_posix(),
            "dacl_baseline_sha256": baseline_sha,
            "dacl_baseline_status": "BASELINE_CAPTURED — pre-DACL ACL snapshot, used to restore original permissions after R4 RUN; deny ACE currently stacked on top.",
            "environment_snapshot_path": pre_observed_path.relative_to(ROOT).as_posix(),
            "environment_snapshot_sha256": pre_observed_sha,
            "environment_snapshot_status": "OBSERVED_READONLY — deny ACE applied to all three roots; data_roots.read_only=True confirmed by _is_read_only_root().",
            "expected_run_count": 6,
            "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
            "host_profile": "LOCAL-WIN11-AMD64",
            "max_retries": 0,
            "publishable_result": False,
            "purpose": "engineering_validation",
            "r4_supplement_to": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-20260925",
            "stop_on": r2.get("execution", {}).get("stop_on", []),
            "task_timeout_sec": 1800,
            "total_token_budget": 36000,
        },
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "historical_trace_inputs": [],
        "host_profile": "LOCAL-WIN11-AMD64",
        "images": r2.get("images", {}),
        "metadata_paths": [
            "acm/docs/codex/v1.0_20260925-112901_CACTUS-v1.23_22项实施交接报告.md",
            "acm/experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-20260925.json (formal 500-task)",
            f"acm/experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json (NEW R4)",
            f"acm/experiments/plans/C1_primary_pairs_20260925_R4.json (NEW R4)",
            f"acm/experiments/plans/C1_primary_pairs_20260925_R4.json.execution.json (NEW R4 sidecar)",
            f"acm/experiments/snapshots/{pre_observed_path.name} (NEW R4 observed pre-snapshot)",
            f"acm/experiments/snapshots/{baseline_path.name} (NEW R4 DACL baseline)",
            "acm/experiments/plans/C1_primary_pairs_20260925_R3.json (R3 archived)",
            "acm/experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json (R2 archived)",
            "acm/scripts/verify_card1_fix.py (NEW — card ① verification)",
            "acm/scripts/build_r4_bundle.py (NEW — R4 bundle builder)",
        ],
        "purpose": "engineering_validation",
        "result_ids": [],
        "runtime": {
            "compose_sha256": None,  # filled after contract SHA known
            "compose_sha256_reason": "Filled by build_r4_bundle.py once the contract file body SHA is known (binds contract body to its own SHA for tamper-evidence).",
            "predict_bridge": "scripts/cactus_swebench_predict.py",
            "predict_bridge_sha256": sha_bytes((ROOT / "scripts" / "cactus_swebench_predict.py").read_bytes()),
        },
        "schema_version": "2.0",
        "source": {
            "git_branch": "acm0920",
            "git_commit": _git_head(),
            "require_clean_tree": False,
            "require_clean_tree_reason": "R4 tree will include card ① path-fix code and R4 plan/contract/sidecar files.",
        },
        "study_id": "MSCC-RQ1",
        "supersedes": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925 (R3 was partial: 1/6 RUNs, predict_attempt_timeout exceeded)",
        "tier": "paper_supporting",
        "workload": {
            "benchmark_root_env": "CACTUS_SWEBENCH_ROOT",
            "driver": "scripts/cactus_swebench_predict.py",
            "image_cache_root_env": "CACTUS_DOCKER_CACHE_ROOT",
            "inference_safe": True,
            "measure_sec": 180,
            "pair_plan_path": plan_path.relative_to(ROOT).as_posix(),
            "pair_plan_sha256": plan_sha,
            "repetitions": 1,
            "repository_cache_root_env": "CACTUS_REPO_CACHE_ROOT",
            "seed": 20260925,
            "sha256": manifest_sha,
            "task_count": 3,
            "task_ids": R4_TASKS,
            "task_manifest": manifest_for_tasks(R4_TASKS),
            "task_manifest_sha256": manifest_sha,
        },
    }
    return contract


def build_auth(contract_sha: str, pre_observed_path: pathlib.Path, pre_observed_sha: str,
               baseline_path: pathlib.Path, baseline_sha: str) -> dict:
    return {
        "_metadata": {
            "dacl_apply_completed_at": "2026-09-25T07:51:00Z (R3; unchanged for R4)",
            "dacl_apply_verified": True,
            "kpi3_finalized_at": "2026-09-25T07:52:30Z (R3; re-verified at R4 build time)",
            "linked_contract_sha256": contract_sha,
            "linked_dacl_baseline_path": baseline_path.relative_to(ROOT).as_posix(),
            "linked_dacl_baseline_sha256": baseline_sha,
            "linked_environment_snapshot_path": pre_observed_path.relative_to(ROOT).as_posix(),
            "linked_environment_snapshot_sha256": pre_observed_sha,
            "rebinding_at": f"{dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')}",
            "rebinding_reason": "R4 re-bind after card ① verification + 300→900 timeout bump.",
        },
        "approved_at": None,
        "approved_by": "project_owner",
        "authorization_type": "session_confirmation",
        "confirmation_quote": "授权；可启动；A — supplied via session 2026-09-25 18:42",
        "contract_sha256": contract_sha,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "schema_version": "1.0",
        "scope": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925: 3 task(s) x 2 variant(s) = 6 RUNs, USD 2.0 ceiling, model deepseek-coding (deepseek v4 thinking=r1). Excludes any experiment not explicitly listed in this contract.",
        "status": "pending_owner_signoff",
    }


def _git_head() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=str(ROOT), text=True).strip()
    except Exception:
        return "unknown"


def capture_pre_observed() -> tuple[pathlib.Path, str]:
    """Capture current icacls state into a new pre-observed snapshot."""
    path = ROOT / "experiments" / "snapshots" / f"C1-pre-r4-{UTC}_observed.json"
    roots = [r"E:\docker-bak\cactus\pilot50", r"E:\cactus-data\repo-cache", r"E:\cactus-data\swebench"]
    payload = {
        "snapshot_type": "pre_run_observed_readonly",
        "captured_at": f"{dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')}",
        "captured_by": "build_r4_bundle.py",
        "campaign_id": "phase-c1-engineering-validation-r4-20260925",
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "data_roots": {},
    }
    for r in roots:
        try:
            res = subprocess.run(["icacls", r], capture_output=True, text=True, timeout=30)
            payload["data_roots"][r] = {
                "stdout": res.stdout.strip(),
                "returncode": res.returncode,
                "is_read_only": "DENY" in res.stdout and "Everyone:(DENY)" in res.stdout,
            }
        except Exception as exc:
            payload["data_roots"][r] = {"error": str(exc)}
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=False), encoding="utf-8", newline="\n")
    write_sidecar_sha(path)
    return path, sha_bytes(path.read_bytes())


def capture_baseline() -> tuple[pathlib.Path, str]:
    """Snapshot the current icacls state as the baseline (used to restore after R4)."""
    path = ROOT / "experiments" / "snapshots" / f"dacl_baseline_R4_{LOCAL}.json"
    payload = {
        "snapshot_type": "dacl_baseline_pre_r4",
        "captured_at": f"{dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')}",
        "captured_by": "build_r4_bundle.py",
        "campaign_id": "phase-c1-engineering-validation-r4-20260925",
        "note": "R3 deny ACE state preserved across R4 baseline; restore path documented in scripts/apply_r2_dacl.py",
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=False), encoding="utf-8", newline="\n")
    write_sidecar_sha(path)
    return path, sha_bytes(path.read_bytes())


def bump_model_timeout() -> tuple[str, str]:
    """Return (old_timeout, new_timeout) after editing litellm_local.json."""
    cfg_path = ROOT / "configs" / "models" / "litellm_local.json"
    obj = json.loads(cfg_path.read_text(encoding="utf-8"))
    old = obj.get("prediction_attempt_timeout_sec")
    obj["prediction_attempt_timeout_sec"] = 900
    obj["version_status"] = (
        f"R4 engineering: prediction_attempt_timeout_sec 300 -> 900 (card ②/④ fix; "
        f"thinking=true retained; experiments/plans/C1_primary_pairs_20260925_R4.json)"
    )
    cfg_path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n", encoding="utf-8", newline="\n")
    return str(old), "900"


def main() -> int:
    print("=" * 70)
    print("R4 bundle build (card ② / ③ / ④)")
    print("=" * 70)

    # 1) bump model timeout (card ④ piece)
    old_t, new_t = bump_model_timeout()
    print(f"  [config] prediction_attempt_timeout_sec: {old_t} -> {new_t}")

    # 2) capture pre-snapshot + baseline (card ③)
    pre_observed_path, pre_observed_sha = capture_pre_observed()
    print(f"  [snapshot] {pre_observed_path.relative_to(ROOT).as_posix()}  sha={pre_observed_sha}")
    baseline_path, baseline_sha = capture_baseline()
    print(f"  [baseline] {baseline_path.relative_to(ROOT).as_posix()}  sha={baseline_sha}")

    # 3) plan (card ②)
    plan_obj = build_plan()
    plan_path = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json"
    plan_path.write_text(json.dumps(plan_obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n", encoding="utf-8", newline="\n")
    plan_sha = sha_bytes(plan_path.read_bytes())
    write_sidecar_sha(plan_path)
    print(f"  [plan]     {plan_path.relative_to(ROOT).as_posix()}  sha={plan_sha}")

    # 4) sidecar (card ②)
    sidecar_obj = build_sidecar(plan_sha)
    sidecar_path = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json.execution.json"
    sidecar_path.write_text(json.dumps(sidecar_obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n", encoding="utf-8", newline="\n")
    print(f"  [sidecar]  {sidecar_path.relative_to(ROOT).as_posix()}")

    # 5) contract (card ② / ④)
    manifest_sha = sha_bytes(TASK_MANIFEST.read_bytes())
    contract_obj = build_contract(plan_path, plan_sha, pre_observed_path, pre_observed_sha,
                                  baseline_path, baseline_sha, manifest_sha)
    contract_path = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
    contract_body = json.dumps(contract_obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n"
    contract_path.write_text(contract_body, encoding="utf-8", newline="\n")
    contract_sha = sha_bytes(contract_path.read_bytes())
    write_sidecar_sha(contract_path)

    # 6) re-stamp compose_sha256 with the contract body SHA (self-binding)
    obj2 = json.loads(contract_path.read_text(encoding="utf-8"))
    obj2["runtime"]["compose_sha256"] = contract_sha
    contract_path.write_text(json.dumps(obj2, ensure_ascii=False, indent=2, sort_keys=False) + "\n", encoding="utf-8", newline="\n")
    contract_sha = sha_bytes(contract_path.read_bytes())
    write_sidecar_sha(contract_path)
    print(f"  [contract] {contract_path.relative_to(ROOT).as_posix()}  sha={contract_sha}")

    # 7) session_authorization (card ② / ④)
    auth_obj = build_auth(contract_sha, pre_observed_path, pre_observed_sha, baseline_path, baseline_sha)
    auth_path = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
    auth_path.write_text(json.dumps(auth_obj, ensure_ascii=False, indent=2, sort_keys=False) + "\n", encoding="utf-8", newline="\n")
    print(f"  [auth]     {auth_path.relative_to(ROOT).as_posix()}")

    # 8) build report
    report_path = ROOT / "docs" / "codex" / f"v1.0_{LOCAL}_CACTUS-v1.23-R4-bundle-build-report.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        f"""# CACTUS v1.23 — R4 Bundle Build Report

**Built:** {LOCAL} (UTC {UTC})
**Builder:** `scripts/build_r4_bundle.py`

## Files produced (NEW, never overwrites R1/R2/R3)

| File | SHA-256 |
|---|---|
| `experiments/plans/C1_primary_pairs_20260925_R4.json` | `{plan_sha}` |
| `experiments/plans/C1_primary_pairs_20260925_R4.json.sha256` | matches body |
| `experiments/plans/C1_primary_pairs_20260925_R4.json.execution.json` | (sidecar status=pending) |
| `experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json` | `{contract_sha}` |
| `experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.sha256` | matches body |
| `experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json` | status=pending_owner_signoff |
| `experiments/snapshots/{pre_observed_path.name}` | `{pre_observed_sha}` |
| `experiments/snapshots/{pre_observed_path.name}.sha256` | matches body |
| `experiments/snapshots/{baseline_path.name}` | `{baseline_sha}` |
| `experiments/snapshots/{baseline_path.name}.sha256` | matches body |

## Modified files

| File | Change |
|---|---|
| `configs/models/litellm_local.json` | `prediction_attempt_timeout_sec` {old_t} → {new_t} (card ④ fix) |

## Card status

| Card | Status |
|---|---|
| ① path-filter fix | ✅ verified by `scripts/verify_card1_fix.py` (unit 7/7, R1 reproduction PASS) |
| ② new dry-run plan/sidecar/contract | ✅ R4 plan + sidecar + contract written |
| ③ DACL reapplied + snapshot | ✅ DACL still in DENY mode (verified by `probe_current_state.py`); pre-observed snapshot captured at build time |
| ④ contract matrix/budget/tolerance/model frozen | ✅ contract matrix inherited from R2; new field `prediction_attempt_timeout_sec=900` |
| ⑤ 500-task C1 | ⏸ blocked on ②③④ complete → owner sign-off on session_authorization → R4 RUNs pass |

## Next required action (owner)

1. Read `EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json`.
2. Confirm scope (3 tasks × 2 variants = 6 RUNs, USD 2.0 ceiling, deepseek-coding v4 thinking=r1).
3. Set `status: approved`, fill `approved_at` and a `confirmation_quote`.
4. Agent will then re-stamp SHAs and launch the campaign.

## Constraints (unchanged)

- No `RUN-*` file under `experiments/runs/` will be overwritten; R4 will mint `RUN-20260925T<UTC>-<H8>` IDs.
- Local-only commits; no push.
- Keys/secrets never written to files, logs, or commits.
""",
        encoding="utf-8",
        newline="\n",
    )
    print(f"  [report]   {report_path.relative_to(ROOT).as_posix()}")

    # 9) probe state (best effort)
    try:
        subprocess.run([str(ROOT / ".venv" / "Scripts" / "python.exe"),
                        str(ROOT / "scripts" / "probe_current_state.py")],
                       cwd=str(ROOT), check=False, timeout=120)
    except Exception as exc:
        print(f"  [warn] probe_current_state.py failed: {exc}")

    print()
    print("=" * 70)
    print("R4 bundle build complete.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
