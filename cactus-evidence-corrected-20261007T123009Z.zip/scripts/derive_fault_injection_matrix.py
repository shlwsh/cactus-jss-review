"""Derive detection matrix and performance metrics from P0-5 fault injection results.

Outputs:
  experiments/derived/detection_matrix.json
Validates acceptance gates:
  H2: detection recall >= 90% per fault type
  H3: false positive rate <= 5%
  H4: overhead quantified
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics


RAW_RESULTS_PATH = Path("experiments/derived/fault_injection_raw_results.json")
OUTPUT_MATRIX_PATH = Path("experiments/derived/detection_matrix.json")


def analyze_results(raw_data: dict) -> dict:
    results = raw_data["results"]
    controls = [r for r in results if r["category"] == "control"]
    faults = [r for r in results if r["category"] == "fault_injection"]

    # 1. Control bundle performance (False Positive Rate)
    # A false positive is a control bundle that is incorrectly rejected (actual_admitted == False)
    fp_count = sum(1 for r in controls if not r["actual_admitted"])
    control_count = len(controls)
    fpr = fp_count / max(1, control_count)

    # 2. Fault detection performance by fault type
    by_fault = defaultdict(list)
    for r in faults:
        by_fault[r["fault_type"]].append(r)

    matrix = {}
    total_detected = 0
    total_faults = len(faults)

    for f_name, items in sorted(by_fault.items()):
        n_items = len(items)
        detected = sum(1 for r in items if r["detected_by_gate"])
        total_detected += detected
        recall = detected / max(1, n_items)

        # Stages
        stages = defaultdict(int)
        for r in items:
            stages[r["detection_stage"]] += 1

        # Representative reasons
        reasons_counter = defaultdict(int)
        for r in items:
            for reason in r["reasons"]:
                reasons_counter[reason] += 1

        durations = [r["elapsed_sec"] for r in items]
        matrix[f_name] = {
            "instances": n_items,
            "detected": detected,
            "recall": recall,
            "recall_percent": f"{recall * 100:.1f}%",
            "stages": dict(stages),
            "top_reasons": sorted(reasons_counter.items(), key=lambda x: x[1], reverse=True)[:3],
            "mean_elapsed_sec": statistics.mean(durations),
            "median_elapsed_sec": statistics.median(durations),
        }

    overall_recall = total_detected / max(1, total_faults)

    # 3. Overhead quantification
    all_durations = [r["elapsed_sec"] for r in results]
    control_durations = [r["elapsed_sec"] for r in controls]
    fault_durations = [r["elapsed_sec"] for r in faults]

    overhead = {
        "total_test_cases": len(results),
        "total_elapsed_sec": sum(all_durations),
        "mean_check_time_ms": statistics.mean(all_durations) * 1000,
        "median_check_time_ms": statistics.median(all_durations) * 1000,
        "control_mean_check_time_ms": statistics.mean(control_durations) * 1000,
        "fault_mean_check_time_ms": statistics.mean(fault_durations) * 1000,
    }

    # 4. Gate verification
    h2_recall_pass = all(m["recall"] >= 0.90 for m in matrix.values())
    h3_fpr_pass = fpr <= 0.05
    verdict = "PASS" if (h2_recall_pass and h3_fpr_pass) else "FAIL"

    derived = {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "experiment_id": "EXP-CACTUS-FAULT-INJECTION-20261006T100000Z",
        "verdict": verdict,
        "gates": {
            "H2_detection_recall_ge_90pct": {
                "threshold": 0.90,
                "overall_recall": overall_recall,
                "per_fault_all_pass": h2_recall_pass,
                "status": "PASS" if h2_recall_pass else "FAIL",
            },
            "H3_false_positive_rate_le_5pct": {
                "threshold": 0.05,
                "control_instances": control_count,
                "false_positives": fp_count,
                "false_positive_rate": fpr,
                "status": "PASS" if h3_fpr_pass else "FAIL",
            },
            "H4_overhead_quantified": {
                "status": "PASS",
                "metrics": overhead,
            },
        },
        "overall_summary": {
            "total_test_cases": len(results),
            "control_instances": control_count,
            "fault_instances": total_faults,
            "overall_recall": overall_recall,
            "false_positive_rate": fpr,
        },
        "detection_matrix": matrix,
    }

    return derived


def main() -> None:
    if not RAW_RESULTS_PATH.exists():
        raise FileNotFoundError(f"Missing raw results: {RAW_RESULTS_PATH}")
    raw_data = json.loads(RAW_RESULTS_PATH.read_text(encoding="utf-8"))
    derived = analyze_results(raw_data)

    OUTPUT_MATRIX_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_MATRIX_PATH.write_text(json.dumps(derived, indent=2, sort_keys=True), encoding="utf-8")

    print(f"=== Detection Matrix Analysis ===")
    print(f"  Overall Verdict: {derived['verdict']}")
    print(f"  Overall Recall:  {derived['overall_summary']['overall_recall']*100:.1f}%")
    print(f"  False Positives: {derived['overall_summary']['false_positive_rate']*100:.1f}%")
    print(f"  Mean check time: {derived['gates']['H4_overhead_quantified']['metrics']['mean_check_time_ms']:.2f} ms")
    print("\nPer-Fault Recall:")
    for f_name, m in derived["detection_matrix"].items():
        print(f"  {f_name:<30}: {m['recall_percent']} ({m['detected']}/{m['instances']}) [stages: {m['stages']}]")


if __name__ == "__main__":
    main()
