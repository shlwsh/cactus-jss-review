"""Analyze what the model's patch actually does for astropy__astropy-13033."""
from pathlib import Path
import tempfile
import subprocess
import sys

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest = list(load_manifest(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"))
task = next(t for t in manifest if t.task_id == "astropy__astropy-13033")
ws = Path(tempfile.mkdtemp(prefix="cactus-test-analyze-"))
repo = checkout_base_commit(task, cache_root=Path(r"E:\cactus-data\repo-cache"), workspace_root=ws, allow_network_fetch=True)

# Apply the model's patch using a file (avoid quoting issues)
patch_path = ws / "model.patch"
patch_path.write_text(
    "diff --git a/astropy/timeseries/core.py b/astropy/timeseries/core.py\n"
    "--- a/astropy/timeseries/core.py\n"
    "+++ b/astropy/timeseries/core.py\n"
    "@@ -74,7 +74,7 @@\n"
    "                                  \"as the first column{} but time series has no columns\"\n"
    "                                  .format(self.__class__.__name__, required_columns[0], plural))\n"
    " \n"
    "-            elif self.colnames[:len(required_columns)] != required_columns:\n"
    "+            elif len(self.colnames) < len(required_columns) or self.colnames[:len(required_columns)] != required_columns:\n"
    " \n"
    "                 raise ValueError(\"{}\"\n",
    encoding="utf-8",
)

result = subprocess.run(
    ["git", "-C", str(repo), "apply", "--whitespace=nowarn", str(patch_path)],
    capture_output=True, text=True,
)
print(f"git apply: rc={result.returncode} stderr={result.stderr.strip()}")

# Read patched core.py
core = (repo / "astropy" / "timeseries" / "core.py").read_text(encoding="utf-8")
# Find the patched lines
lines = core.splitlines()
print("=== Patched _check_required_columns (lines 58-86) ===")
for i, line in enumerate(lines[57:86], 58):
    print(f"  {i:3d}: {line}")

# Show test_required_columns test (with the new test_patch)
print("\n=== Test test_required_columns (lines 352-405) ===")
test_lines = (repo / "astropy" / "timeseries" / "tests" / "test_sampled.py").read_text(encoding="utf-8").splitlines()
for i, line in enumerate(test_lines[351:410], 352):
    print(f"  {i:3d}: {line}")

# Now apply the test_patch (gold's test_patch, which adds the new test case for 13009)
test_patch_path = ws / "test.patch"
test_patch_path.write_text(
    "diff --git a/astropy/timeseries/tests/test_sampled.py b/astropy/timeseries/tests/test_sampled.py\n"
    "--- a/astropy/timeseries/tests/test_sampled.py\n"
    "+++ b/astropy/timeseries/tests/test_sampled.py\n"
    "@@ -395,6 +395,14 @@ def test_required_columns():\n"
    "     assert exc.value.args[0] == (\"TimeSeries object is invalid - expected \"\n"
    "                                  \"'time' as the first column but found 'banana'\")\n"
    " \n"
    "+    # https://github.com/astropy/astropy/issues/13009\n"
    "+    ts_2cols_required = ts.copy()\n"
    "+    ts_2cols_required._required_columns = ['time', 'a']\n"
    "+    with pytest.raises(ValueError) as exc:\n"
    "+        ts_2cols_required.remove_column('a')\n"
    "+    assert exc.value.args[0] == (\"TimeSeries object is invalid - expected \"\n"
    "+                                 \"['time', 'a'] as the first columns but found ['time', 'b']\")\n"
    "+\n"
    " \n"
    " @pytest.mark.parametrize('cls', [BoxLeastSquares, LombScargle])\n"
    " def test_periodogram(cls):\n",
    encoding="utf-8",
)

result = subprocess.run(
    ["git", "-C", str(repo), "apply", "--whitespace=nowarn", str(test_patch_path)],
    capture_output=True, text=True,
)
print(f"\ntest_patch apply: rc={result.returncode} stderr={result.stderr.strip()}")

# Run the test
print("\n=== pytest test_required_columns ===")
result = subprocess.run(
    [str(ROOT / ".venv" / "Scripts" / "python.exe"), "-m", "pytest",
     "astropy/timeseries/tests/test_sampled.py::test_required_columns",
     "-xvs", "--tb=short", "--no-header", "-q"],
    cwd=str(repo),
    capture_output=True, text=True,
    timeout=120,
)
print("--- stdout ---")
print(result.stdout[:4000])
print("--- stderr ---")
print(result.stderr[:2000])