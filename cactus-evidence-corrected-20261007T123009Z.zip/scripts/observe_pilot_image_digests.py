"""Record immutable local Docker digests for the Phase C Pilot contract.

This is an observation helper only.  It never edits the authorized contract,
downloads images, or creates an approval marker.  The resulting artifact is a
review input for replacing the historical short local-image IDs with complete
manifest digests in a separately reviewed contract revision.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _local_repo_digests(repository: str, tag: str = "") -> tuple[list[str], str | None]:
    inspect_refs = [repository]
    # SWE-bench may leave pulled images untagged.  The frozen contract keeps
    # the local image ID prefix in ``tag``; Docker can inspect the full ID.
    if tag.startswith("sha256-"):
        inspect_refs.append("sha256:" + tag.removeprefix("sha256-"))

    result = None
    for inspect_ref in inspect_refs:
        candidate = subprocess.run(
            ["docker", "image", "inspect", inspect_ref],
            capture_output=True,
            text=True,
            check=False,
        )
        if candidate.returncode == 0:
            result = candidate
            break
        result = candidate
    assert result is not None
    if result.returncode:
        detail = (result.stderr or result.stdout).strip().splitlines()
        return [], detail[-1] if detail else "docker image inspect failed"
    try:
        images = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        return [], f"invalid docker inspect JSON: {exc}"
    if not isinstance(images, list):
        return [], "docker inspect returned a non-list payload"

    digests: set[str] = set()
    for image in images:
        if not isinstance(image, dict):
            continue
        for repo_digest in image.get("RepoDigests", []):
            if isinstance(repo_digest, str) and "@" in repo_digest:
                digest = repo_digest.rsplit("@", 1)[1]
                if _IMAGE_DIGEST.fullmatch(digest):
                    digests.add(digest)
    return sorted(digests), None


def build_observation(contract_path: Path) -> dict[str, Any]:
    contract_bytes = contract_path.read_bytes()
    contract = json.loads(contract_bytes.decode("utf-8"))
    images = contract.get("images") if isinstance(contract, dict) else None
    if not isinstance(images, dict) or not images:
        raise ValueError("contract images catalog is missing or empty")

    observed_images: dict[str, dict[str, Any]] = {}
    all_candidates_available = True
    all_contract_digests_match = True
    for name, image in sorted(images.items()):
        if not isinstance(image, dict):
            observed_images[str(name)] = {"status": "INVALID_CONTRACT_IMAGE"}
            all_candidates_available = False
            all_contract_digests_match = False
            continue
        repository = str(image.get("repository", ""))
        expected = image.get("digest", "")
        local_digests, error = _local_repo_digests(repository, str(image.get("tag", "")))
        candidate = local_digests[0] if len(local_digests) == 1 else None
        exact_match = isinstance(expected, str) and _IMAGE_DIGEST.fullmatch(expected) and expected in local_digests
        all_candidates_available = all_candidates_available and candidate is not None
        all_contract_digests_match = all_contract_digests_match and exact_match
        observed_images[str(name)] = {
            "repository": repository,
            "contract_digest": expected,
            "contract_digest_complete": bool(isinstance(expected, str) and _IMAGE_DIGEST.fullmatch(expected)),
            "local_repo_digests": local_digests,
            "candidate_digest": candidate,
            "exact_match": exact_match,
            "status": "MATCH" if exact_match else ("CANDIDATE_AVAILABLE" if candidate else "MISSING_OR_UNINSPECTABLE"),
            **({"inspect_error": error} if error else {}),
        }

    if all_contract_digests_match:
        status = "CONTRACT_IMAGES_OK"
    elif all_candidates_available:
        status = "READY_FOR_CONTRACT_REVIEW"
    else:
        status = "BLOCKED_MISSING_IMAGE_DIGEST"

    return {
        "schema_version": "1.0",
        "observed_at": _utc_now(),
        "status": status,
        "source_contract": str(contract_path).replace("\\", "/"),
        "source_contract_sha256": hashlib.sha256(contract_bytes).hexdigest(),
        "authorized_contract_unchanged": True,
        "approval_marker_created": False,
        "execution_performed": False,
        "images": observed_images,
        "next_action": (
            "Review and authorize a new contract revision using candidate_digest values; "
            "do not reuse the existing approval marker after changing contract content."
            if status == "READY_FOR_CONTRACT_REVIEW"
            else "No contract change or formal execution is authorized by this observation."
        ),
    }


def build_contract_candidate(contract_path: Path, observation: dict[str, Any]) -> dict[str, Any]:
    """Build an unapproved contract candidate from a digest observation."""

    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    candidate = copy.deepcopy(contract)
    for name, observed in observation["images"].items():
        digest = observed.get("candidate_digest")
        if digest and isinstance(candidate.get("images", {}).get(name), dict):
            image = candidate["images"][name]
            image["digest"] = digest
            image["status"] = "LOCAL_REPO_DIGEST_OBSERVED_PENDING_REVIEW"
            image["note"] = "Complete manifest digest observed locally; candidate only, not authorized."
    metadata = candidate.setdefault("_metadata", {})
    metadata["candidate_status"] = "pending_owner_review"
    metadata["candidate_generated_at"] = observation["observed_at"]
    metadata["candidate_source_contract_sha256"] = observation["source_contract_sha256"]
    metadata["candidate_note"] = (
        "Image digests were materialized from local Docker RepoDigests after an immutable pull. "
        "This file does not replace the authorized contract and requires a fresh session confirmation."
    )
    return candidate


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--contract",
        type=Path,
        default=Path("experiments/contracts/EXP-CACTUS-PILOT-V2.json"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/pilot_image_digest_observation.json"),
    )
    parser.add_argument(
        "--candidate-contract",
        type=Path,
        help="also write an unapproved contract candidate with observed complete digests",
    )
    args = parser.parse_args()
    observation = build_observation(args.contract)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(observation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    if args.candidate_contract:
        candidate = build_contract_candidate(args.contract, observation)
        args.candidate_contract.parent.mkdir(parents=True, exist_ok=True)
        args.candidate_contract.write_text(json.dumps(candidate, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(observation, ensure_ascii=False, indent=2))
    return 0 if observation["status"] in {"CONTRACT_IMAGES_OK", "READY_FOR_CONTRACT_REVIEW"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
