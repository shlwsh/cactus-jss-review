"""launch_r4_all_think.py — Launch all 3 R4 tasks with think config."""

from __future__ import annotations

import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

from inject_session_keys import REQUIRED_KEYS, load_resolved  # noqa: E402

CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
APPROVAL = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
PLAN = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json"
MODEL_CONFIG = ROOT / "configs" / "models" / "litellm_local_think.json"
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
OUTPUT_ROOT = ROOT / "experiments" / "runs"
REPO_CACHE = ROOT / "experiments" / "repo_cache"
DATASET = Path(r"E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
CAMPAIGN_ID = "phase-c1-r4-think-v2-20260925"

RUNNER = ROOT / "scripts" / "run_swebench_campaign.py"
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"

TASKS = ["astropy__astropy-12907", "astropy__astropy-13033", "astropy__astropy-13236"]


def main() -> int:
    env_path, resolved = load_resolved()
    env = {**os.environ, **{k: resolved[k]["value"] for k in REQUIRED_KEYS}}
    for required in (CONTRACT, APPROVAL, PLAN, MODEL_CONFIG, TASK_MANIFEST, RUNNER, DATASET):
        if not required.exists():
            print(f"ERROR: required path missing: {required}", file=sys.stderr)
            return 2

    log_path = OUTPUT_ROOT / f"_r4_all_think_{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    cfg = json.loads(MODEL_CONFIG.read_text(encoding="utf-8"))
    print("=" * 70)
    print("R4 THINK-MODE: ALL 3 TASKS (cactus_full variant only, max 1 attempt each)")
    print("=" * 70)
    print(f"contract    : {CONTRACT.name}")
    print(f"plan        : {PLAN.name}")
    print(f"model_cfg   : {MODEL_CONFIG.name}")
    print(f"  thinking          = {cfg.get('thinking')}")
    print(f"  max_output_tokens = {cfg.get('max_output_tokens')}")
    print(f"  reasoning_effort  = {cfg.get('reasoning_effort')}")
    print(f"  max_attempts      = {cfg.get('prediction_max_attempts')}")
    print(f"  retry_max_chars   = {cfg.get('prediction_retry_context_max_chars')}")
    print(f"campaign    : {CAMPAIGN_ID}")
    print(f"tasks       : {TASKS}")
    print(f"log         : {log_path}")
    print("=" * 70)

    # Use --limit 1 and run each task separately to avoid the cost_budget_unverified issue
    results = {}
    with log_path.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"# R4 all-think launches\n# started: {dt.datetime.now(dt.timezone.utc).isoformat()}\n")
        fh.flush()
        for task_id in TASKS:
            print(f"\n>>> TASK: {task_id}")
            cmd = [
                str(PYTHON),
                "-m", "scripts.run_swebench_campaign",
                "--contract", str(CONTRACT),
                "--approval", str(APPROVAL),
                "--model-config", str(MODEL_CONFIG),
                "--tasks", str(TASK_MANIFEST),
                "--output-root", str(OUTPUT_ROOT),
                "--repo-cache", str(REPO_CACHE),
                "--evaluator-dataset", str(DATASET),
                "--project-root", str(ROOT),
                "--pair-plan", str(PLAN),
                "--campaign-id", f"{CAMPAIGN_ID}-{task_id}",
                "--task-id", task_id,
                "--limit", "1",
            ]
            print("$ " + " ".join(cmd))
            fh.write(f"\n# TASK {task_id}\n# cmd: " + " ".join(cmd) + "\n")
            fh.flush()
            proc = subprocess.Popen(
                cmd, cwd=str(ROOT.parent), env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1,
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                sys.stdout.write(line)
                sys.stdout.flush()
                fh.write(line)
                fh.flush()
            rc = proc.wait()
            print(f">>> {task_id} finished with exit={rc}")
            results[task_id] = rc
            fh.write(f"\n# {task_id} finished exit={rc}\n")
            fh.flush()

    print()
    print("=" * 70)
    print("R4 all-think summary:")
    for t, rc in results.items():
        print(f"  {t}: exit={rc}")
    print(f"log: {log_path}")
    print("=" * 70)
    return 0 if all(rc == 0 for rc in results.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
