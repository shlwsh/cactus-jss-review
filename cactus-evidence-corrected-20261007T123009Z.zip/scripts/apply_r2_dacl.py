"""Apply deny mutation ACE to the three CACTUS data roots (OWNER STEP).

This script is intended to be run by the project owner after the Agent has
captured the baseline ACL snapshot. It:

1. Adds a deny ACE (Modify/Write/Append/Delete) to each of the three roots
   via icacls /deny, which makes _dataset_resolver._is_read_only_root return
   True and unlocks resolve_data_roots(require_all=True).
2. Verifies the deny ACE is present after the change.

Deny ACE is applied to:
    BUILTIN\\Users  (read-only) and
    Everyone        (no mutation)

The original ACL is preserved by stacking the deny ACE on top; icacls does
not delete existing allow ACEs. Removal can be done with:
    icacls <path> /remove:g <sid>

USAGE (PowerShell, elevated):
    python scripts\\apply_r2_dacl.py --apply
    python scripts\\apply_r2_dacl.py --verify
    python scripts\\apply_r2_dacl.py --rollback     # remove deny ACE

After --apply or --rollback, the Agent should re-run:
    python scripts\\capture_r2_pre.py --dacl-status observed_with_readonly_true

NOTE: This script MUST be invoked by the owner. The Agent cannot run icacls
in the current sandbox because it requires Administrator privileges.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT_PATHS = [
    "E:\\docker-bak\\cactus\\pilot50",
    "E:\\cactus-data\\repo-cache",
    "E:\\cactus-data\\swebench",
]

# Deny mutations: Modify, Write, Append, Delete
# (WD=Modify, AD=AppendData, WEA=WriteExtendedAttributes, WA=WriteAttributes,
#  DE=Delete) — matches _dataset_resolver._WINDOWS_MUTATING_RIGHTS.
DENY_RIGHTS = "(WD,AD,WEA,WA,DE)"

# Apply deny ACE to Users (covers interactive sessions) and Everyone
# (covers any future subprocess). Built-in Administrator keeps Allow (need it
# for owner operations post-run).
DENY_IDENTITIES = [
    "BUILTIN\\Users",
    "Everyone",
]


def _icacls(args: list[str]) -> tuple[int, str]:
    icacls = shutil.which("icacls.exe") or shutil.which("icacls")
    if not icacls:
        return 1, "icacls not on PATH"
    try:
        result = subprocess.run(
            [icacls] + args,
            check=False,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 1, f"icacls failed: {exc}"
    return result.returncode, (result.stdout + result.stderr).strip()


def apply() -> int:
    rc = 0
    for root in ROOT_PATHS:
        for identity in DENY_IDENTITIES:
            args = [root, "/deny", identity + ":" + DENY_RIGHTS]
            print(f"  icacls {' '.join(args)}")
            code, out = _icacls(args)
            if code != 0:
                print(f"  FAIL code={code}: {out}")
                rc = code
            else:
                print(f"  OK {identity} deny ACE added to {root}")
    return rc


def verify() -> int:
    print("Verifying deny ACE on each root...")
    rc = 0
    for root in ROOT_PATHS:
        code, out = _icacls([root])
        deny_found = False
        for line in out.splitlines():
            if "(DENY)" in line.upper() and any(
                right in line.upper()
                for right in ("WD", "AD", "WEA", "WA", "DE")
            ):
                if any(ident in line for ident in DENY_IDENTITIES):
                    deny_found = True
                    print(f"  PASS {root}: {line.strip()}")
        if not deny_found:
            print(f"  FAIL {root}: no deny ACE for {DENY_IDENTITIES}")
            print(out)
            rc = 1
    return rc


def rollback() -> int:
    rc = 0
    for root in ROOT_PATHS:
        for identity in DENY_IDENTITIES:
            args = [root, "/remove:g", identity]
            print(f"  icacls {' '.join(args)}")
            code, out = _icacls(args)
            if code != 0:
                print(f"  FAIL code={code}: {out}")
                rc = code
            else:
                print(f"  OK {identity} removed from {root}")
    return rc


def main() -> int:
    parser = argparse.ArgumentParser(prog="apply_r2_dacl")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--apply", action="store_true", help="apply deny ACE to all three roots")
    group.add_argument("--verify", action="store_true", help="verify deny ACE exists")
    group.add_argument("--rollback", action="store_true", help="remove deny ACE")
    args = parser.parse_args()

    if args.apply:
        return apply()
    if args.verify:
        return verify()
    if args.rollback:
        return rollback()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())