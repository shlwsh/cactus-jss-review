"""Generate the 13398 gold patch from web content."""
import json
import re
from pathlib import Path

# This is the raw diff content fetched from GitHub
# Will be loaded from cache file
cache_file = Path("E:/work/p5-acm/acm/scripts/_13398_raw_diff.txt")

if not cache_file.exists():
    print(f"Cache file {cache_file} not found")
else:
    content = cache_file.read_text(encoding='utf-8')
    # Parse the diff content
    # The web fetch output starts with metadata and ends with the diff
    # Find the start of "diff --git"
    diff_start = content.find('diff --git a/astropy/coordinates/builtin_frames/__init__.py')
    if diff_start > 0:
        diff_content = content[diff_start:].rstrip()
        print(f"Diff length: {len(diff_content)}")
        # Save the diff to a file
        output = Path("E:/work/p5-acm/acm/experiments/runs/_13398_gold_patch.diff")
        output.write_text(diff_content + "\n", encoding='utf-8')
        print(f"Saved to {output}")
        print(f"First 300 chars: {diff_content[:300]}")
    else:
        print("Could not find diff start")
