"""Dump unique event types + first non-empty data."""
import json, sys
from pathlib import Path

name = sys.argv[1] if len(sys.argv) > 1 else 'django__django-11910'
base = Path(f'experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/{name}/events.jsonl')
if not base.exists():
    print(f'not found: {base}'); sys.exit(1)

types = {}
nonempty = {}
for line in base.read_text(encoding='utf-8', errors='ignore').splitlines():
    try:
        e = json.loads(line)
    except Exception:
        continue
    et = e.get('type', '?')
    types[et] = types.get(et, 0) + 1
    d = e.get('data', {})
    if isinstance(d, dict) and d and et not in nonempty:
        nonempty[et] = json.dumps(d, ensure_ascii=False)[:500]

print(f'total events: {sum(types.values())}')
print(f'unique types ({len(types)}):')
for t, c in sorted(types.items(), key=lambda x: -x[1]):
    print(f'  {c:>4}  {t}')
print('\nfirst non-empty data per type:')
for t, d in nonempty.items():
    print(f'  --- {t} ---')
    print(f'    {d}')