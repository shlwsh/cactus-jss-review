"""Show all model responses."""
import json
import sys
from pathlib import Path

run = Path(sys.argv[1])
events = [json.loads(l) for l in (run / "trace" / "events.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]

print(f"=== {len([e for e in events if e['type'] == 'model_call'])} model_call events ===\n")
for i, e in enumerate(events):
    if e["type"] == "model_call":
        p = e["payload"]
        print(f"--- [{i}] turn={p.get('turn_id')} ---")
        print(f"  in={p.get('input_tokens')} out={p.get('output_tokens')} finish={p.get('finish_reason')}")
        resp = p.get("response_text", "")
        print(f"  FULL RESPONSE ({len(resp)} chars):")
        print(resp)
        print()

print(f"\n=== {len([e for e in events if e['type'] == 'prediction_rejected'])} rejections ===\n")
for e in events:
    if e["type"] == "prediction_rejected":
        p = e["payload"]
        print(f"--- reason_class={p.get('reason_class')} attempt={p.get('attempt')} ---")
        print(f"  reason: {p.get('reason')}")
        print(f"  response: {p.get('response_excerpt')}")
        print()
