"""Freeze an inference-safe, deterministic 50-task SWE-bench Lite subset.

The evaluator parquet remains outside the repository because it contains gold
patches.  This command reads it locally, verifies the fixed Lite-300 universe,
and writes only the fields needed by CACTUS inference and the official harness.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import pyarrow.parquet as pq


LITE_TEST_COUNT = 300
SUBSET_COUNT = 50
FORBIDDEN_FIELDS = frozenset({"patch", "test_patch", "gold_patch", "ground_truth_patch"})
REQUIRED_SOURCE_FIELDS = frozenset({
    "base_commit", "image", "instance_id", "repo", "version", "problem_statement", "FAIL_TO_PASS",
})
OUTPUT_FIELDS = (
    "base_commit", "image", "instance_id", "repo", "version", "problem_statement", "FAIL_TO_PASS",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _require_string(row: dict[str, Any], name: str) -> str:
    value = row.get(name)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Lite row {row.get('instance_id', '<unknown>')!r} has no non-empty {name}")
    return value


def _require_string_list(row: dict[str, Any], name: str) -> list[str]:
    value = row.get(name)
    if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
        raise ValueError(f"Lite row {row.get('instance_id', '<unknown>')!r} has invalid {name}")
    return list(value)


def read_lite_rows(parquet: Path) -> list[dict[str, Any]]:
    # Read a projected, inference-safe column set.  In particular, never
    # materialize evaluator scripts: those can embed the held-out test patch.
    table = pq.read_table(parquet, columns=sorted(REQUIRED_SOURCE_FIELDS))
    rows = table.to_pylist()
    if len(rows) != LITE_TEST_COUNT:
        raise ValueError(f"SWE-bench Lite test source must have exactly {LITE_TEST_COUNT} rows, got {len(rows)}")
    seen: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Lite parquet contains a non-object row")
        missing = REQUIRED_SOURCE_FIELDS - row.keys()
        if missing:
            raise ValueError("Lite parquet misses required fields: " + ", ".join(sorted(missing)))
        task_id = _require_string(row, "instance_id")
        if task_id in seen:
            raise ValueError(f"duplicate Lite instance_id: {task_id}")
        seen.add(task_id)
        for name in ("base_commit", "image", "repo", "version", "problem_statement"):
            _require_string(row, name)
        _require_string_list(row, "FAIL_TO_PASS")
    return rows


def inference_safe_row(row: dict[str, Any]) -> dict[str, Any]:
    leaked = FORBIDDEN_FIELDS & row.keys()
    if leaked:
        # The source is expected to contain gold fields; this function is the
        # only transformation boundary and intentionally never copies them.
        pass
    result = {name: row[name] for name in OUTPUT_FIELDS}
    result.update({
        "task_id": result["instance_id"],
        "repo_id": result["repo"],
        "issue_text": result["problem_statement"],
        "test_command": ["swebench", "eval", "lite", "-i", result["instance_id"]],
        "split": "test",
        "benchmark": "SWE-bench_Lite",
    })
    disallowed = FORBIDDEN_FIELDS | {"eval_script", "PASS_TO_PASS", "log_parser", "eval_type"}
    if disallowed & result.keys():
        raise AssertionError("inference-safe transformation retained a forbidden evaluator field")
    return dict(sorted(result.items()))


def build(parquet: Path, output: Path, *, expected_source_sha256: str | None = None) -> dict[str, Any]:
    if output.exists():
        raise FileExistsError(f"refusing to overwrite frozen manifest: {output}")
    source_sha256 = sha256(parquet)
    if expected_source_sha256 is not None and source_sha256 != expected_source_sha256:
        raise ValueError(f"Lite source SHA-256 mismatch: expected {expected_source_sha256}, got {source_sha256}")
    rows = read_lite_rows(parquet)
    selected = sorted(rows, key=lambda item: str(item["instance_id"]))[:SUBSET_COUNT]
    safe_rows = [inference_safe_row(row) for row in selected]
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in safe_rows), encoding="utf-8", newline="\n")
    digest = sha256(output)
    output.with_suffix(output.suffix + ".sha256").write_text(f"{digest}  {output.name}\n", encoding="utf-8", newline="\n")
    return {"source_sha256": source_sha256, "manifest_sha256": digest, "task_count": len(safe_rows), "task_ids": [row["task_id"] for row in safe_rows]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lite-parquet", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-source-sha256")
    args = parser.parse_args()
    print(json.dumps(build(args.lite_parquet, args.output, expected_source_sha256=args.expected_source_sha256), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
