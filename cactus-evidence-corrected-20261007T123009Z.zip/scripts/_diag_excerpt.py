"""Extract response_text from model_call events for all failed tasks."""
import json
from pathlib import Path
BASE = Path("experiments/runs/FACO-FULL-LITE50-RESUME-20261003T203555Z")
FAILED = [
    "astropy__astropy-12907",
    "django__django-10924", "django__django-11019", "django__django-11179",
    "django__django-11564", "django__django-11797", "django__django-11910",
    "django__django-12125", "django__django-12284", "django__django-12470",
    "django__django-12708", "django__django-13028", "django__django-13158",
]
for tid in FAILED:
    p = BASE / tid / "events.jsonl"
    with p.open("r", encoding="utf-8") as f:
        events = [json.loads(line) for line in f]
    print(f"\n========= {tid} =========")
    # find model_call events with response_text and SITES in prompt (site selection phase)
    for ev in events:
        if ev.get("type") == "model_call":
            payload = ev.get("payload", {})
            prompt = payload.get("prompt_text", "")
            response = payload.get("response_text", "")
            output_tokens = payload.get("output_tokens", "?")
            max_tokens = payload.get("max_tokens", "?")
            # only show site selection phase
            if "SITES:" in prompt or "site group" in prompt.lower():
                print(f"\n  [seq {ev.get('seq')} ot={output_tokens}/{max_tokens}]")
                # check if response starts with SITES:
                resp_short = response[:300] if response else "(empty)"
                print(f"  RESP: {resp_short!r}")
