"""Reproduce the no-op patch case end-to-end with the real base-commit core.py.

We:
1. Materialize the base commit (298ccb47) for astropy__astropy-13033 via
   cactus.runner.swebench_campaign.checkout_base_commit
2. Run _statement_edit_to_patch with the failing model response
3. Print every step's output
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

# Materialize the base commit
TASKS_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
tasks = {t.task_id: t for t in load_manifest(TASKS_MANIFEST)}
task = tasks["astropy__astropy-13033"]
print(f"task_id={task.task_id} base_commit={task.base_commit}")

workspace_root = Path(tempfile.mkdtemp(prefix="cactus-diag-"))
print(f"workspace_root={workspace_root}")

try:
    repo_path = checkout_base_commit(
        task,
        cache_root=REPO_CACHE,
        workspace_root=workspace_root,
        allow_network_fetch=True,
    )
    print(f"repo_path={repo_path}")
    print(f"HEAD={(repo_path / '.git/HEAD').read_text().strip()}")
except Exception as exc:
    print(f"checkout_base_commit failed: {exc}")
    sys.exit(1)

core_path = repo_path / "astropy" / "timeseries" / "core.py"
print(f"core.py exists={core_path.exists()}  size={core_path.stat().st_size if core_path.exists() else 'N/A'}")
src = core_path.read_text(encoding="utf-8")
print()

print("=== core.py lines 55-95 ===")
for i, line in enumerate(src.splitlines()[54:95], 56):
    print(f"  {i:3d}: {line}")
print()

from cactus_swebench_predict import (
    _try_parse_with_quote_recovery,
    _statement_edit_to_patch,
    _wrap_for_canonicalize,
)
import ast

# Print canonical form of the source-side matched statement
tree = ast.parse(src)
for cls in ast.walk(tree):
    if isinstance(cls, ast.ClassDef) and cls.name == "BaseTimeSeries":
        for child in cls.body:
            if isinstance(child, ast.FunctionDef) and child.name == "_check_required_columns":
                for sub in ast.iter_child_nodes(child):
                    if isinstance(sub, ast.Raise):
                        seg = ast.get_source_segment(src, sub)
                        wrapped = _wrap_for_canonicalize(seg)
                        wrapped_tree = ast.parse(wrapped)
                        canon = ast.unparse(wrapped_tree.body[0].body[0])
                        print(f"raise @ line {sub.lineno}")
                        print(f"  source: {seg!r}")
                        print(f"  canonical: {canon!r}")
                        print()

# The model response that produced the no-op patch (reconstructed from trace)
MODEL_RESPONSE = (
    '{"edits":[{"path":"astropy/timeseries/core.py","symbol":'
    '"BaseTimeSeries._check_required_columns","old_statement":'
    '"raise ValueError(\'{} object is invalid - expected \'{}\' as the first column{} but found \'{}\''
    "'.format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))\","
    '"replacement":'
    '"raise ValueError(\'{} object is invalid - expected \'{}\' as the first column{} but found \'{}\''
    "'.format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))\"}]}"
)

print("=== Run _statement_edit_to_patch ===")
try:
    patch = _statement_edit_to_patch(MODEL_RESPONSE, repo_path)
    print(f"PATCH GENERATED! Length={len(patch)}")
    print("--- patch ---")
    print(patch)
    print("--- end ---")
except ValueError as exc:
    msg = str(exc)
    print(f"REJECTED.")
    # Show only first 500 chars
    print(f"  reason (first 500 chars): {msg[:500]}")