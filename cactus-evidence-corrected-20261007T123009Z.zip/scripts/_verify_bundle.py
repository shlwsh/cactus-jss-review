"""Verify git bundle and check base commits."""
import shutil
import subprocess
from pathlib import Path

bundle = Path("E:/work/p5-acm/acm/tmp/docker_bundles/mount/repo.bundle")
clone_dir = Path("E:/work/p5-acm/acm/tmp/clone_test")

# Clean up existing clone dir
if clone_dir.exists():
    shutil.rmtree(clone_dir)
clone_dir.mkdir(parents=True, exist_ok=True)

print(f"Bundle size: {bundle.stat().st_size // 1024 // 1024} MB")

# Clone from bundle
r = subprocess.run(
    ["git", "clone", "--bare", str(bundle), str(clone_dir)],
    capture_output=True, text=True, timeout=120,
)
print(f"Clone exit: {r.returncode}")
if r.returncode != 0:
    print(f"STDERR: {r.stderr[:300]}")
    # Try verify with bundle directly
    r3 = subprocess.run(
        ["git", "bundle", "list-heads", str(bundle)],
        capture_output=True, text=True, timeout=30,
    )
    print(f"Bundle heads: {r3.stdout[:200]}")

# Verify commits
for commit in [
    "d16bfe05a744909de4b27f5875fe0d4ed41ce607",  # 12907
    "298ccb478e6bf092953bca67a3d29dc6c35f6752",  # 13033
    "6ed769d58d89380ebaa1ef52b300691eefda8928",  # 13236
]:
    if clone_dir.exists():
        r2 = subprocess.run(
            ["git", "-C", str(clone_dir), "cat-file", "-t", f"{commit}" + "{commit}"],
            capture_output=True, text=True, timeout=10,
        )
    else:
        r2 = subprocess.run(
            ["git", "cat-file", "-t", f"{commit}" + "{commit}"],
            cwd=str(bundle.parent),
            capture_output=True, text=True, timeout=10,
        )
    status = "OK" if r2.returncode == 0 else "MISSING"
    print(f"  {commit[:12]}: {status}")
