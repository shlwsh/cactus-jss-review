"""Capture corrected primary metadata and prepare BibTeX for selected suggestions."""
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import urllib.request
from verify_cited_papers import Metadata, sha

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'paper/data/scholar' / ('selected_references_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir(exist_ok=False)
SELECTED = [
    ('ralph2020standards', 'arxiv', '2010.03525'),
    ('petersen2015mapping', 'doi', '10.1016/j.infsof.2015.03.007'),
    ('hou2024llmse', 'doi', '10.1145/3695988'),
    ('smith2015overfitting', 'doi', '10.1145/2786805.2786825'),
    ('kim2013par', 'doi', '10.1109/ICSE.2013.6606626'),
    ('zheng2023code', 'arxiv', '2311.10372'),
    ('yang2023contamination', 'arxiv', '2311.04850'),
    ('jia2011mutation', 'doi', '10.1109/TSE.2010.62'),
    ('alur2013sygus', 'doi', '10.1109/FMCAD.2013.6679385'),
]

records = []; bibs = []
for key, kind, identifier in SELECTED:
    url = ('https://arxiv.org/abs/' if kind == 'arxiv' else 'https://api.crossref.org/works/') + identifier
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'CACTUS-citation-verification/1.0'}), timeout=40) as response:
                data = response.read(); final_url = response.url
            break
        except Exception:
            if attempt == 2: raise
            time.sleep(3 * (attempt+1))
    path = OUT / (key + ('.html' if kind == 'arxiv' else '.json'))
    path.write_bytes(data)
    if kind == 'arxiv':
        meta = Metadata(); meta.feed(data.decode('utf-8'))
        values = meta.values
        fields = {'author': ' and '.join(values['citation_author']), 'title': values['citation_title'][0],
                  'year': values['citation_date'][0][:4], 'howpublished': 'arXiv preprint arXiv:' + identifier,
                  'url': url, 'doi': '10.48550/arXiv.' + identifier}
        entry_type = 'misc'
    else:
        m = json.loads(data)['message']
        fields = {'author': ' and '.join(a['family'] + ', ' + a.get('given', '') for a in m['author']),
                  'title': m['title'][0], 'year': str(m.get('published-print', m['published'])['date-parts'][0][0]),
                  'doi': m['DOI']}
        article = m['type'] == 'journal-article'
        fields['journal' if article else 'booktitle'] = m['container-title'][0]
        for field in ('volume', 'issue', 'page'):
            if m.get(field): fields[{'issue': 'number', 'page': 'pages'}.get(field, field)] = m[field]
        entry_type = 'article' if article else 'inproceedings'
    bibs.append('@'+entry_type+'{'+key+',\n'+'\n'.join('  '+f+' = {'+v+'},' for f,v in fields.items())+'\n}\n')
    records.append({'key': key, 'url': url, 'final_url': final_url, 'retrieved_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
                    'file_path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path), 'metadata': fields})
    print(key, fields['title'], fields['year'], flush=True)
    time.sleep(1)
(OUT / 'selected.bib').write_text('\n'.join(bibs), encoding='utf-8', newline='\n')
(OUT / 'index.json').write_text(json.dumps({'records': records}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(OUT.relative_to(ROOT).as_posix())
