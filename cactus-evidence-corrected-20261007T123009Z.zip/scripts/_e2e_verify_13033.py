"""End-to-end verification of R4 elif-fix for astropy__astropy-13033.

1. Check out astropy at base commit 298ccb478e6bf092953bca67a3d29dc6c35f6752
2. Run the cactus_swebench_predict.py subprocess (statement_edit mode) for task 13033
3. Verify the resulting patch via git apply --check
4. Compare with the gold patch direction
"""

from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

REPO_CACHE = ROOT / "experiments" / "repo_cache"
SAFE_NAME = "astropy__astropy"
BASE_COMMIT = "298ccb478e6bf092953bca67a3d29dc6c35f6752"
TASK_ID = "astropy__astropy-13033"

mirror = REPO_CACHE / f"{SAFE_NAME}.git"
workspace = Path(tempfile.mkdtemp(prefix="r4_e2e_"))
checkout = workspace / "repository"

print(f"=== R4 E2E Verification: {TASK_ID} ===")
print(f"workspace: {checkout}")

print("\n[1] Cloning base commit...")
subprocess.run(
    ["git", "clone", "--no-checkout", str(mirror), str(checkout)],
    cwd=str(workspace), check=True, capture_output=True,
)
subprocess.run(
    ["git", "-C", str(checkout), "checkout", "--detach", BASE_COMMIT],
    cwd=str(workspace), check=True, capture_output=True,
)
print(f"   HEAD: {subprocess.run(['git', '-C', str(checkout), 'rev-parse', 'HEAD'], capture_output=True, text=True).stdout.strip()}")

# Resolve API key (avoid PowerShell override of 'test') — read real key from .env
import re
ENV_FILE = ROOT / "docs" / "llm" / ".env"
_env_text = ENV_FILE.read_text(encoding="utf-8")
_match = re.search(r"^CACTUS_LITELLM_API_KEY=(.*)$", _env_text, re.MULTILINE)
api_key = _match.group(1).strip().strip('"').strip("'") if _match else ""
if len(api_key) < 16:
    raise SystemExit(f"env API key looks invalid (len={len(api_key)}); aborting")

print("\n[2] Running predict subprocess...")
predict_log = workspace / "predict.stderr.log"
cmd = [
    str(ROOT / ".venv" / "Scripts" / "python.exe"),
    str(ROOT / "scripts" / "cactus_swebench_predict.py"),
    "--tasks", str(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"),
    "--task-id", TASK_ID,
    "--repo-root", str(checkout),
    "--model-config", str(ROOT / "configs" / "models" / "litellm_local_nothink_v7.json"),
    "--output", str(workspace / "prediction.jsonl"),
    "--budget", "12000",
    "--request-timeout-sec", "900",
    "--variant", "cactus_full",
    "--trace", str(workspace / "trace.jsonl"),
]
env = {**os.environ, "PYTHONPATH": "scripts;.", "CACTUS_LITELLM_API_KEY": api_key}
proc = subprocess.run(
    cmd, cwd=str(ROOT), env=env,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    text=True, timeout=900,
)
print(f"   exit={proc.returncode}")
stderr = proc.stderr
# Save full stderr/stdout for later inspection
(workspace / "predict.stderr.log").write_text(stderr, encoding="utf-8")
(workspace / "predict.stdout.log").write_text(proc.stdout, encoding="utf-8")
print(f"   stderr last 800 chars:\n{stderr[-800:]}")

print("\n[3] Reading prediction...")
pred_path = workspace / "prediction.jsonl"
if not pred_path.is_file():
    print("FAIL: prediction.jsonl not produced")
    sys.exit(1)

with pred_path.open(encoding="utf-8") as fh:
    prediction = json.loads(fh.readline())
print(f"   patch length: {len(prediction['model_patch'])} chars")
print(f"   model_patch head: {prediction['model_patch'][:300]}...")

print("\n[3.5] All model response heads from stderr log...")
predict_log = workspace / "predict.stderr.log"
if predict_log.is_file():
    import re
    text = predict_log.read_text(encoding="utf-8", errors="replace")
    matches = re.findall(r'"resp_chars":(\d+),"resp_head":"((?:[^"\\]|\\.)*)"', text)
    for i, (chars, head) in enumerate(matches):
        unesc = head.replace('\\n', '\n').replace('\\"', '"')
        print(f"   attempt {i+1}: {chars} chars")
        print(f"     head: {unesc[:380]}")

print("\n[4] git apply --check ...")
check = subprocess.run(
    ["git", "apply", "--check", "--whitespace=nowarn"],
    cwd=str(checkout), input=prediction["model_patch"].encode("utf-8"),
    capture_output=True,
)
print(f"   exit code: {check.returncode}")
if check.returncode != 0:
    print(f"   stderr: {check.stderr.decode('utf-8')}")
    sys.exit(1)

print("\n[5] Stderr diagnostics from predict:")
if predict_log.is_file():
    diag = predict_log.read_text(encoding="utf-8")
    for line in diag.splitlines():
        if "statement_edit" in line or "elif" in line.lower():
            print(f"   {line}")

print("\n[6] Computing model vs gold direction...")
print(f"   model patched lines:")
patch_lines = prediction["model_patch"].splitlines()
for line in patch_lines:
    if line.startswith("+") and not line.startswith("+++"):
        print(f"     + {line[1:]}")
    elif line.startswith("-") and not line.startswith("---"):
        print(f"     - {line[1:]}")

print("\n=== ALL CHECKS PASSED ===")
print(f"prediction SHA256: {hashlib.sha256(prediction['model_patch'].encode('utf-8')).hexdigest()}")
