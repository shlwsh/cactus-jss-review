"""
Step 2: Build a real-time monitor for CACTUS R4 model interactions.

Monitors a running RUN directory; on each model_call / prediction_rejected
event, computes a quick verdict:
- empty_response: model returned 0 chars (likely API error or token-limit)
- length_limit: finish_reason=length (model didn't finish)
- placeholder_replacement: replacement looks like placeholder (.placeholder, ...)
- symbol_hallucination: symbol contains non-ASCII or fake-looking chars
- old_statement_mismatch: AST didn't find old_statement
- hallucinated_old: old_statement has obvious typos vs source (e.g. righth_shape)

Emits a per-RUN verdict file `_r4_monitor_verdict.json`.
Designed to be cheap (single read per call) so it can be invoked from a
launcher or post-hoc as a forensic tool.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List


HALLUCINATION_TOKENS = [
    ".placeholder",
    "placeholder",
    "TODO",
    "FIXME",
    "...replace...",
    "<REPLACE>",
]


def safe_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def parse_edits(response_text: str) -> List[Dict[str, str]]:
    try:
        obj = json.loads(response_text)
        return list(obj.get("edits") or [])
    except Exception:
        return []


def classify_attempt(mc: Dict[str, Any], rj: Dict[str, Any] | None) -> Dict[str, Any]:
    """Return verdict for one model_call + reject pair."""
    p = mc.get("payload", {})
    response_text = safe_text(p.get("response_text", ""))
    prompt_text = safe_text(p.get("prompt_text", ""))
    finish_reason = p.get("finish_reason")
    out_tokens = p.get("output_tokens") or 0
    edits = parse_edits(response_text)
    verdict: Dict[str, Any] = {
        "finish_reason": finish_reason,
        "output_tokens": out_tokens,
        "response_chars": len(response_text),
        "n_edits": len(edits),
        "verdict_tags": [],
        "verdict_actions": [],
        "verdict_severity": "ok",
        "edits_summary": [],
        "reject_reason": (rj or {}).get("reason"),
        "reject_reason_class": (rj or {}).get("reason_class"),
    }

    # 1. Empty response
    if len(response_text.strip()) == 0:
        verdict["verdict_tags"].append("empty_response")
        verdict["verdict_severity"] = "fail"
        verdict["verdict_actions"].append("retry_with_higher_max_tokens_or_thinking=true")

    # 2. Length-limit hit
    if finish_reason == "length":
        verdict["verdict_tags"].append("length_limit")
        verdict["verdict_severity"] = "fail"
        verdict["verdict_actions"].append("increase_max_output_tokens_or_enable_thinking")

    # 3. JSON parse failure (no edits parsed + non-empty text)
    if len(response_text.strip()) > 0 and not edits:
        verdict["verdict_tags"].append("json_parse_failure")
        verdict["verdict_severity"] = "fail"
        verdict["verdict_actions"].append("verify_guided_decoding_schema_and_temperature")

    for ed in edits:
        ed_summary: Dict[str, Any] = {
            "path": ed.get("path"),
            "symbol": ed.get("symbol"),
            "old_statement_head": safe_text(ed.get("old_statement"))[:100],
            "replacement_head": safe_text(ed.get("replacement"))[:100],
            "tags": [],
        }
        replacement = safe_text(ed.get("replacement"))
        old = safe_text(ed.get("old_statement"))
        symbol = safe_text(ed.get("symbol"))

        # Placeholder check
        for tok in HALLUCINATION_TOKENS:
            if tok in replacement:
                ed_summary["tags"].append(f"placeholder_replacement:{tok!r}")
                break
        # Symbol hallucination (non-ASCII, weird chars)
        if symbol and (not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", symbol)):
            ed_summary["tags"].append("symbol_hallucination")
        # Obvious typos vs known code (e.g. righth_shape -> right.shape)
        if "righth_shape" in old:
            ed_summary["tags"].append("typo:righth_shape_vs_right.shape")
        if old.strip() == replacement.strip():
            ed_summary["tags"].append("no_op_edit")

        verdict["edits_summary"].append(ed_summary)
        if any("placeholder" in t for t in ed_summary["tags"]):
            verdict["verdict_tags"].append("placeholder_replacement")
            verdict["verdict_severity"] = "fail"
        if "symbol_hallucination" in ed_summary["tags"]:
            verdict["verdict_tags"].append("symbol_hallucination")
            verdict["verdict_severity"] = "fail"
        if "no_op_edit" in ed_summary["tags"]:
            verdict["verdict_tags"].append("no_op_edit")
            verdict["verdict_severity"] = "warn"

    # 4. Patch validation rejection without empty JSON (most common)
    rc = (rj or {}).get("reason_class")
    if rc == "patch_validation_rejected":
        if verdict["verdict_severity"] == "ok":
            verdict["verdict_severity"] = "warn"
        verdict["verdict_tags"].append("patch_validation_rejected")
        verdict["verdict_actions"].append(
            "inspect_old_statement_vs_source: use diff/grep to compare with file content"
        )

    return verdict


def monitor_run(run_dir: Path) -> Dict[str, Any]:
    trace = run_dir / "trace" / "events.jsonl"
    if not trace.exists():
        return {"run_id": run_dir.name, "verdict": "no_trace", "attempts": []}
    events = [
        json.loads(line)
        for line in trace.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    mcalls = [e for e in events if e.get("type") == "model_call"]
    rejects = [e for e in events if e.get("type") == "prediction_rejected"]
    attempts = []
    for idx, mc in enumerate(mcalls):
        rj = rejects[idx]["payload"] if idx < len(rejects) else {}
        attempts.append(classify_attempt(mc, rj))
    # Aggregate verdict
    severities = [a["verdict_severity"] for a in attempts]
    if any(s == "fail" for s in severities):
        agg = "fail"
    elif any(s == "warn" for s in severities):
        agg = "warn"
    else:
        agg = "ok"
    return {
        "run_id": run_dir.name,
        "trace_path": str(trace.relative_to(run_dir.parent.parent)),
        "n_attempts": len(attempts),
        "aggregate_severity": agg,
        "attempts": attempts,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True, help="RUN-* directory under experiments/runs")
    parser.add_argument(
        "--output",
        default=None,
        help="Output JSON path; default: <run-dir>/_r4_monitor_verdict.json",
    )
    args = parser.parse_args()
    run_dir = Path(args.run_dir).resolve()
    out_path = Path(args.output) if args.output else run_dir / "_r4_monitor_verdict.json"
    verdict = monitor_run(run_dir)
    out_path.write_text(json.dumps(verdict, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"run_id": verdict["run_id"], "aggregate_severity": verdict["aggregate_severity"], "n_attempts": verdict["n_attempts"]}, ensure_ascii=False))
    print(f"verdict saved to: {out_path}")
    sys.exit(0 if verdict["aggregate_severity"] in ("ok", "warn") else 2)


if __name__ == "__main__":
    main()
