"""Diagnose the no-op patch case from R4-13033 first-round trace.

The model produced old_statement == replacement (literal textually equal
multi-line raise block collapsed to single line). Trace shows:
- _statement_edit_to_patch ran the multi-line normalized branch
- semantic no-op guard failed to trigger
- patch was generated, evaluation returned resolved=False
"""
from __future__ import annotations

import json
import sys
import textwrap
import ast
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

# The model response, reconstructed from the trace events.jsonl
# (the actual raw text is one long escaped line — we keep it as one Python str).
MODEL_RESPONSE = (
    '{"edits":[{"path":"astropy/timeseries/core.py","symbol":'
    '"BaseTimeSeries._check_required_columns","old_statement":'
    '"raise ValueError(\'{} object is invalid - expected \'{}\' as the first column{} but found \'{}\''
    "'.format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))\","
    '"replacement":'
    '"raise ValueError(\'{} object is invalid - expected \'{}\' as the first column{} but found \'{}\''
    "'.format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))\"}]}"
)

print("=== Model response (raw) ===")
print(MODEL_RESPONSE)
print()

# Parse the JSON
value = json.loads(MODEL_RESPONSE)
edit = value["edits"][0]
old_statement = edit["old_statement"]
replacement = edit["replacement"]
print("=== old_statement ===")
print(old_statement)
print()
print("=== replacement ===")
print(replacement)
print()

# Now apply quote recovery to the replacement (which has the broken ' pattern)
from cactus_swebench_predict import (
    _try_parse_with_quote_recovery,
    _wrap_for_canonicalize,
    _statement_edit_to_patch,
)

repl_tree, repl_src = _try_parse_with_quote_recovery(replacement + "\n")
print("=== replacement parse via _try_parse_with_quote_recovery ===")
print("parsed?", repl_tree is not None)
if repl_tree is not None:
    canon_repl = ast.unparse(repl_tree.body[0])
    print("canonical AST:", canon_repl)
print()

# Same for the source side — use the actual base-commit core.py
# from the repo cache for end-to-end test
import subprocess
repo_path = ROOT / "experiments" / "repo_cache" / "astropy__astropy.git"
ref_check = subprocess.run(
    ["git", "rev-parse", "HEAD"], cwd=str(repo_path), capture_output=True, text=True, timeout=30
)
print("Repo cache HEAD:", ref_check.stdout.strip())
# 991a1090... is the base commit used by the Docker image
# However, the SWE-bench harness uses 78f471b... — let's check what _run_r4_v3 used
# (it uses checkout_base_commit which checks out the actual base for that task)
print()

# Try to find the core.py the predict script would have used
ws_dir = Path("E:/cactus-data/repo-cache/_workspaces")
if ws_dir.exists():
    for ws in sorted(ws_dir.iterdir()):
        core = ws / "astropy" / "timeseries" / "core.py"
        if core.exists():
            print("Found workspace:", ws, "size=", core.stat().st_size)

# Try the actual E:\cactus-data\tmp workspace
tmp_dir = Path("E:/cactus-data/tmp")
print()
print("tmp_dir exists?", tmp_dir.exists())
if tmp_dir.exists():
    for d in sorted(tmp_dir.iterdir())[:3]:
        print("  tmp item:", d.name, "is_dir=", d.is_dir())

# Hardcode the source text — same as what's in 298ccb47 base commit
SOURCE_TEXT = textwrap.dedent('''\
    def _check_required_columns(self):

        if not self._required_columns_enabled:
            return

        if self._required_columns is not None:

            if self._required_columns_relax:
                required_columns = self._required_columns[:len(self.colnames)]
            else:
                required_columns = self._required_columns

            plural = 's' if len(required_columns) > 1 else ''

            if not self._required_columns_relax and len(self.colnames) == 0:

                raise ValueError("{} object is invalid - expected '{}' "
                                 "as the first column{} but time series has no columns"
                                 .format(self.__class__.__name__, required_columns[0], plural))

            elif self.colnames[:len(required_columns)] != required_columns:

                raise ValueError("{} object is invalid - expected '{}' "
                                 "as the first column{} but found '{}'"
                                 .format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))

            if (self._required_columns_relax
                    and self._required_columns == self.colnames[:len(self._required_columns)]):
                self._required_columns_relax = False
''')

print()
print("=== Run _statement_edit_to_patch on this no-op response ===")
try:
    patch = _statement_edit_to_patch(MODEL_RESPONSE, Path("/tmp"))  # dummy path; will fail path check
    print("PATCH GENERATED (length):", len(patch))
except ValueError as exc:
    print("REJECTED:", exc)