"""P0-5 Fault Injection Validation Suite for CACTUS Evidence Admission Gate.

Evaluates the Admission Gate and Bundle Validator against 10 fault mutation types:
  F01: source hash mutation (commit mismatch)
  F02: driver hash mutation (workload sha256 mismatch)
  F03: missing evaluator report
  F04: invalid prediction (corrupted JSON)
  F05: empty patch with success claim
  F06: evaluator / raw disagreement
  F07: billing / provider usage mismatch
  F08: task ID mutation
  F09: manifest tampering (checksum mismatch)
  F10: bundle tampering (file content tampered without checksum update)

Includes 20 control bundles (unmutated, known admitted). Total: 220 test cases.
Measures detection recall, false positive rate, detection stage, and overhead.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import time
import sys
from typing import Any

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from cactus.governance.canonical import canonical_json
from cactus.runner.bundle_validator import validate_bundle



CONTRACTS_DIR = ROOT_DIR / "experiments" / "contracts"
WORK_DIR = ROOT_DIR / "experiments" / "fault_injection" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
ADMITTED_RECORDS_PATH = ROOT_DIR / "paper" / "data" / "admitted_retry_records.json"


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def update_checksums_file(bundle_dir: Path) -> None:
    """Regenerate checksums.sha256 for a bundle."""
    lines = []
    for f in sorted(bundle_dir.rglob("*")):
        if f.is_file() and f.name != "checksums.sha256":
            rel = f.relative_to(bundle_dir).as_posix()
            lines.append(f"{sha256_file(f)}  {rel}")
    (bundle_dir / "checksums.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def evaluate_admission(bundle_dir, contract_path, contract):
    """Compatibility entry point; rules live in the production core."""
    from cactus.governance.admission import evaluate_admission as admission, read_json
    authorization = read_json(contract_path.with_name(contract_path.stem + ".session_authorization.json"))
    return admission(ROOT_DIR, bundle_dir, contract, authorization=authorization)


# Mutation operators (F01 - F10)
def mutate_F01_source_hash(target_dir: Path) -> None:
    """F01: mutate source commit hash in run_manifest.json."""
    m_path = target_dir / "run_manifest.json"
    m = json.loads(m_path.read_text(encoding="utf-8"))
    m["code"]["commit"] = "0000000000000000000000000000000000000000"
    m_path.write_text(json.dumps(m, indent=2), encoding="utf-8")
    update_checksums_file(target_dir)


def mutate_F02_driver_hash(target_dir: Path) -> None:
    """F02: mutate driver script sha256 in contract.json."""
    c_path = target_dir / "contract.json"
    c = json.loads(c_path.read_text(encoding="utf-8"))
    c["workload"]["sha256"] = "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
    c_path.write_text(json.dumps(c, indent=2), encoding="utf-8")
    update_checksums_file(target_dir)


def mutate_F03_missing_evaluator(target_dir: Path) -> None:
    """F03: delete evaluator report JSON."""
    for f in (target_dir / "evaluation").glob("*.json"):
        f.unlink()
    update_checksums_file(target_dir)


def mutate_F04_invalid_prediction(target_dir: Path) -> None:
    """F04: corrupt prediction.jsonl with malformed non-JSON text."""
    p_path = target_dir / "raw" / "prediction.jsonl"
    p_path.write_text("<<<CORRUPT NON-JSON PREDICTION SYNTAX ERROR>>>\n", encoding="utf-8")
    update_checksums_file(target_dir)


def mutate_F05_empty_patch(target_dir: Path) -> None:
    """F05: set empty patch diff while runner reports success."""
    p_path = target_dir / "raw" / "prediction.jsonl"
    p_lines = [json.loads(l) for l in p_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    for p in p_lines:
        p["model_patch"] = ""
    p_path.write_text("\n".join(json.dumps(p) for p in p_lines) + "\n", encoding="utf-8")
    update_checksums_file(target_dir)


def mutate_F06_eval_raw_disagreement(target_dir: Path) -> None:
    """F06: flip resolved status to create contradiction between evaluator report and raw result."""
    reports = list((target_dir / "evaluation").glob("*.json"))
    r_path = target_dir / "raw" / "result.json"
    r = json.loads(r_path.read_text(encoding="utf-8"))
    currently_resolved = bool(r.get("data", {}).get("resolved", False))
    # Invert raw result resolved status
    r["data"]["resolved"] = not currently_resolved
    r_path.write_text(json.dumps(r, indent=2), encoding="utf-8")
    update_checksums_file(target_dir)


def mutate_F07_billing_mismatch(target_dir: Path) -> None:
    """F07: billing record token count does not match provider usage (>20%)."""
    b_path = target_dir / "billing" / "litellm_spend.json"
    if b_path.exists():
        b = json.loads(b_path.read_text(encoding="utf-8"))
        recon = b.get("provider_usage_reconciliation", {})
        recon["status"] = "mismatch"
        recon["provider_tokens"] = 1000
        recon["billing_tokens"] = 50000
        b["status"] = "unreconciled"
        b_path.write_text(json.dumps(b, indent=2), encoding="utf-8")
        update_checksums_file(target_dir)


def mutate_F08_task_id_mutation(target_dir: Path) -> None:
    """F08: mutate task_id in raw/result.json."""
    r_path = target_dir / "raw" / "result.json"
    r = json.loads(r_path.read_text(encoding="utf-8"))
    r["data"]["task_id"] = "mutated_repo__mutated_task-99999"
    r_path.write_text(json.dumps(r, indent=2), encoding="utf-8")
    update_checksums_file(target_dir)


def mutate_F09_manifest_tampering(target_dir: Path) -> None:
    """F09: tamper with configuration hash in run_manifest.json without updating checksums."""
    m_path = target_dir / "run_manifest.json"
    m = json.loads(m_path.read_text(encoding="utf-8"))
    m["configuration"]["sha256"] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    m_path.write_text(json.dumps(m, indent=2), encoding="utf-8")
    # Intentionally do NOT update checksums.sha256


def mutate_F10_bundle_tampering(target_dir: Path) -> None:
    """F10: modify bundle file without updating checksums.sha256."""
    p_path = target_dir / "raw" / "prediction.jsonl"
    p_path.write_text(p_path.read_text(encoding="utf-8") + "\n# TAMPERED BY FAULT INJECTION\n", encoding="utf-8")
    # Intentionally do NOT update checksums.sha256


MUTATION_OPERATORS = {
    "F01_source_hash_mutation": mutate_F01_source_hash,
    "F02_driver_hash_mutation": mutate_F02_driver_hash,
    "F03_missing_evaluator_report": mutate_F03_missing_evaluator,
    "F04_invalid_prediction": mutate_F04_invalid_prediction,
    "F05_empty_patch": mutate_F05_empty_patch,
    "F06_evaluator_raw_disagreement": mutate_F06_eval_raw_disagreement,
    "F07_billing_mismatch": mutate_F07_billing_mismatch,
    "F08_task_id_mutation": mutate_F08_task_id_mutation,
    "F09_manifest_tampering": mutate_F09_manifest_tampering,
    "F10_bundle_tampering": mutate_F10_bundle_tampering,
}


def load_seed_bundles(count: int = 20) -> list[tuple[Path, Path, dict[str, Any]]]:
    """Load known admitted RUN bundles from admitted_retry_records.json.

    Returns: list of (run_dir, contract_path, contract_data)
    """
    if not ADMITTED_RECORDS_PATH.exists():
        raise FileNotFoundError(f"Admitted records file not found: {ADMITTED_RECORDS_PATH}")
    records = json.loads(ADMITTED_RECORDS_PATH.read_text(encoding="utf-8"))

    seeds = []
    seen = set()
    for rec in records:
        prov = rec.get("provenance", {})
        run_id = prov.get("run_id")
        exp_id = prov.get("experiment_id")
        if not run_id or not exp_id or run_id in seen:
            continue
        run_dir = ROOT_DIR / "experiments" / "runs" / run_id
        contract_path = CONTRACTS_DIR / f"{exp_id}.json"
        if not run_dir.exists() or not contract_path.exists():
            continue
        contract_data = json.loads(contract_path.read_text(encoding="utf-8"))
        # Verify baseline admissibility
        baseline_check = evaluate_admission(run_dir, contract_path, contract_data)
        if baseline_check["admitted"]:
            seen.add(run_id)
            seeds.append((run_dir, contract_path, contract_data))
        if len(seeds) >= count:
            break

    if len(seeds) < count:
        raise RuntimeError(f"Found only {len(seeds)} verified admitted seed bundles, needed {count}")
    return seeds


def run_suite() -> dict[str, Any]:
    print("=== P0-5 Fault Injection Validation Suite ===")
    seeds = load_seed_bundles(20)
    print(f"Loaded and verified {len(seeds)} admitted seed bundles.")

    # Clean working directory
    WORK_DIR.mkdir(parents=True, exist_ok=False)

    results = []
    test_id = 0

    # 1. Evaluate 20 Control Bundles
    print("\n--- Evaluating 20 Control Bundles ---")
    for i, (seed_dir, contract_path, contract_data) in enumerate(seeds):
        test_id += 1
        case_id = f"CTRL-{i+1:03d}"
        target_dir = WORK_DIR / case_id / seed_dir.name
        shutil.copytree(seed_dir, target_dir)

        res = evaluate_admission(target_dir, contract_path, contract_data)
        record = {
            "test_id": test_id,
            "case_id": case_id,
            "category": "control",
            "fault_type": "none",
            "seed_bundle": seed_dir.name,
            "expected_admitted": True,
            "actual_admitted": res["admitted"],
            "detected_by_gate": not res["admitted"],
            "detection_stage": res["stage"],
            "reasons": res["reasons"],
            "elapsed_sec": res["elapsed_sec"],
        }
        results.append(record)
        status_sym = "[PASS]" if res["admitted"] else "[FAIL - FALSE POSITIVE]"
        print(f"  [{case_id}] {status_sym} admitted={res['admitted']} ({res['elapsed_sec']*1000:.1f}ms)")

    # 2. Evaluate 10 Fault Types x 20 Instances = 200 Fault Bundles
    print("\n--- Evaluating 200 Fault Injection Bundles (10 types x 20 instances) ---")
    for f_idx, (f_name, mutator) in enumerate(MUTATION_OPERATORS.items(), 1):
        print(f"\n>> Fault Type [{f_name}] ({f_idx}/10):")
        detected_count = 0
        for i, (seed_dir, contract_path, contract_data) in enumerate(seeds):
            test_id += 1
            case_id = f"FAULT-{f_idx:02d}-{i+1:03d}"
            target_dir = WORK_DIR / case_id / seed_dir.name
            shutil.copytree(seed_dir, target_dir)

            # Apply mutation
            mutator(target_dir)

            # Evaluate admission gate
            res = evaluate_admission(target_dir, contract_path, contract_data)
            record = {
                "test_id": test_id,
                "case_id": case_id,
                "category": "fault_injection",
                "fault_type": f_name,
                "seed_bundle": seed_dir.name,
                "expected_admitted": False,
                "actual_admitted": res["admitted"],
                "detected_by_gate": not res["admitted"],
                "detection_stage": res["stage"],
                "reasons": res["reasons"],
                "elapsed_sec": res["elapsed_sec"],
            }
            results.append(record)
            if not res["admitted"]:
                detected_count += 1

        print(f"   -> Detection: {detected_count}/20 ({detected_count/20*100:.1f}%)")

    # Retain new case evidence; never erase previous validation workspaces.

    return {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "total_test_cases": len(results),
        "results": results,
    }


def main() -> None:
    suite_output = run_suite()
    out_file = WORK_DIR / "raw_results.json"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text(json.dumps(suite_output, indent=2), encoding="utf-8")
    print(f"\nSuite complete. Raw results written to {out_file}")


if __name__ == "__main__":
    main()
