"""Run prediction for a single SWE-bench task using v3.0 dual insurance algorithm."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

# Add src to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit


def run_single_task(
    task_id: str, *, variant: str = "cactus_full", validation_id: str = "VALIDATION-10"
) -> dict:
    started_at = time.time()
    manifest_path = PROJECT_ROOT / "data/manifests/swebench_lite50_b0dde109_test_inference_safe.jsonl"
    model_config_path = PROJECT_ROOT / "configs/models/lite50_v3_dual_insurance.json"
    repo_cache = PROJECT_ROOT / "experiments/repo_cache"
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", validation_id):
        raise ValueError(f"Invalid validation_id: {validation_id!r}")
    runs_dir = PROJECT_ROOT / "experiments/runs" / validation_id / task_id
    runs_dir.mkdir(parents=True, exist_ok=True)

    tasks = load_manifest(manifest_path)
    task = next((t for t in tasks if t.task_id == task_id), None)
    if not task:
        return {"task_id": task_id, "status": "error", "error": f"Task {task_id} not found in manifest"}

    scratch_base = Path("E:/cactus-data/lite50/scratch")
    if not scratch_base.exists():
        scratch_base = Path(tempfile.gettempdir())
    
    workspace = scratch_base / f"val_{task_id}_{int(time.time())}"
    workspace.mkdir(parents=True, exist_ok=True)

    try:
        print(f"[PREPARE] Checking out {task_id} at {task.base_commit[:8]}...", flush=True)
        repo_root = checkout_base_commit(task, cache_root=repo_cache, workspace_root=workspace, allow_network_fetch=False)

        prediction_path = runs_dir / "prediction.jsonl"
        trace_path = runs_dir / "events.jsonl"

        import subprocess
        cmd = [
            sys.executable,
            str(PROJECT_ROOT / "scripts/cactus_swebench_predict.py"),
            "--tasks", str(manifest_path),
            "--task-id", task_id,
            "--repo-root", str(repo_root),
            "--model-config", str(model_config_path),
            "--trace", str(trace_path),
            "--output", str(prediction_path),
            "--budget", "12000",
            "--request-timeout-sec", "600",
            "--variant", variant,
        ]

        token_policy = {
            "per_task_soft_limit": 100000,
            "per_task_hard_limit": 400000,
            "per_call_min_reserve": 2000,
            "estimator_safety_factor": 1.1,
            "campaign_token_budget": 60000000,
            "campaign_tokens_used": 0,
            "campaign_tokens_remaining": 60000000,
            "remaining_task_count": 10,
        }
        cmd.extend(["--token-policy-json", json.dumps(token_policy)])

        child_env = os.environ.copy()
        child_env["PYTHONPATH"] = f"{PROJECT_ROOT / 'src'};{PROJECT_ROOT}"
        print(f"[RUN] Starting prediction for {task_id}...", flush=True)
        proc = subprocess.run(
            cmd,
            cwd=str(PROJECT_ROOT),
            capture_output=True,
            text=True,
            timeout=1200,
            env=child_env,
        )

        elapsed = time.time() - started_at
        log_path = runs_dir / "predict.log"
        log_path.write_text(f"STDOUT:\n{proc.stdout}\n\nSTDERR:\n{proc.stderr}\n", encoding="utf-8")

        if proc.returncode == 0 and prediction_path.exists() and prediction_path.stat().st_size > 0:
            print(f"[SUCCESS] {task_id} completed successfully in {elapsed:.1f}s", flush=True)
            return {
                "task_id": task_id,
                "status": "passed",
                "elapsed_sec": round(elapsed, 2),
                "patch_bytes": prediction_path.stat().st_size,
            }
        else:
            print(f"[FAILED] {task_id} exit={proc.returncode} in {elapsed:.1f}s", flush=True)
            stderr_snippet = proc.stderr.strip()[-500:] if proc.stderr else proc.stdout.strip()[-500:]
            return {
                "task_id": task_id,
                "status": "failed",
                "elapsed_sec": round(elapsed, 2),
                "returncode": proc.returncode,
                "error": stderr_snippet,
            }
    except Exception as exc:
        elapsed = time.time() - started_at
        print(f"[EXCEPTION] {task_id}: {exc}", flush=True)
        return {
            "task_id": task_id,
            "status": "exception",
            "elapsed_sec": round(elapsed, 2),
            "error": str(exc),
        }
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--variant", default="cactus_full")
    parser.add_argument("--validation-id", default="VALIDATION-10")
    args = parser.parse_args()

    result = run_single_task(
        args.task_id, variant=args.variant, validation_id=args.validation_id
    )
    print("RESULT_JSON:" + json.dumps(result))
    sys.exit(0 if result.get("status") == "passed" else 1)
