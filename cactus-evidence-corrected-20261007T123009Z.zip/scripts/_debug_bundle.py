"""Debug bundle export and import."""
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
MOUNT = ROOT / "tmp" / "docker_bundles" / "mount"
MOUNT.mkdir(parents=True, exist_ok=True)
MOUNT_STR = str(MOUNT).replace("\\", "/")

image = "swebench/sweb.eval.x86_64.astropy_1776_astropy-12907:78f471b"
base_commit = "d16bfe05a744909de4b27f5875fe0d4ed41ce607"

bundle_name = "astropy_test.bundle"
bundle_path = MOUNT / bundle_name

# Create bundle
print("Creating bundle...")
r = subprocess.run(
    ["docker", "run", "--rm", "-v", f"{MOUNT_STR}:/out", image, "bash", "-c",
     f"cd /testbed && git bundle create /out/{bundle_name} --all 2>&1"],
    capture_output=True, text=True, timeout=300,
)
print(f"Bundle exit: {r.returncode}")
print(f"Stdout: {r.stdout[:200]}")
print(f"Stderr: {r.stderr[:200]}")

if not bundle_path.exists():
    print("Bundle not created!")
else:
    print(f"Bundle size: {bundle_path.stat().st_size // 1024 // 1024} MB")

    # Clone
    tmp_clone = ROOT / "tmp" / f"clone_{int(time.time())}"
    tmp_clone.mkdir(parents=True, exist_ok=True)

    print(f"\nCloning to {tmp_clone}...")
    r2 = subprocess.run(
        ["git", "clone", str(bundle_path), str(tmp_clone)],
        capture_output=True, text=True, timeout=300,
    )
    print(f"Clone exit: {r2.returncode}")
    if r2.returncode != 0:
        print(f"Clone stderr: {r2.stderr[:200]}")
    else:
        # Verify
        print(f"\nVerifying base commit {base_commit[:12]}...")
        r3 = subprocess.run(
            ["git", "-C", str(tmp_clone), "cat-file", "-t", f"{base_commit}" + "{commit}"],
            capture_output=True, text=True, timeout=10,
        )
        print(f"cat-file exit: {r3.returncode}")
        if r3.returncode != 0:
            print(f"NOT FOUND")

            # Check log
            r4 = subprocess.run(
                ["git", "-C", str(tmp_clone), "log", "--oneline", "-10"],
                capture_output=True, text=True, timeout=10,
            )
            print(f"Log:\n{r4.stdout}")

            # Check rev-parse
            r5 = subprocess.run(
                ["git", "-C", str(tmp_clone), "rev-parse", base_commit[:12]],
                capture_output=True, text=True, timeout=10,
            )
            print(f"rev-parse exit: {r5.returncode}")
            if r5.returncode == 0:
                print(f"FOUND via rev-parse: {r5.stdout.strip()}")
        else:
            print(f"FOUND!")

        # Cleanup
        try:
            shutil.rmtree(tmp_clone)
        except Exception:
            pass
