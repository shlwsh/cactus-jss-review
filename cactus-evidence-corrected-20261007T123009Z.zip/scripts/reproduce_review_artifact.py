"""Regenerate a declared review package; never assert original-archive admission."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "src"), str(ROOT / "scripts")]


def verify_package():
    path = ROOT / "artifact_manifest.json"
    if not path.is_file():
        raise ValueError("this command requires a declared review artifact, not the research workspace")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest.get('schema_version') != '1.0' or not isinstance(manifest.get('input_hashes'), dict) or not manifest['input_hashes']:
        raise ValueError('invalid review artifact manifest')
    for name, digest in manifest["input_hashes"].items():
        if not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest):
            raise ValueError('invalid input digest: ' + name)
        target = (ROOT / name).resolve(); target.relative_to(ROOT.resolve())
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise ValueError("review artifact input changed: " + name)
    return manifest


def run(command, cwd=ROOT):
    env = {**os.environ, "PYTHONPATH": os.pathsep.join([str(ROOT), str(ROOT/'src'), str(ROOT/'scripts')])}
    completed = subprocess.run(command, cwd=cwd, env=env, capture_output=True)
    if completed.returncode:
        raise RuntimeError(completed.stdout.decode(errors='replace') + completed.stderr.decode(errors='replace'))


def verify_expected(*, tables=False, figures=False, paper=False):
    """Compare regenerated observations with the immutable package baseline."""
    expected_path = ROOT / 'expected/values.json'
    if not expected_path.is_file():
        raise ValueError('review package has no expected value baseline')
    expected = json.loads(expected_path.read_text(encoding='utf-8'))
    actual_ledger = json.loads((ROOT/'paper/data/publication_values.json').read_text(encoding='utf-8'))
    actual = {key: {'value':row['value'], 'display':row['display']} for key,row in actual_ledger['values'].items()}
    if actual != expected:
        raise ValueError('regenerated value/display pairs differ from package baseline')
    counts = {'value_display_pairs':len(expected)}
    mapping=json.loads((ROOT/'expected/manuscript_value_mapping.json').read_text(encoding='utf-8'))
    for row in mapping:
        if row['paper_value_id'] not in expected or expected[row['paper_value_id']] != {'value':row['expected_value'],'display':row['expected_display']}:
            raise ValueError('manuscript/artifact value mapping differs')
    counts['mapped_occurrences']=len(mapping)
    if tables:
        entries=json.loads((ROOT/'expected/table_checksums.json').read_text(encoding='utf-8'))
        for name,digest in entries.items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
                raise ValueError('regenerated TeX differs: '+name)
        counts['tex_artifacts']=len(entries)
    if figures:
        from PIL import Image
        entries=json.loads((ROOT/'expected/figure_checksums.json').read_text(encoding='utf-8'))['files']
        # Exact bytes are a stricter, reproducible check in the locked same-host
        # rehearsal; portable regeneration does not promise cross-platform fonts.
        different=[]
        for name,digest in entries.items():
            path=ROOT/name
            with Image.open(path) as img: img.verify()
            if hashlib.sha256(path.read_bytes()).hexdigest()!=digest: different.append(name)
        counts['png_artifacts']=len(entries)
        counts['png_byte_differences']=different
        if different: raise ValueError('regenerated PNG differs from same-environment baseline: '+', '.join(different))
    if paper:
        baseline=json.loads((ROOT/'expected/validation_summary.json').read_text(encoding='utf-8'))
        result=subprocess.run(['pdftotext','-layout',str(ROOT/'paper/build/main.pdf'),'-'],capture_output=True,check=True)
        digest=hashlib.sha256(' '.join(result.stdout.decode('utf-8').split()).encode('utf-8')).hexdigest()
        if digest!=baseline['manuscript_normalized_text_sha256']:
            raise ValueError('regenerated manuscript text differs from reviewed baseline')
        counts['manuscript_normalized_text_sha256']=digest
    return counts


def reproduce(command):
    manifest = verify_package()
    if command in {'mutations','all'}:
        run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_admission_semantics.py', '-v'])
        run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_review_artifact.py', '-v'])
        run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_near_valid_controls.py', '-v'])
        run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_seed_coverage.py', '-v'])
        from scripts.validate_packaged_semantics import run as validate_semantics
        synthetic=validate_semantics()
        if synthetic['verdict']!='PASS':
            raise ValueError('packaged synthetic semantic suite failed')
    else:
        synthetic=None
    if command in {'tables','figures','paper','all'}:
        from scripts.generate_publication_values import generate, verify, scan
        from scripts.verify_cited_papers import verify as citations
        citations()
        if command in {'paper','all'}:
            from scripts.paper_pipeline import bibliography, BUILD
            BUILD.mkdir(parents=True,exist_ok=True)
            bibliography()
        generate(); verify()
        if command in {'figures','paper','all'}:
            for script in ['generate_admission_values.py','generate_fig_system_overview.py','generate_fig_dual_lens_workflow.py','generate_fig_failure_taxonomy.py','generate_fig_semantic_admission.py']:
                run([sys.executable,str(ROOT/'paper/figures'/script)])
        if command in {'paper','all'}:
            result=scan()
            if result['errors']: raise ValueError(result['errors'])
            for _ in range(3):
                run(['pdflatex','-interaction=nonstopmode','-halt-on-error','-output-directory=build','main.tex'],ROOT/'paper')
            from scripts.check_publication_pdf import check
            rendering=check(ROOT/'paper/build/main.pdf',ROOT/'paper/build/main.log')
        else:
            rendering=None
    else:
        rendering=None
    comparison=verify_expected(tables=True,figures=command in {'figures','paper','all'},paper=command in {'paper','all'}) if command in {'tables','figures','paper','all'} else None
    result={'status':'PASS','scope':'packaged projections and synthetic fixtures; original historical admission is not certified',
            'command':command,'rendering':rendering,'comparison':comparison,
            'synthetic_semantics':None if synthetic is None else {key:synthetic[key] for key in ['verdict','summary','origin']},
            'levels':manifest['reproducibility_levels']}
    (ROOT/'review_reproduction_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['verify','mutations','tables','figures','paper','all'],default='all',nargs='?')
    reproduce(parser.parse_args().command)
