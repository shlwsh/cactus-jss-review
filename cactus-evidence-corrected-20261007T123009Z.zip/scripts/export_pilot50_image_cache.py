"""Export Pilot50 Docker images as one shared-layer cache archive."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from scripts.pull_pilot50_images import _category
except ModuleNotFoundError:  # Direct execution places only scripts/ on sys.path.
    from pull_pilot50_images import _category


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PLAN = ROOT / "artifacts" / "phase_c_pilot50_plan.json"
DEFAULT_OBSERVATION = ROOT / "artifacts" / "pilot50_image_digest_observation.json"
DEFAULT_CACHE_ROOT = Path("E:/docker-bak/cactus/pilot50")
SHARED_DIRNAME = "shared"
SHARED_ARCHIVE_NAME = "base-images.docker.tar"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _shared_paths(cache_root: Path) -> tuple[Path, Path, Path]:
    shared_dir = cache_root / SHARED_DIRNAME
    return shared_dir / SHARED_ARCHIVE_NAME, shared_dir / "base-manifest.json", shared_dir / f"{SHARED_ARCHIVE_NAME}.partial"


def _reusable(manifest_path: Path, archive_path: Path, image_refs: list[str], digests: dict[str, str], plan_sha256: str) -> bool:
    """Return whether a shared archive exactly covers the requested plan."""
    if not manifest_path.exists() or not archive_path.exists():
        return False
    try:
        manifest = _load(manifest_path)
    except (OSError, ValueError, json.JSONDecodeError):
        return False
    return (
        manifest.get("source_plan_sha256") == plan_sha256
        and manifest.get("image_refs") == image_refs
        and manifest.get("image_digests") == digests
        and manifest.get("archive_sha256") == _sha256(archive_path)
    )


def _category_results(grouped: dict[str, list[str]], status: str, archive_path: Path, archive_size_bytes: int | None = None, message: str = "") -> list[dict[str, Any]]:
    results = []
    for category, refs in sorted(grouped.items()):
        item: dict[str, Any] = {
            "category": category,
            "status": status,
            "image_count": len(refs),
            "archive": archive_path.as_posix(),
            "archive_scope": "all-pilot50-images",
        }
        if archive_size_bytes is not None:
            item["archive_size_bytes"] = archive_size_bytes
        if message:
            item["message"] = message
        results.append(item)
    return results


def _write_category_manifests(cache_root: Path, grouped: dict[str, list[str]], plan_sha256: str, archive_path: Path, generated_at: str) -> None:
    """Write category references only; never copy the shared archive."""
    relative_archive = Path("..").joinpath(SHARED_DIRNAME, SHARED_ARCHIVE_NAME).as_posix()
    for category, refs in sorted(grouped.items()):
        category_dir = cache_root / category
        category_dir.mkdir(parents=True, exist_ok=True)
        manifest = {
            "schema_version": "2.0",
            "generated_at": generated_at,
            "cache_scope": "swebench-pilot50",
            "category": category,
            "source_plan_sha256": plan_sha256,
            "image_count": len(refs),
            "image_refs": refs,
            "storage_strategy": "shared-layer-bundle",
            "shared_archive": relative_archive,
            "archive": archive_path.as_posix(),
            "execution_performed": False,
        }
        (category_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def export(
    plan_path: Path = DEFAULT_PLAN,
    observation_path: Path = DEFAULT_OBSERVATION,
    cache_root: Path = DEFAULT_CACHE_ROOT,
    categories: set[str] | None = None,
    force: bool = False,
    timeout_sec: float = 1800.0,
    retries: int = 2,
    retry_delay_sec: float = 10.0,
    command_runner=subprocess.run,
    additional_images: dict[str, str] | None = None,
) -> dict[str, Any]:
    if retries < 1:
        raise ValueError("retries must be positive")
    plan_bytes = plan_path.read_bytes()
    plan = _load(plan_path)
    observation = _load(observation_path)
    plan_image_refs = sorted(str(item.get("image")) for item in plan.get("evaluator_images", []) if isinstance(item, dict) and item.get("image"))
    additional_images = {str(ref): str(digest) for ref, digest in (additional_images or {}).items() if ref and digest}
    image_refs = sorted(set(plan_image_refs) | set(additional_images))
    observed = {str(item.get("image_ref")): str(item.get("candidate_digest")) for item in observation.get("images", []) if isinstance(item, dict) and item.get("image_ref") and item.get("candidate_digest")}
    if len(plan_image_refs) != 50 or len(observed) != 50 or any(ref not in observed for ref in plan_image_refs):
        return {"status": "BLOCKED", "reason": "50 complete local image digests are required before archive export", "exported_category_count": 0}

    normalized = {value.lower().replace("_", "-") for value in (categories or set())}
    all_grouped: dict[str, list[str]] = {}
    for ref in image_refs:
        all_grouped.setdefault(_category(ref), []).append(ref)
    requested_grouped = {category: refs for category, refs in all_grouped.items() if not normalized or category in normalized}
    if not requested_grouped:
        return {"status": "BLOCKED", "reason": "requested categories do not match the Pilot50 plan", "exported_category_count": 0}

    cache_root.mkdir(parents=True, exist_ok=True)
    archive_path, manifest_path, partial_path = _shared_paths(cache_root)
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    plan_sha256 = hashlib.sha256(plan_bytes).hexdigest()
    digests = {ref: observed[ref] for ref in plan_image_refs}
    digests.update(additional_images)
    if any(ref not in digests for ref in image_refs):
        return {"status": "BLOCKED", "reason": "all additional image refs require an explicit digest", "exported_category_count": 0}
    generated_at = _utc_now()
    archive_status = "REUSED"
    archive_size_bytes: int | None = archive_path.stat().st_size if archive_path.exists() else None
    failure_message = ""

    if force or not _reusable(manifest_path, archive_path, image_refs, digests, plan_sha256):
        archive_status = "FAILED"
        result = None
        for attempt in range(1, retries + 1):
            if partial_path.exists():
                partial_path.unlink()
            try:
                # One invocation over all refs lets Docker deduplicate shared layers.
                result = command_runner(["docker", "save", "--output", str(partial_path), *image_refs], capture_output=True, text=True, check=False, timeout=timeout_sec)
                failure_message = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()[-1000:]
            except subprocess.TimeoutExpired as exc:
                result = None
                failure_message = f"docker save timed out after {timeout_sec}s: {exc}"
            if result is not None and result.returncode == 0 and partial_path.exists():
                break
            if attempt < retries:
                time.sleep(retry_delay_sec * (2 ** (attempt - 1)))
        if result is not None and result.returncode == 0 and partial_path.exists():
            partial_path.replace(archive_path)
            archive_size_bytes = archive_path.stat().st_size
            generated_at = _utc_now()
            manifest = {
                "schema_version": "2.0",
                "generated_at": generated_at,
                "cache_scope": "swebench-pilot50",
                "storage_strategy": "single-shared-layer-bundle",
                "source_plan": plan_path.as_posix(),
                "source_plan_sha256": plan_sha256,
                "image_count": len(image_refs),
                "image_refs": image_refs,
                "image_digests": digests,
                "additional_images": additional_images,
                "categories": {category: refs for category, refs in sorted(all_grouped.items())},
                "archive": archive_path.as_posix(),
                "archive_size_bytes": archive_size_bytes,
                "archive_sha256": _sha256(archive_path),
                "network_calls": 0,
                "execution_performed": False,
                "deduplication_note": "All refs are saved together so Docker stores each shared layer once in this archive.",
            }
            manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
            archive_status = "EXPORTED"

    _write_category_manifests(cache_root, all_grouped, plan_sha256, archive_path, generated_at)
    category_results = _category_results(requested_grouped, archive_status, archive_path, archive_size_bytes, failure_message if archive_status == "FAILED" else "")
    result = {
        "schema_version": "2.0",
        "generated_at": generated_at,
        "cache_root": cache_root.as_posix(),
        "source_plan": plan_path.as_posix(),
        "source_plan_sha256": plan_sha256,
        "storage_strategy": "single-shared-layer-bundle",
        "shared_archive": archive_path.as_posix(),
        "requested_categories": sorted(requested_grouped),
        "execution_performed": False,
        "network_calls": 0,
        "categories": category_results,
        "exported_category_count": sum(item["status"] == "EXPORTED" for item in category_results),
        "reused_category_count": sum(item["status"] == "REUSED" for item in category_results),
        "failed_category_count": sum(item["status"] == "FAILED" for item in category_results),
        "docker_save_invocations": 1 if archive_status == "EXPORTED" else 0,
        "status": "complete" if archive_status in {"EXPORTED", "REUSED"} else "partial_failure",
    }
    (cache_root / "index.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--observation", type=Path, default=DEFAULT_OBSERVATION)
    parser.add_argument("--cache-root", type=Path, default=DEFAULT_CACHE_ROOT)
    parser.add_argument("--category", action="append", dest="categories", help="Only report this category; the shared archive remains plan-wide")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--timeout-sec", type=float, default=1800.0)
    parser.add_argument("--retries", type=int, default=2)
    parser.add_argument("--retry-delay-sec", type=float, default=10.0)
    parser.add_argument("--extra-image", action="append", default=[], metavar="REF=DIGEST", help="Add a content-addressed image ref to the same shared archive; repeatable")
    args = parser.parse_args()
    extra_images = {}
    for item in args.extra_image:
        ref, separator, digest = item.partition("=")
        if not separator or not ref or not digest:
            parser.error(f"--extra-image must use REF=DIGEST: {item}")
        extra_images[ref] = digest
    result = export(args.plan, args.observation, args.cache_root, set(args.categories or ()), args.force, args.timeout_sec, args.retries, args.retry_delay_sec, additional_images=extra_images)
    print(json.dumps({key: result[key] for key in ("status", "storage_strategy", "shared_archive", "exported_category_count", "reused_category_count", "failed_category_count") if key in result}, ensure_ascii=False))
    return 0 if result.get("status") == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
