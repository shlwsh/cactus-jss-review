"""Build a JSON-serialised deterministic repository index."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cactus.repository.index import build_index


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    index = build_index(args.root)
    payload = {"root": index.root, "index_hash": index.index_hash, "files": list(index.files), "units": [unit.to_dict() for unit in index.units], "edges": [{"source_id": edge.source_id, "target_id": edge.target_id, "relation": edge.relation, "confidence": edge.confidence} for edge in index.edges], "parse_failures": list(index.parse_failures)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "pass", "files": len(index.files), "units": len(index.units), "edges": len(index.edges), "index_hash": index.index_hash}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
