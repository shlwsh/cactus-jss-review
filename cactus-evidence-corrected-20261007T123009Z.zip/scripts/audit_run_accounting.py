#!/usr/bin/env python3
"""Audit RUN-directory scope, status, attempts and final-outcome provenance.

Historical RUN bundles are read only.  Missing campaign metadata is reported
as ``unknown_scope_runs`` instead of being silently assigned to the formal
campaign.
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RUNS = ROOT / "experiments" / "runs"
DEFAULT_OUTCOMES = ROOT / "paper" / "data" / "final_task_outcomes.csv"
DEFAULT_JSON = ROOT / "docs" / "audit" / "run_accounting.json"
DEFAULT_TEX = ROOT / "paper" / "generated" / "run_accounting.tex"
FORMAL_EXPERIMENT = "EXP-CACTUS-SWEBENCH-VERIFIED-V2"


def task_from_manifest(manifest: dict[str, object], run_dir: Path) -> str | None:
    command = manifest.get("command")
    if isinstance(command, list) and "--task-id" in command:
        index = command.index("--task-id")
        if index + 1 < len(command):
            return str(command[index + 1])
    for candidate in (run_dir / "raw" / "result.json", run_dir / "raw" / "prediction.json"):
        if candidate.is_file():
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            for key_path in (("data", "task_id"), ("task_id",), ("instance_id",)):
                value: object = data
                for key in key_path:
                    if not isinstance(value, dict):
                        value = None
                        break
                    value = value.get(key)
                if value:
                    return str(value)
    return None


def scope(manifest: dict[str, object] | None) -> str:
    if not manifest:
        return "unknown"
    experiment = str(manifest.get("experiment_id", ""))
    study = str(manifest.get("study_id", ""))
    if experiment == FORMAL_EXPERIMENT:
        return "formal_campaign"
    if study.startswith("MSCC-PILOT") or "PILOT" in experiment:
        return "pilot"
    if experiment or study:
        return "development"
    return "unknown"


def audit(runs_root: Path = DEFAULT_RUNS, outcomes_path: Path = DEFAULT_OUTCOMES) -> dict[str, object]:
    outcomes = {}
    with outcomes_path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            outcomes[row["task"]] = row
    records: list[dict[str, object]] = []
    task_runs: dict[str, list[dict[str, object]]] = defaultdict(list)
    for run_dir in sorted(path for path in runs_root.glob("RUN-*") if path.is_dir()):
        manifest_path = run_dir / "run_manifest.json"
        manifest = None
        if manifest_path.is_file():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                manifest = None
        item = {
            "run_id": run_dir.name,
            "path": run_dir.relative_to(ROOT).as_posix(),
            "scope": scope(manifest),
            "manifest_present": manifest is not None,
            "status": str(manifest.get("status", "unknown")) if manifest else "unknown",
            "experiment_id": str(manifest.get("experiment_id", "")) if manifest else "",
            "study_id": str(manifest.get("study_id", "")) if manifest else "",
            "campaign_id": str(manifest.get("campaign_id", "")) if manifest else "",
            "effective_campaign_id": (
                str(manifest.get("campaign_id"))
                if manifest and manifest.get("campaign_id")
                else f"legacy:{manifest.get('experiment_id')}" if manifest and manifest.get("experiment_id") else ""
            ),
            "protocol_version": str(manifest.get("protocol_version", "")) if manifest else "",
            "variant_id": str(manifest.get("variant_id", "")) if manifest else "",
            "attempt_index": manifest.get("attempt_index") if manifest else None,
            "task_id": task_from_manifest(manifest or {}, run_dir),
        }
        records.append(item)
        if item["task_id"]:
            task_runs[str(item["task_id"])].append(item)

    formal = [item for item in records if item["scope"] == "formal_campaign"]
    attempts = Counter(len([item for item in items if item["scope"] == "formal_campaign"]) for items in task_runs.values())
    completed_by_task = {
        task: [item for item in items if item["scope"] == "formal_campaign" and item["status"] == "completed"]
        for task, items in task_runs.items()
    }
    multiple_completed = sorted(task for task, items in completed_by_task.items() if len(items) > 1)
    all_with_task = [task for task in task_runs if task in outcomes]
    report = {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source": {"runs_root": runs_root.relative_to(ROOT).as_posix(), "outcomes": outcomes_path.relative_to(ROOT).as_posix()},
        "scope_counts": dict(Counter(str(item["scope"]) for item in records)),
        "all_run_dirs": len(records),
        "formal_campaign_runs": len(formal),
        "development_runs": sum(item["scope"] == "development" for item in records),
        "pilot_runs": sum(item["scope"] == "pilot" for item in records),
        "unknown_scope_runs": sum(item["scope"] == "unknown" for item in records),
        "formal_completed_runs": sum(item["status"] == "completed" for item in formal),
        "formal_failed_runs": sum(item["status"] == "failed" for item in formal),
        "formal_distinct_tasks": len({str(item["task_id"]) for item in formal if item["task_id"]}),
        "formal_tasks_with_outcomes": len(set(all_with_task)),
        "attempt_count_distribution": {str(key): value for key, value in sorted(attempts.items())},
        "max_attempts_per_task": max(attempts, default=0),
        "median_attempts_per_task": statistics.median([len(items) for items in task_runs.values()]) if task_runs else 0,
        "tasks_with_multiple_completed_runs": multiple_completed,
        "tasks_with_policy_retries": sorted(task for task, items in task_runs.items() if any(item.get("attempt_index") not in (None, 0, "0") for item in items)),
        "tasks_with_nonpolicy_retries": sorted(task for task, items in task_runs.items() if len(items) > 1 and not any(item.get("attempt_index") not in (None, 0, "0") for item in items)),
        "missing_campaign_id_formal_runs": sum(item["scope"] == "formal_campaign" and not item["campaign_id"] for item in records),
        "records": records,
    }
    return report


def render_tex(report: dict[str, object]) -> str:
    rows = [
        ("All RUN directories", report["all_run_dirs"]),
        ("RUNs classified as the Verified campaign", report["formal_campaign_runs"]),
        ("Formal completed runs", report["formal_completed_runs"]),
        ("Formal failed runs", report["formal_failed_runs"]),
        ("Formal distinct tasks", report["formal_distinct_tasks"]),
        ("Pilot runs", report["pilot_runs"]),
        ("Development runs", report["development_runs"]),
        ("Unknown-scope runs", report["unknown_scope_runs"]),
        ("Formal runs missing campaign ID", report["missing_campaign_id_formal_runs"]),
    ]
    lines = ["% Generated by scripts/audit_run_accounting.py; do not hand-edit.", r"\begin{tabular}{lr}", r"Quantity & Count\\", r"\midrule"]
    lines.extend(f"{label} & {value}\\\\" for label, value in rows)
    lines.extend([r"\bottomrule", r"\end{tabular}", ""])
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=DEFAULT_RUNS)
    parser.add_argument("--outcomes", type=Path, default=DEFAULT_OUTCOMES)
    parser.add_argument("--json-output", type=Path, default=DEFAULT_JSON)
    parser.add_argument("--tex-output", type=Path, default=DEFAULT_TEX)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args(argv)
    report = audit(args.runs, args.outcomes)
    args.json_output.parent.mkdir(parents=True, exist_ok=True)
    args.tex_output.parent.mkdir(parents=True, exist_ok=True)
    args.json_output.write_text(json.dumps({key: value for key, value in report.items() if key != "records"}, indent=2) + "\n", encoding="utf-8", newline="\n")
    args.tex_output.write_text(render_tex(report), encoding="utf-8", newline="\n")
    from artifact_provenance import write
    manifests = [p for p in sorted(args.runs.glob("RUN-*/run_manifest.json")) if p.is_file()]
    write(args.tex_output, [args.outcomes, *manifests], Path(__file__), transform={"scope": "inventory_accounting_not_effectiveness_or_admission"})
    legacy_table = ROOT / "docs/paper_tables/table_campaign_accounting.tex"
    legacy_table.write_text(render_tex(report), encoding="utf-8", newline="\n")
    write(legacy_table, [args.outcomes, *manifests], Path(__file__), transform={"scope": "inventory_accounting_not_effectiveness_or_admission"})
    print(json.dumps({key: value for key, value in report.items() if key != "records"}, ensure_ascii=False))
    if args.strict and any(item["scope"] == "formal_campaign" and not item["effective_campaign_id"] for item in report["records"]):
        print("AUDIT FAILED: formal runs without any campaign/protocol identity; see report", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    import sys
    raise SystemExit(main())
