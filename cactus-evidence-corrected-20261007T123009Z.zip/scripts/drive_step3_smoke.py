"""
Step 3: Single-task validation with full monitoring.

Runs one SWE-bench task with thinking enabled and the r4_monitor watching.
Emits a per-task verdict immediately on completion.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

CONTRACT_DEFAULT = (
    ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
)
APPROVAL_DEFAULT = (
    ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
)
MODEL_CONFIG = ROOT / "configs/models/litellm_local.json"
TASKS_JSONL = ROOT / "json/cactus_tasks_inference_safe.jsonl"


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def ts_human() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def run_smoke(task_id: str, run_root: Path, contract: Path, approval: Path,
              model_config: Path, max_output_tokens: int | None = None,
              thinking: bool | None = None, dry_run: bool = False) -> dict:
    """Run a single-task smoke test using predict_bridge directly.

    Returns a dict with: run_id, task_id, status, monitor_verdict, output_dir.
    """
    out_dir = run_root / f"RUN-{utc_now()}-SMOKE-{task_id.split('__', 1)[-1][:8]}"
    out_dir.mkdir(parents=True, exist_ok=True)
    trace_dir = out_dir / "trace"
    trace_dir.mkdir(exist_ok=True)
    output_json = out_dir / "prediction.json"
    cmd = [
        str(ROOT / ".venv/Scripts/python.exe"),
        str(ROOT / "scripts/cactus_swebench_predict.py"),
        "--task-id", task_id,
        "--tasks", str(TASKS_JSONL),
        "--repo-root", "E:/work/p5-acm/acm/_eval_repos",
        "--model-config", str(model_config),
        "--trace", str(trace_dir),
        "--output", str(output_json),
        "--budget", "12000",
        "--variant", "cactus_full",
    ]
    if max_output_tokens is not None:
        cmd += ["--max-output-tokens", str(max_output_tokens)]

    if dry_run:
        return {
            "out_dir": str(out_dir),
            "cmd": cmd,
            "dry_run": True,
            "task_id": task_id,
        }

    env = os.environ.copy()
    # Try to inject the LiteLLM key from the project's .env if available
    env_file = ROOT / "docs/llm/.env"
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            if any(tag in k.upper() for tag in ("LITELLM", "API_KEY", "CACTUS")):
                env[k] = v.strip()

    t0 = time.time()
    result = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=900)
    elapsed = time.time() - t0

    # Persist subprocess output
    (out_dir / "subprocess.stdout.log").write_text(result.stdout, encoding="utf-8")
    (out_dir / "subprocess.stderr.log").write_text(result.stderr, encoding="utf-8")
    (out_dir / "subprocess.cmd.json").write_text(
        json.dumps({"cmd": cmd, "returncode": result.returncode, "elapsed_sec": elapsed}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return {
        "out_dir": str(out_dir),
        "returncode": result.returncode,
        "elapsed_sec": elapsed,
        "stdout_tail": result.stdout[-500:],
        "stderr_tail": result.stderr[-500:],
        "task_id": task_id,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--task-id", default="astropy__astropy-12907",
                   help="Task to run; default astropy__astropy-12907 (R4's first task)")
    p.add_argument("--contract", default=str(CONTRACT_DEFAULT))
    p.add_argument("--approval", default=str(APPROVAL_DEFAULT))
    p.add_argument("--model-config", default=str(MODEL_CONFIG))
    p.add_argument("--run-root", default=str(ROOT / "experiments/runs"))
    p.add_argument("--max-output-tokens", type=int, default=None,
                   help="Override max_output_tokens (e.g. 16384) for thinking mode")
    p.add_argument("--thinking", choices=["true", "false"], default=None,
                   help="Override thinking flag in model config")
    p.add_argument("--dry-run", action="store_true", help="Print command without running")
    args = p.parse_args()

    summary = {
        "started_at": ts_human(),
        "task_id": args.task_id,
        "contract": args.contract,
        "approval": args.approval,
        "model_config": args.model_config,
        "max_output_tokens": args.max_output_tokens,
        "thinking": args.thinking,
    }
    print("=" * 70)
    print(f"STEP 3: SINGLE-TASK VALIDATION — task={args.task_id}")
    print("=" * 70)
    print(json.dumps(summary, ensure_ascii=False, indent=2))

    if args.thinking is not None or args.max_output_tokens is not None:
        # Modify the model config in a sidecar copy (do not touch original)
        sidecar_cfg = Path(args.model_config).with_name("litellm_local_smoke.json")
        cfg = json.loads(Path(args.model_config).read_text(encoding="utf-8"))
        if args.thinking is not None:
            cfg["thinking"] = args.thinking == "true"
        if args.max_output_tokens is not None:
            cfg["max_output_tokens"] = args.max_output_tokens
        sidecar_cfg.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"sidecar config written: {sidecar_cfg}")
        model_cfg = sidecar_cfg
    else:
        model_cfg = Path(args.model_config)

    result = run_smoke(
        task_id=args.task_id,
        run_root=Path(args.run_root),
        contract=Path(args.contract),
        approval=Path(args.approval),
        model_config=model_cfg,
        max_output_tokens=args.max_output_tokens,
        dry_run=args.dry_run,
    )

    summary["result"] = result
    summary["finished_at"] = ts_human()

    out_log = Path(args.run_root) / f"_step3_smoke_{utc_now()}.json"
    out_log.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nSummary written to: {out_log}")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
