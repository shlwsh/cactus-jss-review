#!/usr/bin/env python3
"""drive_blocker3_finalize.py — End-to-end 卡点③ finalizer.

Idempotent wrapper that:
  (1) validates each step that should already be done
  (2) repairs the dacl_baseline .sha256 sidecar BOM (if present)
  (3) re-runs _is_read_only_root() 实证 on the three data roots
  (4) writes a single handoff JSON summary into docs/codex/

Re-running is safe — no destructive ops without --apply-dacl.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(r"E:\work\p5-acm\acm")

CONTRACT_REL = "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
AUTH_REL     = "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.session_authorization.json"
SIDECAR_REL  = "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.sha256"
OBS_SNAP_REL = "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json"
PEND_SNAP_REL= "experiments/snapshots/C1-pre-r2-20260925T071721Z_pending_dacl.json"
DACL_BASE_REL= "experiments/snapshots/dacl_baseline_R2_20260925-151621.json"
DACL_BASE_SH = "experiments/snapshots/dacl_baseline_R2_20260925-151621.json.sha256"

DATA_ROOTS = [
    r"E:\docker-bak\cactus\pilot50",
    r"E:\cactus-data\repo-cache",
    r"E:\cactus-data\swebench",
]

def sha_file_bytes(p: pathlib.Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def sha_file_text(p: pathlib.Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()  # sidecar is bytes

def load_json(p: pathlib.Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8-sig"))

def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def fix_sidecar_bom(sidecar: pathlib.Path, expected_sha: str) -> tuple[bool, str]:
    """Sidecar's expected format: '<sha>  <basename>\n'. Some files contain BOM.

    Returns (changed, new_content).
    """
    raw = sidecar.read_bytes()
    expected = f"{expected_sha}  {sidecar.name.replace('.sha256', '')}\n"
    if raw == expected.encode("ascii"):
        return False, "sidecar already matches (no BOM, no padding)"
    # Strip BOM if present
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    norm = raw.replace(b"\r\n", b"\n").strip()
    target = expected.encode("ascii").strip()
    if norm == target:
        sidecar.write_bytes(expected.encode("ascii"))
        return True, "re-wrote sidecar without BOM"
    if norm.split()[0:2] == target.split()[0:2]:
        sidecar.write_bytes(expected.encode("ascii"))
        return True, "re-aligned sidecar lines"
    return False, f"unexpected sidecar content: {raw!r}"


def check_deny_ace_present(root: str) -> tuple[str, bool, list[str]]:
    import subprocess
    r = subprocess.run(["icacls", root], capture_output=True, text=True, timeout=30)
    acl_lines = [ln.strip() for ln in r.stdout.splitlines() if ln.strip()]
    deny_lines = [ln for ln in acl_lines if "(DENY)" in ln.upper()]
    has_everyone = any("Everyone:(DENY)" in ln or "Everyone: (DENY)" in ln for ln in deny_lines)
    has_users = any("BUILTIN\\Users:(DENY)" in ln for ln in deny_lines)
    if has_everyone and has_users:
        verdict = "BOTH_DENY_ACES_PRESENT"
    elif has_everyone or has_users:
        verdict = "PARTIAL"
    else:
        verdict = "NO_DENY_ACE"
    return verdict, has_everyone and has_users, deny_lines


def check_read_only_runtime(root: str) -> dict:
    """Emulate the dataset_resolver perspective: try os.access(W_OK), try probing."""
    info = {"path": root, "exists": os.path.exists(root)}
    if not info["exists"]:
        return info
    info["os.access.W_OK"] = os.access(root, os.W_OK)
    info["os.access.R_OK"] = os.access(root, os.R_OK)
    # Try an actual mutation only if the snapshot needs an updated read_only=False.
    # We don't actually mutate here; the icacls DENY lines are the authoritative signal.
    return info


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--fix-sidecar-bom", action="store_true",
                   help="Rewrite the dacl_baseline .sha256 file without BOM")
    p.add_argument("--summary-path",
                   default="experiments/snapshots/blocker3_finalize_state.json",
                   help="Output consolidated state JSON")
    p.add_argument("--verify-only", action="store_true")
    args = p.parse_args()

    state = {
        "captured_at_utc": utc_now(),
        "contract": {},
        "auth": {},
        "snapshots": {},
        "dacl_state": {},
        "read_only_runtime": {},
        "binding_consistency": {"ok": True, "issues": []},
    }

    # --- read on-disk truth ---
    contract_path = ROOT / CONTRACT_REL
    auth_path     = ROOT / AUTH_REL
    sidecar_path  = ROOT / SIDECAR_REL
    obs_snap_path = ROOT / OBS_SNAP_REL
    pend_snap_path = ROOT / PEND_SNAP_REL
    dacl_base_path = ROOT / DACL_BASE_REL
    dacl_base_sh_path = ROOT / DACL_BASE_SH

    contract = load_json(contract_path)
    auth = load_json(auth_path)
    obs_snap = load_json(obs_snap_path)
    pend_snap = load_json(pend_snap_path)
    dacl_base = load_json(dacl_base_path)

    state["contract"]["body_sha256"] = sha_file_bytes(contract_path)
    state["contract"]["linked_env_snap_path"] = contract["execution"]["environment_snapshot_path"]
    state["contract"]["linked_env_snap_sha"] = contract["execution"]["environment_snapshot_sha256"]
    state["contract"]["linked_dacl_baseline_path"] = contract["execution"]["dacl_baseline_path"]
    state["contract"]["linked_dacl_baseline_sha"] = contract["execution"]["dacl_baseline_sha256"]
    state["contract"]["dacl_status_in_metadata"] = contract["_metadata"].get("r2_kpi3_progress", {}).get("step_b_owner_dacl_apply")
    state["contract"]["env_snap_status_text"] = contract["execution"].get("environment_snapshot_status", "")[:100]

    state["auth"]["contract_sha256_canonical"] = auth["contract_sha256"]
    state["auth"]["linked_contract_sha256_body"] = auth["_metadata"]["linked_contract_sha256"]
    state["auth"]["linked_env_snap_sha"] = auth["_metadata"]["linked_environment_snapshot_sha256"]
    state["auth"]["linked_dacl_baseline_sha"] = auth["_metadata"]["linked_dacl_baseline_sha256"]
    state["auth"]["rebinding_at"] = auth["_metadata"].get("rebinding_at")
    state["auth"]["dacl_apply_completed_at"] = auth["_metadata"].get("dacl_apply_completed_at")
    state["auth"]["dacl_apply_verified"] = auth["_metadata"].get("dacl_apply_verified")

    state["snapshots"]["observed"] = {
        "path": OBS_SNAP_REL,
        "body_sha256": sha_file_bytes(obs_snap_path),
        "dacl_status": obs_snap["extra"]["dacl_status"],
        "data_roots_read_only": [v["read_only"] for v in obs_snap["data_roots"].values()],
        "captured_at": obs_snap["generated_at"],
    }
    state["snapshots"]["pending"] = {
        "path": PEND_SNAP_REL,
        "body_sha256": sha_file_bytes(pend_snap_path),
        "dacl_status": pend_snap["extra"]["dacl_status"],
        "data_roots_read_only": [v["read_only"] for v in pend_snap["data_roots"].values()],
    }
    state["snapshots"]["dacl_baseline"] = {
        "path": DACL_BASE_REL,
        "body_sha256": sha_file_bytes(dacl_base_path),
        "roots": list(dacl_base.get("roots", {}).keys()) or [r["path"] for r in dacl_base.get("entries", [])] if isinstance(dacl_base, dict) else [],
    }

    # --- sidecar BOM fix (if requested) ---
    if args.fix_sidecar_bom:
        ok, msg = fix_sidecar_bom(dacl_base_sh_path, dacl_base_path)
        state["binding_consistency"]["sidecar_bom_fix"] = {"applied": ok, "msg": msg}

    # --- DACL check on the 3 roots ---
    for root in DATA_ROOTS:
        verdict, has_both, deny_lines = check_deny_ace_present(root)
        state["dacl_state"][root] = {
            "verdict": verdict,
            "deny_ace_everyone_and_users": has_both,
            "deny_lines": deny_lines,
        }
        state["read_only_runtime"][root] = check_read_only_runtime(root)

    # --- cross-consistency ---
    iss = []
    if state["contract"]["linked_env_snap_sha"] != state["snapshots"]["observed"]["body_sha256"]:
        iss.append("contract.env_snap_sha != observed snapshot body sha")
    if state["contract"]["linked_dacl_baseline_sha"] != state["snapshots"]["dacl_baseline"]["body_sha256"]:
        iss.append("contract.dacl_baseline_sha != baseline body sha")
    if state["auth"]["linked_env_snap_sha"] != state["snapshots"]["observed"]["body_sha256"]:
        iss.append("auth.linked_env_snap_sha != observed snapshot body sha")
    if state["auth"]["linked_dacl_baseline_sha"] != state["snapshots"]["dacl_baseline"]["body_sha256"]:
        iss.append("auth.linked_dacl_baseline_sha != baseline body sha")
    if state["auth"]["linked_contract_sha256_body"] != state["contract"]["body_sha256"]:
        iss.append("auth.linked_contract_sha256 != contract body sha")
    if state["auth"]["contract_sha256_canonical"] != hashlib.sha256(
        json.dumps(contract, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ).hexdigest():
        iss.append("auth.contract_sha256 != canonical_json(contract) sha")
    sidecar_text = sidecar_path.read_text(encoding="utf-8-sig").strip()
    if not sidecar_text.startswith(state["contract"]["body_sha256"]):
        iss.append(f"contract sidecar does not start with body sha")

    state["binding_consistency"]["issues"] = iss
    state["binding_consistency"]["ok"] = not iss

    if not all(s["verdict"] == "BOTH_DENY_ACES_PRESENT" for s in state["dacl_state"].values()):
        state["binding_consistency"]["ok"] = False
        state["binding_consistency"]["issues"].append(
            "DACL runtime state: at least one root lacks the deny ACE pair")

    # Decide final verdict
    if state["binding_consistency"]["ok"]:
        state["blocker3_verdict"] = "PASS"
    else:
        state["blocker3_verdict"] = "GAPS_REMAIN"

    out_path = ROOT / args.summary_path
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(state, indent=2, ensure_ascii=False, sort_keys=False),
        encoding="utf-8",
    )
    print(f"summary -> {out_path}")
    print(json.dumps(state["blocker3_verdict"], ensure_ascii=False, indent=2))
    if iss:
        print("issues:")
        for i in iss:
            print(f"  - {i}")
    return 0 if state["binding_consistency"]["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
