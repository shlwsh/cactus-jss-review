"""Derive an immutable progress reconciliation view; never rewrite frozen outcomes."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from scripts.aggregate_lite50_results import _valid_evaluator
from scripts.artifact_provenance import write

ROOT = Path(__file__).resolve().parents[1]


def sync(output: Path) -> dict:
    output = output.resolve()
    output.relative_to((ROOT / "experiments/derived").resolve())
    if output.exists():
        raise FileExistsError("refusing to overwrite reconciliation evidence")
    source = ROOT / "analysis/phase_c_progress.jsonl"
    progress = [json.loads(line) for line in source.read_text(encoding="utf-8").splitlines() if line.strip()]
    rows = []
    inputs = [source, ROOT / "scripts/aggregate_lite50_results.py"]
    for record in progress:
        run_id = record.get("run_id")
        if not isinstance(run_id, str) or Path(run_id).name != run_id:
            raise ValueError("unsafe or missing RUN identity in progress log")
        run = ROOT / "experiments/runs" / run_id
        reports = sorted((run / "evaluation").glob("*.json"))
        official = {}
        if len(reports) == 1:
            official = json.loads(reports[0].read_text(encoding="utf-8"))
            inputs.append(reports[0])
        valid = _valid_evaluator(official, record.get("task_id"))
        rows.append({"progress_record": record, "evaluator_valid": valid,
                     "outcome": ("VALID_RESOLVED" if official["resolved_instances"] else "VALID_UNRESOLVED") if valid else "UNADJUDICATED",
                     "publication_admission": "not_established_by_progress_reconciliation"})
    payload = {"schema_version": "1.0", "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
               "policy": "completed_is_not_evaluator_valid; no_frozen_snapshot_overwrite", "records": rows}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write(output, inputs, Path(__file__), transform={"policy": payload["policy"]}, kind="derived_dataset")
    return {"status": "PASS", "reconciled_progress_records": len(rows)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(sync(args.output), ensure_ascii=False))
