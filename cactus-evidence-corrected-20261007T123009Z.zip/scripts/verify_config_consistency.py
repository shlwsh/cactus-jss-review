"""验证工程验证与生产配置完全一致."""

from __future__ import annotations

import json
from pathlib import Path
import sys


def get_acm_root() -> Path:
    """获取 acm 仓库根目录."""
    candidate = Path(__file__).resolve().parent.parent
    if (candidate / "configs").exists():
        return candidate
    cwd = Path.cwd()
    if (cwd / "configs").exists():
        return cwd
    if (cwd / "acm" / "configs").exists():
        return cwd / "acm"
    return candidate


def verify_config_consistency(config_path: Path | None = None) -> tuple[bool, str]:
    """验证配置文件一致性.

    核心配置项（必须完全一致）：
    - algorithm_revision
    - self_correction_loop.*
    - multi_candidate.*
    - validation.*
    - origin_traceability.*
    """
    if config_path is None:
        config_path = get_acm_root() / "configs" / "models" / "lite50_v3_dual_insurance.json"

    if not config_path.exists():
        return False, f"配置文件不存在: {config_path}"

    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)

    # 核心算法配置（必须一致）
    core_keys = [
        "algorithm_revision",
        "self_correction_loop",
        "multi_candidate",
        "validation",
        "origin_traceability",
    ]

    for key in core_keys:
        if key not in config:
            return False, f"缺少核心配置: {key}"

    # 检查子配置关键字段
    scl = config.get("self_correction_loop", {})
    if not isinstance(scl, dict) or "enabled" not in scl or "max_attempts" not in scl:
        return False, "self_correction_loop 配置结构不完整"

    mc = config.get("multi_candidate", {})
    if not isinstance(mc, dict) or "num_candidates" not in mc:
        return False, "multi_candidate 配置结构不完整"

    val = config.get("validation", {})
    if not isinstance(val, dict) or "layers" not in val:
        return False, "validation 配置结构不完整"

    return True, "配置一致性验证通过"


if __name__ == "__main__":
    is_consistent, msg = verify_config_consistency()
    if not is_consistent:
        print(f"❌ {msg}", file=sys.stderr)
        sys.exit(1)
    print(f"✅ {msg}")
