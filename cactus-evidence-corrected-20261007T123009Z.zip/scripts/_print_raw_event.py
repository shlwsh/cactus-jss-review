"""Print raw JSON of last 3 events."""
import json, sys
from pathlib import Path

name = sys.argv[1] if len(sys.argv) > 1 else 'django__django-11910'
base = Path(f'experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/{name}/events.jsonl')
lines = base.read_text(encoding='utf-8', errors='ignore').splitlines()

# Print full structure of last 5 events
for l in lines[-5:]:
    try:
        e = json.loads(l)
        print('---')
        print(json.dumps(e, ensure_ascii=False, indent=2)[:1500])
    except Exception:
        pass