"""Run deterministic offline context-selection pilots.

This command intentionally does not call a model or evaluator. It creates
selection plans and marks execution outcomes as pending until an authorized
provider/evaluator runner supplies evidence bundles.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cactus.context.packer import pack_context
from cactus.engine import ContextEngine
from cactus.trace.store import TraceStore


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--budget", type=int, default=2000)
    parser.add_argument("--limit", type=int, default=10)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8"))
    tasks = [json.loads(line) for line in args.manifest.read_text(encoding="utf-8").splitlines() if line.strip()]
    tasks = tasks[: args.limit]
    rows = []
    for task in tasks:
        task_id = str(task.get("instance_id", task.get("task_id", "unknown")))
        events = args.output / "events" / f"{task_id}.jsonl"
        engine = ContextEngine(args.repo_root, TraceStore(events, f"PLAN-{task_id}"))
        variant = config.get("variant", "cactus_full")
        context_cfg = config.get("context", {})
        plan, context = engine.propose(str(task.get("problem_statement", "")), f"plan-{task_id}", args.budget, use_graph=bool(context_cfg.get("symbol_graph", variant != "no_symbol_graph")), use_budget=bool(context_cfg.get("budget_controller", variant != "no_budget_controller")))
        selected = [unit for unit in engine._last_units if unit.unit_id in set(plan.selected_unit_ids)] if hasattr(engine, "_last_units") else []
        bundle = pack_context(selected, task_id=task_id, budget=args.budget) if selected else {"context_bundle_hash": hashlib.sha256(context.encode()).hexdigest(), "token_count": plan.token_count, "chunks": []}
        rows.append({"instance_id": task_id, "variant": variant, "status": "selection_planned", "canonical_outcome": "pending", "context_bundle_hash": bundle["context_bundle_hash"], "context_token_count": plan.token_count, "selected_unit_count": len(plan.selected_unit_ids), "evidence_status": "pending_model_and_evaluator"})
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "selection_summary.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    (args.output / "run_status.json").write_text(json.dumps({"status": "selection_planned", "records": len(rows), "model_execution": "not_started", "evaluator_execution": "not_started"}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "selection_planned", "records": len(rows), "output": args.output.as_posix()}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
