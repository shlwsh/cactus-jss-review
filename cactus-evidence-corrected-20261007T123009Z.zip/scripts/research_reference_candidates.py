"""Capture user-suggested identifiers from primary metadata services, without trusting titles."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import urllib.request
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]
STAMP = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT = ROOT / 'paper/data/scholar' / ('reference_candidates_' + STAMP)
OUT.mkdir(exist_ok=False)
BACKUP = OUT / 'before'
BACKUP.mkdir()
for name in ('main.tex', 'references.bib', 'publication_sources.json', 'data/scholar/cited_papers_manifest.json'):
    target = BACKUP / Path(name).name
    shutil.copy2(ROOT / 'paper' / name, target)

DOIS = ['10.1145/3475716.3475772', '10.1016/j.infsof.2015.03.007',
        '10.1145/3641541', '10.1145/2818754.2818771', '10.1145/2908080.2908107',
        '10.1109/TSE.2019.2946147', '10.1109/TSE.2024.3456388',
        '10.1109/TSE.2010.62', '10.1109/FMCAD.2013.6679385']
QUERIES = ['The Practicality of Automated Program Repair Rethinking the Metrics',
           'Automatic Patch Generation Learned from Human-Written Patches',
           'Are Automated Program Repair Tools Ready for Real Software',
           'Software Engineering in the Era of Large Language Models A Vision and Roadmap',
           'A Survey on Large Language Models for Code Generation']

def capture(item):
    kind, value, number = item
    url = ('https://api.crossref.org/works/' + urllib.parse.quote(value, safe='') if kind == 'doi'
           else 'https://api.crossref.org/works?rows=3&query.title=' + urllib.parse.quote(value))
    record = {'kind': kind, 'input': value, 'url': url}
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'CACTUS-citation-verification/1.0'}), timeout=35) as response:
            data = response.read()
            record['final_url'] = response.url
        path = OUT / f'{number:02d}_{kind}.json'
        path.write_bytes(data)
        record.update(file_path=path.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(data).hexdigest(),
                      retrieved_at=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'))
        message = json.loads(data)['message']
        items = [message] if kind == 'doi' else message['items']
        record['matches'] = [{k: m.get(k) for k in ('DOI', 'title', 'author', 'published', 'container-title', 'volume', 'issue', 'page', 'link', 'type')} for m in items]
    except Exception as exc:
        record['error'] = type(exc).__name__ + ': ' + str(exc)
    return record

jobs = [('doi', d, n) for n, d in enumerate(DOIS)] + [('title', q, n+len(DOIS)) for n, q in enumerate(QUERIES)]
with ThreadPoolExecutor(max_workers=4) as pool:
    records = list(pool.map(capture, jobs))
(OUT / 'index.json').write_text(json.dumps({'generated_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'), 'records': records}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(OUT.relative_to(ROOT).as_posix())
for r in records:
    print(r['input'], json.dumps([(m['DOI'], m['title'], m['container-title']) for m in r.get('matches', [])], ensure_ascii=False), r.get('error', ''))
