"""Map each context unit to its file/symbol/lines."""
import json
import sys
from pathlib import Path

run = Path(sys.argv[1])
events = [json.loads(l) for l in (run / "trace" / "events.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]

def show(name, key, p, max_items=30):
    val = p.get(key)
    if val is None:
        return
    if isinstance(val, int):
        print(f"  {key}={val}")
    elif isinstance(val, list):
        print(f"  {key} ({len(val)} items):")
        for u in val[:max_items]:
            print(f"    {u}")
    elif isinstance(val, dict):
        print(f"  {key} ({len(val)} entries):")
        for k, v in list(val.items())[:max_items]:
            print(f"    {k}: {str(v)[:200]}")
    else:
        print(f"  {key}={val}")

for et in ["issue_symbol_anchors", "literal_source_anchors", "context_candidates_pruned",
           "literal_anchor_candidates", "context_selected"]:
    print(f"\n=== {et} ===")
    found = [e for e in events if e["type"] == et]
    if not found:
        print("  (not present)")
        continue
    # Show last one (most recent / most relevant)
    p = found[-1]["payload"]
    for k in p.keys():
        show(et, k, p)
