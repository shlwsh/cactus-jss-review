"""CLI wrapper for the read-only evaluator-only replay planner."""

from __future__ import annotations

import json
from pathlib import Path

from cactus.evaluation.replay import execute_replay, write_replay_plan

def plan_replay(source_runs: Path, output: Path, *, dual_lens: bool = False) -> dict[str, object]:
    plan = write_replay_plan(source_runs, output, dual_lens=dual_lens)
    return {key: plan[key] for key in ("bundles", "ready", "pending_evidence", "status")}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("source_runs", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--dual-lens", action="store_true", help="record dual-lens replay metadata")
    parser.add_argument("--execute", action="store_true", help="execute official evaluator only against sealed predictions")
    parser.add_argument("--dataset", type=Path, help="local evaluator dataset JSON/JSONL; required with --execute")
    parser.add_argument("--contract", type=Path, help="digest-pinned contract; required with --execute")
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--limit", type=int)
    parser.add_argument("--timeout", type=int, default=1800)
    args = parser.parse_args()
    if args.execute:
        if args.dataset is None or args.contract is None:
            parser.error("--dataset and --contract are required with --execute")
        result = execute_replay(
            args.source_runs,
            args.output,
            dataset_path=args.dataset,
            contract_path=args.contract,
            project_root=args.project_root,
            limit=args.limit,
            timeout=args.timeout,
        )
    else:
        result = plan_replay(args.source_runs, args.output, dual_lens=args.dual_lens)
    print(json.dumps(result, ensure_ascii=False))
