"""Get the SWE-bench patch for astropy-12907."""
import json
import sys
from pathlib import Path

target_id = sys.argv[1] if len(sys.argv) > 1 else "astropy__astropy-12907"
for line in Path("json/cactus_tasks_inference_safe.jsonl").read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    task = json.loads(line)
    if task.get("instance_id") == target_id:
        print(f"instance_id: {task.get('instance_id')}")
        print(f"base_commit: {task.get('base_commit')}")
        print(f"FAIL_TO_PASS: {task.get('FAIL_TO_PASS')}")
        print(f"PASS_TO_PASS: {task.get('PASS_TO_PASS')}")
        print()
        print("--- patch ---")
        print(task.get("patch", ""))
        print()
        print("--- test_patch ---")
        print(task.get("test_patch", ""))
        break
