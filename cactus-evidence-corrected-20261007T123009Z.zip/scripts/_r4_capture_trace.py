"""Capture a clean predict trace for R4-13033 using the fixed working tree
predict script. Reproduces the r4_v12 conditions but uses the current code.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

REPO_CACHE = ROOT / "experiments" / "repo_cache"
SAFE_NAME = "astropy__astropy"
BASE_COMMIT = "298ccb478e6bf092953bca67a3d29dc6c35f6752"
TASK_ID = "astropy__astropy-13033"

mirror = REPO_CACHE / f"{SAFE_NAME}.git"
workspace = Path(tempfile.mkdtemp(prefix="r4_fix_"))
checkout = workspace / "repository"

print(f"=== R4-13033 Predict Trace (fixed) ===")
print(f"workspace: {workspace}")

print("\n[1] Cloning base commit...")
subprocess.run(
    ["git", "clone", "--no-checkout", str(mirror), str(checkout)],
    cwd=str(workspace), check=True, capture_output=True,
)
subprocess.run(
    ["git", "-C", str(checkout), "checkout", "--detach", BASE_COMMIT],
    cwd=str(workspace), check=True, capture_output=True,
)
head = subprocess.run(
    ["git", "-C", str(checkout), "rev-parse", "HEAD"],
    cwd=str(workspace), capture_output=True, text=True,
).stdout.strip()
print(f"   HEAD: {head}")

import re
ENV_FILE = ROOT / "docs" / "llm" / ".env"
_env_text = ENV_FILE.read_text(encoding="utf-8")
_match = re.search(r"^CACTUS_LITELLM_API_KEY=(.*)$", _env_text, re.MULTILINE)
api_key = _match.group(1).strip().strip('"').strip("'") if _match else ""
if len(api_key) < 16:
    raise SystemExit(f"env API key looks invalid (len={len(api_key)}); aborting")

print("\n[2] Running predict subprocess (fixed working tree)...")
predict_log = workspace / "predict.stderr.log"
cmd = [
    str(ROOT / ".venv" / "Scripts" / "python.exe"),
    str(ROOT / "scripts" / "cactus_swebench_predict.py"),
    "--tasks", str(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"),
    "--task-id", TASK_ID,
    "--repo-root", str(checkout),
    "--model-config", str(ROOT / "configs" / "models" / "litellm_local_nothink_v7.json"),
    "--output", str(workspace / "prediction.jsonl"),
    "--budget", "12000",
    "--request-timeout-sec", "900",
    "--variant", "cactus_full",
    "--trace", str(workspace / "trace.jsonl"),
]
env = {**os.environ, "PYTHONPATH": "scripts;.", "CACTUS_LITELLM_API_KEY": api_key}
proc = subprocess.run(
    cmd, cwd=str(ROOT), env=env,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    text=True, timeout=900,
)
print(f"   exit={proc.returncode}")

(workspace / "predict.stderr.log").write_text(proc.stderr, encoding="utf-8")
(workspace / "predict.stdout.log").write_text(proc.stdout, encoding="utf-8")

# Print key diagnostics
print(f"\n   stderr [statement_edit] lines:")
for line in proc.stderr.splitlines():
    if "[statement_edit" in line:
        print(f"     {line}")

print(f"\n   stderr last 500 chars:\n{proc.stderr[-500:]}")

print("\n[3] Reading prediction...")
pred_path = workspace / "prediction.jsonl"
if not pred_path.is_file():
    print("FAIL: prediction.jsonl not produced")
    sys.exit(1)

with pred_path.open(encoding="utf-8") as fh:
    prediction = json.loads(fh.readline())
print(f"   patch length: {len(prediction['model_patch'])} chars")
patch_sha = hashlib.sha256(prediction['model_patch'].encode('utf-8')).hexdigest()
print(f"   patch SHA256: {patch_sha}")

print("\n[4] git apply --check ...")
check = subprocess.run(
    ["git", "apply", "--check", "--whitespace=nowarn"],
    cwd=str(checkout), input=prediction["model_patch"].encode("utf-8"),
    capture_output=True,
)
print(f"   exit code: {check.returncode}")
if check.returncode != 0:
    print(f"   stderr: {check.stderr.decode('utf-8')}")

print(f"\n=== Run workspace preserved at: {workspace} ===")
print(f"=== Patch SHA256: {patch_sha} ===")
print(f"=== Next: docker run for SWE-bench evaluation (currently docker daemon 500 error) ===")