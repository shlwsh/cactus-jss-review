"""Verify 卡点2: all files ready, then run preflight G0-G2."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import os
from pathlib import Path

ROOT = Path(".")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    plan = ROOT / "experiments/plans/C1_primary_pairs_20260925_R2.json"
    plan_ex = ROOT / "experiments/plans/C1_primary_pairs_20260925_R2.json.execution.json"
    contract = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
    auth = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.session_authorization.json"
    snap = ROOT / "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json"

    files = [plan, plan_ex, contract, auth, snap]
    print("=== file existence ===")
    all_ok = True
    for f in files:
        exists = f.is_file()
        size = f.stat().st_size if exists else 0
        s = sha256(f)[:16] + "..." if exists else "N/A"
        status = "OK" if exists else "MISSING"
        if not exists:
            all_ok = False
        print(f"  {status} {f} ({size}B) {s}")

    if not all_ok:
        print("FATAL: some files missing")
        return 1

    c = json.loads(contract.read_text(encoding="utf-8"))
    a = json.loads(auth.read_text(encoding="utf-8"))
    pe = json.loads(plan_ex.read_text(encoding="utf-8"))

    print()
    print("=== contract key fields ===")
    print(f"  experiment_id:    {c['experiment_id']}")
    print(f"  purpose:          {c['execution']['purpose']}")
    print(f"  tier:             {c['tier']}")
    print(f"  campaign_id:      {c['execution']['campaign_id']}")
    print(f"  task_count:       {c['workload']['task_count']}")
    print(f"  task_ids:         {c['workload']['task_ids']}")
    print(f"  pair_plan_sha256: {c['workload']['pair_plan_sha256']}")
    print(f"  env_snap:         {c['execution']['environment_snapshot_path']}")
    print(f"  env_snap_sha256:  {c['execution']['environment_snapshot_sha256']}")
    print(f"  kpi3 step_b:      {c['_metadata']['r2_kpi3_progress']['step_b_owner_dacl_apply']}")
    print(f"  kpi3 step_d:      {c['_metadata']['r2_kpi3_progress']['step_d_owner_dacl_apply_then_agent_re_capture']}")
    print(f"  kpi3 step_e:      {c['_metadata']['r2_kpi3_progress']['step_e_contract_update_after_step_d']}")

    print()
    print("=== auth key fields ===")
    print(f"  schema_version:       {a['schema_version']}")
    print(f"  authorization_type:   {a['authorization_type']}")
    print(f"  tier:                 {a.get('tier', '(v1.0 — no tier field)')}")
    print(f"  experiment_id:        {a['experiment_id']}")
    print(f"  status:               {a['status']}")
    print(f"  approved_by:          {a['approved_by']}")
    print(f"  approved_at:          {a['approved_at']}")
    print(f"  contract_sha256:      {a['contract_sha256']}")
    print(f"  linked_snap:          {a['_metadata']['linked_environment_snapshot_path']}")
    print(f"  dacl_apply_verified:  {a['_metadata']['dacl_apply_verified']}")

    print()
    print("=== plan execution sidecar ===")
    print(f"  campaign_id:    {pe['campaign_id']}")
    print(f"  status:         {pe.get('status', '?')}")
    print(f"  expected_runs:  {pe.get('_metadata', {}).get('expected_run_count', '?')}")
    print(f"  plan_sha256:    {pe.get('plan_sha256', pe.get('_metadata', {}).get('plan_sha256', '?'))}")

    # Verify SHA chain
    print()
    print("=== SHA chain ===")
    contract_sha = sha256(contract)
    snap_sha = sha256(snap)
    expected_snap = c["execution"]["environment_snapshot_sha256"]
    expected_auth_contract = a["contract_sha256"]

    from cactus.governance.canonical import canonical_json
    canonical_sha = hashlib.sha256(canonical_json(c).encode("utf-8")).hexdigest()

    # linked_contract_sha256 = contract body SHA (not canonical)
    linked_contract = a["_metadata"].get("linked_contract_sha256", "")
    print(f"  contract body SHA:        {contract_sha}")
    print(f"  auth linked_contract:     {linked_contract}")
    print(f"  contract SHA match:       {contract_sha == linked_contract}")
    print(f"  canonical_json(contract):  {canonical_sha}")
    print(f"  auth.contract_sha256:     {expected_auth_contract}")
    print(f"  canonical match:          {canonical_sha == expected_auth_contract}")
    print(f"  snapshot SHA:             {snap_sha}")
    print(f"  contract references snap: {expected_snap}")
    print(f"  snapshot match:           {snap_sha == expected_snap}")

    all_ok = (
        contract_sha == linked_contract
        and canonical_sha == expected_auth_contract
        and snap_sha == expected_snap
    )

    if not all_ok:
        print("FATAL: SHA chain broken")
        return 1

    print()
    print("=== formal_execution_errors ===")
    from cactus.runner.formal import formal_execution_errors

    approval_text = auth.read_text(encoding="utf-8")
    with tempfile.NamedTemporaryFile(
        "w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        f.write(approval_text)
        tmp_path = f.name
    try:
        errors = formal_execution_errors(
            c, project_root=ROOT, approval_path=Path(tmp_path)
        )
        if not errors:
            print("  PASS — no formal execution errors")
        else:
            for e in errors:
                print(f"  FAIL {e}")
            return 1
    finally:
        os.unlink(tmp_path)

    print()
    print("=== preflight (G0-level) ===")
    from cactus.runner.preflight import preflight

    # paper_supporting tier: require_clean_tree=False (AUTO_COMMIT)
    errors = preflight(c, project_root=ROOT, require_clean_tree=False)
    if not errors:
        print("  preflight PASS — no errors")
    else:
        for e in errors:
            print(f"  preflight FAIL: {e}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
