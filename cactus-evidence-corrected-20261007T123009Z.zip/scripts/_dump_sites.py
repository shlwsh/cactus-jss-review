import json
import re

paths = [
    'e:/work/p5-acm/acm/experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/django__django-11910/events.jsonl',
    'e:/work/p5-acm/acm/experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/django__django-12125/events.jsonl',
]

pat = re.compile(r"SITES:\s*S-[a-f0-9]+(?:,\s*S-[a-f0-9]+)*")

for path in paths:
    print('=== ', path, ' ===')
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                e = json.loads(line)
                t = e.get('type', '')
                seq = e.get('seq', 0)
                p = e.get('payload', {})
                txt = json.dumps(p)
                for m in pat.findall(txt):
                    print(f'seq={seq} type={t} {m[:240]}')
            except Exception:
                pass