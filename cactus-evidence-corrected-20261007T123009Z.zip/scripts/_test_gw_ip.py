"""Test LiteLLM gateway at correct IP."""
import urllib.request
import json

url = "http://172.19.50.70:4000/v1/models"
headers = {"Authorization": "Bearer sk-dgx-local-2026"}

try:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
        models = data.get("data", [])
        print(f"OK: {len(models)} models available")
        for m in models[:5]:
            print(f"  - {m.get('id', '?')}")
except Exception as e:
    print(f"FAIL: {type(e).__name__}: {e}")
