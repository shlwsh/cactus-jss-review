#!/usr/bin/env python3
"""Pipelined 3-task SWE-bench eval runner.

Strategy (Owner 决策 2026-09-20 12:20 UTC+8):
- Task1 runs in foreground; during Task1, Task2 image is pulled + warmed up.
- Task1 completes → Task2 eval immediately.
- During Task2, Task3 image is pulled + warmed up.
- Task2 completes → Task3 eval.
- After each task: archive bundle sealed → rmi image.

This achieves maximum pipeline utilization while respecting:
  1. Task order (sequential dependency for the actual eval)
  2. Per-task image lifecycle (rmi after each task, but keep pre-warmed for next)
  3. Experiment data governance (bundle sealed per task, immutable)
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]  # .../acm/scripts/run_3_task_pipelined.py → .../acm
CONTRACT = REPO / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V2-OWNER-20260919.json"
APPROVAL = REPO / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V2-OWNER-20260919.session_authorization.json"
TASK_MANIFEST = REPO / "json/cactus_tasks_inference_safe.jsonl"
MODEL_CONFIG = REPO / "configs/models/litellm_local.json"
RUNNER = REPO / "scripts/run_swebench_campaign.py"
OUTPUT_ROOT = REPO / "experiments/runs"
REPO_CACHE = REPO / "experiments/repo_cache"

src_path = str(REPO / "src")
if src_path not in sys.path:
    sys.path.insert(0, src_path)
os.environ["PYTHONPATH"] = f"{src_path};{REPO};" + os.environ.get("PYTHONPATH", "")

TASKS = ["astropy__astropy-12907", "astropy__astropy-13033", "astropy__astropy-13236"]

LOCAL_DATASET = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
DATASET = str(LOCAL_DATASET) if LOCAL_DATASET.exists() else "SWE-bench/SWE-bench_Verified"


def _docker_pull(image_ref: str, timeout_sec: int = 600) -> tuple[bool, bool]:
    """Pull with --platform linux/amd64. Returns (success, was_cached)."""
    check = subprocess.run(
        ["docker", "image", "inspect", image_ref, "--format={{.Id}}"],
        capture_output=True, text=True, timeout=10, check=False,
    )
    was_cached = check.returncode == 0
    if was_cached:
        print(f"[PULL-CACHED] {image_ref}", flush=True)
        return True, True

    cmd = ["docker", "pull", "--platform", "linux/amd64", image_ref]
    print(f"[PULL-NEW] {' '.join(cmd)}", flush=True)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_sec)
    print(result.stdout[-500:] if result.stdout else "")
    if result.returncode != 0:
        print(f"[PULL-FAIL] {result.stderr.strip()[:500]}", flush=True)
        return False, False
    print(f"[PULL-OK] {image_ref} (newly downloaded)", flush=True)
    return True, False


def _docker_warmup(image_ref: str, task_id: str) -> bool:
    """Trigger QEMU JIT cache for the image."""
    body = (
        "import sys, platform\n"
        "TASK_ID = 'TASK_PLACEHOLDER'\n"
        "print('warmup ok task=' + TASK_ID + ' py=' + str(sys.version_info[:3]) + ' arch=' + platform.machine(), flush=True)\n"
    ).replace("TASK_PLACEHOLDER", task_id)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(body)
        script_path = f.name
    cmd = ["docker", "run", "--rm", "--platform", "linux/amd64",
           "-v", f"{script_path}:/warmup.py:ro",
           image_ref, "python", "/warmup.py"]
    print(f"[WARMUP] {' '.join(cmd)}", flush=True)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        print(f"[WARMUP] exit={result.returncode} stdout={result.stdout.strip()}")
        if result.returncode != 0:
            print(f"[WARMUP-STDERR] {result.stderr.strip()[:300]}")
            return False
        return True
    except subprocess.TimeoutExpired:
        print("[WARMUP-TIMEOUT]")
        return False
    finally:
        try:
            os.unlink(script_path)
        except OSError:
            pass


def _docker_rmi(image_ref: str) -> None:
    """Force-remove image (best-effort)."""
    cmd = ["docker", "rmi", "--force", image_ref]
    print(f"[RMI] {' '.join(cmd)}", flush=True)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        print("[RMI-TIMEOUT]")
        return
    print(f"[RMI] exit={result.returncode}")
    if result.stdout.strip():
        print(f"[RMI-STDOUT] {result.stdout.strip()[:200]}")


def _verify_digest(image_ref: str, expected: str) -> bool:
    """Verify RepoDigests match contract digest."""
    result = subprocess.run(
        ["docker", "image", "inspect", image_ref, "--format={{json .RepoDigests}}"],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        print(f"[DIGEST-CHECK-FAIL] {result.stderr.strip()[:200]}")
        return False
    digests = json.loads(result.stdout) if result.stdout.strip() else []
    expected_no_prefix = expected.replace("sha256:", "")
    for d in digests:
        if d.endswith(f"@sha256:{expected_no_prefix}"):
            print(f"[DIGEST-MATCH] {expected}")
            return True
    print(f"[DIGEST-MISMATCH] expected={expected} got={digests}")
    return False


def _lookup_image(contract: dict, task_id: str) -> tuple[str, str] | None:
    tasks = [json.loads(l) for l in open(TASK_MANIFEST)]
    task_list = [t["task_id"] for t in tasks]
    if task_id not in task_list:
        return None
    index = task_list.index(task_id)
    eval_key = f"eval_{index + 1:03d}"
    entry = contract["images"].get(eval_key)
    if not entry:
        return None
    repository = entry["repository"]
    image_ref = f"{repository}:latest"
    digest = entry["digest"]
    return image_ref, digest


def _resolve_swebench_dataset_alias(name: str) -> str:
    """Resolve SWE-bench CLI-style aliases to full HuggingFace dataset names.

    Mirrors the alias resolution in swebench.cli so that harness calls
    receive the same dataset name the official CLI uses.
    """
    lower = name.lower()
    if lower in {"swe-bench", "swebench", "swe_bench", "full"}:
        return "SWE-bench/SWE-bench"
    if lower in {"swe-bench-lite", "swebench-lite", "swe_bench_lite",
                 "swe-bench_lite", "lite"}:
        return "SWE-bench/SWE-bench_Lite"
    if lower in {"swe-bench_verified", "swebench_verified", "verified"}:
        # NOTE: 'verified' alias → SWE-bench/SWE-bench_Verified (has 'image' field).
        # The old 'SWE-bench/SWE-bench_Verified' does NOT have 'image' field,
        # which causes KeyError: 'image' in swebench harness make_test_spec().
        return "SWE-bench/SWE-bench_Verified"
    if lower in {"swe-bench_multilingual", "swebench_multilingual", "multilingual"}:
        return "SWE-bench/SWE-bench_Multilingual"
    if lower in {"swe-bench_multimodal", "swebench_multimodal", "multimodal"}:
        return "SWE-bench/SWE-bench_Multimodal"
    # Already a full HF path or local file; pass through unchanged
    return name
    tasks = [json.loads(l) for l in open(TASK_MANIFEST)]
    task_list = [t["task_id"] for t in tasks]
    if task_id not in task_list:
        return None
    index = task_list.index(task_id)
    eval_key = f"eval_{index + 1:03d}"
    entry = contract["images"].get(eval_key)
    if not entry:
        return None
    repository = entry["repository"]
    image_ref = f"{repository}:latest"
    digest = entry["digest"]
    return image_ref, digest


def prewarm_task(contract: dict, task_id: str) -> bool:
    """Pull + warmup one task's image. Called in background while previous task runs."""
    lookup = _lookup_image(contract, task_id)
    if not lookup:
        print(f"[PREWARM] NOT-IN-CONTRACT: {task_id}")
        return False
    image_ref, expected_digest = lookup
    print(f"[PREWARM] ========== {task_id} ==========", flush=True)
    print(f"  image_ref: {image_ref}", flush=True)

    ok, was_cached = _docker_pull(image_ref)
    if not ok:
        return False

    if not was_cached:
        if not _verify_digest(image_ref, expected_digest):
            _docker_rmi(image_ref)
            return False

    if not _docker_warmup(image_ref, task_id):
        if not was_cached:
            _docker_rmi(image_ref)
        return False

    print(f"[PREWARM-OK] {task_id} (image ready)", flush=True)
    return True


def run_task_eval(task_id: str, contract: dict) -> tuple[bool, str]:
    """Run one task's eval via run_swebench_campaign.py. Returns (ok, run_id)."""
    lookup = _lookup_image(contract, task_id)
    if not lookup:
        print(f"[EVAL] NOT-IN-CONTRACT: {task_id}")
        return False, ""
    image_ref, expected_digest = lookup

    print(f"\n========== EVAL: {task_id} ==========", flush=True)
    print(f"  image_ref: {image_ref}", flush=True)

    # Check image exists (should already be pre-warmed or local)
    ok, was_cached = _docker_pull(image_ref)
    if not ok:
        return False, ""
    if not was_cached:
        if not _verify_digest(image_ref, expected_digest):
            _docker_rmi(image_ref)
            return False, ""
        if not _docker_warmup(image_ref, task_id):
            _docker_rmi(image_ref)
            return False, ""

    cmd = [
        sys.executable, str(RUNNER),
        "--contract", str(CONTRACT),
        "--approval", str(APPROVAL),
        "--model-config", str(MODEL_CONFIG),
        "--tasks", str(TASK_MANIFEST),
        "--output-root", str(OUTPUT_ROOT),
        "--repo-cache", str(REPO_CACHE),
        "--evaluator-dataset", DATASET,
        "--project-root", str(REPO),
        "--task-id", task_id,
    ]
    print(f"[EVAL-CMD] {' '.join(cmd)}", flush=True)
    started = time.monotonic()
    result = subprocess.run(cmd, cwd=REPO, env=os.environ.copy())
    elapsed = time.monotonic() - started
    print(f"[EVAL-EXIT] exit={result.returncode} elapsed={elapsed:.1f}s", flush=True)

    # Find the RUN bundle for this task
    latest_runs = sorted(OUTPUT_ROOT.glob("RUN-*"), key=lambda p: p.stat().st_mtime)
    if not latest_runs:
        print("[EVAL] no RUN-* directory created")
        return False, ""

    # Find the most recent RUN whose run_manifest has this task_id
    run_id = ""
    manifest_data = None
    for run_dir in reversed(latest_runs):
        manifest_path = run_dir / "run_manifest.json"
        if not manifest_path.exists():
            continue
        try:
            md = json.loads(manifest_path.read_text())
            # Check if this manifest corresponds to our task
            cmd_in_manifest = md.get("command", [])
            if task_id in cmd_in_manifest or any(task_id in str(a) for a in md.get("outputs", [])):
                run_id = run_dir.name
                manifest_data = md
                break
        except (OSError, json.JSONDecodeError):
            continue

    if not manifest_data:
        print(f"[EVAL] no run_manifest.json found for {task_id}")
        return False, ""

    status = manifest_data.get("status", "unknown")
    print(f"[EVAL-BUNDLE] {run_id} status={status}")

    # RMI image (was_cached means it was already local before this pipeline)
    # We rmi if newly downloaded, but since we prewarmed, it was already local
    # Only rmi if this was a fresh pull done during eval (not prewarmed)
    # Simple rule: always rmi after each task to keep pipeline clean
    _docker_rmi(image_ref)

    ok = result.returncode == 0 and status == "completed"
    return ok, run_id


def wait_for_task(pid: int, timeout_sec: int = 3600) -> int | None:
    """Poll a process until it exits. Returns exit code, or None on timeout."""
    start = time.monotonic()
    while time.monotonic() - start < timeout_sec:
        result = subprocess.run(["ps", "-p", str(pid)], capture_output=True, timeout=5)
        if result.returncode != 0:
            # Process exited; get exit code
            proc_result = subprocess.run(["ps", "-p", str(pid), "-o", "pid,stat"],
                                        capture_output=True, text=True, check=False)
            # Process no longer in ps; try wait
            return None  # caller should use pid directly
        time.sleep(5)
    return None


def main() -> int:
    contract = json.loads(CONTRACT.read_text())

    print(f"[PIPELINE] 3 tasks: {TASKS}", flush=True)

    results: dict[str, tuple[bool, str]] = {}
    prewarm_pids: dict[str, int] = {}  # task_id -> pid of background prewarm

    # Phase: Prewarm Task 2 while Task 1 starts
    print(f"[PHASE] Starting Task 1 eval + prewarming Task 2 in background", flush=True)
    eval1_proc = subprocess.Popen(
        [sys.executable, str(RUNNER),
         "--contract", str(CONTRACT), "--approval", str(APPROVAL),
         "--model-config", str(MODEL_CONFIG), "--tasks", str(TASK_MANIFEST),
         "--output-root", str(OUTPUT_ROOT), "--repo-cache", str(REPO_CACHE),
         "--evaluator-dataset", DATASET,
         "--project-root", str(REPO), "--task-id", TASKS[0]],
        cwd=REPO, env=os.environ.copy(),
    )
    eval1_pid = eval1_proc.pid

    # Prewarm Task 2 in background while Task 1 runs
    # NOTE: evaluator-dataset alias 'verified' is resolved by the harness to
    # 'SWE-bench/SWE-bench_Verified' (which has the 'image' field).
    # The old 'princeton-nlp/SWE-bench_Verified' lacks 'image' and
    # causes KeyError: 'image' in make_test_spec().
    pw2 = subprocess.Popen(
        [sys.executable, __file__, "--prewarm-only", "--task-id", TASKS[1]],
        cwd=REPO, env=os.environ.copy(),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    prewarm_pids[TASKS[1]] = pw2.pid
    print(f"[PREWARM] Task2 prewarm started pid={pw2.pid}", flush=True)

    # Wait for Task 1 to complete
    print(f"[WATCH] Waiting for Task 1 (pid={eval1_pid})...", flush=True)
    eval1_returncode = eval1_proc.wait()

    # Poll prewarm task 2 result
    pw2_output, _ = pw2.communicate(timeout=30)
    print(f"[PREWARM2] output:\n{pw2_output[-500:]}", flush=True)
    pw2_ok = pw2.returncode == 0
    print(f"[PREWARM2] done: {'OK' if pw2_ok else 'FAIL'} exit={pw2.returncode}", flush=True)

    if eval1_returncode != 0:
        print(f"[STOP] Task 1 process exited with returncode {eval1_returncode}. Stopping pipeline.", flush=True)
        return 1

    latest_runs = sorted(OUTPUT_ROOT.glob("RUN-*"), key=lambda p: p.stat().st_mtime)
    t1_ok = False
    t1_run_id = ""
    for run_dir in reversed(latest_runs):
        try:
            md = json.loads((run_dir / "run_manifest.json").read_text())
        except (OSError, json.JSONDecodeError):
            continue
        cmd = md.get("command", [])
        if TASKS[0] in cmd:
            t1_ok = md.get("status") == "completed"
            t1_run_id = run_dir.name
            break
    print(f"\n========== TASK 1 RESULT: {'COMPLETED' if t1_ok else 'FAILED'} ({t1_run_id}) ==========\n", flush=True)
    results[TASKS[0]] = (t1_ok, t1_run_id)

    if not t1_ok:
        print("[STOP] Task 1 failed. Per Owner policy: stopping pipeline.", flush=True)
        return 1

    # Phase: Run Task 2 eval + prewarm Task 3
    print(f"[PHASE] Starting Task 2 eval + prewarming Task 3 in background", flush=True)
    eval2_proc = subprocess.Popen(
        [sys.executable, str(RUNNER),
         "--contract", str(CONTRACT), "--approval", str(APPROVAL),
         "--model-config", str(MODEL_CONFIG), "--tasks", str(TASK_MANIFEST),
         "--output-root", str(OUTPUT_ROOT), "--repo-cache", str(REPO_CACHE),
         "--evaluator-dataset", DATASET,
         "--project-root", str(REPO), "--task-id", TASKS[1]],
        cwd=REPO, env=os.environ.copy(),
    )
    eval2_pid = eval2_proc.pid

    # Prewarm Task 3 in background
    pw3 = subprocess.Popen(
        [sys.executable, __file__, "--prewarm-only", "--task-id", TASKS[2]],
        cwd=REPO, env=os.environ.copy(),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    prewarm_pids[TASKS[2]] = pw3.pid
    print(f"[PREWARM] Task3 prewarm started pid={pw3.pid}", flush=True)

    # Wait for Task 2
    eval2_returncode = eval2_proc.wait()

    pw3_output, _ = pw3.communicate(timeout=30)
    print(f"[PREWARM3] output:\n{pw3_output[-500:]}", flush=True)
    pw3_ok = pw3.returncode == 0

    if eval2_returncode != 0:
        print(f"[STOP] Task 2 process exited with returncode {eval2_returncode}. Stopping pipeline.", flush=True)
        return 1

    # Find Task 2 result by task_id in manifest command
    latest_runs2 = sorted(OUTPUT_ROOT.glob("RUN-*"), key=lambda p: p.stat().st_mtime)
    t2_ok = False
    t2_run_id = ""
    for run_dir in reversed(latest_runs2):
        try:
            md = json.loads((run_dir / "run_manifest.json").read_text())
        except (OSError, json.JSONDecodeError):
            continue
        cmd = md.get("command", [])
        if TASKS[1] in cmd:
            t2_ok = md.get("status") == "completed"
            t2_run_id = run_dir.name
            break
    print(f"\n========== TASK 2 RESULT: {'COMPLETED' if t2_ok else 'FAILED'} ({t2_run_id}) ==========\n", flush=True)
    results[TASKS[1]] = (t2_ok, t2_run_id)

    if not t2_ok:
        print("[STOP] Task 2 failed. Per Owner policy: stopping pipeline.", flush=True)
        return 1

    # Phase: Run Task 3 eval
    print(f"[PHASE] Starting Task 3 eval", flush=True)
    t3_ok, t3_run_id = run_task_eval(TASKS[2], contract)
    print(f"\n========== TASK 3 RESULT: {'COMPLETED' if t3_ok else 'FAILED'} ({t3_run_id}) ==========\n", flush=True)
    results[TASKS[2]] = (t3_ok, t3_run_id)

    # Summary
    print("\n" + "=" * 60)
    print("PIPELINE SUMMARY")
    print("=" * 60)
    for t, (ok, run_id) in results.items():
        print(f"  {t}: {'OK' if ok else 'FAIL'}  bundle={run_id}")
    print(f"  completed: {sum(1 for o, _ in results.values() if o)}/{len(results)}")
    return 0 if all(ok for ok, _ in results.values()) else 1


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--prewarm-only", action="store_true")
    parser.add_argument("--task-id", choices=TASKS)
    args = parser.parse_args()
    if args.prewarm_only and args.task_id:
        contract = json.loads(CONTRACT.read_text())
        sys.exit(0 if prewarm_task(contract, args.task_id) else 1)
    else:
        sys.exit(main())
