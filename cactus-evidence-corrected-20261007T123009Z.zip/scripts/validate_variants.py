"""Validate variant configurations against the frozen experiment contract."""

from __future__ import annotations

import json
from pathlib import Path


REQUIRED = {"full_context", "cactus_full", "no_symbol_graph", "no_budget_controller", "no_failure_recovery"}


def validate(config_dir: Path) -> list[str]:
    errors = []
    files = {path.stem: json.loads(path.read_text(encoding="utf-8")) for path in config_dir.glob("*.json")}
    missing = REQUIRED - set(files)
    errors.extend(f"missing variant: {name}" for name in sorted(missing))
    for name, config in files.items():
        if config.get("variant") != name:
            errors.append(f"variant name mismatch: {name}")
        context = config.get("context", {})
        for field in ("selector", "symbol_graph", "budget_controller", "failure_recovery"):
            if field not in context:
                errors.append(f"{name}.context missing {field}")
    return errors


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("config_dir", type=Path)
    args = parser.parse_args()
    errors = validate(args.config_dir)
    print(json.dumps({"status": "pass" if not errors else "fail", "errors": errors}))
    raise SystemExit(bool(errors))
