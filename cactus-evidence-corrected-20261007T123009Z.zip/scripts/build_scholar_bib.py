"""Build a reviewed BibTeX supplement from harvested arXiv metadata."""
from __future__ import annotations

import json
import re
import csv
from pathlib import Path

SELECTED = [
    "2303.08774", "2210.03629", "2201.11903", "2305.10601", "2302.04761",
    "2307.16789", "2207.01780", "2109.00859", "2309.12499", "2404.05427",
    "2403.08604", "2305.16504", "2206.14858", "2304.12244", "2307.13854",
    "2309.15237", "2311.09721", "2310.03714", "2401.13178", "2402.17553",
    "2401.13649", "2305.19308", "2312.10665", "2405.12132", "2509.16941",
    "2602.09540",
]


def key(row: dict) -> str:
    return "arxiv" + row["arxiv_id"].replace(".", "")


def clean(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    source = root / "paper" / "data" / "scholar" / "arxiv_metadata.json"
    data = json.loads(source.read_text(encoding="utf-8"))
    by_id = {row["arxiv_id"]: row for row in data["records"]}
    missing = [arxiv_id for arxiv_id in SELECTED if arxiv_id not in by_id or by_id[arxiv_id]["status"] != "verified"]
    if missing:
        raise SystemExit(f"unverified selected records: {missing}")
    entries = []
    manifest = []
    for arxiv_id in SELECTED:
        row = by_id[arxiv_id]
        year = row["date"][:4]
        authors = " and ".join(clean(a) for a in row["authors"])
        entries.append(
            "@article{{{key},\n  author = {{{authors}}},\n  title = {{{title}}},\n  journal = {{arXiv preprint arXiv:{arxiv_id}}},\n  year = {{{year}}},\n  url = {{{url}}},\n  doi = {{10.48550/arXiv.{arxiv_id}}}\n}}\n".format(
                key=key(row), authors=authors, title=clean(row["title"]), arxiv_id=arxiv_id, year=year, url=row["url"]
            )
        )
        manifest.append({"citation_key": key(row), "arxiv_id": arxiv_id, "title": row["title"], "year": year, "url": row["url"], "metadata_status": "verified", "pdf_archived": False})
    out = root / "paper" / "data" / "scholar"
    (root / "paper" / "references_scholar.bib").write_text("\n".join(entries), encoding="utf-8")
    (out / "cited_papers_manifest.json").write_text(json.dumps({"schema_version": "1.0", "source": "official arXiv abstract pages", "records": manifest}, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "failed_downloads.json").write_text(json.dumps({"schema_version": "1.0", "records": [], "note": "Metadata-only intake; PDF download deferred until licensing and venue requirements are confirmed."}, ensure_ascii=False, indent=2), encoding="utf-8")
    matrix = root / "paper" / "data" / "related_work_matrix.csv"
    with matrix.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["paper_id", "title", "year", "topic", "primary_source", "verified", "status", "relation_to_cactus"])
        fixed = [
            ("swebenchverified", "SWE-bench Verified", "2024", "benchmark dataset", "https://www.swebench.com/", "benchmark task provenance"),
            ("acmart", "ACM Master Article Template", "2026", "publication format", "https://www.acm.org/publications/proceedings-template", "submission format"),
            ("swebench", "SWE-bench: Can Language Models Resolve Real-World GitHub Issues?", "2023", "repository-level evaluation", "https://arxiv.org/abs/2310.06770", "benchmark task and evaluator context"),
            ("reacc", "ReACC: A Retrieval-Augmented Code Completion Framework", "2022", "code retrieval", "https://arxiv.org/abs/2203.07722", "retrieval baseline motivation"),
            ("repocoder", "RepoCoder: Repository-Level Code Completion Through Iterative Retrieval and Generation", "2023", "repository context", "https://arxiv.org/abs/2303.12570", "iterative retrieval baseline motivation"),
            ("sweagent", "SWE-agent: Agent-Computer Interfaces Enable Automated Software Engineering", "2024", "software engineering agents", "https://arxiv.org/abs/2405.15793", "agent interaction baseline"),
            ("agentless", "Agentless: Demystifying LLM-based Software Engineering Agents", "2024", "software engineering agents", "https://arxiv.org/abs/2407.01489", "lightweight pipeline comparator"),
            ("openhands", "OpenHands: An Open Platform for AI Software Developers as Generalist Agents", "2024", "software engineering agents", "https://arxiv.org/abs/2407.16741", "cross-agent generalization target"),
            ("agentbench", "AgentBench: Evaluating LLMs as Agents", "2023", "agent evaluation", "https://arxiv.org/abs/2308.03688", "failure-aware evaluation motivation"),
        ]
        for paper_id, title, year, topic, url, relation in fixed:
            writer.writerow([paper_id, title, year, topic, url, "yes", "verified", relation])
        for arxiv_id in SELECTED:
            row = by_id[arxiv_id]
            writer.writerow([key(row), row["title"], row["date"][:4], "LLM/code/agent evaluation", row["url"], "yes", "verified", "comparison dimension or evaluation precedent"])
    print(json.dumps({"selected": len(entries), "bib": str(root / "paper" / "references_scholar.bib")}))


if __name__ == "__main__":
    main()
