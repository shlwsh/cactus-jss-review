"""Acquire and attest an official SWE-bench JSON task file.

The command is opt-in and never runs tasks.  It requires a source URL, an
expected SHA-256 and an explicit license note; an unverified download is
deleted and no manifest is emitted.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def _attestation(url: str, expected_sha256: str, license_name: str, source_version: str, source_format: str, raw_output: Path, manifest_output: Path, task_count: int | None, transport_url: str | None = None, execution_authorized: bool = False) -> None:
    if len(expected_sha256) != 64 or any(c not in "0123456789abcdef" for c in expected_sha256):
        raise ValueError("expected_sha256 must be lowercase SHA-256")
    actual = hashlib.sha256(raw_output.read_bytes()).hexdigest()
    if actual != expected_sha256:
        raise ValueError(f"SHA-256 mismatch: expected {expected_sha256}, got {actual}")
    if source_format == "json":
        parsed = json.loads(raw_output.read_text(encoding="utf-8"))
        if not isinstance(parsed, list) or not parsed:
            raise ValueError("JSON source must be a non-empty array")
        task_count = len(parsed)
    elif source_format == "parquet":
        if not raw_output.read_bytes()[:4] == b"PAR1":
            raise ValueError("Parquet source does not have a PAR1 header")
        if task_count is not None and task_count < 1:
            raise ValueError("task_count must be positive when supplied")
    else:
        raise ValueError("source_format must be json or parquet")
    record = {
        "schema_version": "1.0",
        "benchmark": "SWE-bench",
        "source_url": url,
        "source_version": source_version,
        "license": license_name,
        "sha256": actual,
        "downloaded_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "task_count": task_count,
        "source_format": source_format,
        **({"transport_url": transport_url} if transport_url else {}),
        "raw_path": str(raw_output),
        "public_repo_code": False,
        "execution_authorized": execution_authorized,
    }
    manifest_output.parent.mkdir(parents=True, exist_ok=True)
    manifest_output.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def acquire(url: str, expected_sha256: str, license_name: str, source_version: str, source_format: str, raw_output: Path, manifest_output: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "cactus-benchmark-acquisition/1.0"})
    with urllib.request.urlopen(request, timeout=60) as response:
        payload = response.read()
    raw_output.parent.mkdir(parents=True, exist_ok=True)
    raw_output.write_bytes(payload)
    _attestation(url, expected_sha256, license_name, source_version, source_format, raw_output, manifest_output, None)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--license", required=True)
    parser.add_argument("--version", required=True)
    parser.add_argument("--format", choices=("json", "parquet"), default="json")
    parser.add_argument("--raw-output", type=Path, required=True)
    parser.add_argument("--manifest-output", type=Path, required=True)
    parser.add_argument("--existing", action="store_true", help="attest a pre-downloaded file after SHA-256 verification")
    parser.add_argument("--task-count", type=int)
    parser.add_argument("--transport-url", help="mirror URL used only when the official source was inaccessible")
    parser.add_argument("--execution-authorized", action="store_true", help="record explicit project-owner authorization to execute this frozen source")
    args = parser.parse_args()
    if args.existing:
        _attestation(args.url, args.sha256, args.license, args.version, args.format, args.raw_output, args.manifest_output, args.task_count, args.transport_url, args.execution_authorized)
    else:
        acquire(args.url, args.sha256, args.license, args.version, args.format, args.raw_output, args.manifest_output)
    print(f"PASS acquired and attested {args.raw_output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
