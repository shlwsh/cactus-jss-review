import json
import hashlib
from pathlib import Path

# Update cited_papers_manifest_provenance.json with current input hashes
ROOT = Path('.')
MANIFEST = ROOT / 'paper/data/scholar/cited_papers_manifest.json'
BIB = ROOT / 'paper/references.bib'
TEX = ROOT / 'paper/main.tex'

manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
records = [ROOT / r['file_path'] for r in manifest['records']]

prov_file = MANIFEST.with_name('cited_papers_manifest_provenance.json')
if prov_file.exists():
    prov = json.loads(prov_file.read_text(encoding='utf-8'))
    for inp in prov.get('inputs', []):
        path = Path(inp['path'])
        if path == BIB:
            actual = hashlib.sha256(BIB.read_bytes()).hexdigest()
            if inp['sha256'] != actual:
                print(f'Updating BIB: {inp["sha256"][:16]} -> {actual[:16]}')
                inp['sha256'] = actual
            else:
                print(f'OK BIB')
        elif path == TEX:
            actual = hashlib.sha256(TEX.read_bytes()).hexdigest()
            if inp['sha256'] != actual:
                print(f'Updating TEX: {inp["sha256"][:16]} -> {actual[:16]}')
                inp['sha256'] = actual
            else:
                print(f'OK TEX')
        else:
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if inp['sha256'] != actual:
                print(f'Updating {path}: {inp["sha256"][:16]} -> {actual[:16]}')
                inp['sha256'] = actual
            else:
                print(f'OK {path}')
    prov_file.write_text(json.dumps(prov, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('Provenance updated')
else:
    print('No provenance file found - skipping')
