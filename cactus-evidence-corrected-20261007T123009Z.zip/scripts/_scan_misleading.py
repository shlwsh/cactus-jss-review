"""Find every SWE-bench Verified task whose issue_text classifies as misleading_exception.

Drives the "generalise beyond astropy-13033" check for the
``_misleading_exception_template_patch`` algorithm: if the template is truly
repo-agnostic, it should produce non-trivial patches for *every* task in this
list — not just the one whose gold patch was used to motivate the helper body.

This script does not run the template.  It only enumerates candidates and saves
them as JSON for downstream verification.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT))

spec = importlib.util.spec_from_file_location("cactus_swebench_predict_scan", str(ROOT / "scripts" / "cactus_swebench_predict.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

from cactus.adapters.benchmark import load_manifest  # type: ignore

manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = list(load_manifest(manifest))
print(f"[scan] total tasks in inference-safe manifest: {len(tasks)}", flush=True)

by_archetype: dict[str, list[str]] = {}
for task in tasks:
    archetype = mod._classify_issue_type(task.issue_text or "")
    by_archetype.setdefault(archetype, []).append(task.task_id)

print("\n[scan] archetype distribution:")
for arch, ids in sorted(by_archetype.items(), key=lambda kv: -len(kv[1])):
    print(f"  {arch:30s}: {len(ids)}")
    if len(ids) <= 12:
        print(f"    -> {ids}")
    else:
        print(f"    -> first 5: {ids[:5]}")

print("\n[scan] tasks classified as misleading_exception:")
for tid in by_archetype.get("misleading_exception", []):
    print(f"  - {tid}")

# Save the candidate list for downstream verification.
out = ROOT / "experiments" / "derived" / "misleading_exception_candidates.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(
    json.dumps(
        {"schema_version": "1.0", "archetype": "misleading_exception", "task_ids": by_archetype.get("misleading_exception", [])},
        ensure_ascii=False, indent=2,
    ) + "\n",
    encoding="utf-8",
)
print(f"\n[scan] saved candidate list to {out}")
