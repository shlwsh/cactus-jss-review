"""Decode a CACTUS trace events.jsonl for inspection."""
import json
import sys
from pathlib import Path

trace = Path(sys.argv[1])
events = [json.loads(l) for l in trace.read_text(encoding="utf-8").splitlines() if l.strip()]
print(f"Total events: {len(events)}")
print(f"Unique event types: {sorted({e.get('type','?') for e in events})}")
print()

for i, e in enumerate(events):
    t = e.get("type", "?")
    if t == "model_call":
        p = e.get("payload", {})
        rt = p.get("response_text", "") or ""
        pt = p.get("prompt_text", "") or ""
        print(f"[{i}] model_call")
        print(f"  tokens in={p.get('input_tokens')} out={p.get('output_tokens')}")
        print(f"  prompt_chars={len(pt)} prompt_head={pt[:200]!r}")
        print(f"  resp_chars={len(rt)} resp_head={rt[:600]!r}")
        if len(rt) > 600:
            print(f"  resp_tail={rt[-200:]!r}")
    elif t == "prediction_rejected":
        print(f"[{i}] prediction_rejected")
        print(f"  reason={e.get('reason','')[:600]}")
    elif t == "prediction_accepted":
        print(f"[{i}] prediction_accepted")
    elif t == "prediction_exhausted":
        print(f"[{i}] prediction_exhausted")
    else:
        print(f"[{i}] {t}  keys={list(e.keys())}")
    print()
