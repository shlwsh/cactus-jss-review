"""Generate publication values without bibliography verification.

Used when paper files have been modified and sidecar hashes don't match.
"""
import sys
import pathlib

sys.path.insert(0, 'src')
sys.path.insert(0, '.')

import scripts.generate_publication_values as gpv
from pathlib import Path

ROOT = Path('.')
result = gpv.derive(ROOT, include_bibliography=False)
print(f'Result: {result}')
print('Publication values generated successfully.')
