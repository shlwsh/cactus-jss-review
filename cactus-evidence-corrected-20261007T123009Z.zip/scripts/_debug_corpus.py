#!/usr/bin/env python3
"""Compare corpus summary to diagnose mismatch."""
from scripts.audit_evidence_corpus import derive, load
from pathlib import Path
import json

# 生成新的摘要
summary, runs, tasks, sources = derive()

# 加载已存储的摘要
stored = load(Path('experiments/derived/governance_20261005T210000Z/summary.json'))
stored_generated_at = stored.pop('generated_at')

# 比较关键字段
print('=== 新生成的摘要关键字段 ===')
for key in ['run_directory_count', 'canonical_run_count', 'verified_bundle_count', 
            'invalid_directory_count', 'historical_snapshot_rows', 'indexed_result_files',
            'archive_integrity', 'policy']:
    print(f'{key}: {summary.get(key)}')

print()
print('=== 存储的摘要关键字段 ===')
for key in ['run_directory_count', 'canonical_run_count', 'verified_bundle_count', 
            'invalid_directory_count', 'historical_snapshot_rows', 'indexed_result_files',
            'archive_integrity', 'policy']:
    print(f'{key}: {stored.get(key)}')

print()
print('=== 差异 ===')
for key in summary:
    if key not in ['snapshot_binding', 'progress_binding', 'selection_policy_binding', 
                   'integrity_reason_counts', 'historical_snapshot_exclusion_counts']:
        if summary[key] != stored.get(key):
            print(f'DIFF {key}: new={summary[key]} old={stored.get(key)}')
