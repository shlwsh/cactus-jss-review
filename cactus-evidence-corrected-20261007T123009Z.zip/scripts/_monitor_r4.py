"""R4 progress monitor - run every 15 seconds."""
import json
import sys
import datetime as dt
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
RUNS = ROOT / "experiments" / "runs"
CAMPAIGN_ID = "phase-c1-engineering-validation-r4-20260925"

def check():
    now = dt.datetime.now(dt.timezone.utc).strftime("%H:%M:%S UTC")
    
    # Get latest RUNs from today
    runs = sorted(
        [d for d in RUNS.iterdir() if d.is_dir() and d.name.startswith("RUN-20260926")],
        key=lambda d: d.stat().st_mtime,
        reverse=True,
    )[:6]
    
    print(f"\n{'='*60}")
    print(f"  [{now}] R4 监控")
    print(f"{'='*60}")
    
    for d in runs:
        m = d / "run_manifest.json"
        s = "?"
        task_id = "?"
        if m.exists():
            try:
                md = json.loads(m.read_text())
                s = md.get("status", "?")
                task_id = md.get("task_id", "?")
                if task_id == "?":
                    tasks = md.get("tasks", [])
                    if tasks:
                        task_id = tasks[0] if isinstance(tasks, list) else "?"
            except Exception:
                s = "ERR"
        
        logs_dir = d / "logs"
        log_count = len(list(logs_dir.glob("*"))) if logs_dir.exists() else 0
        
        # Read last stdout line
        stdout = d / "logs" / "predict.stdout.log"
        tail = ""
        if stdout.exists():
            try:
                lines = [l for l in stdout.read_text(encoding="utf-8", errors="replace").split("\n") if l.strip()]
                if lines:
                    tail = lines[-1][:100]
            except Exception:
                tail = "(read error)"
        
        # Read last stderr line
        stderr = d / "logs" / "predict.stderr.log"
        err_tail = ""
        if stderr.exists():
            try:
                lines = [l for l in stderr.read_text(encoding="utf-8", errors="replace").split("\n") if l.strip()]
                if lines:
                    err_tail = lines[-1][:100]
            except Exception:
                err_tail = "(read error)"
        
        # Status emoji
        emoji = {"completed": "OK", "failed": "FAIL", "running": ">>>", "pending": "..."}.get(s, s)
        
        print(f"  {emoji} {d.name}")
        print(f"      task={task_id} status={s} logs={log_count}")
        if tail:
            print(f"      stdout: {tail}")
        if err_tail:
            print(f"      stderr: {err_tail}")
    
    # Check execution state
    exec_state = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json.execution.json"
    if exec_state.exists():
        try:
            es = json.loads(exec_state.read_text())
            completed = len(es.get("completed_runs") or [])
            pending = len(es.get("pending_runs") or [])
            state = es.get("execution_state", "?")
            print(f"\n  计划执行状态: state={state} completed={completed} pending={pending}")
        except Exception as e:
            print(f"\n  执行状态读取错误: {e}")
    else:
        print(f"\n  无执行状态文件")

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--once":
        check()
    else:
        # Run once for now
        check()

if __name__ == "__main__":
    main()
