"""Offline verification of the JSS revision's prediction and fault-test evidence.

This verifies archived artifacts, without model calls, evaluator runs, or edits
to historical evidence. Prediction-format success is never repair success.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]


def inspect(root: Path = ROOT):
    from scripts.derive_p04_matched_results import load_p04_results, derive_metrics
    from scripts.derive_fault_injection_matrix import analyze_results

    cohort_path = root / "experiments/plans/P04_matched_100tasks_cohort.json"
    safe_path = cohort_path.with_suffix(".jsonl")
    cohort = json.loads(cohort_path.read_text(encoding="utf-8"))
    safe = [json.loads(line) for line in safe_path.read_text(encoding="utf-8").splitlines()]
    task_ids = set(cohort["task_ids"])
    if len(task_ids) != cohort["task_count"] or {r["task_id"] for r in safe} != task_ids:
        raise ValueError("cohort coverage drift")
    if any("patch" in r or "test_patch" in r for r in safe):
        raise ValueError("gold patches in inference manifest")
    manifest_hash_matches = hashlib.sha256(safe_path.read_bytes()).hexdigest() == cohort["manifest_jsonl_sha256"]
    runs = root / "experiments/runs/P04-MATCHED-100TASKS"
    data = load_p04_results(runs)
    if set(data) != task_ids or any(set(row) != {"FACO", "BM25", "STRUCTURAL", "MAXIMAL"} for row in data.values()):
        raise ValueError("incomplete matched prediction cohort")
    metrics = derive_metrics(data)
    archived_path = root / "experiments/derived/p04_matched_derived_metrics.json"
    archived = json.loads(archived_path.read_text(encoding="utf-8"))
    metrics.pop("generated_at"); archived.pop("generated_at")
    if metrics != archived:
        raise ValueError("matched metrics do not recompute from predictions")
    raw_path = root / "experiments/derived/fault_injection_raw_results.json"
    raw = json.loads(raw_path.read_text(encoding="utf-8"))
    cases = raw["results"]
    if len({r["case_id"] for r in cases}) != len(cases):
        raise ValueError("duplicate fault-test case")
    for case in cases:
        if case["category"] == "fault_injection" and case["detected_by_gate"] != (not case["actual_admitted"]):
            raise ValueError("fault-test detection contradicts admission")
    fault = analyze_results(raw)
    fault.pop("generated_at")
    config_path = root / "configs/models/litellm_local_nothink_v7.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    # Explicit allowlist: never copy endpoints, billing identities, or credentials.
    config_fields = ["model_id", "model_version", "provider", "deployment_type", "context_limit",
                     "max_output_tokens", "temperature", "prediction_max_attempts", "prediction_retry_temperature", "thinking"]
    files = [cohort_path, safe_path, archived_path, raw_path, config_path,
             root / "scripts/derive_p04_matched_results.py", root / "scripts/derive_fault_injection_matrix.py",
             root / "scripts/run_fault_injection_suite.py", root / "scripts/run_p04_matched_experiment.py",
             root / "scripts/select_p04_cohort.py"]
    files += sorted(p for p in runs.rglob("*") if p.is_file())
    inventory = [{"path": p.relative_to(root).as_posix(), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    report = {"schema_version": "1.0", "scope": "offline artifact verification; no repair-success or primary-evidence certification",
            "matched": metrics, "fault_injection": fault, "input_inventory": inventory,
            "cohort_declared_manifest_hash_matches_bytes": manifest_hash_matches,
            "configured_model": {key: config.get(key) for key in config_fields},
            "config_binding": "current configured values; immutable per-call provider model snapshot not established",
            "fault_detection_stages": dict(Counter(r["detection_stage"] for r in cases if r["category"] == "fault_injection")),
            "limitations": ["matched endpoint is nonempty prediction with diff marker, not evaluated repair",
                            "patch length is Python character count, not tokens",
                            "task-level taxonomy aggregate contradicts its task list; counts withheld",
                            "fault tests reuse seed bundles; integrity rejection may precede semantic admission checks",
                            "no independent human inter-rater coding or public artifact DOI established"]}
    return json.loads(json.dumps(report)), files


def verify_snapshot(path: Path, root: Path = ROOT):
    expected, _ = inspect(root)
    actual = json.loads(path.read_text(encoding="utf-8"))
    actual.pop("generated_at")
    if expected != actual:
        raise ValueError("JSS source audit snapshot differs from current evidence")
    return {"status": "PASS", "prediction_tasks": expected["matched"]["cohort_size"],
            "fault_test_cases": expected["fault_injection"]["overall_summary"]["total_test_cases"],
            "scope": expected["scope"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report, files = inspect()
    report["generated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    from scripts.artifact_provenance import write
    write(args.output, files, Path(__file__), transform={"activity": "recompute archived prediction and fault-test metrics; audit only"}, kind="derived_dataset")
    print(json.dumps(verify_snapshot(args.output), ensure_ascii=False))
