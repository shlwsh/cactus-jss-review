"""Verify one frozen Lite-50 evaluator archive without retaining a local image."""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from build_lite50_image_archive_manifest import _runtime_image_ids, sha256


def run(command: list[str], *, timeout: int = 1800) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, text=True, capture_output=True, check=False, timeout=timeout)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--task-manifest", type=Path, required=True)
    parser.add_argument("--eval-index", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--docker-bin", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError(f"refusing to overwrite evidence: {args.output}")
    tasks = [json.loads(line) for line in args.task_manifest.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(tasks) != 50 or not 1 <= args.eval_index <= len(tasks):
        raise ValueError("expected a 50-task manifest and a valid eval index")
    task = tasks[args.eval_index - 1]
    task_id, base_commit = task["task_id"], task["base_commit"]
    image = f"sweb.eval.x86_64.{task_id}:latest"
    archive_ids = _runtime_image_ids(args.archive)
    if len(archive_ids) != 1:
        raise ValueError("a single-eval archive must contain exactly one runtime ID")
    loaded = False
    try:
        result = run([str(args.docker_bin), "load", "--input", str(args.archive)])
        if result.returncode:
            raise RuntimeError(result.stderr[-2000:])
        loaded = True
        def in_image(*command: str) -> str:
            result = run([str(args.docker_bin), "run", "--rm", "--pull=never", image, *command], timeout=300)
            if result.returncode:
                raise RuntimeError(result.stderr[-2000:])
            return result.stdout.strip()
        head = in_image("git", "-C", "/testbed", "rev-parse", "HEAD")
        status = in_image("git", "-C", "/testbed", "status", "--porcelain", "--untracked-files=no")
        tree = in_image("git", "-C", "/testbed", "rev-parse", "HEAD^{tree}")
        result = run([str(args.docker_bin), "image", "inspect", image, "--format={{.Id}}"])
        local_id = result.stdout.strip()
        if result.returncode or head != base_commit or status or local_id != archive_ids[0]:
            raise RuntimeError("archive source or runtime identity verification failed")
        payload = {"schema_version": "1.0", "verified_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "eval_id": f"eval_{args.eval_index:03d}", "task_id": task_id, "base_commit": base_commit, "archive_path": args.archive.resolve().as_posix(), "archive_sha256": sha256(args.archive), "archive_size_bytes": args.archive.stat().st_size, "local_image_id": local_id, "runtime_id": archive_ids[0], "source_tree": tree, "status": "VERIFIED"}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    finally:
        if loaded:
            run([str(args.docker_bin), "image", "rm", image], timeout=300)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
