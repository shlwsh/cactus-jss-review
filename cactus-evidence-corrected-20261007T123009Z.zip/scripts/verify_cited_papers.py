"""Verify actual cited keys, archive official metadata, and check archive hashes.

Default is offline. --download fetches official sources; --sync-bib updates
arXiv title/author/year fields using the captured primary-source metadata.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import time
import urllib.request
import urllib.error

ROOT = Path(__file__).resolve().parents[1]
BIB = ROOT / "paper/references.bib"
TEX = ROOT / "paper/main.tex"
MANIFEST = ROOT / "paper/data/scholar/cited_papers_manifest.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def entries(text):
    result = {}
    for match in re.finditer(r"@\w+\s*\{\s*([^,]+),", text):
        start = match.end(); depth = 1; i = start
        while depth:
            if text[i] == "{" and (i == 0 or text[i-1] != "\\"):
                depth += 1
            if text[i] == "}" and text[i-1] != "\\":
                depth -= 1
            i += 1
        body = text[start:i-1]
        fields = {}
        for field in re.finditer(r"(?m)^\s*(\w+)\s*=\s*\{", body):
            j = field.end(); k = j; d = 1
            while d:
                if body[k] == "{" and body[k-1] != "\\": d += 1
                if body[k] == "}" and body[k-1] != "\\": d -= 1
                k += 1
            fields[field.group(1).lower()] = body[j:k-1]
        key = match.group(1).strip()
        if key in result: raise ValueError(f"duplicate BibTeX key: {key}")
        result[key] = {"fields": fields, "start": start, "end": i-1, "body": body}
    return result


class Metadata(HTMLParser):
    def __init__(self):
        super().__init__(); self.values = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "meta" and "name" in attrs:
            self.values.setdefault(attrs["name"].lower(), []).append(attrs.get("content", ""))


def cited():
    return sorted({k.strip() for block in re.findall(r"\\cite[a-zA-Z*]*(?:\[[^\]]*\])*\{([^}]+)\}", TEX.read_text(encoding="utf-8")) for k in block.split(",")})


def fetch(key, entry, directory):
    fields = entry["fields"]
    url = fields.get("url")
    if not url and fields.get("doi"):
        url = "https://api.crossref.org/works/" + fields["doi"]
    if not url: raise ValueError(f"no official URL/DOI: {key}")
    request = urllib.request.Request(url, headers={"User-Agent": "CACTUS-citation-verification/1.0"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                data = response.read(); final_url = response.url
            break
        except urllib.error.HTTPError as exc:
            if exc.code not in (429, 502, 503, 504) or attempt == 2: raise
            time.sleep(3 * (attempt + 1))
    if len(data) < 100: raise ValueError(f"empty official response: {key}")
    suffix = ".json" if "api.crossref.org" in url else ".html"
    path = directory / (key + suffix)
    path.write_bytes(data)
    metadata = Metadata(); metadata.feed(data.decode("utf-8", errors="replace"))
    values = metadata.values
    official = {}
    if "arxiv.org/abs/" in url:
        for name in ("citation_title", "citation_author", "citation_date", "citation_arxiv_id"):
            if not values.get(name): raise ValueError(f"missing arXiv metadata {key}: {name}")
        official = {"title": values["citation_title"][0], "author": " and ".join(values["citation_author"]), "year": values["citation_date"][0][:4]}
        if values["citation_arxiv_id"][0] != url.rsplit("/", 1)[1].split("v")[0]:
            raise ValueError(f"arXiv identifier mismatch: {key}")
    elif suffix == ".json":
        message = json.loads(data)["message"]
        official = {"title": message["title"][0],
                    "author": " and ".join(a["family"] + ", " + a.get("given", "") for a in message["author"]),
                    "year": str(message.get("published-print", message["published"])["date-parts"][0][0])}
        if fields.get("doi", "").lower() != message["DOI"].lower():
            raise ValueError(f"Crossref DOI mismatch: {key}")
        venue = "journal" if message["type"] == "journal-article" else "booktitle"
        official[venue] = message["container-title"][0]
        if re.sub(r"[\W_]", "", fields["title"]).lower() != re.sub(r"[\W_]", "", official["title"]).lower():
            raise ValueError(f"Crossref title mismatch: {key}")
    return {"citation_key": key, "url": url, "final_url": final_url, "official_metadata": official,
            "archive_status": "snapshot", "metadata_status": "official_source_captured",
            "file_path": path.relative_to(ROOT).as_posix(), "sha256": sha(path), "file_size_bytes": len(data)}


def download(sync, reuse_archives=False):
    text = BIB.read_text(encoding="utf-8"); bib = entries(text); keys = cited()
    missing = set(keys) - set(bib)
    if missing: raise ValueError(f"missing BibTeX: {sorted(missing)}")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    directory = ROOT / "paper/data/papers" / ("verification_" + stamp)
    directory.mkdir(parents=True, exist_ok=False)
    cached = {}
    if reuse_archives and MANIFEST.is_file():
        for record in json.loads(MANIFEST.read_text(encoding="utf-8"))["records"]:
            path = ROOT / record["file_path"]
            entry = bib.get(record["citation_key"], {}).get("fields", {})
            url = entry.get("url") or ("https://api.crossref.org/works/" + entry["doi"] if entry.get("doi") else None)
            if (path.is_file() and sha(path) == record["sha256"] and record["url"] == url
                    and all(re.sub(r"[{}]", "", entry.get(field, "")) == value for field, value in record.get("official_metadata", {}).items())):
                cached[record["citation_key"]] = record
    def capture(key):
        if key in cached:
            return cached[key]
        try:
            return fetch(key, bib[key], directory)
        except Exception as exc:
            raise ValueError(f"official citation capture failed: {key} ({type(exc).__name__})") from exc
    with ThreadPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(capture, keys))
    changes = []
    if sync:
        # Replace spans in reverse order to preserve positions.
        by_key = {r["citation_key"]: r for r in records}
        for key, entry in sorted(bib.items(), key=lambda pair: pair[1]["start"], reverse=True):
            if key not in by_key or "arxiv.org/abs/" not in by_key[key]["url"]: continue
            body = entry["body"]
            for field, value in by_key[key]["official_metadata"].items():
                if entry["fields"].get(field) == value: continue
                # These official scalar fields contain no BibTeX brace nesting.
                pattern = rf"(?m)^(\s*{field}\s*=\s*)\{{.*?\}}(,?\s*)$"
                body, count = re.subn(pattern, lambda m: m[1] + "{" + value + "}" + m[2], body)
                if count != 1: raise ValueError(f"unable to sync {key}.{field}")
                changes.append({"key": key, "field": field, "before": entry["fields"].get(field), "after": value})
            text = text[:entry["start"]] + body + text[entry["end"]:]
        BIB.write_text(text, encoding="utf-8", newline="\n")
    manifest = {"schema_version": "2.0", "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "total_cited": len(keys), "records": records, "bib_sha256": sha(BIB), "tex_sha256": sha(TEX),
                "metadata_changes": changes, "scope": "official_metadata_HTML_or_Crossref_snapshot; PDF archival is not asserted",
                "generator_sha256": sha(Path(__file__))}
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write_manifest_provenance(manifest)
    # Preserve each run as an immutable dated snapshot as well as the current index.
    (directory / "cited_papers_manifest.json").write_bytes(MANIFEST.read_bytes())
    return verify()


def verify():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8")); keys = cited(); bib = entries(BIB.read_text(encoding="utf-8"))
    failures = []
    if set(keys) != {r["citation_key"] for r in manifest["records"]}: failures.append("cited/archive key coverage drift")
    if manifest["total_cited"] != len(keys) or len(manifest["records"]) != len(keys): failures.append("cited/archive count drift")
    if manifest.get("bib_sha256") != sha(BIB): failures.append("bibliography hash drift")
    if manifest.get("tex_sha256") != sha(TEX): failures.append("manuscript hash drift")
    for r in manifest["records"]:
        path = (ROOT / r["file_path"]).resolve(); path.relative_to(ROOT.resolve())
        if not path.is_file() or sha(path) != r["sha256"]: failures.append(f"archive hash mismatch: {r['citation_key']}")
        fields = bib.get(r["citation_key"], {}).get("fields", {})
        for field, expected in r.get("official_metadata", {}).items():
            if re.sub(r"[{}]", "", fields.get(field, "")) != expected:
                failures.append(f"official metadata differs: {r['citation_key']}.{field}")
        if r["archive_status"] not in ("ok", "snapshot"): failures.append(f"unarchived: {r['citation_key']}")
    report = {"status": "fail" if failures else "pass", "total_cited": len(keys), "archived_snapshots": len(manifest["records"]),
              "metadata_corrections": len(manifest.get("metadata_changes", [])), "failures": failures,
              "manifest_sha256": sha(MANIFEST)}
    print(json.dumps(report, ensure_ascii=False))
    if failures: raise ValueError("citation verification failed")
    return report


def refresh_bindings():
    """Rebind an edited manuscript to already captured official metadata offline."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    keys = set(cited())
    if not keys.issubset({r["citation_key"] for r in manifest["records"]}):
        raise ValueError("new cited keys require a new online capture")
    # Withdrawing a citation needs no new network claim. Historical manifests
    # and original official snapshots remain preserved.
    manifest["records"] = [r for r in manifest["records"] if r["citation_key"] in keys]
    manifest["total_cited"] = len(keys)
    manifest["bib_sha256"] = sha(BIB)
    manifest["tex_sha256"] = sha(TEX)
    manifest["generated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    manifest["generator_sha256"] = sha(Path(__file__))
    manifest["binding_refresh"] = "offline; official capture paths and hashes preserved"
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write_manifest_provenance(manifest)
    verify()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    archive = MANIFEST.with_name("cited_papers_manifest_" + stamp + ".json")
    if archive.exists(): raise FileExistsError(archive)
    archive.write_bytes(MANIFEST.read_bytes())


def write_manifest_provenance(manifest):
    from artifact_provenance import write
    write(MANIFEST, [BIB, TEX, *(ROOT / r["file_path"] for r in manifest["records"])], Path(__file__),
          transform={"scope": "actual_cited_keys_official_snapshots", "PDF_archival_asserted": False}, kind="derived_dataset")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download", action="store_true")
    parser.add_argument("--sync-bib", action="store_true")
    parser.add_argument("--reuse-archives", action="store_true", help="retain verified official snapshots and fetch only new/changed cited keys")
    parser.add_argument("--refresh-bindings", action="store_true")
    args = parser.parse_args()
    if args.sync_bib and not args.download: parser.error("--sync-bib requires --download")
    if args.reuse_archives and not args.download: parser.error("--reuse-archives requires --download")
    if args.refresh_bindings:
        if args.download: parser.error("refresh is offline")
        refresh_bindings()
    else:
        download(args.sync_bib, args.reuse_archives) if args.download else verify()
