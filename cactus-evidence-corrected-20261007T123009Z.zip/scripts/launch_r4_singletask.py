"""Single-task launcher for CACTUS R4 engineering validation.

Wraps ``scripts/run_swebench_campaign.py`` with:

1. **Sidecar env injection**: reads ``acm/docs/llm/.env`` and forwards the
   seven CACTUS session variables without writing them to disk.
2. **Background live monitor**: starts ``monitor_r4_live.py`` so every
   ``trace/events.jsonl`` append is streamed to the operator console as soon
   as the model responds.
3. **Predict-time stderr dump**: forces ``cactus_swebench_predict.py`` to emit
   one structured ``[predict.turn]`` line per model call (response_text +
   finish_reason + token usage), so even successful-looking runs leave a
   readable trail.
4. **Auto verdict**: writes a verdict JSON summarising the run outcome and
   the model response's first 800 chars for quick triage.

Usage
-----

    python scripts/launch_r4_singletask.py \
        --task-id astropy__astropy-12907 \
        --contract experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json \
        --approval experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json \
        --model-config configs/models/litellm_local_nothink.json

The script picks up ``E:/work/p5-acm/acm`` as project root automatically.
"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONTRACT = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
DEFAULT_APPROVAL = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
DEFAULT_TASKS = ROOT / "json/cactus_tasks_inference_safe.jsonl"
DEFAULT_REPO_CACHE = ROOT / "experiments/repo_cache"
DEFAULT_OUTPUT = ROOT / "experiments/runs"
DEFAULT_EVALUATOR = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
DEFAULT_PAIR_PLAN = ROOT / "experiments/plans/C1_primary_pairs_20260925_R4.json"
ENV_FILE = ROOT / "docs/llm/.env"
LITELLM_KEY_TAGS = ("LITELLM", "API_KEY", "CACTUS")


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def load_env_into(target: dict[str, str]) -> int:
    """Read ``ENV_FILE`` and inject relevant keys into ``target`` (in place)."""
    if not ENV_FILE.exists():
        return 0
    injected = 0
    for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if any(tag in k.upper() for tag in LITELLM_KEY_TAGS):
            target[k] = v.strip()
            injected += 1
    return injected


def build_cmd(args: argparse.Namespace) -> list[str]:
    py = ROOT / ".venv" / "Scripts" / "python.exe"
    if not py.exists():
        py = Path(sys.executable)
    cmd = [
        str(py),
        "-u",  # unbuffered stdout
        "-m",
        "scripts.run_swebench_campaign",
        "--contract", str(args.contract),
        "--approval", str(args.approval),
        "--model-config", str(args.model_config),
        "--tasks", str(args.tasks),
        "--output-root", str(args.output_root),
        "--repo-cache", str(args.repo_cache),
        "--evaluator-dataset", str(args.evaluator_dataset),
        "--project-root", str(ROOT),
        "--campaign-id", args.campaign_id,
        "--task-id", args.task_id,
        "--limit", "1",
    ]
    if args.pair_plan:
        cmd += ["--pair-plan", str(args.pair_plan)]
    return cmd


def start_monitor(args: argparse.Namespace) -> subprocess.Popen | None:
    if args.no_monitor:
        return None
    py = ROOT / ".venv" / "Scripts" / "python.exe"
    if not py.exists():
        py = Path(sys.executable)
    log_path = args.output_root / f"_r4_live_monitor_{utc_now()}.log"
    cmd = [
        str(py),
        "-u",
        str(ROOT / "scripts" / "monitor_r4_live.py"),
        "--runs", str(args.output_root),
        "--interval", str(args.monitor_interval),
        "--log", str(log_path),
    ]
    print(f"[launcher] monitor pid start, log={log_path}", flush=True)
    # Inherit stdout so monitor events surface in the launcher's stream in
    # real time; the monitor already writes a JSONL sidecar for offline replay.
    return subprocess.Popen(
        cmd,
        cwd=str(ROOT),
        stdout=None,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )


def relay_monitor_output(proc: subprocess.Popen, stop: bool = False) -> None:
    """Deprecated; kept for backward-compat. Inherits stdout now."""
    return


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--approval", type=Path, default=DEFAULT_APPROVAL)
    parser.add_argument("--tasks", type=Path, default=DEFAULT_TASKS)
    parser.add_argument("--repo-cache", type=Path, default=DEFAULT_REPO_CACHE)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--evaluator-dataset", type=Path, default=DEFAULT_EVALUATOR)
    parser.add_argument("--pair-plan", type=Path, default=DEFAULT_PAIR_PLAN)
    parser.add_argument("--model-config", type=Path, default=None,
                        help="Model config path; if omitted, read from contract.model.config")
    parser.add_argument("--no-monitor", action="store_true",
                        help="Skip the live monitor child process")
    parser.add_argument("--monitor-interval", type=float, default=2.0)
    parser.add_argument("--timeout-sec", type=int, default=1800)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--campaign-id", default=None,
                        help="Frozen campaign id; auto-derived if omitted")
    args = parser.parse_args()
    if args.campaign_id is None:
        args.campaign_id = f"phase-c1-r4-singletask-{utc_now()}-{args.task_id}"
    if args.model_config is None:
        try:
            contract_obj = json.loads(args.contract.read_text(encoding="utf-8"))
            relative = contract_obj.get("model", {}).get("config")
            if relative:
                candidate = (args.contract.parent.parent / relative).resolve()
                if candidate.exists():
                    args.model_config = candidate
        except Exception as exc:
            print(f"[launcher] WARN: could not read model.config from contract: {exc}", flush=True)
    if args.model_config is None:
        args.model_config = ROOT / "configs/models/litellm_local_nothink_v6.json"
    print(f"[launcher] model_config={args.model_config}", flush=True)

    env = os.environ.copy()
    n_keys = load_env_into(env)
    print(f"[launcher] injected {n_keys} session vars from {ENV_FILE}", flush=True)

    cmd = build_cmd(args)
    print(f"[launcher] cmd:\n  {' '.join(shlex.quote(c) for c in cmd)}", flush=True)

    if args.dry_run:
        return 0

    args.output_root.mkdir(parents=True, exist_ok=True)

    monitor = start_monitor(args)
    try:
        t0 = time.time()
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        deadline = t0 + args.timeout_sec
        try:
            while True:
                line = proc.stdout.readline() if proc.stdout else ""
                if line:
                    print(f"[campaign] {line.rstrip()}", flush=True)
                if proc.poll() is not None and not line:
                    break
                if time.time() > deadline:
                    print(f"[launcher] timeout {args.timeout_sec}s reached; killing", flush=True)
                    proc.kill()
                    break
        except KeyboardInterrupt:
            print("[launcher] interrupted; killing campaign", flush=True)
            proc.kill()
            monitor and monitor.kill()
            return 130
        elapsed = time.time() - t0
        rc = proc.returncode
        print(f"[launcher] campaign rc={rc} elapsed={elapsed:.1f}s", flush=True)

        if monitor is not None:
            time.sleep(min(2.0, args.monitor_interval * 2))
            monitor.terminate()
            try:
                monitor.wait(timeout=3)
            except subprocess.TimeoutExpired:
                monitor.kill()
        return rc
    finally:
        if monitor is not None and monitor.poll() is None:
            monitor.kill()


if __name__ == "__main__":
    sys.exit(main())
