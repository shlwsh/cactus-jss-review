"""launch_r4_all_v2.py — Launch each R4 task independently to avoid pair-plan state conflicts.

Strategy:
  - For each task, run a separate campaign (own campaign_id, own execution state)
  - This avoids the "paired C1 plan already has an execution record" issue
  - Each task gets its own RUN bundle, all from the same contract+approval

Tasks:
  astropy__astropy-12907 — nested CompoundModel bug (HARD)
  astropy__astropy-13033 — ?
  astropy__astropy-13236 — ?
"""

from __future__ import annotations

import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

from inject_session_keys import REQUIRED_KEYS, load_resolved  # noqa: E402

CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
APPROVAL = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
PLAN = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json"
MODEL_CONFIG = ROOT / "configs" / "models" / "litellm_local_think.json"
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
OUTPUT_ROOT = ROOT / "experiments" / "runs"
REPO_CACHE = ROOT / "experiments" / "repo_cache"
DATASET = Path(r"E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
RUNNER = ROOT / "scripts" / "run_swebench_campaign.py"
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"

TASKS = ["astropy__astropy-12907", "astropy__astropy-13033", "astropy__astropy-13236"]
BASE_CAMPAIGN = "phase-c1-r4-think-v3-" + dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def main() -> int:
    env_path, resolved = load_resolved()
    env = {**os.environ, **{k: resolved[k]["value"] for k in REQUIRED_KEYS}}
    for required in (CONTRACT, APPROVAL, PLAN, MODEL_CONFIG, TASK_MANIFEST, RUNNER, DATASET):
        if not required.exists():
            print(f"ERROR: required path missing: {required}", file=sys.stderr)
            return 2

    cfg = json.loads(MODEL_CONFIG.read_text(encoding="utf-8"))
    log_path = OUTPUT_ROOT / f"_r4_all_v2_{BASE_CAMPAIGN}.log"
    print("=" * 70)
    print(f"R4 THINK-MODE V3: 3 TASKS, INDEPENDENT CAMPAIGNS")
    print("=" * 70)
    print(f"contract    : {CONTRACT.name}")
    print(f"plan        : {PLAN.name}")
    print(f"model_cfg   : {MODEL_CONFIG.name}")
    print(f"  thinking          = {cfg.get('thinking')}")
    print(f"  max_output_tokens = {cfg.get('max_output_tokens')}")
    print(f"  reasoning_effort  = {cfg.get('reasoning_effort')}")
    print(f"campaign    : {BASE_CAMPAIGN}-<task>")
    print(f"tasks       : {TASKS}")
    print(f"log         : {log_path}")
    print("=" * 70)

    results = {}
    with log_path.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"# R4 all-v2 launches\n# started: {dt.datetime.now(dt.timezone.utc).isoformat()}\n\n")
        fh.flush()
        for task_id in TASKS:
            campaign_id = f"{BASE_CAMPAIGN}-{task_id}"
            print(f"\n>>> TASK: {task_id}  campaign={campaign_id}")
            cmd = [
                str(PYTHON),
                "-m", "scripts.run_swebench_campaign",
                "--contract", str(CONTRACT),
                "--approval", str(APPROVAL),
                "--model-config", str(MODEL_CONFIG),
                "--tasks", str(TASK_MANIFEST),
                "--output-root", str(OUTPUT_ROOT),
                "--repo-cache", str(REPO_CACHE),
                "--evaluator-dataset", str(DATASET),
                "--project-root", str(ROOT),
                "--pair-plan", str(PLAN),
                "--campaign-id", campaign_id,
                "--task-id", task_id,
                "--limit", "1",
            ]
            print("$ " + " ".join(cmd))
            fh.write(f"\n# TASK {task_id}\n# cmd: " + " ".join(cmd) + "\n")
            fh.flush()
            try:
                proc = subprocess.Popen(
                    cmd, cwd=str(ROOT.parent), env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, bufsize=1,
                )
                assert proc.stdout is not None
                for line in proc.stdout:
                    sys.stdout.write(line)
                    sys.stdout.flush()
                    fh.write(line)
                    fh.flush()
                rc = proc.wait(timeout=1800)  # 30 min cap
            except subprocess.TimeoutExpired:
                print(f">>> TIMEOUT after 1800s for {task_id}")
                proc.kill()
                rc = -1
            print(f">>> {task_id} finished with exit={rc}")
            results[task_id] = rc
            fh.write(f"\n# {task_id} finished exit={rc}\n")
            fh.flush()

    print()
    print("=" * 70)
    print("R4 all-v2 summary:")
    for t, rc in results.items():
        status = "OK" if rc == 0 else "FAIL"
        print(f"  {t}: exit={rc} ({status})")
    print(f"log: {log_path}")
    print("=" * 70)
    return 0 if all(rc == 0 for rc in results.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
