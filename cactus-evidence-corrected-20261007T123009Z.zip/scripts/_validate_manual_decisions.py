import hashlib, yaml, json
p = r'E:\work\p5-acm\acm\experiments\migration\manual_decisions.yaml'
content = open(p, encoding='utf-8').read()
sha = hashlib.sha256(content.encode()).hexdigest()
print('file_size_bytes:', len(content.encode()))
print('file_sha256:', sha)
try:
    d = yaml.safe_load(content)
    print('yaml_valid: True')
    print('decision_count:', len(d.get('decisions', [])))
    print('schema_gaps_count:', len(d.get('schema_gaps_documented', [])))
    for dec in d['decisions']:
        eid = dec['entity_id']
        st = dec['status']
        did = dec['decision_id']
        print('  ' + did + ': ' + eid + ' -> ' + st)
    sidecar = {
        'source_file': 'experiments/migration/manual_decisions.yaml',
        'source_sha256': sha,
        'source_size_bytes': len(content.encode()),
        'validated_at': '2026-09-27T02:24:00Z',
        'validator': 'AI Agent (P-03 manual-decisions path)',
    }
    with open(p + '.sha256', 'w', encoding='utf-8') as f:
        f.write(sha + '  experiments/migration/manual_decisions.yaml\n')
    print('sidecar_written: True')
except Exception as e:
    print('yaml_invalid:', repr(e))
