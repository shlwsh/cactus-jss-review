import json
import re

paths = [
    'e:/work/p5-acm/acm/experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/django__django-11910/events.jsonl',
    'e:/work/p5-acm/acm/experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/django__django-12125/events.jsonl',
]

for path in paths:
    print('=== ', path, ' ===')
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                e = json.loads(line)
                t = e.get('type', '')
                seq = e.get('seq', 0)
                if t != 'observe': continue
                p = e.get('payload', {})
                # Get all keys
                keys = list(p.keys())
                # If 'task' is present and very long
                for k in ('task', 'content', 'message'):
                    v = p.get(k, '')
                    if isinstance(v, str) and len(v) > 1000:
                        # search for "warning" or "exception" or "Problem"
                        for kw in ('## Issue', 'Description', 'Traceback', 'django__django', 'Problem statement'):
                            if kw in v:
                                idx = v.find(kw)
                                print(f'seq={seq} k={k} kw={kw} idx={idx}')
                                print(v[max(0, idx-100):idx+1500])
                                print()
                                break
                        break
            except Exception:
                pass