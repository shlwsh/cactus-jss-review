"""Rank inference-safe SWE-bench tasks for the targeted E6 pilot.

The selector reads only the model-safe task manifest (issue text and declared
FAIL_TO_PASS identifiers). It never reads SWE-bench gold patches or test_patch.
Scores are screening heuristics and require human review before a run contract
freezes the selected task IDs.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
from dataclasses import replace
from pathlib import Path

from cactus.adapters.benchmark import BenchmarkTask, load_evaluation_test_ids, load_manifest
from cactus.context.test_aware import extract_test_hints
from cactus.engine import TaskComplexity, estimate_task_complexity
from cactus.governance.canonical import utc_now


def _matches(text: str, patterns: tuple[str, ...]) -> list[str]:
    found: list[str] = []
    for pattern in patterns:
        found.extend(match.group(0).rstrip("(").strip() for match in re.finditer(pattern, text, flags=re.IGNORECASE))
    return sorted(set(item.casefold() for item in found))


def _features(task: BenchmarkTask) -> tuple[dict[str, bool], dict[str, list[str]]]:
    text = task.issue_text.casefold()
    assertion_evidence = _matches(text, (
        r"\bself\.(assert[A-Z][A-Za-z0-9_]*)\s*\(",
        r"\bpytest\.raises\s*\(",
        r"\bassert\s+(?!=)",
    ))
    helper_evidence = _matches(text, (
        r"\bhelper(?:\s+(?:function|method))?\b",
        r"\bcall[- ]?site\b",
        r"\bcallers?\b",
        r"\b(?:missing|add|requires?|needs?)\s+call\s+`?[a-z_][\w.]*`?",
        r"\binvok\w*\b",
        r"\bwrapper\b",
        r"\bdelegat\w+\s+to\b",
        r"\b_check_[A-Za-z0-9_]+\b",
    ))
    inheritance_evidence = _matches(text, (
        r"\binherit\w*\b",
        r"\bsubclass(?:es)?\b",
        r"\bbase\s+class\b",
        r"\bsuperclass\b",
        r"\bextends\b",
        r"\bsuper\s*\(\s*\)",
        r"\bclass\s+[A-Za-z_]\w*\s*\(\s*[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*",
    ))
    evidence = {
        "multiple_assertion_signals": assertion_evidence,
        "helper_or_call_site_signals": helper_evidence,
        "inheritance_signals": inheritance_evidence,
    }
    features = {
        "multiple_assertion_signals": len(assertion_evidence) >= 2,
        "helper_or_call_site_signals": bool(helper_evidence),
        "inheritance_signals": bool(inheritance_evidence),
    }
    return features, evidence


def _test_paths(identifier: str) -> tuple[tuple[str, str | None, str | None], ...]:
    """Resolve an allowlisted FAIL_TO_PASS identifier to candidate base paths."""
    dotted = re.fullmatch(r"([^\s]+)\s+\(([A-Za-z_][\w.]*)\)", identifier)
    if "::" in identifier:
        path, test_case = identifier.split("::", 1)
        case_parts = test_case.split("::")
        test_name = case_parts[-1].split("[", 1)[0]
        class_name = "::".join(case_parts[:-1]) or None
        return ((path.replace("\\", "/"), test_name, class_name),)
    if dotted:
        test_name, owner = dotted.groups()
        if owner.endswith("." + test_name):
            owner = owner[:-(len(test_name) + 1)]
        module_name = owner.rpartition(".")[0]
        parts = module_name.split(".")
        if not module_name or not all(re.fullmatch(r"[A-Za-z_]\w*", part) for part in parts):
            return ()
        module_path = "/".join(parts)
        return tuple((path, test_name, owner.rsplit(".", 1)[-1]) for path in (
            module_path + ".py",
            module_path + "/__init__.py",
            "tests/" + module_path + ".py",
            "tests/" + module_path + "/__init__.py",
        ))
    return ()


def _base_test_hints(task: BenchmarkTask, repo_cache: Path) -> tuple[int | None, list[str], str]:
    """Read only bounded test-source blobs at the benchmark base commit."""
    if estimate_task_complexity(task.issue_text, fail_to_pass_count=len(task.fail_to_pass)) is not TaskComplexity.COMPLEX:
        return None, [], "complexity_gate_closed"
    if not task.fail_to_pass:
        return None, [], "fail_to_pass_missing"
    mirror = repo_cache / f"{task.repo_id.replace('/', '__')}.git"
    if not mirror.is_dir():
        return None, [], "repo_mirror_missing"
    hints = []
    readable_sources = 0
    lookup_failed = False
    for identifier in task.fail_to_pass[:12]:
        candidates = _test_paths(str(identifier))
        candidates = tuple(
            item for item in candidates
            if item[0] and not Path(item[0]).is_absolute() and ".." not in Path(item[0]).parts
        )
        if not candidates:
            continue
        request = "".join(f"{task.base_commit}:{path}\n" for path, _, _ in candidates).encode("utf-8")
        result = subprocess.run(
            ["git", "--git-dir", str(mirror), "cat-file", "--batch"],
            input=request,
            capture_output=True,
            check=False,
        )
        if result.returncode:
            lookup_failed = True
            continue
        output = result.stdout
        offset = 0
        selected: tuple[bytes, str, str | None, str | None] | None = None
        for path, test_name, class_name in candidates:
            line_end = output.find(b"\n", offset)
            if line_end < 0:
                break
            header = output[offset:line_end].decode("ascii", errors="replace")
            offset = line_end + 1
            if header.endswith(" missing"):
                continue
            try:
                size = int(header.split()[-1])
            except (ValueError, IndexError):
                break
            content = output[offset:offset + size]
            offset += size + 1
            if size <= 1_000_000:
                selected = (content, path, test_name, class_name)
                break
        if selected is None:
            continue
        content, path, test_name, class_name = selected
        try:
            source = content.decode("utf-8")
        except UnicodeError:
            continue
        readable_sources += 1
        hints.extend(extract_test_hints(source, path, test_name=test_name, class_name=class_name))
        if len(hints) >= 30:
            break
    if hints:
        status = "structural_hints_found"
    elif readable_sources:
        status = "source_available_no_structural_hints"
    elif lookup_failed:
        status = "base_test_blob_lookup_failed"
    else:
        status = "base_test_source_missing"
    return len(hints), sorted({hint.assertion_kind for hint in hints}), status


def rank_e6_tasks(
    tasks: tuple[BenchmarkTask, ...], *, limit: int = 10, repo_cache: Path | None = None,
) -> list[dict[str, object]]:
    if limit < 1:
        raise ValueError("limit must be positive")
    ranked: list[tuple[int, int, BenchmarkTask, dict[str, bool], TaskComplexity, int | None, list[str], str, dict[str, bool | None]]] = []
    evidence_by_index: dict[int, dict[str, list[str]]] = {}
    for index, task in enumerate(tasks):
        features, evidence = _features(task)
        evidence_by_index[index] = evidence
        score = sum(features.values())
        complexity = estimate_task_complexity(task.issue_text, fail_to_pass_count=len(task.fail_to_pass))
        score += int(complexity == TaskComplexity.COMPLEX)
        hint_count, hint_kinds, hint_status = _base_test_hints(task, repo_cache) if repo_cache is not None else (None, [], "not_checked")
        similarity_features: dict[str, bool | None] = {
            "multiple_assertion_formats": None if hint_count is None else len(hint_kinds) > 1,
            "helper_or_call_site_signals": features["helper_or_call_site_signals"],
            "inheritance_signals": features["inheritance_signals"],
        }
        ranked.append((score, index, task, features, complexity, hint_count, hint_kinds, hint_status, similarity_features))
    ranked.sort(
        key=lambda item: (
            -(item[5] is not None and item[5] > 0),
            -sum(value is True for value in item[8].values()),
            -(item[5] is not None and len(item[6]) > 1),
            -item[0], -min(len(item[6]), 5), -min(item[5] or 0, 30),
            item[1], item[2].task_id,
        )
    )
    return [
        {
            "rank": position,
            "task_id": task.task_id,
            "repo_id": task.repo_id,
            "score": score,
            "features": features,
            "complexity": complexity.value,
            "base_test_hint_count": hint_count,
            "base_test_hint_kinds": hint_kinds,
            "base_test_assertion_kind_count": None if hint_count is None else len(hint_kinds),
            "base_test_multiple_assertion_formats": None if hint_count is None else len(hint_kinds) > 1,
            "plan_similarity_features": similarity_features,
            "plan_similarity_signal_count": sum(value is True for value in similarity_features.values()),
            "plan_similarity_qualified": all(value is True for value in similarity_features.values()),
            "test_hint_screen_status": hint_status,
            "test_aware_treatment_available": None if hint_count is None else hint_count > 0,
            "feature_evidence": evidence_by_index[selected_index],
            "fail_to_pass_identifiers": list(task.fail_to_pass),
            "screening_only": True,
        }
        for position, (score, selected_index, task, features, complexity, hint_count, hint_kinds, hint_status, similarity_features) in enumerate(ranked[:limit], 1)
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", type=Path, required=True, help="Inference-safe SWE-bench JSONL")
    parser.add_argument("--evaluator-manifest", type=Path, help="Allowlisted evaluator JSONL containing FAIL_TO_PASS but no patch fields")
    parser.add_argument("--repo-cache", type=Path, help="Optional local bare-repository cache for checking base-commit test hints")
    parser.add_argument("--output", type=Path, required=True, help="JSON selection report")
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--minimum-treatment-eligible", type=int, default=10)
    parser.add_argument("--minimum-plan-similarity", type=int, default=10)
    args = parser.parse_args()
    if args.minimum_treatment_eligible < 1:
        parser.error("--minimum-treatment-eligible must be positive")
    if args.minimum_plan_similarity < 1:
        parser.error("--minimum-plan-similarity must be positive")
    if args.output.exists():
        parser.error(f"output exists; refusing to overwrite screening evidence: {args.output}")
    tasks = load_manifest(args.tasks)
    evaluation_hash = None
    if args.evaluator_manifest is not None:
        fail_to_pass = load_evaluation_test_ids(args.evaluator_manifest.resolve())
        missing = [task.task_id for task in tasks if task.task_id not in fail_to_pass]
        if missing:
            raise SystemExit("evaluator manifest misses task IDs: " + ", ".join(missing[:10]))
        tasks = tuple(replace(task, fail_to_pass=fail_to_pass[task.task_id]) for task in tasks)
        evaluation_hash = hashlib.sha256(args.evaluator_manifest.read_bytes()).hexdigest()
    ranked = rank_e6_tasks(tasks, limit=len(tasks), repo_cache=args.repo_cache)
    selected = ranked[:args.limit]
    eligible_count = sum(bool(item["test_aware_treatment_available"]) for item in ranked)
    eligible_rows = [item for item in ranked if item["test_aware_treatment_available"] is True]
    similarity_qualified_rows = [item for item in eligible_rows if item["plan_similarity_qualified"] is True]
    if args.repo_cache is None:
        selection_status = "not_checked"
    elif eligible_count < args.minimum_treatment_eligible:
        selection_status = "insufficient_treatment_eligible_tasks"
    else:
        selection_status = "minimum_eligibility_met"
    payload = {
        "schema_version": 3,
        "created_at": utc_now(),
        "task_manifest_sha256": hashlib.sha256(args.tasks.read_bytes()).hexdigest(),
        "task_count": len(tasks),
        "selection_method": (
            "inference_safe_issue_text_plus_allowlisted_FAIL_TO_PASS_metadata"
            if evaluation_hash else "inference_safe_issue_text_heuristics"
        ),
        "ranking_policy": (
            "treatment_eligible_then_test_and_issue_plan_similarity_then_hint_coverage"
        ),
        "gold_patch_fields_read": False,
        "evaluator_manifest_sha256": evaluation_hash,
        "fail_to_pass_task_count": sum(bool(task.fail_to_pass) for task in tasks),
        "all_issue_plan_signals_task_count": sum(
            all(_features(task)[0].values()) for task in tasks
        ),
        "human_review_required": True,
        "selection_status": selection_status,
        "base_test_sources_checked": args.repo_cache is not None,
        "minimum_treatment_eligible_required": args.minimum_treatment_eligible if args.repo_cache is not None else None,
        "minimum_plan_similarity_required": args.minimum_plan_similarity if args.repo_cache is not None else None,
        "test_aware_treatment_eligible_count": eligible_count if args.repo_cache is not None else None,
        "eligible_with_multiple_assertion_formats_count": sum(
            item["base_test_multiple_assertion_formats"] is True for item in eligible_rows
        ) if args.repo_cache is not None else None,
        "eligible_with_any_plan_similarity_signal_count": sum(
            any(item["features"].values()) for item in eligible_rows
        ) if args.repo_cache is not None else None,
        "eligible_with_all_plan_similarity_signals_count": sum(
            item["plan_similarity_qualified"] is True for item in eligible_rows
        ) if args.repo_cache is not None else None,
        "eligible_with_two_or_more_plan_similarity_signals_count": sum(
            item["plan_similarity_signal_count"] >= 2 for item in eligible_rows
        ) if args.repo_cache is not None else None,
        "plan_similarity_status": (
            "not_checked" if args.repo_cache is None
            else "minimum_similarity_met" if len(similarity_qualified_rows) >= args.minimum_plan_similarity
            else "insufficient_plan_similarity_tasks"
        ),
        "selected_test_aware_treatment_count": sum(
            item["test_aware_treatment_available"] is True for item in selected
        ) if args.repo_cache is not None else None,
        "selected_multiple_assertion_format_count": sum(
            item["base_test_multiple_assertion_formats"] is True for item in selected
        ) if args.repo_cache is not None else None,
        "selected_plan_similarity_qualified_count": sum(
            item["plan_similarity_qualified"] is True for item in selected
        ) if args.repo_cache is not None else None,
        "selected": selected,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"selected={len(selected)} manifest_tasks={len(tasks)} output={args.output}")
    if selection_status == "insufficient_treatment_eligible_tasks":
        print(
            f"insufficient test-aware cohort: eligible={eligible_count} "
            f"required={args.minimum_treatment_eligible}"
        )
        return 2
    if args.repo_cache is not None and payload["plan_similarity_status"] == "insufficient_plan_similarity_tasks":
        print(
            f"insufficient 13033-like cohort: qualified={len(similarity_qualified_rows)} "
            f"required={args.minimum_plan_similarity}"
        )
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
