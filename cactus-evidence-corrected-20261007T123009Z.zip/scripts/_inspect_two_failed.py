import json
import sys

task = sys.argv[1]
postfix_dir = sys.argv[2]
p = f'experiments/runs/{postfix_dir}/{task}/events.jsonl'
with open(p, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]
print(f'Total events: {len(events)}')

# 列出所有 select / plan / candidate / diagnose 调用
for e in events:
    t = e.get('type', '')
    seq = e.get('seq', '?')
    p2 = e.get('payload', {})
    if 'select' in t.lower() or 'plan' in t.lower() or 'candidate' in t.lower() or 'diagnose' in t.lower() or 'dual' in t.lower():
        if 'selected_site_ids' in p2:
            print(f'seq={seq} [{t}] selected_site_ids={p2.get("selected_site_ids")}')
        elif 'sites' in p2 and isinstance(p2.get('sites'), list):
            print(f'seq={seq} [{t}] sites={p2.get("sites")} reason={str(p2.get("reason"))[:120]}')
        elif 'selected_paths' in p2:
            print(f'seq={seq} [{t}] selected_paths={p2.get("selected_paths")}')
        elif t in ('v3_dual_insurance_result','prediction_exhausted','prediction_rejected','prediction_sites_rejected','plan_result','plan_proposed'):
            print(f'seq={seq} [{t}] {str(p2)[:250]}')