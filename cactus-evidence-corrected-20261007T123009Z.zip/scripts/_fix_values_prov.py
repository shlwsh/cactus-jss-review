import json
import hashlib
from pathlib import Path

# Fix publication_values.json.provenance.json
values_prov = json.loads(open('paper/data/publication_values.json.provenance.json').read())
sources_prov_file = Path('paper/publication_sources.json')
new_sources_hash = hashlib.sha256(sources_prov_file.read_bytes()).hexdigest()

for inp in values_prov.get('inputs', []):
    path_str = inp['path']
    if path_str == 'paper/publication_sources.json':
        old = inp['sha256']
        if old != new_sources_hash:
            print(f'Updating {path_str}: {old[:16]}... -> {new_sources_hash[:16]}...')
            inp['sha256'] = new_sources_hash
        else:
            print(f'OK {path_str}')
    else:
        path = Path(path_str)
        if path.is_file():
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if inp['sha256'] != actual:
                print(f'Updating {path_str}: {inp["sha256"][:16]}... -> {actual[:16]}...')
                inp['sha256'] = actual
            else:
                print(f'OK {path_str}')
        else:
            print(f'SKIP {path_str} (not found)')

open('paper/data/publication_values.json.provenance.json', 'w').write(json.dumps(values_prov, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Values provenance updated')
