"""Automated paper numbers and statistical consistency validation script.

Implements Section 26 of CACTUS Rectification Plan v2.
Checks consistency across:
- Derived result registry (experiments/derived/result_registry_v2.jsonl)
- Audit summary (artifacts/audit_v2/reclassified_outcomes_summary.json)
- Variants contract (artifacts/contracts/variant_diff_report.json)
- Analysis datasets (analysis/data/paired_task_results.csv)
- Paper tables (artifacts/tables/)
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def validate_paper_numbers(root: Path = ROOT) -> tuple[bool, list[str]]:
    errors: list[str] = []

    audit_summary_file = root / "artifacts" / "audit_v2" / "audit_summary.json"
    if not audit_summary_file.is_file():
        audit_summary_file = root / "artifacts" / "audit_v2" / "reclassified_outcomes_summary.json"
    registry_file = root / "experiments" / "derived" / "result_registry_v2.jsonl"
    variant_report_file = root / "artifacts" / "contracts" / "variant_diff_report.json"
    paired_csv_file = root / "analysis" / "data" / "paired_task_results.csv"

    # 1. Audit summary check
    if not audit_summary_file.is_file():
        errors.append(f"Audit summary missing in artifacts/audit_v2/")
        return False, errors

    try:
        audit_data = json.loads(audit_summary_file.read_text(encoding="utf-8"))
    except Exception as e:
        errors.append(f"Failed to parse audit summary: {e}")
        return False, errors

    total_runs = audit_data.get("total_sealed_runs") or audit_data.get("total_runs", 0)
    total_unique_tasks = audit_data.get("unique_tasks_evaluated") or audit_data.get("total_unique_tasks", 0)
    funnel = audit_data.get("funnel", {})
    fam_dist = audit_data.get("failure_family_distribution", {})

    if total_runs <= 0:
        errors.append(f"Total runs must be > 0, got {total_runs}")
    if total_unique_tasks <= 0:
        errors.append(f"Total unique tasks must be > 0, got {total_unique_tasks}")

    # 2. Failure family sum check
    fam_sum = sum(fam_dist.values())
    if fam_sum != total_unique_tasks:
        errors.append(
            f"Failure family sum mismatch: sum({fam_dist}) = {fam_sum} != total_unique_tasks ({total_unique_tasks})"
        )

    # 3. Funnel consistency
    if funnel.get("total_tasks") != total_unique_tasks:
        errors.append(
            f"Funnel total_tasks ({funnel.get('total_tasks')}) != total_unique_tasks ({total_unique_tasks})"
        )

    non_empty = funnel.get("non_empty_generation", 0)
    parsed = funnel.get("parsed_diff", 0)
    applied = funnel.get("applied_patch", 0)
    valid = funnel.get("evaluator_valid", 0)
    resolved = funnel.get("resolved", 0)

    # Monotonicity checks for generation funnel
    if not (non_empty <= total_unique_tasks and parsed <= non_empty and applied <= parsed and resolved <= valid):
        errors.append(
            f"Funnel monotonicity violated: total={total_unique_tasks}, non_empty={non_empty}, parsed={parsed}, applied={applied}, valid={valid}, resolved={resolved}"
        )

    # 4. Result registry consistency
    if registry_file.is_file():
        registry_lines = [line.strip() for line in registry_file.read_text(encoding="utf-8").splitlines() if line.strip()]
        if len(registry_lines) != total_runs:
            errors.append(
                f"Registry line count ({len(registry_lines)}) != total_runs ({total_runs})"
            )

    # 5. Variant contract check
    try:
        from cactus.experiments.variants import FROZEN_VARIANTS
        if len(FROZEN_VARIANTS) != 9:
            errors.append(f"Expected 9 defined frozen variants, got {len(FROZEN_VARIANTS)}")
    except Exception as e:
        errors.append(f"Failed to import FROZEN_VARIANTS: {e}")

    if variant_report_file.is_file():
        try:
            var_data = json.loads(variant_report_file.read_text(encoding="utf-8"))
            # Expect 6 ablation variants reported against base cactus_full
            expected_ablations = {
                "cactus_no_symbol_graph",
                "cactus_static_density",
                "cactus_no_ace",
                "cactus_no_budget_controller",
                "cactus_no_patch_normalizer",
                "cactus_no_failure_recovery",
            }
            if not expected_ablations.issubset(set(var_data.keys())):
                errors.append(f"Variant diff report missing expected ablations: {expected_ablations - set(var_data.keys())}")
        except Exception as e:
            errors.append(f"Failed to parse variant report: {e}")

    # 6. Paired dataset check
    if paired_csv_file.is_file():
        with paired_csv_file.open("r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            paired_rows = list(reader)
        if len(paired_rows) != total_runs:
            errors.append(
                f"Paired CSV rows ({len(paired_rows)}) != total_runs ({total_runs})"
            )

    is_valid = len(errors) == 0
    return is_valid, errors


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate paper numbers and statistical consistency.")
    parser.add_argument("--root", type=Path, default=ROOT, help="Project root directory.")
    args = parser.parse_args()

    print(f"[VALIDATE] Validating paper numbers under {args.root}...")
    is_valid, errors = validate_paper_numbers(args.root)
    if is_valid:
        print("[PASS] All paper metrics and statistical tables are consistent!")
        sys.exit(0)
    else:
        print(f"[FAIL] Found {len(errors)} consistency error(s):")
        for err in errors:
            print(f"  - {err}")
        sys.exit(1)


if __name__ == "__main__":
    main()
