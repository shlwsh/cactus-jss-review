"""Inventory all historical evidence without changing or upgrading any source.

The archive integrity verdict stays FAIL when historical bundles are defective.
Publication admission is an independent, stricter view; quarantine is never a
repair, an integrity PASS, or an owner override.
"""
from __future__ import annotations

import argparse
import csv
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from functools import lru_cache
from pathlib import Path

from cactus.governance.canonical import canonical_json
from cactus.governance.evidence_locations import iter_runs
from cactus.runner.bundle_validator import validate_bundle
from scripts.aggregate_lite50_results import _valid_evaluator

ROOT = Path(__file__).resolve().parents[1]


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_object(path: Path) -> dict:
    try:
        value = load(path)
        return value if isinstance(value, dict) else {}
    except (ValueError, OSError):
        return {}


@lru_cache(maxsize=32)
def _schema_validator(path: Path, digest: str):
    # jsonschema is an existing declared project dependency. No network refs.
    from jsonschema import Draft202012Validator
    schema = load(path)
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)


def schema_errors(root: Path, name: str, payload) -> list[str]:
    path = root / f"experiments/schemas/{name}.schema.json"
    validator = _schema_validator(path, sha(path))
    return ["schema:" + "/".join(map(str, error.path)) + ":" + error.validator
            for error in validator.iter_errors(payload)]


def derive(root: Path = ROOT) -> tuple[dict, list[dict], list[dict], list[dict]]:
    runs = []
    for logical, run in iter_runs(root):
        hashes = {logical + "/" + p.relative_to(run).as_posix(): sha(p) for p in sorted(run.rglob("*")) if p.is_file()}
        manifest = read_object(run / "run_manifest.json")
        raw = read_object(run / "raw/result.json")
        config = read_object(run / "resolved_config.json")
        errors = validate_bundle(run) if run.name.startswith("RUN-") else ["diagnostic_directory_no_formal_admission"]
        if manifest:
            errors.extend(schema_errors(root, "run_manifest", manifest))
        if raw:
            errors.extend(schema_errors(root, "raw_result", raw))
        if not errors and manifest.get("status") == "running":
            errors.append("unsealed_running_state")
        task = raw.get("data", {}).get("task_id") or config.get("task", {}).get("task_id") or manifest.get("task_id")
        reports = sorted((run / "evaluation").glob("*.json"))
        report = read_object(reports[0]) if len(reports) == 1 else {}
        # Report validity is observed independently of bundle admission.
        valid = _valid_evaluator(report, task)
        runs.append({"run_id": run.name, "path": logical,
                     "experiment_id": manifest.get("experiment_id"), "task_id": task,
                     "status": manifest.get("status"), "file_hashes": hashes,
                     "tree_sha256": hashlib.sha256(canonical_json(hashes).encode()).hexdigest(),
                     "integrity_status": "invalid" if errors else "verified",
                     "integrity_errors": sorted(set(errors)), "evaluator_valid": valid,
                     "evaluator_resolved": valid and report.get("resolved_instances") == 1,
                     "publication_admission": "not_established_by_archive_integrity"})
    by_run = {r["run_id"]: r for r in runs}

    progress = root / "analysis/phase_c_progress.jsonl"
    progress_rows = [json.loads(line) for line in progress.read_text(encoding="utf-8").splitlines() if line.strip()]
    latest_completed = {r["task_id"]: r for r in progress_rows if r.get("status") == "completed" and "task_id" in r}
    snapshot = root / "paper/data/final_task_outcomes.csv"
    with snapshot.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    tasks = []
    for row in rows:
        selected = latest_completed.get(row["task"], {})
        run = by_run.get(selected.get("run_id"), {})
        reasons = ["no_validated_terminal_attempt_chain", "no_publication_admission_record"]
        if not selected:
            reasons.append("no_matching_completed_progress_record")
        elif selected.get("timestamp", "").replace("T", " ").removesuffix("Z") != row["time"]:
            reasons.append("snapshot_progress_selection_mismatch")
        if not run:
            reasons.append("selected_run_unavailable")
        else:
            if run["integrity_status"] != "verified":
                reasons.append("selected_bundle_integrity_failure")
            if not run["evaluator_valid"]:
                reasons.append("selected_evaluator_not_valid")
            # A valid unresolved observation cannot be inferred from completed.
            if row["unresolved"] == "1" and not run["evaluator_valid"]:
                reasons.append("completed_was_conflated_with_unresolved")
            if row["resolved"] == "1" and not run["evaluator_resolved"]:
                reasons.append("snapshot_resolved_not_confirmed")
            if run.get("task_id") != row["task"]:
                reasons.append("selected_task_identity_mismatch")
        tasks.append({"task_id": row["task"], "snapshot_record": row,
                      "snapshot_record_sha256": hashlib.sha256(canonical_json(row).encode()).hexdigest(),
                      "progress_record": selected, "selected_run_id": selected.get("run_id"),
                      "selected_evaluator_valid": run.get("evaluator_valid", False),
                      "claim_status": "blocked", "exclusion_reasons": reasons})

    # Index every legacy registry and result file, including blocked material.
    sources = []
    registry_issues = []
    scope = [root / "experiments/derived", root / "results", root / "paper/data", root / "analysis"]
    for directory in scope:
        for path in sorted(directory.rglob("*")):
            if not path.is_file() or path.suffix not in {".json", ".jsonl", ".csv"}:
                continue
            if any(part.startswith("governance_") for part in path.parts) or "papers" in path.parts or "scholar" in path.parts:
                continue
            if path.name.startswith("publication_"):
                # Current publication derivatives have their own recursively
                # verified graph. Including them in an immutable archive index
                # would create a provenance cycle; this is not an admission.
                continue
            item = {"path": path.relative_to(root).as_posix(), "sha256": sha(path),
                    "publication_state": "not_admitted_by_presence_or_hash_alone"}
            if "registry" in path.name and path.suffix == ".jsonl":
                records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
                errors = [e for record in records for e in schema_errors(root, "result_record", record)]
                item["record_count"] = len(records)
                item["schema_error_count"] = len(errors)
                item["schema_error_types"] = dict(sorted(Counter(errors).items()))
                if errors:
                    registry_issues.append({"path": item["path"], "code": "legacy_registry_schema_not_publication_admissible", "count": len(errors)})
                else:
                    from cactus.governance.policy import derive_claim_status
                    ids = [record["result_id"] for record in records]
                    if len(ids) != len(set(ids)):
                        registry_issues.append({"path": item["path"], "code": "duplicate_registry_result_id"})
                    for record in records:
                        requested = record.get("publication", {}).get("claim_status", "blocked")
                        status, _ = derive_claim_status(record["evidence"], requested=requested)
                        if status != requested:
                            registry_issues.append({"path": item["path"], "code": "registry_policy_disagreement", "result_id": record["result_id"]})
            sources.append(item)
    summary = {"schema_version": "1.0", "archive_integrity": "FAIL" if any(r["integrity_errors"] for r in runs) else "PASS",
               "run_directory_count": len(runs), "canonical_run_count": sum(r["run_id"].startswith("RUN-") for r in runs),
               "verified_bundle_count": sum(not r["integrity_errors"] for r in runs),
               "invalid_directory_count": sum(bool(r["integrity_errors"]) for r in runs),
               "integrity_reason_counts": dict(sorted(Counter(e for r in runs for e in r["integrity_errors"]).items())),
               "historical_snapshot_rows": len(tasks), "historical_snapshot_admitted_rows": 0,
               "historical_snapshot_exclusion_counts": dict(sorted(Counter(e for r in tasks for e in r["exclusion_reasons"]).items())),
               "indexed_result_files": len(sources),
               "registry_issues": registry_issues,
               "policy": "immutable_archive; fail_closed_admission; no_reconstructed_measurements; no_owner_overrides",
               "snapshot_binding": {"path": snapshot.relative_to(root).as_posix(), "sha256": sha(snapshot)},
               "progress_binding": {"path": progress.relative_to(root).as_posix(), "sha256": sha(progress)},
               "selection_policy_binding": {"path": "paper/final_outcome_selection_policy.md", "sha256": sha(root / "paper/final_outcome_selection_policy.md")}}
    return summary, runs, tasks, sources


def generate(output: Path) -> dict:
    if output.exists():
        raise FileExistsError("refusing to overwrite a governance snapshot")
    summary, runs, tasks, sources = derive()
    output.mkdir(parents=True)
    for name, data in [("run_inventory.jsonl", runs), ("historical_task_admission.jsonl", tasks), ("source_index.jsonl", sources)]:
        (output / name).write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in data), encoding="utf-8", newline="\n")
    summary["generated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    from scripts.artifact_provenance import write
    inputs = [ROOT / r["path"] for run in runs for r in [{"path": p} for p in run["file_hashes"]]]
    inputs += [ROOT / summary[k]["path"] for k in ("snapshot_binding", "progress_binding", "selection_policy_binding")]
    inputs += list((ROOT / "experiments/schemas").glob("*.schema.json"))
    inputs += [ROOT / "src/cactus/runner/bundle_validator.py", ROOT / "scripts/aggregate_lite50_results.py",
               ROOT / "src/cactus/governance/admission.py",
               ROOT / "src/cactus/governance/policy.py", ROOT / "configs/policies/publication_policy.json"]
    write(output / "run_inventory.jsonl", inputs, Path(__file__), transform={"policy": summary["policy"]}, kind="derived_dataset")
    for name in ("summary.json", "historical_task_admission.jsonl", "source_index.jsonl"):
        write(output / name, [output / "run_inventory.jsonl", *[ROOT / r["path"] for r in sources]], Path(__file__), transform={"policy": summary["policy"]}, kind="derived_dataset")
    return summary


def verify(output: Path) -> dict:
    expected, runs, tasks, sources = derive()
    actual = load(output / "summary.json")
    actual.pop("generated_at")
    if actual != expected:
        raise ValueError("corpus summary changed; regenerate a new immutable snapshot")
    for name, data in [("run_inventory.jsonl", runs), ("historical_task_admission.jsonl", tasks), ("source_index.jsonl", sources)]:
        actual_rows = [json.loads(line) for line in (output / name).read_text(encoding="utf-8").splitlines()]
        if actual_rows != data:
            raise ValueError(f"corpus drift: {name}")
    return {"status": "PASS", "archive_integrity": expected["archive_integrity"], "policy": expected["policy"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    print(json.dumps(verify(args.output) if args.verify else generate(args.output), ensure_ascii=False))
