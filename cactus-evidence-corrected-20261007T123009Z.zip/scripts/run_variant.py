"""Run an offline context-selection variant on development tasks.

This command deliberately produces selection evidence only. It never invokes a
model, evaluator, gateway, or billing service, so its output cannot be used as
a repair-result RUN or a publication performance result.
"""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path

from cactus.domain.models import ContextUnit
from cactus.retrieval.lexical import lexical_candidates
from cactus.retrieval.marginal_utility import canonical_bundle_hash, select_marginal_utility
from cactus.retrieval.static_density import select_static_density
from cactus.retrieval.scoring import score_candidates
from cactus.selection.maximal_context import select_maximal_context
from cactus.task.parser import parse_task


ROOT = Path(__file__).resolve().parents[1]
DEV_SET = ROOT / "data" / "fixtures" / "dev_set" / "tasks.jsonl"
VARIANTS = ("maximal_context", "lexical_bm25", "cactus_full", "cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density")


def _display_path(path: Path) -> str:
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return f"external/{path.name}"


def _units(record: dict[str, object]) -> tuple[ContextUnit, ...]:
    normalized = []
    for raw in record["units"]:
        payload = dict(raw)
        provenance = dict(payload.pop("provenance", {}))
        for key in ("lexical_score", "coverage_keys", "parent_unit_id"):
            if key in payload:
                provenance[key] = payload.pop(key)
        payload["provenance"] = provenance
        normalized.append(ContextUnit(**payload))
    return tuple(normalized)


def _select(variant: str, units: tuple[ContextUnit, ...], query: str, budget: int):
    intent = parse_task(query)
    lexical = dict(lexical_candidates(units, intent))
    raw_distances = intent.extra.get("graph_distances", {}) if hasattr(intent, "extra") else {}
    graph_distances = {str(key): int(value) for key, value in raw_distances.items()} if isinstance(raw_distances, dict) else {}
    score_weights = {"graph": 0.0} if variant == "cactus_no_symbol_graph" else None
    scores = score_candidates(units, intent, lexical=lexical, graph_distances=graph_distances, weights=score_weights)
    if variant == "maximal_context":
        return select_maximal_context(units, budget=budget, mentioned_files=intent.mentioned_files)
    if variant == "lexical_bm25":
        return select_static_density(units, lexical, budget=budget).selected_unit_ids
    if variant == "cactus_static_density":
        return select_static_density(units, scores, budget=budget).selected_unit_ids
    if variant == "cactus_no_budget_controller":
        return select_marginal_utility(units, scores, budget=sum(unit.token_count for unit in units)).selected_unit_ids
    if variant in {"cactus_full", "cactus_no_symbol_graph", "cactus_no_failure_recovery"}:
        return select_marginal_utility(units, scores, budget=budget, weights={"new_file_lambda": 0.10} if variant != "cactus_no_failure_recovery" else {}).selected_unit_ids
    raise ValueError(f"unknown variant: {variant}")


def run(variant: str, *, dev_set: Path = DEV_SET, output: Path | None = None, limit: int = 10, budget: int = 180) -> dict[str, object]:
    if variant not in VARIANTS:
        raise ValueError(f"variant must be one of {', '.join(VARIANTS)}")
    if limit < 1 or budget < 0:
        raise ValueError("limit must be positive and budget must be non-negative")
    output = output or ROOT / "analysis" / f"variant_{variant}_selection.jsonl"
    output.parent.mkdir(parents=True, exist_ok=True)
    with dev_set.open(encoding="utf-8") as handle:
        records = [json.loads(line) for line in handle if line.strip()][:limit]
    rows = []
    for record in records:
        units = _units(record)
        selected_ids = tuple(_select(variant, units, str(record["query"]), budget))
        by_id = {unit.unit_id: unit for unit in units}
        selected = [by_id[unit_id] for unit_id in selected_ids]
        used = sum(unit.token_count for unit in selected)
        rows.append({"task_id": record["task_id"], "variant": variant, "budget": budget, "selected_unit_ids": list(selected_ids), "selected_tokens": used, "selected_files": len({unit.path for unit in selected}), "selected_chunks": len(selected), "fragmentation_index": len(selected) / max(1.0, used / 1000.0), "bundle_hash": canonical_bundle_hash(selected), "evidence_status": "selection_only", "model_calls": 0, "evaluator_calls": 0})
    with output.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    summary = {"schema_version": "2.1", "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "variant": variant, "dev_set": _display_path(dev_set), "task_count": len(rows), "budget": budget, "output": _display_path(output), "evidence_status": "selection_only", "model_calls": 0, "evaluator_calls": 0}
    (output.with_suffix(".summary.json")).write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", required=True, choices=VARIANTS)
    parser.add_argument("--dev-set", type=Path, default=DEV_SET)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--budget", type=int, default=180)
    args = parser.parse_args()
    print(json.dumps(run(args.variant, dev_set=args.dev_set, output=args.output, limit=args.limit, budget=args.budget), ensure_ascii=False))
