"""Deep-dive a run: show full context + model reasoning."""
import json
import sys
from pathlib import Path

run = Path(sys.argv[1])
events = [json.loads(l) for l in (run / "trace" / "events.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]

for e in events:
    t = e["type"]
    p = e["payload"]
    if t == "model_call":
        print(f"=== model_call @ {e['utc_ts']} ===")
        print(f"  max_tokens={p.get('max_tokens')}, in={p.get('input_tokens')}, out={p.get('output_tokens')}")
        print(f"  finish={p.get('finish_reason')}")
        # Try to find prompt / response
        for k in ("prompt", "messages", "user_message", "system_message"):
            if k in p:
                val = p[k]
                if isinstance(val, list):
                    for m in val:
                        if isinstance(m, dict):
                            c = m.get("content", "")
                            if isinstance(c, str):
                                print(f"  [{k}.{m.get('role','?')}]: {c[:800]}")
                                if len(c) > 800:
                                    print(f"      ... ({len(c)} chars total)")
                else:
                    print(f"  [{k}]: {str(val)[:800]}")
        resp = p.get("response_text", "")
        print(f"\n  FULL RESPONSE ({len(resp)} chars):")
        print(f"  {resp}")
        print()
        # Show file list of context
        files = p.get("context_files", [])
        if files:
            print(f"  context_files: {files}")
        sel = p.get("context_selected_units", [])
        if sel:
            print(f"  context_selected_units ({len(sel)}):")
            for u in sel[:30]:
                print(f"    - {u}")
    elif t == "context_selected":
        sel = p.get("selected", [])
        toks = p.get("tokens", 0)
        print(f"=== context_selected @ {e['utc_ts']}: {len(sel)} units, {toks} tokens ===")
        for u in sel[:50]:
            if isinstance(u, dict):
                p_u = u.get("path", "?")
                s_u = u.get("symbol", u.get("unit_id", "?"))
                tt = u.get("token_count", u.get("tokens", "?"))
                print(f"    {p_u}::{s_u} ({tt}t)")
            else:
                print(f"    {u}")
    elif t == "prediction_rejected":
        print(f"=== prediction_rejected @ {e['utc_ts']} ===")
        for k, v in p.items():
            if k == "reason":
                print(f"  reason: {v[:600]}")
            else:
                print(f"  {k}: {str(v)[:300]}")
    elif t == "prediction_accepted":
        print(f"=== prediction_accepted @ {e['utc_ts']}: attempt={p.get('attempt')} ===")
