"""Dump format_call source segment to clarify the AST position."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import importlib.util
spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

import ast

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]

ws = Path(tempfile.mkdtemp(prefix="cactus-diag-fc-"))
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)

source = (repo_path / "astropy" / "timeseries" / "core.py").read_text(encoding="utf-8")
source_lines = source.splitlines(keepends=True)

candidates = mod._find_misleading_raise_nodes(source, "astropy/timeseries/core.py")

def _score(c):
    m, r, fc = c
    idx0_count = sum(1 for a in fc.args if isinstance(a, ast.Subscript) and isinstance(a.slice, ast.Constant) and a.slice.value == 0)
    has_fmt = any(isinstance(a, ast.Constant) and isinstance(a.value, str) and "{}" in a.value for a in fc.args)
    return idx0_count * 10 + (1 if has_fmt else 0)

candidates = sorted(candidates, key=_score, reverse=True)

for m, r, fc in candidates:
    print(f"\n=== raise @ line {r.lineno} ===", flush=True)
    fc_lno = fc.lineno
    fc_col = fc.col_offset
    fc_end_lno = getattr(fc, "end_lineno", fc_lno)
    fc_end_col = getattr(fc, "end_col_offset", None)
    print(f"  format_call: lno={fc_lno}, col={fc_col}, end_lno={fc_end_lno}, end_col={fc_end_col}", flush=True)
    # Print source lines with marker
    for ln in range(max(1, fc_lno - 1), min(len(source_lines), fc_end_lno + 2)):
        text = source_lines[ln - 1]
        marker = "<<<" if ln == fc_lno else ""
        print(f"  L{ln:3d}: {text.rstrip()!r} {marker}", flush=True)
    # Extract fc slice
    if fc_lno == fc_end_lno:
        line_text = source_lines[fc_lno - 1]
        if fc_end_col is not None:
            text = line_text[fc_col:fc_end_col]
            print(f"  slice[{fc_col}:{fc_end_col}] = {text!r}", flush=True)
    else:
        chunks = [source_lines[fc_lno - 1][fc_col:]]
        for ln in range(fc_lno, fc_end_lno - 1):
            chunks.append(source_lines[ln])
        last = source_lines[fc_end_lno - 1]
        chunks.append(last[:fc_end_col] if fc_end_col is not None else last)
        text = "".join(chunks)
        print(f"  multiline slice = {text!r}", flush=True)
    print(f"  fc.args (ast.unparse): {[ast.unparse(a) for a in fc.args]}", flush=True)

import shutil
shutil.rmtree(ws, ignore_errors=True)
