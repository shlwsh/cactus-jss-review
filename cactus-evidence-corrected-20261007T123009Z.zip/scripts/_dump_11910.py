"""Detailed 11910 events."""
import json
with open('experiments/runs/ITER3-11910-20261004T065000Z/django__django-11910/events.jsonl', encoding='utf-8') as f:
    for line in f:
        e = json.loads(line)
        t = e.get('type','')
        p = e.get('payload',{})
        if t in ('prediction_sites_rejected','prediction_rejected','v3_dual_insurance_result','prediction_exhausted','repair_sites'):
            print(f'seq={e.get("seq")} t={t}')
            for k,v in p.items():
                v_str = str(v)[:400] if not isinstance(v,(int,float,bool,type(None))) else v
                print(f'  {k}: {v_str}')
            print('---')
