"""Debug the helper insertion indentation for 13033."""
from __future__ import annotations

import ast
import importlib.util
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT))

spec = importlib.util.spec_from_file_location("mod", str(ROOT / "scripts" / "cactus_swebench_predict.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

from cactus.adapters.benchmark import load_manifest

task = next(t for t in load_manifest(ROOT / "json" / "cactus_tasks_inference_safe.jsonl")
             if t.task_id == "astropy__astropy-13033")

ws = Path(tempfile.mkdtemp(prefix="dbg_indent_"))
co = ws / "repository"
mirror = ROOT / "experiments" / "repo_cache" / "astropy__astropy.git"
subprocess.run(["git", "clone", "--no-checkout", str(mirror), str(co)], cwd=str(ws), check=True, capture_output=True)
subprocess.run(["git", "-C", str(co), "checkout", "--detach", task.base_commit], cwd=str(ws), check=True, capture_output=True)

src = (co / "astropy/timeseries/core.py").read_text(encoding="utf-8")
tree = ast.parse(src)

for cls in ast.walk(tree):
    if not isinstance(cls, ast.ClassDef) or cls.name != "BaseTimeSeries":
        continue
    for child in cls.body:
        if not isinstance(child, ast.FunctionDef) or child.name != "_check_required_columns":
            continue

        # Show the actual method-body indent from raw source
        print("=== Method _check_required_columns ===")
        mdef = child
        print(f"  mdef.lineno = {mdef.lineno}")
        print(f"  mdef.col_offset = {mdef.col_offset}")

        # First statement inside method body
        first = mdef.body[0]
        print(f"  first.lineno = {first.lineno}")
        print(f"  first.col_offset = {first.col_offset}")
        print(f"  method_body_indent = {first.col_offset}")

        # What the helper template produces
        helper_body = mod._INNER_HELPER_TEMPLATE.format(helper_name="as_scalar_or_list_str")
        print(f"\n[helper_body unindented]\n{helper_body}")

        # What the helper should look like with correct indent
        print(f"\n[helper_body with indent={first.col_offset} spaces]")
        indent = " " * first.col_offset
        for line in helper_body.splitlines():
            print(f"  {indent}{line}" if line.strip() else f"  ")

        # What ast.get_source_segment returns for the first statement
        first_src = ast.get_source_segment(src, first)
        print(f"\n[ast.get_source_segment(first)]\n{repr(first_src)}")

        # The CURRENT algorithm:
        source_lines = src.splitlines(keepends=True)
        first_raw_line = source_lines[first.lineno - 1]
        current_indent = first_raw_line[:first.col_offset]
        print(f"\n[current_indent (from raw line)] = {repr(current_indent)} (len={len(current_indent)})")

        # What the NEW algorithm should produce:
        # The dedented first statement should have its INNER indent preserved, not MIN indent.
        # The correct indent for `return` is: method_body_indent + 4 (one level deeper).
        correct_return_indent = first.col_offset + 4
        print(f"\n[correct return indent] = {correct_return_indent} spaces (method_body + 4)")

        # Show what the current _build_template_edit_for_helper_insert produces
        result = mod._build_template_edit_for_helper_insert(src, child, "as_scalar_or_list_str")
        print(f"\n[current replacement]\n{result['replacement']}")
        break
    break
