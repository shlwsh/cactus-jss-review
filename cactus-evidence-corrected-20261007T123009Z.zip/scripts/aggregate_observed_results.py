"""Aggregate sealed CACTUS RUN bundles into deterministic task-level metrics."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable


PRIMARY_VARIANTS = {"maximal_context", "lexical_bm25", "cactus_full"}
ABLATION_VARIANTS = {
    "cactus_no_symbol_graph",
    "cactus_no_budget_controller",
    "cactus_no_failure_recovery",
    "cactus_static_density",
}
FIELDS = (
    "run_id",
    "experiment_id",
    "task_id",
    "variant",
    "run_status",
    "evaluator_valid",
    "canonical_outcome",
    "resolved_instances",
    "completed_instances",
    "error_instances",
    "input_tokens",
    "output_tokens",
    "verified_cost",
    "bundle_sha256",
)


def _json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _task_id(bundle: Path, manifest: dict[str, Any], raw: dict[str, Any]) -> str:
    data = raw.get("data") if isinstance(raw.get("data"), dict) else {}
    task = data.get("task_id") or manifest.get("task_id") or manifest.get("instance_id")
    if task:
        return str(task)
    config = _json(bundle / "resolved_config.json")
    task_data = config.get("task") if isinstance(config.get("task"), dict) else {}
    return str(task_data.get("task_id", ""))


def _evaluation(bundle: Path) -> dict[str, Any]:
    reports = sorted((bundle / "evaluation").glob("*.json")) if (bundle / "evaluation").is_dir() else []
    return _json(reports[0]) if len(reports) == 1 else {}


def _tokens(bundle: Path) -> tuple[int, int]:
    input_tokens = output_tokens = 0
    trace = bundle / "trace" / "events.jsonl"
    if not trace.is_file():
        return 0, 0
    for line in trace.read_text(encoding="utf-8").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") != "model_call":
            continue
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        input_tokens += int(payload.get("input_tokens") or 0)
        output_tokens += int(payload.get("output_tokens") or 0)
    return input_tokens, output_tokens


def _cost(bundle: Path) -> str:
    billing = _json(bundle / "billing" / "litellm_spend.json")
    if billing.get("status") != "verified_cost":
        return ""
    value = billing.get("total_spend", billing.get("spend"))
    return "" if value in (None, "") else str(float(value))


def _outcome(manifest: dict[str, Any], report: dict[str, Any]) -> tuple[str, bool]:
    if not report:
        return "INCOMPLETE" if manifest.get("status") != "completed" else "EVALUATOR_ERROR", False
    infra = any(int(report.get(field, 0) or 0) > 0 for field in ("infra_failure_instances", "ambiguous_failure_instances", "unstopped_instances"))
    if infra or report.get("unstopped_containers"):
        return "EVALUATOR_ERROR", False
    completed = int(report.get("completed_instances", 0) or 0)
    resolved = int(report.get("resolved_instances", 0) or 0)
    errors = int(report.get("error_instances", 0) or 0)
    if completed <= 0 or errors > 0:
        return "EVALUATOR_ERROR", False
    return ("VALID_RESOLVED" if resolved > 0 else "VALID_UNRESOLVED"), True


def _bundle_sha256(bundle: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(path for path in bundle.rglob("*") if path.is_file() and path.name != "checksums.sha256"):
        digest.update(path.relative_to(bundle).as_posix().encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def rows(runs_root: Path, *, experiment_id: str | None = None) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    for bundle in sorted(path for path in runs_root.glob("RUN-*") if path.is_dir()):
        manifest = _json(bundle / "run_manifest.json")
        if not manifest or (experiment_id and manifest.get("experiment_id") != experiment_id):
            continue
        config = _json(bundle / "resolved_config.json")
        raw = _json(bundle / "raw" / "result.json")
        report = _evaluation(bundle)
        variant = str(config.get("variant") or manifest.get("variant") or "")
        task_id = _task_id(bundle, manifest, raw)
        outcome, valid = _outcome(manifest, report)
        input_tokens, output_tokens = _tokens(bundle)
        output.append({
            "run_id": str(manifest.get("run_id") or bundle.name),
            "experiment_id": str(manifest.get("experiment_id", "")),
            "task_id": task_id,
            "variant": variant,
            "run_status": str(manifest.get("status", "")),
            "evaluator_valid": "1" if valid else "0",
            "canonical_outcome": outcome,
            "resolved_instances": str(int(report.get("resolved_instances", 0) or 0)),
            "completed_instances": str(int(report.get("completed_instances", 0) or 0)),
            "error_instances": str(int(report.get("error_instances", 0) or 0)),
            "input_tokens": str(input_tokens),
            "output_tokens": str(output_tokens),
            "verified_cost": _cost(bundle),
            "bundle_sha256": _bundle_sha256(bundle),
        })
    return output


def _write(path: Path, records: Iterable[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)


def aggregate(runs_root: Path, output_dir: Path, *, experiment_id: str | None = None) -> dict[str, Any]:
    all_rows = rows(runs_root, experiment_id=experiment_id)
    _write(output_dir / "task_level_metrics.csv", all_rows)
    _write(output_dir / "main_task_level_metrics.csv", (row for row in all_rows if row["variant"] in PRIMARY_VARIANTS))
    _write(output_dir / "ablation_results.csv", (row for row in all_rows if row["variant"] in ABLATION_VARIANTS))
    summary = {
        "schema_version": "2.1",
        "runs_root": runs_root.as_posix(),
        "experiment_id": experiment_id,
        "row_count": len(all_rows),
        "variants": sorted({row["variant"] for row in all_rows if row["variant"]}),
        "valid_rows": sum(row["evaluator_valid"] == "1" for row in all_rows),
        "status": "observed" if all_rows else "pending_evidence",
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "aggregation_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, default=Path("experiments/runs"))
    parser.add_argument("--output-dir", type=Path, default=Path("results"))
    parser.add_argument("--experiment-id")
    args = parser.parse_args()
    print(json.dumps(aggregate(args.runs, args.output_dir, experiment_id=args.experiment_id), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
