import json
import sys
from pathlib import Path

# Add src to sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "src"))

from cactus.runner.bundle_validator import validate_bundle

def main():
    progress_file = REPO_ROOT / "analysis" / "phase_c_progress.jsonl"
    if not progress_file.exists():
        print("Progress file not found.")
        sys.exit(1)
    
    lines = [json.loads(l) for l in progress_file.read_text(encoding="utf-8").strip().split("\n") if l.strip()]
    runs_dir = REPO_ROOT / "experiments" / "runs"
    
    total = len(lines)
    errors = []
    
    for item in lines:
        run_id = item["run_id"]
        bundle_path = runs_dir / run_id
        if not bundle_path.exists():
            errors.append((run_id, ["Bundle path does not exist"]))
            continue
        errs = validate_bundle(bundle_path)
        if errs:
            errors.append((run_id, errs))
            
    print(f"Validated {total} runs.")
    print(f"Error count: {len(errors)}")
    if errors:
        for r, es in errors:
            print(f"RUN {r}: {es}")
        sys.exit(1)
    else:
        print("ALL RUN BUNDLES ARE 100% VALID!")

if __name__ == "__main__":
    main()
