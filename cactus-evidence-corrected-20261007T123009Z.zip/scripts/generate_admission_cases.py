"""Generate real evaluator-valid, evidence-inadmissible case chains read-only."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from cactus.governance.admission import read_json
from scripts.import_formal_run_bundles import inventory_row
from scripts.artifact_provenance import write


def generate(output: Path):
    config = read_json(ROOT / 'paper/publication_sources.json')
    inventory = ROOT / config['sources']['retry_inventory']['path']
    rows = [json.loads(line) for line in inventory.read_text().splitlines()]
    eligible = [r for r in rows if r['evaluator_valid'] and 'contract_driver_source_hash_mismatch' in r['exclusion_reasons']]
    chosen = [eligible[0], next(r for r in eligible if r['task_id'] != eligible[0]['task_id'])]
    cases, inputs = [], [inventory, ROOT / 'src/cactus/governance/admission.py']
    for row in chosen:
        bundle = ROOT / row['run_path']; contract_path = ROOT / row['contract_path']
        actual = inventory_row(ROOT, bundle, contract_path, read_json(contract_path))
        if actual != row: raise ValueError('case inventory drift')
        raw = read_json(bundle / 'raw/result.json')
        cases.append({k:row[k] for k in ['run_id','task_id','experiment_id','source_commit','declared_driver_sha256',
                      'source_driver_sha256','contract_sha256','bundle_tree_sha256','evaluator_valid','resolved','admitted','exclusion_reasons']})
        cases[-1]['raw_evaluator_valid'] = raw['data']['evaluator_valid']
        cases[-1]['raw_resolved'] = raw['data']['resolved']
        inputs += [contract_path, bundle / 'raw/result.json', bundle / 'run_manifest.json',
                   *sorted((bundle / 'evaluation').glob('*.json'))]
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps({'schema_version':'1.0','generated_at':datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
                                'selection':'first two lexicographically inventoried evaluator-valid driver conflicts with distinct task IDs; illustrative, not prevalence estimates',
                                'cases':cases},ensure_ascii=False,indent=2)+'\n')
    write(output,inputs,Path(__file__),transform={'activity':'read-only reconstruction of real evidence chains from retained objects'},kind='derived_dataset')
    return cases


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path,required=True)
    print(json.dumps(generate(parser.parse_args().output),indent=2))
