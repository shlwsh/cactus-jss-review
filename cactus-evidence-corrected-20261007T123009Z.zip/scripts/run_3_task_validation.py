#!/usr/bin/env python3
"""Single-task formal eval runner with per-task image lifecycle.

Strategy (Owner 决策 2026-09-20):
- 3 tasks serial: astropy-12907 → astropy-13033 → astropy-13236
- Per task: pull → warmup → run_campaign → bundle sealed → docker rmi
- Each task's docker image is removed after RUN bundle is sealed
- Stop on first task that returns completed=False (Owner: "保证成功")

This script is the entry point. It does NOT itself run agents. It invokes
``scripts/run_swebench_campaign.py`` per task so that each task gets its own
RunBundle under experiments/runs/RUN-*/. Image lifecycle is enforced here
because the runner's image cleanup only removes eval images SWE-bench reports
as unremoved; it does not delete the per-task base image we pulled.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]  # .../acm/scripts/run_3_task_validation.py → .../acm
CONTRACT = REPO / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V2-OWNER-20260922.json"
APPROVAL = REPO / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V2-OWNER-20260922.session_authorization.json"
TASK_MANIFEST = REPO / "json/cactus_tasks_inference_safe.jsonl"
MODEL_CONFIG = REPO / "configs/models/litellm_local.json"
RUNNER = REPO / "scripts/run_swebench_campaign.py"
OUTPUT_ROOT = REPO / "experiments/runs"
REPO_CACHE = REPO / "experiments/repo_cache"

# Owner-selected 3 astropy tasks (verified in eval_* contract images)
TASKS = ["psf__requests-2317", "pytest-dev__pytest-10081", "pytest-dev__pytest-10356"]

LOCAL_DATASET = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
DATASET = str(LOCAL_DATASET) if LOCAL_DATASET.exists() else "SWE-bench/SWE-bench_Verified"


def _docker_pull(image_ref: str, timeout_sec: int = 600) -> tuple[bool, bool]:
    """Pull with --platform linux/amd64 (ARM64 host uses QEMU).

    Returns (success, was_cached).  was_cached=True means the image was
    already present locally and no new layers were downloaded; the caller
    should NOT delete this image after the task to preserve the cache for
    subsequent tasks.
    """
    # First check: is it already local?
    check = subprocess.run(
        ["docker", "image", "inspect", image_ref, "--format={{.Id}}"],
        capture_output=True, text=True, timeout=10, check=False,
    )
    was_cached = check.returncode == 0

    if was_cached:
        # Digest check first to confirm it matches contract before using
        print(f"[PULL-CACHED] {image_ref} (already local)", flush=True)
        return True, True

    # Not cached — pull
    cmd = ["docker", "pull", "--platform", "linux/amd64", image_ref]
    print(f"[PULL-NEW] {' '.join(cmd)}", flush=True)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_sec)
    print(result.stdout[-500:] if result.stdout else "")
    if result.returncode != 0:
        print(f"[PULL-FAIL] {result.stderr.strip()[:500]}", flush=True)
        return False, False
    print(f"[PULL-OK] {image_ref} (newly downloaded)", flush=True)
    return True, False  # was_cached=False → safe to delete after task


def _docker_warmup(image_ref: str, task_id: str) -> bool:
    """Smoke-test image boots; trigger QEMU JIT cache.

    Writes the script to a temp file to avoid shell f-string expansion of
    Python f-string placeholders; the f-string in the script body would
    otherwise be expanded by the outer shell before reaching Python.
    """
    import tempfile
    # IMPORTANT: do NOT use an f-string here.  f-strings are evaluated by
    # *this* Python interpreter at write time, which would interpolate
    # `{task_id}` to its current value.  The literal text we want the
    # container's Python interpreter to see must come from a plain string.
    body = (
        "import sys, platform\n"
        "TASK_ID = 'TASK_PLACEHOLDER'\n"
        "print('warmup ok task=' + TASK_ID + ' py=' + str(sys.version_info[:3]) + ' arch=' + platform.machine(), flush=True)\n"
    ).replace("TASK_PLACEHOLDER", task_id)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(body)
        script_path = f.name
    cmd = ["docker", "run", "--rm", "--platform", "linux/amd64",
           "-v", f"{script_path}:/warmup.py:ro",
           image_ref, "python", "/warmup.py"]
    print(f"[WARMUP] {' '.join(cmd)}", flush=True)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        print(f"[WARMUP] exit={result.returncode} stdout={result.stdout.strip()}")
        if result.returncode != 0:
            print(f"[WARMUP-STDERR] {result.stderr.strip()[:300]}")
            return False
        return True
    except subprocess.TimeoutExpired:
        print("[WARMUP-TIMEOUT]")
        return False
    finally:
        try:
            os.unlink(script_path)
        except OSError:
            pass


def _docker_rmi(image_ref: str, *, force: bool = True) -> bool:
    """Force-remove image after RUN bundle sealed.

    Returns True if image was removed; False if it was not present.
    Best-effort: never raises.
    """
    cmd = ["docker", "rmi", "--force" if force else image_ref]
    print(f"[RMI] {' '.join(cmd)}", flush=True)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        print("[RMI-TIMEOUT]")
        return False
    print(f"[RMI] exit={result.returncode}")
    if result.stdout.strip():
        print(f"[RMI-STDOUT] {result.stdout.strip()[:200]}")
    if result.returncode != 0 and result.stderr.strip():
        print(f"[RMI-STDERR] {result.stderr.strip()[:200]}")
    return result.returncode == 0


def _lookup_image(contract: dict, task_id: str) -> tuple[str, str] | None:
    """Find image_ref for task_id via contract images catalog.

    SWE-bench publishes each eval image tagged `:latest`; the contract
    records the immutable digest but the on-registry pull tag is always
    `latest` (the digest tag form is a SWE-bench convention but registry
    refuses it as a tag).  We pull by `:latest` and verify the digest
    afterward via `RepoDigests` to enforce contract integrity.
    """
    tasks = [json.loads(l) for l in open(TASK_MANIFEST)]
    # match by eval_001 order (first 3 = first 3 tasks in JSONL)
    task_list = [t["task_id"] for t in tasks]
    if task_id not in task_list:
        return None
    index = task_list.index(task_id)
    eval_key = f"eval_{index + 1:03d}"
    entry = contract["images"].get(eval_key)
    if not entry:
        return None
    repository = entry["repository"]
    # SWE-bench publishes each eval image as `<repository>:latest`; the
    # contract records the immutable digest separately.  Pulling by `:latest`
    # and then verifying RepoDigests against the contract digest is the
    # only working pattern (the digest-as-tag form is rejected by the
    # registry).
    image_ref = f"{repository}:latest"
    digest = entry["digest"]
    return image_ref, digest


def _verify_digest(image_ref: str, expected: str) -> bool:
    """Verify pulled image digest matches contract entry."""
    result = subprocess.run(
        ["docker", "image", "inspect", image_ref, "--format={{.Id}}"],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        print(f"[DIGEST-CHECK-FAIL] {result.stderr.strip()[:200]}")
        return False
    # The image id from `inspect` is the local ID, not the registry digest.
    # We compare via RepoDigests.
    result2 = subprocess.run(
        ["docker", "image", "inspect", image_ref, "--format={{json .RepoDigests}}"],
        capture_output=True, text=True, timeout=30,
    )
    digests = json.loads(result2.stdout) if result2.stdout.strip() else []
    expected_no_prefix = expected.replace("sha256:", "")
    for d in digests:
        if d.endswith(f"@sha256:{expected_no_prefix}"):
            print(f"[DIGEST-MATCH] {expected}")
            return True
    print(f"[DIGEST-MISMATCH] expected={expected} got={digests}")
    return False


def run_one_task(task_id: str, contract: dict, *, campaign_id: str | None = None, variant: str = "cactus_full", dry_run: bool = False) -> bool:
    """Run one task with full lifecycle. Returns True on completed status.

    Per-project规范:
    - Image lifecycle: pull (or cache-hit) → warmup → eval → archive → rmi (if newly downloaded)
    - Archive: RUN bundle lands at experiments/runs/RUN-*/, validated via manifest
    - Data governance: bundle is immutable; no hand-editing after seal
    """
    lookup = _lookup_image(contract, task_id)
    if not lookup:
        print(f"[TASK-NOT-IN-CONTRACT] {task_id}")
        return False
    image_ref, expected_digest = lookup
    print(f"\n========== TASK: {task_id} ==========")
    print(f"  image_ref    : {image_ref}")
    print(f"  expected_sha : {expected_digest}")

    # 1. PULL (or confirm cached)
    ok, was_cached = _docker_pull(image_ref)
    if not ok:
        return False

    # 2. DIGEST CHECK (only if newly pulled; cached images already verified)
    if not was_cached:
        if not _verify_digest(image_ref, expected_digest):
            _docker_rmi(image_ref)
            return False

    # 3. WARMUP (QEMU JIT cache warmup)
    if not _docker_warmup(image_ref, task_id):
        if not was_cached:
            _docker_rmi(image_ref)
        return False

    if dry_run:
        print(f"[DRY-RUN] stopping before eval (image {'cached' if was_cached else 'freshly downloaded'})")
        return True

    if not campaign_id:
        raise ValueError("campaign_id is required for evaluation runs")

    # 4. RUN CAMPAIGN (via project-standard script)
    # SWE-bench's harness expects the full HuggingFace dataset name; the
    # task manifest carries ``benchmark: "SWE-bench_Verified"`` so the
    # canonical name is ``SWE-bench/SWE-bench_Verified``.  Earlier
    # runs of this script used the bare alias ``verified`` which HF's
    # load_dataset cannot resolve.
    cmd = [
        sys.executable, str(RUNNER),
        "--contract", str(CONTRACT),
        "--approval", str(APPROVAL),
        "--model-config", str(MODEL_CONFIG),
        "--tasks", str(TASK_MANIFEST),
        "--output-root", str(OUTPUT_ROOT),
        "--repo-cache", str(REPO_CACHE),
        "--evaluator-dataset", DATASET,
        "--project-root", str(REPO),
        "--task-id", task_id,
        "--variant", variant,
        "--campaign-id", campaign_id,
    ]
    print(f"[RUN-CAMPAIGN] {' '.join(cmd)}", flush=True)
    existing_run_ids = {path.name for path in OUTPUT_ROOT.glob("RUN-*") if path.is_dir()}
    started = time.monotonic()
    result = subprocess.run(cmd, cwd=REPO, env=os.environ.copy())
    elapsed = time.monotonic() - started
    print(f"[RUN-CAMPAIGN] exit={result.returncode} elapsed={elapsed:.1f}s")

    # 5. ARCHIVE CONFIRM: bundle sealed at experiments/runs/RUN-*/
    latest_runs = sorted(
        (path for path in OUTPUT_ROOT.glob("RUN-*") if path.is_dir() and path.name not in existing_run_ids),
        key=lambda p: p.stat().st_mtime,
    )
    if not latest_runs:
        print(f"[ARCHIVE-FAIL] no RUN-* directory created")
        if not was_cached:
            _docker_rmi(image_ref)
        return False
    latest = latest_runs[-1]
    manifest = latest / "run_manifest.json"
    if not manifest.exists():
        print(f"[ARCHIVE-FAIL] no run_manifest.json in {latest}")
        if not was_cached:
            _docker_rmi(image_ref)
        return False
    manifest_data = json.loads(manifest.read_text())
    if any(
        manifest_data.get(field) != expected
        for field, expected in (("campaign_id", campaign_id), ("variant_id", variant), ("task_id", task_id))
    ):
        print(f"[ARCHIVE-FAIL] {latest.name} identity does not match requested campaign/variant/task")
        if not was_cached:
            _docker_rmi(image_ref)
        return False
    print(f"[ARCHIVE-OK] {latest.name}")
    print(f"[ARCHIVE] status={manifest_data.get('status')}")

    # 6. RMI IMAGE (only if freshly downloaded; preserve cache for next task)
    if not was_cached:
        _docker_rmi(image_ref)

    return result.returncode == 0 and manifest_data.get("status") == "completed"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-id", choices=TASKS + ["all"], default="all")
    parser.add_argument("--dry-run", action="store_true",
                        help="pull + warmup only, do NOT run eval")
    parser.add_argument("--campaign-id", help="Required for evaluation runs; recorded in each RUN manifest")
    parser.add_argument("--variant", default="cactus_full", choices=("maximal_context", "lexical_bm25", "cactus_full", "cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density"))
    args = parser.parse_args()

    if not args.dry_run and not args.campaign_id:
        parser.error("--campaign-id is required unless --dry-run is selected")

    contract = json.loads(CONTRACT.read_text())

    selected = TASKS if args.task_id == "all" else [args.task_id]
    print(f"[PLAN] {len(selected)} task(s): {selected}")
    print(f"[PLAN] dry_run={args.dry_run}")

    results: dict[str, bool] = {}
    for task_id in selected:
        try:
            ok = run_one_task(task_id, contract, campaign_id=args.campaign_id, variant=args.variant, dry_run=args.dry_run)
            results[task_id] = ok
            if not ok:
                print(f"[STOP] task {task_id} failed; will not retry per Owner '保证成功' policy")
                break
        except Exception as exc:
            print(f"[TASK-EXCEPTION] {task_id}: {type(exc).__name__}: {exc}")
            results[task_id] = False
            break

    print("\n========== SUMMARY ==========")
    for t, ok in results.items():
        print(f"  {t}: {'OK' if ok else 'FAIL'}")
    print(f"  total: {sum(results.values())}/{len(results)}")
    return 0 if all(results.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
