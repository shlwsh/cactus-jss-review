#!/usr/bin/env python3
"""Add P04 results to publication_values.json."""
import sys
sys.path.insert(0, 'src')
sys.path.insert(0, '.')

import json
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path('.')
LEDGER = ROOT / 'paper/data/publication_values.json'
METRICS_FILE = ROOT / 'experiments/derived/p04_matched_derived_metrics.json'

# Load existing ledger
ledger = json.loads(LEDGER.read_text(encoding='utf-8'))
values = ledger.get('values', {})

# Load P04 metrics
metrics = json.loads(METRICS_FILE.read_text(encoding='utf-8'))

# Add P04 values
def add_p04(ident, value, display=None):
    if display is None:
        display = str(value)
    values[ident] = {
        'value': value,
        'display': display,
        'kind': 'supporting_observation',
        'sources': [{'path': str(METRICS_FILE.relative_to(ROOT).as_posix()), 'sha256': 'dynamic'}],
        'selector': 'P04 matched context study',
        'transform': 'identity',
        'allowed_sections': ['any']
    }

# Cohort size
add_p04('p04.cohort_size', metrics['cohort_size'])

# Strategy metrics
for strategy, data in metrics['strategy_metrics'].items():
    prefix = f'p04.{strategy.lower()}'
    add_p04(f'{prefix}.valid_rate', data['valid_rate'], f'{data["valid_rate"]:.2f}')
    add_p04(f'{prefix}.valid_patches', data['valid_patches'])
    add_p04(f'{prefix}.median_patch_len', data['patch_len_median'], f'{data["patch_len_median"]:.1f}')
    add_p04(f'{prefix}.iqr_patch_len', data['patch_len_iqr'], f'{data["patch_len_iqr"]:.1f}')

# Cochran's Q test
cochran = metrics['cochran_q_test']
add_p04('p04.cochran.q', cochran['q_statistic'], f'{cochran["q_statistic"]:.4f}')
add_p04('p04.cochran.df', cochran['df'])
add_p04('p04.cochran.p', cochran['p_value'], f'{cochran["p_value"]:.6f}')

# Pairwise comparisons
for comparison, data in metrics['pairwise_comparisons'].items():
    # Parse comparison name: e.g., "FACO_vs_MAXIMAL" -> "faco_vs_maximal"
    parts = comparison.lower().split('_vs_')
    prefix = f'p04.{parts[0]}_vs_{parts[1]}'
    add_p04(f'{prefix}.diff', data['difference_in_proportions'], f'{data["difference_in_proportions"]:.2f}')
    add_p04(f'{prefix}.ci_low', data['ci_95_diff'][0], f'{data["ci_95_diff"][0]:.2f}')
    add_p04(f'{prefix}.ci_high', data['ci_95_diff'][1], f'{data["ci_95_diff"][1]:.2f}')
    add_p04(f'{prefix}.p', data['mcnemar_exact_p'], f'{data["mcnemar_exact_p"]:.5f}')

# Save updated ledger
ledger['values'] = values
ledger['generated_at'] = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

print(f'Added {len(values)} values to publication_values.json')
print('P04 values added:')
for k in sorted(values.keys()):
    if k.startswith('p04.'):
        print(f'  {k}: {values[k]["display"]}')
