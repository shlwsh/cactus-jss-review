"""Augment the CACTUS inference-safe manifest with SWE-bench harness fields.

The inference-safe transformation strips ``patch`` and ``test_patch`` so they
cannot leak into the model input prompt.  The SWE-bench harness, however,
still needs ``image``, ``instance_id``, ``repo``, ``log_parser``,
``eval_script``, ``FAIL_TO_PASS``, ``PASS_TO_PASS`` and ``version`` to spin
up the official Docker evaluator image and parse the test outcome.

This script joins the inference-safe manifest with the official SWE-bench
parquet and emits a new manifest containing the *evaluation* fields without
re-introducing the gold ``patch`` / ``test_patch`` content.  The output is
written next to the input with an ``_eval`` suffix.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pyarrow.parquet as pq


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--safe-manifest", type=Path, required=True)
    parser.add_argument("--parquet", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--strict-fields", action="store_true",
                        help="Raise if any task in the safe manifest is missing from the parquet.")
    args = parser.parse_args()

    print(f"Loading parquet {args.parquet} ...")
    table = pq.read_table(str(args.parquet))
    parquet_by_id = {table.column("instance_id")[i].as_py(): i for i in range(table.num_rows)}
    print(f"Parquet rows: {table.num_rows}")

    EVAL_FIELDS = (
        "image", "instance_id", "repo", "version", "log_parser",
        "eval_script", "FAIL_TO_PASS", "PASS_TO_PASS", "difficulty",
        "eval_type", "created_at", "environment_setup_commit",
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    rows = 0
    matched = 0
    with args.safe_manifest.open(encoding="utf-8") as src, args.output.open("w", encoding="utf-8", newline="\n") as dst:
        for line in src:
            line = line.strip()
            if not line:
                continue
            rows += 1
            entry = json.loads(line)
            task_id = entry["task_id"]
            if task_id not in parquet_by_id:
                if args.strict_fields:
                    raise SystemExit(f"task_id not in parquet: {task_id}")
                continue
            idx = parquet_by_id[task_id]
            for field in EVAL_FIELDS:
                if field in entry:
                    continue
                value = table.column(field)[idx].as_py()
                entry[field] = value
            matched += 1
            dst.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")
    print(f"safe rows: {rows}, matched: {matched}, output: {args.output}")
    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    print(f"sha256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
