"""Generate paper inputs from pinned, separate evidence cohorts (offline)."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "paper/evidence_sources.json"
CATALOG = ROOT / "paper/data/evidence_catalog.json"
GENERATED = ROOT / "paper/generated"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def source_path(item: dict) -> Path:
    path = (ROOT / item["path"]).resolve()
    path.relative_to(ROOT.resolve())
    if sha(path) != item["sha256"]:
        raise ValueError(f"pinned source hash mismatch: {item['path']}")
    return path


def derive() -> tuple[dict, dict[str, str], list[dict]]:
    config = load(CONFIG)
    sources = config["sources"]
    paths = {key: source_path(item) for key, item in sources.items()}
    with paths["verified_snapshot"].open(encoding="utf-8-sig", newline="") as handle:
        outcomes = list(csv.DictReader(handle))
    if len(outcomes) != len({r["task"] for r in outcomes}):
        raise ValueError("duplicate task in frozen snapshot")
    counts = {k: sum(int(r[k] or 0) for r in outcomes) for k in ("resolved", "unresolved", "error")}
    if sum(counts.values()) != len(outcomes):
        raise ValueError("snapshot categories do not conserve tasks")
    summary = load(paths["retry_summary"])
    inventory = [json.loads(line) for line in paths["retry_inventory"].read_text(encoding="utf-8").splitlines()]
    registry = [json.loads(line) for line in paths["retry_registry"].read_text(encoding="utf-8").splitlines()]
    by_run = {r["run_id"]: r for r in inventory}
    admitted = [r for r in inventory if r["admitted"]]
    if len(by_run) != len(inventory) or len(registry) != len(admitted):
        raise ValueError("duplicate RUN or registry admission mismatch")
    if {r["provenance"]["run_id"] for r in registry} != {r["run_id"] for r in admitted}:
        raise ValueError("registry coverage mismatch")
    for record in registry:
        row = by_run[record["provenance"]["run_id"]]
        if record["publication"]["claim_status"] != "supporting" or record["value"] != int(row["resolved"]):
            raise ValueError("registry value/publication mismatch")
        for key in ("task_id", "experiment_id", "source_commit", "bundle_tree_sha256", "contract_sha256"):
            if row[key] != record["provenance"][key]:
                raise ValueError(f"registry provenance mismatch: {key}")
    def summarize(rows):
        admitted_rows = [r for r in rows if r["admitted"]]
        return {
            "sealed_run_count": len(rows),
            "unique_task_count": len({r["task_id"] for r in rows}),
            "bundle_valid_count": sum(r["bundle_valid"] for r in rows),
            "evaluator_valid_count": sum(r["evaluator_valid"] for r in rows),
            "admitted_run_count": len(admitted_rows),
            "excluded_run_count": len(rows) - len(admitted_rows),
            "resolved_run_count": sum(r["resolved"] for r in admitted_rows),
            "resolved_task_ids": sorted({r["task_id"] for r in admitted_rows if r["resolved"]}),
            "observed_resolved_run_count": sum(r["resolved"] for r in rows),
            "observed_resolved_task_ids": sorted({r["task_id"] for r in rows if r["resolved"]}),
            "exclusion_reason_counts": dict(sorted(Counter(reason for r in rows for reason in r["exclusion_reasons"]).items())),
        }
    retry = summarize(inventory)
    if any(summary.get(k) != v for k, v in retry.items()):
        raise ValueError("retry summary differs from inventory")
    groups = []
    for identifier in sorted({r["experiment_id"] for r in inventory}):
        rows = [r for r in inventory if r["experiment_id"] == identifier]
        group = summarize(rows)
        if any(summary["experiments"][identifier].get(k) != v for k, v in group.items()):
            raise ValueError(f"contract summary mismatch: {identifier}")
        groups.append({"experiment_id": identifier, "source_commits": sorted({r["source_commit"] for r in rows}), **group})
    catalog = {
        "schema_version": "1.0", "sources": sources,
        "aggregation_policy": "separate_cohorts_and_contracts; retain_every_retry; no_best_of_retries_or_pooled_repair_rate",
        "cohorts": [
            {"cohort_id": "verified_frozen_snapshot", "unit": "unique_task", "scope": "historical_single_variant_snapshot",
             "counts": {"unique_tasks": len(outcomes), **counts, "evaluator_valid": counts["resolved"] + counts["unresolved"]},
             "claim_boundary": "descriptive historical snapshot; full current RUN admission is not established"},
            {"cohort_id": "lite50_failure_selected_retries", "unit": "RUN", "scope": "failure_selected_retry_attempts",
             "counts": retry, "contracts": groups,
             "claim_boundary": "supporting only for admitted records; excluded observations are audit evidence, not effectiveness evidence"},
        ],
    }
    values = {
        "RetryArchivedRuns": retry["sealed_run_count"], "RetryUniqueTasks": retry["unique_task_count"],
        "RetryBundleValidRuns": retry["bundle_valid_count"], "RetryEvaluatorValidRuns": retry["evaluator_valid_count"],
        "RetryAdmittedRuns": retry["admitted_run_count"], "RetryExcludedRuns": retry["excluded_run_count"],
        "RetryResolvedRuns": retry["resolved_run_count"], "RetryResolvedTasks": len(retry["resolved_task_ids"]),
        "RetryObservedResolvedRuns": retry["observed_resolved_run_count"],
        "RetryObservedResolvedTasks": len(retry["observed_resolved_task_ids"]),
        "RetrySourceMismatchRuns": retry["exclusion_reason_counts"].get("contract_driver_source_hash_mismatch", 0),
        "RetryAdmittedUniqueTasks": len({r["task_id"] for r in admitted}),
        "RetryResolvedTaskList": ", ".join(r"\nolinkurl{" + task + "}" for task in retry["resolved_task_ids"]),
    }
    rten = next(g for g in groups if "REMAINING-R10-" in g["experiment_id"])
    values.update({"RetryRtenRuns": rten["sealed_run_count"], "RetryRtenEvaluatorRuns": rten["evaluator_valid_count"],
                   "RetryRtenObservedResolvedRuns": rten["observed_resolved_run_count"], "RetryRtenAdmittedRuns": rten["admitted_run_count"]})
    macros = "% Generated from pinned evidence_sources.json; separate cohorts.\n" + "".join(
        f"\\newcommand{{\\{name}}}{{{value}}}\n" for name, value in values.items())
    rows = [r"\begin{tabular}{lrr}", r"\toprule", r"Audit stage & RUNs & Unique tasks\\", r"\midrule",
            r"Archived & \RetryArchivedRuns{} & \RetryUniqueTasks{}\\",
            r"Bundle checks pass & \RetryBundleValidRuns{} & ---\\",
            r"Official evaluator valid & \RetryEvaluatorValidRuns{} & ---\\",
            r"Full admission & \RetryAdmittedRuns{} & \RetryAdmittedUniqueTasks{}\\",
            r"Resolved, admitted & \RetryResolvedRuns{} & \RetryResolvedTasks{}\\",
            r"Excluded & \RetryExcludedRuns{} & ---\\", r"\bottomrule", r"\end{tabular}"]
    reasons = [r"\begin{tabular}{lr}", r"\toprule", r"Exclusion reason (overlapping) & RUNs\\", r"\midrule"]
    labels = {"billing_not_reconciled": "Billing not reconciled", "contract_driver_source_hash_mismatch": "Driver/source hash mismatch",
              "no_valid_official_evaluator": "No valid official evaluator", "no_valid_prediction_patch": "No valid prediction patch",
              "raw_evaluator_result_mismatch": "Raw/evaluator mismatch", "raw_evidence_not_verified_measured": "Raw evidence fails measured/verified gate"}
    for reason, count in retry["exclusion_reason_counts"].items():
        reasons.append(f"{labels[reason]} & {count}\\\\")
    reasons.extend([r"\bottomrule", r"\end{tabular}"])
    contracts = [r"\begin{tabular}{lrrrr}", r"\toprule", r"Contract group & Archived & Eval. & Admitted & Resolved$^*$\\", r"\midrule"]
    for g in groups:
        short = g["experiment_id"].replace("EXP-CACTUS-SWEBENCH-", "").split("-2026")[0]
        contracts.append(f"{short} & {g['sealed_run_count']} & {g['evaluator_valid_count']} & {g['admitted_run_count']} & {g['resolved_run_count']}\\\\")
    contracts.extend([r"\bottomrule", r"\end{tabular}"])
    artifacts = {"evidence_macros.tex": macros, "table_retry_admission.tex": "\n".join(rows) + "\n",
                 "table_retry_exclusions.tex": "\n".join(reasons) + "\n", "table_retry_contracts.tex": "\n".join(contracts) + "\n"}
    inputs = [{"path": CONFIG.relative_to(ROOT).as_posix(), "sha256": sha(CONFIG)}, *sources.values()]
    return catalog, artifacts, inputs


def write_provenance(path: Path, inputs: list[dict], timestamp: str, kind="derived_dataset") -> None:
    from artifact_provenance import git_commit
    commit = git_commit(ROOT)
    payload = {"schema_version": "2.0", "artifact_id": "DATA-PAPER-" + hashlib.sha256(path.relative_to(ROOT).as_posix().encode()).hexdigest().upper(),
               "artifact_type": kind, "artifact_path": path.relative_to(ROOT).as_posix(), "artifact_sha256": sha(path),
               "generated_at": timestamp, "generator": {"script": "scripts/generate_evidence_catalog.py", "script_sha256": sha(Path(__file__)), "source_commit": commit,
               "working_tree_content_bound_by_script_hash": True}, "inputs": inputs,
               "transform": {"policy": "pinned_cohorts_no_pooled_resolution_rate"}}
    path.with_name(path.name + ".provenance.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def generate() -> dict:
    catalog, artifacts, inputs = derive()
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    catalog["generated_at"] = timestamp
    CATALOG.parent.mkdir(parents=True, exist_ok=True)
    CATALOG.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write_provenance(CATALOG, inputs, timestamp)
    GENERATED.mkdir(parents=True, exist_ok=True)
    for name, content in artifacts.items():
        path = GENERATED / name
        path.write_text(content, encoding="utf-8", newline="\n")
        write_provenance(path, inputs, timestamp, "table")
    records = [json.loads(line) for line in source_path(load(CONFIG)["sources"]["retry_registry"]).read_text(encoding="utf-8").splitlines()]
    record_path = ROOT / "paper/data/admitted_retry_records.json"
    record_path.write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write_provenance(record_path, inputs, timestamp)
    csv_path = ROOT / "paper/data/admitted_retry_results.csv"
    md_path = ROOT / "paper/data/admitted_retry_results.md"
    subprocess.run([os.sys.executable, "-m", "cactus.cli", "artifact-table", str(record_path), str(csv_path), str(md_path)],
                   cwd=ROOT, env={**os.environ, "PYTHONPATH": str(ROOT / "src")}, check=True,
                   stdout=subprocess.DEVNULL)
    for path in (csv_path, md_path):
        write_provenance(path, [*inputs, {"path": record_path.relative_to(ROOT).as_posix(), "sha256": sha(record_path)},
                              {"path": "src/cactus/analysis/artifact.py", "sha256": sha(ROOT / "src/cactus/analysis/artifact.py")}], timestamp, "table")
    return {"status": "pass", "cohorts": [c["cohort_id"] for c in catalog["cohorts"]]}


def verify() -> dict:
    expected, artifacts, inputs = derive()
    actual = load(CATALOG)
    actual.pop("generated_at")
    if actual != expected:
        raise ValueError("generated evidence catalog drift")
    for name, content in artifacts.items():
        if (GENERATED / name).read_text(encoding="utf-8") != content:
            raise ValueError(f"generated paper evidence drift: {name}")
    for path in [CATALOG, *(GENERATED / name for name in artifacts)]:
        sidecar = load(path.with_name(path.name + ".provenance.json"))
        if sidecar["artifact_sha256"] != sha(path) or sidecar["inputs"] != inputs or sidecar["generator"]["script_sha256"] != sha(Path(__file__)):
            raise ValueError(f"paper evidence provenance drift: {path.name}")
    registry = [json.loads(line) for line in source_path(load(CONFIG)["sources"]["retry_registry"]).read_text(encoding="utf-8").splitlines()]
    if load(ROOT / "paper/data/admitted_retry_records.json") != registry:
        raise ValueError("admitted retry record drift")
    with (ROOT / "paper/data/admitted_retry_results.csv").open(encoding="utf-8", newline="") as handle:
        csv_rows = list(csv.DictReader(handle))
    if len(csv_rows) != len(registry) or {r["result_id"] for r in csv_rows} != {r["result_id"] for r in registry}:
        raise ValueError("admitted retry table coverage drift")
    registry_by_id = {r["result_id"]: r for r in registry}
    for row in csv_rows:
        record = registry_by_id[row["result_id"]]
        expected_hash = hashlib.sha256(json.dumps(record, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
        if (row["source_sha256"] != expected_hash or row["claim_status"] != record["publication"]["claim_status"]
                or any(row[key] != str(record[key]) for key in ("study_id", "metric_id", "value", "unit"))):
            raise ValueError("admitted retry table value/policy/hash drift")
    for name in ("admitted_retry_records.json", "admitted_retry_results.csv", "admitted_retry_results.md"):
        path = ROOT / "paper/data" / name
        sidecar = load(path.with_name(name + ".provenance.json"))
        if sidecar["artifact_sha256"] != sha(path) or any(sha(ROOT / item["path"]) != item["sha256"] for item in sidecar["inputs"]):
            raise ValueError(f"admitted retry artifact drift: {name}")
    return {"status": "pass", "cohort_count": len(expected["cohorts"]), "artifact_count": 4 + len(artifacts)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    print(json.dumps(verify() if args.verify else generate(), ensure_ascii=False))
