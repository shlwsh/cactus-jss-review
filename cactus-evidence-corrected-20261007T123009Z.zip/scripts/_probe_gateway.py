"""Quick probe to verify LiteLLM gateway is accessible."""
import urllib.request
import json

url = "http://172.19.9.104:4000/v1/models"
headers = {"Authorization": "Bearer sk-dgx-local-2026"}

try:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
        models = data.get("data", [])
        print(f"OK: {len(models)} models available")
        for m in models[:5]:
            print(f"  - {m.get('id', '?')}")
except Exception as e:
    print(f"FAIL: {e}")
