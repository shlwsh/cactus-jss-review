"""Freeze v2.1 selector parameters from an independent, label-free dev set."""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "frozen_selector_v2.1.yaml"
DEV_SET = ROOT / "data" / "fixtures" / "dev_set" / "tasks.jsonl"
REPORT = ROOT / "artifacts" / "parameter_freeze_report.md"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git_commit() -> str:
    return subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, capture_output=True, check=False).stdout.strip()


def freeze(config: Path = CONFIG, dev_set: Path = DEV_SET, report: Path = REPORT) -> dict[str, object]:
    if not config.is_file() or not dev_set.is_file():
        raise FileNotFoundError("selector config and independent dev set are required")
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    payload = {"config_sha256": _sha(config), "dev_set_sha256": _sha(dev_set), "selector_version": "cactus-selector-v2.1.0", "git_commit": _git_commit()}
    protocol_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    lock = {"schema_version": "2.1", "protocol_hash": protocol_hash, "frozen_at": generated_at, "inputs": payload, "formal_results_used": False, "status": "frozen_for_pre_registration"}
    lock_path = config.with_suffix(".lock.json")
    lock_path.write_text(json.dumps(lock, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text("\n".join([
        "# CACTUS v2.1 选择器参数冻结报告", "", f"> 冻结时间：{generated_at}", f"> 协议哈希：`{protocol_hash}`", f"> 配置哈希：`{payload['config_sha256']}`", f"> 开发集哈希：`{payload['dev_set_sha256']}`", f"> Git 提交：`{payload['git_commit']}`", "", "## 冻结依据", "", "- 参数来自独立的 24 任务合成开发集。", "- 开发集不包含正式任务的 resolved/unresolved 标签。", "- 冻结目标仅包括结构覆盖、上下文稳定性、词元占用和碎片化，不使用正式修复率调参。", "- 正式 500 任务实验开始后不得修改本配置或协议哈希。", "", "## Gate 状态", "", "`FROZEN_FOR_PRE_REGISTRATION`：参数已形成可验证冻结候选；正式实验仍须通过合同、预算、计费和评估器门禁。", ""]), encoding="utf-8")
    return {"protocol_hash": protocol_hash, "config": config.as_posix(), "dev_set": dev_set.as_posix(), "report": report.as_posix(), "status": lock["status"]}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=CONFIG)
    parser.add_argument("--dev-set", type=Path, default=DEV_SET)
    parser.add_argument("--report", type=Path, default=REPORT)
    args = parser.parse_args()
    print(json.dumps(freeze(args.config, args.dev_set, args.report), ensure_ascii=False))
