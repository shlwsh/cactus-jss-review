#!/usr/bin/env python3
"""Debug scan for specific lines from main.tex."""
import re

# Read main.tex
with open('paper/main.tex', 'r', encoding='utf-8') as f:
    lines = f.readlines()

def process_line(line):
    digit_check = line
    digit_check = re.sub(r"\b(?:flake8|mypy|pyright|ruff)\s+[A-Z]\d+", "TOOL_CODE", digit_check)
    digit_check = re.sub(r"\$\\[gl]e\$\d+", "INEQUALITY_ZERO", digit_check)
    digit_check = re.sub(r"\\(?:DataValue|input|label|ref|cite[a-zA-Z*]*|bibliography|bibliographystyle)\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\includegraphics(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\(?:documentclass|usepackage)(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\email\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\(?:emergencystretch|setlength)\s*(?:=\s*)?(?:\{[^}]*\})?\s*\{?\d+(?:\.\d+)?(?:pt|em|mm|cm)\}?", "", digit_check)
    digit_check = re.sub(r"\\b(?:BM25|§\d+)\b", "ALLOWED_ID", digit_check)
    digit_check = re.sub(r"\\[a-zA-Z]+\{[^}]*\}", "", digit_check)
    return digit_check

# Check specific lines
for lineno in [361, 363, 378, 380, 390, 395, 400]:
    line = lines[lineno - 1]  # 0-indexed
    result = process_line(line)
    if re.search(r"\d", result):
        print(f"Line {lineno}: FOUND DIGITS")
        for m in re.finditer(r"\d+", result):
            start = max(0, m.start() - 40)
            end = min(len(result), m.end() + 40)
            print(f"  Digit at position {m.start()}: '{m.group()}'")
            print(f"  Context: ...{result[start:end]}...")
    else:
        print(f"Line {lineno}: OK")
