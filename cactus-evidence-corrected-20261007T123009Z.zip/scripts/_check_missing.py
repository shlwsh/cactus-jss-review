#!/usr/bin/env python3
"""Check which inputs in old governance provenance are missing."""
import json
from pathlib import Path

prov_path = Path('experiments/derived/governance_20261004T093000Z/historical_task_admission.jsonl.provenance.json')
prov = json.loads(prov_path.read_text())

missing = []
for inp in prov['inputs']:
    path = Path(inp['path'])
    exists = path.exists()
    if not exists:
        missing.append(inp['path'])
        print(f"NOT FOUND: {inp['path']}")

if missing:
    print(f"\nTotal missing: {len(missing)}")
else:
    print("All inputs exist!")
