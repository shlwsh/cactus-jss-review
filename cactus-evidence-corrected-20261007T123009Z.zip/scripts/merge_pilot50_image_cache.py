"""Merge Docker save archives into one deduplicated Pilot50 cache archive."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import tarfile
import time
from pathlib import Path
from typing import Any


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(archive: tarfile.TarFile, name: str) -> Any:
    member = archive.getmember(name)
    handle = archive.extractfile(member)
    if handle is None:
        raise ValueError(f"archive member is not readable: {name}")
    return json.load(handle)


def _entry_key(entry: dict[str, Any]) -> tuple[str, tuple[str, ...]]:
    return str(entry.get("Config", "")), tuple(str(layer) for layer in entry.get("Layers", []))


def _merge_manifests(base_entries: list[dict[str, Any]], extra_entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[tuple[str, tuple[str, ...]], dict[str, Any]] = {}
    for entry in [*base_entries, *extra_entries]:
        if not isinstance(entry, dict):
            raise ValueError("manifest.json must contain object entries")
        key = _entry_key(entry)
        current = merged.setdefault(key, dict(entry))
        tags = list(current.get("RepoTags", []))
        for tag in entry.get("RepoTags", []):
            if tag not in tags:
                tags.append(tag)
        current["RepoTags"] = sorted(tags)
    return list(merged.values())


def _copy_blobs(source: tarfile.TarFile, target: tarfile.TarFile, copied: set[str]) -> None:
    for member in source:
        if not member.isfile() or not member.name.startswith("blobs/sha256/"):
            continue
        if member.name in copied:
            continue
        handle = source.extractfile(member)
        if handle is None:
            raise ValueError(f"archive member is not readable: {member.name}")
        target.addfile(member, handle)
        copied.add(member.name)


def merge_archives(base_archive: Path, extra_archives: list[Path], output_archive: Path) -> dict[str, Any]:
    """Merge Docker save archives without loading the full base into Docker."""
    output_archive.parent.mkdir(parents=True, exist_ok=True)
    if output_archive.exists():
        output_archive.unlink()
    with tarfile.open(base_archive, mode="r") as base:
        base_entries = _read_json(base, "manifest.json")
        if not isinstance(base_entries, list):
            raise ValueError("base manifest.json must be a list")
        extra_entries: list[dict[str, Any]] = []
        with tarfile.open(output_archive, mode="w") as target:
            copied: set[str] = set()
            _copy_blobs(base, target, copied)
            for extra_path in extra_archives:
                with tarfile.open(extra_path, mode="r") as extra:
                    entries = _read_json(extra, "manifest.json")
                    if not isinstance(entries, list):
                        raise ValueError(f"extra manifest.json must be a list: {extra_path}")
                    extra_entries.extend(entry for entry in entries if isinstance(entry, dict))
                    _copy_blobs(extra, target, copied)
            manifest_bytes = json.dumps(_merge_manifests(base_entries, extra_entries), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            info = tarfile.TarInfo("manifest.json")
            info.size = len(manifest_bytes)
            info.mode = 0o644
            info.mtime = int(time.time())
            target.addfile(info, io.BytesIO(manifest_bytes))
    return {
        "archive": output_archive.as_posix(),
        "archive_size_bytes": output_archive.stat().st_size,
        "archive_sha256": _sha256(output_archive),
        "manifest_entry_count": len(_merge_manifests(base_entries, extra_entries)),
        "blob_count": len(copied),
    }


def update_cache_manifest(manifest_path: Path, archive_path: Path, extra_images: dict[str, str]) -> dict[str, Any]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    image_refs = sorted(set(str(ref) for ref in manifest.get("image_refs", [])) | set(extra_images))
    image_digests = {str(ref): str(digest) for ref, digest in manifest.get("image_digests", {}).items()}
    image_digests.update(extra_images)
    manifest.update(
        {
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "image_count": len(image_refs),
            "image_refs": image_refs,
            "image_digests": image_digests,
            "additional_images": extra_images,
            "archive": archive_path.as_posix(),
            "archive_size_bytes": archive_path.stat().st_size,
            "archive_sha256": _sha256(archive_path),
            "network_calls": 0,
            "execution_performed": False,
        }
    )
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return manifest


def _parse_extra(values: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        ref, separator, digest = value.partition("=")
        if not separator or not ref or len(digest) != 71 or not digest.startswith("sha256:"):
            raise ValueError(f"extra image must be REF=sha256:<64 hex chars>: {value}")
        int(digest[7:], 16)
        result[ref] = digest
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-archive", type=Path, required=True)
    parser.add_argument("--extra-archive", type=Path, action="append", required=True)
    parser.add_argument("--output-archive", type=Path, required=True)
    parser.add_argument("--promote-to", type=Path, help="Replace this archive only after the new archive is complete")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--extra-image", action="append", default=[], metavar="REF=DIGEST")
    args = parser.parse_args()
    extra_images = _parse_extra(args.extra_image)
    result = merge_archives(args.base_archive, args.extra_archive, args.output_archive)
    update_cache_manifest(args.manifest, args.output_archive, extra_images)
    if args.promote_to is not None:
        if args.promote_to.resolve() == args.output_archive.resolve():
            raise ValueError("--promote-to must differ from --output-archive")
        if args.promote_to.exists():
            args.promote_to.unlink()
        args.output_archive.replace(args.promote_to)
        update_cache_manifest(args.manifest, args.promote_to, extra_images)
        result["archive"] = args.promote_to.as_posix()
        result["archive_size_bytes"] = args.promote_to.stat().st_size
        result["archive_sha256"] = _sha256(args.promote_to)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
