"""Inspect the V2 Pilot contract, session authorization, and image availability."""
import json
import re
import subprocess
from pathlib import Path


_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _local_repo_digests(repository: str, tag: str = "") -> set[str]:
    """Return manifest digests reported by the local Docker image store."""
    image_ref = f"{repository}:{tag}" if tag else repository
    result = subprocess.run(
        ['docker', 'image', 'inspect', image_ref],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        return set()
    try:
        images = json.loads(result.stdout)
    except json.JSONDecodeError:
        return set()
    if not isinstance(images, list):
        return set()
    digests: set[str] = set()
    for image in images:
        if not isinstance(image, dict):
            continue
        for repo_digest in image.get('RepoDigests', []):
            if isinstance(repo_digest, str) and '@' in repo_digest:
                digests.add(repo_digest.rsplit('@', 1)[1])
    return digests


pilot_path = Path('experiments/contracts/EXP-CACTUS-PILOT-V2.json')
pilot = json.loads(pilot_path.read_text(encoding='utf-8'))
approval_marker = pilot_path.with_name(pilot_path.name.replace('.json', '.approval_marker.json'))
session_authorization = pilot_path.with_name(pilot_path.name.replace('.json', '.session_authorization.json'))
approval_path = approval_marker if approval_marker.is_file() else session_authorization
approval = json.loads(approval_path.read_text(encoding='utf-8')) if approval_path.is_file() else {'status': 'missing'}

print('=== Pilot 合同 ===')
print('experiment_id:', pilot['experiment_id'])
print('git_commit:', pilot['source']['git_commit'])
print('host_profile:', pilot['host_profile'])
print('pilot_tasks:', pilot['execution']['pilot_tasks'])
print('cost_budget: USD', pilot['execution']['cost_budget']['amount'])
print('token_budget:', pilot['execution']['total_token_budget'])
print('task_timeout:', pilot['execution']['task_timeout_sec'], 's')
print()
print('=== Pilot Approval ===')
print('record:', approval_path.name if approval_path.is_file() else 'missing')
print('status:', approval['status'])
print('approved_at:', approval.get('approved_at', ''))
print()
print('=== 镜像 digest 状态 ===')
for name, img in pilot['images'].items():
    expected_digest = img.get('digest', '') if isinstance(img, dict) else ''
    local_digests = _local_repo_digests(str(img.get('repository', '')), str(img.get('tag', ''))) if isinstance(img, dict) else set()
    if not isinstance(expected_digest, str) or not _IMAGE_DIGEST.fullmatch(expected_digest):
        observed = f'; local RepoDigests={sorted(local_digests)}' if local_digests else ''
        print(f'  [BLOCKED] {name}: contract digest is not a complete SHA-256 ({expected_digest!r}){observed}')
        continue
    if expected_digest in local_digests:
        print(f'  [OK] {name}: digest={expected_digest}')
    elif local_digests:
        print(f'  [DIGEST MISMATCH] {name}: expected={expected_digest}; local={sorted(local_digests)}')
    else:
        print(f'  [PULL NEEDED] {name}: expected={expected_digest}')
