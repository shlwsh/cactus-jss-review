import json
from pathlib import Path

manifest_path = Path('data/manifests/swebench_verified_78f471b_source.json')
with open(manifest_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

instances = data.get('instances', [])
print(f'Total instances: {len(instances)}')
print()
print('Task IDs:')
for inst in instances:
    print(f'  {inst["instance_id"]}')
