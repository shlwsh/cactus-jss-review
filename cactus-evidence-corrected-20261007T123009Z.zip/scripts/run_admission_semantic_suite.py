"""Offline checksum-consistent mutation study using the publication admission core.

Every invocation retains a new directory, controls, mutated copies, complete
decisions, and generation-time provenance. No original RUN is modified.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import shutil
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from cactus.governance.admission import evaluate_admission, read_json, source_hash
from cactus.governance.canonical import canonical_json
from cactus.governance.evidence_locations import resolve_source
from cactus.runner.bundle_validator import validate_bundle
from scripts.artifact_provenance import write
from scripts.import_formal_run_bundles import files, tree_hash


OPERATORS = {
    "S01_prediction_substitution": "no_valid_prediction_patch",
    "S02_source_revision_substitution": "source_commit_mismatch",
    "S03_driver_digest_substitution": "contract_frozen_mismatch",
    "S04_evaluator_raw_inconsistency": "raw_evaluator_result_mismatch",
    "S05_billing_substitution": "billing_attempt_usage_mismatch",
    "S06_task_id_substitution": "task_identity_mismatch",
    "S07_authorization_substitution": "authorization_contract_mismatch",
    "S08_evaluator_version_drift": "evaluator_image_contract_mismatch",
}


def save(path: Path, data) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reseal(bundle: Path) -> None:
    """Only for isolated test copies: regenerate all content bindings, then seal."""
    manifest = read_json(bundle / "run_manifest.json")
    config = read_json(bundle / "resolved_config.json")
    manifest["configuration"]["sha256"] = hashlib.sha256(canonical_json(config).encode()).hexdigest()
    contract = read_json(bundle / "contract.json")
    (bundle / "contract.sha256").write_text(hashlib.sha256(canonical_json(contract).encode()).hexdigest() + "\n", encoding="utf-8")
    prediction = bundle / "raw/prediction.jsonl"
    if prediction.is_file():
        manifest["prediction_hash"] = sha(prediction)
        raw = read_json(bundle / "raw/result.json")
        raw["data"]["prediction_hash"] = sha(prediction)
        save(bundle / "raw/result.json", raw)
    for phase in ("pre", "post"):
        env = manifest["environment"]
        if env.get(phase + "_path"):
            env[phase + "_sha256"] = sha(bundle / env[phase + "_path"])
    for item in manifest["outputs"]:
        item["sha256"] = sha(bundle / item["path"])
    save(bundle / "run_manifest.json", manifest)
    hashes = files(bundle)
    (bundle / "checksums.sha256").write_text("".join(f"{digest}  {name}\n" for name, digest in hashes.items() if name != "checksums.sha256"), encoding="utf-8", newline="\n")


def mutate(operator: str, target: Path, donor: Path, *, donor_commit: str, driver_digest: str) -> None:
    if operator == "S01_prediction_substitution":
        shutil.copyfile(donor / "raw/prediction.jsonl", target / "raw/prediction.jsonl")
    elif operator == "S02_source_revision_substitution":
        path = target / "run_manifest.json"; value = read_json(path)
        value["code"]["commit"] = donor_commit; save(path, value)
    elif operator == "S03_driver_digest_substitution":
        path = target / "contract.json"; value = read_json(path)
        value["workload"]["sha256"] = driver_digest; save(path, value)
    elif operator == "S04_evaluator_raw_inconsistency":
        path = target / "raw/result.json"; value = read_json(path)
        value["data"]["resolved"] = not value["data"]["resolved"]; save(path, value)
    elif operator == "S05_billing_substitution":
        shutil.copyfile(donor / "billing/litellm_spend.json", target / "billing/litellm_spend.json")
    elif operator == "S06_task_id_substitution":
        path = target / "raw/result.json"; value = read_json(path)
        value["data"]["task_id"] = read_json(donor / "raw/result.json")["data"]["task_id"]; save(path, value)
    elif operator == "S08_evaluator_version_drift":
        path = target / "resolved_config.json"; value = read_json(path)
        value["evaluator_image"] = read_json(donor / "resolved_config.json")["evaluator_image"]; save(path, value)
    elif operator != "S07_authorization_substitution":
        raise ValueError("unknown mutation")
    reseal(target)


def summarize(cases: list[dict]) -> dict:
    controls = [c for c in cases if c["operator"] == "control"]
    faults = [c for c in cases if c["operator"] != "control"]
    tp = sum(not c["decision"]["admitted"] for c in faults)
    fp = sum(not c["decision"]["admitted"] for c in controls)
    latency = sorted(c["decision"]["elapsed_sec"] * 1000 for c in cases)
    per_operator = {}
    for operator in OPERATORS:
        group = [c for c in faults if c["operator"] == operator]
        per_operator[operator] = {
            "cases": len(group), "rejected": sum(not c["decision"]["admitted"] for c in group),
            "integrity_passed": sum(c["decision"]["integrity_passed"] for c in group),
            "intended_rule_detected": sum(OPERATORS[operator] in c["decision"]["reasons"] for c in group),
            "stages": dict(Counter(c["decision"]["stage"] for c in group)),
            "reasons": dict(Counter(r for c in group for r in c["decision"]["reasons"])),
        }
    return {"tp": tp, "fn": len(faults)-tp, "fp": fp, "tn": len(controls)-fp,
            "fault_count": len(faults), "control_count": len(controls), "operator_count": len(OPERATORS),
            "recall": tp/len(faults), "specificity": (len(controls)-fp)/len(controls), "fpr": fp/len(controls),
            "integrity_rejections": sum(c["decision"]["stage"] == "integrity" for c in faults),
            "semantic_rejections": sum(c["decision"]["stage"] == "semantic" for c in faults),
            "mean_ms": statistics.mean(latency), "median_ms": statistics.median(latency),
            "p95_ms": latency[math.ceil(.95*len(latency))-1], "p95_method": "nearest-rank",
            "per_operator": per_operator}


def run(output: Path, count: int = 20) -> dict:
    config = read_json(ROOT / "paper/publication_sources.json")
    inventory = ROOT / config["sources"]["retry_inventory"]["path"]
    rows = [json.loads(line) for line in inventory.read_text().splitlines()]
    seeds = [r for r in rows if r["admitted"]][:count]
    if count < 2 or len(seeds) != count:
        raise ValueError("insufficient admitted seeds")
    output = output.resolve(); output.relative_to(ROOT)
    if output.exists():
        raise FileExistsError("refusing to overwrite mutation evidence")
    bundles = {r["run_id"]: resolve_source(ROOT, r["run_path"]) for r in seeds}
    originals = {name: tree_hash(path) for name, path in bundles.items()}
    contracts = {r["run_id"]: read_json(ROOT / r["contract_path"]) for r in seeds}
    authorizations = {r["run_id"]: read_json((ROOT / r["contract_path"]).with_name(Path(r["contract_path"]).stem + ".session_authorization.json")) for r in seeds}
    # Real, retained alternate source/authorization; do not invent signed approvals.
    donor_row = next(r for r in rows if r["source_commit"] != seeds[0]["source_commit"])
    donor_commit = donor_row["source_commit"]
    alternate_auth_path = ROOT / donor_row["contract_path"]
    alternate_auth = read_json(alternate_auth_path.with_name(alternate_auth_path.stem + ".session_authorization.json"))
    output.mkdir(parents=True)
    cases = []
    for index, seed in enumerate(seeds):
        name = seed["run_id"]; baseline = bundles[name]; contract = contracts[name]; auth = authorizations[name]
        donor = next(bundles[r["run_id"]] for r in seeds if r["task_id"] != seed["task_id"]
                     and read_json(bundles[r["run_id"]] / "billing/litellm_spend.json")["total_tokens"] != read_json(baseline / "billing/litellm_spend.json")["total_tokens"])
        alternate = next(r for r in rows if r["source_commit"] != seed["source_commit"]
                         and source_hash(ROOT, r["source_commit"], contract["workload"]["driver"]) != contract["workload"]["sha256"])
        changed_digest = source_hash(ROOT, alternate["source_commit"], contract["workload"]["driver"])
        for operator in ["control", *OPERATORS]:
            case_id = f"{operator}-{index+1:03d}"
            target = output / "cases" / case_id / name
            shutil.copytree(baseline, target)
            case_auth = auth
            if operator != "control":
                mutate(operator, target, donor, donor_commit=alternate["source_commit"], driver_digest=changed_digest)
                if operator == "S07_authorization_substitution":
                    case_auth = alternate_auth if alternate_auth["experiment_id"] != contract["experiment_id"] else authorizations[next(k for k in authorizations if authorizations[k]["experiment_id"] != contract["experiment_id"])]
            decision = evaluate_admission(ROOT, target, contract, authorization=case_auth)
            case = {"case_id": case_id, "operator": operator, "seed_run_id": name,
                    "bundle_path": target.relative_to(ROOT).as_posix(), "bundle_tree_sha256": tree_hash(target),
                    "contract": contract, "authorization": case_auth,
                    "expected_admitted": operator == "control", "decision": decision}
            cases.append(case)
    if {name: tree_hash(path) for name, path in bundles.items()} != originals:
        raise ValueError("original evidence changed")
    summary = summarize(cases)
    summary["seed_count"] = len(seeds)
    passed = (summary["fn"] == summary["fp"] == summary["integrity_rejections"] == 0
              and all(v["cases"] == v["integrity_passed"] == v["intended_rule_detected"] for v in summary["per_operator"].values()))
    result = {"schema_version": "1.0", "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
              "evidence_kind": "controlled_mutation_of_observed_archive; not new repair execution",
              "admission_implementation": "src/cactus/governance/admission.py",
              "admission_sha256": sha(ROOT / "src/cactus/governance/admission.py"),
              "verdict": "PASS" if passed else "FAIL", "original_trees": originals,
              "latency_scope": "materialized files; warm process/source cache; excludes copying, resealing, model/evaluator calls",
              "summary": summary, "cases": cases}
    path = output / "semantic_mutations.json"; save(path, result)
    inputs = [inventory, ROOT / "src/cactus/governance/admission.py", ROOT / "src/cactus/runner/bundle_validator.py"]
    inputs += [ROOT / r["contract_path"] for r in seeds]
    write(path, inputs, Path(__file__), transform={"operators": OPERATORS, "origin": result["evidence_kind"], "original_trees": originals}, kind="derived_dataset")
    print(json.dumps({"output": path.relative_to(ROOT).as_posix(), "verdict": result["verdict"], "summary": summary}, indent=2))
    return result


def verify_snapshot(path: Path) -> dict:
    """Recompute every decision and source-tree identity; preserve recorded latency."""
    result = read_json(path)
    if result["admission_sha256"] != sha(ROOT / result["admission_implementation"]):
        raise ValueError("semantic admission implementation drift")
    if len({c["case_id"] for c in result["cases"]}) != len(result["cases"]):
        raise ValueError("duplicate semantic mutation case")
    for case in result["cases"]:
        bundle = (ROOT / case["bundle_path"]).resolve(); bundle.relative_to(ROOT)
        if tree_hash(bundle) != case["bundle_tree_sha256"]:
            raise ValueError("semantic case tree drift")
        actual = evaluate_admission(ROOT, bundle, case["contract"], authorization=case["authorization"])
        expected = dict(case["decision"])
        actual.pop("elapsed_sec"); expected.pop("elapsed_sec")
        if actual != expected:
            raise ValueError("semantic case decision drift: " + case["case_id"])
    for name, digest in result["original_trees"].items():
        if tree_hash(resolve_source(ROOT, "experiments/runs/" + name)) != digest:
            raise ValueError("original seed tree drift")
    summary = summarize(result["cases"])
    summary["seed_count"] = len(result["original_trees"])
    if summary != result["summary"]:
        raise ValueError("semantic mutation summary drift")
    return {"status": "PASS", "cases": len(result["cases"]), "scope": result["evidence_kind"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", type=int, default=20)
    args = parser.parse_args()
    raise SystemExit(0 if run(args.output, args.seeds)["verdict"] == "PASS" else 2)
