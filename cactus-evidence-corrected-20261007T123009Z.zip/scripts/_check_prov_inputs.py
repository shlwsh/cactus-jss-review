#!/usr/bin/env python3
"""Check if files in provenance exist."""
import json
from pathlib import Path

# Check the summary.json.provenance.json
prov = json.loads(Path('experiments/derived/governance_20261006T082437Z/summary.json.provenance.json').read_text())
for inp in prov['inputs']:
    p = Path(inp['path'])
    exists = p.exists()
    status = 'EXISTS' if exists else 'NOT FOUND'
    print(f"{inp['path']}: {status}")
