"""Plan fail-closed evaluator-only replays from immutable RUN evidence."""

from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RUNS = ROOT / "experiments" / "runs"
DEFAULT_OUTPUT = ROOT / "analysis"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _display_path(path: Path, *, base: Path = ROOT) -> str:
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return f"external/{path.name}"


def _manifest(bundle: Path) -> dict[str, object]:
    path = bundle / "run_manifest.json"
    if not path.is_file():
        path = bundle / "manifest.json"
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except json.JSONDecodeError:
        return {}


def _find(bundle: Path, patterns: tuple[str, ...]) -> Path | None:
    matches = sorted(path for pattern in patterns for path in bundle.glob(pattern) if path.is_file())
    return matches[0] if matches else None


def plan(source_runs: Path = DEFAULT_RUNS, output_dir: Path = DEFAULT_OUTPUT) -> dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    bundles = sorted({path.parent for path in source_runs.rglob("run_manifest.json")} | {path.parent for path in source_runs.rglob("manifest.json")})
    rows: list[dict[str, object]] = []
    for bundle in bundles:
        manifest = _manifest(bundle)
        patch = _find(bundle, ("patch.diff", "prediction/*.diff", "raw/*.patch", "raw/*.diff"))
        evaluator = _find(bundle, ("evaluator_report.*", "evaluation/*.json", "evaluator/*.json"))
        checksums = bundle / "checksums.sha256"
        sealed = (bundle / "SEALED").is_file() or checksums.is_file()
        status = "ready" if patch and evaluator and sealed else "pending_evidence"
        rows.append({
            "instance_id": manifest.get("instance_id", manifest.get("task_id", bundle.name)),
            "source_bundle": _display_path(bundle),
            "patch_path": _display_path(patch) if patch else None,
            "patch_sha256": _sha(patch) if patch else None,
            "evaluator_report": _display_path(evaluator) if evaluator else None,
            "evaluator_version": manifest.get("evaluator_version"),
            "container_digest": manifest.get("container_digest"),
            "context_bundle_hash": manifest.get("context_bundle_hash"),
            "status": status,
            "model_call_allowed": False,
            "source_immutable": True,
        })
    fields = ["instance_id", "source_bundle", "patch_path", "patch_sha256", "evaluator_report", "evaluator_version", "container_digest", "context_bundle_hash", "status", "model_call_allowed", "source_immutable"]
    with (output_dir / "evaluator_replay_results.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    summary = {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_runs": _display_path(source_runs),
        "bundle_count": len(rows),
        "ready_count": sum(row["status"] == "ready" for row in rows),
        "pending_evidence_count": sum(row["status"] != "ready" for row in rows),
        "model_calls": 0,
        "status": "ready" if rows and all(row["status"] == "ready" for row in rows) else "pending_evidence",
        "note": "Planning only; no model call and no source RUN mutation are permitted.",
    }
    (output_dir / "failure_recovery_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, default=DEFAULT_RUNS)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    print(json.dumps(plan(args.runs, args.output_dir), ensure_ascii=False))
