"""Flatten a LaTeX upload source bundle and independently compile its copy."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.check_publication_pdf import check

DEPENDENCY = re.compile(r'\\(input|include|includegraphics|documentclass|bibliographystyle|bibliography)(?:\[[^]]*\])?\{([^}]+)\}')
SUFFIX = {'input': '.tex', 'include': '.tex', 'documentclass': '.cls', 'bibliographystyle': '.bst', 'bibliography': '.bib', 'includegraphics': '.pdf'}


def flatten(paper):
    paper = Path(paper).resolve()
    files, mapping, names = {}, {}, {}
    def visit(path):
        path = path.resolve()
        relative = path.relative_to(paper).as_posix()
        if path in files:
            return
        target = 'manuscript.tex' if relative == 'main.tex' else path.name
        if target in names and names[target] != path:
            raise ValueError('flattened filename collision: ' + target)
        names[target] = path
        mapping[relative] = target
        files[path] = path.read_bytes()
        if path.suffix == '.tex':
            text = path.read_text(encoding='utf-8')
            for match in DEPENDENCY.finditer(text):
                command, name = match.group(1, 2)
                candidate = paper / name
                if not candidate.suffix:
                    candidate = candidate.with_suffix(SUFFIX[command])
                if command == 'documentclass' and not candidate.exists():
                    continue
                visit(candidate)
    visit(paper / 'main.tex')
    output = {}
    for path, contents in files.items():
        if path.suffix == '.tex':
            text = contents.decode('utf-8')
            def replace(match):
                command, name = match.group(1, 2)
                original = name if Path(name).suffix else name + SUFFIX[command]
                renamed = mapping.get(original)
                if not renamed:
                    return match.group(0)
                if not Path(name).suffix:
                    renamed = str(Path(renamed).with_suffix(''))
                return match.group(0).replace('{' + name + '}', '{' + renamed + '}')
            contents = DEPENDENCY.sub(replace, text).encode('utf-8')
        output[mapping[path.relative_to(paper).as_posix()]] = contents
    return output, mapping


def create(output, paper=ROOT / 'paper'):
    output = Path(output).resolve()
    archive = output.with_name(output.name + '.zip')
    if output.exists() or archive.exists():
        raise FileExistsError('refusing to overwrite source upload bundle')
    files, mapping = flatten(paper)
    output.mkdir(parents=True)
    source = output / 'flat_source'
    source.mkdir()
    for name, contents in files.items():
        (source / name).write_bytes(contents)
    hashes = {name: hashlib.sha256(contents).hexdigest() for name, contents in files.items()}
    manifest = {'generated_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'), 'role': 'flattened manuscript upload source; declarations are separate',
                'submission_ready': False, 'author_approval': 'not asserted', 'source_mapping': mapping, 'sha256': hashes}
    (source / 'SOURCE_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(source.iterdir()):
            bundle.write(path, path.name)
    isolated = output / 'isolated_compile'
    isolated.mkdir()
    with zipfile.ZipFile(archive) as bundle:
        bundle.extractall(isolated)
    for index, command in enumerate((['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'manuscript.tex'], ['bibtex', 'manuscript'],
                                      ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'manuscript.tex'], ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'manuscript.tex'])):
        result = subprocess.run(command, cwd=isolated, capture_output=True, timeout=120)
        (output / f'compile_{index}.log').write_bytes(result.stdout + result.stderr)
        if result.returncode:
            raise ValueError(f'isolated source build failed at command {index}, exit {result.returncode}')
    result = {'status': 'PASS', 'archive': str(archive), 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
              'flat_file_count': len(files), 'compilation': 'pdflatex, bibtex, pdflatex, pdflatex', 'rendering': check(isolated / 'manuscript.pdf', isolated / 'manuscript.log'), 'submission_ready': False}
    (output / 'bundle_validation.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    print(json.dumps(create(parser.parse_args().output), indent=2))
