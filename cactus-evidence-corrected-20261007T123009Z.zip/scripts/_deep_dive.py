"""Deep-dive root cause for 11910 and 12125 across POSTFIX1/2/3 runs."""
import json
from pathlib import Path
from collections import Counter

TASKS = ['django__django-11910', 'django__django-12125']
RUNS = [
    'FACO-FULL-LITE50-POSTFIX-20261003T214359Z',
    'FACO-FULL-LITE50-POSTFIX2-20261003T220125Z',
    'FACO-FULL-LITE50-POSTFIX3-20261003T222550Z',
]

for task in TASKS:
    print(f'\n{"="*80}\nTASK: {task}\n{"="*80}')
    for run in RUNS:
        base = Path(f'experiments/runs/{run}/{task}')
        plog = base/'predict.log'
        evs = base/'events.jsonl'
        if not plog.exists():
            print(f'  --- {run}: NO predict.log ---')
            continue
        plog_text = plog.read_text(encoding='utf-8', errors='ignore').strip()
        # Last line = reason
        reason = plog_text.splitlines()[-1] if plog_text else '?'
        n_events = 0
        rejections = []
        final_3_calls = []
        if evs.exists():
            events = [json.loads(l) for l in evs.read_text(encoding='utf-8', errors='ignore').splitlines()]
            n_events = len(events)
            for e in events:
                if e.get('type') in ('prediction_rejected', 'prediction_sites_rejected', 'prediction_exhausted'):
                    p = e.get('payload', {})
                    rejections.append({
                        'seq': e.get('seq'),
                        'type': e.get('type'),
                        'attempt': p.get('attempt'),
                        'reason': str(p.get('reason', p.get('final_rejection', '')))[:200],
                        'excluded_count': len(p.get('excluded_site_ids', [])) if p.get('excluded_site_ids') else 0,
                    })
            mcalls = [e for e in events if e.get('type') == 'model_call']
            for e in mcalls[-3:]:
                p = e.get('payload', {})
                final_3_calls.append({
                    'seq': e.get('seq'),
                    'turn': p.get('turn_id', '?'),
                    'in': p.get('input_tokens'),
                    'out': p.get('output_tokens'),
                    'finish': p.get('finish_reason'),
                })
        print(f'  --- {run} ---')
        print(f'  final: {reason[:200]}')
        print(f'  events={n_events}, rejections={len(rejections)}')
        for r in rejections:
            print(f'    reject[{r["seq"]}] {r["type"]} attempt={r["attempt"]} exc={r["excluded_count"]}: {r["reason"][:140]}')
        for c in final_3_calls:
            print(f'    call[{c["seq"]}] {c["turn"]} in={c["in"]} out={c["out"]} fin={c["finish"]}')