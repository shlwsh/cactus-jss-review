#!/usr/bin/env python3
"""Read-only audit of local Docker image-cache manifest digest completeness."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = Path("E:/docker-bak/cactus/pilot50")
DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def audit(cache_root: Path = DEFAULT_ROOT) -> dict[str, object]:
    files = sorted(cache_root.rglob("local-manifest.json"))
    malformed: list[str] = []
    unpinned: list[str] = []
    entries = 0
    for path in files:
        try:
            manifest = json.loads(path.read_text(encoding="utf-8"))
            rows = manifest.get("entries", [])
            if not isinstance(rows, list):
                raise ValueError("entries must be a list")
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            malformed.append(f"{path}: {exc}")
            continue
        for row in rows:
            entries += 1
            digest = row.get("candidate_digest") if isinstance(row, dict) else None
            if not isinstance(digest, str) or not DIGEST.fullmatch(digest):
                unpinned.append(str(path.relative_to(cache_root)) + ": candidate_digest missing or invalid")
    failures = malformed + unpinned
    return {
        "status": "pass" if files and not failures else "fail",
        "manifest_count": len(files),
        "image_entry_count": entries,
        "unpinned_entry_count": len(unpinned),
        "malformed_manifest_count": len(malformed),
        "failures": failures,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = audit(args.cache_root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if args.strict and result["status"] != "pass" else 0


if __name__ == "__main__":
    raise SystemExit(main())
