"""Print lines with explicit line numbers around 79-83."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import importlib.util
spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

import ast

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]

ws = Path(tempfile.mkdtemp(prefix="cactus-diag-ln-"))
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)

source = (repo_path / "astropy" / "timeseries" / "core.py").read_text(encoding="utf-8")
lines = source.splitlines()

# Find the raise statements and print lines
print("=== File content lines 75-90 ===")
for i, ln in enumerate(lines[74:90], 75):
    print(f"  {i:3d}: {ln!r}")

tree = ast.parse(source)
print("\n=== Raise statements in _check_required_columns ===")
for cls in ast.walk(tree):
    if isinstance(cls, ast.ClassDef) and cls.name == "BaseTimeSeries":
        for m in cls.body:
            if isinstance(m, ast.FunctionDef) and m.name == "_check_required_columns":
                for sub in ast.iter_child_nodes(m):
                    if isinstance(sub, ast.Raise):
                        print(f"  raise @ line {sub.lineno}, col {sub.col_offset}")
                        print(f"  end_line {sub.end_lineno}, end_col {sub.end_col_offset}")
                        if sub.exc is not None and isinstance(sub.exc, ast.Call):
                            print(f"  exc.args[0] = {type(sub.exc.args[0]).__name__}: {ast.unparse(sub.exc.args[0])[:80]}")
                            if isinstance(sub.exc.args[0], ast.Call):
                                fc = sub.exc.args[0]
                                print(f"  format_call.lineno={fc.lineno}, col={fc.col_offset}")
                                print(f"  format_call.end_lineno={fc.end_lineno}, end_col={fc.end_col_offset}")

import shutil
shutil.rmtree(ws, ignore_errors=True)
