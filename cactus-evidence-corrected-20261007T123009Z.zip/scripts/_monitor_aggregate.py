import sys
from pathlib import Path

sys.path.insert(0, "scripts")
from r4_monitor import monitor_run

RUNS = [
    "RUN-20260925T105655Z-4B606E26",
    "RUN-20260925T111245Z-ED516428",
    "RUN-20260925T113558Z-0D213BFD",
    "RUN-20260925T120939Z-9F868CEF",
    "RUN-20260925T122119Z-500AC775",
    "RUN-20260925T122938Z-66CC37F3",
    "RUN-20260925T124001Z-5F41C11D",
    "RUN-20260925T124946Z-31DC4349",
]

print("=" * 80)
print("STEP 2: R4 MONITOR — AGGREGATE VERDICTS")
print("=" * 80)
fail_count = 0
warn_count = 0
ok_count = 0
for rid in RUNS:
    v = monitor_run(Path(f"experiments/runs/{rid}"))
    sev = v["aggregate_severity"]
    if sev == "fail":
        fail_count += 1
    elif sev == "warn":
        warn_count += 1
    else:
        ok_count += 1
    print(f"\n[{rid}] severity={sev}, n_attempts={v['n_attempts']}")
    for a in v["attempts"]:
        print(f"  attempt finish_reason={a['finish_reason']}, out_tokens={a['output_tokens']}, resp_chars={a['response_chars']}, tags={a['verdict_tags']}")
        for e in a["edits_summary"]:
            tag_str = ",".join(e["tags"]) if e["tags"] else "-"
            print(f"    edit tags={tag_str}, old={e['old_statement_head']!r}, new={e['replacement_head']!r}")
        if a["reject_reason"]:
            print(f"    reject: {a['reject_reason_class']} — {a['reject_reason']}")
print(f"\n=== AGGREGATE: ok={ok_count}, warn={warn_count}, fail={fail_count} ===")
