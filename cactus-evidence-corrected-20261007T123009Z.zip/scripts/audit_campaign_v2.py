"""Audit Campaign V2: Generate comprehensive audit reports and attribution matrices.

Implements Section 6 & TASK-003 of CACTUS Rectification Plan v2.
Outputs all deliverables under artifacts/audit_v2/.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from scripts.migrate_outcomes_v2 import migrate_history
from cactus.failure_recovery.taxonomy import TaskOutcomeV2


def generate_audit_reports(outcomes: list[TaskOutcomeV2], out_dir: Path) -> dict[str, object]:
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. attempt_outcomes_v2.csv
    attempt_csv = out_dir / "attempt_outcomes_v2.csv"
    fieldnames = [
        "task_id",
        "attempt_id",
        "generation_status",
        "patch_parse_status",
        "patch_apply_status",
        "execution_status",
        "evaluator_status",
        "repair_status",
        "failure_family",
        "failure_code",
        "is_algorithm_valid",
        "is_evaluator_valid",
        "is_primary_analysis_eligible",
    ]
    with attempt_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for o in outcomes:
            row = {k: getattr(o, k) for k in fieldnames}
            writer.writerow(row)

    # 2. task_latest_outcome.csv & task_outcomes_v2.csv (deduplicated by task_id taking latest attempt)
    by_task: dict[str, list[TaskOutcomeV2]] = defaultdict(list)
    for o in outcomes:
        by_task[o.task_id].append(o)

    latest_outcomes: list[TaskOutcomeV2] = []
    for tid, attempts in by_task.items():
        # sort by attempt_id
        ordered = sorted(attempts, key=lambda x: x.attempt_id)
        latest_outcomes.append(ordered[-1])

    for fname in ("task_latest_outcome.csv", "task_outcomes_v2.csv"):
        tpath = out_dir / fname
        with tpath.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for o in latest_outcomes:
                row = {k: getattr(o, k) for k in fieldnames}
                writer.writerow(row)

    # 3. failure_family_counts.csv
    fam_counts = Counter(o.failure_family or "SUCCESS" for o in latest_outcomes)
    with (out_dir / "failure_family_counts.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["failure_family", "count", "percentage"])
        total = len(latest_outcomes) or 1
        for fam, cnt in fam_counts.most_common():
            writer.writerow([fam, cnt, f"{(cnt / total) * 100:.2f}%"])

    # 4. failure_code_counts.csv
    code_counts = Counter(o.failure_code or "SUCCESS" for o in latest_outcomes)
    with (out_dir / "failure_code_counts.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["failure_code", "count", "percentage"])
        for code, cnt in code_counts.most_common():
            writer.writerow([code, cnt, f"{(cnt / total) * 100:.2f}%"])

    # 5. overlap_matrix.csv (correlation between empty patch, apply failure, and evaluator status)
    with (out_dir / "overlap_matrix.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["category", "total", "evaluator_not_run", "evaluator_crashed", "evaluator_valid"])
        for cat in ("ALG", "PAT", "EXE", "EVA", "GOV", "SUCCESS"):
            sub = [o for o in latest_outcomes if (o.failure_family or "SUCCESS") == cat]
            c_not_run = sum(1 for o in sub if o.evaluator_status == "NOT_RUN")
            c_crash = sum(1 for o in sub if o.evaluator_status in ("CRASH", "TIMEOUT", "OOM"))
            c_valid = sum(1 for o in sub if o.evaluator_status == "VALID")
            writer.writerow([cat, len(sub), c_not_run, c_crash, c_valid])

    # 6. migration_warnings.csv
    warnings: list[dict[str, str]] = []
    for o in latest_outcomes:
        if o.failure_family == "ALG" and o.evaluator_status == "VALID":
            warnings.append({"task_id": o.task_id, "warning": "ALG failure with VALID evaluator status anomaly"})
        if o.repair_status == "RESOLVED" and o.failure_code is not None:
            warnings.append({"task_id": o.task_id, "warning": "RESOLVED task has residual failure_code"})

    with (out_dir / "migration_warnings.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["task_id", "warning"])
        writer.writeheader()
        for w in warnings:
            writer.writerow(w)

    # 7. audit_summary.json
    unique_tasks = len(latest_outcomes)
    total_attempts = len(outcomes)
    non_empty_gen = sum(1 for o in latest_outcomes if o.generation_status == "NON_EMPTY")
    parsed_diff = sum(1 for o in latest_outcomes if o.patch_parse_status == "PARSED")
    applied_patch = sum(1 for o in latest_outcomes if o.patch_apply_status == "APPLIED")
    eval_valid = sum(1 for o in latest_outcomes if o.is_evaluator_valid)
    resolved = sum(1 for o in latest_outcomes if o.repair_status == "RESOLVED")

    summary = {
        "audit_version": "v2.0",
        "total_sealed_runs": total_attempts,
        "unique_tasks_evaluated": unique_tasks,
        "funnel": {
            "total_tasks": unique_tasks,
            "non_empty_generation": non_empty_gen,
            "generation_efficiency": round(non_empty_gen / max(1, unique_tasks), 4),
            "parsed_diff": parsed_diff,
            "diff_parse_efficiency": round(parsed_diff / max(1, non_empty_gen), 4),
            "applied_patch": applied_patch,
            "patch_apply_efficiency": round(applied_patch / max(1, parsed_diff), 4),
            "evaluator_valid": eval_valid,
            "evaluator_valid_efficiency": round(eval_valid / max(1, applied_patch), 4),
            "resolved": resolved,
            "conditional_resolution_rate": round(resolved / max(1, eval_valid), 4),
            "overall_resolution_rate": round(resolved / max(1, unique_tasks), 4),
        },
        "failure_family_distribution": dict(fam_counts),
        "failure_code_distribution": dict(code_counts),
    }

    with (out_dir / "audit_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit campaign and produce v2 outcome analytics.")
    parser.add_argument("--runs-dir", type=Path, default=ROOT / "experiments" / "runs", help="Path to experiments/runs")
    parser.add_argument("--out-dir", type=Path, default=ROOT / "artifacts" / "audit_v2", help="Directory for audit outputs")
    args = parser.parse_args()

    print(f"[AUDIT] Scanning {args.runs_dir} ...")
    outcomes = migrate_history(args.runs_dir, ROOT / "experiments" / "derived" / "result_registry_v2.jsonl")
    summary = generate_audit_reports(outcomes, args.out_dir)
    print(f"[AUDIT] Audit summary generated at {args.out_dir}:")
    print(json.dumps(summary["funnel"], indent=2))


if __name__ == "__main__":
    main()
