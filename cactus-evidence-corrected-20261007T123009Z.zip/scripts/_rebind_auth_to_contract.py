"""Re-bind auth.contract_sha256 to current contract canonical SHA.

After any contract modification, the session_authorization's
``contract_sha256`` field (computed by session_auth.confirm_authorization
as canonical_json(contract).sha256) must be re-derived; otherwise
formal.py will fail with "session authorization contract_sha256 does
not match contract".

Also update _metadata.linked_contract_sha256 to the file body SHA so
downstream tooling matches either definition.
"""

import hashlib
import json
from pathlib import Path

from cactus.governance.canonical import canonical_json

CONTRACT_PATH = Path(
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
)
AUTH_PATH = CONTRACT_PATH.with_name(CONTRACT_PATH.stem + ".session_authorization.json")


def main() -> int:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    auth = json.loads(AUTH_PATH.read_text(encoding="utf-8"))

    canonical_sha = hashlib.sha256(canonical_json(contract).encode("utf-8")).hexdigest()
    body_sha = hashlib.sha256(CONTRACT_PATH.read_bytes()).hexdigest()

    print(f"canonical_json sha  : {canonical_sha}")
    print(f"file body sha       : {body_sha}")
    print(f"auth.contract_sha   : {auth['contract_sha256']}")
    print(f"auth linked_sha     : {auth['_metadata'].get('linked_contract_sha256')}")

    auth["contract_sha256"] = canonical_sha
    auth["_metadata"]["linked_contract_sha256"] = body_sha
    auth["_metadata"]["rebinding_reason"] = (
        "Re-bound after R2 contract was updated for KPI 3 "
        "(environment_snapshot fields, dacl_baseline fields, study_id, "
        "result_ids, workload.* fields)."
    )
    auth["_metadata"]["rebinding_at"] = "2026-09-25T07:21:00Z"

    out_bytes = json.dumps(
        auth, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    tmp = AUTH_PATH.with_suffix(".json.tmp")
    tmp.write_bytes(out_bytes)
    tmp.replace(AUTH_PATH)

    # Re-verify
    from cactus.governance.schema import validate_session_authorization
    reloaded = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
    print()
    print("validate_session_authorization errors:", validate_session_authorization(reloaded))
    print(f"new auth.contract_sha: {reloaded['contract_sha256']}")
    print(f"new linked_sha       : {reloaded['_metadata']['linked_contract_sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())