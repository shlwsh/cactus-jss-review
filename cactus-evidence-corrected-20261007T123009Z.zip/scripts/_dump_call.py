"""Dump all model_call payload fields."""
import json
import sys
from pathlib import Path

run = Path(sys.argv[1])
events = [json.loads(l) for l in (run / "trace" / "events.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
mc = next(e for e in events if e["type"] == "model_call")
p = mc["payload"]
print("Top-level keys:", list(p.keys()))
print()

# Print all keys with their content (truncated)
for k, v in p.items():
    if isinstance(v, str):
        print(f"=== {k} (str, {len(v)} chars) ===")
        print(v[:4000])
        if len(v) > 4000:
            print(f"... [{len(v) - 4000} more chars]")
        print()
    elif isinstance(v, list):
        print(f"=== {k} (list, {len(v)} items) ===")
        for i, item in enumerate(v):
            if isinstance(item, dict):
                role = item.get("role", "?")
                content = str(item.get("content", ""))
                print(f"--- [{i}] role={role}, {len(content)} chars ---")
                print(content[:3000])
                if len(content) > 3000:
                    print(f"... [{len(content) - 3000} more chars]")
                print()
            elif isinstance(item, str):
                print(f"--- [{i}] ({len(item)} chars) ---")
                print(item[:2000])
                print()
    elif isinstance(v, dict):
        print(f"=== {k} (dict) ===")
        for kk, vv in v.items():
            if isinstance(vv, str):
                print(f"  [{kk}] ({len(vv)} chars): {vv[:500]}")
            else:
                print(f"  [{kk}]: {str(vv)[:300]}")
        print()
    else:
        print(f"=== {k} ({type(v).__name__}): {str(v)[:300]} ===")
