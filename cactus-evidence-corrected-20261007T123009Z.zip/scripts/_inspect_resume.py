import json
from pathlib import Path

base = Path("experiments/runs/FACO-FULL-LITE50-RESUME-20261003T203555Z")
print("Resume status by task:")
for task_dir in sorted(base.iterdir()):
    if not task_dir.is_dir():
        continue
    pred = task_dir / "prediction.jsonl"
    plog = task_dir / "predict.log"
    status = "PRED" if pred.exists() and pred.stat().st_size > 0 else "NO-PRED"
    plog_tail = ""
    if plog.exists():
        plog_text = plog.read_text(encoding="utf-8", errors="ignore")
        plog_tail = plog_text.strip().splitlines()[-1] if plog_text.strip() else ""
    print(f"  {task_dir.name:<35} {status:<7} predict.log-tail={plog_tail[:80]!r}")
