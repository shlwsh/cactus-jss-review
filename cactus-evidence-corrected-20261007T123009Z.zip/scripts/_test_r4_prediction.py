"""Direct prediction test for R4 tasks to verify context selector fixes.

Usage:
    & .\.venv\Scripts\python.exe scripts\_test_r4_prediction.py
"""
from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
VENV_PY = ROOT / ".venv" / "Scripts" / "python.exe"
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
MODEL_CONFIG = ROOT / "configs" / "models" / "litellm_local_nothink_v7.json"
OUTPUT_ROOT = ROOT / "experiments" / "runs"
SCRIPTS_DIR = ROOT / "scripts"

# R4 tasks to verify
R4_TASKS = [
    "astropy__astropy-13033",  # Failed: _check_required_columns not in context
    "astropy__astropy-13236",  # Failed: Table structured column issue
    "astropy__astropy-12907",  # Failed: separable.py not in context (R1/R3)
]

# SWE-bench evaluation dataset - for getting base_commit and repo
EVAL_DATASET = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")

# Repo root - from Docker image's internal path or local checkout
# The predict script needs --repo-root pointing to the checked-out repo
REPO_CACHE = ROOT / "experiments" / "repo_cache"


def load_eval_tasks():
    """Load evaluation tasks to get base_commit per task."""
    tasks = {}
    if EVAL_DATASET.exists():
        with open(EVAL_DATASET) as f:
            for line in f:
                t = json.loads(line)
                tasks[t["instance_id"]] = t
    return tasks


def get_repo_root_for_task(task_id: str) -> Path | None:
    """Determine the repo root for a task.

    The predict script needs --repo-root. For SWE-bench, this is typically
    the git-worktree checkout inside the Docker container's workspace.
    Since we're running locally, we try:
    1. experiments/repo_cache/{repo_id}.git (bare mirror)
    2. A temporary worktree

    For now, we use the Docker image approach via the predict script's
    repo_root handling. We pass None and let the script figure it out,
    OR we create a temporary worktree from the bare mirror.
    """
    eval_tasks = load_eval_tasks()
    task = eval_tasks.get(task_id)
    if not task:
        print(f"  WARNING: {task_id} not in eval dataset")
        return None

    repo_id = task.get("repo", "")
    base_commit = task.get("base_commit", "")
    if not repo_id:
        return None

    # Create a worktree from the bare mirror
    mirror = REPO_CACHE / f"{repo_id.replace('/', '__')}.git"
    if not mirror.exists():
        print(f"  ERROR: bare mirror not found: {mirror}")
        return None

    # Check if base commit exists
    r = subprocess.run(
        ["git", "-C", str(mirror), "cat-file", "-e", f"{base_commit}{{commit}}"],
        capture_output=True, timeout=30,
    )
    if r.returncode != 0:
        print(f"  ERROR: base commit {base_commit} not in mirror")
        return None

    # Create a temporary worktree
    worktree_root = ROOT / "tmp" / "repos"
    worktree_root.mkdir(parents=True, exist_ok=True)
    worktree = worktree_root / repo_id.replace("/", "_")

    if worktree.exists():
        # Update existing worktree
        r = subprocess.run(
            ["git", "-C", str(worktree), "fetch", "origin", base_commit],
            capture_output=True, timeout=60,
        )
        r = subprocess.run(
            ["git", "-C", str(worktree), "checkout", "--detach", base_commit],
            capture_output=True, timeout=30,
        )
    else:
        # Create new worktree
        r = subprocess.run(
            ["git", "worktree", "add", str(worktree), base_commit],
            capture_output=True, timeout=60,
            cwd=str(mirror),
        )
        if r.returncode != 0:
            # Fallback: clone
            print(f"  Fallback: cloning {repo_id}...")
            r = subprocess.run(
                [str(VENV_PY), "-c",
                 f"import subprocess; subprocess.run(['git', 'clone', '{mirror}', '{worktree}'])"],
                capture_output=True, timeout=120,
            )
            if r.returncode == 0:
                r = subprocess.run(
                    ["git", "-C", str(worktree), "checkout", "--detach", base_commit],
                    capture_output=True, timeout=30,
                )

    if r.returncode != 0:
        print(f"  ERROR: failed to create worktree: {r.stderr.decode()[:200]}")
        return None

    print(f"  Repo root: {worktree}")
    return worktree


def run_prediction(task_id: str, timeout_sec: int = 900) -> dict:
    """Run prediction for a single task and return result."""
    repo_root = get_repo_root_for_task(task_id)
    if not repo_root:
        return {"status": "error", "reason": "no_repo_root"}

    output_dir = OUTPUT_ROOT / f"_r4_test_{task_id.replace('__', '_')}_{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    output_dir.mkdir(parents=True, exist_ok=True)

    output_file = output_dir / "prediction.jsonl"
    trace_file = output_dir / "trace.jsonl"

    cmd = [
        str(VENV_PY),
        str(SCRIPTS_DIR / "cactus_swebench_predict.py"),
        "--tasks", str(TASK_MANIFEST),
        "--task-id", task_id,
        "--repo-root", str(repo_root),
        "--model-config", str(MODEL_CONFIG),
        "--trace", str(trace_file),
        "--output", str(output_file),
        "--budget", "14000",
        "--request-timeout-sec", "900",
        "--variant", "cactus_full",
    ]

    print(f"\n  Command: {' '.join(cmd[:6])}...")
    print(f"  Output: {output_dir}")

    env = os.environ.copy()
    # Inject session variables
    env["CACTUS_LITELLM_API_KEY"] = env.get("CACTUS_LITELLM_API_KEY", "sk-dgx-local-2026")
    env["CACTUS_LITELLM_BILLING_API_KEY"] = env.get("CACTUS_LITELLM_BILLING_API_KEY", "sk-fw8MS3ly9sLOd0nK75j-mA")
    env["CACTUS_LITELLM_LOG_KEY_ALIAS"] = env.get("CACTUS_LITELLM_LOG_KEY_ALIAS", "cactus-billing")

    started = time.monotonic()
    try:
        result = subprocess.run(
            cmd,
            cwd=str(ROOT),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
        elapsed = time.monotonic() - started
    except subprocess.TimeoutExpired:
        elapsed = time.monotonic() - started
        return {
            "status": "timeout",
            "task_id": task_id,
            "elapsed_sec": round(elapsed, 1),
            "reason": f"timeout after {timeout_sec}s",
        }

    # Read stderr for analysis
    stderr = result.stderr

    # Check for specific errors
    if "symbol '_check_required_columns' not found" in stderr:
        status = "fail_context"
        reason = "symbol not in context"
    elif "old_statement must exactly match" in stderr:
        status = "fail_context"
        reason = "old_statement mismatch (context issue)"
    elif "RuntimeError: prediction generation exhausted" in stderr:
        status = "fail_model"
        reason = "prediction exhausted"
    elif result.returncode == 0:
        status = "success"
        reason = "prediction generated"
    else:
        status = "error"
        reason = stderr[:200] if stderr else f"exit {result.returncode}"

    return {
        "status": status,
        "task_id": task_id,
        "reason": reason,
        "elapsed_sec": round(elapsed, 1),
        "returncode": result.returncode,
        "stdout_tail": result.stdout[-300:] if result.stdout else "",
        "stderr_tail": stderr[-300:] if stderr else "",
    }


def main():
    print("=" * 70)
    print("R4 上下文选择器修复验证")
    print("=" * 70)
    print(f"Time: {dt.datetime.now(dt.timezone.utc).isoformat()}")
    print(f"Tasks: {R4_TASKS}")
    print()

    results = []
    for i, task_id in enumerate(R4_TASKS):
        print(f"[{i+1}/{len(R4_TASKS)}] 测试任务: {task_id}")
        result = run_prediction(task_id, timeout_sec=900)
        results.append(result)
        print(f"  结果: {result['status']} | {result['reason']} | {result.get('elapsed_sec', '?')}s")

        # Cleanup temp repos
        task = load_eval_tasks().get(task_id, {})
        repo_id = task.get("repo", "")
        worktree = ROOT / "tmp" / "repos" / repo_id.replace("/", "_")
        if worktree.exists():
            try:
                shutil.rmtree(worktree)
            except Exception:
                pass

    print()
    print("=" * 70)
    print("结果汇总")
    print("=" * 70)
    for r in results:
        emoji = {"success": "OK", "fail_context": "CTX", "fail_model": "MOD", "error": "ERR", "timeout": "TMO"}.get(r["status"], r["status"])
        print(f"  {emoji} {r['task_id']}: {r['status']} - {r['reason']} ({r.get('elapsed_sec', '?')}s)")

    # Count
    success = sum(1 for r in results if r["status"] == "success")
    fail_ctx = sum(1 for r in results if r["status"] == "fail_context")
    print()
    print(f"成功: {success}/{len(results)}, 上下文失败: {fail_ctx}")


if __name__ == "__main__":
    main()
