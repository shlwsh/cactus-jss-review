#!/usr/bin/env python3
"""Check the submission package inputs; packaging is blocked until evidence gates pass."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    "paper/main.tex",
    "paper/references.bib",
    "paper/variant_registry.yaml",
    "paper/claim_registry.yaml",
    "README_REPRODUCIBILITY.md",
    "paper/CITATION.cff",
)


def check() -> dict[str, object]:
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    freeze = {}
    try:
        import yaml

        freeze = yaml.safe_load((ROOT / "paper/submission_freeze.yaml").read_text(encoding="utf-8")) or {}
    except (ImportError, OSError, ValueError) as exc:
        missing.append(f"valid paper/submission_freeze.yaml ({exc})")
    protocol = freeze.get("submission_protocol", {})
    unresolved = [
        name
        for name in ("phase_c1_status", "phase_d_status")
        if protocol.get(name) not in {"complete", "sealed"}
    ]
    return {
        "status": "blocked" if missing or unresolved else "ready",
        "required_files_missing": missing,
        "evidence_gates_pending": unresolved,
        "package_created": False,
        "note": "No archive is created while Phase C1/Phase D evidence gates remain pending.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = check()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if args.strict and result["status"] != "ready" else 0


if __name__ == "__main__":
    raise SystemExit(main())
