"""Offline packaged admission validation: 20 synthetic seeds and 160 mutations.

This executes the unchanged production checker on freshly materialized fixtures.
It does not replay or certify the separately retained observed-archive cases.
Authorization-shaped and measured/observed-shaped fixture fields are test inputs,
never owner approval or evidence of a new model/evaluator execution.
"""
from __future__ import annotations

from datetime import datetime, timezone
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]

from cactus.governance.admission import evaluate_admission
from cactus.governance.canonical import canonical_json
from scripts.import_formal_run_bundles import tree_hash
from scripts.run_admission_semantic_suite import OPERATORS, mutate, summarize


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n',
                    encoding='utf-8', newline='\n')


def fixture_factory():
    """Load the shipped regression factory without requiring tests as a package."""
    path = ROOT / 'tests/test_admission_semantics.py'
    spec = importlib.util.spec_from_file_location('packaged_admission_fixture', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.AdmissionSemanticsTests(methodName='test_valid_control')


def run(root=ROOT):
    root = Path(root).resolve()
    output_parent = root / 'synthetic_semantic_runs'
    output_parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output = Path(tempfile.mkdtemp(prefix=stamp + '-', dir=output_parent))
    source_directory = output / 'source_capsule'
    source_directory.mkdir()
    # Independent synthetic bytes, not a guess about omitted historical commits.
    baseline_source = {'driver.py': b'# synthetic driver fixture\n',
                       'derive.py': b'# synthetic derivation fixture\n'}
    alternate_source = {**baseline_source, 'driver.py': b'# alternate synthetic driver fixture\n'}
    commits = {'1' * 40: baseline_source, '5' * 40: alternate_source}
    source_paths = {}
    for commit, source in commits.items():
        directory = source_directory / commit
        directory.mkdir()
        for name, content in source.items():
            path = directory / name
            path.write_bytes(content)
            source_paths[commit, name] = (path, digest(path))

    def source_lookup(_root, commit, relative):
        path, expected = source_paths[commit, relative]
        actual = digest(path)
        if actual != expected:
            raise ValueError('synthetic source capsule bytes changed')
        return actual

    tasks = ['synthetic__case-' + str(index + 1) for index in range(20)]
    fixture = fixture_factory()
    fixture.root = output / 'seeds'
    fixture.root.mkdir()
    fixture.contract = {
        'experiment_id': 'EXP-SYNTHETIC-TEST', 'source': {'git_commit': '1' * 40},
        'workload': {'driver': 'driver.py', 'sha256': source_paths['1' * 40, 'driver.py'][1]},
        'derivation': {'script': 'derive.py', 'sha256': source_paths['1' * 40, 'derive.py'][1]},
        'model': {'model_version': 'test-v1'},
        'images': {task: {'repository': 'swebench/sweb.eval.x86_64.' + task.replace('__', '_1776_'),
                          'digest': 'sha256:' + '4' * 64} for task in tasks},
    }
    # Required schema fields imitate authorization solely to exercise the checker.
    fixture.auth = {
        'schema_version': '1.0', 'authorization_type': 'session_confirmation', 'status': 'approved',
        'experiment_id': fixture.contract['experiment_id'], 'approved_by': 'project_owner',
        'approved_at': '2026-10-07T00:00:00Z',
        'confirmation_quote': 'SYNTHETIC PACKAGE FIXTURE ONLY; NEVER OWNER APPROVAL',
        'scope': 'synthetic checker test input only; not an experiment authorization',
        'contract_sha256': hashlib.sha256(canonical_json(fixture.contract).encode()).hexdigest(),
    }
    save(output / 'fixture_contract.json', fixture.contract)
    save(output / 'fixture_authorization.json', fixture.auth)
    seeds = [fixture.make_bundle(f'RUN-20261007T000000Z-{index + 1:08X}', task, 100 + index)
             for index, task in enumerate(tasks)]
    original_trees = {seed.name: tree_hash(seed) for seed in seeds}
    cases = []
    failures = []
    for index, seed in enumerate(seeds):
        donor = seeds[(index + 1) % len(seeds)]
        for operator in ['control', *OPERATORS]:
            case_id = f'{operator}-{index + 1:03d}'
            target = output / 'cases' / case_id / seed.name
            shutil.copytree(seed, target)
            auth = copy.deepcopy(fixture.auth)
            if operator != 'control':
                mutate(operator, target, donor, donor_commit='5' * 40,
                       driver_digest=source_paths['5' * 40, 'driver.py'][1])
                if operator == 'S07_authorization_substitution':
                    auth['experiment_id'] = 'EXP-OTHER-SYNTHETIC-PACKAGE'
            save(target.parent / 'fixture_authorization.json', auth)
            decision = evaluate_admission(root, target, fixture.contract,
                                          authorization=auth, source_lookup=source_lookup)
            expected_admitted = operator == 'control'
            expected_reason = None if expected_admitted else OPERATORS[operator]
            expected_stage = 'none' if expected_admitted else 'semantic'
            passed = (decision['integrity_passed'] and decision['admitted'] == expected_admitted
                      and decision['stage'] == expected_stage
                      and (expected_reason is None or expected_reason in decision['reasons']))
            if not passed:
                failures.append(case_id)
            cases.append({'case_id': case_id, 'origin': 'synthetic', 'operator': operator,
                          'seed_run_id': seed.name, 'task_id': tasks[index],
                          'bundle_path': target.relative_to(root).as_posix(),
                          'bundle_tree_sha256': tree_hash(target), 'expected_admitted': expected_admitted,
                          'expected_reason': expected_reason, 'expected_stage': expected_stage,
                          'case_validation_passed': passed, 'decision': decision})
    if original_trees != {seed.name: tree_hash(seed) for seed in seeds}:
        raise ValueError('synthetic seed fixtures were modified')
    summary = summarize(cases)
    summary['seed_count'] = len(seeds)
    report = {
        'schema_version': '1.0', 'generated_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'origin': 'synthetic', 'evidence_kind': 'fresh synthetic fixture execution of unchanged production core',
        'scope': '20 synthetic controls and 160 checksum-consistent mutations; not replay of observed archive cases',
        'fixture_authorization_is_owner_approval': False,
        'fixture_claim_fields': 'measured/observed-shaped fields are synthetic checker inputs, not measured repair evidence',
        'source_lookup': 'independent synthetic byte capsule; no Git history or network lookup',
        'admission_implementation': 'src/cactus/governance/admission.py',
        'admission_sha256': digest(ROOT / 'src/cactus/governance/admission.py'),
        'mutation_implementation': 'scripts/run_admission_semantic_suite.py',
        'mutation_sha256': digest(ROOT / 'scripts/run_admission_semantic_suite.py'),
        'fixture_factory': 'tests/test_admission_semantics.py',
        'fixture_factory_sha256': digest(ROOT / 'tests/test_admission_semantics.py'),
        'operators': OPERATORS, 'summary': summary, 'original_seed_trees': original_trees,
        'source_capsule_hashes': {path.relative_to(root).as_posix(): expected for path, expected in source_paths.values()},
        'latency_scope': 'synthetic on-disk core evaluation only; not historical latency replication',
        'validation_failures': failures, 'verdict': 'FAIL' if failures else 'PASS', 'cases': cases,
    }
    save(output / 'synthetic_semantic_validation.json', report)
    save(root / 'synthetic_semantic_validation.json', report)
    provenance = {'schema_version': '1.0', 'origin': 'synthetic',
                  'generated_at': report['generated_at'],
                  'artifact_sha256': digest(output / 'synthetic_semantic_validation.json'),
                  'immutable_snapshot': (output / 'synthetic_semantic_validation.json').relative_to(root).as_posix(),
                  'generator_sha256': digest(Path(__file__)),
                  'admission_sha256': report['admission_sha256'], 'mutation_sha256': report['mutation_sha256'],
                  'fixture_factory_sha256': report['fixture_factory_sha256'],
                  'source_capsule_hashes': report['source_capsule_hashes']}
    save(output / 'synthetic_semantic_validation.json.provenance.json', provenance)
    save(root / 'synthetic_semantic_validation.json.provenance.json', provenance)
    print(json.dumps({'verdict': report['verdict'], 'origin': 'synthetic',
                      'summary': summary, 'validation_failures': failures}, indent=2))
    return report


if __name__ == '__main__':
    raise SystemExit(0 if run()['verdict'] == 'PASS' else 2)
