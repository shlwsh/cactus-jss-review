"""End-to-end binding verification for R2 contract / auth / snapshot."""

import hashlib
import json

from cactus.governance.contract import validate_contract
from cactus.governance.schema import (
    validate_environment_snapshot,
    validate_session_authorization,
)

CONTRACT = "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
AUTH = "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.session_authorization.json"
SNAP = "experiments/snapshots/C1-pre-r2-20260925T071721Z_pending_dacl.json"
BASELINE = "experiments/snapshots/dacl_baseline_R2_20260925-151621.json"


def sha(path: str) -> str:
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def main() -> int:
    contract = json.loads(open(CONTRACT).read())
    auth = json.loads(open(AUTH).read())
    snap = json.loads(open(SNAP).read())

    print("=== schema validation ===")
    print("contract:", validate_contract(contract))
    print("session_auth:", validate_session_authorization(auth))
    print("env_snapshot:", validate_environment_snapshot(snap))

    print("\n=== contract / auth binding ===")
    contract_body_sha = sha(CONTRACT)
    print(f"contract body SHA-256     : {contract_body_sha}")
    print(f"auth linked_contract_sha  : {auth['_metadata']['linked_contract_sha256']}")
    print(f"match: {contract_body_sha == auth['_metadata']['linked_contract_sha256']}")

    print("\n=== contract / snapshot binding ===")
    print(f"contract.compose_sha256   : {contract['runtime']['compose_sha256']}")
    print(f"contract env_snap sha     : {contract['execution']['environment_snapshot_sha256']}")
    actual_snap = sha(SNAP)
    print(f"snapshot actual sha256    : {actual_snap}")
    print(f"snapshot match: {contract['execution']['environment_snapshot_sha256'] == actual_snap}")

    print("\n=== contract / dacl baseline binding ===")
    declared_baseline = contract["execution"]["dacl_baseline_sha256"]
    actual_baseline = sha(BASELINE)
    print(f"contract dacl_baseline sha: {declared_baseline}")
    print(f"baseline actual sha       : {actual_baseline}")
    print(f"match: {declared_baseline == actual_baseline}")

    print("\n=== environment snapshot dacl_status ===")
    print(f"  status: {snap['extra']['dacl_status']}")
    print(f"  data_roots.read_only   : {[v['read_only'] for v in snap['data_roots'].values()]}")

    print("\n=== file inventory ===")
    import os
    for path in (CONTRACT, AUTH, SNAP, BASELINE):
        size = os.path.getsize(path)
        sidecar = path + ".sha256"
        side = open(sidecar).read().strip() if os.path.exists(sidecar) else "<none>"
        print(f"  {path}")
        print(f"    size={size}  sidecar={side}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())