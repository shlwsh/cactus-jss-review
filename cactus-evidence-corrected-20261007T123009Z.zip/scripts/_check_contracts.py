"""Compare contract model binding vs think sidecar."""
import json
from pathlib import Path

c = json.loads(Path("experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json").read_text(encoding="utf-8"))
print("=== Contract model section ===")
print(json.dumps(c.get("model", {}), indent=2)[:2000])
print()
print("=== Contract sha256 ===")
print(c.get("contract_sha256"))
print()
mc = json.loads(Path("configs/models/litellm_local.json").read_text(encoding="utf-8"))
print("=== litellm_local.json (used by contract) ===")
for k in ("thinking", "max_output_tokens", "reasoning_effort", "deployment_name"):
    print(f"  {k}: {mc.get(k)}")
print()
mc2 = json.loads(Path("configs/models/litellm_local_think.json").read_text(encoding="utf-8"))
print("=== litellm_local_think.json (sidecar I created) ===")
for k in ("thinking", "max_output_tokens", "reasoning_effort", "deployment_name"):
    print(f"  {k}: {mc2.get(k)}")
