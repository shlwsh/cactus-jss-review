"""Verify gold patch fixes 13033 test."""
from pathlib import Path
import tempfile
import subprocess
import sys
import shutil
import json

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest = list(load_manifest(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"))
task = next(t for t in manifest if t.task_id == "astropy__astropy-13033")
ws = Path(tempfile.mkdtemp(prefix="cactus-gold-test-"))
repo = checkout_base_commit(task, cache_root=Path(r"E:\cactus-data\repo-cache"), workspace_root=ws, allow_network_fetch=True)
print(f"repo: {repo}")

# Apply GOLD patch using file (avoid quoting issues)
gold_patch_file = ws / "gold.patch"
gold_patch_file.write_text(
    "diff --git a/astropy/timeseries/core.py b/astropy/timeseries/core.py\n"
    "--- a/astropy/timeseries/core.py\n"
    "+++ b/astropy/timeseries/core.py\n"
    "@@ -55,6 +55,13 @@ class BaseTimeSeries(QTable):\n"
    "     _required_columns_relax = False\n"
    " \n"
    "     def _check_required_columns(self):\n"
    "+        def as_scalar_or_list_str(obj):\n"
    "+            if not hasattr(obj, \"__len__\"):\n"
    "+                return f\"'{obj}'\"\n"
    "+            elif len(obj) == 1:\n"
    "+                return f\"'{obj[0]}'\"\n"
    "+            else:\n"
    "+                return str(obj)\n"
    " \n"
    "         if not self._required_columns_enabled:\n"
    "             return\n"
    "@@ -76,9 +83,10 @@ def _check_required_columns(self):\n"
    " \n"
    "             elif self.colnames[:len(required_columns)] != required_columns:\n"
    " \n"
    "-                raise ValueError(\"{} object is invalid - expected '{}' \"\n"
    "-                                 \"as the first column{} but found '{}'\"\n"
    "-                                 .format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))\n"
    "+                raise ValueError(\"{} object is invalid - expected {} \"\n"
    "+                                 \"as the first column{} but found {}\"\n"
    "+                                 .format(self.__class__.__name__, as_scalar_or_list_str(required_columns),\n"
    "+                                            plural, as_scalar_or_list_str(self.colnames[:len(required_columns)])))\n"
    " \n"
    "             if (self._required_columns_relax\n"
    "                     and self._required_columns == self.colnames[:len(self._required_columns)]):\n"
    "                 self._required_columns_relax = False\n",
    encoding="utf-8",
)
result = subprocess.run(
    ["git", "-C", str(repo), "apply", "--whitespace=nowarn", str(gold_patch_file)],
    capture_output=True, text=True,
)
print(f"gold patch apply: rc={result.returncode} stderr={result.stderr.strip()}")

# Apply the test_patch
test_patch_file = ws / "test.patch"
test_patch_file.write_text(
    "diff --git a/astropy/timeseries/tests/test_sampled.py b/astropy/timeseries/tests/test_sampled.py\n"
    "--- a/astropy/timeseries/tests/test_sampled.py\n"
    "+++ b/astropy/timeseries/tests/test_sampled.py\n"
    "@@ -395,6 +395,14 @@ def test_required_columns():\n"
    "     assert exc.value.args[0] == (\"TimeSeries object is invalid - expected \"\n"
    "                                  \"'time' as the first column but found 'banana'\")\n"
    " \n"
    "+    # https://github.com/astropy/astropy/issues/13009\n"
    "+    ts_2cols_required = ts.copy()\n"
    "+    ts_2cols_required._required_columns = ['time', 'a']\n"
    "+    with pytest.raises(ValueError) as exc:\n"
    "+        ts_2cols_required.remove_column('a')\n"
    "+    assert exc.value.args[0] == (\"TimeSeries object is invalid - expected \"\n"
    "+                                 \"['time', 'a'] as the first columns but found ['time', 'b']\")\n"
    "+\n"
    " \n"
    " @pytest.mark.parametrize('cls', [BoxLeastSquares, LombScargle])\n"
    " def test_periodogram(cls):\n",
    encoding="utf-8",
)
result = subprocess.run(
    ["git", "-C", str(repo), "apply", "--whitespace=nowarn", str(test_patch_file)],
    capture_output=True, text=True,
)
print(f"test_patch apply: rc={result.returncode} stderr={result.stderr.strip()}")

# Run pytest with system Python (C:\Python313 has pytest 9.1.1)
print("\n=== Running pytest test_required_columns (with gold patch) ===")
result = subprocess.run(
    [r"C:\Python313\python.exe", "-m", "pytest",
     "astropy/timeseries/tests/test_sampled.py::test_required_columns",
     "-xvs", "--tb=short", "--no-header"],
    cwd=str(repo),
    capture_output=True, text=True,
    timeout=180,
    env={**__import__("os").environ, "PYTHONPATH": "."},
)
print("--- stdout ---")
print(result.stdout[:5000])
print("--- stderr ---")
print(result.stderr[:1500])