"""Pull missing Pilot evaluator images with bounded retries and an audit record."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PLAN = ROOT / "artifacts" / "phase_c_pilot50_plan.json"
DEFAULT_OUTPUT = ROOT / "artifacts" / "pilot50_image_pull_report.json"
DEFAULT_CACHE_DIR = Path("E:/docker-bak/cactus/pilot50")
SHARED_ARCHIVE_RELATIVE = Path("shared") / "base-images.docker.tar"
SHARED_MANIFEST_RELATIVE = Path("shared") / "base-manifest.json"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _available(image_ref: str) -> bool:
    result = subprocess.run(["docker", "image", "inspect", image_ref], capture_output=True, text=True, check=False)
    return result.returncode == 0


def _category(image_ref: str) -> str:
    """Return the benchmark repository category encoded in a SWE-bench image ref."""
    repository = image_ref.split("@", 1)[0].split(":", 1)[0].rsplit("/", 1)[-1]
    match = re.search(r"_\d+_(?P<repo>[^:]+?)-\d+$", repository)
    if match:
        return match.group("repo").lower().replace("_", "-")
    return repository.lower().replace("_", "-")


def _inspect_local(image_ref: str) -> dict[str, Any] | None:
    """Read local Docker metadata without contacting a registry."""
    result = subprocess.run(["docker", "image", "inspect", image_ref], capture_output=True, text=True, check=False)
    if result.returncode != 0:
        return None
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, list) or not payload or not isinstance(payload[0], dict):
        return None
    item = payload[0]
    repo_digests = [value for value in item.get("RepoDigests", []) if isinstance(value, str)]
    image_id = item.get("Id")
    return {
        "image_ref": image_ref,
        "category": _category(image_ref),
        "repository": image_ref.split("@", 1)[0].split(":", 1)[0],
        "local_image_id": image_id if isinstance(image_id, str) else None,
        "repo_digests": sorted(repo_digests),
        "candidate_digest": next((value.rsplit("@", 1)[-1] for value in repo_digests if "@sha256:" in value), None),
        "cached_at": _utc_now(),
        "cache_source": "docker-local-image-store",
    }


def _load_cache(cache_dir: Path) -> dict[str, dict[str, Any]]:
    index_path = cache_dir / "local-cache-index.json"
    if not index_path.exists():
        return {}
    try:
        payload = json.loads(index_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    entries = payload.get("entries", []) if isinstance(payload, dict) else []
    return {str(item["image_ref"]): item for item in entries if isinstance(item, dict) and item.get("image_ref")}


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _shared_archive(cache_dir: Path, required_refs: list[str] | None = None) -> Path | None:
    """Resolve a valid shared archive from the cache manifest."""
    manifest_path = cache_dir / SHARED_MANIFEST_RELATIVE
    archive_path = cache_dir / SHARED_ARCHIVE_RELATIVE
    if not manifest_path.exists() or not archive_path.exists():
        return None
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(manifest, dict) or manifest.get("storage_strategy") != "single-shared-layer-bundle":
        return None
    manifest_refs = manifest.get("image_refs", [])
    if required_refs is not None and (not isinstance(manifest_refs, list) or not set(required_refs).issubset({str(ref) for ref in manifest_refs})):
        return None
    expected = manifest.get("archive_sha256")
    if not isinstance(expected, str) or len(expected) != 64 or _sha256_file(archive_path) != expected:
        return None
    return archive_path


def _write_cache(
    cache_dir: Path,
    entries: dict[str, dict[str, Any]],
    source_plan_sha256: str,
    network_pull_count: int,
    archive_load_count: int = 0,
    archive_restore_status: str = "NOT_NEEDED",
) -> None:
    """Persist one aggregate index and one manifest per benchmark category."""
    ordered = [entries[key] for key in sorted(entries)]
    categories: dict[str, list[dict[str, Any]]] = {}
    for item in ordered:
        categories.setdefault(str(item["category"]), []).append(item)
    cache_dir.mkdir(parents=True, exist_ok=True)
    index = {
        "schema_version": "1.0",
        "generated_at": _utc_now(),
        "cache_scope": "swebench-pilot50",
        "source_plan_sha256": source_plan_sha256,
        "entry_count": len(ordered),
        "category_count": len(categories),
        "network_pull_count": network_pull_count,
        "archive_load_count": archive_load_count,
        "archive_restore_status": archive_restore_status,
        "storage_strategy": "single-shared-layer-bundle",
        "shared_archive": SHARED_ARCHIVE_RELATIVE.as_posix(),
        "categories": sorted(categories),
        "entries": ordered,
    }
    (cache_dir / "local-cache-index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    for category, category_entries in categories.items():
        category_dir = cache_dir / category
        category_dir.mkdir(parents=True, exist_ok=True)
        manifest = {
            "schema_version": "1.0",
            "generated_at": index["generated_at"],
            "cache_scope": "swebench-pilot50",
            "category": category,
            "source_plan_sha256": source_plan_sha256,
            "entry_count": len(category_entries),
            "storage_strategy": "shared-layer-bundle",
            "shared_archive": Path("..").joinpath(SHARED_ARCHIVE_RELATIVE).as_posix(),
            "entries": category_entries,
        }
        (category_dir / "local-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def pull(
    plan_path: Path = DEFAULT_PLAN,
    output: Path = DEFAULT_OUTPUT,
    retries: int = 3,
    retry_delay_sec: float = 10.0,
    pull_timeout_sec: float = 300.0,
    max_images: int | None = None,
    command_runner=subprocess.run,
    sleeper=time.sleep,
    cache_dir: Path = DEFAULT_CACHE_DIR,
    categories: set[str] | None = None,
    cache_only: bool = False,
) -> dict[str, Any]:
    if retries < 1:
        raise ValueError("retries must be positive")
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes.decode("utf-8"))
    planned = plan.get("evaluator_images") if isinstance(plan, dict) else None
    if not isinstance(planned, list):
        raise ValueError("pilot50 plan has no evaluator_images list")
    refs = [str(item.get("image")) for item in planned if isinstance(item, dict) and item.get("image")]
    if categories:
        normalized_categories = {value.lower().replace("_", "-") for value in categories}
        refs = [image_ref for image_ref in refs if _category(image_ref) in normalized_categories]
    if max_images is not None:
        refs = refs[:max_images]

    cache_entries = _load_cache(cache_dir)
    records: list[dict[str, Any]] = []
    network_pull_count = 0
    cache_hit_count = 0
    cache_write_count = 0
    archive_load_count = 0
    archive_restore_status = "NOT_NEEDED"
    archive_load_timeout_sec = max(pull_timeout_sec, 1800.0)
    shared_archive = _shared_archive(cache_dir, refs)
    availability = {image_ref: _available(image_ref) for image_ref in refs}
    restored_refs: set[str] = set()
    missing_refs = [image_ref for image_ref in refs if not availability[image_ref]]
    if missing_refs and shared_archive is not None:
        archive_restore_status = "FAILED"
        try:
            load_result = command_runner(["docker", "load", "--input", str(shared_archive)], capture_output=True, text=True, check=False, timeout=archive_load_timeout_sec)
            archive_load_count = 1
            if load_result.returncode == 0:
                for image_ref in missing_refs:
                    availability[image_ref] = _available(image_ref)
                    if availability[image_ref]:
                        restored_refs.add(image_ref)
                archive_restore_status = "LOADED" if restored_refs else "LOADED_NO_PLANNED_REFS"
            else:
                archive_restore_status = "LOAD_FAILED"
        except subprocess.TimeoutExpired:
            archive_load_count = 1
            archive_restore_status = "LOAD_TIMEOUT"
    for image_ref in refs:
        if availability[image_ref]:
            status = "SHARED_ARCHIVE_HIT" if image_ref in restored_refs else ("CACHE_HIT" if image_ref in cache_entries else "ALREADY_AVAILABLE")
            if status == "CACHE_HIT":
                cache_hit_count += 1
            records.append({"image_ref": image_ref, "category": _category(image_ref), "status": status, "attempts": 0})
            metadata = _inspect_local(image_ref)
            if metadata is not None:
                cache_entries[image_ref] = metadata
                cache_write_count += 1
            continue
        if cache_only:
            records.append({"image_ref": image_ref, "category": _category(image_ref), "status": "MISSING_LOCAL_CACHE", "attempts": []})
            continue
        attempts: list[dict[str, Any]] = []
        for attempt in range(1, retries + 1):
            network_pull_count += 1
            try:
                result = command_runner(
                    ["docker", "pull", "--quiet", image_ref],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=pull_timeout_sec,
                )
            except subprocess.TimeoutExpired as exc:
                attempts.append({"attempt": attempt, "returncode": None, "message": f"docker pull timed out after {pull_timeout_sec}s: {exc}"})
                if attempt < retries:
                    sleeper(retry_delay_sec * (2 ** (attempt - 1)))
                continue
            combined = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
            attempts.append({"attempt": attempt, "returncode": result.returncode, "message": combined[-1000:]})
            if result.returncode == 0 and _available(image_ref):
                availability[image_ref] = True
                records.append({"image_ref": image_ref, "category": _category(image_ref), "status": "PULLED_AND_CACHED", "attempts": attempts})
                metadata = _inspect_local(image_ref)
                if metadata is not None:
                    cache_entries[image_ref] = metadata
                    cache_write_count += 1
                break
            if attempt < retries:
                sleeper(retry_delay_sec * (2 ** (attempt - 1)))
        else:
            records.append({"image_ref": image_ref, "category": _category(image_ref), "status": "FAILED", "attempts": attempts})

    _write_cache(cache_dir, cache_entries, hashlib.sha256(plan_bytes).hexdigest(), network_pull_count, archive_load_count, archive_restore_status)
    available_count = sum(item["status"] in {"CACHE_HIT", "ALREADY_AVAILABLE", "SHARED_ARCHIVE_HIT", "PULLED_AND_CACHED"} for item in records)
    failed_count = sum(item["status"] == "FAILED" for item in records)
    failed_count += sum(item["status"] == "MISSING_LOCAL_CACHE" for item in records)
    result = {
        "schema_version": "1.0",
        "generated_at": _utc_now(),
        "source_plan": plan_path.as_posix(),
        "source_plan_sha256": hashlib.sha256(plan_bytes).hexdigest(),
        "cache_dir": cache_dir.as_posix(),
        "cache_only": cache_only,
        "categories": sorted({_category(image_ref) for image_ref in refs}),
        "planned_scope_count": len(refs),
        "available_or_pulled_count": available_count,
        "failed_count": failed_count,
        "cache_hit_count": cache_hit_count,
        "shared_archive": shared_archive.as_posix() if shared_archive else None,
        "archive_load_count": archive_load_count,
        "archive_restore_status": archive_restore_status,
        "cache_write_count": cache_write_count,
        "network_pull_count": network_pull_count,
        "execution_performed": False,
        "model_calls": 0,
        "billing_calls": 0,
        "status": "complete" if failed_count == 0 else "partial_failure",
        "images": records,
        "next_action": "Run observe_pilot50_image_digests.py after all planned images are available; subsequent runs reuse the shared archive and local metadata." if failed_count == 0 else "Retry failed images after the shared archive or registry connection recovers; no formal execution is permitted.",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--retry-delay-sec", type=float, default=10.0)
    parser.add_argument("--pull-timeout-sec", type=float, default=300.0)
    parser.add_argument("--max-images", type=int)
    parser.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE_DIR)
    parser.add_argument("--category", action="append", dest="categories", help="Only process this repository category; repeatable")
    parser.add_argument("--cache-only", action="store_true", help="Never contact the registry; report only locally available images")
    args = parser.parse_args()
    result = pull(args.plan, args.output, args.retries, args.retry_delay_sec, args.pull_timeout_sec, args.max_images, cache_dir=args.cache_dir, categories=set(args.categories or ()), cache_only=args.cache_only)
    print(json.dumps({key: result[key] for key in ("status", "planned_scope_count", "available_or_pulled_count", "failed_count")}, ensure_ascii=False))
    return 0 if result["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
