"""Summarize executed evaluator-only replays without upgrading evidence."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from cactus.evaluation.taxonomy_v2 import classify_text


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTCOMES = ROOT / "paper" / "data" / "final_task_outcomes.csv"
DEFAULT_OUTPUT = ROOT / "analysis" / "evaluator_replay_observed_summary.json"


def _default_roots() -> tuple[Path, ...]:
    return tuple(sorted(ROOT.glob("artifacts/replay-executed-*")))


def _replay_manifests(roots: tuple[Path, ...]) -> list[dict[str, object]]:
    manifests: list[dict[str, object]] = []
    for root in roots:
        if not root.is_dir():
            continue
        for path in sorted(root.rglob("replay_manifest.json")):
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(value, dict) and value.get("mode") == "evaluator_only":
                value["_path"] = path.as_posix()
                manifests.append(value)
    return manifests


def _historical_errors(path: Path) -> set[str]:
    with path.open(encoding="utf-8", newline="") as handle:
        return {
            row["task"]
            for row in csv.DictReader(handle)
            if row.get("error") == "1" and row.get("task")
        }


def _classification(manifest: dict[str, object]) -> dict[str, object]:
    replay_path = Path(str(manifest.get("_path", ""))).parent
    text_parts: list[str] = []
    for name in ("stdout.log", "stderr.log"):
        path = replay_path / "logs" / name
        if path.is_file():
            text_parts.append(path.read_text(encoding="utf-8", errors="replace"))
    result = classify_text("\n".join(text_parts))
    report = manifest.get("report") if isinstance(manifest.get("report"), dict) else {}
    errors = int(report.get("error_instances", 0) or 0)
    infra = int(report.get("infra_failure_instances", 0) or 0)
    completed = int(report.get("completed_instances", 0) or 0)
    if infra:
        outcome = "evaluator_infrastructure_failure"
    elif errors:
        outcome = "algorithm_invalid_patch" if result.failure_family.value == "A" else "evaluator_task_error"
    elif completed:
        outcome = "evaluator_valid"
    else:
        outcome = "missing_evaluator_outcome"
    return {
        "task_id": manifest.get("instance_id"),
        "replay_id": manifest.get("replay_id"),
        "replay_status": manifest.get("status"),
        "outcome": outcome,
        "failure_family": result.failure_family.value,
        "failure_code": result.failure_code.value,
        "source_bundle_unchanged": manifest.get("source_bundle_unchanged") is True,
        "evaluator_image_digest": manifest.get("evaluator_image_digest"),
    }


def summarize(
    roots: tuple[Path, ...] | None = None,
    outcomes_path: Path = DEFAULT_OUTCOMES,
    output: Path = DEFAULT_OUTPUT,
) -> dict[str, object]:
    manifests = _replay_manifests(roots or _default_roots())
    # Keep the latest observed replay for each task in the task-level summary.
    latest: dict[str, dict[str, object]] = {}
    for manifest in manifests:
        task_id = str(manifest.get("instance_id", ""))
        if task_id:
            latest[task_id] = _classification(manifest)
    rows = [latest[key] for key in sorted(latest)]
    historical = _historical_errors(outcomes_path) if outcomes_path.is_file() else set()
    replayed_historical = sorted(set(latest) & historical)
    valid_count = sum(row["outcome"] == "evaluator_valid" for row in rows)
    observed_count = len(rows)
    summary: dict[str, object] = {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "mode": "evaluator_only_observed",
        "model_calls": 0,
        "billing_calls": 0,
        "replay_invocation_count": len(manifests),
        "unique_replayed_task_count": observed_count,
        "historical_evaluator_error_count": len(historical),
        "replayed_historical_error_task_count": len(replayed_historical),
        "pending_historical_error_task_count": len(historical - set(replayed_historical)),
        "evaluator_valid_task_count": valid_count,
        "evaluator_validity_rate": valid_count / observed_count if observed_count else None,
        "outcome_counts": dict(sorted(Counter(str(row["outcome"]) for row in rows).items())),
        "replayed_historical_task_ids": replayed_historical,
        "status": "observed_partial" if historical - set(replayed_historical) else "observed_complete",
        "rows": rows,
        "note": "Task-level replay evidence only; pending historical errors remain unevaluated and no causal claim is inferred beyond the captured evaluator log classification.",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", action="append", dest="roots", type=Path)
    parser.add_argument("--outcomes", type=Path, default=DEFAULT_OUTCOMES)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    roots = tuple(args.roots) if args.roots else None
    result = summarize(roots, args.outcomes, args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
