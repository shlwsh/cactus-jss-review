"""Freeze the current paper, protocol and outcome state without mutating inputs."""

from __future__ import annotations

import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-PILOT-V2.json"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git(args: list[str]) -> str:
    return subprocess.run(["git", *args], cwd=ROOT, text=True, capture_output=True, check=False).stdout.strip()


def _outcome_snapshot(path: Path) -> dict[str, int]:
    counts = {"unique": 0, "resolved": 0, "unresolved": 0, "evaluator_error": 0, "pending": 0}
    if not path.is_file():
        return counts
    with path.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    counts["unique"] = len({row.get("task", "") for row in rows if row.get("task")})
    counts["resolved"] = sum(row.get("resolved") == "1" for row in rows)
    counts["unresolved"] = sum(row.get("unresolved") == "1" for row in rows)
    counts["evaluator_error"] = sum(row.get("error") == "1" for row in rows)
    counts["pending"] = sum(row.get("status") == "pending" for row in rows)
    return counts


def _artifact(path: Path, label: str | None = None) -> dict[str, Any]:
    item: dict[str, Any] = {"path": label or path.relative_to(ROOT).as_posix(), "exists": path.is_file()}
    if path.is_file():
        item.update({"sha256": _sha256(path), "bytes": path.stat().st_size})
    return item


def freeze(output_dir: Path | None = None) -> dict[str, Any]:
    output_dir = output_dir or ROOT / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    outcome_path = ROOT / "paper" / "data" / "final_task_outcomes.csv"
    manifest_raw = contract.get("workload", {}).get("task_manifest", {}).get("path", "")
    manifest_path = Path(manifest_raw) if manifest_raw else Path()
    artifacts = [
        _artifact(outcome_path),
        _artifact(ROOT / "paper" / "build" / "data_summary.json"),
        _artifact(CONTRACT),
        _artifact(ROOT / "paper" / "build" / "main.pdf"),
        _artifact(manifest_path, "external_task_manifest") if manifest_path else {"path": "external_task_manifest", "exists": False},
    ]
    snapshot = {
        "schema_version": "1.0",
        "generated_at": generated_at,
        "git": {
            "commit": _git(["rev-parse", "HEAD"]),
            "branch": _git(["branch", "--show-current"]),
            "dirty": bool(_git(["status", "--porcelain"])),
        },
        "outcome_snapshot": _outcome_snapshot(outcome_path),
        "contract": {
            "experiment_id": contract.get("experiment_id"),
            "source_commit": contract.get("source", {}).get("git_commit"),
            "model_id": contract.get("model", {}).get("model_id"),
            "model_version": contract.get("model", {}).get("model_version"),
            "evaluator_wrapper": contract.get("agent", {}).get("evaluation_wrapper"),
            "image_digests": {name: value.get("digest") for name, value in contract.get("images", {}).items()},
        },
        "artifacts": artifacts,
        "immutability": {"historical_runs_read_only": True, "source_results_modified": False},
    }
    snapshot_path = output_dir / "baseline_snapshot.json"
    snapshot_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    protocol = {
        "schema_version": "1.0",
        "generated_at": generated_at,
        "protocol_version": "2.1",
        "experiment_id": contract.get("experiment_id"),
        "contract_sha256": _sha256(CONTRACT),
        "task_count": contract.get("execution", {}).get("task_count"),
        "tasks": contract.get("execution", {}).get("pilot_tasks", []),
        "budget": contract.get("execution", {}).get("cost_budget"),
        "outcome_snapshot": snapshot["outcome_snapshot"],
        "model": snapshot["contract"],
        "stop_conditions": ["evr_below_95_percent", "bundle_hash_mismatch", "budget_violation", "billing_failure_over_5_percent", "protocol_hash_changed"],
    }
    (output_dir / "current_protocol.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"snapshot": snapshot_path.relative_to(ROOT).as_posix(), "protocol": "artifacts/current_protocol.json", "outcome_snapshot": snapshot["outcome_snapshot"], "generated_at": generated_at}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=ROOT / "artifacts")
    args = parser.parse_args()
    print(json.dumps(freeze(args.output_dir), ensure_ascii=False))
