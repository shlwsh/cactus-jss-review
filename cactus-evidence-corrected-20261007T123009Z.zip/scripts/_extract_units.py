"""Extract all unit paths from prompt text."""
import json
import re
import sys
from pathlib import Path

run = Path(sys.argv[1])
events = [json.loads(l) for l in (run / "trace" / "events.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
mc = next(e for e in events if e["type"] == "model_call")
prompt = mc["payload"]["prompt_text"]

# Find all unit headers
pattern = re.compile(r"<!-- cactus-unit:(\w+) path:(\S+) lines:(\S+).*?kind:(\w+) -->")
units = pattern.findall(prompt)
print(f"Found {len(units)} unit markers in prompt_text:\n")
for u in units:
    print(f"  {u[0]} | {u[1]} | lines={u[2]} | kind={u[3]}")

# Also check for separable.py and _cstack references
print(f"\nseparable.py mentions: {prompt.count('separable.py')}")
print(f"_cstack mentions: {prompt.count('_cstack')}")
print(f"separability_matrix mentions: {prompt.count('separability_matrix')}")
print(f"cright mentions: {prompt.count('cright')}")

# Show lines around _cstack
m = re.search(r"def _cstack.*?(?=def |<!--|$)", prompt, re.DOTALL)
if m:
    print(f"\n=== _cstack context in prompt ({len(m.group())} chars) ===")
    print(m.group()[:2000])
