"""record_interactions.py — Extract full model interactions from a RUN's trace.

For each model_call event, extract:
  - the prompt text sent to the model
  - the full response text
  - parsed JSON edits (if present)
  - the validation/rejection reason

Outputs a clean JSONL file at <run_dir>/interactions.jsonl that you can grep,
diff, or feed into another LLM for root-cause analysis.

Usage:
  & .\\.venv\\Scripts\\python.exe scripts\\record_interactions.py experiments\\runs\\RUN-XXXX
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


_JSON_RE = re.compile(r"\{[\s\S]*\}")


def _extract_edits(response_text: str) -> dict | None:
    """Try to extract the {edits: [...]} JSON object from the response text."""
    if not response_text:
        return None
    # Try direct parse
    stripped = response_text.strip()
    if stripped.startswith("{") and stripped.endswith("}"):
        try:
            data = json.loads(stripped)
            if isinstance(data, dict) and "edits" in data:
                return data
        except json.JSONDecodeError:
            pass
    # Try fenced
    m = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", response_text)
    if m:
        try:
            data = json.loads(m.group(1))
            if isinstance(data, dict) and "edits" in data:
                return data
        except json.JSONDecodeError:
            pass
    # Last resort: first {...} block
    m = _JSON_RE.search(response_text)
    if m:
        try:
            data = json.loads(m.group(0))
            if isinstance(data, dict) and "edits" in data:
                return data
        except json.JSONDecodeError:
            pass
    return None


def _summarize_rejection(reason: str | None) -> dict:
    if not reason:
        return {"rejected": False}
    s = reason.lower()
    return {
        "rejected": True,
        "first_120": reason[:120],
        "matched_symbol": "symbol must match exactly" in s,
        "matched_path": "path" in s and ("must" in s or "expected" in s or "invalid" in s),
        "matched_json": "json" in s or "parse" in s,
        "matched_diff": "diff" in s or "hunk" in s,
    }


def extract(run_dir: Path) -> list[dict]:
    trace_path = run_dir / "trace" / "events.jsonl"
    if not trace_path.exists():
        print(f"[ERROR] trace not found: {trace_path}", file=sys.stderr)
        return []

    events = []
    for line in trace_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    model_calls = [e for e in events if e.get("type") == "model_call"]
    rejections = [e for e in events if e.get("type") == "prediction_rejected"]

    interactions = []
    for i, mc in enumerate(model_calls):
        payload = mc.get("payload", {})
        attempt = i + 1
        response_text = payload.get("response_text", "")
        prompt_text = payload.get("prompt_text", "")
        # find latest rejection for this attempt
        related_rej = next(
            (
                r.get("payload", {})
                for r in rejections
                if r.get("payload", {}).get("attempt") == attempt
            ),
            None,
        )

        edits = _extract_edits(response_text)
        edit_summary = None
        if edits and isinstance(edits.get("edits"), list):
            edit_summary = []
            for e in edits["edits"]:
                old = e.get("old_statement", "")
                rep = e.get("replacement", "")
                edit_summary.append({
                    "path": e.get("path", ""),
                    "symbol": e.get("symbol", ""),
                    "old_first_120": (old[:120] + ("...[truncated]" if len(old) > 120 else "")),
                    "old_len": len(old),
                    "replacement_first_120": (rep[:120] + ("...[truncated]" if len(rep) > 120 else "")),
                    "replacement_len": len(rep),
                    "old_has_placeholder": any(tok in old.upper() for tok in
                        ["PLACEHOLDER", "_NOT_ALLOWED", "RECONSTRUCT_CANONICAL", "SYNTAX_INVALID",
                         "BEST_EFFORT", "ONE_VALUE", "MUST_BE_EXACTLY"]),
                    "old_is_hallucinated_symbol": bool(re.search(r"[A-Z][a-z]+\[[^\]]*\]", old)),
                })

        interactions.append({
            "attempt": attempt,
            "ts": mc.get("utc_ts"),
            "finish_reason": payload.get("finish_reason"),
            "input_tokens": payload.get("input_tokens"),
            "output_tokens": payload.get("output_tokens"),
            "max_tokens": payload.get("max_tokens"),
            "usage_source": payload.get("usage_source"),
            "prompt_sha256": payload.get("prompt_sha256"),
            "prompt_chars": payload.get("prompt_chars"),
            "response_chars": payload.get("response_chars"),
            "temperature": payload.get("temperature"),
            "frequency_penalty": payload.get("frequency_penalty"),
            "presence_penalty": payload.get("presence_penalty"),
            "repetition_penalty": payload.get("repetition_penalty"),
            "metadata_keys": payload.get("metadata_keys", []),
            "rejection": _summarize_rejection((related_rej or {}).get("reason")),
            "rejection_reason_full": (related_rej or {}).get("reason"),
            "rejection_response_chars": (related_rej or {}).get("response_chars"),
            "rejection_response_excerpt": (related_rej or {}).get("response_excerpt"),
            "edits": edits,
            "edit_summary": edit_summary,
            "response_first_500": response_text[:500],
            "response_last_500": response_text[-500:] if len(response_text) > 500 else "",
            "prompt_first_500": prompt_text[:500],
            "prompt_last_500": prompt_text[-500:] if len(prompt_text) > 500 else "",
        })
    return interactions


def render_console(interactions: list[dict]) -> str:
    out = []
    out.append("=" * 80)
    out.append(f"INTERACTIONS DUMP — {len(interactions)} model call(s)")
    out.append("=" * 80)
    for it in interactions:
        out.append("")
        out.append(f"── ATTEMPT {it['attempt']} @ {it['ts']} ──")
        out.append(f"  finish_reason    : {it['finish_reason']}")
        out.append(f"  in/out tokens    : {it['input_tokens']} / {it['output_tokens']} (max={it['max_tokens']})")
        out.append(f"  temperature      : {it['temperature']}")
        out.append(f"  frequency_penalty: {it['frequency_penalty']}")
        out.append(f"  repetition_penalty: {it['repetition_penalty']}")
        out.append(f"  prompt_chars     : {it['prompt_chars']}, sha256[:12]={it['prompt_sha256'][:12] if it['prompt_sha256'] else None}")
        out.append(f"  response_chars   : {it['response_chars']}")
        if it["rejection"].get("rejected"):
            out.append(f"  REJECTION        : {it['rejection']['first_120']}")
            for k in ("matched_symbol", "matched_path", "matched_json", "matched_diff"):
                if it["rejection"].get(k):
                    out.append(f"                   • {k}")
        if it["edit_summary"]:
            for j, e in enumerate(it["edit_summary"]):
                flag = " ⚠HALLUCINATED" if e["old_is_hallucinated_symbol"] else ""
                ph = " ⚠PLACEHOLDER" if e["old_has_placeholder"] else ""
                out.append(f"  EDIT #{j+1}{flag}{ph}")
                out.append(f"    path           : {e['path']}")
                out.append(f"    symbol         : {e['symbol']}")
                out.append(f"    old (first 120): {e['old_first_120']}")
                out.append(f"    new (first 120): {e['replacement_first_120']}")
                out.append(f"    old_len={e['old_len']} new_len={e['replacement_len']}")
        elif it["edits"] is None and it["response_chars"]:
            out.append(f"  ⚠ NO JSON EDITS PARSED (response first 200): {it['response_first_500'][:200]}")
        out.append("")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="Extract model interactions from a RUN trace")
    ap.add_argument("run_dir", type=Path, help="Path to RUN directory")
    ap.add_argument("--output", type=Path, default=None,
                    help="Output JSONL path (default: <run_dir>/interactions.jsonl)")
    ap.add_argument("--quiet", action="store_true", help="Suppress console output")
    args = ap.parse_args()

    run_dir = args.run_dir.resolve()
    interactions = extract(run_dir)
    if not interactions:
        print("[!] no model_call events found in trace", file=sys.stderr)
        sys.exit(1)

    out_path = args.output or (run_dir / "interactions.jsonl")
    with out_path.open("w", encoding="utf-8", newline="\n") as fh:
        for it in interactions:
            fh.write(json.dumps(it, ensure_ascii=False) + "\n")

    if not args.quiet:
        print(render_console(interactions))
        print(f"\nFull interactions dumped to: {out_path}")
    else:
        print(f"wrote {len(interactions)} interactions to {out_path}", file=sys.stderr)


if __name__ == "__main__":
    sys.exit(main() or 0)
