"""Fetch full history for git mirrors (Windows-safe)."""
import subprocess
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm/experiments/repo_cache")

# Mirror configs
mirrors = [
    ("astropy__astropy.git", "298ccb478e6bf092953bca67a3d29dc6c35f6752"),
    ("django__django.git", None),
]

for name, _ in mirrors:
    mirror = ROOT / name
    if not mirror.exists():
        print(f"SKIP: {name} not found")
        continue

    print(f"Fetching full history for {name}...")

    # Try fetch --unshallow
    r = subprocess.run(
        ["git", "fetch", "--unshallow", "--tags"],
        cwd=str(mirror),
        capture_output=True,
        text=True,
        timeout=600,
    )

    if r.returncode != 0:
        print(f"  fetch --unshallow failed: {r.stderr[:200]}")
        # Try fetch all
        r2 = subprocess.run(
            ["git", "fetch", "--all", "--tags"],
            cwd=str(mirror),
            capture_output=True,
            text=True,
            timeout=600,
        )
        if r2.returncode != 0:
            print(f"  fetch --all also failed: {r2.stderr[:200]}")
        else:
            print(f"  fetch --all succeeded")
    else:
        print(f"  fetch --unshallow succeeded")

    # Verify base commits
    for commit in ["298ccb478e6bf092953bca67a3d29dc6c35f6752", "6ed769d58d89380ebaa1ef52b300691eefda8928"]:
        r = subprocess.run(
            ["git", "-C", str(mirror), "cat-file", "-e", f"{commit}" + "{commit}"],
            capture_output=True, timeout=10,
        )
        status = "OK" if r.returncode == 0 else "MISSING"
        print(f"    {commit[:12]}: {status}")
