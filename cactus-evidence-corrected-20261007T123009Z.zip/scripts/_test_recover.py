"""Test the flattened-indent recovery function."""
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

import importlib.util
spec = importlib.util.spec_from_file_location("cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# The actual model output
helper_edit_replacement = (
    "        def as_scalar_or_list_str(obj):"
    "            if not hasattr(obj, '__len__'):"
    "                return f'{{obj}}'"
    "            elif len(obj) == 1:"
    "                return f'{{obj[0]}}'"
    "            else:"
    "                return str(obj)"
    "        if not self._required_columns_enabled:"
)
recovered = mod._recover_flattened_indent(helper_edit_replacement)
print("RECOVERED:")
print(recovered)
print()
print("=" * 40)

import ast
try:
    tree = ast.parse(recovered)
    print(f"PARSE OK, body count: {len(tree.body)}")
    for i, node in enumerate(tree.body):
        print(f"  body[{i}] type={type(node).__name__}")
except SyntaxError as e:
    print(f"PARSE FAIL: {e}")
