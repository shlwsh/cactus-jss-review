"""Dedicated run for django__django-11019 with fresh token budget and updated hint rule.

The new _ISSUE_HINTS rule for media_merge_ordering pins django/forms/widgets.py
as preferred_path, which should ensure Media.merge units enter the repair sites pool.

Usage:
    python scripts/run_single_task_django11019.py [--dry-run]
"""
from __future__ import annotations

import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"

TASK_ID = "django__django-11019"


def main():
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    validation_id = f"DJ11019-FIXED-{ts}"
    print(f"Running {TASK_ID} with fresh budget...")
    print(f"Validation ID: {validation_id}")

    output_dir = RUNS_DIR / validation_id / TASK_ID
    output_dir.mkdir(parents=True, exist_ok=True)
    trace_path = output_dir / "trace.jsonl"

    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_single_task_predict.py"),
        "--task-id", TASK_ID,
        "--variant", "cactus_full",
        "--validation-id", validation_id,
    ]

    started = time.time()
    env = subprocess.os.environ.copy()
    env["PYTHONPATH"] = str(PROJECT_ROOT)
    result = subprocess.run(
        cmd,
        cwd=str(PROJECT_ROOT),
        env=env,
        capture_output=True,
        text=True,
        timeout=1800,
    )
    duration = time.time() - started

    print(f"\nResult: returncode={result.returncode}, duration={duration:.0f}s")
    if result.returncode == 0:
        print("PASS")
    else:
        print("FAIL")
        print(f"STDERR: {result.stderr[-1000:]}")

    # Check prediction
    import json
    pred_path = output_dir / "prediction.jsonl"
    if pred_path.exists():
        with open(pred_path, encoding="utf-8") as f:
            data = json.loads(f.readline())
        patch = data.get("model_patch", "")
        print(f"Patch length: {len(patch)}")
        print(f"Patch preview:\n{patch[:300]}")


if __name__ == "__main__":
    main()
