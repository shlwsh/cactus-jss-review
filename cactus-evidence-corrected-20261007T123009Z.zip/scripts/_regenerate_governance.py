#!/usr/bin/env python3
"""Generate new governance snapshot and update publication_sources.json."""
import sys
import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path('.')
sys.path.insert(0, 'src')
sys.path.insert(0, '.')

from scripts.audit_evidence_corpus import generate

# 生成新的 governance 快照
timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
output_dir = ROOT / f"experiments/derived/governance_{timestamp}"

print(f"Generating new governance snapshot: {output_dir}")
summary = generate(output_dir)
print(f"Generated: run_directory_count={summary['run_directory_count']}")

# 计算新快照文件的 SHA256
def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

# 更新 publication_sources.json
sources_file = ROOT / "paper/publication_sources.json"
sources = json.loads(sources_file.read_text(encoding="utf-8"))

# 更新 corpus_summary 相关条目
for key in ['corpus_summary', 'corpus_inventory']:
    old_path = sources['sources'][key]['path']
    # 从路径中提取目录名
    old_dir = ROOT / old_path.split('/')[0] + '/' + old_path.split('/')[1]
    new_path = f"experiments/derived/governance_{timestamp}/{old_path.split('/')[-1]}"
    new_full_path = ROOT / new_path
    sources['sources'][key]['path'] = new_path
    sources['sources'][key]['sha256'] = sha256(new_full_path)
    print(f"Updated {key}: {new_path}")

# 保存更新后的配置
sources_file.write_text(json.dumps(sources, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"\nUpdated {sources_file}")
print("Done!")
