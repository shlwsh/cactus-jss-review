#!/usr/bin/env python3
"""Fix provenance for old governance historical_task_admission.jsonl."""
import sys
sys.path.insert(0, 'src')
sys.path.insert(0, '.')

import json
import hashlib
from pathlib import Path
from scripts.artifact_provenance import write

ROOT = Path('.')

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

# The old provenance references files that moved to archived_unreferenced
# We need to update the provenance to use correct paths

old_prov_path = ROOT / 'experiments/derived/governance_20261004T093000Z/historical_task_admission.jsonl.provenance.json'
hist_file = ROOT / 'experiments/derived/governance_20261004T093000Z/historical_task_admission.jsonl'

# Load existing provenance
old_prov = json.loads(old_prov_path.read_text())

# Create input mapping for moved files
path_mappings = {
    'experiments/derived/final_task_outcomes.csv': 'paper/data/final_task_outcomes.csv',
    'experiments/derived/lite50_v2_runtimeid_20260929T095818Z.json': 'experiments/derived/archived_unreferenced/lite50_v2_runtimeid_20260929T095818Z.json',
    'experiments/derived/result_registry_v2.jsonl': 'experiments/derived/archived_unreferenced/result_registry_v2.jsonl',
}

# Update inputs with correct paths
new_inputs = []
for inp in old_prov['inputs']:
    old_path = inp['path']
    if old_path in path_mappings:
        new_path = ROOT / path_mappings[old_path]
        if new_path.exists():
            inp['path'] = path_mappings[old_path]
            inp['sha256'] = sha256(new_path)
            print(f"Mapped: {old_path} -> {path_mappings[old_path]}")
    new_inputs.append(inp)

# Update provenance file
old_prov['inputs'] = new_inputs
old_prov_path.write_text(json.dumps(old_prov, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print("Updated provenance file!")
