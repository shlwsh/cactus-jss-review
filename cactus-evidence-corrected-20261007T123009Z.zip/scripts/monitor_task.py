"""
monitor_task.py — Real-time CACTUS task monitor.

Watches a RUN's trace/events.jsonl as it grows and prints live diagnostics
so you catch failure patterns (parse errors, rejection reasons, token budget
issues, missing usage) BEFORE the campaign finishes.

Usage:
  & .\\.venv\\Scripts\\python.exe scripts\\monitor_task.py <RUN_DIR> [--poll 5]

Example (watch running task):
  & .\\.venv\\Scripts\\python.exe scripts\\monitor_task.py experiments\\runs\\RUN-20260925T113558Z-0D213BFD
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from datetime import datetime, timezone


def _fmt(ts: str) -> str:
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).strftime("%H:%M:%S")
    except Exception:
        return ts


def _human_tokens(n: int | None) -> str:
    if n is None:
        return "N/A"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def analyze_trace(trace_path: Path) -> dict:
    """Parse events.jsonl and return structured diagnostics."""
    if not trace_path.exists():
        return {"error": "trace file not found", "events": []}

    raw = trace_path.read_text(encoding="utf-8")
    lines = [l.strip() for l in raw.splitlines() if l.strip()]
    events = []
    for l in lines:
        try:
            events.append(json.loads(l))
        except Exception:
            pass

    # Count event types
    types: dict[str, int] = {}
    for e in events:
        t = e.get("type") or e.get("event") or "?"
        types[t] = types.get(t, 0) + 1

    # Model calls
    model_calls = []
    for e in events:
        if e.get("type") == "model_call":
            p = e.get("payload", {})
            model_calls.append({
                "turn_id": p.get("turn_id", ""),
                "finish_reason": p.get("finish_reason"),
                "input_tokens": p.get("input_tokens"),
                "output_tokens": p.get("output_tokens"),
                "max_tokens": p.get("max_tokens"),
                "usage_source": p.get("usage_source"),
                "ts": e.get("utc_ts"),
                "seq": e.get("seq"),
            })

    # Rejections
    rejections = []
    for e in events:
        if e.get("type") == "prediction_rejected":
            p = e.get("payload", {})
            rejections.append({
                "attempt": p.get("attempt"),
                "turn_id": p.get("turn_id", ""),
                "reason": p.get("reason", ""),
                "reason_class": p.get("reason_class", ""),
                "response_chars": p.get("response_chars", 0),
                "response_excerpt": p.get("response_excerpt", ""),
            })

    # Context summaries (final token counts)
    context_summaries = []
    for e in events:
        if e.get("type") == "context_summary":
            p = e.get("payload", {})
            context_summaries.append({
                "full_context_tokens": p.get("full_context_tokens"),
                "selected_context_tokens": p.get("selected_context_tokens"),
                "selected_context_ratio": p.get("selected_context_ratio"),
                "selected_file_count": p.get("selected_file_count"),
                "turn_id": p.get("turn_id", ""),
            })

    # Observes (errors / warnings)
    observes = []
    for e in events:
        if e.get("type") == "observe":
            p = e.get("payload", {})
            observes.append({
                "severity": p.get("severity"),
                "message": p.get("message", ""),
                "ts": e.get("utc_ts"),
            })

    # Latest heartbeat
    latest_ts = max((e.get("utc_ts", "") for e in events), default="")

    return {
        "events": events,
        "types": types,
        "total_events": len(events),
        "model_calls": model_calls,
        "rejections": rejections,
        "context_summaries": context_summaries,
        "observes": observes,
        "latest_ts": latest_ts,
    }


def print_dashboard(run_dir: Path, diag: dict, verbose: bool = False):
    ts_now = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")

    print()
    print("╔══════════════════════════════════════════════════════════════════════╗")
    print(f"║  CACTUS Task Monitor   {ts_now:<43}║")
    print("╠══════════════════════════════════════════════════════════════════════╣")

    run_id = run_dir.name
    print(f"║ RUN: {run_id:<63}║")

    trace = run_dir / "trace" / "events.jsonl"
    if trace.exists():
        size_kb = trace.stat().st_size / 1024
        print(f"║ trace: {size_kb:.1f} KB  ({diag['total_events']} events)              {diag.get('latest_ts',''):<20}║")
    else:
        print(f"║ trace: NOT FOUND                                              ║")

    print("╠══════════════════════════════════════════════════════════════════════╣")

    # Model calls table
    mc = diag["model_calls"]
    if mc:
        print("║  MODEL CALLS                                                         ║")
        for i, call in enumerate(mc):
            fr = call["finish_reason"] or "?"
            ratio = ""
            if call["output_tokens"] and call["max_tokens"]:
                ratio = f" ({100*call['output_tokens']/call['max_tokens']:.0f}%)"
            ratio = ""
            if call["output_tokens"] and call["max_tokens"]:
                ratio = f" ({100*call['output_tokens']/call['max_tokens']:.0f}%)"
            tokens_str = f"{_human_tokens(call['input_tokens'])} in / {_human_tokens(call['output_tokens'])} out{ratio}"
            print(f"║  #{i+1} finish={fr:<6} {tokens_str:<40} @ {_fmt(call['ts'] or '')}     ║")
        print("╠══════════════════════════════════════════════════════════════════════╣")

    # Rejections
    rej = diag["rejections"]
    if rej:
        print("║  ✖ REJECTIONS                                                        ║")
        for r in rej:
            reason_short = r["reason"][:55] if r["reason"] else "?"
            print(f"║    attempt={r['attempt']} reason_class={r['reason_class']:<25}       ║")
            print(f"║    {reason_short:<63}║")
        print("╠══════════════════════════════════════════════════════════════════════╣")

    # Observes (warnings/errors)
    obs = diag["observes"]
    if obs:
        warn_count = sum(1 for o in obs if o.get("severity") in ("warning", "error"))
        if warn_count:
            print(f"║  ⚠ OBSERVES (warnings/errors): {warn_count}                                   ║")
            for o in obs[-5:]:  # last 5
                if o.get("severity") in ("warning", "error"):
                    msg = o["message"][:60]
                    print(f"║    [{o.get('severity','')}] {msg:<55}       ║")
            print("╠══════════════════════════════════════════════════════════════════════╣")

    # Context summary
    cs = diag["context_summaries"]
    if cs:
        latest_cs = cs[-1]
        ratio = latest_cs.get("selected_context_ratio", 0) or 0
        print("║  CONTEXT                                                             ║")
        print(f"║    full: {_human_tokens(latest_cs.get('full_context_tokens')):>10} tokens  selected: {_human_tokens(latest_cs.get('selected_context_tokens')):>8} tokens  ({100*ratio:.3f}%)  ║")
        print(f"║    files: {latest_cs.get('selected_file_count', '?')}                                                       ║")
        print("╠══════════════════════════════════════════════════════════════════════╣")

    # Early-warning checks
    print("║  DIAGNOSTICS                                                         ║")

    warnings: list[str] = []

    # Check 1: model calls with length finish (token budget issue)
    length_calls = [c for c in mc if c.get("finish_reason") == "length"]
    if length_calls:
        lc = length_calls[-1]
        warnings.append(
            f"⚠ finish_reason=length: output_tokens={lc.get('output_tokens')} hit max_tokens={lc.get('max_tokens')} "
            f"(model may be outputting thinking, not JSON)"
        )

    # Check 2: parse failure
    parse_rejs = [r for r in rej if "parse" in r.get("reason_class", "").lower()]
    if parse_rejs:
        warnings.append(f"⚠ Parse failure on attempt {parse_rejs[0]['attempt']}")

    # Check 3: rejection ratio high
    if len(rej) >= 3:
        warnings.append(f"⚠ Multiple rejections ({len(rej)}): model not converging")

    # Check 4: usage_source != billing (billing not recorded)
    no_billing = [c for c in mc if c.get("usage_source") != "billing"]
    if no_billing and len(mc) >= 2:
        warnings.append(f"⚠ {len(no_billing)} call(s) with usage_source != 'billing' (cost tracking gap)")

    # Check 5: No model call yet after significant time
    if not mc and diag["total_events"] > 10:
        warnings.append("⚠ No model_call events yet despite many events (possible pre-call error)")

    # Check 6: response chars but parse failure
    zero_char_rejs = [r for r in rej if r.get("response_chars", 0) == 0]
    if zero_char_rejs:
        warnings.append(f"⚠ {len(zero_char_rejs)} rejection(s) with 0 response chars (model silent)")

    if warnings:
        for w in warnings:
            print(f"║  {w:<66}║")
    else:
        print("║  ✓ No early warnings detected                                       ║")

    print("╚══════════════════════════════════════════════════════════════════════╝")
    print()


def monitor_live(run_dir: Path, poll_sec: float = 5.0):
    """Poll trace file and print live dashboard."""
    trace_path = run_dir / "trace" / "events.jsonl"

    print(f"[monitor] Watching {trace_path}")
    print(f"[monitor] poll interval: {poll_sec}s")
    print()

    last_size = -1
    last_event_count = 0
    last_mc_count = 0

    while True:
        try:
            if not trace_path.exists():
                print(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] trace file not yet created, waiting...")
                time.sleep(poll_sec)
                continue

            size = trace_path.stat().st_size
            if size == last_size:
                # File unchanged - check if RUN is done
                manifest_path = run_dir / "run_manifest.json"
                if manifest_path.exists():
                    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                    status = manifest.get("status")
                    if status in ("completed", "failed", "sealed"):
                        print(f"\n[monitor] RUN finished with status={status}")
                        diag = analyze_trace(trace_path)
                        print_dashboard(run_dir, diag, verbose=True)
                        return
                time.sleep(poll_sec)
                continue

            last_size = size
            diag = analyze_trace(trace_path)
            new_events = diag["total_events"] - last_event_count
            new_mc = len(diag["model_calls"]) - last_mc_count
            last_event_count = diag["total_events"]
            last_mc_count = len(diag["model_calls"])

            ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
            print(f"[{ts}] +{new_events} events (+{new_mc} model_calls), total {diag['total_events']}")

            # Always print on model call completion
            if new_mc > 0:
                latest_mc = diag["model_calls"][-1]
                print_dashboard(run_dir, diag, verbose=True)
            else:
                # Just show summary line
                print_dashboard(run_dir, diag, verbose=False)

            time.sleep(poll_sec)

        except KeyboardInterrupt:
            print("\n[monitor] Interrupted by user")
            return
        except Exception as exc:
            print(f"[monitor] Error: {exc}")
            time.sleep(poll_sec)


def main():
    import argparse
    ap = argparse.ArgumentParser(description="CACTUS task monitor")
    ap.add_argument("run_dir", type=Path, help="Path to RUN directory")
    ap.add_argument("--poll", type=float, default=5.0, help="Poll interval in seconds (default: 5)")
    ap.add_argument("--once", action="store_true", help="Print once and exit (for post-run analysis)")
    args = ap.parse_args()

    run_dir = args.run_dir.resolve()
    if not run_dir.is_dir():
        print(f"ERROR: not a directory: {run_dir}", file=sys.stderr)
        sys.exit(1)

    if args.once:
        trace_path = run_dir / "trace" / "events.jsonl"
        diag = analyze_trace(trace_path)
        print_dashboard(run_dir, diag, verbose=True)
        return

    monitor_live(run_dir, poll_sec=args.poll)


if __name__ == "__main__":
    main()
