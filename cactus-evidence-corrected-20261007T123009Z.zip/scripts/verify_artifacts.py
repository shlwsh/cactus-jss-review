"""Create or verify an immutable baseline snapshot of project artifacts."""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(project_root: Path, output: Path) -> dict[str, object]:
    paths = [project_root / "paper/data/final_task_outcomes.csv", project_root / "paper/build/data_summary.json", project_root / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V1.json"]
    rows = [{"path": path.relative_to(project_root).as_posix(), "sha256": sha256(path), "bytes": path.stat().st_size} for path in paths if path.exists()]
    commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=project_root, text=True, capture_output=True, check=False).stdout.strip()
    payload = {"schema_version": "1.0", "commit": commit, "artifacts": rows, "outcome_snapshot": {"unique": 500, "resolved": 6, "unresolved": 28, "evaluator_error": 466, "pending": 0}}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return payload


def verify(project_root: Path, snapshot_path: Path) -> list[str]:
    payload = json.loads(snapshot_path.read_text(encoding="utf-8"))
    errors = []
    for item in payload.get("artifacts", []):
        path = project_root / item["path"]
        if not path.exists():
            errors.append(f"missing artifact: {item['path']}")
        elif sha256(path) != item["sha256"]:
            errors.append(f"hash mismatch: {item['path']}")
    return errors


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if args.verify:
        errors = verify(root, args.snapshot)
        print(json.dumps({"status": "pass" if not errors else "fail", "errors": errors}))
        raise SystemExit(bool(errors))
    print(json.dumps(snapshot(root, args.snapshot), ensure_ascii=False))
