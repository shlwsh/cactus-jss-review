#!/usr/bin/env python3
"""Debug scan function for line 309."""
import re
from pathlib import Path

line = "RQ3 asks: under frozen and matched experimental conditions, how do context-selection strategies affect repair outcomes and failure profiles? We designed a frozen matched cohort of \\DataValue{p04.cohort_size.raw} SWE-bench Verified tasks (revision \\texttt{78f471b}), with four strategies evaluated on each identical task under identical experimental conditions: task ID, source commit, evaluator version, driver digest, model, prompt, temperature, context-token budget (\\texttt{16384}), and container digest were held constant across all four treatments."

digit_check = line
digit_check = re.sub(r"\b(?:flake8|mypy|pyright|ruff)\s+[A-Z]\d+", "TOOL_CODE", digit_check)
digit_check = re.sub(r"\$\\[gl]e\$\d+", "INEQUALITY_ZERO", digit_check)
digit_check = re.sub(r"\\(?:DataValue|input|label|ref|cite[a-zA-Z*]*|bibliography|bibliographystyle)\{[^}]*\}", "", digit_check)
digit_check = re.sub(r"\\includegraphics(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
digit_check = re.sub(r"\\(?:documentclass|usepackage)(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
digit_check = re.sub(r"\\email\{[^}]*\}", "", digit_check)
digit_check = re.sub(r"\\(?:emergencystretch|setlength)\s*(?:=\s*)?(?:\{[^}]*\})?\s*\{?\d+(?:\.\d+)?(?:pt|em|mm|cm)\}?", "", digit_check)
digit_check = re.sub(r"\\b(?:BM25|§\d+)\b", "ALLOWED_ID", digit_check)
digit_check = re.sub(r"\\[a-zA-Z]+\{[^}]*\}", "", digit_check)

print("Original line:")
print(line)
print()
print("After regex processing:")
print(digit_check)
print()
if re.search(r"\d", digit_check):
    print("FOUND DIGITS!")
    import re
    for m in re.finditer(r"\d+", digit_check):
        print(f"  Digit at position {m.start()}: '{m.group()}'")
        # Show context
        start = max(0, m.start() - 20)
        end = min(len(digit_check), m.end() + 20)
        print(f"  Context: ...{digit_check[start:end]}...")
else:
    print("No digits found!")
