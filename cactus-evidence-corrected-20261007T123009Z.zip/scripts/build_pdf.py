#!/usr/bin/env python3
"""
构建当前期刊论文 PDF，并输出带版本号和 UTC 时间戳的版本。

用法:
    python scripts/build_pdf.py [--version VERSION] [--paper-dir DIR]

输出格式: CACTUS_JSS_v<VERSION>_<YYYYMMDD-HHMMSS>.pdf
"""

from __future__ import annotations

import argparse
import re
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

current_file = Path(__file__).resolve()
if current_file.parent.parent.name == "acm":
    ACM_DIR = current_file.parent.parent
    REPO_ROOT = ACM_DIR.parent
else:
    REPO_ROOT = current_file.parent.parent
    ACM_DIR = REPO_ROOT / "acm"

PAPER_DIR = ACM_DIR / "paper"
BUILD_DIR = PAPER_DIR / "build"
OUTPUT_DIR = ACM_DIR / "pdf"
sys.path.insert(0, str(ACM_DIR))
sys.path.insert(0, str(ACM_DIR / "src"))

# Filename pattern: CACTUS_v<MAJOR>.<MINOR>_<YYYYMMDD-HHMMSS>.pdf
_VERSION_RE = re.compile(
    r"^CACTUS(?:_JSS)?_v(?P<major>\d+)\.(?P<minor>\d+)_\d{8}-\d{6}\.pdf$"
)


def get_git_commit() -> str:
    """获取当前 Git commit SHA（前7位）。"""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=REPO_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "unknown"


def next_version(output_dir: Path = OUTPUT_DIR, base: str = "1.0") -> str:
    """
    Auto-detect next paper version by scanning ``acm/pdf/``.

    The scan looks for files matching ``CACTUS_v<MAJOR>.<MINOR>_<stamp>.pdf``,
    selects the lexicographically-largest ``(MAJOR, MINOR)`` pair, and
    increments the minor component by one. Falls back to ``base`` (default
    ``"1.0"``) when the directory does not exist or contains no versioned
    PDFs.

    Examples
    --------
    >>> # No prior PDF
    >>> next_version(Path("/tmp/empty"))
    '1.0'
    >>> # Prior PDF at v1.3
    >>> next_version(Path("/tmp/with"))  # doctest: +SKIP
    '1.4'
    """
    candidates: list[tuple[int, int]] = []
    if output_dir.is_dir():
        for path in output_dir.iterdir():
            match = _VERSION_RE.match(path.name)
            if not match:
                continue
            candidates.append((int(match["major"]), int(match["minor"])))

    if not candidates:
        return base

    # Pick the largest by (major, minor); minor-only auto-bump keeps the
    # patch history linear, matching the v1.0 → v1.1 → ... convention from
    # the project's doc-naming-rule.
    major, minor = max(candidates)
    return f"{major}.{minor + 1}"


def generate_figures(python_bin: str) -> None:
    """
    Generate manuscript figures via ``acm/paper/figures/generate_figures.py``.

    pdflatex fails (Fatal error) if any ``figures/output/*.pdf`` referenced by
    main.tex is missing, so we always render figures first. Skipped silently
    if the generator script does not exist. Failures are surfaced so the user
    does not chase a downstream pdflatex error whose root cause is matplotlib.
    """
    script = ACM_DIR / "paper" / "figures" / "generate_figures.py"
    if not script.is_file():
        print(f"[build_pdf] 未找到图表生成脚本 {script},跳过", file=sys.stderr)
        return

    import os
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ACM_DIR / "scripts")
    env.setdefault("MPLBACKEND", "Agg")

    print("正在生成图表 (matplotlib → acm/paper/figures/output)...")
    result = subprocess.run(
        [python_bin, str(script)],
        cwd=ACM_DIR,
        capture_output=True,
        text=True,
        env=env,
    )
    if result.returncode != 0:
        print(f"图表生成失败 (exit={result.returncode}):", file=sys.stderr)
        if result.stdout:
            print(result.stdout, file=sys.stderr)
        if result.stderr:
            print(result.stderr, file=sys.stderr)
        sys.exit(1)


def compile_paper(python_bin: str) -> Path:
    """使用 paper_pipeline.py 编译论文。"""
    script = ACM_DIR / "scripts" / "paper_pipeline.py"
    import os
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ACM_DIR / "scripts")

    result = subprocess.run(
        [python_bin, str(script), "build"],
        cwd=ACM_DIR,
        capture_output=True,
        text=True,
        env=env,
    )
    if result.returncode != 0:
        print(f"编译失败:\n{result.stderr}", file=sys.stderr)
        sys.exit(1)
    
    pdf_path = BUILD_DIR / "main.pdf"
    if not pdf_path.exists():
        print(f"错误: 编译后未找到 PDF 文件 {pdf_path}", file=sys.stderr)
        sys.exit(1)
    
    return pdf_path


def copy_publication(pdf_path: Path, output_path: Path, version: str, *, overwrite: bool = False) -> Path:
    """Record the copy operation and retain the original compilation binding."""
    from scripts.artifact_provenance import write
    sidecar = pdf_path.with_name(pdf_path.name + ".provenance.json")
    if not sidecar.is_file():
        raise ValueError("compiled PDF is missing provenance")
    if output_path.exists() and not overwrite:
        raise FileExistsError("refusing to overwrite a versioned publication")
    shutil.copy2(pdf_path, output_path)
    write(output_path, [pdf_path, sidecar], Path(__file__),
          transform={"activity": "copy verified compiled publication", "publication_version": version,
                     "mutable_alias": overwrite}, kind="main_paper")
    return output_path


def build_versioned_pdf(pdf_path: Path, version: str) -> Path:
    """
    将 PDF 复制到 acm/pdf/ 目录，文件名包含版本号和时间戳。
    
    格式: CACTUS_v<VERSION>_<YYYYMMDD-HHMMSS>.pdf
    """
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # 本地时间戳，精确到秒（避免文件名与本地时钟不一致）
    from datetime import timezone
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    
    language = "_CN" if pdf_path.parent.parent.name == "paper-cn" else ""
    from scripts.paper_pipeline import publication_styles
    document_class, _ = publication_styles()
    journal_label = "_JSS" if document_class.stem == "elsarticle" else ""
    filename = f"CACTUS{language}{journal_label}_v{version}_{timestamp}.pdf"
    output_path = OUTPUT_DIR / filename
    
    return copy_publication(pdf_path, output_path, version)


def main() -> int:
    parser = argparse.ArgumentParser(description="构建当前期刊论文 PDF")
    parser.add_argument(
        "--version", "-v",
        default=None,
        help=(
            "显式指定论文版本号 (例如 1.3);省略时自动从 acm/pdf/ 中"
            "扫描并递增小版本号,首次构建默认为 1.0"
        ),
    )
    parser.add_argument(
        "--no-bump",
        action="store_true",
        help=(
            "禁用自动递增:即使用户未传 --version,也不扫描已有 PDF;"
            "等价于把默认版本写死为 1.0。重复构建同名版本可能覆盖同名 PDF"
        ),
    )
    parser.add_argument(
        "--paper-dir",
        type=Path,
        default=PAPER_DIR,
        help=f"论文目录 (默认: {PAPER_DIR})"
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=OUTPUT_DIR,
        help=f"输出目录 (默认: {OUTPUT_DIR})"
    )
    args = parser.parse_args()

    # 决定本次构建使用的版本号。优先级:
    #   1) --version 显式覆盖;
    #   2) --no-bump 关闭扫描 → 退回 "1.0";
    #   3) 默认 → 从 acm/pdf/ 扫描最新版本并自动递增小版本号。
    if args.version is not None:
        version = args.version
        version_source = "explicit(--version)"
    elif args.no_bump:
        version = "1.0"
        version_source = "fallback(--no-bump)"
    else:
        version = next_version(args.output_dir)
        version_source = f"auto-bump(scan {args.output_dir})"

    git_commit = get_git_commit()
    print(f"Git commit: {git_commit}")
    print(f"论文版本: v{version}  [{version_source}]")

    # 决定构建使用的 python 解释器(优先 acm/.venv,Windows/POSIX 兼容)。
    python_bin = sys.executable
    for candidate in (
        ACM_DIR / ".venv" / "bin" / "python",            # Linux/macOS
        ACM_DIR / ".venv" / "Scripts" / "python.exe",   # Windows
    ):
        if candidate.is_file():
            python_bin = str(candidate)
            break

    # 先生成图表,再编译 LaTeX:否则 pdflatex 会因 figures/output/*.pdf 缺失而致命退出。
    # The evidence-verified pipeline generates only admitted, ledger-backed
    # current figures. The legacy CSV plotter cannot precede admission.

    # 编译论文
    print("正在编译论文...")
    pdf_path = compile_paper(python_bin)
    print(f"编译完成: {pdf_path}")

    from cactus.tools.datactl import verify_sidecar
    from scripts.paper_pipeline import validate
    validate()
    seen = set()
    for compiled in (pdf_path,):
        errors = verify_sidecar(ACM_DIR, compiled, seen=seen)
        if errors:
            raise ValueError("PDF provenance failed: " + "; ".join(errors))

    # 生成带版本号和时间戳的 PDF
    versioned_pdf = build_versioned_pdf(pdf_path, version)

    # 同时生成一个 latest.pdf 便于快速访问（不纳入版本控制）
    latest_pdf = OUTPUT_DIR / "CACTUS_latest.pdf"
    copy_publication(pdf_path, latest_pdf, version, overwrite=True)
    jss_latest_pdf = OUTPUT_DIR / "CACTUS_JSS_latest.pdf"
    copy_publication(pdf_path, jss_latest_pdf, version, overwrite=True)
    chinese_version = None
    # The current publication pipeline builds English only. Never stamp an old
    # Chinese build as a new, synchronized publication.

    print(f"\n输出文件:")
    print(f"  版本化 PDF: {versioned_pdf}")
    print(f"  最新 PDF:   {latest_pdf}")
    print(f"  JSS 最新 PDF: {jss_latest_pdf}")
    if chinese_version:
        print(f"  中文 PDF:   {chinese_version}")
    print(f"  输出目录:   {OUTPUT_DIR}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
