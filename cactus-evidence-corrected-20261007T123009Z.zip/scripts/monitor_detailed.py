"""Detailed real-time monitor for a single RUN.

Polls trace events.jsonl and prints live status with full event details.

Usage: python monitor_detailed.py <run-id> [--interval 5] [--once]
"""
import argparse
import json
import sys
import time
from pathlib import Path

REPO = Path("e:/work/p5-acm/acm")
RUNS_DIR = REPO / "experiments" / "runs"


def find_run_dir(run_id: str) -> Path:
    target = Path(run_id).name
    for p in RUNS_DIR.iterdir():
        if p.name == target:
            return p
    raise SystemExit(f"RUN dir not found for {run_id}")


def fmt_event(e: dict) -> list[str]:
    t = e["type"]
    ts = e.get("utc_ts", "?")
    p = e.get("payload", {})
    lines = [f"  [{ts}] {t}"]
    if t == "model_call":
        lines.append(f"    turn={p.get('turn_id')}")
        lines.append(f"    max={p.get('max_tokens')} in={p.get('input_tokens')} out={p.get('output_tokens')} finish={p.get('finish_reason')}")
        resp = p.get("response_text", "")
        if len(resp) > 400:
            lines.append(f"    response ({len(resp)} chars): {resp[:200]}...{resp[-100:]}")
        else:
            lines.append(f"    response: {resp}")
    elif t == "prediction_rejected":
        lines.append(f"    attempt={p.get('attempt')} class={p.get('reason_class')}")
        lines.append(f"    reason: {p.get('reason', '')[:300]}")
    elif t == "prediction_accepted":
        lines.append(f"    attempt={p.get('attempt')}")
        if "patch_chars" in p:
            lines.append(f"    patch_chars={p.get('patch_chars')}")
    elif t == "context_selected":
        sel = p.get("selected", [])
        toks = p.get("tokens", 0)
        lines.append(f"    units={len(sel)} tokens={toks} status={p.get('status')}")
        for u in sel:
            if isinstance(u, str):
                lines.append(f"      - {u}")
    elif t == "literal_anchor_candidates":
        lines.append(f"    paths={p.get('paths')}")
        lines.append(f"    anchor={p.get('anchor_units')} candidates={p.get('candidate_units')} matched={p.get('matched_anchor_units')} mode={p.get('mode')}")
    elif t == "issue_symbol_anchors":
        lines.append(f"    symbols={p.get('symbols')}")
        lines.append(f"    paths={p.get('paths')}")
    elif t == "prediction.heartbeat" or t == "prediction.heartbeat":
        lines.append(f"    elapsed={p.get('elapsed_sec')}s")
    elif t == "task.start":
        lines.append(f"    variant={p.get('variant')}")
    elif t == "task.end" or t == "campaign.end" or t == "campaign.ready":
        lines.append(f"    {p}")
    elif t == "prediction.start":
        lines.append(f"    timeout={p.get('timeout_sec')} token_limit={p.get('output_token_limit')}")
    return lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_id")
    ap.add_argument("--interval", type=float, default=4.0)
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()

    run = find_run_dir(args.run_id)
    trace = run / "trace" / "events.jsonl"
    print(f"Watching: {trace}")
    print(f"Interval: {args.interval}s\n")

    last_count = 0
    start = time.time()
    while True:
        if trace.exists():
            events = [json.loads(l) for l in trace.read_text(encoding="utf-8").splitlines() if l.strip()]
            if len(events) > last_count:
                for e in events[last_count:]:
                    for line in fmt_event(e):
                        print(line)
                    print()
                last_count = len(events)
        elapsed = time.time() - start
        sys.stdout.write(f"\r[{elapsed:6.1f}s] events={last_count}  ")
        sys.stdout.flush()
        if args.once and last_count > 0:
            # show latest event detail one more time then exit
            pass
        time.sleep(args.interval)
        if args.once:
            break


if __name__ == "__main__":
    main()
