"""Prepare a deterministic 50-task Pilot plan without executing a workload."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MANIFEST = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
DEFAULT_PLAN = ROOT / "artifacts" / "phase_c_pilot50_plan.json"
DEFAULT_TASKS = ROOT / "artifacts" / "pilot50_tasks.jsonl"


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"manifest line {line_number} is not an object")
        rows.append(value)
    return rows


def _select_round_robin(rows: list[dict[str, Any]], count: int) -> list[dict[str, Any]]:
    if count < 1:
        raise ValueError("count must be positive")
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row.get("repo", row.get("repo_id", "")))].append(row)
    if any(not key for key in grouped):
        raise ValueError("every task must declare repo or repo_id")
    for values in grouped.values():
        values.sort(key=lambda row: str(row.get("task_id", row.get("instance_id", ""))))
    selected: list[dict[str, Any]] = []
    repositories = sorted(grouped)
    while len(selected) < min(count, len(rows)):
        added = False
        for repository in repositories:
            if grouped[repository]:
                selected.append(grouped[repository].pop(0))
                added = True
                if len(selected) == count:
                    break
        if not added:
            break
    if len(selected) != count:
        raise ValueError(f"manifest contains only {len(rows)} task(s), cannot select {count}")
    return selected


def prepare(manifest: Path = DEFAULT_MANIFEST, plan_output: Path = DEFAULT_PLAN, task_output: Path = DEFAULT_TASKS, count: int = 50) -> dict[str, Any]:
    source_rows = _read_jsonl(manifest)
    selected = _select_round_robin(source_rows, count)
    task_ids = [str(row.get("task_id", row.get("instance_id", ""))) for row in selected]
    if any(not task_id for task_id in task_ids) or len(set(task_ids)) != len(task_ids):
        raise ValueError("selected tasks must have unique non-empty task_id values")
    # The augmented manifest is an evaluator input, not a model input.  Keep
    # the selection safe if upstream data ever contains gold patch fields.
    safe_rows = [{key: value for key, value in row.items() if key not in {"patch", "test_patch"}} for row in selected]
    task_output.parent.mkdir(parents=True, exist_ok=True)
    task_output.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in safe_rows), encoding="utf-8", newline="\n")
    image_refs = sorted({str(row.get("image", "")) for row in selected})
    plan = {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "status": "planning_only",
        "execution_performed": False,
        "model_calls": 0,
        "source_manifest": manifest.as_posix(),
        "source_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
        "selected_manifest": task_output.as_posix(),
        "selected_manifest_sha256": hashlib.sha256(task_output.read_bytes()).hexdigest(),
        "task_count": len(safe_rows),
        "task_ids": task_ids,
        "repository_distribution": dict(sorted(Counter(str(row.get("repo", row.get("repo_id", ""))) for row in safe_rows).items())),
        "evaluator_image_count": len(image_refs),
        "evaluator_images": [{"image": image, "digest_status": "pending_observation"} for image in image_refs],
        "gold_fields_removed": sum(int("patch" in row or "test_patch" in row) for row in selected),
        "gate": {"status": "BLOCKED", "reasons": ["50-task Pilot requires complete digest observation for every evaluator image", "50-task Pilot requires a reviewed contract and session authorization", "formal execution requires a clean worktree"]},
        "next_action": "Observe/pull each evaluator image, create a reviewed contract with complete digests, then run formal preflight before execution.",
    }
    plan_output.parent.mkdir(parents=True, exist_ok=True)
    plan_output.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return plan


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--plan-output", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--task-output", type=Path, default=DEFAULT_TASKS)
    parser.add_argument("--count", type=int, default=50)
    args = parser.parse_args()
    result = prepare(args.manifest, args.plan_output, args.task_output, args.count)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
