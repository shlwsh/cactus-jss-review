import subprocess
from pathlib import Path

patch = """diff --git a/astropy/wcs/wcs.py b/astropy/wcs/wcs.py
--- a/astropy/wcs/wcs.py
+++ b/astropy/wcs/wcs.py
@@ -1212,6 +1212,8 @@ reduce these to 2 dimensions using the naxis kwarg.
         \"\"\"
 
         def _return_list_of_arrays(axes, origin):
+            if any([x.size == 0 for x in axes]):
+                return axes
             try:
                 axes = np.broadcast_arrays(*axes)
             except ValueError:
@@ -1235,6 +1237,8 @@ reduce these to 2 dimensions using the naxis kwarg.
                 raise ValueError(
                     \"When providing two arguments, the array must be \"
                     \"of shape (N, {0})\".format(self.naxis))
+            if 0 in xy.shape:
+                return xy
             if ra_dec_order and sky == 'input':
                 xy = self._denormalize_sky(xy)
             result = func(xy, origin)
"""

test_patch = """diff --git a/astropy/wcs/tests/test_wcs.py b/astropy/wcs/tests/test_wcs.py
--- a/astropy/wcs/tests/test_wcs.py
+++ b/astropy/wcs/tests/test_wcs.py
@@ -1093,3 +1093,21 @@ def test_keyedsip():
     assert isinstance( w.sip, wcs.Sip )
     assert w.sip.crpix[0] == 2048
     assert w.sip.crpix[1] == 1026
+
+
+def test_zero_size_input():
+    with fits.open(get_pkg_data_filename('data/sip.fits')) as f:
        w = wcs.WCS(f[0].header)

    inp = np.zeros((0, 2))
    assert_array_equal(inp, w.all_pix2world(inp, 0))
    assert_array_equal(inp, w.all_world2pix(inp, 0))

    inp = [], [1]
    result = w.all_pix2world([], [1], 0)
    assert_array_equal(inp[0], result[0])
    assert_array_equal(inp[1], result[1])

    result = w.all_world2pix([], [1], 0)
    assert_array_equal(inp[0], result[0])
    assert_array_equal(inp[1], result[1])
"""

Path('E:/cactus-data/lite50/temp/dev-tests/patch.diff').write_text(patch, encoding='utf-8')
Path('E:/cactus-data/lite50/temp/dev-tests/test_patch.diff').write_text(test_patch, encoding='utf-8')

# Run docker to test
cmd = [
    "docker", "run", "--rm",
    "-v", "E:/cactus-data/lite50/temp/dev-tests/patch.diff:/tmp/patch.diff:ro",
    "-v", "E:/cactus-data/lite50/temp/dev-tests/test_patch.diff:/tmp/test_patch.diff:ro",
    "sweb.eval.x86_64.astropy__astropy-7746:latest",
    "/bin/bash", "-c",
    "cd /testbed && git apply -v /tmp/patch.diff && git apply -v /tmp/test_patch.diff && /opt/miniconda3/envs/testbed/bin/pytest -rA astropy/wcs/tests/test_wcs.py -k test_zero_size_input"
]
print("Running docker test...")
res = subprocess.run(cmd, capture_output=True, text=True)
print("Returncode:", res.returncode)
print("STDOUT:\n", res.stdout)
print("STDERR:\n", res.stderr)
