#!/usr/bin/env python3
"""合成回归脚本：验证动态分发链可以把 operator helper 加入 repair-site 候选。"""

import json
import sys
from pathlib import Path

# 添加 src 目录到路径
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from cactus.context.repair_sites import build_repair_sites
from cactus.domain.models import ContextUnit


# 模拟 Astropy separable.py 真实调用链
# 来自 issue astropy__astropy-12907：嵌套 CompoundModel 问题
SEPARABLE_PY = '''
"""Separability matrix functions for compound models."""

import numpy as np

__all__ = ['separability_matrix', '_cstack', '_cdot', '_coord_matrix', '_separable']


def _cstack(left, right):
    """Stack two separability matrices left and right.

    Parameters
    ----------
    left : ndarray
        Separability matrix of the left operand.
    right : ndarray
        Separability matrix of the right operand.

    Returns
    -------
    stacked : ndarray
        A block-diagonal matrix combining left and right.
    """
    n = left.shape[-1]
    m = right.shape[-1]
    result = np.zeros((n + m, n + m), dtype=bool)
    result[:n, :n] = left
    result[n:, n:] = right
    return result


def _cdot(left, right):
    """Matrix product of separability matrices.

    Parameters
    ----------
    left : ndarray
    right : ndarray

    Returns
    -------
    product : ndarray
    """
    return np.dot(left, right)


def _coord_matrix(model):
    """Create a coordinate matrix for a non-separable model.

    Parameters
    ----------
    model : Model

    Returns
    -------
    matrix : ndarray
        Boolean separability matrix.
    """
    if model.separable:
        return np.eye(model.n_inputs)
    return np.ones((model.n_inputs, model.n_inputs), dtype=bool)


def _separable(transform):
    """Compute the separability matrix for a transform.

    For nested CompoundModels, this recurses through left and right
    operands and combines them via the appropriate operator.

    Parameters
    ----------
    transform : Model

    Returns
    -------
    matrix : ndarray
    """
    from astropy.modeling import CompoundModel
    if isinstance(transform, CompoundModel):
        left = _separable(transform.left)
        right = _separable(transform.right)
        return _operators[transform.op](left, right)
    if not transform.separable:
        return _coord_matrix(transform)
    return np.eye(transform.n_inputs)


def separability_matrix(transform):
    """Compute separability matrix for an arbitrary model.

    Parameters
    ----------
    transform : Model

    Returns
    -------
    separability : ndarray
        A boolean matrix indicating input-output separability.
    """
    if transform.n_inputs == 1 and transform.n_outputs == 1:
        return np.array([[True]])
    return _separable(transform)


_operators = {'&': _cstack, '|': _cdot, '*': _cdot}
'''


def main():
    # Issue text from astropy__astropy-12907
    issue_text = """
Modeling's `separability_matrix` does not compute separability correctly for nested CompoundModels.

Consider the following model:
```python
from astropy.modeling import models as m
from astropy.modeling.separable import separability_matrix
cm = m.Linear1D(10) & m.Linear1D(5)
```

For `separability_matrix(m.Pix2Sky_TAN() & cm)`:
```
array([[ True,  True, False, False],
       [ True,  True, False, False],
       [False, False,  True,  True],
       [False, False,  True,  True]])
```

The inputs and outputs are no longer separable for nested CompoundModels.
This feels like a bug in the separability calculation.
"""

    unit = ContextUnit(
        unit_id="astropy-modeling-separable",
        kind="file",
        path="astropy/modeling/separable.py",
        token_count=len(SEPARABLE_PY),
        text=SEPARABLE_PY,
    )

    context, sites = build_repair_sites(
        [unit],
        issue_text,
    )

    # 诊断报告
    report = {
        "task": "astropy__astropy-12907",
        "source_scope": "synthetic_ast_fixture_not_benchmark_checkout",
        "cstack_in_context": "_cstack" in context,
        "coord_matrix_in_context": "_coord_matrix" in context,
        "separable_in_context": "_separable" in context,
        "cstack_has_site": any(s.symbol == "_cstack" for s in sites.values()),
        "coord_matrix_has_site": any(s.symbol == "_coord_matrix" for s in sites.values()),
        "context_length": len(context),
        "max_chars": 18000,
        "budget_utilization_pct": f"{len(context) / 18000 * 100:.1f}%",
        "num_sites": len(sites),
        "function_names_in_context": [
            line.split("symbol:")[1].split(" ")[0]
            for line in context.split("\n")
            if "symbol:" in line and "<!--" in line
        ],
    }

    print(json.dumps(report, indent=2))

    # 验收检查
    if report["cstack_in_context"] and report["cstack_has_site"]:
        print("\n[PASS] _cstack is in context and has at least one site")
    else:
        print("\n[FAIL] _cstack is NOT in context or has no site")
        return 1

    if report["coord_matrix_in_context"] and report["coord_matrix_has_site"]:
        print("[PASS] _coord_matrix is in context and has at least one site")
    else:
        print("[FAIL] _coord_matrix is NOT in context or has no site")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
