"""Examine the v3 algorithm's site selection + replace prompts."""
src = open('scripts/cactus_swebench_predict.py', encoding='utf-8').read()
import re
# Find _generate_site_edit_v3
i = src.find('def _generate_site_edit_v3')
if i < 0:
    i = src.find('_generate_site_edit_v3(')
print(f'_generate_site_edit_v3 at offset {i}')
# print 4000 chars around it
print('---v3 area---')
print(src[i:i+4000])
print('---end---')