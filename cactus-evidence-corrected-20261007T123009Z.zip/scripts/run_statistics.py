"""Compute paired experiment statistics, or emit explicit pending artifacts."""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path

from cactus.analysis.paired_stats import mcnemar_exact, paired_bootstrap
from cactus.evaluation.effect import cohens_d, cliffs_delta, paired_contingency
from cactus.evaluation.multiple import holm


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "results"
DEFAULT_OUTPUT = ROOT / "analysis"
BOOTSTRAP_SAMPLES = 10000


def _read(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _resolved(row: dict[str, str]) -> bool:
    if row.get("canonical_outcome"):
        return row["canonical_outcome"] == "VALID_RESOLVED"
    return row.get("resolved", "").lower() in {"1", "true", "yes"}


def _valid(row: dict[str, str]) -> bool:
    if row.get("evaluator_valid"):
        return row["evaluator_valid"].lower() in {"1", "true", "yes"}
    return row.get("canonical_outcome", "") in {"VALID_RESOLVED", "VALID_UNRESOLVED"}


def _number(row: dict[str, str], *names: str) -> float | None:
    for name in names:
        value = row.get(name)
        if value not in (None, "", "null"):
            try:
                return float(value)
            except ValueError:
                return None
    return None


def _pending(missing: list[str], generated_at: str) -> dict[str, object]:
    return {"schema_version": "2.1", "generated_at": generated_at, "status": "pending_evidence", "missing_inputs": missing, "values": {}}


def _variant_rows(rows: list[dict[str, str]]) -> dict[str, dict[str, dict[str, str]]]:
    grouped: dict[str, dict[str, dict[str, str]]] = {}
    for row in rows:
        variant = row.get("variant", "").strip()
        task_id = row.get("task_id", row.get("instance_id", "")).strip()
        if variant and task_id:
            grouped.setdefault(variant, {})[task_id] = row
    return grouped


def _paired_rows(rows: list[dict[str, str]], first_variant: str, second_variant: str) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    grouped = _variant_rows(rows)
    first = grouped.get(first_variant, {})
    second = grouped.get(second_variant, {})
    pairs = [(first[task], second[task]) for task in sorted(set(first) & set(second)) if _valid(first[task]) and _valid(second[task])]
    return [pair[0] for pair in pairs], [pair[1] for pair in pairs]


def _numeric_pair(first: list[dict[str, str]], second: list[dict[str, str]], *names: str) -> tuple[list[float], list[float]] | None:
    first_values = [_number(row, *names) for row in first]
    second_values = [_number(row, *names) for row in second]
    if not first_values or not second_values or not all(value is not None for value in first_values + second_values):
        return None
    return [float(value) for value in first_values], [float(value) for value in second_values]


def _main_comparison(rows: list[dict[str, str]], generated_at: str) -> tuple[dict[str, object], dict[str, object]]:
    first, second = _paired_rows(rows, "maximal_context", "cactus_full")
    if not first:
        pending = _pending(["evaluator-valid paired maximal_context/cactus_full rows"], generated_at)
        return pending, {"status": "pending_evidence", "reason": "no evaluator-valid paired maximal_context/cactus_full tasks"}
    first_success = [_resolved(row) for row in first]
    second_success = [_resolved(row) for row in second]
    contingency = paired_contingency(first_success, second_success)
    mcnemar = {
        "schema_version": "2.1",
        "generated_at": generated_at,
        **contingency,
        "p_value": mcnemar_exact(contingency["first_true_second_false"], contingency["first_false_second_true"]),
        "n": len(first),
        "comparison": "maximal_context_vs_cactus_full",
        "status": "observed",
    }
    bootstrap_values: dict[str, object] = {}
    token_pair = _numeric_pair(first, second, "input_tokens")
    if token_pair:
        bootstrap_values["input_tokens"] = {**paired_bootstrap(*token_pair, samples=BOOTSTRAP_SAMPLES, seed=1), "status": "observed"}
    else:
        bootstrap_values["input_tokens"] = {"status": "pending_evidence", "reason": "input_tokens missing"}
    cost_pair = _numeric_pair(first, second, "verified_cost", "cost")
    if cost_pair:
        bootstrap_values["verified_cost"] = {**paired_bootstrap(*cost_pair, samples=BOOTSTRAP_SAMPLES, seed=1), "status": "observed"}
    else:
        bootstrap_values["verified_cost"] = {"status": "pending_evidence", "reason": "verified cost missing"}
    bootstrap = {"schema_version": "2.1", "generated_at": generated_at, "status": "observed", "values": bootstrap_values}
    values: dict[str, object] = {
        "cactus_minus_maximal_resolution_rate": (sum(second_success) - sum(first_success)) / len(first),
    }
    if token_pair and bootstrap_values["input_tokens"].get("status") == "observed":
        first_tokens, second_tokens = token_pair
        stats = bootstrap_values["input_tokens"]
        values.update({
            "maximal_minus_cactus_input_tokens_mean": stats["mean_difference"],
            "maximal_minus_cactus_input_tokens_median": stats["median_difference"],
            "input_token_savings_relative_to_maximal": (sum(first_tokens) - sum(second_tokens)) / max(1e-12, sum(first_tokens)),
            "input_token_cohens_d": cohens_d(first_tokens, second_tokens),
            "input_token_cliffs_delta": cliffs_delta(first_tokens, second_tokens),
            "input_token_ci_low": stats["ci_low"],
            "input_token_ci_high": stats["ci_high"],
        })
    if cost_pair and bootstrap_values["verified_cost"].get("status") == "observed":
        first_cost, second_cost = cost_pair
        stats = bootstrap_values["verified_cost"]
        values.update({
            "maximal_minus_cactus_cost_mean": stats["mean_difference"],
            "maximal_minus_cactus_cost_median": stats["median_difference"],
            "cost_savings_relative_to_maximal": (sum(first_cost) - sum(second_cost)) / max(1e-12, sum(first_cost)),
            "cost_cohens_d": cohens_d(first_cost, second_cost),
            "cost_cliffs_delta": cliffs_delta(first_cost, second_cost),
            "cost_ci_low": stats["ci_low"],
            "cost_ci_high": stats["ci_high"],
        })
    effects = {"schema_version": "2.1", "generated_at": generated_at, "status": "observed", "n": len(first), "values": values}
    return {"mcnemar": mcnemar, "bootstrap": bootstrap, "effects": effects}, {"status": "observed", "n": len(first)}


def _ablation_comparison(rows: list[dict[str, str]], generated_at: str) -> dict[str, object]:
    comparisons: list[dict[str, object]] = []
    p_values: list[float] = []
    for variant in ("cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density"):
        first, second = _paired_rows(rows, "cactus_full", variant)
        if not first:
            comparisons.append({"variant": variant, "status": "pending_evidence", "reason": "no evaluator-valid paired tasks"})
            continue
        contingency = paired_contingency([_resolved(row) for row in first], [_resolved(row) for row in second])
        p_value = mcnemar_exact(contingency["first_true_second_false"], contingency["first_false_second_true"])
        p_values.append(p_value)
        comparisons.append({"variant": variant, "n": len(first), **contingency, "p_value": p_value, "status": "observed"})
    adjusted = holm(p_values) if p_values else []
    index = 0
    for comparison in comparisons:
        if comparison["status"] == "observed":
            comparison["holm_adjusted_p_value"] = adjusted[index]
            index += 1
    return {"schema_version": "2.1", "generated_at": generated_at, "status": "observed" if p_values else "pending_evidence", "comparisons": comparisons, "method": "Holm-Bonferroni", "alpha": 0.05}


def run(input_dir: Path = DEFAULT_INPUT, output_dir: Path = DEFAULT_OUTPUT) -> dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    main_path = input_dir / "main_task_level_metrics.csv"
    ablation_path = input_dir / "ablation_results.csv"
    main_rows = _read(main_path) if main_path.is_file() else []
    if main_rows:
        comparison, comparison_summary = _main_comparison(main_rows, generated_at)
        mcnemar = comparison.get("mcnemar", comparison)
        bootstrap = comparison.get("bootstrap", {"schema_version": "2.1", "generated_at": generated_at, "status": "pending_evidence", "values": {}})
        effects = comparison.get("effects", _pending(["paired numeric outcomes"], generated_at))
    else:
        mcnemar = _pending(["results/main_task_level_metrics.csv"], generated_at)
        bootstrap = {"schema_version": "2.1", "generated_at": generated_at, "status": "pending_evidence", "values": {}}
        effects = _pending(["results/main_task_level_metrics.csv"], generated_at)
        comparison_summary = {"status": "pending_evidence"}
    power_path = ROOT / "paper" / "power_analysis.yaml"
    try:
        import yaml

        power_spec = yaml.safe_load(power_path.read_text(encoding="utf-8")) or {}
    except (OSError, ImportError, ValueError):
        power_spec = {}
    power_values = {
        key: power_spec.get(key)
        for key in ("alpha", "power", "minimum_meaningful_effect", "expected_discordant_pair_rate", "sample_size")
    }
    power_frozen = power_spec.get("status") == "owner_frozen" and all(value is not None for value in power_values.values())
    required_pairs = power_values["sample_size"] if power_frozen else None
    outputs = {
        "mcnemar_results.json": mcnemar,
        "bootstrap_intervals.json": bootstrap,
        "effect_sizes.json": effects,
        "holm_corrected_ablation.json": _ablation_comparison(_read(ablation_path), generated_at) if ablation_path.is_file() else _pending(["results/ablation_results.csv"], generated_at),
        "power_analysis.json": {
            "schema_version": "2.1",
            "generated_at": generated_at,
            "status": "planning_only" if power_frozen else "pending_owner_freeze",
            "assumptions": power_values,
            "required_paired_tasks": required_pairs,
            "source": "paper/power_analysis.yaml",
            "note": "Power values are never inferred from pilot or C0 outcomes; owner-frozen parameters are required before sample-size calculation.",
        },
    }
    for name, value in outputs.items():
        (output_dir / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    summary = {"schema_version": "2.1", "generated_at": generated_at, "input_dir": "results", "output_dir": "analysis", "main_rows": len(main_rows), "main_comparison": comparison_summary, "status": "observed" if comparison_summary.get("status") == "observed" else "pending_evidence", "outputs": sorted(outputs)}
    (output_dir / "statistics_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    print(json.dumps(run(args.input_dir, args.output_dir), ensure_ascii=False))
