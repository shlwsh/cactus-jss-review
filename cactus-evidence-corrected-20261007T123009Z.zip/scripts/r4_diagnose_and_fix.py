"""Diagnostic + verification harness for R4 statement-edit failures (astropy-13033).

Two execution modes:

1) --mode offline (default): validate a pre-captured response JSON against the
   pinned base-commit workspace using ``_statement_edit_to_patch`` directly.
   Fast, no network, useful for verifying a known bad response.

2) --mode pipeline: run the full ``cactus_swebench_predict.py`` for one task,
   capture its stderr (including ``[statement_edit ...]`` diagnostics), and
   validate the produced patch.

The harness never touches Docker or LiteLLM; it only exercises the local
validator. Output is a JSON report on stdout and optionally to ``--output``.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cactus.adapters.benchmark import load_manifest


def _predict_module() -> Any:
    script = Path(__file__).resolve().with_name("cactus_swebench_predict.py")
    spec = importlib.util.spec_from_file_location("cactus_swebench_predict", script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load prediction bridge: {script}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_response(args: argparse.Namespace) -> str:
    if args.response_file is not None:
        return args.response_file.read_text(encoding="utf-8")
    if args.response_json is not None:
        return args.response_json
    raise SystemExit("offline mode requires --response-file or --response-json")


def _run_subprocess(cmd: list[str], cwd: Path, timeout: int, env: dict[str, str] | None = None) -> dict[str, Any]:
    proc = subprocess.run(
        cmd, cwd=str(cwd),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, timeout=timeout, env=env,
    )
    return {
        "cmd": cmd,
        "exit_code": proc.returncode,
        "stdout_tail": proc.stdout[-1500:],
        "stderr_tail": proc.stderr[-1500:],
        "stderr_full": proc.stderr,
        "stdout_full": proc.stdout,
    }


def diagnose(
    *,
    manifest: Path,
    task_id: str,
    repo_root: Path,
    response: str,
) -> dict[str, Any]:
    """Public alias for the offline diagnostic harness (regression-tested)."""
    return diagnose_offline(
        manifest=manifest,
        task_id=task_id,
        repo_root=repo_root,
        response=response,
    )


def diagnose_offline(*, manifest: Path, task_id: str, repo_root: Path, response: str) -> dict[str, Any]:
    repo_root = repo_root.resolve()
    tasks = {task.task_id: task for task in load_manifest(manifest)}
    if task_id not in tasks:
        raise ValueError(f"task_id is not present in the inference-safe manifest: {task_id}")
    task = tasks[task_id]
    revision = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=repo_root, check=True,
        capture_output=True, text=True,
    ).stdout.strip().lower()
    report: dict[str, Any] = {
        "schema_version": "1.0",
        "task_id": task_id,
        "repo_id": task.repo_id,
        "expected_base_commit": task.base_commit,
        "actual_base_commit": revision,
        "base_commit_matches": revision == task.base_commit,
        "prediction_sha256": hashlib.sha256(response.encode("utf-8")).hexdigest(),
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "network_calls": 0,
        "repository_modified": False,
        "mode": "offline",
    }
    if revision != task.base_commit:
        report.update(status="base_commit_mismatch", patch_applicable=False)
        return report

    response_data = json.loads(response)
    edits = response_data.get("edits") if isinstance(response_data, dict) else None
    if not isinstance(edits, list):
        raise ValueError("response must be a statement_edit JSON object with an edits array")
    allowed_paths = {
        edit.get("path") for edit in edits
        if isinstance(edit, dict) and isinstance(edit.get("path"), str)
    }
    diagnostic = io.StringIO()
    try:
        with contextlib.redirect_stderr(diagnostic):
            patch = _predict_module()._statement_edit_to_patch(
                response, repo_root, allowed_paths=allowed_paths,
            )
        check = subprocess.run(
            ["git", "apply", "--check", "--whitespace=nowarn"],
            cwd=repo_root, input=patch.encode("utf-8"), capture_output=True, check=False,
        )
        check_output = (check.stderr or check.stdout).decode("utf-8", errors="replace").strip()
        report.update(
            status="patch_ready" if check.returncode == 0 else "patch_not_applicable",
            patch_applicable=check.returncode == 0,
            patch_sha256=hashlib.sha256(patch.encode("utf-8")).hexdigest(),
            patch=patch,
            apply_check_output=check_output,
        )
    except (ValueError, json.JSONDecodeError) as exc:
        report.update(
            status="patch_rejected",
            patch_applicable=False,
            error=str(exc),
        )
    report["statement_edit_diagnostics"] = diagnostic.getvalue().splitlines()
    return report


def diagnose_pipeline(
    *,
    manifest: Path,
    task_id: str,
    repo_root: Path,
    python_exe: Path,
    model_config: Path,
    budget: int,
    request_timeout_sec: int,
    api_key: str,
    trace_path: Path | None,
    output_path: Path | None,
) -> dict[str, Any]:
    repo_root = repo_root.resolve()
    tasks = {task.task_id: task for task in load_manifest(manifest)}
    if task_id not in tasks:
        raise ValueError(f"task_id is not present in the inference-safe manifest: {task_id}")
    task = tasks[task_id]
    revision = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=repo_root, check=True,
        capture_output=True, text=True,
    ).stdout.strip().lower()
    if revision != task.base_commit:
        return {
            "schema_version": "1.0",
            "task_id": task_id,
            "mode": "pipeline",
            "status": "base_commit_mismatch",
            "expected_base_commit": task.base_commit,
            "actual_base_commit": revision,
        }

    env = {**__import__("os").environ, "PYTHONPATH": "scripts;.", "CACTUS_LITELLM_API_KEY": api_key}
    cmd = [
        str(python_exe),
        str(Path(__file__).resolve().with_name("cactus_swebench_predict.py")),
        "--tasks", str(manifest),
        "--task-id", task_id,
        "--repo-root", str(repo_root),
        "--model-config", str(model_config),
        "--budget", str(budget),
        "--request-timeout-sec", str(request_timeout_sec),
        "--variant", "cactus_full",
    ]
    if output_path is not None:
        cmd.extend(["--output", str(output_path)])
    if trace_path is not None:
        cmd.extend(["--trace", str(trace_path)])

    repo_root_for_run = Path(__file__).resolve().parent.parent
    proc_result = _run_subprocess(cmd, cwd=repo_root_for_run, timeout=request_timeout_sec + 600, env=env)

    statement_edit_lines = [
        line for line in proc_result["stderr_full"].splitlines()
        if "[statement_edit" in line
    ]
    report: dict[str, Any] = {
        "schema_version": "1.0",
        "task_id": task_id,
        "repo_id": task.repo_id,
        "mode": "pipeline",
        "expected_base_commit": task.base_commit,
        "actual_base_commit": revision,
        "base_commit_matches": True,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "network_calls": 1,
        "repository_modified": False,
        "predict_exit_code": proc_result["exit_code"],
        "predict_stdout_tail": proc_result["stdout_tail"],
        "predict_stderr_tail": proc_result["stderr_tail"],
        "statement_edit_diagnostics": statement_edit_lines,
    }

    if proc_result["exit_code"] != 0 or output_path is None or not Path(output_path).is_file():
        report["status"] = "predict_failed"
        return report

    prediction = json.loads(Path(output_path).read_text(encoding="utf-8").splitlines()[0])
    patch = prediction.get("model_patch", "")
    report["prediction_sha256"] = hashlib.sha256(patch.encode("utf-8")).hexdigest() if patch else None
    report["prediction_chars"] = len(patch)

    if patch:
        check = subprocess.run(
            ["git", "apply", "--check", "--whitespace=nowarn"],
            cwd=repo_root, input=patch.encode("utf-8"),
            capture_output=True, check=False,
        )
        check_output = (check.stderr or check.stdout).decode("utf-8", errors="replace").strip()
        report["patch_applicable"] = check.returncode == 0
        report["apply_check_output"] = check_output
        report["status"] = "patch_ready" if check.returncode == 0 else "patch_not_applicable"
    else:
        report["status"] = "empty_patch"
        report["patch_applicable"] = False
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=Path("json/cactus_tasks_inference_safe.jsonl"))
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--mode", choices=["offline", "pipeline"], default="offline")
    parser.add_argument("--repo-root", type=Path, required=True,
                        help="checked-out task repository at its pinned base commit")
    parser.add_argument("--output", type=Path, help="optional path for the JSON diagnostic report")

    source = parser.add_argument_group("offline inputs")
    source.add_argument("--response-file", type=Path)
    source.add_argument("--response-json")

    pipeline = parser.add_argument_group("pipeline inputs")
    pipeline.add_argument("--python-exe", type=Path, default=Path(".venv/Scripts/python.exe"))
    pipeline.add_argument("--model-config", type=Path, default=Path("configs/models/litellm_local_nothink_v7.json"))
    pipeline.add_argument("--budget", type=int, default=12000)
    pipeline.add_argument("--request-timeout-sec", type=int, default=900)
    pipeline.add_argument("--api-key", default=None, help="CACTUS_LITELLM_API_KEY (else read from env)")
    pipeline.add_argument("--trace", type=Path)
    pipeline.add_argument("--predict-output", type=Path, help="where to write prediction.jsonl")
    args = parser.parse_args(argv)

    api_key = args.api_key or __import__("os").environ.get("CACTUS_LITELLM_API_KEY", "")
    if args.mode == "offline":
        if not (args.response_file or args.response_json):
            parser.error("--mode offline requires --response-file or --response-json")
        response = _load_response(args)
        try:
            report = diagnose_offline(manifest=args.manifest, task_id=args.task_id,
                                       repo_root=args.repo_root, response=response)
        except (OSError, ValueError, subprocess.CalledProcessError) as exc:
            parser.error(str(exc))
    else:
        if not api_key:
            parser.error("--mode pipeline requires --api-key or CACTUS_LITELLM_API_KEY in env")
        try:
            report = diagnose_pipeline(
                manifest=args.manifest, task_id=args.task_id, repo_root=args.repo_root,
                python_exe=args.python_exe, model_config=args.model_config,
                budget=args.budget, request_timeout_sec=args.request_timeout_sec,
                api_key=api_key, trace_path=args.trace, output_path=args.predict_output,
            )
        except (OSError, ValueError, subprocess.CalledProcessError) as exc:
            parser.error(str(exc))

    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    return 0 if report.get("status") in {"patch_ready", "patch_not_applicable", "base_commit_mismatch"} else 1


if __name__ == "__main__":
    raise SystemExit(main())