"""Plan an immutable quarantine and recovery; this command never moves RUNs."""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
from collections import Counter
import hashlib
import json
from pathlib import Path

from cactus.governance.canonical import canonical_json
from cactus.governance.policy import derive_claim_status
from scripts.artifact_provenance import write, git_commit

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def fingerprint(row):
    path = (ROOT / row["path"]).resolve()
    path.relative_to((ROOT / "experiments/runs").resolve())
    if not path.is_dir() or path.is_symlink():
        raise ValueError("missing/unsafe original directory: " + row["run_id"])
    members = sorted(path.rglob("*"))
    if any(p.is_symlink() for p in members):
        raise ValueError("symlink inside source directory")
    actual = {p.relative_to(ROOT).as_posix(): sha(p) for p in members if p.is_file()}
    if actual != row["file_hashes"]:
        raise ValueError("source drift since the original audit: " + row["run_id"])
    content = {p.relative_to(path).as_posix(): actual[p.relative_to(ROOT).as_posix()]
               for p in members if p.is_file()}
    return {"content_sha256": hashlib.sha256(canonical_json(content).encode()).hexdigest(),
            "file_hashes_relative_to_directory": content, "file_count": len(content),
            "bytes": sum(p.stat().st_size for p in members if p.is_file())}


def strategies(errors):
    result = []
    if any("checksum mismatch" in e for e in errors):
        result.append("recover_original_bytes_from_trusted_sealed_archive; preserve_conflicting_versions; never_resign_changed_bytes")
    if any("configuration canonical hash" in e or "manifest output mismatch" in e for e in errors):
        result.append("reconcile_frozen_contract_config_and_source_identity; incompatible_identity_requires_new_RUN")
    if any(e.startswith("schema:") for e in errors):
        result.append("source_backed_legacy_schema_migration_to_new_record; unknown_fields_stay_unknown_and_blocked")
    if any("missing required" in e for e in errors):
        result.append("search_trusted_original_backups_for_missing_files; unavailable_observations_require_new_experiment")
    if any("unlisted file" in e for e in errors):
        result.append("preserve_postseal_additions_as_separate_supplement; verify_original_seal; do_not_rewrite_checksums")
    if any("diagnostic_directory" in e or "run_id" in e for e in errors):
        result.append("retain_diagnostic_identity_and_classification; never_relabel_as_formal_RUN; new_formal_execution_if_needed")
    if any("running" in e for e in errors):
        result.append("retain_unfinished_attempt; collect_actual_terminal_evidence_or_execute_new_RUN")
    return result or ["expert_source_review_and_fail_closed_recovery"]


def generate():
    instant = datetime.now(timezone.utc)
    generated = instant.strftime("%Y-%m-%dT%H:%M:%SZ")
    stamp = instant.astimezone(timezone(timedelta(hours=8))).strftime("%Y%m%d-%H%M%S")
    batch = instant.strftime("%Y%m%dT%H%M%SZ")
    output = ROOT / "docs/50tasks" / ("v1.0_" + stamp + "_历史问题目录隔离与证据恢复方案")
    if output.exists():
        raise FileExistsError(output)
    config_path = ROOT / "paper/publication_sources.json"
    config = load(config_path)
    for source in config["sources"].values():
        if sha(ROOT / source["path"]) != source["sha256"]:
            raise ValueError("pinned source drift")
    inventory_path = ROOT / config["sources"]["corpus_inventory"]["path"]
    inventory = rows(inventory_path)
    retry_path = ROOT / config["sources"]["retry_inventory"]["path"]
    retry = rows(retry_path)
    registry_path = ROOT / config["sources"]["retry_registry"]["path"]
    registry = rows(registry_path)
    admitted = {row["run_id"]: row for row in retry if row["admitted"]}
    if {row["provenance"]["run_id"] for row in registry} != set(admitted):
        raise ValueError("admission registry mismatch")
    for row in registry:
        claim, _ = derive_claim_status(row["evidence"], requested="supporting")
        if claim != "supporting" or row["publication"]["claim_status"] != claim:
            raise ValueError("current publication policy mismatch")
    bad = [row for row in inventory if row["integrity_errors"]]
    good = [row for row in inventory if not row["integrity_errors"]]
    bad_ids = {row["run_id"] for row in bad}
    if bad_ids & set(admitted):
        raise ValueError("proposed quarantine intersects admitted publication evidence")
    if set(row["run_id"] for row in inventory) != {p.name for p in (ROOT / "experiments/runs").iterdir() if p.is_dir()}:
        raise ValueError("archive directory inventory drift")
    proposed_storage = "F:/cactus-data/quarantine/" + batch
    cases = []
    live_inputs = []
    for row in bad:
        current = fingerprint(row)
        live_inputs.extend(ROOT / path for path in row["file_hashes"])
        cases.append({"run_id": row["run_id"], "task_id": row["task_id"], "experiment_id": row["experiment_id"],
                      "original_path": row["path"], "proposed_storage_relative_path": row["run_id"],
                      "original_inventory_tree_sha256": row["tree_sha256"], **current,
                      "original_integrity_errors": row["integrity_errors"], "claim_status": "blocked",
                      "recovery_status": "planned_not_moved", "required_recovery": strategies(row["integrity_errors"]),
                      "reentry_requirements": ["trusted_original_evidence_or_new_RUN", "bundle_and_schema_valid",
                          "contract_authorization_source_image_billing_verified", "patch_official_evaluator_raw_agreement",
                          "policy_derived_claim_status", "new_admission_and_publication_snapshot"]})
    protected = []
    for row in good:
        record = {"run_id": row["run_id"], "path": row["path"], "original_inventory_tree_sha256": row["tree_sha256"],
                  "archive_integrity_status": "verified_in_frozen_corpus", "preservation": "retain_original_in_active_path",
                  "publication_admission": "supporting" if row["run_id"] in admitted else "not_established_by_bundle_integrity"}
        if row["run_id"] in admitted:
            current = fingerprint(row)
            if current["content_sha256"] != admitted[row["run_id"]]["bundle_tree_sha256"]:
                raise ValueError("admitted RUN tree drift")
            live_inputs.extend(ROOT / path for path in row["file_hashes"])
            record.update({"content_sha256": current["content_sha256"], "task_id": admitted[row["run_id"]]["task_id"],
                           "resolved": admitted[row["run_id"]]["resolved"], "live_bytes_verified_at": generated})
        protected.append(record)
    counts = {"original_directories": len(inventory), "retain_verified_directories": len(good),
              "quarantine_candidates": len(bad), "quarantine_RUN_prefix": sum(row["run_id"].startswith("RUN-") for row in bad),
              "quarantine_diagnostics": sum(not row["run_id"].startswith("RUN-") for row in bad),
              "protected_admitted_runs": len(admitted), "protected_admitted_tasks": len({row["task_id"] for row in admitted.values()}),
              "protected_resolved_runs": sum(row["resolved"] for row in admitted.values()),
              "quarantine_files": sum(row["file_count"] for row in cases), "quarantine_bytes": sum(row["bytes"] for row in cases)}
    output.mkdir()
    candidates = output / "quarantine_candidates.jsonl"
    retained = output / "retained_archive.jsonl"
    for path, records in ((candidates, cases), (retained, protected)):
        path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in records), encoding="utf-8", newline="\n")
    inputs = [config_path, inventory_path, retry_path, registry_path, *sorted(set(live_inputs))]
    write(candidates, inputs, Path(__file__), transform={"activity": "non_destructive_quarantine_plan", "no_directories_moved": True}, kind="derived_dataset")
    write(retained, inputs, Path(__file__), transform={"activity": "preserve_all_verified_and_admitted_evidence", "integrity_is_not_admission": True}, kind="derived_dataset")
    summary = {"schema_version": "1.0", "generated_at": generated, "counts": counts,
               "plan_status": "prepared_not_executed", "proposed_storage_root": proposed_storage,
               "archive_integrity": "FAIL_retained", "blocking_dependency": "logical_path_resolver_required_before_physical_move",
               "source_commit": git_commit(ROOT),
               "policy": "immutable_originals; reversible_quarantine; no_admission_upgrade; new_RUN_for_new_observation"}
    summary_path = output / "summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write(summary_path, [candidates, retained], Path(__file__), transform={"activity": "summarize_quarantine_plan"}, kind="derived_dataset")
    text = f'''# 历史问题目录隔离与证据恢复方案

- 版本：v1.0；生成时间（UTC）：{generated}；文件名时间：{stamp}（Asia/Shanghai）。
- 分支 acm0920；当前工作目录不变；本批只编制和核验清单，没有移动目录、补填证据或启动实验。

## 1. 可行性与保留范围

可行。保留 {counts['retain_verified_directories']} 个完整性通过目录，包括已准入的 {counts['protected_admitted_runs']} 个 supporting RUN/{counts['protected_admitted_tasks']} 个任务及 {counts['protected_resolved_runs']} 个 resolved RUN。已准入证据与拟隔离集合交集为零，并已复核这些 RUN 的实际字节摘要。其余完整性通过目录保留归档身份，不能自动成为可引用结果。

拟隔离 {counts['quarantine_candidates']} 个目录：{counts['quarantine_RUN_prefix']} 个 RUN 前缀目录、{counts['quarantine_diagnostics']} 个诊断目录；本批逐目录复核实际文件清单及摘要与原核查快照一致，共 {counts['quarantine_files']} 文件/{counts['quarantine_bytes']} 字节。标注位于 quarantine_candidates.jsonl，原 RUN 内不添加标记文件。所有 {counts['original_directories']} 个原目录均有保留或隔离去向，不能漏目录。

## 2. 临时隔离区的存储规则

建议隔离批次根目录为 `{proposed_storage}`，作为受保护的长期恢复工作区，禁止系统临时目录自动清理。每个目录保存原名及完整字节；证据索引保存在项目内，外部磁盘路径由本地主机位置配置绑定。原逻辑路径、相对文件清单、每文件 SHA-256、位置无关 content_sha256、隔离原因和恢复状态分别记录。

原隔离副本只读；恢复工作另建副本或子目录。原始材料不覆盖、未知字段不猜测；保留迁移前完整快照、原目录清单、既有论文数值账本、图表/PDF及文献 capture。各次动作生成独立 UTC 秒级迁移日志与摘要，owner-only manual_decisions 不由脚本改写。

## 3. 物理迁移之前的实现条件

当前 corpus replay、历史 artifact sidecar 和 publication gate 按 experiments/runs 的原路径读取。直接移动会报缺失，不能只移动后重签来源文件。须先实现：

1. 逻辑来源定位器：原路径 → 受控隔离存储位置，验证安全根目录、不可变迁移清单及原始文件摘要，禁止任意路径、链接和跨目录逃逸。
2. corpus 枚举 active 与 quarantine 的完整并集，继续以原逻辑路径重算原快照；3919 个原目录都仍可核验，原 archive_integrity FAIL 不消失。
3. sidecar 输入解析、逐任务历史关联、审计扫描适配定位器，保证问题记录仍被完整核查，不能以迁走规避审计。
4. 发布验证保持独立：24 个准入 RUN 与现有宏、表、图、PDF 引用不变；增设活跃库完整性及隔离清单覆盖门禁，三类门禁分开显示。

## 4. 迁移事务顺序与验收

先核验绝对源路径都位于原 runs 根目录、绝对目标都位于明确隔离根目录，检查无模型/evaluator 正在使用这些目录、目标无重名和容量足够。逐目录执行“复制 → 核对完整文件集/摘要/字节数 → 保存提交状态 → 切换位置映射 → 从活跃根移出原目录”。跨盘采用可恢复状态机；源移出前必须已有验证副本，任何中断均能续做或回滚，不允许批量删除后再补证据。

验收：保留目录数不减、已准入记录集合/值不变、131 个问题目录全部有 verified copy 和明确映射、原快照可重算、publication PASS、当前引用来源摘要一致。隔离状态不升级为 verified 或 resolved。迁移之后全历史包括隔离档案仍报告真实 FAIL；活跃库和隔离覆盖门禁可以分别报告其实际状态。

## 5. 分类恢复与补充实验

每个目录的原原因、恢复动作和重入库要求见 quarantine_candidates.jsonl。优先恢复 checksum/identity 冲突，其次找缺失封存文件，再做可追溯旧 schema 迁移。后加日志/账单/evaluator 单独封存为 supplement，不能改原 checksums。诊断目录保留诊断身份，不改名冒充正式 RUN。

恢复原历史观察须取得可信原始封存证据；缺失记录不能靠新实验冒充。补充实验建立新合同/准确授权、固定镜像与源码、干净工作目录、账单和新 RUN-ID，以 parent_run_id/recovery_case_id 关联原问题；运行前通过正式门禁。新评测证明的是新尝试，原坏记录继续保留。

重入库条件：bundle/checksum/完整 schema、任务身份、源码/driver/derivation、合同/授权/镜像、账单、patch、官方 evaluator 与 raw 一致、政策推导的 claim_status 均满足。生成新的 admission registry 与快照，重新生成宏/表/图/PDF并核验；不能手改 registry 或把所有成功重试拼成最佳解决率。恢复不成功则长期 blocked，保留完整原因。

## 6. 当前清单与后续交接

- retained_archive.jsonl：所有完整性通过目录的保留清单，并单独标明已获 supporting 准入的 RUN。
- quarantine_candidates.jsonl：全部问题目录逐项标注、文件摘要、恢复路线与重入库条件。
- summary.json：计数、拟隔离根目录、依赖和未执行状态；三类文件均有同次 provenance sidecar。

旧500题准入链、旧registry和旧图表问题另设恢复工作项；131目录隔离并不自动解决它们。本批方案尚未实施物理迁移，后续先完成定位器及门禁适配，再执行有摘要验证与回滚记录的迁移。任何新建或切换 worktree 仍须先申请。
'''
    document = output / (output.name + ".md")
    document.write_text(text, encoding="utf-8", newline="\n")
    write(document, [summary_path, candidates, retained], Path(__file__), transform={"activity": "Chinese quarantine_and_recovery_plan"}, kind="derived_dataset")
    print(json.dumps({"plan": document.relative_to(ROOT).as_posix(), "counts": counts, "moved_directories": 0}, ensure_ascii=False))


if __name__ == "__main__":
    generate()
