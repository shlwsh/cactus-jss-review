"""Verify think config."""
import json
from pathlib import Path

mc = json.loads(Path("configs/models/litellm_local_think.json").read_text(encoding="utf-8"))
print("Config:")
for k in ("thinking", "max_output_tokens", "reasoning_effort", "prediction_max_attempts", "prediction_retry_context_max_chars"):
    print(f"  {k} = {mc.get(k)}")
print()
print(f"execution state exists: {Path('experiments/plans/C1_primary_pairs_20260925_R4.json.execution.json').exists()}")
