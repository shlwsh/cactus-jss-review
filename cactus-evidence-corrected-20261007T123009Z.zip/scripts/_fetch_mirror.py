"""Fetch full history for git mirrors."""
import subprocess
from pathlib import Path

mirror = Path("E:/work/p5-acm/acm/experiments/repo_cache/astropy__astropy.git")
print(f"Fetching full history for {mirror}...")
print("(May take 5-10 minutes)")

r = subprocess.run(
    ["git", "fetch", "--unshallow", "--tags", "--all"],
    cwd=str(mirror),
    capture_output=True,
    text=True,
    timeout=600,
)
print(f"Exit code: {r.returncode}")
if r.returncode != 0:
    print("STDERR:", r.stderr[:500])
else:
    print("Done!")

# Verify needed commits
for commit in [
    "298ccb478e6bf092953bca67a3d29dc6c35f6752",  # 13033
    "6ed769d58d89380ebaa1ef52b300691eefda8928",  # 13236
    "d16bfe05a744909de4b27f5875fe0d4ed41ce607",  # 12907
]:
    r = subprocess.run(
        ["git", "-C", str(mirror), "cat-file", "-e", f"{commit}" + "{commit}"],
        capture_output=True, timeout=10,
    )
    status = "OK" if r.returncode == 0 else "MISSING"
    print(f"  {commit[:12]}: {status}")
