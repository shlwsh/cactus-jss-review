"""monitor_live_v2.py — Enhanced real-time CACTUS task monitor with rich output.

Improvements over monitor_task.py:
  - Compact progress line every poll (elapsed, remaining, events, model_calls, rejects)
  - Detailed event-stream tail showing newest events as they arrive
  - Token-budget progress bar per model_call
  - Auto-detects RUN completion (status in run_manifest.json)
  - Works for both single-task and multi-task campaigns
  - Shows ETA based on observed model_call durations

Usage:
  & .\\.venv\\Scripts\\python.exe scripts\\monitor_live_v2.py <RUN_DIR> [--poll 5] [--stream]
  & .\\.venv\\Scripts\\python.exe scripts\\monitor_live_v2.py <RUN_DIR> --once
  & .\\.venv\\Scripts\\python.exe scripts\\monitor_live_v2.py <RUN_DIR> --stream       # tail-mode (every event)
"""

from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def _fmt(ts: str) -> str:
    if not ts:
        return "??:??:??"
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).strftime("%H:%M:%S")
    except Exception:
        return ts


def _fmt_dur(sec: float) -> str:
    if sec < 0:
        sec = 0
    if sec >= 3600:
        return f"{sec / 3600:.1f}h"
    if sec >= 60:
        return f"{int(sec // 60)}m{int(sec % 60):02d}s"
    return f"{int(sec)}s"


def _human_tokens(n: int | None) -> str:
    if n is None:
        return "?"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def _bar(ratio: float, width: int = 30) -> str:
    """Build a unicode bar with ratio filled (0.0 - 1.0)."""
    ratio = max(0.0, min(1.0, ratio))
    filled = int(width * ratio)
    return "█" * filled + "░" * (width - filled)


def load_events(trace_path: Path) -> list[dict]:
    if not trace_path.exists():
        return []
    raw = trace_path.read_text(encoding="utf-8")
    out = []
    for l in raw.splitlines():
        l = l.strip()
        if not l:
            continue
        try:
            out.append(json.loads(l))
        except Exception:
            continue
    return out


def summarize(events: list[dict]) -> dict:
    from collections import Counter
    types = Counter(e.get("type") or e.get("event") or "?" for e in events)
    model_calls = []
    for e in events:
        if e.get("type") == "model_call":
            p = e.get("payload", {})
            model_calls.append({
                "turn_id": p.get("turn_id", ""),
                "finish_reason": p.get("finish_reason"),
                "input_tokens": p.get("input_tokens"),
                "output_tokens": p.get("output_tokens"),
                "max_tokens": p.get("max_tokens"),
                "ts": e.get("utc_ts"),
                "usage_source": p.get("usage_source"),
                "response_text": p.get("response_text", ""),
            })
    rejections = []
    for e in events:
        if e.get("type") == "prediction_rejected":
            p = e.get("payload", {})
            rejections.append({
                "attempt": p.get("attempt"),
                "reason_class": p.get("reason_class", ""),
                "reason": p.get("reason", ""),
                "response_chars": p.get("response_chars", 0),
            })
    accepts = [e for e in events if e.get("type") == "prediction_accepted"]
    heartbeats = [e for e in events if e.get("type") == "prediction.heartbeat"]
    last_ts = max((e.get("utc_ts", "") for e in events), default="")
    return {
        "types": dict(types),
        "model_calls": model_calls,
        "rejections": rejections,
        "accepts": accepts,
        "heartbeats": heartbeats,
        "last_ts": last_ts,
    }


def print_compact(run_dir: Path, s: dict, elapsed: float, timeout: float, since_last: dict):
    ts_now = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
    elapsed_str = _fmt_dur(elapsed)
    remain_str = _fmt_dur(timeout - elapsed)
    total_calls = len(s["model_calls"])
    rej = len(s["rejections"])
    acc = len(s["accepts"])

    print()
    print("┌─" + "─" * 70 + "─┐")
    print(f"│ {ts_now}  CACTUS LIVE MONITOR  ·  {run_dir.name[-12:]}".ljust(72) + "│")
    print("├─" + "─" * 70 + "─┤")

    # Progress bar
    ratio = min(1.0, elapsed / timeout) if timeout > 0 else 0
    bar = _bar(ratio, width=40)
    print(f"│ ⏱  {elapsed_str}/{_fmt_dur(timeout)}  [{bar}] {100*ratio:.0f}%  remain={remain_str}".ljust(72) + "│")

    # Counts
    new_ev = since_last.get("events", 0)
    new_mc = since_last.get("model_calls", 0)
    new_rj = since_last.get("rejections", 0)
    delta_str = f"  Δ +{new_ev} ev, +{new_mc} mc, +{new_rj} rj" if (new_ev or new_mc or new_rj) else ""
    print(f"│ 📊 events={sum(s['types'].values())}  model_calls={total_calls}  rejects={rej}  accepts={acc}{delta_str}".ljust(72) + "│")

    # Latest model call
    if s["model_calls"]:
        last_mc = s["model_calls"][-1]
        fr = last_mc["finish_reason"] or "?"
        in_t = _human_tokens(last_mc.get("input_tokens"))
        out_t = _human_tokens(last_mc.get("output_tokens"))
        max_t = last_mc.get("max_tokens") or 0
        use_ratio = (last_mc.get("output_tokens") or 0) / max_t if max_t else 0
        bar2 = _bar(use_ratio, width=20)
        print(f"│ 🤖 last_model_call: finish={fr:<7} in={in_t:>7} out={out_t:>7} [{bar2}] {100*use_ratio:.0f}%".ljust(72) + "│")

    # Rejections summary
    if s["rejections"]:
        r = s["rejections"][-1]
        rc = r["reason_class"][:25]
        reason_short = (r["reason"] or "")[:60]
        print(f"│ ✖  last_reject: [{rc}] {reason_short}".ljust(72) + "│")

    print("└─" + "─" * 70 + "─┘")


def print_event_stream(events: list[dict], last_n: int = 6):
    """Show last N events as a compact stream."""
    print()
    print("─" * 72)
    print(f"📜 Recent events (last {min(last_n, len(events))}):")
    for e in events[-last_n:]:
        ts = _fmt(e.get("utc_ts", ""))
        t = e.get("type") or e.get("event") or "?"
        p = e.get("payload", {})
        if t == "model_call":
            fr = p.get("finish_reason", "?")
            in_t = _human_tokens(p.get("input_tokens"))
            out_t = _human_tokens(p.get("output_tokens"))
            max_t = p.get("max_tokens", 0)
            ratio = (p.get("output_tokens") or 0) / max_t if max_t else 0
            print(f"  [{ts}] MODEL_CALL  finish={fr:<6}  in={in_t:>7}  out={out_t:>7}  ({100*ratio:.0f}% of max)")
            resp = p.get("response_text", "")
            if resp:
                preview = resp.replace("\n", " ")[:120]
                print(f"            ↳ response: {preview}{'...' if len(resp) > 120 else ''}")
        elif t == "prediction_rejected":
            rc = p.get("reason_class", "?")
            reason = (p.get("reason", "") or "")[:80]
            print(f"  [{ts}] REJECTED  reason_class={rc}  reason={reason}")
        elif t == "prediction_accepted":
            print(f"  [{ts}] ACCEPTED  attempt={p.get('attempt', '?')}")
        elif t == "context_summary":
            cs = p.get("selected_context_ratio", 0) or 0
            files = p.get("selected_file_count", "?")
            full = _human_tokens(p.get("full_context_tokens"))
            sel = _human_tokens(p.get("selected_context_tokens"))
            print(f"  [{ts}] CONTEXT_SUMMARY  full={full}  selected={sel} ({100*cs:.2f}%)  files={files}")
        elif t in ("prediction.start", "prediction.heartbeat"):
            elapsed = p.get("elapsed_sec", 0)
            print(f"  [{ts}] {t.upper().replace('.', '_')}  elapsed={elapsed:.0f}s")
        elif t.startswith("issue_") or t.startswith("literal_") or t.startswith("context_"):
            print(f"  [{ts}] {t}  ({len(json.dumps(p))}B payload)")
        else:
            print(f"  [{ts}] {t}")


def monitor_live(run_dir: Path, poll_sec: float = 5.0, stream: bool = False):
    trace_path = run_dir / "trace" / "events.jsonl"
    print(f"[monitor] RUN_DIR = {run_dir}")
    print(f"[monitor] TRACE   = {trace_path}")
    print(f"[monitor] POLL    = {poll_sec}s   mode={'stream' if stream else 'compact'}")
    print()

    last_event_count = 0
    last_mc_count = 0
    last_rj_count = 0
    last_print_count = 0
    t_start = time.time()

    while True:
        if not trace_path.exists():
            print(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] trace file not yet created, waiting...")
            time.sleep(poll_sec)
            continue

        events = load_events(trace_path)
        s = summarize(events)
        since_last = {
            "events": len(events) - last_event_count,
            "model_calls": len(s["model_calls"]) - last_mc_count,
            "rejections": len(s["rejections"]) - last_rj_count,
        }
        last_event_count = len(events)
        last_mc_count = len(s["model_calls"])
        last_rj_count = len(s["rejections"])

        # Determine timeout from heartbeat events or fallback
        timeout = 1500.0
        elapsed = 0.0
        if s["heartbeats"]:
            try:
                last_hb = s["heartbeats"][-1]["payload"]
                elapsed = float(last_hb.get("elapsed_sec", 0))
                timeout = float(last_hb.get("timeout_sec", timeout))
            except Exception:
                pass
        if elapsed == 0 and s["last_ts"]:
            try:
                ts = datetime.fromisoformat(s["last_ts"].replace("Z", "+00:00"))
                elapsed = (datetime.now(timezone.utc) - ts).total_seconds()
            except Exception:
                pass

        # Always print compact line
        if (since_last["events"] + since_last["model_calls"] + since_last["rejections"]) > 0 or last_print_count == 0:
            print_compact(run_dir, s, elapsed, timeout, since_last)
            if stream:
                print_event_stream(events, last_n=8)
            last_print_count += 1

        # Check if RUN finished
        manifest_path = run_dir / "run_manifest.json"
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                status = manifest.get("status")
                if status in ("completed", "failed", "sealed"):
                    print()
                    print(f"[monitor] RUN finished with status={status}")
                    print()
                    # Print final summary
                    print_compact(run_dir, s, elapsed, timeout, {"events": 0, "model_calls": 0, "rejections": 0})
                    print_event_stream(events, last_n=12)
                    return
            except Exception:
                pass

        time.sleep(poll_sec)


def main():
    import argparse
    ap = argparse.ArgumentParser(description="CACTUS task monitor v2 (rich live output)")
    ap.add_argument("run_dir", type=Path, help="Path to RUN directory")
    ap.add_argument("--poll", type=float, default=5.0, help="Poll interval in seconds (default: 5)")
    ap.add_argument("--once", action="store_true", help="Print once and exit")
    ap.add_argument("--stream", action="store_true", help="Always print event stream")
    args = ap.parse_args()

    run_dir = args.run_dir.resolve()
    if not run_dir.is_dir():
        print(f"ERROR: not a directory: {run_dir}", file=sys.stderr)
        sys.exit(1)

    if args.once:
        trace_path = run_dir / "trace" / "events.jsonl"
        events = load_events(trace_path)
        s = summarize(events)
        print_compact(run_dir, s, 0, 0, {"events": 0, "model_calls": 0, "rejections": 0})
        print_event_stream(events, last_n=12)
        return

    try:
        monitor_live(run_dir, poll_sec=args.poll, stream=args.stream)
    except KeyboardInterrupt:
        print("\n[monitor] Interrupted by user")


if __name__ == "__main__":
    main()
