"""Run R4 task predictions inside Docker container.

The Docker image already has:
  - Full git repo at /testbed/astropy (with all needed base commits)
  - LiteLLM accessible at 172.19.50.70:4000

Usage:
    & .\.venv\Scripts\python.exe scripts/_predict_in_docker.py
"""
from __future__ import annotations

import datetime as dt
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
VENV_PY = ROOT / ".venv" / "Scripts" / "python.exe"

# R4 tasks
R4_TASKS = [
    "astropy__astropy-12907",
    "astropy__astropy-13033",
    "astropy__astropy-13236",
]

# Docker images (each has matching base commit)
IMAGE_MAP = {
    "astropy__astropy-12907": "swebench/sweb.eval.x86_64.astropy_1776_astropy-12907:78f471b",
    "astropy__astropy-13033": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033:78f471b",
    "astropy__astropy-13236": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13236:78f471b",
}


def get_repo_worktree(task_id: str) -> str:
    """Return the repo path inside Docker for this task."""
    return "/testbed/astropy"


def run_prediction_in_docker(
    task_id: str,
    variant: str = "cactus_full",
    timeout_sec: int = 1200,
) -> dict:
    """Run prediction for a task inside its matching Docker container."""
    print(f"\n{'='*60}")
    print(f"  任务: {task_id} | variant: {variant}")
    print(f"{'='*60}")

    image = IMAGE_MAP.get(task_id)
    if not image:
        return {"status": "error", "reason": f"no image for {task_id}"}

    repo_root = get_repo_worktree(task_id)
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = ROOT / "experiments" / "runs" / f"_r4_docker_{task_id.replace('__', '_')}_{ts}"
    out_dir.mkdir(parents=True, exist_ok=True)
    output_file = out_dir / "prediction.jsonl"
    trace_file = out_dir / "trace.jsonl"

    # Project paths (mounted as volumes)
    project_root = "/project"
    scripts_dir = f"{project_root}/scripts"
    src_dir = f"{project_root}/src"
    config_dir = f"{project_root}/configs"
    task_manifest = f"{project_root}/json/cactus_tasks_inference_safe.jsonl"
    model_config = f"{config_dir}/models/litellm_local_nothink_v7.json"

    predict_script = f"{scripts_dir}/cactus_swebench_predict.py"

    # Environment variables
    env_vars = [
        "CACTUS_LITELLM_API_KEY=sk-dgx-local-2026",
        "CACTUS_LITELLM_BILLING_API_KEY=sk-fw8MS3ly9sLOd0nK75j-mA",
        "CACTUS_LITELLM_LOG_KEY_ALIAS=cactus-billing",
        "CACTUS_LITELLM_BILLING_KEY_ALIAS=cactus-billing",
        "CACTUS_LITELLM_BILLING_SSH_HOST=172.19.50.70",
        "CACTUS_LITELLM_BILLING_SSH_USER=winbot",
        "CACTUS_LITELLM_BILLING_SSH_PASSWORD=winbot",
    ]

    cmd = (
        f"cd /testbed/astropy && "
        f"{project_root}/.venv/Scripts/python.exe "
        f"{predict_script} "
        f"--tasks {task_manifest} "
        f"--task-id {task_id} "
        f"--repo-root {repo_root} "
        f"--model-config {model_config} "
        f"--trace {trace_file} "
        f"--output {output_file} "
        f"--budget 14000 "
        f"--request-timeout-sec {timeout_sec} "
        f"--variant {variant}"
    )

    docker_cmd = [
        "docker", "run",
        "--rm",
        "-v", f"{ROOT}:{project_root}:ro",
        "-v", f"{ROOT / '.venv'}:{project_root}/.venv:ro",
        "-e", "CACTUS_LITELLM_API_KEY=sk-dgx-local-2026",
        "-e", "CACTUS_LITELLM_BILLING_API_KEY=sk-fw8MS3ly9sLOd0nK75j-mA",
        "-e", "CACTUS_LITELLM_LOG_KEY_ALIAS=cactus-billing",
        "-e", "CACTUS_LITELLM_BILLING_KEY_ALIAS=cactus-billing",
        "-e", "CACTUS_LITELLM_BILLING_SSH_HOST=172.19.50.70",
        "-e", "CACTUS_LITELLM_BILLING_SSH_USER=winbot",
        "-e", "CACTUS_LITELLM_BILLING_SSH_PASSWORD=winbot",
        image,
        "bash", "-c", cmd,
    ]

    print(f"  Image: {image}")
    print(f"  Repo:  {repo_root}")
    print(f"  Output: {out_dir}")
    print(f"\n  开始预测... (timeout={timeout_sec}s)")

    stdout_file = out_dir / "predict.stdout.log"
    stderr_file = out_dir / "predict.stderr.log"

    started = time.monotonic()

    with open(stdout_file, "w", encoding="utf-8") as sout, \
         open(stderr_file, "w", encoding="utf-8") as serr:
        try:
            result = subprocess.run(
                docker_cmd,
                cwd=str(ROOT),
                stdout=sout,
                stderr=serr,
                timeout=timeout_sec + 300,
            )
        except subprocess.TimeoutExpired:
            elapsed = time.monotonic() - started
            return {
                "status": "timeout",
                "task_id": task_id,
                "variant": variant,
                "elapsed_sec": round(elapsed, 1),
                "reason": f"timeout after {timeout_sec}s",
                "output_dir": str(out_dir),
            }

    elapsed = time.monotonic() - started

    stderr_text = stderr_file.read_text(encoding="utf-8", errors="replace") if stderr_file.exists() else ""
    stdout_text = stdout_file.read_text(encoding="utf-8", errors="replace") if stdout_file.exists() else ""

    # Analyze
    if "_check_required_columns" in stderr_text and "not found" in stderr_text:
        status = "fail_context"
        reason = "symbol not in context (fix not working)"
    elif "old_statement must exactly match" in stderr_text:
        status = "fail_context"
        reason = "old_statement mismatch"
    elif "RuntimeError: prediction generation exhausted" in stderr_text:
        status = "fail_model"
        reason = "prediction exhausted"
    elif result.returncode == 0:
        status = "success"
        reason = "prediction generated successfully"
    else:
        status = "error"
        reason = stderr_text[-200:] if stderr_text else f"exit {result.returncode}"

    emoji = {"success": "OK", "fail_context": "CTX", "fail_model": "MOD", "error": "ERR", "timeout": "TMO"}.get(status, "?")
    print(f"\n  结果: {emoji} {status} | {reason} | {elapsed:.0f}s")

    return {
        "status": status,
        "task_id": task_id,
        "variant": variant,
        "reason": reason,
        "elapsed_sec": round(elapsed, 1),
        "returncode": result.returncode,
        "output_dir": str(out_dir),
        "stdout_lines": len(stdout_text.split("\n")) if stdout_text else 0,
        "stderr_lines": len(stderr_text.split("\n")) if stderr_text else 0,
    }


def main():
    print("=" * 70)
    print("R4 Docker 内预测")
    print("=" * 70)
    print(f"Time: {dt.datetime.now(dt.timezone.utc).isoformat()}")
    print(f"Tasks: {R4_TASKS}")

    results = []
    for i, task_id in enumerate(R4_TASKS):
        print(f"\n[{i+1}/{len(R4_TASKS)}] 开始任务 {task_id}")
        result = run_prediction_in_docker(task_id, timeout_sec=1200)
        results.append(result)

    print("\n" + "=" * 70)
    print("最终结果汇总")
    print("=" * 70)
    for r in results:
        emoji = {"success": "OK", "fail_context": "CTX", "fail_model": "MOD", "error": "ERR", "timeout": "TMO"}.get(r["status"], "?")
        print(f"  {emoji} {r['task_id']}: {r['status']} - {r['reason']} ({r.get('elapsed_sec', '?')}s)")

    success = sum(1 for r in results if r["status"] == "success")
    print(f"\n成功: {success}/{len(results)}")

    return 0 if success == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
