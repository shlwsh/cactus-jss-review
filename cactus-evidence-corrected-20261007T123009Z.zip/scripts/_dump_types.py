import json, sys
fn = sys.argv[1]
target_types = sys.argv[2].split(',')
with open(fn, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]
for e in events:
    t = e.get('type', '?')
    p = e.get('payload', {})
    if t in target_types:
        s = json.dumps(p, ensure_ascii=False, indent=2)
        if len(s) > 3000:
            s = s[:3000] + '\n...'
        seq = e.get('seq')
        print(f'=== seq={seq} {t} ===')
        print(s)
        print()
