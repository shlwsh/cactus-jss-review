"""Prepare versioned submission attachments; never invent author declarations.

Run with the artifact runtime containing python-docx. The research pipeline
does not depend on these document-generation packages.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def build(output: Path):
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor
    output = output.resolve(); output.relative_to(ROOT)
    if output.exists():
        raise FileExistsError('refusing to overwrite submission attachments')
    output.mkdir(parents=True)
    release = json.loads((ROOT / 'paper/review_release.json').read_text(encoding='utf-8'))
    version = release['paper_version']
    now = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    def document(title, paragraphs, filename, bullets=False):
        doc = Document()
        section = doc.sections[0]
        section.page_height, section.page_width = Cm(29.7), Cm(21)
        section.top_margin = section.bottom_margin = Cm(2.5)
        section.left_margin = section.right_margin = Cm(2.5)
        normal = doc.styles['Normal']; normal.font.name = 'Arial'; normal.font.size = Pt(11)
        normal.paragraph_format.space_after = Pt(10)
        title_style = doc.styles['Title']; title_style.font.name = 'Arial'
        title_style.font.size = Pt(18); title_style.font.color.rgb = RGBColor(0, 0, 0)
        for border in doc.styles.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
        doc.add_paragraph(title, 'Title')
        for text in paragraphs:
            doc.add_paragraph(text, 'List Bullet' if bullets else 'Normal')
        section.footer.paragraphs[0].text = f'CACTUS JSS v{version} | {now}'
        for border in doc.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
        doc.save(output / filename)
    highlights = [line.strip() for line in (ROOT/'paper/submission/highlights.txt').read_text().splitlines() if line.strip()]
    if not 3 <= len(highlights) <= 5 or any(len(line) > 85 for line in highlights):
        raise ValueError('invalid highlights length')
    document('CACTUS Highlights', highlights, 'CACTUS_JSS_highlights.docx', bullets=True)
    interest = (ROOT/'paper/submission/competing_interest_draft.txt').read_text(encoding='utf-8')
    document('CACTUS Competing Interest Declaration Draft', [paragraph for paragraph in interest.split('\n\n') if paragraph.strip()],
             'CACTUS_JSS_competing_interest_DRAFT.docx')
    for filename in ('highlights.txt', 'competing_interest_draft.txt', 'funding_draft.txt', 'credit_draft.txt',
                     'generative_ai_draft.txt', 'author_confirmation.template.json'):
        shutil.copyfile(ROOT/'paper/submission'/filename, output/filename)
    cover = (ROOT/'paper/submission/cover_letter.tex').read_text(encoding='utf-8')
    import re
    cover = re.sub(r'Version [\d.]+; prepared [\dT:Z-]+\.', f'Version {version}; prepared {now}.', cover)
    (output/'cover_letter.tex').write_text(cover, encoding='utf-8', newline='\n')
    readme = r'''\documentclass[11pt,a4paper]{article}
\usepackage[margin=2.4cm]{geometry}
\usepackage[T1]{fontenc}\usepackage{lmodern,microtype,xurl}
\usepackage[hidelinks]{hyperref}
\setlength{\parindent}{0pt}\setlength{\parskip}{0.65em}
\begin{document}
\section*{CACTUS JSS review artifact}
Version VERSION; prepared TIMESTAMP. This candidate preserves executable
publication inputs and an auditable record of what can be reproduced.
Its local validation does not establish original-archive re-admission,
independent artifact evaluation, or author approval for journal submission.
\subsection*{Reproducibility scope}
Paper regeneration recomputes values, tables, figures and manuscript text
from pinned projections and compares them with the packaged expected baseline.
Synthetic admission regression creates its own fixtures and exercises the
unmodified production core. Original observed RUN trees, source history,
independent authorizations, and billing identities are omitted. Full inference
and official evaluator replay require separately authorized infrastructure.
\subsection*{Shortest offline path}
Install the dependencies listed in environment/requirements-lock.txt in a new
Python virtual environment. Provide pdflatex, bibtex and Poppler on PATH.
From the extracted archive root execute
\begin{quote}\texttt{python scripts/reproduce\_review\_artifact.py all}\end{quote}
The command verifies package input checksums, production-core synthetic
tests, recorded-decision projections, the value ledger, generated TeX,
same-environment PNGs, and normalized manuscript text.
\subsection*{Study interpretation}
Recorded original-study cases retain 160 semantic rejections, 20 intact
admissions, and 40 separately reported near-valid admissions. Seed summaries
require complete per-seed operator coverage. These repeated copies are not
independent population samples. New synthetic fixtures do not replay the
observed archive or overwrite its latency measurements.
\subsection*{Version identifiers and access}
The concept DOI is \url{https://doi.org/10.5281/zenodo.23205936}.
The prior v1.39 version DOI is \url{https://doi.org/10.5281/zenodo.23207699}.
This v1.40 local candidate has no verified public release or version DOI yet.
The prior DOI does not identify it. Planned release:
\url{https://github.com/shlwsh/cactus-jss-review/releases/tag/cactus-jss-review-v1.40}.
\subsection*{Distribution and submission}
CACTUS-origin review material retains CC-BY-4.0 terms; third-party material
retains its own notices. Elsevier styles retain LPPL notices. Third-party
cited full-text PDFs are omitted. Postal affiliations, author contributions,
funding and competing interests require author confirmation. A final approval
record must bind the actual final manuscript SHA-256. The submission checklist
is a separate gate and never grants formal experiment authorization.
\end{document}
'''.replace('VERSION', version).replace('TIMESTAMP', now)
    (output/'artifact_README.tex').write_text(readme, encoding='utf-8', newline='\n')
    for name in ('cover_letter', 'artifact_README'):
        for iteration in range(2):
            result = subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error', name+'.tex'],
                                    cwd=output, capture_output=True, timeout=120)
            (output/f'{name}_{iteration}.log').write_bytes(result.stdout+result.stderr)
            if result.returncode:
                raise ValueError(name+' compilation failed')
    shutil.copyfile(output/'cover_letter.pdf', output/'CACTUS_JSS_cover_letter_DRAFT.pdf')
    shutil.copyfile(output/'artifact_README.pdf', output/'CACTUS_JSS_artifact_README.pdf')
    manifest = {'generated_at': now, 'version': version, 'role': 'submission attachment candidate',
                'submission_ready': False, 'author_approval': 'not asserted', 'highlight_lengths': list(map(len,highlights)),
                'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(output.iterdir())
                           if p.suffix in {'.pdf','.docx','.txt','.tex','.json'}}}
    (output/'attachment_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'directory':str(output),'version':version,'submission_ready':False,'highlight_lengths':list(map(len,highlights))}))
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    build(parser.parse_args().output)
