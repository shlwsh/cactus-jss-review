"""Build an unapproved 50-task contract candidate from observed evidence."""

from __future__ import annotations

import copy
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PLAN = ROOT / "artifacts" / "phase_c_pilot50_plan.json"
DEFAULT_OBSERVATION = ROOT / "artifacts" / "pilot50_image_digest_observation.json"
DEFAULT_SOURCE_CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-PILOT-V2.json"
DEFAULT_OUTPUT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-PILOT50-CANDIDATE.json"
_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _read(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON input must be an object: {path}")
    return value


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _head() -> str:
    result = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=False)
    if result.returncode or not re.fullmatch(r"[0-9a-f]{40}", result.stdout.strip()):
        raise RuntimeError("cannot resolve a full current git HEAD")
    return result.stdout.strip()


def prepare(
    plan_path: Path = DEFAULT_PLAN,
    observation_path: Path = DEFAULT_OBSERVATION,
    source_contract_path: Path = DEFAULT_SOURCE_CONTRACT,
    output: Path = DEFAULT_OUTPUT,
) -> dict[str, Any]:
    plan_bytes = plan_path.read_bytes()
    plan = _read(plan_path)
    observation = _read(observation_path)
    planned = plan.get("evaluator_images") if isinstance(plan.get("evaluator_images"), list) else []
    observed = observation.get("images") if isinstance(observation.get("images"), list) else []
    observed_by_ref = {str(item.get("image_ref")): item for item in observed if isinstance(item, dict)}
    missing: list[str] = []
    image_catalog: dict[str, dict[str, Any]] = {}
    for index, item in enumerate(planned, 1):
        image_ref = str(item.get("image", "")) if isinstance(item, dict) else ""
        record = observed_by_ref.get(image_ref, {})
        digest = record.get("candidate_digest")
        if not isinstance(digest, str) or not _IMAGE_DIGEST.fullmatch(digest):
            missing.append(image_ref or f"image-{index:03d}")
            continue
        repository = image_ref.rsplit(":", 1)[0] if ":" in image_ref.rsplit("/", 1)[-1] else image_ref
        image_catalog[f"eval_{index:03d}"] = {
            "repository": repository,
            "tag": digest.replace(":", "-"),
            "digest": digest,
            "status": "OBSERVED_PENDING_REVIEW",
            "source_image_ref": image_ref,
        }

    task_ids = plan.get("task_ids") if isinstance(plan.get("task_ids"), list) else []
    blockers: list[str] = []
    if int(plan.get("task_count", 0) or 0) != 50 or len(task_ids) != 50:
        blockers.append("Pilot plan must contain exactly 50 task IDs")
    if len(planned) != 50 or missing:
        blockers.append(f"complete evaluator image digests are missing for {len(missing)} of {len(planned)} images")
    if blockers:
        result = {
            "schema_version": "1.0",
            "generated_at": _utc_now(),
            "status": "BLOCKED",
            "source_plan": plan_path.as_posix(),
            "source_plan_sha256": hashlib.sha256(plan_bytes).hexdigest(),
            "missing_images": missing,
            "candidate_written": False,
            "approval_marker_created": False,
            "execution_performed": False,
            "blockers": blockers,
        }
        return result

    candidate = copy.deepcopy(_read(source_contract_path))
    candidate["experiment_id"] = "EXP-CACTUS-PILOT50-V1"
    candidate["study_id"] = "MSCC-PILOT50"
    candidate["purpose"] = "exploratory"
    source = candidate.setdefault("source", {})
    source["git_commit"] = _head()
    source["require_clean_tree"] = True
    workload = candidate.setdefault("workload", {})
    workload["task_manifest"] = {
        "path": plan.get("selected_manifest"),
        "sha256": plan.get("selected_manifest_sha256"),
        "source_attestation": "data/manifests/swebench_verified_78f471b_source.json",
        "augmentation": "planning-only selected manifest strips patch and test_patch; evaluator metadata remains for the harness.",
    }
    workload["note"] = "50-task Pilot candidate; no formal execution has occurred."
    execution = candidate.setdefault("execution", {})
    execution["task_count"] = 50
    execution["pilot_tasks"] = task_ids
    execution["total_token_budget"] = execution.get("total_token_budget", 600000)
    candidate["images"] = image_catalog
    metadata = candidate.setdefault("_metadata", {})
    metadata.update(
        {
            "candidate_status": "pending_owner_review",
            "candidate_generated_at": _utc_now(),
            "candidate_source_plan_sha256": hashlib.sha256(plan_bytes).hexdigest(),
            "candidate_note": "Unapproved 50-task contract candidate. Requires explicit session confirmation, budget review, and clean-tree preflight.",
            "approval_marker_created": False,
            "execution_performed": False,
        }
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(candidate, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return {
        "schema_version": "1.0",
        "generated_at": metadata["candidate_generated_at"],
        "status": "READY_FOR_OWNER_REVIEW",
        "candidate_path": output.as_posix(),
        "candidate_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "task_count": 50,
        "image_count": len(image_catalog),
        "candidate_written": True,
        "approval_marker_created": False,
        "execution_performed": False,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--observation", type=Path, default=DEFAULT_OBSERVATION)
    parser.add_argument("--source-contract", type=Path, default=DEFAULT_SOURCE_CONTRACT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    result = prepare(args.plan, args.observation, args.source_contract, args.output)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["status"] == "READY_FOR_OWNER_REVIEW" else 2


if __name__ == "__main__":
    raise SystemExit(main())
