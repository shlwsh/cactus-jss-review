"""Monitor POSTFIX3 progress, one tick."""
import json, sys, os
from pathlib import Path

run_id = os.environ.get('RUN_ID', 'FACO-FULL-LITE50-POSTFIX3-20261003T222550Z')
base = Path(f'experiments/runs/{run_id}')
if not base.exists():
    print(f'run dir not found: {base}')
    sys.exit(1)

print(f"{'TASK':<32} {'STATUS':<6} {'ATT':<4} {'LAST_EVENT':<22}")
print('-' * 72)
n_pass = n_fail = n_pend = 0
for task_dir in sorted(base.iterdir()):
    if not task_dir.is_dir(): continue
    pred = task_dir / 'prediction.jsonl'
    plog = task_dir / 'predict.log'
    evs  = task_dir / 'events.jsonl'
    status = 'PEND'; tail = '-'
    if plog.exists():
        t = plog.read_text(encoding='utf-8', errors='ignore').strip()
        if t.startswith('FAIL'): status = 'FAIL'; n_fail += 1
        elif 'PRED:' in t or pred.exists(): status = 'PASS'; n_pass += 1
        else: status = 'RUN'; n_pend += 1
        lines = t.splitlines()
        tail = lines[-1][:22] if lines else '-'
    elif pred.exists() and pred.stat().st_size > 0:
        status = 'PASS'; n_pass += 1
    else:
        n_pend += 1
    att = 0; last_ts = '-'
    if evs.exists():
        for l in evs.read_text(encoding='utf-8', errors='ignore').splitlines()[-30:]:
            try:
                e = json.loads(l)
                if e.get('type') == 'PREDICTION_RESULT': att += 1
                if 'ts' in e: last_ts = e['ts'][:19]
            except Exception: pass
    print(f'{task_dir.name:<32} {status:<6} {att:<4} {last_ts:<22} {tail}')
print('-' * 72)
print(f'SUMMARY: PASS={n_pass}  FAIL={n_fail}  PEND={n_pend}')