"""Find the exact 'one complete Python statement' message."""
import re
src = open('scripts/cactus_swebench_predict.py', encoding='utf-8').read()
for m in re.finditer(r'exactly one complete Python statement', src):
    start = max(0, m.start() - 200)
    end = min(len(src), m.end() + 200)
    print('---')
    print(src[start:end+3])
    print('---')