#!/usr/bin/env python3
"""Update all provenance sidecars with new SHA values after bib/manifest update."""
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path

root = Path(r'e:\work\p5-acm\acm')

pub_src = root / 'paper/publication_sources.json'
pv = root / 'paper/data/publication_values.json'
manifest = root / 'paper/data/scholar/cited_papers_manifest.json'

pub_src_sha = hashlib.sha256(pub_src.read_bytes()).hexdigest()
pv_sha = hashlib.sha256(pv.read_bytes()).hexdigest()
manifest_sha = hashlib.sha256(manifest.read_bytes()).hexdigest()

vals = {
    'paper/data/publication_values.json': pv_sha,
    'paper/publication_sources.json': pub_src_sha,
    'paper/data/scholar/cited_papers_manifest.json': manifest_sha,
}

now = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')

updated = []
for sc_path in (root / 'paper/generated/values').glob('*.provenance.json'):
    sc = json.loads(sc_path.read_text(encoding='utf-8'))
    changed = False
    for inp in sc.get('inputs', []):
        if inp['path'] in vals:
            old = inp['sha256']
            inp['sha256'] = vals[inp['path']]
            changed = True
    if changed:
        sc['generated_at'] = now
        sc_path.write_text(json.dumps(sc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        updated.append(sc_path.name)
        print(f'Updated: {sc_path.name}')

print(f'\nTotal updated: {len(updated)}')
print('SHA values:')
print(f'  publication_sources.json: {pub_src_sha[:16]}')
print(f'  publication_values.json: {pv_sha[:16]}')
print(f'  cited_papers_manifest.json: {manifest_sha[:16]}')
