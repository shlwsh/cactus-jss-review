"""Dump trace events summary to a readable JSON."""
import json
import sys
from pathlib import Path

trace_path = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260926T120619Z-4BAA1DC9\trace\events.jsonl")
out_path = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260926T120619Z-4BAA1DC9\trace\_events_summary.json")

events = []
with trace_path.open("r", encoding="utf-8-sig") as f:
    for ln in f:
        ln = ln.strip()
        if not ln:
            continue
        try:
            events.append(json.loads(ln))
        except Exception as exc:
            print(f"parse error: {exc}", file=sys.stderr)

summary = []
for i, e in enumerate(events):
    summary.append({
        "i": i,
        "type": e.get("type"),
        "seq": e.get("seq"),
        "ts": e.get("utc_ts"),
    })

out_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"events total: {len(events)}")
print(f"summary saved to: {out_path}")
