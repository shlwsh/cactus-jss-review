"""Quick status check for the R4 v8 single-task launch."""
import json
import time
from pathlib import Path

p = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260925T222323Z-C4330524\trace\events.jsonl")
events = [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
print(f"total events: {len(events)}")
print(f"last utc_ts: {events[-1].get('utc_ts')}")
print(f"last type: {events[-1].get('type')}")
mcs = [e for e in events if e.get("type") == "model_call"]
print(f"model_call events: {len(mcs)}")
mtime = p.stat().st_mtime
print(f"file mtime: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(mtime))}")
print(f"now:        {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}")
print(f"age_sec: {time.time() - mtime:.1f}")

sp = Path(r"E:\work\p5-acm\acm\experiments\runs\RUN-20260925T222323Z-C4330524\logs\predict.stderr.log")
print(f"\npredict.stderr.log exists: {sp.exists()}")
if sp.exists():
    print(f"size: {sp.stat().st_size}")
    content = sp.read_text(encoding="utf-8")
    print(f"content tail:\n{content[-500:]}")
else:
    print("stderr file not created yet")
