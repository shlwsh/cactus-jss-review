"""Ad-hoc verification driver: run the official SWE-bench harness against an
already-written CACTUS prediction, without re-running the entire campaign.

Scope (current 2026-09-26 incident):
- RUN-20260925T224201Z-7EDB41FB predict step PASSED with valid JSON
- Campaign launcher was killed at the 600s wall-clock deadline before the
  evaluation phase ever started, so the bundle is missing:
    * evaluation/
    * logs/evaluate.stdout.log
    * logs/evaluate.stderr.log
    * run_manifest.json (bundle unsealed)
- This driver manually invokes swebench_eval_lf.py (the LF-aware wrapper used
  by run_task) with the same argv the campaign would have used, then mirrors
  stdout/stderr into the bundle so the evidence matches what the official
  runner would have recorded.

Usage:
  & E:\\work\\p5-acm\\acm\\.venv\\Scripts\\python.exe -u scripts\\_verify_eval_step.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
RUN_ID = "RUN-20260925T224201Z-7EDB41FB"
TASK_ID = "astropy__astropy-12907"
INSTANCE = TASK_ID
DATASET = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
PREDICTION = ROOT / "experiments" / "runs" / RUN_ID / "raw" / "prediction.jsonl"
RUN_ROOT = ROOT / "experiments" / "runs" / RUN_ID
REPORT_DIR = RUN_ROOT / "evaluation"
LOGS_DIR = RUN_ROOT / "logs"
PINNED_IMAGE = "swebench/sweb.eval.x86_64.astropy_1776_astropy-12907@sha256:e082963099ed7d5a5f75a0be46e338be36faae33b2cba5289a9ddbd505997f1f"
TIMEOUT_SEC = 1800  # matches contract.execution.task_timeout_sec

ENV_FILE = ROOT / "docs" / "llm" / ".env"
LITELLM_KEY_TAGS = ("LITELLM", "API_KEY", "CACTUS")


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_env_into(target: dict[str, str]) -> int:
    if not ENV_FILE.exists():
        return 0
    injected = 0
    for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if any(tag in k.upper() for tag in LITELLM_KEY_TAGS):
            target[k] = v.strip()
            injected += 1
    return injected


def main() -> int:
    if not PREDICTION.is_file():
        print(f"[eval-driver] FAIL: prediction file missing: {PREDICTION}", flush=True)
        return 2
    if not DATASET.is_file():
        print(f"[eval-driver] FAIL: dataset file missing: {DATASET}", flush=True)
        return 2

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    argv = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"),
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(PREDICTION),
        "--instance", INSTANCE,
        "--pinned-image", PINNED_IMAGE,
        "--run-id", RUN_ID,
        "--workers", "1",
        "--timeout", str(TIMEOUT_SEC),
        "--report-dir", str(REPORT_DIR),
    ]
    print(f"[eval-driver] {utc_now()} cmd:\n  {' '.join(argv)}", flush=True)

    env = os.environ.copy()
    n = load_env_into(env)
    print(f"[eval-driver] injected {n} session vars from {ENV_FILE}", flush=True)

    t0 = time.monotonic()
    started_at = utc_now()
    proc = subprocess.run(
        argv,
        cwd=str(ROOT),
        env=env,
        capture_output=True,
        text=True,
        timeout=TIMEOUT_SEC + 120,
        check=False,
    )
    elapsed = time.monotonic() - t0
    finished_at = utc_now()
    print(f"[eval-driver] {finished_at} rc={proc.returncode} elapsed={elapsed:.1f}s stdout={len(proc.stdout)}B stderr={len(proc.stderr)}B", flush=True)

    stdout_log = LOGS_DIR / "evaluate.stdout.log"
    stderr_log = LOGS_DIR / "evaluate.stderr.log"
    stdout_log.write_text(proc.stdout, encoding="utf-8", newline="\n")
    stderr_log.write_text(proc.stderr, encoding="utf-8", newline="\n")

    meta = {
        "schema_version": "2.0",
        "run_id": RUN_ID,
        "task_id": TASK_ID,
        "phase": "evaluation",
        "started_at": started_at,
        "finished_at": finished_at,
        "elapsed_sec": round(elapsed, 1),
        "exit_code": proc.returncode,
        "pinned_image": PINNED_IMAGE,
        "dataset": str(DATASET),
        "prediction": str(PREDICTION),
        "report_dir": str(REPORT_DIR),
        "timeout_sec": TIMEOUT_SEC,
    }
    (LOGS_DIR / "evaluate_command.json").write_text(
        json.dumps(meta, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(f"[eval-driver] wrote {stdout_log.name}, {stderr_log.name}, evaluate_command.json", flush=True)

    reports = sorted(REPORT_DIR.glob(f"*.{RUN_ID}.json"))
    if reports:
        print(f"[eval-driver] evaluation report(s): {[r.name for r in reports]}", flush=True)
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            resolved_ids = rep.get("resolved_ids") or []
            print(f"[eval-driver] resolved_instances={rep.get('resolved_instances')} resolved_ids={resolved_ids}", flush=True)
        except Exception as exc:
            print(f"[eval-driver] WARN: could not parse report: {exc}", flush=True)
    else:
        print(f"[eval-driver] no *.{RUN_ID}.json report produced in {REPORT_DIR}", flush=True)
    return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
