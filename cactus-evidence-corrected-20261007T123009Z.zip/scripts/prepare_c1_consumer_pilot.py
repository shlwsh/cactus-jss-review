"""Freeze a fresh, one-task Matplotlib engineering contract from FIX8.

Run only from a clean committed CACTUS tree. The historical FIX8 contract and
RUN remain untouched. No secret is read or persisted by this preparation step.
"""

from __future__ import annotations

import copy
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from cactus.governance.canonical import canonical_json


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "experiments/contracts/EXP-CACTUS-C1-PILOT-MPL-FIX8-20260927T215813Z.json"
CONFIG = ROOT / "configs/models/litellm_local_c1_consumer_v1.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def sidecar(path: Path) -> None:
    path.with_name(path.name + ".sha256").write_text(f"{sha(path)}  {path.name}\n", encoding="utf-8", newline="\n")


def main() -> int:
    git = lambda *args: subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()
    if git("status", "--porcelain"):
        raise RuntimeError("commit code and start from a clean tree before freezing the pilot")
    source_commit = git("rev-parse", "HEAD")
    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    utc = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    contract_id = f"EXP-CACTUS-C1-PILOT-MPL-CONSUMER-{stamp}"
    old = json.loads(BASE.read_text(encoding="utf-8"))
    config = json.loads(CONFIG.read_text(encoding="utf-8"))
    contract = copy.deepcopy(old)
    image = contract["images"]["eval_001"]
    image_ref = f"{image['repository']}:{image['tag']}"
    observed_id = subprocess.check_output(
        ["docker", "image", "inspect", image_ref, "--format", "{{json .Id}}"],
        text=True, timeout=30,
    ).strip()
    if json.loads(observed_id) != image["local_image_id"]:
        raise RuntimeError("local Docker image ID differs from the frozen contract")
    snapshot_path = ROOT / "experiments/snapshots" / f"C1-MPL-consumer-pre-{stamp}_observed.json"
    baseline = json.loads((ROOT / contract["execution"]["environment_snapshot_path"]).read_text(encoding="utf-8"))
    snapshot = copy.deepcopy(baseline)
    snapshot["generated_at"] = utc
    snapshot["platform"] = platform.platform()
    snapshot["processor"] = platform.processor()
    snapshot["python"] = platform.python_version()
    snapshot["extra"].update({"capture_scope": "current host, fixed task inputs, and exact local evaluator image ID",
                              "evaluator_image_ref": image_ref, "evaluator_local_image_id": image["local_image_id"],
                              "archive_sha256_status": "prior_attestation_not_rehashed"})
    write_json(snapshot_path, snapshot)
    sidecar(snapshot_path)
    contract_path = ROOT / "experiments/contracts" / f"{contract_id}.json"
    authorization_path = contract_path.with_name(f"{contract_id}.session_authorization.json")
    contract["experiment_id"] = contract_id
    contract["_metadata"].update({"generated_at": utc, "candidate_generated_at": utc,
                                   "candidate_approved_at": utc,
                                   "candidate_scope": "one_task_consumer_chain_engineering_validation",
                                   "owner_confirmation_status": "confirmed_in_current_session",
                                   "note": "One Matplotlib task; current consumer-chain algorithm; engineering validation only.",
                                   "candidate_note": "One frozen Matplotlib task, one RUN, USD 2 ceiling, cactus_full only."})
    contract["source"]["git_commit"] = source_commit
    contract["source"]["note"] = "Current C1 consumer-chain algorithm; non-publishable one-task engineering validation."
    contract["execution"].update({"total_token_budget": 120000, "predict_timeout_sec": 2400,
                                  "environment_snapshot_path": snapshot_path.relative_to(ROOT).as_posix(),
                                  "environment_snapshot_sha256": sha(snapshot_path)})
    contract["execution"]["metadata_paths"] = [
        f"acm/{CONFIG.relative_to(ROOT).as_posix()}",
        f"acm/{contract_path.relative_to(ROOT).as_posix()}",
        f"acm/{contract_path.relative_to(ROOT).as_posix()}.sha256",
        f"acm/{authorization_path.relative_to(ROOT).as_posix()}",
        f"acm/{snapshot_path.relative_to(ROOT).as_posix()}",
        f"acm/{snapshot_path.relative_to(ROOT).as_posix()}.sha256",
    ]
    contract["workload"]["sha256"] = sha(ROOT / contract["workload"]["driver"])
    contract["model"].update({"config": CONFIG.relative_to(ROOT).as_posix(),
                              "max_output_tokens": config["max_output_tokens"],
                              "prediction_max_attempts": config["prediction_max_attempts"],
                              "prediction_retry_strategy": config["prediction_retry_strategy"],
                              "model_version": config["model_version"],
                              "thinking": config["thinking"],
                              "reasoning_effort": config["reasoning_effort"]})
    write_json(contract_path, contract)
    sidecar(contract_path)
    authorization = {
        "schema_version": "1.0", "authorization_type": "session_confirmation", "status": "approved",
        "experiment_id": contract_id, "approved_by": "project_owner", "approved_at": utc,
        "confirmation_quote": "根据acm\\docs\\codex\\v1.0_20260928-065500_C1算法根因改进技术实现方案.md予以开发，修正算法，实现单任务验证通过；",
        "scope": f"{contract_id}: one Matplotlib task, one cactus_full RUN, USD 2 ceiling, engineering validation only.",
        "contract_sha256": hashlib.sha256(canonical_json(contract).encode("utf-8")).hexdigest(),
    }
    write_json(authorization_path, authorization)
    print(json.dumps({"experiment_id": contract_id, "contract": str(contract_path),
                      "authorization": str(authorization_path), "source_commit": source_commit,
                      "snapshot_sha256": sha(snapshot_path)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
