"""Verify think config and all R4 launch dependencies."""
import json
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")

cfg = json.loads((ROOT / "configs/models/litellm_local_think.json").read_text(encoding="utf-8"))
print("=== Think config ===")
print(f"  thinking: {cfg.get('thinking')}")
print(f"  max_output_tokens: {cfg.get('max_output_tokens')}")
print(f"  reasoning_effort: {cfg.get('reasoning_effort')}")
print(f"  price_version: {cfg.get('price_version')}")
print(f"  deployment_name: {cfg.get('deployment_name')}")

print("\n=== Required artifacts ===")
paths = [
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json",
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json",
    "experiments/plans/C1_primary_pairs_20260925_R4.json",
    "json/cactus_tasks_inference_safe.jsonl",
]
for p in paths:
    pp = ROOT / p
    status = "OK" if pp.exists() else "MISSING"
    print(f"  {p}: {status}")

ds = Path(r"E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
print(f"  dataset: {'OK' if ds.exists() else 'MISSING'} ({ds})")
env = ROOT / "docs/llm/.env"
print(f"  .env: {'OK' if env.exists() else 'MISSING'}")

print("\n=== Authorization status ===")
auth = json.loads((ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json").read_text(encoding="utf-8"))
print(f"  status: {auth.get('status')}")
print(f"  approved_by: {auth.get('approved_by')}")
print(f"  approved_at: {auth.get('approved_at')}")
print(f"  scope: {auth.get('scope', '')[:100]}...")
