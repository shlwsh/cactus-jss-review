"""Construct a fail-closed paper-supporting contract for the frozen Lite-50."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

TASK_COUNT = 50
FORBIDDEN = {"patch", "test_patch", "gold_patch", "ground_truth_patch"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def read_tasks(path: Path) -> list[dict[str, Any]]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    ids = [row.get("task_id") for row in rows if isinstance(row, dict)]
    if len(rows) != TASK_COUNT or len(ids) != TASK_COUNT or len(set(ids)) != TASK_COUNT or not all(isinstance(x, str) and x for x in ids):
        raise ValueError("Lite-50 manifest must contain exactly 50 unique task IDs")
    if ids != sorted(ids):
        raise ValueError("Lite-50 manifest task IDs must be lexicographically sorted")
    if any(FORBIDDEN & row.keys() for row in rows):
        raise ValueError("Lite-50 inference manifest contains forbidden gold fields")
    return rows


def build(*, output: Path, source_commit: str, manifest: Path, source_attestation: Path, image_observation: Path, environment: Path, model_config: Path, price_card: Path, evaluator_dataset: str, image_archive_manifest: Path | None = None, image_cache_root: str | None = None, scratch_root: str | None = None, algorithm_revision: str | None = None, total_token_budget: int | None = None) -> dict[str, Any]:
    if output.exists() or output.with_suffix(output.suffix + ".sha256").exists():
        raise FileExistsError(f"refusing to overwrite contract candidate: {output}")
    if len(source_commit) != 40 or any(c not in "0123456789abcdef" for c in source_commit):
        raise ValueError("source commit must be a 40-character lowercase SHA-1")
    rows = read_tasks(manifest)
    attestation, observation, env, model = map(load_json, (source_attestation, image_observation, environment, model_config))
    evaluator_sha = attestation.get("sha256")
    if attestation.get("benchmark") != "SWE-bench" or attestation.get("task_count") != 300 or not isinstance(evaluator_sha, str) or len(evaluator_sha) != 64:
        raise ValueError("source attestation does not bind SWE-bench Lite test-300 with a full hash")
    observed = observation.get("images")
    if observation.get("status") != "READY_FOR_CONTRACT_CANDIDATE" or not isinstance(observed, list) or len(observed) != TASK_COUNT:
        raise ValueError("image observation is not a complete Lite-50 candidate")
    by_task = {record.get("task_id"): record for record in observed if isinstance(record, dict)}
    if set(by_task) != {row["task_id"] for row in rows}:
        raise ValueError("image observation task set does not exactly match Lite-50 manifest")
    images: dict[str, dict[str, str]] = {}
    for index, row in enumerate(rows, 1):
        record = by_task[row["task_id"]]; repository, digest = record.get("repository"), record.get("digest")
        if not isinstance(repository, str) or not isinstance(digest, str) or not digest.startswith("sha256:") or len(digest) != 71:
            raise ValueError(f"image observation lacks immutable digest for {row['task_id']}")
        images[f"eval_{index:03d}"] = {"repository": repository, "tag": "sha256-" + digest[7:19], "digest": digest, "status": "OBSERVED_NOT_YET_LOCAL_VERIFIED"}
    archive_binding: dict[str, dict[str, Any]] = {}
    if image_archive_manifest is not None:
        archive_data = load_json(image_archive_manifest)
        if archive_data.get("status") != "READY_FOR_CONTRACT_BINDING" or archive_data.get("image_count") != TASK_COUNT:
            raise ValueError("image archive manifest is not a complete Lite-50 binding")
        for row in archive_data.get("images", []):
            if not isinstance(row, dict) or not isinstance(row.get("eval_id"), str):
                raise ValueError("image archive manifest contains an invalid image row")
            archive_binding[row["eval_id"]] = row
        if set(archive_binding) != set(images):
            raise ValueError("image archive manifest task set does not exactly match Lite-50")
        for eval_id, row in archive_binding.items():
            target = images[eval_id]
            if row.get("repository") != target["repository"] or row.get("digest") != target["digest"]:
                raise ValueError(f"image archive manifest conflicts with frozen digest for {eval_id}")
            archive_path = row.get("archive_path")
            archive_sha = row.get("archive_sha256")
            archive_size = row.get("archive_size_bytes")
            local_id = row.get("local_image_id")
            if not isinstance(archive_path, str) or not isinstance(archive_sha, str) or not re.fullmatch(r"[0-9a-f]{64}", archive_sha) or not isinstance(archive_size, int) or archive_size <= 0 or not isinstance(local_id, str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", local_id):
                raise ValueError(f"image archive manifest has incomplete binding for {eval_id}")
            # This is the OCI manifest digest exposed by ``docker image
            # inspect .Id`` after loading the frozen archive.  Binding it in
            # both the contract and cache sidecar keeps the on-demand runtime
            # verification offline and fail-closed.
            target.update({
                "archive_path": archive_path,
                "archive_sha256": archive_sha,
                "archive_size_bytes": archive_size,
                "local_image_id": local_id,
            })
    if env.get("capture_mode") != "observed":
        raise ValueError("Lite-50 requires a fresh observed environment snapshot")
    if model.get("billing_required") is not True or model.get("usage_required") is not True or not price_card.is_file():
        raise ValueError("Lite-50 requires usage, billing, and a price card")
    if algorithm_revision is not None and algorithm_revision not in ("lite50_v2", "lite50_v3_dual_insurance"):
        raise ValueError("unsupported algorithm revision")
    if algorithm_revision in ("lite50_v2", "lite50_v3_dual_insurance"):
        if model.get("algorithm_revision") != algorithm_revision:
            raise ValueError(f"{algorithm_revision} requires a matching opt-in model configuration")
        if not isinstance(total_token_budget, int) or total_token_budget < 1:
            raise ValueError(f"{algorithm_revision} requires an explicitly supplied total token budget")
    root = output.resolve().parents[2]
    rel = lambda p: p.resolve().relative_to(root).as_posix()
    environment_sidecar = environment.with_suffix(environment.suffix + ".sha256")
    environment_line = f"{sha256(environment)}  {environment.name}\n"
    if environment_sidecar.exists() and environment_sidecar.read_text(encoding="utf-8") != environment_line:
        raise ValueError("existing environment snapshot SHA-256 sidecar does not match")
    if not environment_sidecar.exists():
        environment_sidecar.write_text(environment_line, encoding="utf-8", newline="\n")
    stamp = utc_now().replace("-", "").replace(":", "")
    exp_id = output.stem if output.stem.startswith("EXP-CACTUS-") else f"EXP-CACTUS-SWEBENCH-LITE50-{stamp}"
    bind_model = ("algorithm_revision", "provider", "model_id", "model_version", "max_output_tokens", "prediction_max_attempts", "prediction_retry_strategy", "prediction_output_mode", "thinking", "usage_required", "billing_required", "billing_source", "billing_endpoint", "billing_api_key_env", "billing_log_key_alias_env", "billing_scope", "billing_user_id", "reasoning_effort")
    contract: dict[str, Any] = {
        "schema_version": "2.0", "experiment_id": exp_id, "study_id": "MSCC-LITE50", "purpose": "paper_supporting", "source": {"git_commit": source_commit, "require_clean_tree": True},
        "agent": {"agent_id": "CACTUS-v0.1.0", "bridge": "scripts/cactus_swebench_predict.py", "evaluation_wrapper": "scripts/swebench_eval_lf.py"},
        "workload": {"driver": "scripts/cactus_swebench_predict.py", "sha256": sha256(root / "scripts/cactus_swebench_predict.py"), "warmup_sec": 0, "measure_sec": 30, "repetitions": 1, "seed": 20260928, "variant_matrix": ["cactus_full"], "task_manifest": {"path": rel(manifest), "sha256": sha256(manifest), "source_attestation": rel(source_attestation), "inference_safe": True}},
        "derivation": {"script": "scripts/aggregate_lite50_results.py", "sha256": sha256(root / "scripts/aggregate_lite50_results.py")}, "result_ids": [], "host_profile": "LOCAL-WIN11-AMD64", "images": images,
        "model": {k: model[k] for k in bind_model if k in model} | {"config": rel(model_config), "price_card_path": rel(price_card), "price_card_sha256": sha256(price_card), "billing_status": "FROZEN"},
        "execution": {"task_count": TASK_COUNT, "expected_run_count": TASK_COUNT, "concurrency": 1, "max_retries": 0, "agent_turn_budget_tokens": 12000, "total_token_budget": 600000, "task_timeout_sec": 1800, "budget_usd": 20.0, "cost_budget": {"amount": 20.0, "currency": "USD", "basis": "litellm_gateway_spend", "price_version": model.get("price_version"), "status": "PENDING_OWNER_REVIEW"}, "evaluator_dataset": evaluator_dataset, "evaluator_dataset_sha256": evaluator_sha, "environment_snapshot_path": rel(environment), "environment_snapshot_sha256": sha256(environment), "environment_snapshot_status": "OBSERVED", "metadata_paths": [rel(environment), rel(environment_sidecar), rel(output.with_suffix(output.suffix + ".sha256"))], "stop_on": ["provider_usage_missing", "provider_usage_mismatch", "cost_budget_exceeded", "token_budget_exceeded", "billing_evidence_missing", "evaluator_infrastructure_failure", "run_integrity_failure", "data_leakage_detected", "image_missing"]},
        "variants": ["cactus_full"], "tolerance_policy": "SWEBENCH-SUPPORTING-DESCRIPTIVE-V1", "publishable_result": True,
        "_metadata": {"candidate_status": "pending_owner_review", "candidate_generated_at": utc_now(), "candidate_scope": "Lite-50 deterministic subset", "candidate_expected_run_count": TASK_COUNT, "candidate_task_manifest_sha256": sha256(manifest), "candidate_evaluator_dataset_sha256": evaluator_sha, "candidate_image_observation_sha256": sha256(image_observation), "limitations": "Descriptive supporting evidence only for Lite-50; not generalizable to SWE-bench Verified-500 or overall repair efficacy."},
    }
    if image_cache_root:
        contract["execution"]["image_cache_root"] = image_cache_root
    if image_archive_manifest is not None:
        contract["execution"]["image_archive_manifest"] = {
            "path": rel(image_archive_manifest),
            "sha256": sha256(image_archive_manifest),
        }
        contract["execution"]["metadata_paths"].append(rel(image_archive_manifest))
    if scratch_root:
        contract["execution"]["scratch_root"] = scratch_root
    if algorithm_revision in ("lite50_v2", "lite50_v3_dual_insurance"):
        contract["execution"]["total_token_budget"] = total_token_budget
        contract["execution"]["token_architecture"] = {
            "per_task_soft_limit": 30000,
            "per_task_hard_limit": 60000,
            "per_call_min_reserve": 2000,
            "estimator_safety_factor": 1.1,
        }
        contract["execution"]["stop_on"].append("per_task_token_exceeded")
    output.parent.mkdir(parents=True, exist_ok=True); output.write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    digest = sha256(output); output.with_suffix(output.suffix + ".sha256").write_text(f"{digest}  {output.name}\n", encoding="utf-8", newline="\n")
    return {"experiment_id": contract["experiment_id"], "contract_sha256": digest, "task_count": TASK_COUNT, "image_count": len(images)}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("output", "manifest", "source-attestation", "image-observation", "environment", "model-config", "price-card"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--image-archive-manifest", type=Path)
    p.add_argument("--image-cache-root")
    p.add_argument("--scratch-root")
    p.add_argument("--algorithm-revision", choices=("lite50_v2", "lite50_v3_dual_insurance"))
    p.add_argument("--total-token-budget", type=int)
    p.add_argument("--source-commit", required=True); p.add_argument("--evaluator-dataset", required=True)
    a = p.parse_args(); print(json.dumps(build(output=a.output, source_commit=a.source_commit, manifest=a.manifest, source_attestation=a.source_attestation, image_observation=a.image_observation, environment=a.environment, model_config=a.model_config, price_card=a.price_card, evaluator_dataset=a.evaluator_dataset, image_archive_manifest=a.image_archive_manifest, image_cache_root=a.image_cache_root, scratch_root=a.scratch_root, algorithm_revision=a.algorithm_revision, total_token_budget=a.total_token_budget), ensure_ascii=False)); return 0


if __name__ == "__main__":
    raise SystemExit(main())
