"""Test LiteLLM gateway connectivity."""
import urllib.request
import ssl
import json

url = "http://172.19.9.104:4000/v1/models"
headers = {"Authorization": "Bearer sk-dgx-local-2026"}

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

try:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
        models = data.get("data", [])
        print(f"OK: {len(models)} models available")
        for m in models[:5]:
            print(f"  - {m.get('id', '?')}")
except Exception as e:
    print(f"FAIL: {type(e).__name__}: {e}")
    import traceback
    traceback.print_exc()
