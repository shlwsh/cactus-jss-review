"""Show recent trace events."""
import json
import sys
from pathlib import Path

trace = Path(sys.argv[1])
events = [json.loads(l) for l in trace.read_text(encoding="utf-8").splitlines() if l.strip()]
print(f"Total events: {len(events)}\n")
for e in events[-15:]:
    t = e.get("type")
    ts = e.get("utc_ts", "?")
    p = e.get("payload", {})
    print(f"[{ts}] {t}")
    if t == "model_call":
        max_t = p.get("max_tokens")
        in_t = p.get("input_tokens")
        out_t = p.get("output_tokens")
        fr = p.get("finish_reason")
        print(f"   max_tokens={max_t}, in={in_t}, out={out_t}, finish={fr}")
        resp = (p.get("response_text") or "")[:300]
        print(f"   response: {resp}")
    elif t == "prediction_rejected":
        print(f"   reason: {(p.get('reason') or '')[:200]}")
    elif t == "prediction_accepted":
        print(f"   attempt={p.get('attempt')}")
    elif t == "observe":
        msg = p.get("message", "")
        if msg:
            print(f"   msg: {msg[:200]}")
        else:
            task = p.get("task", "")
            if task:
                print(f"   task: {task[:150]}...")
    elif t in ("issue_symbol_anchors", "literal_source_anchors", "context_candidates_pruned",
               "literal_anchor_candidates", "context_selected", "context_summary"):
        print(f"   payload_keys: {list(p.keys())[:5]}")
    print()
