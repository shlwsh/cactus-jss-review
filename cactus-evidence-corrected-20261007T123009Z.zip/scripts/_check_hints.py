import re
src = open('scripts/cactus_swebench_predict.py', encoding='utf-8').read()
ids = re.findall(r'"id":\s*"([^"]+)"', src)
print('Hint IDs:')
for i in ids:
    print(' ', i)
