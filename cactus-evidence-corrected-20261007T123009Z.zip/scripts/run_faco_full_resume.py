"""Run FACO predictions for the 21 failed tasks under a fresh validation_id.

Each task gets its own invocation of run_single_task_predict.py with
PYTHONPATH set, CACTUS_LITELLM_API_KEY exported, and per-task timeouts.

Run in foreground from PowerShell so the user sees live progress.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"
DEFAULT_VALIDATION = "FACO-FULL-LITE50-RESUME-20261003T205831Z"

NO_PRED = [
    "astropy__astropy-12907",
    "astropy__astropy-14365",
    "django__django-10924",
    "django__django-11019",
    "django__django-11179",
    "django__django-11422",
    "django__django-11564",
    "django__django-11797",
    "django__django-11910",
    "django__django-11999",
    "django__django-12125",
    "django__django-12284",
    "django__django-12286",
    "django__django-12453",
    "django__django-12470",
    "django__django-12589",
    "django__django-12708",
    "django__django-12915",
    "django__django-13028",
    "django__django-13158",
    "django__django-13220",
]


def run_one(task_id: str, validation_id: str, variant: str, dry_run: bool) -> dict:
    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_single_task_predict.py"),
        "--task-id", task_id,
        "--validation-id", validation_id,
        "--variant", variant,
    ]
    started = datetime.utcnow().isoformat() + "Z"
    if dry_run:
        print("DRY-RUN:", " ".join(cmd))
        return {"task_id": task_id, "status": "dry", "cmd": cmd}
    try:
        proc = subprocess.run(cmd, cwd=str(PROJECT_ROOT), capture_output=True, text=True, timeout=900)
    except subprocess.TimeoutExpired:
        return {"task_id": task_id, "status": "timeout", "started_utc": started}
    pred_path = RUNS_DIR / validation_id / task_id / "prediction.jsonl"
    pred_bytes = pred_path.stat().st_size if pred_path.exists() else 0
    result = {
        "task_id": task_id,
        "validation_id": validation_id,
        "started_utc": started,
        "returncode": proc.returncode,
        "pred_bytes": pred_bytes,
        "stdout_tail": proc.stdout[-800:] if proc.stdout else "",
        "stderr_tail": proc.stderr[-500:] if proc.stderr else "",
    }
    print(f"[{task_id}] rc={proc.returncode} pred={pred_bytes}B")
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--validation-id", default=DEFAULT_VALIDATION)
    ap.add_argument("--variant", default="cactus_full")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--only", nargs="*", help="Run only these task IDs (default: all 21)")
    args = ap.parse_args()

    targets = args.only if args.only else NO_PRED
    print(f"validation_id={args.validation_id}  variant={args.variant}")
    print(f"targets ({len(targets)}): {targets}")

    summary = []
    for tid in targets:
        try:
            r = run_one(tid, args.validation_id, args.variant, args.dry_run)
        except Exception as e:
            r = {"task_id": tid, "status": "exception", "error": str(e),
                 "tb": traceback.format_exc()}
        summary.append(r)
        print(json.dumps({k: r.get(k) for k in ("task_id", "returncode", "pred_bytes")}, ensure_ascii=False))

    print("\n=== SUMMARY ===")
    for r in summary:
        rc = r.get("returncode")
        pb = r.get("pred_bytes")
        status = "PASS" if rc == 0 and pb and pb > 100 else ("FAIL" if rc not in (None, 0) else "NO-PRED")
        print(f"{r['task_id']:<35}  rc={rc}  pred={pb}B  -> {status}")

    print(f"\nDone {len(summary)} tasks.")


if __name__ == "__main__":
    main()
