import os, json, sys

base = r'E:\work\p5-acm\acm\experiments\runs'

tasks = [
    'astropy__astropy-12907','astropy__astropy-14182','astropy__astropy-14365','astropy__astropy-14995','astropy__astropy-6938','astropy__astropy-7746',
    'django__django-10914','django__django-10924','django__django-11001','django__django-11019','django__django-11039','django__django-11049','django__django-11099','django__django-11133','django__django-11179','django__django-11283',
    'django__django-11422','django__django-11564','django__django-11583','django__django-11620','django__django-11630','django__django-11742','django__django-11797','django__django-11815','django__django-11848','django__django-11905',
    'django__django-11910','django__django-11964','django__django-11999','django__django-12113','django__django-12125','django__django-12184','django__django-12284','django__django-12286','django__django-12308','django__django-12453',
    'django__django-12470','django__django-12497','django__django-12589','django__django-12700','django__django-12708','django__django-12747','django__django-12856','django__django-12908','django__django-12915','django__django-12983',
    'django__django-13028','django__django-13033','django__django-13158','django__django-13220'
]

results = []
for task in tasks:
    best_run = None
    best_patch = None
    best_patch_len = 0
    for run_name in sorted(os.listdir(base)):
        run_dir = os.path.join(base, run_name)
        if not os.path.isdir(run_dir):
            continue
        pred_path = os.path.join(run_dir, task, 'prediction.jsonl')
        if os.path.exists(pred_path):
            try:
                with open(pred_path, encoding='utf-8') as f:
                    data = json.loads(f.readline())
                patch = data.get('model_patch', '')
                if patch and patch.strip():
                    if len(patch) > best_patch_len:
                        best_run = run_name
                        best_patch = patch
                        best_patch_len = len(patch)
            except Exception as e:
                print(f'Error reading {pred_path}: {e}', file=sys.stderr)
    status = 'PASS' if best_patch else 'FAIL'
    results.append({'task': task, 'status': status, 'run': best_run, 'patch_len': best_patch_len})

pass_count = sum(1 for r in results if r['status'] == 'PASS')
fail_count = sum(1 for r in results if r['status'] == 'FAIL')

print(f'PASS: {pass_count} / {len(results)} ({pass_count*100//len(results)}%)')
print(f'FAIL: {fail_count}')

if fail_count > 0:
    print('FAILED TASKS:')
    for r in results:
        if r['status'] == 'FAIL':
            print(f'  {r["task"]}')

# Save to JSON for next step
output = {'summary': {'total': len(results), 'pass': pass_count, 'fail': fail_count}, 'results': results}
output_path = os.path.join(base, '_lite50_50task_results.json')
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)
print(f'Results saved to {output_path}')
