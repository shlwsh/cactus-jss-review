import json
import glob

results = {}
for log in glob.glob('experiments/runs/_*.log'):
    try:
        # 尝试 utf-8 和 utf-16
        content = None
        with open(log, 'rb') as f:
            raw = f.read()
        for enc in ['utf-8', 'utf-16', 'ascii', 'latin-1']:
            try:
                content = raw.decode(enc)
                break
            except Exception:
                continue
        if not content:
            continue
        for line in content.splitlines():
            if 'RESULT_JSON:' in line:
                try:
                    r = json.loads(line.split('RESULT_JSON:')[1])
                    tid = r.get('task_id')
                    if tid:
                        results[tid] = r
                except Exception:
                    pass
    except Exception:
        pass

print(f'Total tasks tested: {len(results)}')
passed = sum(1 for r in results.values() if r.get('status') == 'passed')
print(f'Passed: {passed}')
print(f'Failed: {len(results) - passed}')
print()
print('Failed tasks:')
for tid, r in sorted(results.items()):
    if r.get('status') != 'passed':
        print(f'  {tid}: status={r.get("status")} err={r.get("error", "")[:160]}')