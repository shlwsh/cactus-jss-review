import json
import hashlib
from pathlib import Path

# Fix cited_papers_manifest.json.provenance.json with correct hashes
manifest_file = Path('paper/data/scholar/cited_papers_manifest.json')
prov_file = manifest_file.with_name(manifest_file.name + '.provenance.json')

manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
prov = json.loads(prov_file.read_text(encoding='utf-8'))

# Update artifact hash (the manifest itself)
new_manifest_hash = hashlib.sha256(manifest_file.read_bytes()).hexdigest()
old = prov.get('artifact_sha256', '')
print(f'artifact (manifest): {old[:16]}... -> {new_manifest_hash[:16]}...')
prov['artifact_sha256'] = new_manifest_hash

# Update inputs
for inp in prov.get('inputs', []):
    path = Path(inp['path'])
    actual_sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if inp['sha256'] != actual_sha:
        print(f'  Updating {path}: {inp["sha256"][:16]}... -> {actual_sha[:16]}...')
        inp['sha256'] = actual_sha
    else:
        print(f'  OK {path}')

prov_file.write_text(json.dumps(prov, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Provenance updated')
