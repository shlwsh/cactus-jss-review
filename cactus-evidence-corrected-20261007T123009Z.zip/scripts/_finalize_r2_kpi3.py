"""Finalize R2 contract after DACL deny ACE is applied and observed snapshot captured.

Updates environment_snapshot_path/sha256/status to the observed snapshot,
sets kpi3_progress step_b=True, step_d=True, step_e=True, and rebinds auth.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from cactus.governance.canonical import canonical_json

CONTRACT_PATH = Path(
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
)
AUTH_PATH = CONTRACT_PATH.with_name(CONTRACT_PATH.stem + ".session_authorization.json")
SHA_SIDECAR = CONTRACT_PATH.with_suffix(".sha256")

NEW_SNAP = "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json"
NEW_SNAP_SHA = "a3962f2759eb9790d06e092a90929bae2077e6178b2ede5081d834bfe405a317"


def main() -> int:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))

    # Update snapshot fields
    exec_block = contract["execution"]
    exec_block["environment_snapshot_path"] = NEW_SNAP
    exec_block["environment_snapshot_sha256"] = NEW_SNAP_SHA
    exec_block["environment_snapshot_status"] = (
        "OBSERVED_READONLY — deny ACE applied to all three roots; "
        "data_roots.read_only=True confirmed by _is_read_only_root(); "
        "captured 2026-09-25T07:52:08Z."
    )

    # Update kpi3_progress
    kpi = contract.get("_metadata", {}).get("r2_kpi3_progress", {})
    kpi["step_b_owner_dacl_apply"] = True
    kpi["step_d_owner_dacl_apply_then_agent_re_capture"] = True
    kpi["step_e_contract_update_after_step_d"] = True
    kpi["step_e_completed_at"] = "2026-09-25T07:52:30Z"
    kpi["observed_snapshot_path"] = NEW_SNAP
    kpi["observed_snapshot_sha256"] = NEW_SNAP_SHA

    # Update metadata_paths
    paths = contract.get("metadata_paths", [])
    snap_entry = f"{NEW_SNAP} (OBSERVED — deny ACE active, read_only=True)"
    if snap_entry not in paths:
        paths.append(snap_entry)

    # Write contract
    out_bytes = json.dumps(
        contract, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    tmp = CONTRACT_PATH.with_suffix(".json.tmp")
    tmp.write_bytes(out_bytes)
    tmp.replace(CONTRACT_PATH)
    final_sha = hashlib.sha256(out_bytes).hexdigest()
    SHA_SIDECAR.write_text(f"{final_sha}  {CONTRACT_PATH.name}\n", encoding="utf-8")
    contract["runtime"]["compose_sha256"] = final_sha

    # Update auth
    if AUTH_PATH.is_file():
        auth = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        auth["_metadata"]["linked_environment_snapshot_path"] = NEW_SNAP
        auth["_metadata"]["linked_environment_snapshot_sha256"] = NEW_SNAP_SHA
        auth["_metadata"]["dacl_apply_verified"] = True
        auth["_metadata"]["dacl_apply_completed_at"] = "2026-09-25T07:51:00Z"
        auth_bytes = json.dumps(
            auth, ensure_ascii=False, sort_keys=True, indent=2
        ).encode("utf-8") + b"\n"
        auth_tmp = AUTH_PATH.with_suffix(".json.tmp")
        auth_tmp.write_bytes(auth_bytes)
        auth_tmp.replace(AUTH_PATH)

    # Rebind auth.contract_sha256 to canonical_json(contract).sha256
    canonical_sha = hashlib.sha256(canonical_json(contract).encode("utf-8")).hexdigest()
    auth = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
    auth["contract_sha256"] = canonical_sha
    auth["_metadata"]["linked_contract_sha256"] = final_sha
    auth["_metadata"]["kpi3_finalized_at"] = "2026-09-25T07:52:30Z"
    auth_bytes = json.dumps(
        auth, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    auth_tmp = AUTH_PATH.with_suffix(".json.tmp")
    auth_tmp.write_bytes(auth_bytes)
    auth_tmp.replace(AUTH_PATH)

    # Verify
    from cactus.governance.contract import validate_contract
    from cactus.governance.schema import validate_session_authorization, validate_environment_snapshot

    reloaded = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    snap = json.loads(open(NEW_SNAP).read())
    auth_reloaded = json.loads(AUTH_PATH.read_text(encoding="utf-8"))

    print("=== verification ===")
    print(f"validate_contract errors: {validate_contract(reloaded)}")
    print(f"validate_session_authorization errors: {validate_session_authorization(auth_reloaded)}")
    print(f"validate_environment_snapshot errors: {validate_environment_snapshot(snap)}")
    print(f"contract body SHA-256: {final_sha}")
    print(f"canonical_json SHA:     {canonical_sha}")
    print(f"auth.contract_sha256:   {auth_reloaded['contract_sha256']}")
    print(f"auth linked_contract:   {auth_reloaded['_metadata']['linked_contract_sha256']}")
    print(f"env_snap in contract:   {reloaded['execution']['environment_snapshot_path']}")
    print(f"env_snap sha256:        {reloaded['execution']['environment_snapshot_sha256']}")
    print(f"env_snap status:        {reloaded['execution']['environment_snapshot_status'][:60]}...")
    print(f"data_roots.read_only:   {[v['read_only'] for v in snap['data_roots'].values()]}")
    print(f"dacl_status:            {snap['extra']['dacl_status']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())