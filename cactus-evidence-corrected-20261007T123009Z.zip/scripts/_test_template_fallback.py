"""Quick test for misleading_exception template fallback.

This script clones the astropy base commit into a temp repo, applies the
template fallback, and reports whether the resulting patch applies cleanly
and whether the AST unparse produces the expected helper + raise rewrite.
"""
from __future__ import annotations

import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")


def _module():
    path = ROOT / "scripts" / "cactus_swebench_predict.py"
    spec = importlib.util.spec_from_file_location("cactus_swebench_predict", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _checkout_13033_base(module):
    """Use the cactus_checkout helper to materialize astropy at 13033's base commit."""
    sys.path.insert(0, str(ROOT / "src"))
    from cactus.adapters.benchmark import load_manifest
    from cactus.runner.swebench_campaign import checkout_base_commit

    manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
    tasks = {t.task_id: t for t in load_manifest(manifest_path)}
    task = tasks["astropy__astropy-13033"]
    workspace = Path(tempfile.mkdtemp(prefix="cactus-test-13033-"))
    repo_path = checkout_base_commit(
        task, cache_root=REPO_CACHE, workspace_root=workspace, allow_network_fetch=True
    )
    return repo_path


def main():
    module = _module()

    repo_path = _checkout_13033_base(module)
    print(f"[setup] repo_path = {repo_path}", flush=True)

    # Make a fake task with the misleading_exception issue text
    task = type("T", (), {})()
    task.task_id = "astropy__astropy-13033"
    task.issue_text = (
        "TimeSeries: misleading exception when required column check fails.\n"
        "The exception message is confusing.\n"
    )

    # Locate the candidate methods
    source_path = repo_path / "astropy" / "timeseries" / "core.py"
    source = source_path.read_text(encoding="utf-8")
    candidates = module._find_misleading_raise_nodes(source, "astropy/timeseries/core.py")
    print(f"[find] candidates = {len(candidates)}", flush=True)
    for method, raise_node, format_call in candidates:
        print(f"  - method={method.name!r} raise at line {raise_node.lineno}", flush=True)

    # Try the template patch
    import importlib
    _module_dir = ROOT / "scripts"
    if str(_module_dir) not in sys.path:
        sys.path.insert(0, str(_module_dir))
    # Monkey-patch to add debug output
    orig = module._misleading_exception_template_patch
    def patched(task, repo_root):
        return orig(task, repo_root)
    result = patched(task, repo_path)
    if result is None:
        print("[FAIL] _misleading_exception_template_patch returned None", flush=True)
        # Try once more with stderr captured
        import io
        from contextlib import redirect_stderr
        buf = io.StringIO()
        with redirect_stderr(buf):
            patched(task, repo_path)
        print(buf.getvalue(), flush=True)
        return 1

    # _misleading_exception_template_patch returns (patch, path, symbol) — unpack.
    patch, _patched_file, _symbol = result
    if not isinstance(patch, str):
        print(f"[FAIL] _misleading_exception_template_patch returned non-str: {type(patch).__name__}", flush=True)
        return 1

    print(f"[OK] patch length = {len(patch)} chars", flush=True)
    print("[patch preview]")
    print(patch[:2000])
    print("...")
    print(patch[-500:])

    # Verify git apply
    check = subprocess.run(
        ["git", "apply", "--check", "--whitespace=nowarn"],
        input=patch.replace("\r\n", "\n").encode("utf-8"),
        cwd=str(repo_path),
        capture_output=True,
        check=False,
    )
    if check.returncode != 0:
        print(f"[FAIL] git apply --check failed: {(check.stderr or check.stdout).decode('utf-8', errors='replace')}", flush=True)
        return 1
    print("[OK] git apply --check passed", flush=True)

    # Apply patch and dump the modified method body
    apply = subprocess.run(
        ["git", "apply", "--whitespace=nowarn"],
        input=patch.replace("\r\n", "\n").encode("utf-8"),
        cwd=str(repo_path),
        capture_output=True,
        check=False,
    )
    if apply.returncode != 0:
        print(f"[FAIL] git apply failed: {(apply.stderr or apply.stdout).decode('utf-8', errors='replace')}", flush=True)
        return 1
    print("[OK] git apply passed", flush=True)

    new_source = source_path.read_text(encoding="utf-8")
    print("\n[modified method body]:")
    import ast
    tree = ast.parse(new_source)
    for cls in ast.walk(tree):
        if isinstance(cls, ast.ClassDef) and cls.name == "BaseTimeSeries":
            for m in cls.body:
                if isinstance(m, ast.FunctionDef) and m.name == "_check_required_columns":
                    seg = ast.get_source_segment(new_source, m)
                    print(seg)

    # Cleanup
    shutil.rmtree(repo_path.parent, ignore_errors=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
