"""Diagnose why attempt 1 was rejected and exercise recovery paths.

Reproduces attempt 1's response payload from RUN-20260926T131329Z-F5337EEE and
walks each edit's replacement through every recovery strategy.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

import cactus_swebench_predict as mod

# attempt 1: 3-edit response with flattened-indent and {{obj}} braces.
# We construct the JSON via Python objects to avoid escaping pitfalls.
attempt1_obj = {
    "edits": [
        {
            "path": "astropy/timeseries/core.py",
            "symbol": "BaseTimeSeries._check_required_columns",
            "old_statement": "        if not self._required_columns_enabled:",
            "replacement": (
                "        def as_scalar_or_list_str(obj):"
                "            if not hasattr(obj, '__len__'):"
                "                return f'{{obj}}'"
                "            elif len(obj) == 1:"
                "                return f'{{obj[0]}}'"
                "            else:"
                "                return str(obj)"
                "        if not self._required_columns_enabled:"
            ),
        },
        {
            "path": "astropy/timeseries/core.py",
            "symbol": "BaseTimeSeries._check_required_columns",
            "old_statement": (
                "                raise ValueError('{} object is invalid - expected '{}' ' "
                "                                 'as the first column{} but time series has no columns' "
                "                                 .format(self.__class__.__name__, required_columns[0], plural))"
            ),
            "replacement": (
                "                raise ValueError('{} object is invalid - expected {} ' "
                "                                 'as the first column{} but time series has no columns' "
                "                                 .format(self.__class__.__name__, as_scalar_or_list_str(required_columns), plural))"
            ),
        },
        {
            "path": "astropy/timeseries/core.py",
            "symbol": "BaseTimeSeries._check_required_columns",
            "old_statement": (
                "                raise ValueError('{} object is invalid - expected '{}' ' "
                "                                 'as the first column{} but found '{}'' "
                "                                 .format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))"
            ),
            "replacement": (
                "                raise ValueError('{} object is invalid - expected {} ' "
                "                                 'as the first column{} but found {}' "
                "                                 .format(self.__class__.__name__, as_scalar_or_list_str(required_columns), plural, as_scalar_or_list_str(self.colnames[:len(required_columns)])))"
            ),
        },
    ]
}
attempt1 = json.dumps(attempt1_obj)

print("=== Parsing attempt 1 JSON ===")
try:
    parsed = json.loads(attempt1)
    print(f"  edits count: {len(parsed['edits'])}")
except json.JSONDecodeError as exc:
    print(f"  JSON decode FAILED: {exc}")
    sys.exit(1)

for i, edit in enumerate(parsed['edits']):
    repl = edit['replacement']
    print(f"\n=== Edit {i+1} replacement (first 250 chars) ===")
    print(repl[:250])
    print(f"--- _try_parse_with_quote_recovery ---")
    tree, recovered = mod._try_parse_with_quote_recovery(repl.strip() + "\n")
    if tree:
        print(f"  OK (recovered: {recovered[:200]!r})")
    else:
        print(f"  FAILED")
    # Also try the unparse step (used downstream)
    print(f"--- _recover_flattened_indent alone ---")
    flat = mod._recover_flattened_indent(repl)
    print(f"  flat recovery (first 250 chars): {flat[:250]!r}")
    tree2, _ = mod._try_parse_with_quote_recovery(flat.strip() + "\n")
    if tree2:
        print(f"  flat+parse OK")
    else:
        print(f"  flat+parse FAILED")