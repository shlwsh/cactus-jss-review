"""Trace why _misleading_exception_template_patch returns None for each non-13033 task."""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT))

spec = importlib.util.spec_from_file_location("cactus_swebench_predict_trace", str(ROOT / "scripts" / "cactus_swebench_predict.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

from cactus.adapters.benchmark import load_manifest  # type: ignore
import ast

manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
REPO_CACHE = ROOT / "experiments" / "repo_cache"

targets = ["astropy__astropy-14096", "django__django-12262", "django__django-13417"]

for tid in targets:
    task = next(t for t in load_manifest(manifest) if t.task_id == tid)
    print(f"\n=== {tid} ===")
    print(f"  repo_id = {task.repo_id}")
    print(f"  base_commit = {task.base_commit[:10]}...")
    print(f"  issue_text head = {(task.issue_text or '')[:200]!r}")

    safe = task.repo_id.replace("/", "__")
    mirror = REPO_CACHE / f"{safe}.git"
    if not mirror.exists():
        print(f"  [skip] no repo cache for {mirror}")
        continue
    ws = Path(tempfile.mkdtemp(prefix=f"trace_{tid[:20]}_"))
    co = ws / "repository"
    subprocess.run(["git", "clone", "--no-checkout", str(mirror), str(co)], cwd=str(ws), check=True, capture_output=True)
    subprocess.run(["git", "-C", str(co), "checkout", "--detach", task.base_commit], cwd=str(ws), check=True, capture_output=True)

    # Walk every .py file and look for raise .format(...) with [0] Subscript.
    found = []
    for py in sorted(co.rglob("*.py")):
        try:
            text = py.read_text(encoding="utf-8")
        except OSError:
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        for cls in ast.walk(tree):
            if not isinstance(cls, ast.ClassDef):
                continue
            for child in cls.body:
                if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                low = child.name.lower()
                if not any(tok in low for tok in ("_check_", "_validate_", "_verify_", "_assert_", "_require_")):
                    continue
                for sub in ast.walk(child):
                    if not isinstance(sub, ast.Raise) or sub.exc is None:
                        continue
                    if not isinstance(sub.exc, ast.Call):
                        continue
                    if not sub.exc.args:
                        continue
                    first_arg = sub.exc.args[0]
                    if not (isinstance(first_arg, ast.Call) and isinstance(first_arg.func, ast.Attribute) and first_arg.func.attr == "format"):
                        continue
                    has_idx0 = any(
                        isinstance(a, ast.Subscript) and isinstance(a.slice, ast.Constant) and a.slice.value == 0
                        for a in first_arg.args
                    )
                    if has_idx0:
                        rel = py.relative_to(co).as_posix()
                        found.append((rel, f"{cls.name}.{child.name}", sub.lineno))

    print(f"  AST matches (raise with .format(... [0] ...) in _check_/... methods): {len(found)}")
    for rel, sym, ln in found[:5]:
        print(f"    - {rel}:{sym} raise at line {ln}")
    if not found:
        # Look at every raise .format() in the repo (broader search).
        broader = []
        for py in sorted(co.rglob("*.py")):
            try:
                text = py.read_text(encoding="utf-8")
            except OSError:
                continue
            try:
                tree = ast.parse(text)
            except SyntaxError:
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Raise) and isinstance(node.exc, ast.Call):
                    if node.exc.args and isinstance(node.exc.args[0], ast.Call) and isinstance(node.exc.args[0].func, ast.Attribute):
                        if node.exc.args[0].func.attr == "format":
                            rel = py.relative_to(co).as_posix()
                            broader.append((rel, node.lineno))
        print(f"  Broader: any raise with .format() args: {len(broader)}")
        for rel, ln in broader[:3]:
            print(f"    - {rel} line {ln}")
