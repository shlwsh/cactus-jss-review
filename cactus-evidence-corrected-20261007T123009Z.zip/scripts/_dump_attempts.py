"""Inspect each attempt's model_call output + rejection."""
import json, sys
from pathlib import Path

name = sys.argv[1] if len(sys.argv) > 1 else 'django__django-11910'
base = Path(f'experiments/runs/FACO-FULL-LITE50-POSTFIX3-20261003T222550Z/{name}/events.jsonl')
events = [json.loads(l) for l in base.read_text(encoding='utf-8', errors='ignore').splitlines()]

# Find all model_call events, sort by seq
mcalls = [(e['seq'], e) for e in events if e.get('type') == 'model_call']
mcalls.sort()
print(f'model_call count = {len(mcalls)}')
for i, (seq, e) in enumerate(mcalls, 1):
    p = e.get('payload', {})
    turn = p.get('turn_id', '?')
    meta = p.get('metadata', {})
    sr = p.get('finish_reason', '?')
    out_t = p.get('output_tokens', '?')
    in_t = p.get('input_tokens', '?')
    print(f'\n--- model_call #{i} (seq={seq}) ---')
    print(f'turn: {turn}')
    print(f'finish_reason: {sr}  in={in_t}  out={out_t}')
    resp = p.get('response_text', '')
    if resp:
        print(f'response_text (last 600): ...{resp[-600:]}')

print('\n=== rejections ===')
for e in events:
    if e.get('type') in ('prediction_rejected', 'prediction_sites_rejected', 'prediction_exhausted'):
        p = e.get('payload', {})
        print(f'  seq={e["seq"]} {e["type"]}: {p.get("reason","-")[:160]}  sites={p.get("site_ids","-")}  excluded_count={len(p.get("excluded_site_ids",[]))}')