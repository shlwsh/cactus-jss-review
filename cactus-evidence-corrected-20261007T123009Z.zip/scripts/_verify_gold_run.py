"""Apply gold patch and run pytest in one go."""
from pathlib import Path
import tempfile
import subprocess
import sys
import os

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest = list(load_manifest(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"))
task = next(t for t in manifest if t.task_id == "astropy__astropy-13033")
ws = Path(tempfile.mkdtemp(prefix="cactus-gold-verify-"))
repo = checkout_base_commit(task, cache_root=Path(r"E:\cactus-data\repo-cache"), workspace_root=ws, allow_network_fetch=True)
print(f"repo: {repo}")

# Apply gold patch via string replacement
core_path = repo / "astropy" / "timeseries" / "core.py"
core_text = core_path.read_text(encoding="utf-8")

# 1. Insert as_scalar_or_list_str helper
old_def = "    def _check_required_columns(self):\n\n        if not self._required_columns_enabled:"
new_def = (
    "    def _check_required_columns(self):\n"
    "        def as_scalar_or_list_str(obj):\n"
    "            if not hasattr(obj, \"__len__\"):\n"
    "                return f\"'{obj}'\"\n"
    "            elif len(obj) == 1:\n"
    "                return f\"'{obj[0]}'\"\n"
    "            else:\n"
    "                return str(obj)\n"
    "\n"
    "        if not self._required_columns_enabled:"
)
assert old_def in core_text
core_text = core_text.replace(old_def, new_def, 1)

# 2. Replace the error message format
text_lines = core_text.splitlines(keepends=True)
raise_idx = None
for i, line in enumerate(text_lines):
    if "as the first column{} but found '{}'" in line:
        raise_idx = i - 1
        break
assert raise_idx is not None

new_text_lines = (
    text_lines[:raise_idx]
    + [
        '                raise ValueError("{} object is invalid - expected {} "\n',
        '                                 "as the first column{} but found {}"\n',
        '                                 .format(self.__class__.__name__, as_scalar_or_list_str(required_columns),\n',
        '                                            plural, as_scalar_or_list_str(self.colnames[:len(required_columns)])))\n',
    ]
    + text_lines[raise_idx + 3:]
)
core_path.write_text("".join(new_text_lines), encoding="utf-8")

# Apply test patch (insert before @pytest.mark.parametrize)
test_path = repo / "astropy" / "timeseries" / "tests" / "test_sampled.py"
test_text = test_path.read_text(encoding="utf-8")
target = "@pytest.mark.parametrize('cls', [BoxLeastSquares, LombScargle])\ndef test_periodogram(cls):"
insertion = (
    "    # https://github.com/astropy/astropy/issues/13009\n"
    "    ts_2cols_required = ts.copy()\n"
    "    ts_2cols_required._required_columns = ['time', 'a']\n"
    "    with pytest.raises(ValueError) as exc:\n"
    "        ts_2cols_required.remove_column('a')\n"
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    "                                 \"['time', 'a'] as the first columns but found ['time', 'b']\")\n"
    "\n"
    "\n"
)
assert target in test_text
test_text = test_text.replace(target, insertion + target, 1)
test_path.write_text(test_text, encoding="utf-8")

# Save repo path for next step
repo_file = ws / "REPO_PATH.txt"
repo_file.write_text(str(repo), encoding="utf-8")
print(f"saved repo path to: {repo_file}")
print(f"repo: {repo}")

# Run pytest from inside repo
print("\n=== pytest test_required_columns with gold patch ===")
# Disable the conftest's warning filter that causes the import error
result = subprocess.run(
    [r"C:\Python313\python.exe", "-m", "pytest",
     "astropy/timeseries/tests/test_sampled.py::test_required_columns",
     "-xvs", "--tb=short", "--no-header",
     "-p", "no:cacheprovider",
     "-W", "ignore::DeprecationWarning",
     "-W", "ignore::FutureWarning",
     "--override-ini=filterwarnings=",
     ],
    cwd=str(repo),
    capture_output=True, text=True,
    timeout=180,
    env={**os.environ, "PYTHONPATH": "."},
)
print("--- stdout ---")
print(result.stdout[:5000])
print("--- stderr ---")
print(result.stderr[:2000])