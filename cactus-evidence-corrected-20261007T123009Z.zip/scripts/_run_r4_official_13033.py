"""R4 official-API end-to-end: DeepSeek V4.1 Flash 官方 API + CACTUS predict + SWE-bench Docker eval on 13033.

Goal: prove that the *official* DeepSeek-V4.1-Flash API can drive the *same*
CACTUS predict → Docker eval pipeline that the local vLLM version already
uses, and that the resulting patch makes 13033 PASS (resolve the misleading
exception issue).

Compared to _run_r4_v3.py:
  - Drops the known_gold_patch injection path entirely; this run is
    model-emitted only.
  - Uses model_config = deepseek_official_flash_v1.json which routes the
    OpenAI-compatible request to https://api.deepseek.com/v1 instead of the
    local LiteLLM proxy.
  - One task (13033) instead of a list, because we want a single resolved /
    not-resolved verdict to compare against the gold-injection baseline
    (RUN-20260926T121326Z-47883EDF).
  - Pinned image = the exact digest verified by RUN-20260926T121326Z
    (sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de).

Usage:
  & .venv\Scripts\python.exe -u scripts\_run_r4_official_13033.py
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl")
ENV_FILE = ROOT / "docs" / "llm" / ".env"
MODEL_CONFIG = ROOT / "configs" / "models" / "deepseek_official_flash_v1.json"
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
TASKS_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"

TASKS = [
    {
        "task_id": "astropy__astropy-13033",
        "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de",
        "variant": "cactus_full",
    },
]

PREDICT_TIMEOUT = 1500        # 25 min per attempt (DeepSeek API is slower than local vLLM ~12s/call)
EVAL_TIMEOUT = 900            # 15 min per task
CLEANUP_AFTER_EVAL = False

sys.path.insert(0, str(ROOT / "src"))
from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit


@dataclass
class TaskResult:
    task_id: str
    run_id: str
    pinned_image: str
    predict_ok: bool = False
    eval_resolved: bool = False
    tokens_in: int = 0
    tokens_out: int = 0
    predict_elapsed: float = 0.0
    eval_elapsed: float = 0.0
    error: str = ""
    workspace: Path | None = None
    variant: str = "cactus_full"


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(p: Path) -> str:
    import hashlib
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _write_json(p: Path, data: dict) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False) + "\n", encoding="utf-8")


def _load_env() -> tuple[dict, int]:
    """Load every KEY=VALUE pair from docs/llm/.env into env (broader than v3's
    LITELLM-only filter, because the official DeepSeek key var is DEEPSEEK_API_KEY).

    The previous runner's narrow filter ('LITELLM' or 'API_KEY') still picks up
    DEEPSEEK_API_KEY (it contains 'API_KEY'), but we broaden to all keys to
    tolerate future renames.
    """
    env = os.environ.copy()
    n = 0
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k] = v.strip()
            n += 1
    return env, n


def _run_subprocess(cmd: list[str], cwd: Path, env: dict, timeout_sec: int, stdout_path: Path, stderr_path: Path) -> tuple[int, float]:
    t0 = time.monotonic()
    try:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True, text=True, timeout=timeout_sec)
    except subprocess.TimeoutExpired as exc:
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace")
        stderr = (exc.stderr or b"").decode("utf-8", errors="replace")
        stdout_path.write_text(stdout + "\n[__TIMEOUT__]", encoding="utf-8")
        stderr_path.write_text(stderr + f"\n[__TIMEOUT__ after {timeout_sec}s]", encoding="utf-8")
        return -1, time.monotonic() - t0
    stdout_path.write_text(proc.stdout, encoding="utf-8")
    stderr_path.write_text(proc.stderr, encoding="utf-8")
    return proc.returncode, time.monotonic() - t0


# ── Repo setup ────────────────────────────────────────────────────────────────

def setup_workspace(task_id: str, run_id: str, repo_cache: Path) -> Path:
    tasks = {t.task_id: t for t in load_manifest(TASKS_MANIFEST)}
    if task_id not in tasks:
        raise ValueError(f"task_id {task_id!r} not in manifest")
    task = tasks[task_id]
    workspace_root = Path(tempfile.gettempdir()) / f"cactus-official-{run_id}-{uuid.uuid4().hex[:8]}"
    workspace_root.mkdir(parents=True, exist_ok=True)
    repo_path = checkout_base_commit(
        task, cache_root=repo_cache, workspace_root=workspace_root,
        allow_network_fetch=True,
    )
    print(f"[setup:{task_id}] workspace={repo_path}", flush=True)
    print(f"[setup:{task_id}] HEAD commit = {_workspace_head(repo_path)}", flush=True)
    return repo_path


def _workspace_head(repo_path: Path) -> str:
    """Return the current HEAD commit short-SHA the workspace was checked out at."""
    head_file = repo_path / ".git" / "HEAD"
    if not head_file.exists():
        # subdir-style git info? skip
        return "(no .git/HEAD)"
    try:
        ref = head_file.read_text().strip().split()[1]
    except Exception:
        return "(unreadable HEAD)"
    packed = repo_path / ".git" / "packed-refs"
    candidate = (repo_path / ".git" / ref).resolve()
    if candidate.is_file():
        return candidate.read_text().strip()
    if packed.is_file():
        for line in packed.read_text().splitlines():
            if line.startswith("#"):
                continue
            parts = line.strip().split()
            if len(parts) >= 2 and parts[1] == ref:
                return parts[0]
    return ref


def cleanup_workspace(workspace: Path | None) -> None:
    if workspace is None:
        return
    try:
        shutil.rmtree(workspace.parent, ignore_errors=True)
        print(f"[cleanup] removed workspace parent: {workspace.parent}", flush=True)
    except Exception as exc:
        print(f"[cleanup] warning: {exc}", flush=True)


# ── Bundle ───────────────────────────────────────────────────────────────────

def setup_bundle(task_id: str, run_id: str) -> Path:
    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)
    now = utc_now()
    _write_json(run_root / "environment.pre.json", {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "pre", "run_id": run_id,
        "official_api": True,
        "official_api_config": str(MODEL_CONFIG.relative_to(ROOT)),
        "official_api_base_url": "https://api.deepseek.com/v1",
        "official_api_model": "deepseek-flash",
    })
    return run_root


# ── Predict ───────────────────────────────────────────────────────────────────

def run_predict(result: TaskResult) -> None:
    if result.workspace is None:
        result.error = "no workspace"
        return

    run_root = ROOT / "experiments" / "runs" / result.run_id
    trace_path = run_root / "trace" / "events.jsonl"
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"

    if trace_path.exists():
        trace_path.unlink()

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "cactus_swebench_predict.py"),
        "--tasks", str(TASKS_MANIFEST),
        "--task-id", result.task_id,
        "--repo-root", str(result.workspace),
        "--model-config", str(MODEL_CONFIG),
        "--trace", str(trace_path),
        "--output", str(pred_path),
        "--budget", "12000",
        "--request-timeout-sec", str(PREDICT_TIMEOUT - 30),
        "--variant", result.variant,
    ]
    print(f"[predict:{result.task_id}] workspace={result.workspace}", flush=True)
    print(f"[predict:{result.task_id}] model_config={MODEL_CONFIG}", flush=True)
    print(f"[predict:{result.task_id}] pinned_image={result.pinned_image}", flush=True)

    env, n = _load_env()
    if not env.get("DEEPSEEK_API_KEY"):
        result.error = "DEEPSEEK_API_KEY not set in environment"
        print(f"[predict:{result.task_id}] FAIL: {result.error}", flush=True)
        return
    print(f"[predict:{result.task_id}] env injection: {n} keys loaded (DEEPSEEK_API_KEY={'present' if env.get('DEEPSEEK_API_KEY') else 'MISSING'})", flush=True)

    rc, elapsed = _run_subprocess(
        cmd, ROOT, env, PREDICT_TIMEOUT,
        logs_dir / "predict.stdout.log",
        logs_dir / "predict.stderr.log",
    )
    result.predict_elapsed = elapsed

    if trace_path.exists():
        try:
            for ln in trace_path.read_text(encoding="utf-8").splitlines():
                if not ln.strip():
                    continue
                e = json.loads(ln)
                if e.get("type") == "model_call":
                    p = e.get("payload", {})
                    result.tokens_in = p.get("input_tokens", 0)
                    result.tokens_out = p.get("output_tokens", 0)
                    break
        except Exception:
            pass

    if rc == 0 and pred_path.exists():
        result.predict_ok = True
        print(f"[predict:{result.task_id}] OK {result.tokens_in}in/{result.tokens_out}out {elapsed:.0f}s", flush=True)
    else:
        err_log = (logs_dir / "predict.stderr.log").read_text("utf-8", errors="replace")
        lines = [l for l in err_log.splitlines() if l.strip()]
        result.error = lines[-1][:200] if lines else f"rc={rc}"
        print(f"[predict:{result.task_id}] FAIL rc={rc} {result.error}", flush=True)


# ── Eval ──────────────────────────────────────────────────────────────────────

def run_eval(result: TaskResult) -> None:
    if not result.predict_ok:
        print(f"[eval:{result.task_id}] skipping (predict failed)", flush=True)
        return

    run_root = ROOT / "experiments" / "runs" / result.run_id
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"
    eval_dir = run_root / "evaluation"

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(pred_path),
        "--instance", result.task_id,
        "--pinned-image", result.pinned_image,
        "--run-id", result.run_id,
        "--workers", "1",
        "--timeout", str(EVAL_TIMEOUT),
        "--report-dir", str(eval_dir),
    ]
    print(f"[eval:{result.task_id}] starting", flush=True)

    env, _ = _load_env()
    rc, elapsed = _run_subprocess(
        cmd, ROOT, env, EVAL_TIMEOUT,
        logs_dir / "evaluate.stdout.log",
        logs_dir / "evaluate.stderr.log",
    )
    result.eval_elapsed = elapsed

    reports = sorted(eval_dir.glob(f"*.{result.run_id}.json"))
    if reports:
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            result.eval_resolved = int(rep.get("resolved_instances", 0)) > 0
            print(f"[eval:{result.task_id}] resolved={result.eval_resolved} ({elapsed:.0f}s)", flush=True)
            print(f"[eval:{result.task_id}] report file = {reports[0].name}", flush=True)
        except Exception as exc:
            print(f"[eval:{result.task_id}] report parse error: {exc}", flush=True)

    raw_data = {
        "task_id": result.task_id,
        "repo_id": "astropy/astropy",
        "base_commit": "298ccb478e6bf092953bca67a3d29dc6c35f6752",
        "evaluator_exit_code": rc,
        "evaluator_valid": rc == 0,
        "resolved": result.eval_resolved,
        "prediction_hash": _sha256(pred_path) if pred_path.exists() else None,
        "source": "deepseek_official_api_v1",
    }
    raw = {
        "schema_version": "2.0", "run_id": result.run_id,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-OFFICIAL-20260927",
        "generated_at": utc_now(), "data": raw_data,
        "evidence": {
            "origin_type": "measured", "test_scope": "end_to_end",
            "integrity_status": "verified" if result.eval_resolved else "incomplete",
            "reproducibility_status": "partial",
            "statistics_status": "not_required",
        },
    }
    _write_json(run_root / "raw" / "result.json", raw)


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> int:
    ts = utc_now().replace(":", "").replace("-", "")[:15]
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] R4 official-API pipeline — {len(TASKS)} task(s) (sequential)", flush=True)
    print(f"  model_config = {MODEL_CONFIG}", flush=True)
    print(f"  base_url     = https://api.deepseek.com/v1", flush=True)
    print(f"  model_id     = deepseek-flash", flush=True)
    print(f"  dataset      = {DATASET}", flush=True)
    print(f"  repo_cache   = {REPO_CACHE}", flush=True)
    print(f"  predict_timeout={PREDICT_TIMEOUT}s eval_timeout={EVAL_TIMEOUT}s", flush=True)
    print(f"{'='*60}", flush=True)

    results: list[TaskResult] = []

    for i, cfg in enumerate(TASKS):
        task_id = cfg["task_id"]
        uid = uuid.uuid4().hex[:8].upper()
        run_id = f"RUN-{ts}Z-{uid}"
        print(f"\n[Task {i+1}/{len(TASKS)}] {task_id}", flush=True)
        print(f"  run_id={run_id}", flush=True)
        print(f"  image={cfg['pinned_image']}", flush=True)

        setup_bundle(task_id, run_id)
        try:
            workspace = setup_workspace(task_id, run_id, REPO_CACHE)
        except Exception as exc:
            print(f"  [ERROR] workspace setup failed: {exc}", flush=True)
            results.append(TaskResult(task_id, run_id, cfg["pinned_image"], error=str(exc)))
            continue

        result = TaskResult(
            task_id=task_id, run_id=run_id,
            pinned_image=cfg["pinned_image"],
            workspace=workspace,
            variant=cfg.get("variant", "cactus_full"),
        )
        results.append(result)

        run_predict(result)
        run_eval(result)

        if CLEANUP_AFTER_EVAL:
            cleanup_workspace(result.workspace)
            result.workspace = None

        icon = "PASS" if result.eval_resolved else "FAIL"
        print(f"  [{icon}] {task_id}: predict={result.predict_ok} eval={result.eval_resolved} "
              f"tokens={result.tokens_in}in/{result.tokens_out}out "
              f"predict={result.predict_elapsed:.0f}s eval={result.eval_elapsed:.0f}s "
              f"error={result.error or 'none'}", flush=True)

    n_ok = sum(1 for r in results if r.eval_resolved)
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] FINAL: {n_ok}/{len(results)} resolved", flush=True)
    for r in results:
        icon = "PASS" if r.eval_resolved else "FAIL"
        print(f"  [{icon}] {r.task_id}: resolved={r.eval_resolved}", flush=True)
    print(f"{'='*60}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
