import json
import hashlib

# Fix cited_papers_manifest.json: correct bib_sha256 (references.bib) and tex_sha256 (main.tex)
manifest = json.loads(open('paper/data/scholar/cited_papers_manifest.json').read())
bib_hash = hashlib.sha256(open('paper/references.bib', 'rb').read()).hexdigest()
tex_hash = hashlib.sha256(open('paper/main.tex', 'rb').read()).hexdigest()
manifest['bib_sha256'] = bib_hash
manifest['tex_sha256'] = tex_hash
open('paper/data/scholar/cited_papers_manifest.json', 'w').write(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(f'bibliography.bib_sha256 -> {bib_hash[:16]}... (references.bib)')
print(f'manuscript.tex_sha256 -> {tex_hash[:16]}... (main.tex)')
print('Manifest updated')
