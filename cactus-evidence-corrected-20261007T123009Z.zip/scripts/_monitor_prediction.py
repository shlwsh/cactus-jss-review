"""R4 prediction monitor - run every 15 seconds."""
import datetime as dt
import json
import sys
import time
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
OUT_DIR = ROOT / "experiments/runs"


def check_prediction(pid: int, task_id: str, max_wait_sec: int = 1800):
    """Monitor a prediction process."""
    import subprocess

    start_time = time.monotonic()
    last_size = 0
    last_stderr_size = 0

    while True:
        elapsed = time.monotonic() - start_time
        if elapsed > max_wait_sec:
            print(f"TIMEOUT after {elapsed:.0f}s")
            return "timeout"

        # Check if process is still alive
        try:
            r = subprocess.run(
                ["powershell", "-Command", f"Get-Process -Id {pid} -ErrorAction SilentlyContinue"],
                capture_output=True, text=True, timeout=10,
            )
            is_alive = str(pid) in r.stdout
        except Exception:
            is_alive = False

        now = dt.datetime.now(dt.timezone.utc).strftime("%H:%M:%S UTC")

        # Find the output directory for this prediction
        runs = sorted(
            [d for d in OUT_DIR.iterdir() if d.is_dir() and "r4_verify" in d.name and task_id.replace("__", "_") in d.name],
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )
        if not runs:
            print(f"[{now}] PID={pid} alive={is_alive} (no output dir yet, {elapsed:.0f}s elapsed)")
            time.sleep(15)
            continue

        latest = runs[0]

        # Read stdout tail
        stdout_f = latest / "predict.stdout.log"
        stderr_f = latest / "predict.stderr.log"

        stdout_lines = 0
        stderr_lines = 0
        stdout_tail = ""
        stderr_tail = ""

        if stdout_f.exists():
            lines = [l for l in stdout_f.read_text(encoding="utf-8", errors="replace").split("\n") if l.strip()]
            stdout_lines = len(lines)
            stdout_tail = lines[-1][:120] if lines else ""

        if stderr_f.exists():
            lines = [l for l in stderr_f.read_text(encoding="utf-8", errors="replace").split("\n") if l.strip()]
            stderr_lines = len(lines)
            stderr_tail = lines[-1][:120] if lines else ""

        stdout_size = stdout_f.stat().st_size if stdout_f.exists() else 0
        stderr_size = stderr_f.stat().st_size if stderr_f.exists() else 0

        # Check for completion
        if not is_alive:
            print(f"\n[{now}] PID={pid} FINISHED")
            print(f"  Output: {latest.name}")
            print(f"  stdout: {stdout_lines} lines, {stdout_size} bytes")
            print(f"  stderr: {stderr_lines} lines, {stderr_size} bytes")
            if stderr_tail:
                print(f"  stderr tail: {stderr_tail}")
            if stdout_tail:
                print(f"  stdout tail: {stdout_tail}")

            # Analyze result
            if stderr_f.exists():
                stderr_text = stderr_f.read_text(encoding="utf-8", errors="replace")
                if "PASS prediction written" in stderr_text:
                    return "success"
                elif "symbol '_check_required_columns'" in stderr_text and "not found" in stderr_text:
                    return "fail_context"
                elif "old_statement must exactly match" in stderr_text:
                    return "fail_context"
                elif "prediction generation exhausted" in stderr_text:
                    return "fail_model"
                elif stdout_f.exists() and "PASS prediction" in stdout_f.read_text():
                    return "success"

            return "finished"

        # Progress update
        growing = stdout_size > last_size or stderr_size > last_stderr_size
        last_size = stdout_size
        last_stderr_size = stderr_size

        print(f"[{now}] PID={pid} alive={is_alive} {elapsed:.0f}s | stdout={stdout_lines}L/{stdout_size}B | stderr={stderr_lines}L | {stdout_tail[:60] if stdout_tail else '(no output)'}")
        time.sleep(15)


def main():
    import subprocess

    # Find the running prediction process
    try:
        r = subprocess.run(
            ["powershell", "-Command", "Get-Process python -ErrorAction SilentlyContinue | Select-Object Id, @{Name='cmd';Expression={$_.MainWindowTitle}}"],
            capture_output=True, text=True, timeout=10,
        )
        print("Running Python processes:")
        print(r.stdout[:500])
    except Exception as e:
        print(f"Process check error: {e}")

    # Monitor by finding latest output
    runs = sorted(
        [d for d in OUT_DIR.iterdir() if d.is_dir() and "r4_verify" in d.name],
        key=lambda d: d.stat().st_mtime,
        reverse=True,
    )
    if runs:
        latest = runs[0]
        print(f"\nMonitoring: {latest.name}")
        # Try to find PID from stdout
        stdout_f = latest / "predict.stdout.log"
        if stdout_f.exists():
            print(f"stdout tail: {stdout_f.read_text(encoding='utf-8', errors='replace').split(chr(10))[-1][:120]}")

    # Just check latest run
    result = check_prediction(0, "astropy__astropy-13033")
    print(f"\nFinal result: {result}")


if __name__ == "__main__":
    main()
