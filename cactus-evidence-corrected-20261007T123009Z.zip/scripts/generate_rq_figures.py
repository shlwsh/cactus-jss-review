"""Generate RQ1-RQ3 figures from validated, measured CACTUS RUN bundles.

Every metric is derived from sealed RUN evidence. The script fails closed when
any requested variant lacks the required task count or valid evaluator data.
"""

from __future__ import annotations

import argparse
import re
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
FIGURE_STYLE = ROOT / "paper" / "figures"
if str(FIGURE_STYLE) not in sys.path:
    sys.path.insert(0, str(FIGURE_STYLE))

import matplotlib.pyplot as plt
import numpy as np

from plot_style import COLORS, apply_style, save, style_axis
from cactus.governance.provenance import write_sidecar
from cactus.runner.bundle_validator import validate_bundle


def load_measured_rows(runs_root: Path, *, campaign_id: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for bundle in sorted(path for path in runs_root.glob("RUN-*") if path.is_dir()):
        errors = validate_bundle(bundle)
        if errors:
            continue
        try:
            manifest = json.loads((bundle / "run_manifest.json").read_text(encoding="utf-8"))
            result = json.loads((bundle / "raw" / "result.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        data = result.get("data") if isinstance(result.get("data"), dict) else {}
        evidence = result.get("evidence") if isinstance(result.get("evidence"), dict) else {}
        if manifest.get("campaign_id") != campaign_id:
            continue
        if evidence.get("origin_type") != "measured" or evidence.get("integrity_status") != "verified" or data.get("evaluator_valid") is not True:
            continue
        if not isinstance(data.get("resolved"), bool):
            continue
        rows.append({
            "run_id": manifest.get("run_id", bundle.name),
            "task_id": manifest.get("task_id", data.get("task_id")),
            "variant_id": manifest.get("variant_id"),
            "resolved": data["resolved"],
            "input_tokens": int(data.get("input_tokens") or 0),
            "output_tokens": int(data.get("output_tokens") or 0),
            "verified_usd_spend": data.get("verified_usd_spend"),
            "run_manifest": bundle / "run_manifest.json",
            "raw_result": bundle / "raw" / "result.json",
        })
    return rows


def require_complete_variants(rows: list[dict[str, Any]], variants: list[str], expected_tasks: int) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row["variant_id"] in variants:
            grouped[str(row["variant_id"])].append(row)
    result: dict[str, list[dict[str, Any]]] = {}
    reference_task_ids: set[str] | None = None
    reference_variant: str | None = None
    for variant in variants:
        values = grouped.get(variant, [])
        unique = {row["task_id"] for row in values}
        if len(unique) != expected_tasks or len(values) != expected_tasks or None in unique:
            raise ValueError(f"{variant}: expected {expected_tasks} unique evaluator-valid measured tasks; found {len(unique)}")
        task_ids = {str(task_id) for task_id in unique}
        if reference_task_ids is None:
            reference_task_ids = task_ids
            reference_variant = variant
        elif task_ids != reference_task_ids:
            missing = sorted(reference_task_ids - task_ids)
            unexpected = sorted(task_ids - reference_task_ids)
            raise ValueError(
                f"{variant}: matched task IDs differ from {reference_variant}; "
                f"missing={missing[:5]}, unexpected={unexpected[:5]}"
            )
        result[variant] = values
    return result


def _provenance(artifact: Path, inputs: list[Path], *, transform_id: str) -> None:
    is_table = artifact.suffix.lower() == ".tex"
    identifier = re.sub(r"[^A-Z0-9_-]+", "-", artifact.stem.upper()).strip("-_")
    write_sidecar(
        artifact,
        artifact_id=f"{'TAB' if is_table else 'FIG'}-{identifier}",
        artifact_type="table" if is_table else "figure",
        generator_path="scripts/generate_rq_figures.py",
        inputs=[{"path": path.as_posix(), "sha256": __import__("hashlib").sha256(path.read_bytes()).hexdigest()} for path in inputs],
        transform_id=transform_id,
    )


def _save(fig, output: Path, stem: str, inputs: list[Path], transform_id: str) -> None:
    save(fig, output, stem)
    for ext in ("pdf", "png", "svg"):
        _provenance(output / f"{stem}.{ext}", inputs, transform_id=transform_id)
    plt.close(fig)


def _wilson(successes: int, total: int) -> tuple[float, float]:
    if total <= 0:
        return (0.0, 0.0)
    p = successes / total
    z = 1.96
    den = 1 + z * z / total
    center = (p + z * z / (2 * total)) / den
    radius = z * np.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / den
    return max(0.0, center - radius), min(1.0, center + radius)


def _main_results_table_lines(variants: dict[str, list[dict[str, Any]]]) -> list[str]:
    """Render the RQ1 baseline and RQ2 ablations in one measured-results table."""
    ordered_variants = (
        "cactus_test_aware",
        "maximal_context",
        "cactus_no_test_aware",
        "cactus_no_semantic",
        "cactus_no_iteration",
    )
    missing = [variant for variant in ordered_variants if variant not in variants]
    if missing:
        raise ValueError(f"main results table is missing variants: {', '.join(missing)}")

    lines = [
        r"\begin{tabular}{lrrrr}",
        r"\hline",
        r"Variant & Evaluator-valid & Resolved & Resolved rate & Mean tokens \\",
        r"\hline",
    ]
    for variant in ordered_variants:
        rows = variants[variant]
        if not rows:
            raise ValueError(f"{variant}: main results table cannot summarize an empty cohort")
        resolved = sum(bool(row["resolved"]) for row in rows)
        mean_tokens = float(np.mean([row["input_tokens"] + row["output_tokens"] for row in rows]))
        label = variant.replace("_", r"\_")
        lines.append(
            f"{label} & {len(rows)} & {resolved} & {resolved / len(rows):.1%} & {mean_tokens:.0f} \\\\")
    lines.extend([r"\hline", r"\end{tabular}"])
    return lines


def require_reviewed_forensics(rows: list[dict[str, Any]]) -> None:
    review_required = [row for row in rows if row.get("manual_review_required") is True]
    if review_required:
        raise ValueError(
            f"RQ3 forensics still has {len(review_required)} unresolved manual reviews; "
            "resolve those classifications before generating publication figures"
        )


def generate(rows: list[dict[str, Any]], output: Path, *, expected_tasks: int, forensics_path: Path) -> None:
    apply_style()
    output.mkdir(parents=True, exist_ok=True)
    rq1 = require_complete_variants(rows, ["cactus_test_aware", "maximal_context"], expected_tasks)
    rq2 = require_complete_variants(rows, ["cactus_test_aware", "cactus_no_test_aware", "cactus_no_semantic", "cactus_no_iteration"], expected_tasks)
    source_paths = sorted({
        path
        for variant_rows in (*rq1.values(), *rq2.values())
        for row in variant_rows
        for path in (row["run_manifest"], row["raw_result"])
    })

    fig, ax = plt.subplots(figsize=(5.4, 3.6))
    for variant, color, label in (("cactus_test_aware", COLORS["method"], "CACTUS + test-aware"), ("maximal_context", COLORS["baseline"], "Full context")):
        values = rq1[variant]
        valid_costs = [row for row in values if isinstance(row["verified_usd_spend"], (float, int))]
        if len(valid_costs) != expected_tasks:
            raise ValueError(f"{variant}: verified cost missing for {expected_tasks - len(valid_costs)} tasks")
        token_mean = float(np.mean([row["input_tokens"] + row["output_tokens"] for row in values]))
        resolved_rate = float(np.mean([row["resolved"] for row in values]))
        ax.scatter(token_mean, resolved_rate, color=color, s=70, label=label, edgecolor="white", linewidth=0.8, zorder=3)
        ax.annotate(f"{label}: {token_mean:,.0f} tokens, {resolved_rate:.1%}", (token_mean, resolved_rate), xytext=(8, 7), textcoords="offset points", fontsize=8)
    ax.set_xlabel("Mean total tokens per task")
    ax.set_ylabel("Resolved rate")
    ax.set_ylim(0, 1)
    style_axis(ax)
    ax.legend(loc="best")
    _save(fig, output, "fig_rq1_token_vs_accuracy", source_paths, "rq1_variant_token_accuracy")

    labels = ["CACTUS + test-aware", "No test-aware", "No semantic", "No iteration"]
    variants = ["cactus_test_aware", "cactus_no_test_aware", "cactus_no_semantic", "cactus_no_iteration"]
    rates = [float(np.mean([row["resolved"] for row in rq2[name]])) for name in variants]
    intervals = [_wilson(int(sum(row["resolved"] for row in rq2[name])), expected_tasks) for name in variants]
    error_low = [rate - interval[0] for rate, interval in zip(rates, intervals)]
    error_high = [interval[1] - rate for rate, interval in zip(rates, intervals)]
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    positions = np.arange(len(labels))
    colors = [COLORS["method"], COLORS["accent"], COLORS["baseline"], COLORS["error"]]
    ax.bar(positions, rates, color=colors, width=0.62, zorder=2)
    ax.errorbar(positions, rates, yerr=[error_low, error_high], fmt="none", ecolor=COLORS["text"], capsize=4, linewidth=1.2, zorder=3)
    for x, value in zip(positions, rates):
        ax.text(x, value + 0.025, f"{value:.1%}", ha="center", va="bottom", fontsize=8)
    ax.set_xticks(positions, labels, rotation=12, ha="right")
    ax.set_ylabel("Resolved rate")
    ax.set_ylim(0, max(0.2, max(rates, default=0) + 0.2))
    style_axis(ax)
    _save(fig, output, "fig_rq2_ablation_bars", source_paths, "rq2_ablation_wilson_intervals")

    forensics: list[dict[str, Any]] = []
    for line in forensics_path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            forensics.append(json.loads(line))
    unresolved = {str(row["task_id"]) for row in rq2["cactus_test_aware"] if not row["resolved"]}
    selected = [row for row in forensics if str(row.get("task_id")) in unresolved]
    if {str(row.get("task_id")) for row in selected} != unresolved or len(selected) != len(unresolved):
        raise ValueError("RQ3 forensics rows must cover each unresolved E1 task exactly once")
    require_reviewed_forensics(selected)
    categories = Counter(str(row.get("category")) for row in selected)
    coverage = sum(count for name, count in categories.items() if name in {"A", "B", "C", "D"}) / max(1, len(unresolved))
    if not unresolved or coverage < 0.90:
        raise ValueError(f"RQ3 forensics coverage {coverage:.1%} is below required 90%")
    category_names = ["A", "B", "C", "D", "pending_evidence"]
    counts = [categories.get(name, 0) for name in category_names]
    fig, ax = plt.subplots(figsize=(6.1, 3.6))
    bars = ax.barh(category_names, counts, color=[COLORS["method"], COLORS["accent"], COLORS["unresolved"], COLORS["error"], COLORS["neutral"] if "neutral" in COLORS else COLORS["grid"]])
    ax.invert_yaxis()
    for bar, count in zip(bars, counts):
        ax.text(count + 0.1, bar.get_y() + bar.get_height() / 2, f"{count} ({count / len(selected):.1%})", va="center", fontsize=8)
    ax.set_xlabel("Unresolved tasks")
    style_axis(ax)
    _save(fig, output, "fig_rq3_failure_taxonomy", [*source_paths, forensics_path], "rq3_evidence_classified_failures")

    tex = output / "table_main_results.tex"
    lines = _main_results_table_lines({**rq2, **rq1})
    tex.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    _provenance(tex, source_paths, transform_id="table_main_results_from_verified_runs")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--campaign-id", required=True, help="Frozen E1 campaign ID; prevents mixing historical runs")
    parser.add_argument("--forensics", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-tasks", type=int, default=500)
    args = parser.parse_args()
    rows = load_measured_rows(args.runs, campaign_id=args.campaign_id)
    generate(rows, args.output, expected_tasks=args.expected_tasks, forensics_path=args.forensics)
    print(f"generated RQ figures from {len(rows)} validated measured task runs in {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
