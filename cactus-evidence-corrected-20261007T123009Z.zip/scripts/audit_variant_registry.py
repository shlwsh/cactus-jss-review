#!/usr/bin/env python3
"""Strict publication audit for the canonical CACTUS variant registry."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_PRIMARY = {"cactus_full", "maximal_context"}
EXPECTED_BASELINES = {"lexical_bm25", "full_context"}
EXPECTED_ABLATIONS = {
    "cactus_no_symbol_graph",
    "cactus_no_budget_controller",
    "cactus_no_failure_recovery",
    "cactus_static_density",
}


def audit(registry_path: Path = ROOT / "paper/variant_registry.yaml") -> dict[str, object]:
    data = json.loads(registry_path.read_text(encoding="utf-8"))
    errors: list[str] = []
    if data.get("registry_version") != "v1.23":
        errors.append("registry_version must be v1.23")
    if data.get("frozen") is not True:
        errors.append("registry must remain frozen")
    primary = data.get("primary", [])
    baselines = data.get("baselines", [])
    ablations = data.get("ablations", [])
    primary_ids = {row.get("id") for row in primary if isinstance(row, dict)}
    baseline_ids = {row.get("id") for row in baselines if isinstance(row, dict)}
    ablation_ids = {row.get("id") for row in ablations if isinstance(row, dict)}
    if primary_ids != EXPECTED_PRIMARY:
        errors.append(f"primary IDs differ from frozen matrix: {sorted(primary_ids)}")
    if baseline_ids != EXPECTED_BASELINES:
        errors.append(f"baseline IDs differ from frozen matrix: {sorted(baseline_ids)}")
    if ablation_ids != EXPECTED_ABLATIONS:
        errors.append(f"ablation IDs differ from frozen matrix: {sorted(ablation_ids)}")
    if any(row.get("enabled") is True for row in baselines if row.get("id") == "full_context"):
        errors.append("legacy full_context alias must remain disabled")
    enabled = {
        row.get("id")
        for group in (primary, baselines, ablations)
        for row in group
        if isinstance(row, dict) and row.get("enabled") is True
    }
    return {
        "status": "pass" if not errors else "fail",
        "registry_version": data.get("registry_version"),
        "enabled_ids": sorted(enabled),
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registry", type=Path, default=ROOT / "paper/variant_registry.yaml")
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    try:
        result = audit(args.registry)
    except (OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "fail", "errors": [str(exc)]}, indent=2))
        return 2
    print(json.dumps(result, indent=2))
    return 2 if args.strict and result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
