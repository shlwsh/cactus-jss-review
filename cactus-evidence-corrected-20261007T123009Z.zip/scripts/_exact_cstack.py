"""Get exact _cstack text from prompt."""
import json
import re
import sys
from pathlib import Path

run = Path(sys.argv[1])
events = [json.loads(l) for l in (run / "trace" / "events.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
mc = next(e for e in events if e["type"] == "model_call")
prompt = mc["payload"]["prompt_text"]

# Find _cstack function with full body
m = re.search(r"def _cstack\(.*?\n(?:[ \t]+.*\n)+", prompt)
if m:
    print("=== _cstack as in PROMPT ===")
    print(repr(m.group()))
    print()
    print("=== pretty ===")
    print(m.group())

# Also find cright lines
print("\n=== cright lines ===")
for line in prompt.splitlines():
    if "cright" in line:
        print(repr(line))

# Find "return np.hstack" lines
print("\n=== np.hstack lines ===")
for line in prompt.splitlines():
    if "np.hstack" in line:
        print(repr(line))
