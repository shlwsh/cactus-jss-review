"""Bind frozen Lite-50 image digests to immutable F: drive archives.

The archives are intentionally kept outside the repository.  This tool only
records their byte hash/size and the content-addressed *OCI manifest* digest
that Docker exposes as ``docker image inspect .Id`` after ``docker load``; it
never loads or mutates Docker images.  The config blob digest is deliberately
not used as a runtime ID: it identifies image configuration, whereas Docker's
OCI image store addresses a loaded image by its manifest descriptor.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ARCHIVE_RE = re.compile(r"^batch-(?P<batch>\d+)-eval(?P<first>\d{3})(?:-eval(?P<last>\d{3}))?\.tar$")
DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{64}$")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def archive_span(path: Path) -> tuple[int, int]:
    match = ARCHIVE_RE.fullmatch(path.name)
    if not match:
        raise ValueError(f"invalid Lite-50 archive filename: {path.name}")
    first = int(match.group("first"))
    last = int(match.group("last") or match.group("first"))
    if last < first:
        raise ValueError(f"archive range is reversed: {path.name}")
    return first, last


def _runtime_image_ids(path: Path) -> list[str]:
    """Return OCI manifest digests in the archive's Docker-load order.

    ``manifest.json`` identifies each image by a config blob.  Docker exports
    multi-image archives with an OCI ``index.json`` that may list only one
    descriptor, while retaining every OCI manifest as a small blob.  Joining
    each manifest blob filename to its ``config.digest`` makes the mapping
    explicit and avoids relying on incomplete index order.
    """
    try:
        with tarfile.open(path, "r") as archive:
            docker_manifest = json.load(archive.extractfile("manifest.json"))
            index = json.load(archive.extractfile("index.json"))
            descriptors = index.get("manifests") if isinstance(index, dict) else None
            if not isinstance(descriptors, list) or not descriptors:
                raise ValueError("OCI index has no manifest descriptors")
            if any(
                not isinstance(descriptor, dict)
                or not isinstance(descriptor.get("digest"), str)
                or not DIGEST_RE.fullmatch(descriptor["digest"])
                for descriptor in descriptors
            ):
                raise ValueError("OCI index contains malformed manifest digest")
            by_config: dict[str, str] = {}
            for member in archive.getmembers():
                match = re.fullmatch(r"blobs/sha256/([0-9a-f]{64})", member.name)
                if match is None or not member.isfile() or member.size > 2 * 1024 * 1024:
                    continue
                blob = archive.extractfile(member)
                if blob is None:
                    raise ValueError("OCI archive member is unavailable")
                payload = blob.read()
                if hashlib.sha256(payload).hexdigest() != match.group(1):
                    raise ValueError("OCI manifest blob SHA-256 does not match its filename")
                try:
                    image_manifest = json.loads(payload)
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                config = image_manifest.get("config", {}).get("digest") if isinstance(image_manifest, dict) else None
                layers = image_manifest.get("layers") if isinstance(image_manifest, dict) else None
                if not isinstance(config, str) or not DIGEST_RE.fullmatch(config):
                    continue
                if not isinstance(layers, list):
                    continue
                if config in by_config:
                    raise ValueError("OCI archive maps one config digest to multiple manifests")
                by_config[config] = "sha256:" + match.group(1)
    except (KeyError, OSError, tarfile.TarError, json.JSONDecodeError) as exc:
        raise ValueError(f"unable to read OCI manifest from {path}") from exc
    if not isinstance(docker_manifest, list) or not docker_manifest:
        raise ValueError(f"archive manifest is empty: {path}")
    # BuildKit exports a single-image archive with an OCI *index* descriptor.
    # Docker exposes that index digest as ``docker image inspect .Id`` after
    # load, whereas the inner image-manifest digest is a different object.
    # Bind the descriptor itself for this unambiguous single-image shape.
    if (
        len(docker_manifest) == 1
        and isinstance(descriptors, list)
        and len(descriptors) == 1
        and descriptors[0].get("mediaType") == "application/vnd.oci.image.index.v1+json"
    ):
        descriptor_digest = descriptors[0]["digest"]
        return [descriptor_digest]
    ids: list[str] = []
    for row in docker_manifest:
        config = row.get("Config") if isinstance(row, dict) else None
        match = re.fullmatch(r"blobs/sha256/([0-9a-f]{64})", str(config))
        if not match:
            raise ValueError(f"archive has malformed config digest: {path}")
        config_digest = "sha256:" + match.group(1)
        runtime_id = by_config.get(config_digest)
        if runtime_id is None:
            raise ValueError(f"archive config has no OCI manifest descriptor: {path}")
        ids.append(runtime_id)
    return ids


def build(*, contract: Path, task_manifest: Path, archive_root: Path, output: Path, sidecar_root: Path | None = None) -> dict[str, Any]:
    frozen = json.loads(contract.read_text(encoding="utf-8"))
    tasks = [json.loads(line) for line in task_manifest.read_text(encoding="utf-8").splitlines() if line.strip()]
    images = frozen.get("images")
    if not isinstance(images, dict) or len(images) != 50 or len(tasks) != 50:
        raise ValueError("contract and inference manifest must both contain exactly 50 tasks")
    archive_records: list[dict[str, Any]] = []
    image_rows: list[dict[str, Any]] = []
    seen: set[int] = set()
    for archive in sorted(archive_root.glob("batch-*.tar")):
        first, last = archive_span(archive)
        positions = list(range(first, last + 1))
        runtime_ids = _runtime_image_ids(archive)
        if len(runtime_ids) != len(positions):
            raise ValueError(f"archive image count does not match filename range: {archive.name}")
        archive_hash = sha256(archive)
        archive_size = archive.stat().st_size
        archive_record = {
            "path": archive.as_posix(),
            "sha256": archive_hash,
            "size_bytes": archive_size,
            "eval_ids": [f"eval_{index:03d}" for index in positions],
        }
        archive_records.append(archive_record)
        for index, local_id in zip(positions, runtime_ids):
            if index in seen:
                raise ValueError(f"duplicate archive coverage for eval_{index:03d}")
            seen.add(index)
            entry = images.get(f"eval_{index:03d}")
            task = tasks[index - 1]
            if not isinstance(entry, dict) or entry.get("repository") != task.get("image_repository", entry.get("repository")):
                # The task manifest does not require image metadata; the frozen
                # contract remains the authoritative repository/digest binding.
                if not isinstance(entry, dict):
                    raise ValueError(f"contract image entry missing for eval_{index:03d}")
            if not isinstance(entry.get("digest"), str) or not DIGEST_RE.fullmatch(entry["digest"]):
                raise ValueError(f"contract image digest is malformed for eval_{index:03d}")
            image_rows.append({
                "eval_id": f"eval_{index:03d}",
                "task_id": task.get("task_id"),
                "repository": entry["repository"],
                "tag": entry.get("tag"),
                "digest": entry["digest"],
                "local_image_id": local_id,
                "archive_path": archive.as_posix(),
                "archive_sha256": archive_hash,
                "archive_size_bytes": archive_size,
            })
    if seen != set(range(1, 51)):
        missing = sorted(set(range(1, 51)) - seen)
        raise ValueError("Lite-50 archive coverage is incomplete: " + ", ".join(f"eval_{i:03d}" for i in missing))
    result: dict[str, Any] = {
        "schema_version": "1.0",
        "generated_at": utc_now(),
        "status": "READY_FOR_CONTRACT_BINDING",
        "cache_root": archive_root.resolve().as_posix(),
        "contract_path": contract.resolve().as_posix(),
        "contract_sha256": sha256(contract),
        "archive_count": len(archive_records),
        "image_count": len(image_rows),
        "archives": archive_records,
        "images": sorted(image_rows, key=lambda row: row["eval_id"]),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    # ``_image_lifecycle`` looks up the task row by repository category.  The
    # sidecar root may be separated from the immutable archive directory so a
    # rebinding never overwrites historic cache metadata.
    sidecar_root = (sidecar_root or archive_root).resolve()
    by_category: dict[str, list[dict[str, Any]]] = {}
    for row in result["images"]:
        category = str(row["task_id"]).split("__", 1)[0]
        by_category.setdefault(category, []).append({
            "task_id": row["task_id"],
            "image_ref": f"{row['repository']}:latest",
            "candidate_digest": row["digest"],
            "local_image_id": row["local_image_id"],
            "archive_path": row["archive_path"],
            "archive_sha256": row["archive_sha256"],
            "archive_size_bytes": row["archive_size_bytes"],
        })
    for category, entries in by_category.items():
        sidecar = sidecar_root / category / "local-manifest.json"
        sidecar.parent.mkdir(parents=True, exist_ok=True)
        sidecar.write_text(json.dumps({
            "schema_version": "1.0",
            "status": "READY_FOR_CONTRACT_BINDING",
            "generated_at": result["generated_at"],
            "cache_root": sidecar_root.as_posix(),
            "entries": sorted(entries, key=lambda row: row["task_id"]),
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--task-manifest", type=Path, required=True)
    parser.add_argument("--archive-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sidecar-root", type=Path)
    args = parser.parse_args()
    print(json.dumps(build(contract=args.contract, task_manifest=args.task_manifest, archive_root=args.archive_root, output=args.output, sidecar_root=args.sidecar_root), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
