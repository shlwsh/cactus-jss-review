"""Inspect first/last events to find correct field names."""
import json
from pathlib import Path
BASE = Path("experiments/runs/FACO-FULL-LITE50-RESUME-20261003T203555Z")
p = BASE / "astropy__astropy-12907" / "events.jsonl"
with p.open("r", encoding="utf-8") as f:
    events = [json.loads(line) for line in f]
print(f"Total events: {len(events)}")
print("--- First event (truncated) ---")
print(json.dumps(events[0], ensure_ascii=False)[:800])
print("--- Last event (truncated) ---")
print(json.dumps(events[-1], ensure_ascii=False)[:800])
print("--- 5 distinct event_type values ---")
keys = set()
for ev in events:
    keys.add(ev.get("event_type") or ev.get("type") or ev.get("event") or "?")
print(list(keys)[:5])
print("--- All keys in last event ---")
print(list(events[-1].keys()))
