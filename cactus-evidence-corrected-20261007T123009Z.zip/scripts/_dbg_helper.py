"""Directly observe the dict produced by the helper/raise template builders.

Diagnoses the indentation bug in _build_template_edit_for_helper_insert.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

import ast

source = (ROOT / "scripts" / "_trace_test_src.py").read_text(encoding="utf-8") if (ROOT / "scripts" / "_trace_test_src.py").exists() else None
# Use the on-disk source: extract _check_required_columns from a fresh checkout
import tempfile
from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]
ws = Path(tempfile.mkdtemp(prefix="cactus-diag-helper-"))
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)

src = (repo_path / "astropy" / "timeseries" / "core.py").read_text(encoding="utf-8")

# Find the method and target raise
tree = ast.parse(src)
method = None
raise_node = None
for cls in ast.walk(tree):
    if isinstance(cls, ast.ClassDef) and cls.name == "BaseTimeSeries":
        for child in cls.body:
            if isinstance(child, ast.FunctionDef) and child.name == "_check_required_columns":
                method = child
                for sub in ast.iter_child_nodes(child):
                    if isinstance(sub, ast.Raise):
                        # pick the raise at line 79 (the one with .format(... required_columns[0], ... self.colnames[0]))
                        if sub.lineno == 79:
                            raise_node = sub
                            break
                break

print(f"method lines {method.lineno}-{method.end_lineno}, body[0] lineno={method.body[0].lineno}")
print()

# Helper edit
helper_edit = mod._build_template_edit_for_helper_insert(src, method, "as_scalar_or_list_str")
print("=== helper_edit.old_statement ===")
print(helper_edit["old_statement"])
print()
print("=== helper_edit.replacement ===")
print(helper_edit["replacement"])
print()

# Need format_call
# Let's grab both raises
candidates = mod._find_misleading_raise_nodes(src, "astropy/timeseries/core.py")
print(f"candidates: {len(candidates)}")
# Pick the one with most [0] indices
best = max(candidates, key=lambda c: sum(
    1 for a in c[2].args
    if isinstance(a, ast.Subscript) and isinstance(a.slice, ast.Constant) and a.slice.value == 0
))
method_best, raise_best, fmt_best = best
print(f"best candidate: raise at line {raise_best.lineno}")

raise_edit = mod._build_template_edit_for_raise(src, method_best, raise_best, fmt_best)
print()
print("=== raise_edit.old_statement ===")
print(raise_edit["old_statement"])
print()
print("=== raise_edit.replacement ===")
print(raise_edit["replacement"])

import shutil
shutil.rmtree(ws, ignore_errors=True)
