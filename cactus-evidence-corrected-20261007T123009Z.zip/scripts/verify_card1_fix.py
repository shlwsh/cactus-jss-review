"""End-to-end verification for CACTUS 卡点① (path normalization fix).

Source of truth for the "real" case is
  experiments/diagnostic_selected_context.json
which captures the R1 dry-run ground truth for astropy__astropy-12907.

Behavior contract (from cactus_swebench_predict.py docstrings):
  - _path_matches_allowed:
      * exact path hit -> True
      * any allowed_paths element with the same basename (excluding generic
        filenames __init__.py / conftest.py) -> True
      * otherwise -> False
  - _path_normalize_to_allowed:
      * if any prefix of the path is in allowed_paths -> keep the path
      * else if stripping the single leading segment yields a path in
        allowed_paths AND the stripped segment is NOT a generic filename
        -> return the stripped path
      * otherwise -> keep the path

Usage:
  Set-Location E:\\work\\p5-acm\\acm
  & .\\.venv\\Scripts\\python.exe scripts\\verify_card1_fix.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

REPO_ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from cactus_swebench_predict import (  # noqa: E402
    _path_matches_allowed,
    _path_normalize_to_allowed,
)


def _banner(label: str) -> None:
    print("\n" + "=" * 64)
    print(label)
    print("=" * 64)


def verify_unit_functions() -> bool:
    _banner("UNIT TESTS: _path_matches_allowed / _path_normalize_to_allowed")
    allowed = {"modeling/separable.py", "io/fits/file.py", "utils/decorators.py"}

    # (label, path_in, expected_match, expected_normalize_to)
    cases = [
        ("exact match",                       "modeling/separable.py",               True,  "modeling/separable.py"),
        ("repo-qualified strips",             "astropy/modeling/separable.py",       True,  "modeling/separable.py"),
        # single-segment strip only, so deeper prefixes are NOT stripped
        ("deep prefix NOT stripped (1 strip max)", "x/y/io/fits/file.py",           True,  "x/y/io/fits/file.py"),
        ("bare basename",                     "separable.py",                        True,  "separable.py"),
        ("no match",                          "nope/missing.py",                     False, "nope/missing.py"),
        ("generic filename rejected",         "utils/__init__.py",                   False, "utils/__init__.py"),
        # leading generic segment refused by spec
        ("leading generic NOT stripped",      "__init__/separable.py",               True,  "__init__/separable.py"),
    ]

    ok = True
    for label, path, want_match, want_norm in cases:
        got_match = _path_matches_allowed(path, allowed)
        got_norm = _path_normalize_to_allowed(path, allowed)
        match_ok = got_match == want_match
        norm_ok = got_norm == want_norm
        status = "PASS" if (match_ok and norm_ok) else "FAIL"
        print(f"  [{status}] {label:38s} in={path!r:48s} match={got_match} norm={got_norm!r}")
        ok = ok and match_ok and norm_ok
    return ok


def verify_real_astropy_context() -> bool:
    _banner("REAL CONTEXT: astropy__astropy-12907 (from diagnostic_selected_context.json)")
    diag_path = REPO_ROOT / "experiments" / "diagnostic_selected_context.json"
    if not diag_path.exists():
        print(f"  [SKIP] {diag_path} not found")
        return True
    diag = json.loads(diag_path.read_text(encoding="utf-8"))
    selected = set(diag["selected_paths"])
    model_path = diag["model_path"]
    print(f"  selected_paths: {len(selected)} units")
    print(f"  model emitted : {model_path!r}")

    has_exact = model_path in selected
    basename_match = _path_matches_allowed(model_path, selected)
    normalized = _path_normalize_to_allowed(model_path, selected)

    print(f"  exact match for full path?   {has_exact}  (expected False per R1 evidence)")
    print(f"  basename alias match?        {basename_match}  (expected True after fix-A)")
    print(f"  normalize_to_allowed ->      {normalized!r}  (expected 'modeling/separable.py')")

    # Cross-check against the diagnostic verdict.
    verdict = diag.get("verdict", "")
    verdict_ok = "BASENAME_OK" in verdict
    print(f"  recorded verdict: {verdict}")

    ok = (
        has_exact is False
        and basename_match is True
        and normalized == "modeling/separable.py"
        and verdict_ok
    )
    print(f"  [{'PASS' if ok else 'FAIL'}] astropy R1 mismatch resolved by fixes A+B")
    return ok


def main() -> int:
    unit_ok = verify_unit_functions()
    real_ok = verify_real_astropy_context()
    print("\n" + "=" * 64)
    print(f"UNIT: {'PASS' if unit_ok else 'FAIL'}    REAL: {'PASS' if real_ok else 'FAIL'}")
    print("=" * 64)
    return 0 if (unit_ok and real_ok) else 1


if __name__ == "__main__":
    raise SystemExit(main())
