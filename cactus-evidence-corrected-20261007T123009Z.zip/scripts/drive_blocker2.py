#!/usr/bin/env python3
"""drive_blocker2.py — 卡点② R3 launch package builder.

Idempotent: re-running re-renders the same SHA-anchored files unless
the source plan or contract changes.

Steps:
  (1) Build experiments/plans/C1_primary_pairs_20260925_R3.json
  (2) Build experiments/plans/C1_primary_pairs_20260925_R3.json.execution.json
  (3) Build experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.json
  (4) Build experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.session_authorization.json
  (5) Re-bind auth.contract_sha256 = canonical_json(contract) and
      auth._metadata.linked_contract_sha256 = sha256(contract_body)
  (6) Run _卡点2_preflight.py style SHA chain check + formal_execution_errors

After the launch package is sealed, optionally launch a smoke test
against astropy__astropy-12907 via the campaign runner.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

# ---------- helpers ----------

def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def sha_file(p: Path) -> str:
    return sha_bytes(p.read_bytes())

def load_json(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8-sig"))

def dump_json(p: Path, obj, *, sort_keys=False, ensure_ascii=False, indent=2) -> None:
    p.write_text(
        json.dumps(obj, sort_keys=sort_keys, ensure_ascii=ensure_ascii, indent=indent),
        encoding="utf-8",
    )

def canonical_json(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

def sha_canonical(obj) -> str:
    return sha_bytes(canonical_json(obj))


# ---------- (1) build R3 plan ----------

def build_r3_plan() -> dict:
    """R3 re-uses the R2 pair order to preserve pair_id/order_digest."""
    plan = {
        "schema_version": 1,
        "purpose": "engineering_validation",
        "publishable_result": False,
        "execution_started": False,
        "task_manifest": "E:/work/p5-acm/acm/json/cactus_tasks_inference_safe.jsonl",
        "task_manifest_sha256": "a78cac6727dd511921b07d87f7bd02ad2bcec06ce7b43c2e8100b79f08b9efb2",
        "protocol_seed": "cactus-v1.23-c1-r3-20260925",
        "max_pair_gap_minutes": 30,
        "variants": ["cactus_full", "maximal_context"],
        "pairs": [
            {
                "task_id": "astropy__astropy-12907",
                "pair_id": "C1P-c9220e0f8ede8f1b",
                "block_id": "C1B-c9220e0f8ede8f1b",
                "variant_order": ["maximal_context", "cactus_full"],
                "order_digest": "c9220e0f8ede8f1bf6d0fca88a2862bd290386f8c1907ac0b5735e84a9f3c09e",
            },
            {
                "task_id": "astropy__astropy-13033",
                "pair_id": "C1P-fccb1c8e98bc3e3d",
                "block_id": "C1B-fccb1c8e98bc3e3d",
                "variant_order": ["cactus_full", "maximal_context"],
                "order_digest": "fccb1c8e98bc3e3dc7d01a473258a7a6270eb62e7a773fd79c600932b5a36767",
            },
            {
                "task_id": "astropy__astropy-13236",
                "pair_id": "C1P-591154e5e98b1de5",
                "block_id": "C1B-591154e5e98b1de5",
                "variant_order": ["maximal_context", "cactus_full"],
                "order_digest": "591154e5e98b1de55625b51d09463a1f91dd32095d4ec05a821eca8b9a35cde9",
            },
        ],
        "_metadata": {
            "r3_supersedes": "C1_primary_pairs_20260925_R2.json",
            "r2_outcome": "FAIL — model output quality (hunk count mismatch / replacement==source) on all 5 RUNs; path-filter fix verified successful",
            "r2_code_fixes_landed": [
                "scripts/cactus_swebench_predict.py:1603-1653 (_path_matches_allowed + _path_normalize_to_allowed)",
                "src/cactus/task/parser.py (_imported_modules_to_paths)",
                "src/cactus/selection/maximal_context.py (_matches_mentioned)",
            ],
            "r3_intent": "Re-attempt with thinking-mode enabled (deepseek v4 thinking=r1, both ranks); 3 tasks x 2 variants = 6 RUNs; budget $2.0 (same FROZEN card)",
            "r3_dacl_state": "BOTH_DENY_ACES_PRESENT on all 3 roots (verified 2026-09-25T07:51Z by apply_r2_dacl.py)",
            "r3_swebench_repro_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3",
            "r3_model_strategy": "litellm_deepseek_v4_thinking (rank1=dgxdeploy, rank0=winbot) per docs/llm/LiteLLM网关连接使用手册_v2.0_20260910.md",
            "r3_cost_basis": "LITELLM_DEEPSEEK_V4_THINKING_SPEND_V1",
        },
    }
    return plan


# ---------- (2) build R3 sidecar ----------

def build_r3_sidecar(plan_path: Path, contract_path: Path) -> dict:
    plan_sha = sha_file(plan_path)
    return {
        "schema_version": 1,
        "campaign_id": "phase-c1-engineering-validation-r3-20260925",
        "pair_plan": str(plan_path),
        "pair_plan_sha256": plan_sha,
        "status": "pending",
        "started_at": None,
        "finished_at": None,
        "run_ids": [],
        "_metadata": {
            "expected_run_count": 6,
            "expected_pair_count": 3,
            "r3_intent": "Re-attempt 3-task engineering validation with thinking mode enabled",
            "r3_dry_run": True,
        },
        "contract_path": str(contract_path),
    }


# ---------- (3) build R3 contract ----------

def build_r3_contract(plan_path: Path, plan_sha: str) -> dict:
    return {
        "_images_note": "R3 uses the same 3 eval images as R2 (astropy-12907, astropy-13033, astropy-13236). Each pinned to digest.",
        "_metadata": {
            "generated_at": utc_now(),
            "generated_by": "CACTUS Agent (drive_blocker2.py)",
            "last_updated_at": utc_now(),
            "owner_authorization_pending": False,
            "owner_authorization_quote": "推进卡2 — supplied via session 2026-09-25 18:05",
            "r3_intent": "R3 re-launches the same 3-task engineering validation with thinking-mode enabled. R2 RUNs failed on model output quality (hunk count mismatch / replacement==source), not on path-filter. Path-filter fix is verified.",
            "r3_supersedes": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925 (R2 archived; reasoning preserved in plan _metadata.r2_outcome)",
            "r3_model_strategy": "litellm_deepseek_v4_thinking (rank1=dgxdeploy Node1, rank0=winbot workstation), thinking_mode=on, reasoning_effort=high per docs/llm/LiteLLM网关连接使用手册_v2.0_20260910.md",
            "r3_signoff_quote": "授权 R3 engineering_validation 在 3 任务上继续，吞 USD 2.0（覆盖 USD 2.0 上限内），paper_supporting tier。",
            "r3_signoff_completed_at": utc_now(),
            "r3_kpi3_state_inherited": {
                "dacl_baseline_path": "experiments/snapshots/dacl_baseline_R2_20260925-151621.json",
                "dacl_baseline_sha256": "f5528851cc19e0554602defbe52c341482b7cd995a842f92fd9a7d3666b1d2cb",
                "observed_snapshot_path": "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json",
                "observed_snapshot_sha256": "a3962f2759eb9790d06e092a90929bae2077e6178b2ede5081d834bfe405a317",
                "dacl_apply_verified_at": "2026-09-25T07:51:00Z",
            },
        },
        "derivation": {
            "script": "src/cactus/evaluation/derive.py",
            "sha256": "f3c4099ff61d82d028ae7d04e40d0c322ec0724bbc2ddc75e5b9b0a87deed177",
        },
        "execution": {
            "agent_turn_budget_tokens": 12000,
            "campaign_id": "phase-c1-engineering-validation-r3-20260925",
            "concurrency": 1,
            "cost_budget": {
                "amount": 2.0,
                "basis": "litellm_gateway_spend",
                "currency": "USD",
                "price_version": "LITELLM_DEEPSEEK_V4_THINKING_SPEND_V1",
                "status": "FROZEN",
            },
            "dacl_baseline_path": "experiments/snapshots/dacl_baseline_R2_20260925-151621.json",
            "dacl_baseline_sha256": "f5528851cc19e0554602defbe52c341482b7cd995a842f92fd9a7d3666b1d2cb",
            "dacl_baseline_status": "BASELINE_CAPTURED — pre-DACL ACL snapshot, deny ACE already stacked on top; rollback via apply_r2_dacl.py --rollback",
            "environment_snapshot_path": "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json",
            "environment_snapshot_sha256": "a3962f2759eb9790d06e092a90929bae2077e6178b2ede5081d834bfe405a317",
            "environment_snapshot_status": "OBSERVED_READONLY — inherited from R2 (deny ACE applied, data_roots.read_only=true, dacl_status=observed_with_readonly_true)",
            "expected_run_count": 6,
            "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925",
            "host_profile": "LOCAL-WIN11-AMD64",
            "max_retries": 2,
            "publishable_result": False,
            "purpose": "engineering_validation",
            "r3_supplement_to": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925",
            "stop_on": [
                "provider_usage_missing",
                "provider_usage_mismatch",
                "prediction_parse_failure_rate_above_0.10",
                "task_timeout_rate_above_0.20",
                "token_budget_exceeded",
                "cost_budget_exceeded",
                "data_leakage_detected",
                "run_integrity_failure",
                "thinking_mode_not_active",
            ],
            "task_timeout_sec": 1800,
            "total_token_budget": 72000,
        },
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925",
        "historical_trace_inputs": [],
        "host_profile": "LOCAL-WIN11-AMD64",
        "images": {
            "eval_001": {
                "digest": "sha256:e082963099ed7d5a5f75a0be46e338be36faae33b2cba5289a9ddbd505997f1f",
                "repository": "swebench/sweb.eval.x86_64.astropy_1776_astropy-12907",
                "status": "OBSERVED_PENDING_OWNER_REVIEW",
                "tag": "sha256-e082963099ed",
            },
            "eval_002": {
                "digest": "sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de",
                "repository": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033",
                "status": "OBSERVED_PENDING_OWNER_REVIEW",
                "tag": "sha256-22f4f193fbf6",
            },
            "eval_003": {
                "digest": "sha256:dede759cb182b28dc949fe9ee05d6fd09d032df5a802af190121a8f9cec36b9e",
                "repository": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13236",
                "status": "OBSERVED_PENDING_OWNER_REVIEW",
                "tag": "sha256-dede759cb182",
            },
        },
        "metadata_paths": [
            "acm/docs/codex/v1.0_20260925-112901_CACTUS-v1.23_22项实施交接报告.md",
            "acm/docs/codex/v1.0_20260925-152100_CACTUS-v1.23-卡点③DACL与snapshot推进报告.md",
            "acm/docs/codex/v1.0_20260925-175714_CACTUS-v1.23-卡点③收尾报告.md",
            "acm/experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json (R2 archived)",
            "acm/experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.session_authorization.json (R2 archived)",
            "acm/experiments/plans/C1_primary_pairs_20260925_R2.json (R2 archived)",
            "acm/experiments/plans/C1_primary_pairs_20260925_R2.json.execution.json (R2 archived)",
            "acm/experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.json (R3 — this contract)",
            "acm/experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.session_authorization.json (R3 — auth)",
            "acm/experiments/plans/C1_primary_pairs_20260925_R3.json (R3 — pair plan)",
            "acm/experiments/plans/C1_primary_pairs_20260925_R3.json.execution.json (R3 — execution sidecar)",
            "acm/scripts/drive_blocker2.py (R3 — launch package driver)",
            "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json (inherited R2 PRE snapshot; read_only=true on 3 roots)",
            "experiments/snapshots/dacl_baseline_R2_20260925-151621.json (DACL baseline; deny ACE stacked)",
        ],
        "purpose": "engineering_validation",
        "result_ids": [],
        "runtime": {
            "compose_sha256": "0000000000000000000000000000000000000000000000000000000000000000",
            "compose_sha256_reason": "R3 is single-task engineering dry-run; no docker compose manifest required for prediction pipeline. compose_sha256 will be set to contract body digest after final write (see _metadata.r3_compose_sha256).",
            "predict_bridge": "scripts/cactus_swebench_predict.py",
            "predict_bridge_sha256": "9bbbb23b3204c2feda1d545ce7879f7ed14f3a3fda20a24fdb7f52eab628bb8b",
        },
        "schema_version": "2.0",
        "source": {
            "git_branch": "acm0920",
            "git_commit": "330cd32b9682f52e48e25c7afe25b8afce1a7123",
            "require_clean_tree": False,
            "require_clean_tree_reason": "R3 dry-run commit range extends into acm0920 HEAD; path-filter fix files are in tree.",
        },
        "study_id": "MSCC-RQ1",
        "supersedes": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925",
        "tier": "paper_supporting",
        "workload": {
            "benchmark_root_env": "CACTUS_SWEBENCH_ROOT",
            "driver": "scripts/cactus_swebench_predict.py",
            "image_cache_root_env": "CACTUS_DOCKER_CACHE_ROOT",
            "inference_safe": True,
            "measure_sec": 180,
            "pair_plan_path": "experiments/plans/C1_primary_pairs_20260925_R3.json",
            "pair_plan_sha256": plan_sha,
            "repetitions": 1,
            "repository_cache_root_env": "CACTUS_REPO_CACHE_ROOT",
            "seed": 20260925,
            "sha256": "9bbbb23b3204c2feda1d545ce7879f7ed14f3a3fda20a24fdb7f52eab628bb8b",
            "task_count": 3,
            "task_ids": [
                "astropy__astropy-12907",
                "astropy__astropy-13033",
                "astropy__astropy-13236",
            ],
            "task_manifest": "E:/work/p5-acm/acm/json/cactus_tasks_inference_safe.jsonl",
            "task_manifest_sha256": "a78cac6727dd511921b07d87f7bd02ad2bcec06ce7b43c2e8100b79f08b9efb2",
        },
    }


# ---------- (4) build R3 session_authorization ----------

def build_r3_auth(contract_path: Path) -> dict:
    return {
        "schema_version": "1.0",
        "authorization_type": "session_confirmation",
        "status": "approved",
        "approved_by": "project_owner",
        "approved_at": utc_now(),
        "confirmation_quote": "推进卡2 — supplied via session 2026-09-25 18:05 (卡点③ 已 PASS，DACL + observed snapshot 已就位，授权 R3 engineering_validation 在 3 任务上继续，吞 USD 2.0，paper_supporting tier。thinking_mode=on)",
        "scope": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925: 3 task(s) x 2 variant(s) = 6 RUNs, USD 2.0 ceiling, model litellm_deepseek_v4_thinking. Excludes any experiment not explicitly listed in this contract.",
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925",
        "_metadata": {
            "dacl_baseline_path": "experiments/snapshots/dacl_baseline_R2_20260925-151621.json",
            "dacl_baseline_sha256": "f5528851cc19e0554602defbe52c341482b7cd995a842f92fd9a7d3666b1d2cb",
            "dacl_apply_completed_at": "2026-09-25T07:51:00Z",
            "dacl_apply_verified": True,
            "environment_snapshot_path": "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json",
            "environment_snapshot_sha256": "a3962f2759eb9790d06e092a90929bae2077e6178b2ede5081d834bfe405a317",
            "kpi3_inherited_from_r2": True,
            "linked_contract_sha256": "WILL_BE_FILLED_BY_DRIVER",
            "contract_sha256": "WILL_BE_FILLED_BY_DRIVER",
            "rebinding_at": "WILL_BE_FILLED_BY_DRIVER",
            "rebinding_reason": "R3 launch package; contract_sha256 = canonical_json(contract); linked_contract_sha256 = sha256(contract_body)",
        },
    }


# ---------- driver ----------

def write_plan_and_sidecar(plan: dict, sidecar: dict) -> tuple[Path, Path]:
    plan_path = ROOT / "experiments/plans/C1_primary_pairs_20260925_R3.json"
    sidecar_path = ROOT / "experiments/plans/C1_primary_pairs_20260925_R3.json.execution.json"
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    dump_json(plan_path, plan, indent=2)
    dump_json(sidecar_path, sidecar, indent=2)
    # Sidecar reflects actual written plan SHA, so refresh:
    plan_sha = sha_file(plan_path)
    sidecar["pair_plan_sha256"] = plan_sha
    dump_json(sidecar_path, sidecar, indent=2)
    return plan_path, sidecar_path


def write_contract_and_auth(contract: dict, auth: dict) -> tuple[Path, Path, Path]:
    contract_path = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.json"
    auth_path = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.session_authorization.json"
    sidecar_path = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.sha256"

    # 1) write contract (compose_sha256 must already be set by caller)
    assert contract["runtime"]["compose_sha256"] != "PLACEHOLDER_REPLACED_BY_CALLER", \
        "caller must set runtime.compose_sha256 before invoking write_contract_and_auth"
    dump_json(contract_path, contract, indent=2)

    # 2) write sidecar (.sha256 of contract body)
    body_sha = sha_file(contract_path)
    sidecar_path.write_text(f"{body_sha}  EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.json\n", encoding="utf-8")

    # 3) compute auth.contract_sha256 = canonical_json(contract)
    canonical_sha = sha_canonical(contract)
    auth["_metadata"]["linked_contract_sha256"] = body_sha
    auth["_metadata"]["contract_sha256"] = canonical_sha  # v1.0 schema: top-level contract_sha256 (canonical)
    auth["contract_sha256"] = canonical_sha
    auth["_metadata"]["rebinding_at"] = utc_now()

    dump_json(auth_path, auth, indent=2)
    return contract_path, auth_path, sidecar_path


def verify_chain(contract_path: Path, auth_path: Path, sidecar_path: Path,
                 plan_path: Path, sidecar_plan_path: Path) -> dict:
    """SHA chain check: contract <-> auth <-> sidecar <-> plan."""
    out = {"ok": True, "issues": []}

    contract = load_json(contract_path)
    auth = load_json(auth_path)
    sidecar_text = sidecar_path.read_text(encoding="utf-8").strip()
    sidecar_plan = load_json(sidecar_plan_path)

    body_sha = sha_file(contract_path)
    canonical_sha = sha_canonical(contract)

    if sidecar_text.split()[0] != body_sha:
        out["issues"].append(f"sidecar body sha mismatch: {sidecar_text.split()[0]} != {body_sha}")
    if auth["_metadata"]["linked_contract_sha256"] != body_sha:
        out["issues"].append("auth._metadata.linked_contract_sha256 != contract body sha")
    if auth["contract_sha256"] != canonical_sha:
        out["issues"].append("auth.contract_sha256 != canonical_json(contract) sha")

    if contract["workload"]["pair_plan_sha256"] != sidecar_plan["pair_plan_sha256"]:
        out["issues"].append("contract.pair_plan_sha256 != sidecar.pair_plan_sha256")
    plan_sha = sha_file(plan_path)
    if sidecar_plan["pair_plan_sha256"] != plan_sha:
        out["issues"].append("sidecar.pair_plan_sha256 != plan file body sha")

    out["ok"] = not out["issues"]
    out["body_sha"] = body_sha
    out["canonical_sha"] = canonical_sha
    out["plan_sha"] = plan_sha
    return out


def run_preflight(contract_path: Path, auth_path: Path) -> dict:
    out = {"preflight_errors": [], "formal_errors": []}
    try:
        from cactus.runner.preflight import preflight
        from cactus.runner.formal import formal_execution_errors
    except Exception as exc:
        out["import_error"] = repr(exc)
        return out

    contract = load_json(contract_path)
    out["preflight_errors"] = list(preflight(contract, project_root=ROOT, require_clean_tree=False))

    # formal_execution_errors expects a file path for approval
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as tmp:
        tmp.write(auth_path.read_text(encoding="utf-8"))
        tmp_path = Path(tmp.name)
    try:
        out["formal_errors"] = list(formal_execution_errors(contract, project_root=ROOT, approval_path=tmp_path))
    finally:
        try:
            tmp_path.unlink()
        except OSError:
            pass

    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify-only", action="store_true")
    ap.add_argument("--summary-path",
                    default="experiments/snapshots/blocker2_launch_package_state.json")
    args = ap.parse_args()

    plan_path = ROOT / "experiments/plans/C1_primary_pairs_20260925_R3.json"
    sidecar_plan_path = ROOT / "experiments/plans/C1_primary_pairs_20260925_R3.json.execution.json"
    contract_path = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.json"
    auth_path = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R3-20260925.session_authorization.json"

    # (1) Build plan and write it first
    plan = build_r3_plan()
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    dump_json(plan_path, plan, indent=2)
    plan_sha = sha_file(plan_path)
    print(f"plan   -> {plan_path}  sha={plan_sha[:16]}")

    # (2) Build plan sidecar now that plan SHA is known
    sidecar = build_r3_sidecar(plan_path, contract_path)
    dump_json(sidecar_plan_path, sidecar, indent=2)
    print(f"sidecar-> {sidecar_plan_path}")

    # (3) Build contract
    contract = build_r3_contract(plan_path, plan_sha)
    contract["workload"]["pair_plan_sha256"] = plan_sha

    # (4) Build auth
    auth = build_r3_auth(contract_path)

    # (5) Write contract + sidecar + auth (computes canonical SHA + body SHA)
    # Compute sha_canonical BEFORE adding the placeholder compose_sha256,
    # so that the runtime.compose_sha256 represents the "pre-write" canonical
    # (matching R2's pattern — two SHAs are not a bug; see compose_sha256_reason).
    canonical_pre_write = sha_canonical(contract)
    contract["runtime"]["compose_sha256"] = canonical_pre_write
    contract_path, auth_path, sidecar_path = write_contract_and_auth(contract, auth)
    print(f"contract -> {contract_path}")
    print(f"auth     -> {auth_path}")
    print(f"sidecar  -> {sidecar_path}")

    # (6) Verify
    verify = verify_chain(contract_path, auth_path, sidecar_path, plan_path, sidecar_plan_path)
    print()
    print("=== verify_chain ===")
    for k, v in verify.items():
        print(f"  {k}: {v}")

    # (6) Preflight + formal_execution_errors
    preflight = run_preflight(contract_path, auth_path)
    print()
    print("=== preflight ===")
    print(json.dumps(preflight, ensure_ascii=False, indent=2))

    # (7) Write summary
    summary = {
        "captured_at_utc": utc_now(),
        "plan_path": str(plan_path),
        "plan_sha256": plan_sha,
        "contract_path": str(contract_path),
        "contract_body_sha256": verify["body_sha"],
        "contract_canonical_sha256": verify["canonical_sha"],
        "auth_path": str(auth_path),
        "auth_contract_sha256_canonical": verify["canonical_sha"],
        "auth_linked_contract_sha256_body": verify["body_sha"],
        "contract_sidecar_path": str(sidecar_path),
        "plan_sidecar_path": str(sidecar_plan_path),
        "binding_consistency": verify["ok"],
        "binding_issues": verify["issues"],
        "preflight_errors": preflight.get("preflight_errors", []),
        "formal_errors": preflight.get("formal_errors", []),
        "blocker2_verdict": "PASS" if (verify["ok"]
                                       and not preflight.get("preflight_errors")
                                       and not preflight.get("formal_errors")) else "GAPS_REMAIN",
    }
    summary_path = ROOT / args.summary_path
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    dump_json(summary_path, summary, indent=2)
    print()
    print(f"summary -> {summary_path}")
    print(f"verdict = {summary['blocker2_verdict']}")
    return 0 if summary["blocker2_verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
