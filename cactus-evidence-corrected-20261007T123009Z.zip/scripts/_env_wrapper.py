"""Fail-closed checks for session-injected CACTUS environment variables.

This module never reads a secret from disk, returns secret values, or prints
values. Use ``bun run mykey -- <command>`` to inject the session environment.
"""

from __future__ import annotations

import os
import sys
from collections.abc import Mapping


REQUIRED_SESSION_KEYS = (
    "CACTUS_LITELLM_API_KEY",
    "CACTUS_LITELLM_BILLING_API_KEY",
    "CACTUS_LITELLM_LOG_KEY_ALIAS",
    "CACTUS_LITELLM_BILLING_KEY_ALIAS",
    "CACTUS_LITELLM_BILLING_SSH_HOST",
    "CACTUS_LITELLM_BILLING_SSH_USER",
    "CACTUS_LITELLM_BILLING_SSH_PASSWORD",
)


def missing_session_keys(environ: Mapping[str, str] | None = None) -> tuple[str, ...]:
    """Return missing variable names only; never return the values."""
    source = os.environ if environ is None else environ
    return tuple(key for key in REQUIRED_SESSION_KEYS if not source.get(key))


def verify_session_env(environ: Mapping[str, str] | None = None) -> None:
    """Raise a safe error when the mykey session wrapper was not used."""
    missing = missing_session_keys(environ)
    if missing:
        raise RuntimeError(
            "Required session variables are missing: " + ", ".join(missing)
        )


if __name__ == "__main__":
    try:
        verify_session_env()
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(3) from None
    print(f"Session environment ready ({len(REQUIRED_SESSION_KEYS)} variables present).")
