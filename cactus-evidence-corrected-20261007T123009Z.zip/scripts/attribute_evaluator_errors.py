"""Build an evidence-backed evaluator-error attribution ledger.

The script never infers a failure cause from an error count alone. Missing
task-level evidence is explicitly reported as ``pending_evidence``.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def classify(row: dict[str, str], evidence_root: Path | None) -> tuple[str, str]:
    task_id = row["task"]
    if evidence_root is None:
        return "pending_evidence", "No task-level run bundle root was supplied"
    candidates = list(evidence_root.glob(f"**/*{task_id}*"))
    if not candidates:
        return "pending_evidence", "No sealed task-level run bundle was found"
    text = " ".join(str(path).lower() for path in candidates)
    for keyword, category in (("timeout", "timeout"), ("gateway", "gateway"), ("billing", "billing"), ("docker", "environment"), ("eval", "evaluator"), ("patch", "patch")):
        if keyword in text:
            return category, f"Matched evidence path keyword: {keyword}"
    return "needs_manual_review", "Bundle found but no deterministic category signal"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("paper/data/final_task_outcomes.csv"))
    parser.add_argument("--output", type=Path, default=Path("docs/evaluator_error_attribution.csv"))
    parser.add_argument("--evidence-root", type=Path)
    args = parser.parse_args()
    rows: list[dict[str, str]] = []
    with args.input.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row.get("error") == "1":
                category, note = classify(row, args.evidence_root)
                rows.append({"task": row["task"], "category": category, "status": "pending" if category == "pending_evidence" else "review", "note": note})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["task", "category", "status", "note"], lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    summary = {
        "error_rows": len(rows),
        "pending_evidence": sum(r["category"] == "pending_evidence" for r in rows),
        "source": str(args.input),
        "source_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "evidence_root": str(args.evidence_root) if args.evidence_root else None,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "status": "pending_evidence" if any(r["category"] == "pending_evidence" for r in rows) else "classified",
    }
    args.output.with_suffix(".summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
