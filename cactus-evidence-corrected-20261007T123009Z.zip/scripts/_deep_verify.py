#!/usr/bin/env python3
"""Deep verify all provenance for bibliography chain."""
import json
import hashlib
from pathlib import Path

ROOT = Path('.')

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_sidecar_recursive(artifact_path, depth=0, seen=None):
    """Recursively verify sidecar and all inputs."""
    if seen is None:
        seen = set()
    
    artifact = ROOT / artifact_path
    if artifact in seen:
        return []
    seen.add(artifact)
    
    sidecar = artifact.with_name(artifact.name + '.provenance.json')
    if not sidecar.exists():
        return [f"missing: {artifact_path}"]
    
    payload = json.loads(sidecar.read_text(encoding='utf-8'))
    errors = []
    
    # Check artifact hash
    actual_artifact_sha = sha256(artifact)
    if payload.get('artifact_sha256') != actual_artifact_sha:
        errors.append(f"artifact hash mismatch: {artifact_path} (expected {payload.get('artifact_sha256')[:16]}..., got {actual_artifact_sha[:16]}...)")
    
    # Check inputs
    for inp in payload.get('inputs', []):
        inp_path = ROOT / inp['path']
        if inp_path.exists():
            actual_sha = sha256(inp_path)
            if actual_sha != inp['sha256']:
                errors.append(f"input hash mismatch: {inp['path']} (expected {inp['sha256'][:16]}..., got {actual_sha[:16]}...)")
            # Recursively verify
            if inp_path.suffix == '.json' or inp_path.suffix == '.bbl':
                sub_errors = verify_sidecar_recursive(inp['path'], depth+1, seen)
                errors.extend(sub_errors)
    
    return errors

# Verify publication_bibliography.bbl
print("=== Verifying publication_bibliography.bbl ===")
errors = verify_sidecar_recursive('paper/data/publication_bibliography.bbl')
if errors:
    print("ERRORS:")
    for e in errors:
        print(f"  {e}")
else:
    print("OK")

# Also verify cited_papers_manifest.json directly
print("\n=== Verifying cited_papers_manifest.json ===")
manifest_path = 'paper/data/scholar/cited_papers_manifest.json'
manifest = ROOT / manifest_path
manifest_prov = manifest.with_name(manifest.name + '.provenance.json')
if manifest_prov.exists():
    payload = json.loads(manifest_prov.read_text(encoding='utf-8'))
    actual_sha = sha256(manifest)
    if payload.get('artifact_sha256') != actual_sha:
        print(f"artifact hash mismatch: {actual_sha[:16]}... vs {payload.get('artifact_sha256')[:16]}...")
    else:
        print("artifact hash OK")
    for inp in payload.get('inputs', []):
        inp_path = ROOT / inp['path']
        if inp_path.exists():
            actual_sha = sha256(inp_path)
            if actual_sha != inp['sha256']:
                print(f"input mismatch: {inp['path']} - expected {inp['sha256'][:16]}..., got {actual_sha[:16]}...")
else:
    print("no provenance file")
