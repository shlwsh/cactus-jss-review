"""Export full git repos from each Docker image and populate local mirrors."""
from __future__ import annotations

import subprocess
import time
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
REPO_CACHE = ROOT / "experiments" / "repo_cache"
MOUNT = ROOT / "tmp" / "docker_bundles" / "mount"
MOUNT.mkdir(parents=True, exist_ok=True)
MOUNT_STR = str(MOUNT).replace("\\", "/")

IMAGE_TASKS = [
    ("swebench/sweb.eval.x86_64.astropy_1776_astropy-12907:78f471b", "astropy__astropy", "d16bfe05a744909de4b27f5875fe0d4ed41ce607"),
    ("swebench/sweb.eval.x86_64.astropy_1776_astropy-13033:78f471b", "astropy__astropy", "298ccb478e6bf092953bca67a3d29dc6c35f6752"),
    ("swebench/sweb.eval.x86_64.astropy_1776_astropy-13236:78f471b", "astropy__astropy", "6ed769d58d89380ebaa1ef52b300691eefda8928"),
]


def run_docker(image: str, cmd: str, timeout: int = 300) -> tuple[int, str, str]:
    r = subprocess.run(
        ["docker", "run", "--rm", "-v", f"{MOUNT_STR}:/out", image, "bash", "-c", cmd],
        capture_output=True, text=True, timeout=timeout,
    )
    return r.returncode, r.stdout, r.stderr


def verify_commits(repo_path: Path, commits: list[str]) -> dict:
    results = {}
    for c in commits:
        r = subprocess.run(
            ["git", "-C", str(repo_path), "cat-file", "-t", f"{c}" + "{commit}"],
            capture_output=True, text=True, timeout=10,
        )
        results[c] = r.returncode == 0
    return results


def main():
    print("=" * 70)
    print("从 Docker 镜像导出完整 git repos 并补全本地镜像")
    print("=" * 70)

    # Existing local mirror
    local_mirror = REPO_CACHE / "astropy__astropy.git"
    existing_ok = {}
    if local_mirror.exists():
        print(f"\n现有本地镜像: {local_mirror}")
        existing_ok = verify_commits(local_mirror, [c for _, _, c in IMAGE_TASKS])
        for c, ok in existing_ok.items():
            print(f"  {c[:12]}: {'OK' if ok else '缺失'}")

    all_ok = True
    for image, repo_name, base_commit in IMAGE_TASKS:
        print(f"\n{'='*50}")
        print(f"  Image: {image.split('/')[-1]}")
        print(f"  Base:  {base_commit[:12]}")

        # Check if already OK
        if existing_ok.get(base_commit):
            print(f"  已存在，无需导出")
            continue

        # Create bundle in Docker
        bundle_name = f"{repo_name.replace('/', '_')}_{base_commit[:12]}.bundle"
        bundle_path = MOUNT / bundle_name

        print(f"  创建 bundle...")
        rc, out, err = run_docker(
            image,
            f"cd /testbed && git bundle create /out/{bundle_name} --all 2>&1",
            timeout=300,
        )
        if rc != 0:
            print(f"  FAIL: {err[:200]}")
            all_ok = False
            continue

        if not bundle_path.exists():
            print(f"  FAIL: bundle 文件不存在")
            all_ok = False
            continue

        print(f"  Bundle: {bundle_path.stat().st_size // 1024 // 1024} MB")

        # Clone from bundle to temp dir
        tmp_clone = ROOT / "tmp" / f"clone_{int(time.time())}"
        tmp_clone.mkdir(parents=True, exist_ok=True)

        print(f"  克隆 bundle...")
        r2 = subprocess.run(
            ["git", "clone", str(bundle_path), str(tmp_clone)],
            capture_output=True, text=True, timeout=300,
        )
        if r2.returncode != 0:
            print(f"  FAIL: {r2.stderr[:200]}")
            all_ok = False
            continue

        # Verify this clone has the base commit
        commits_ok = verify_commits(tmp_clone, [base_commit])
        if not commits_ok.get(base_commit):
            print(f"  FAIL: base commit 不在 bundle 中")
            all_ok = False
            continue

        print(f"  Base commit 验证: OK")

        # Push to local mirror (or replace it)
        print(f"  推送至本地镜像...")
        r3 = subprocess.run(
            ["git", "-C", str(tmp_clone), "push", str(local_mirror), "--mirror", "--force"],
            capture_output=True, text=True, timeout=120,
        )
        if r3.returncode != 0:
            print(f"  FAIL: push failed: {r3.stderr[:200]}")
            # Fallback: replace mirror
            import shutil
            bak = local_mirror.with_suffix(".git.bak")
            if local_mirror.exists():
                local_mirror.rename(bak)
            tmp_clone.rename(local_mirror)
            print(f"  替换镜像 (备份到 {bak.name})")
        else:
            print(f"  推送成功")

        # Cleanup
        try:
            shutil.rmtree(tmp_clone)
        except Exception:
            pass
        try:
            bundle_path.unlink()
        except Exception:
            pass

    # Final verification
    print("\n" + "=" * 70)
    print("最终验证:")
    final_ok = verify_commits(local_mirror, [c for _, _, c in IMAGE_TASKS])
    for _, _, c in IMAGE_TASKS:
        ok = final_ok.get(c, False)
        print(f"  {c[:12]}: {'OK' if ok else '缺失'}")
        if not ok:
            all_ok = False

    if all_ok:
        print("\n所有镜像 repo 已补全！可运行 R4 预测。")
    else:
        print("\n部分镜像缺失，需进一步处理。")

    return 0 if all_ok else 1


if __name__ == "__main__":
    import shutil
    import sys
    sys.exit(main())
