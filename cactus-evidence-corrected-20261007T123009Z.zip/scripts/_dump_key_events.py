import json, sys
fn = sys.argv[1]
with open(fn, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]
print('Total events:', len(events))
for i, e in enumerate(events):
    t = e.get('type', '?')
    p = e.get('payload', {})
    if t in ('prediction_sites_rejected', 'prediction_rejected', 'prediction_exhausted',
             'member_replacement_decided', 'final_repair_decided',
             'site_selection_decided', 'candidate_emitted', 'no_op_edit',
             'responsibility_chain', 'plan_proposed', 'engine_propose',
             'select_decision', 'generate_decision', 'diagnose_decision',
             'repair_replacement_decided', 'trace_summary'):
        s = json.dumps(p, ensure_ascii=False)
        if len(s) > 800:
            s = s[:800] + '...'
        print(f'[{i:3d} seq={e.get("seq"):3d}] {t}:')
        print(f'    {s}')
