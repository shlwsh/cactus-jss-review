"""Read-only JSS submission checks; author facts and artifact checks are separate."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.check_publication_pdf import check as check_pdf


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def author_issues(record, manuscript_sha256):
    issues = []
    authors = record.get('authors', [])
    if len(authors) != 2:
        issues.append('authors: confirm both manuscript authors')
    for index, author in enumerate(authors):
        for key in ('manuscript_name', 'email', 'organization', 'addressline', 'city', 'postcode', 'country', 'credit_roles', 'competing_interest_disclosure'):
            value = author.get(key)
            if not value or 'AUTHOR_INPUT_NEEDED' in str(value):
                issues.append(f'authors[{index}].{key}')
        for key in ('information_confirmed', 'final_manuscript_approved'):
            if author.get(key) is not True:
                issues.append(f'authors[{index}].{key}')
    if record.get('funding', {}).get('author_confirmed') is not True:
        issues.append('funding.author_confirmed')
    for key in ('specific_grants', 'commercial_or_internal_support', 'grant_identifiers', 'funders_role'):
        if record.get('funding', {}).get(key) is None:
            issues.append('funding.' + key + ': require explicit disclosure (empty list or none is allowed)')
    if record.get('publication_declarations', {}).get('prior_publication_or_preprint_details') is None:
        issues.append('publication_declarations.prior_publication_or_preprint_details')
    for key in ('original_work', 'not_under_concurrent_consideration', 'all_authors_approve_submission', 'third_party_rights_review_completed'):
        if record.get('publication_declarations', {}).get(key) is not True:
            issues.append('publication_declarations.' + key)
    for key in ('author_confirmed', 'human_review_and_editing_completed', 'authors_accept_full_responsibility'):
        if record.get('ai_use', {}).get(key) is not True:
            issues.append('ai_use.' + key)
    confirmation = record.get('confirmation_record', {})
    for key in ('confirmed_by', 'confirmed_at_utc', 'source'):
        if not confirmation.get(key):
            issues.append('confirmation_record.' + key)
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z', str(confirmation.get('confirmed_at_utc', ''))):
        issues.append('confirmation_record.confirmed_at_utc: require UTC to the second')
    if confirmation.get('final_manuscript_sha256') != manuscript_sha256:
        issues.append('confirmation_record.final_manuscript_sha256: does not bind current source')
    return issues


def artifact_metadata_issues(release, author_record):
    """A series DOI or previous release never identifies a new candidate."""
    issues = []
    version_doi = release.get('version_doi')
    if (not re.fullmatch(r'10\.\d{4,9}/\S+', str(version_doi or ''))
            or version_doi in (release.get('concept_doi'), release.get('previous_version_doi'))):
        issues.append('review_release.version_doi: require exact current immutable version DOI')
    if release.get('release_status') != 'public_verified':
        issues.append('review_release.release_status: current candidate not publicly verified')
    artifact = author_record.get('review_artifact', {})
    if author_record.get('manuscript_version') != release.get('paper_version'):
        issues.append('author record manuscript version differs from release')
    for key, expected in [('new_version_doi', version_doi), ('archival_series_doi', release.get('concept_doi')),
                          ('planned_release_url', release.get('release_url'))]:
        if artifact.get(key) != expected:
            issues.append('author record review_artifact.' + key + ': metadata mismatch')
    if artifact.get('public_access_and_download_verified') is not True:
        issues.append('author record: current public access/download not verified')
    return issues


def verify_binding(binding, root):
    path = Path(binding['path'])
    path = path if path.is_absolute() else root / path
    expected = binding.get('sha256', '')
    if not re.fullmatch(r'[a-f0-9]{64}', expected) or not path.is_file() or sha(path) != expected:
        raise ValueError('release file binding mismatch: ' + str(path))
    return path


def release_issues(record, root, pdf, review_zip):
    issues = []
    try:
        if record.get('status') != 'PASS' or record.get('public_access_verified') is not True:
            issues.append('public release/download verification not PASS')
        for key, expected in (('manuscript_pdf', pdf), ('review_zip', review_zip)):
            actual = verify_binding(record['bindings'][key], root)
            if expected is None or sha(actual) != sha(expected):
                issues.append(key + ': release differs from requested input')
        fresh = record.get('fresh_environment', {})
        if fresh.get('status') != 'PASS' or not fresh.get('logs'):
            issues.append('fresh environment reproduction/logs not PASS')
        for binding in fresh.get('logs', []):
            verify_binding(binding, root)
    except (KeyError, ValueError, OSError) as exc:
        issues.append(str(exc))
    return issues


def evaluate(root=ROOT, author_record=None, manuscript_pdf=None, review_zip=None, release_record=None, cover_letter=None):
    root = Path(root)
    paper = root / 'paper'
    main = paper / 'main.tex'
    text = main.read_text(encoding='utf-8')
    technical, checks = [], {}
    lines = [line.strip() for line in (paper / 'submission/highlights.txt').read_text(encoding='utf-8').splitlines() if line.strip()]
    checks['highlights'] = {'count': len(lines), 'lengths': list(map(len, lines))}
    if not 3 <= len(lines) <= 5 or any(len(line) > 85 for line in lines):
        technical.append('highlights: require 3-5 bullets, each at most 85 characters')
    if not re.search(r'\\documentclass\[[^]]*authoryear[^]]*\]\{(?:style/)?elsarticle\}', text) or '\\journal{Journal of Systems and Software}' not in text:
        technical.append('manuscript must use JSS elsarticle authoryear style')
    pdf = Path(manuscript_pdf) if manuscript_pdf else paper / 'build/main.pdf'
    try:
        checks['manuscript_pdf'] = {**check_pdf(pdf), 'path': str(pdf), 'sha256': sha(pdf)}
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        technical.append('manuscript PDF: ' + str(exc))
    letter = Path(cover_letter) if cover_letter else paper / 'submission/v1.39_20261007-081100_投稿信草稿.pdf'
    try:
        info = subprocess.run(['pdfinfo', str(letter)], check=True, capture_output=True).stdout.decode('utf-8')
        if not re.search(r'Pages:\s+1\b', info):
            technical.append('cover letter must be one page')
        letter_text = subprocess.run(['pdftotext', str(letter), '-'], check=True, capture_output=True).stdout.decode('utf-8')
        checks['cover_letter'] = {'path': str(letter), 'sha256': sha(letter), 'draft': 'AUTHOR_INPUT_NEEDED' in letter_text, 'pages': int(re.search(r'Pages:\s+(\d+)', info).group(1))}
    except (OSError, subprocess.SubprocessError) as exc:
        technical.append('cover letter PDF: ' + str(exc))
    drafts = []
    checks['declarations'] = {}
    for filename in ('competing_interest_draft.txt', 'funding_draft.txt', 'credit_draft.txt', 'generative_ai_draft.txt'):
        path = paper / 'submission' / filename
        if not path.is_file():
            technical.append('missing declaration: ' + filename)
            continue
        draft = 'AUTHOR_INPUT_NEEDED' in path.read_text(encoding='utf-8')
        checks['declarations'][filename] = {'sha256': sha(path), 'state': 'draft' if draft else 'text_complete_requires_author_record'}
        if draft:
            drafts.append('author-approved declaration required: ' + filename)
    record_path = Path(author_record) if author_record else paper / 'submission/author_confirmation.template.json'
    record = json.loads(record_path.read_text(encoding='utf-8-sig'))
    needs = author_issues(record, sha(main)) + drafts
    if record.get('review_artifact', {}).get('distribution_terms_confirmed') is not True:
        needs.append('review_artifact.distribution_terms_confirmed')
    # A non-placeholder PDF can still contain explicitly pending declarations.
    for heading in ('Declaration of Competing Interest', 'Funding', 'CRediT authorship contribution statement',
                    'Declaration of generative AI and AI-assisted technologies in the manuscript preparation process'):
        section = re.search(r'\\section\*\{' + re.escape(heading) + r'\}(.+?)(?=\\section|\\appendix|\\bibliographystyle)', text, re.S)
        if section is None or re.search(r'awaits? confirmation|awaits? author confirmation|must confirm|not assert|await confirmation', section.group(1), re.I):
            needs.append('manuscript declaration pending: ' + heading)
    if checks.get('cover_letter', {}).get('draft'):
        needs.append('author-approved cover letter required')
    release = release_issues(json.loads(Path(release_record).read_text(encoding='utf-8-sig')), root, pdf, Path(review_zip) if review_zip else None) if release_record else ['release verification record not supplied']
    metadata = json.loads((paper / 'review_release.json').read_text(encoding='utf-8'))
    release += artifact_metadata_issues(metadata, record)
    return {'generated_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'), 'role': 'submission readiness; never formal experiment authorization',
            'submission_ready': not (technical or needs or release), 'status': 'technical_blocked' if technical else 'needs_author_input' if needs else 'needs_release_verification' if release else 'ready',
            'author_record_sha256': sha(record_path), 'technical_issues': technical, 'author_input_needed': needs, 'release_issues': release, 'checks': checks}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('author-record', 'manuscript-pdf', 'review-zip', 'release-record', 'cover-letter', 'output'):
        parser.add_argument('--' + name, type=Path)
    args = parser.parse_args()
    result = evaluate(author_record=args.author_record, manuscript_pdf=args.manuscript_pdf, review_zip=args.review_zip, release_record=args.release_record, cover_letter=args.cover_letter)
    if args.output:
        with args.output.open('x', encoding='utf-8') as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
            handle.write('\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['submission_ready'] else 1 if result['technical_issues'] else 2)
