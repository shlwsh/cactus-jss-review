"""验证工程验证与生产环境算法代码完全一致."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

# 必须完全一致的算法文件（相对 acm 根目录）
ALGORITHM_FILES = [
    "src/cactus/validation/completeness_validator.py",
    "src/cactus/validation/truncation_detector.py",
    "src/cactus/validation/feedback_generator.py",
    "src/cactus/prediction/self_correcting_predictor.py",
    "configs/models/lite50_v3_dual_insurance.json",
]


def get_acm_root() -> Path:
    """获取 acm 仓库根目录."""
    # 优先使用脚本所在目录的上一级
    candidate = Path(__file__).resolve().parent.parent
    if (candidate / "src" / "cactus").exists():
        return candidate
    cwd = Path.cwd()
    if (cwd / "src" / "cactus").exists():
        return cwd
    if (cwd / "acm" / "src" / "cactus").exists():
        return cwd / "acm"
    return candidate


def verify_algorithm_consistency(
    algorithm_files: list[str],
    base_dir: Path | None = None,
) -> tuple[bool, dict]:
    """验证算法文件存在且计算哈希一致.

    Returns:
        (is_consistent, hash_map)
    """
    root = base_dir or get_acm_root()
    hash_map: dict[str, str] = {}

    for file_rel in algorithm_files:
        path = root / file_rel
        if not path.exists():
            return False, {"error": f"文件不存在: {path}"}

        with open(path, "rb") as f:
            content = f.read()

        sha256 = hashlib.sha256(content).hexdigest()
        hash_map[file_rel] = sha256

    return True, hash_map


def assert_algorithm_consistency(base_dir: Path | None = None) -> dict[str, str]:
    """断言算法一致性（工程验证与生产必须通过）."""
    is_consistent, result = verify_algorithm_consistency(ALGORITHM_FILES, base_dir=base_dir)

    if not is_consistent:
        raise AssertionError(f"算法文件不一致: {result.get('error')}")

    print("✅ 算法一致性验证通过")
    print("工程验证与生产环境运行完全相同的算法代码")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return result


if __name__ == "__main__":
    try:
        assert_algorithm_consistency()
    except Exception as exc:
        print(f"❌ 验证失败: {exc}", file=sys.stderr)
        sys.exit(1)
