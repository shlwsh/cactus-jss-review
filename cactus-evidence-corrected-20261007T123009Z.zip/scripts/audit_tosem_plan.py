"""Audit CACTUS TOSEM v2.1 phase requirements against current evidence.

The audit is deliberately evidence-based: source modules and planning files
are reported as implemented, while experiment phases remain incomplete until
machine-readable observed results and passing gates exist.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]


def _exists(relative: str) -> bool:
    return (ROOT / relative).exists()


def _json(relative: str) -> dict[str, Any]:
    path = ROOT / relative
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _phase(phase: str, status: str, evidence: list[str], missing: list[str], note: str) -> dict[str, Any]:
    return {"phase": phase, "status": status, "evidence": evidence, "missing": missing, "note": note}


def audit() -> dict[str, Any]:
    selector = _json("analysis/context_selector_validation.json")
    replay = _json("analysis/evaluator_replay_observed_summary.json")
    pilot_gate = _json("analysis/phase_c_gate.json")
    matrix = _json("artifacts/phase_c_matrix.json")

    phases = [
        _phase(
            "phase0_freeze",
            "complete" if all(_exists(path) for path in ("artifacts/repo_inventory.md", "artifacts/baseline_snapshot.json", "artifacts/current_protocol.json")) else "incomplete",
            [path for path in ("artifacts/repo_inventory.md", "artifacts/baseline_snapshot.json", "artifacts/current_protocol.json") if _exists(path)],
            [path for path in ("artifacts/repo_inventory.md", "artifacts/baseline_snapshot.json", "artifacts/current_protocol.json") if not _exists(path)],
            "Repository inventory and the 500-task baseline snapshot are required before formal execution.",
        ),
        _phase(
            "phase1_failure_attribution",
            "complete" if replay.get("pending_historical_error_task_count") == 0 else "partial",
            [path for path in ("src/cactus/evaluation/taxonomy_v2.py", "src/cactus/evaluation/replay.py", "analysis/evaluator_replay_observed_summary.json") if _exists(path)],
            ["task-level evaluator replay evidence for all historical evaluator-error tasks"] if replay.get("pending_historical_error_task_count", 466) else [],
            f"Observed replay coverage is {replay.get('replayed_historical_error_task_count', 0)}/{replay.get('historical_evaluator_error_count', 466)} historical errors.",
        ),
        _phase(
            "phase2_algorithm",
            "complete" if all(_exists(path) for path in ("src/cactus/retrieval/coverage.py", "src/cactus/retrieval/marginal_utility.py", "src/cactus/retrieval/static_density.py")) else "incomplete",
            [path for path in ("src/cactus/retrieval/coverage.py", "src/cactus/retrieval/marginal_utility.py", "src/cactus/retrieval/static_density.py") if _exists(path)],
            [path for path in ("src/cactus/retrieval/coverage.py", "src/cactus/retrieval/marginal_utility.py", "src/cactus/retrieval/static_density.py") if not _exists(path)],
            "Algorithm modules are implemented and covered by offline tests; no effectiveness claim follows from this check.",
        ),
        _phase(
            "phase3_parameter_freeze",
            "complete" if selector.get("status") == "pass" and _exists("config/frozen_selector_v2.1.yaml") else "partial",
            [path for path in ("config/frozen_selector_v2.1.yaml", "config/frozen_selector_v2.1.lock.json", "analysis/context_selector_validation.json", "artifacts/parameter_freeze_report.md") if _exists(path)],
            ["passing selector validation and sensitivity evidence"] if selector.get("status") != "pass" else [],
            f"Selector validation status: {selector.get('status', 'missing')}.",
        ),
        _phase(
            "phase4_baselines_pilot",
            "complete" if pilot_gate.get("status") == "PASS" else "blocked",
            [path for path in ("src/cactus/selection/maximal_context.py", "src/cactus/selection/lexical_bm25.py", "src/cactus/selection/cactus_full.py", "artifacts/phase_c_matrix.json", "analysis/phase_c_gate.json") if _exists(path)],
            ["50-task Pilot observed results", "EVR >= 0.95", "sealed bundle failure = 0", "billing missing <= 5%", "budget violation = 0"],
            f"Current matrix={matrix.get('status', 'missing')}, Pilot gate={pilot_gate.get('status', 'missing')}.",
        ),
    ]

    for phase_name, required in (
        ("phase5_main_experiment", ("results/main_paired_results.csv", "results/main_task_level_metrics.csv", "results/main_validity_summary.json")),
        ("phase6_ablation", ("results/ablation_results.csv",)),
        ("phase7_budget_scan", ("results/budget_sweep.csv",)),
        ("phase8_reproducibility", ("results/reproducibility_runs.csv", "results/hash_consistency.csv")),
    ):
        present = [path for path in required if _exists(path)]
        phases.append(_phase(phase_name, "complete" if len(present) == len(required) else "pending", present, [path for path in required if path not in present], "Formal observed results are required; planning artifacts do not satisfy this phase."))

    stats_files = ("analysis/mcnemar_results.json", "analysis/bootstrap_intervals.json", "analysis/holm_corrected_ablation.json", "analysis/effect_sizes.json")
    stats_statuses = [_json(path).get("status") for path in stats_files if _exists(path)]
    phases.append(_phase("phase9_statistics", "complete" if stats_statuses and all(status == "observed" for status in stats_statuses) else "pending", [path for path in stats_files if _exists(path)], ["evaluator-valid paired result rows"] if not stats_statuses or any(status != "observed" for status in stats_statuses) else [], "Statistics must be derived from evaluator-valid paired observations."))

    paper_evidence = [path for path in ("paper/main.tex", "docs/paper_tables/table_main.tex", "docs/paper_tables/table_ablation.tex", "docs/paper_claims_matrix.md") if _exists(path)]
    phases.append(_phase("phase10_paper", "partial" if paper_evidence else "incomplete", paper_evidence, ["real observed tables and figures"], "Paper engineering is present, but pending cells must remain pending until formal results exist."))

    incomplete = [item["phase"] for item in phases if item["status"] not in {"complete"}]
    return {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "plan": "CACTUS TOSEM v2.1",
        "status": "complete" if not incomplete else "incomplete",
        "completed_phase_count": sum(item["status"] == "complete" for item in phases),
        "phase_count": len(phases),
        "incomplete_phases": incomplete,
        "phases": phases,
        "note": "This audit distinguishes implementation/planning evidence from observed formal experiment evidence and never upgrades pending data.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "analysis" / "tosem_plan_audit.json")
    args = parser.parse_args()
    result = audit()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
