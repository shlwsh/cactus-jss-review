"""Show seq 31, 39, 47, 55, 63 replacement prompts and feedback."""
import json
from pathlib import Path

p = Path("experiments/runs/SMOKE-12708-20261003T213916Z/django__django-12708/events.jsonl")
with p.open("r", encoding="utf-8") as f:
    events = [json.loads(line) for line in f]
for ev in events:
    seq = ev.get("seq", 0)
    if seq in (31, 39, 47, 55, 63, 71, 79, 87):
        t = ev.get("type")
        payload = ev.get("payload", {})
        prompt = payload.get("prompt_text", "")
        if "SITES:" in prompt:
            # site selection
            print(f"\n[{t} seq={seq}] (SITES phase) ot={payload.get('output_tokens')}")
            print(f"  prompt tail: {prompt[-600:]!r}")
            print(f"  RESP: {payload.get('response_text','')[:200]!r}")
        elif "replacements" in prompt.lower() or "JSON" in prompt:
            # replacement
            print(f"\n[{t} seq={seq}] (REPLACEMENT phase) ot={payload.get('output_tokens')}")
            # show last 1000 chars of prompt (the feedback area)
            tail = prompt[-1000:]
            print(f"  prompt tail: {tail!r}")
            print(f"  RESP start: {payload.get('response_text','')[:300]!r}")
