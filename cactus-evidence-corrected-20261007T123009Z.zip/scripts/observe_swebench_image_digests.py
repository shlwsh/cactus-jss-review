"""Observe immutable Docker manifest digests for an inference-safe SWE-bench manifest.

The observer reads only task identifiers and evaluator image references.  It
does not pull image layers, invoke a model, or persist registry credentials.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import re
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib import parse, request


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TASKS = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
DEFAULT_OUTPUT = ROOT / "artifacts" / "swebench_verified_78f471b_image_digest_observation.json"
DEFAULT_LOCAL_CACHE = Path("E:/docker-bak/cactus/pilot50")
_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
_ACCEPT = ", ".join(
    (
        "application/vnd.oci.image.index.v1+json",
        "application/vnd.docker.distribution.manifest.list.v2+json",
        "application/vnd.oci.image.manifest.v1+json",
        "application/vnd.docker.distribution.manifest.v2+json",
    )
)


class DigestResolutionError(RuntimeError):
    """Registry lookup failed without exposing response bodies or credentials."""


Resolver = Callable[[str, str, float], str]


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _split_image_ref(image_ref: str) -> tuple[str, str]:
    if not image_ref or "@" in image_ref:
        raise ValueError(f"image reference must be a tagged repository, not a digest: {image_ref!r}")
    final = image_ref.rsplit("/", 1)[-1]
    if ":" not in final:
        raise ValueError(f"image reference has no explicit tag: {image_ref!r}")
    repository, tag = image_ref.rsplit(":", 1)
    if not repository or not tag:
        raise ValueError(f"invalid image reference: {image_ref!r}")
    return repository, tag


def _json_request(url: str, *, headers: dict[str, str], timeout: float) -> tuple[dict[str, Any], dict[str, str]]:
    try:
        with request.urlopen(request.Request(url, headers=headers), timeout=timeout) as response:
            body = response.read()
            response_headers = {key.lower(): value for key, value in response.headers.items()}
    except Exception as exc:  # pragma: no cover - exercised through resolver integration
        raise DigestResolutionError(f"registry request failed: {type(exc).__name__}") from exc
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DigestResolutionError("registry returned non-JSON token response") from exc
    if not isinstance(payload, dict):
        raise DigestResolutionError("registry token response is not an object")
    return payload, response_headers


def resolve_registry_digest(repository: str, tag: str, timeout: float) -> str:
    """Resolve a Docker Hub manifest digest without downloading image layers."""
    token_url = "https://auth.docker.io/token?" + parse.urlencode(
        {"service": "registry.docker.io", "scope": f"repository:{repository}:pull"}
    )
    token_payload, _ = _json_request(token_url, headers={"Accept": "application/json"}, timeout=timeout)
    token = token_payload.get("token") or token_payload.get("access_token")
    if not isinstance(token, str) or not token:
        raise DigestResolutionError("registry token response has no token")
    manifest_url = f"https://registry-1.docker.io/v2/{repository}/manifests/{tag}"
    try:
        with request.urlopen(
            request.Request(
                manifest_url,
                headers={"Accept": _ACCEPT, "Authorization": "Bearer " + token},
            ),
            timeout=timeout,
        ) as response:
            digest = response.headers.get("Docker-Content-Digest", "")
            response.read()
    except Exception as exc:  # pragma: no cover - exercised through resolver integration
        raise DigestResolutionError(f"manifest request failed: {type(exc).__name__}") from exc
    if not _DIGEST.fullmatch(digest):
        raise DigestResolutionError("registry returned no complete Docker-Content-Digest")
    return digest


def _load_images(task_manifest: Path, *, expected_images: int) -> list[tuple[str, str]]:
    if expected_images < 1:
        raise ValueError("expected_images must be positive")
    seen: dict[str, str] = {}
    for number, line in enumerate(task_manifest.read_text(encoding="utf-8").splitlines(), 1):
        try:
            task = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSONL at line {number}") from exc
        if not isinstance(task, dict):
            raise ValueError(f"task at line {number} is not an object")
        task_id = task.get("task_id") or task.get("instance_id")
        image_ref = task.get("image")
        if not isinstance(task_id, str) or not task_id or not isinstance(image_ref, str) or not image_ref:
            raise ValueError(f"task at line {number} lacks task_id or image")
        _split_image_ref(image_ref)
        existing = seen.setdefault(image_ref, task_id)
        if existing != task_id:
            raise ValueError(f"evaluator image is shared by multiple tasks: {image_ref}")
    if len(seen) != expected_images:
        raise ValueError(f"expected {expected_images} unique evaluator images, found {len(seen)}")
    return sorted(((task_id, image_ref) for image_ref, task_id in seen.items()), key=lambda item: item[1])


def _portable_manifest_path(task_manifest: Path) -> str:
    """Persist a logical source name rather than a machine-specific path."""
    try:
        return task_manifest.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return "external-materialized-benchmark/" + task_manifest.name


def _load_local_digests(cache_root: Path | None) -> dict[str, str]:
    """Read only canonical cache manifests; quarantine material is excluded."""
    if cache_root is None:
        return {}
    candidates = [cache_root / "shared" / "base-manifest.json"]
    candidates.extend(sorted(cache_root.glob("*/manifest.json")))
    digests: dict[str, str] = {}
    for path in candidates:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        values = payload.get("image_digests") if isinstance(payload, dict) else None
        if isinstance(values, dict):
            for image_ref, digest in values.items():
                if isinstance(image_ref, str) and isinstance(digest, str) and _DIGEST.fullmatch(digest):
                    digests[image_ref] = digest
    return digests


def _load_resume_records(output: Path, source_sha256: str) -> dict[str, dict[str, Any]]:
    """Reuse only complete records from the same immutable source manifest."""
    try:
        payload = json.loads(output.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict) or payload.get("source_manifest", {}).get("sha256") != source_sha256:
        return {}
    values = payload.get("images")
    if not isinstance(values, list):
        return {}
    return {
        str(item["image_ref"]): item
        for item in values
        if isinstance(item, dict)
        and isinstance(item.get("image_ref"), str)
        and isinstance(item.get("digest"), str)
        and _DIGEST.fullmatch(item["digest"])
    }


def _load_docker_local_digests(image_refs: list[str]) -> dict[str, str]:
    """Read RepoDigests from the local Docker store without contacting a registry."""
    digests: dict[str, str] = {}
    for image_ref in image_refs:
        try:
            result = subprocess.run(
                ["docker", "image", "inspect", image_ref],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
            payload = json.loads(result.stdout) if result.returncode == 0 else []
        except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError):
            continue
        if not isinstance(payload, list) or not payload or not isinstance(payload[0], dict):
            continue
        repo_digests = payload[0].get("RepoDigests")
        if not isinstance(repo_digests, list):
            continue
        candidates = [
            str(value).rsplit("@", 1)[1]
            for value in repo_digests
            if isinstance(value, str) and "@" in value and _DIGEST.fullmatch(value.rsplit("@", 1)[1])
        ]
        if len(set(candidates)) == 1:
            digests[image_ref] = candidates[0]
    return digests


def _resolve_one(
    index: int,
    task_id: str,
    image_ref: str,
    *,
    resolver: Resolver,
    timeout: float,
    retries: int,
) -> dict[str, Any]:
    repository, tag = _split_image_ref(image_ref)
    for attempt in range(1, retries + 1):
        try:
            digest = resolver(repository, tag, timeout)
            return {
                "id": f"eval_{index:03d}",
                "task_id": task_id,
                "image_ref": image_ref,
                "repository": repository,
                "tag": tag,
                "digest": digest,
                "status": "OBSERVED_REGISTRY_MANIFEST",
                "attempts": attempt,
            }
        except DigestResolutionError as exc:
            if attempt == retries:
                return {
                    "id": f"eval_{index:03d}",
                    "task_id": task_id,
                    "image_ref": image_ref,
                    "repository": repository,
                    "tag": tag,
                    "digest": None,
                    "status": "UNRESOLVED",
                    "attempts": attempt,
                    "error_code": str(exc).split(":", 1)[0],
                }
            time.sleep(min(10.0, 0.5 * (2 ** (attempt - 1))))
    raise AssertionError("unreachable")


def _atomic_write(path: Path, contents: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", newline="\n", dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(contents)
    temporary.replace(path)


def observe(
    task_manifest: Path,
    output: Path,
    *,
    expected_images: int = 500,
    workers: int = 4,
    timeout: float = 30.0,
    retries: int = 3,
    force: bool = False,
    local_cache_root: Path | None = None,
    docker_local: bool = True,
    resume: bool = False,
    resolver: Resolver = resolve_registry_digest,
) -> dict[str, Any]:
    """Generate a digest observation document and an adjacent SHA-256 sidecar."""
    if workers < 1 or retries < 1 or timeout <= 0:
        raise ValueError("workers, retries, and timeout must be positive")
    if output.exists() and not force and not resume:
        raise FileExistsError(f"refusing to overwrite existing observation: {output}")
    task_bytes = task_manifest.read_bytes()
    images = _load_images(task_manifest, expected_images=expected_images)
    source_sha256 = hashlib.sha256(task_bytes).hexdigest()
    cached = _load_local_digests(local_cache_root)
    resumed = _load_resume_records(output, source_sha256) if resume and output.exists() else {}
    docker_cached = _load_docker_local_digests([image_ref for _, image_ref in images]) if docker_local else {}
    records: list[dict[str, Any]] = []
    pending: list[tuple[int, str, str]] = []
    for index, (task_id, image_ref) in enumerate(images, 1):
        digest = cached.get(image_ref) or docker_cached.get(image_ref)
        source = "LOCAL_CACHE" if cached.get(image_ref) else ("DOCKER_LOCAL" if digest else None)
        if not digest and image_ref in resumed:
            digest = str(resumed[image_ref]["digest"])
            source = "RESUMED_OBSERVATION"
        if digest:
            repository, tag = _split_image_ref(image_ref)
            records.append({"id": f"eval_{index:03d}", "task_id": task_id, "image_ref": image_ref, "repository": repository, "tag": tag, "digest": digest, "status": f"OBSERVED_{source}", "attempts": 0})
        else:
            pending.append((index, task_id, image_ref))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [
            executor.submit(
                _resolve_one,
                index,
                task_id,
                image_ref,
                resolver=resolver,
                timeout=timeout,
                retries=retries,
            )
            for index, task_id, image_ref in pending
        ]
        for future in futures:
            records.append(future.result())
    records.sort(key=lambda item: item["id"])
    resolved = [record for record in records if isinstance(record.get("digest"), str) and _DIGEST.fullmatch(str(record["digest"]))]
    payload = {
        "schema_version": "1.0",
        "generated_at": _utc_now(),
        "status": "READY_FOR_CONTRACT_CANDIDATE" if len(resolved) == expected_images else "BLOCKED_MISSING_IMAGE_DIGEST",
        "source_manifest": {
            "path": _portable_manifest_path(task_manifest),
            "sha256": source_sha256,
            "task_count": expected_images,
            "inference_safe": True,
            "excluded_fields": ["patch", "test_patch"],
        },
        "observation": {
            "method": "docker-registry-v2-manifest-get",
            "registry": "registry-1.docker.io",
            "image_layers_downloaded": False,
            "model_calls": 0,
            "billing_calls": 0,
        },
        "expected_image_count": expected_images,
        "observed_image_count": len(resolved),
        "local_cache_reused_count": sum(record["status"] in {"OBSERVED_LOCAL_CACHE", "OBSERVED_DOCKER_LOCAL"} for record in records),
        "docker_local_reused_count": sum(record["status"] == "OBSERVED_DOCKER_LOCAL" for record in records),
        "resumed_observation_count": sum(record["status"] == "OBSERVED_RESUMED_OBSERVATION" for record in records),
        "registry_lookup_count": len(pending),
        "images": records,
    }
    serialized = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    _atomic_write(output, serialized)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    _atomic_write(output.with_suffix(output.suffix + ".sha256"), f"{digest}  {output.name}\n")
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", type=Path, default=DEFAULT_TASKS)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--expected-images", type=int, default=500)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--local-cache-root", type=Path, default=DEFAULT_LOCAL_CACHE)
    parser.add_argument("--no-docker-local", action="store_true", help="do not inspect the local Docker image store")
    parser.add_argument("--resume", action="store_true", help="reuse complete records from an existing observation with the same source hash")
    args = parser.parse_args()
    result = observe(
        args.tasks,
        args.output,
        expected_images=args.expected_images,
        workers=args.workers,
        timeout=args.timeout,
        retries=args.retries,
        force=args.force,
        local_cache_root=args.local_cache_root,
        docker_local=not args.no_docker_local,
        resume=args.resume,
    )
    print(json.dumps({key: result[key] for key in ("status", "expected_image_count", "observed_image_count")}, ensure_ascii=False))
    return 0 if result["status"] == "READY_FOR_CONTRACT_CANDIDATE" else 2


if __name__ == "__main__":
    raise SystemExit(main())
