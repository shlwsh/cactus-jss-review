"""Build the actual prompt that would be sent to the LLM for R4-13033.

Replays the prompt-assembly logic from cactus_swebench_predict.py without
actually calling the LLM.  Used to verify:
- which augmentations are present
- the prompt head & tail as the model will see them
- any missing / contradictory instructions
"""
import json
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from cactus.adapters.benchmark import load_manifest
from cactus.context.repair_focus import build_focused_context
from cactus.context.repair_sites import build_repair_sites

# Load task
TASKS_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(TASKS_MANIFEST)}
task = tasks["astropy__astropy-13033"]

print(f"task_id: {task.task_id}")
print(f"base_commit: {task.base_commit}")
print(f"repo_id: {task.repo_id}")
print(f"issue_text (first 800 chars):\n{task.issue_text[:800]}\n")

# Check augmentations
from cactus_swebench_predict import (
    _build_semantic_hint,
    _docker_commit_acknowledgment,
    _STATEMENT_EDIT_FEW_SHOT,
    _classify_issue_type,
    _ISSUE_TYPE_KEYWORDS,
    _SEMANTIC_HINTS,
)
archetype = _classify_issue_type(task.issue_text)
print(f"=== Detected archetype: {archetype} ===")
print(f"--- semantic hint ---\n{_build_semantic_hint(task.issue_text)}")
print(f"--- commit ack ---\n{_docker_commit_acknowledgment(task)}")
print(f"--- few-shot example head ---\n{_STATEMENT_EDIT_FEW_SHOT[:500]}")
print(f"--- few-shot example tail ---\n{_STATEMENT_EDIT_FEW_SHOT[-500:]}")

# Check if old_statement FROM the previous failed run could be valid
# by ensuring the hint + few-shot includes the inner-helper direction
print("\n=== checking few-shot for 'inner helper' guidance ===")
if "as_scalar_or_list_str" in _STATEMENT_EDIT_FEW_SHOT:
    print("  YES: few-shot uses as_scalar_or_list_str as the helper name")
else:
    print("  NO: few-shot does not mention inner helper")

if "inner helper" in _build_semantic_hint(task.issue_text).lower():
    print("  YES: semantic hint mentions inner helper")
else:
    print("  NO: semantic hint does NOT mention inner helper")

# Check whether the previous failed old_statement pattern would now be a no-op
print("\n=== reproducing the no-op old_statement test ===")
import importlib
mod = importlib.import_module("cactus_swebench_predict")
print(f"  module file: {mod.__file__}")
print(f"  has _try_parse_with_quote_recovery: {hasattr(mod, '_try_parse_with_quote_recovery')}")
print(f"  has _normalize_source_segment: {'_normalize_source_segment' in open(mod.__file__, encoding='utf-8').read()}")
