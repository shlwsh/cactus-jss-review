"""Read 11910 and 12125 task details."""
import json
fpath = r'E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_inference_safe.jsonl'
print('Reading:', fpath)
with open(fpath, encoding='utf-8') as f:
    for line in f:
        d = json.loads(line)
        tid = d.get('task_id', '')
        if tid in ('django__django-11910', 'django__django-12125'):
            print('=' * 70)
            print(f'TASK: {tid}')
            print('=' * 70)
            print('keys:', list(d.keys()))
            print()
            print('--- issue_text (first 3000) ---')
            print((d.get('issue_text') or '')[:3000])
            print()
            print('--- base_commit:', d.get('base_commit'))
            print('--- repo_id:', d.get('repo_id'))
            print('--- test_command:', d.get('test_command'))
            src = d.get('source_fields', {})
            print('--- source_fields:', src)
            print()
