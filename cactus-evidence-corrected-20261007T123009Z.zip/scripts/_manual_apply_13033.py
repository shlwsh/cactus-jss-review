"""Manually apply model's patch and run test to confirm 13033 behavior."""
from pathlib import Path
import tempfile
import subprocess
import sys
import shutil

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest = list(load_manifest(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"))
task = next(t for t in manifest if t.task_id == "astropy__astropy-13033")
ws = Path(tempfile.mkdtemp(prefix="cactus-manual-"))
repo = checkout_base_commit(task, cache_root=Path(r"E:\cactus-data\repo-cache"), workspace_root=ws, allow_network_fetch=True)
print(f"repo: {repo}")

# Show core.py lines 70-82 before patching
core_path = repo / "astropy" / "timeseries" / "core.py"
core_text = core_path.read_text(encoding="utf-8")
lines = core_text.splitlines()
print("\n=== Original core.py lines 70-85 ===")
for i, line in enumerate(lines[69:85], 70):
    print(f"  {i:3d}: {line!r}")

# Manually edit the line
old_line = "            elif self.colnames[:len(required_columns)] != required_columns:"
new_line = "            elif len(self.colnames) < len(required_columns) or self.colnames[:len(required_columns)] != required_columns:"
assert old_line in core_text, "old line not found"
new_text = core_text.replace(old_line, new_line, 1)
core_path.write_text(new_text, encoding="utf-8")

print("\n=== Patched core.py lines 70-85 ===")
new_lines = core_path.read_text(encoding="utf-8").splitlines()
for i, line in enumerate(new_lines[69:85], 70):
    print(f"  {i:3d}: {line!r}")

# Apply the test_patch (gold's test_patch adds the new test case for 13009)
test_path = repo / "astropy" / "timeseries" / "tests" / "test_sampled.py"
test_text = test_path.read_text(encoding="utf-8")
old_block = (
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    '                                 "\'time\' as the first column but found \'banana\'")\n'
    '\n'
    '\n'
    'def test_periodogram(cls):'
)
new_block = (
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    '                                 "\'time\' as the first column but found \'banana\'")\n'
    '\n'
    '    # https://github.com/astropy/astropy/issues/13009\n'
    '    ts_2cols_required = ts.copy()\n'
    '    ts_2cols_required._required_columns = [\'time\', \'a\']\n'
    '    with pytest.raises(ValueError) as exc:\n'
    '        ts_2cols_required.remove_column(\'a\')\n'
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    '                                 "[\'time\', \'a\'] as the first columns but found [\'time\', \'b\']")\n'
    '\n'
    '\n'
    'def test_periodogram(cls):'
)
# Wait - the existing structure uses @pytest.mark.parametrize BEFORE test_periodogram
# Let me look at the actual content first
print("\n=== test_sampled.py lines 395-405 ===")
test_lines = test_text.splitlines()
for i, line in enumerate(test_lines[394:405], 395):
    print(f"  {i:3d}: {line!r}")

# Find the @pytest.mark.parametrize line
old_block_v2 = (
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    '                                 "\'time\' as the first column but found \'banana\'")\n'
    '\n'
    '\n'
    '@pytest.mark.parametrize(\'cls\', [BoxLeastSquares, LombScargle])\n'
    'def test_periodogram(cls):'
)
new_block_v2 = (
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    '                                 "\'time\' as the first column but found \'banana\'")\n'
    '\n'
    '    # https://github.com/astropy/astropy/issues/13009\n'
    '    ts_2cols_required = ts.copy()\n'
    '    ts_2cols_required._required_columns = [\'time\', \'a\']\n'
    '    with pytest.raises(ValueError) as exc:\n'
    '        ts_2cols_required.remove_column(\'a\')\n'
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    '                                 "[\'time\', \'a\'] as the first columns but found [\'time\', \'b\']")\n'
    '\n'
    '\n'
    '@pytest.mark.parametrize(\'cls\', [BoxLeastSquares, LombScargle])\n'
    'def test_periodogram(cls):'
)

if old_block_v2 in test_text:
    test_text = test_text.replace(old_block_v2, new_block_v2, 1)
    test_path.write_text(test_text, encoding="utf-8")
    print("\n[OK] test_patch applied")
else:
    print("\n[FAIL] old_block_v2 not found in test_sampled.py")
    sys.exit(1)

# Run the test
print("\n=== Running pytest test_required_columns ===")
result = subprocess.run(
    [str(ROOT / ".venv" / "Scripts" / "python.exe"), "-m", "pytest",
     "astropy/timeseries/tests/test_sampled.py::test_required_columns",
     "-xvs", "--tb=long", "--no-header"],
    cwd=str(repo),
    capture_output=True, text=True,
    timeout=180,
    env={**__import__("os").environ, "PYTHONPATH": "."},
)
print("--- stdout ---")
print(result.stdout[:6000])
print("--- stderr ---")
print(result.stderr[:2000])