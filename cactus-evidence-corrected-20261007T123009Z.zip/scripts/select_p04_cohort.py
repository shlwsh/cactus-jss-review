"""Select and freeze the 100-task cohort for P0-4 Frozen Matched Context Study.

Balances across PASS_TO_PASS_RATIO quartiles and stratifies across repositories.
Extracts inference-safe tasks from cactus_tasks_inference_safe.jsonl.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import numpy as np


SAFE_MANIFEST = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_inference_safe.jsonl")
EVAL_MANIFEST = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl")
REPO_CACHE_ROOT = Path(r"E:\cactus-data\repo-cache")
OUTPUT_DIR = Path("experiments/plans")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def select_cohort(seed: int = 20261006) -> dict:
    safe_rows = [json.loads(line) for line in SAFE_MANIFEST.read_text("utf-8").splitlines()]
    safe_map = {r["task_id"]: r for r in safe_rows}
    eval_rows = [json.loads(line) for line in EVAL_MANIFEST.read_text("utf-8").splitlines()]

    for r in eval_rows:
        p2p = len(r.get("PASS_TO_PASS", []))
        f2p = len(r.get("FAIL_TO_PASS", []))
        r["ratio"] = p2p / max(1, p2p + f2p)

    # Sort deterministically by (ratio, task_id)
    eval_rows.sort(key=lambda x: (x["ratio"], x["task_id"]))

    q_size = len(eval_rows) // 4  # 125
    quartiles = [eval_rows[i * q_size : (i + 1) * q_size] for i in range(4)]

    selected_eval: list[dict] = []
    for q_idx, q_tasks in enumerate(quartiles):
        repo_groups = defaultdict(list)
        for t in q_tasks:
            repo_groups[t["repo"]].append(t)
        
        q_selected = []
        shuffled_repos = sorted(repo_groups.keys())
        idx = 0
        while len(q_selected) < 25:
            repo = shuffled_repos[idx % len(shuffled_repos)]
            if repo_groups[repo]:
                chosen = repo_groups[repo].pop(0)
                chosen["quartile"] = f"Q{q_idx + 1}"
                q_selected.append(chosen)
            idx += 1
        selected_eval.extend(q_selected)

    # Sort final selected tasks deterministically by task_id
    selected_eval.sort(key=lambda x: x["task_id"])

    # Extract corresponding inference-safe rows
    selected_safe = [safe_map[t["task_id"]] for t in selected_eval]

    task_ids = [t["task_id"] for t in selected_eval]
    ratios = [t["ratio"] for t in selected_eval]
    repo_counts = dict(Counter(t["repo"] for t in selected_eval))

    cohort_metadata = {
        "schema_version": "1.0",
        "cohort_id": "COHORT-P04-MATCHED-100TASKS-20261006",
        "generated_at": "2026-10-06T10:30:00Z",
        "source_benchmark": "SWE-bench_Verified",
        "benchmark_revision": "78f471bf655a3137b2e8a75af1501690ec009ec3",
        "task_count": len(task_ids),
        "selection_strategy": "stratified_pass_to_pass_ratio_quartiles_balanced_repo",
        "quartile_task_count": 25,
        "seed": seed,
        "repository_distribution": repo_counts,
        "pass_to_pass_ratio_percentiles": {
            "p0": float(np.percentile(ratios, 0)),
            "p25": float(np.percentile(ratios, 25)),
            "p50": float(np.percentile(ratios, 50)),
            "p75": float(np.percentile(ratios, 75)),
            "p100": float(np.percentile(ratios, 100)),
        },
        "task_ids": task_ids,
        "task_details": [
            {
                "task_id": t["task_id"],
                "repo": t["repo"],
                "base_commit": t["base_commit"],
                "quartile": t["quartile"],
                "pass_to_pass_ratio": t["ratio"],
                "fail_to_pass_count": len(t.get("FAIL_TO_PASS", [])),
                "pass_to_pass_count": len(t.get("PASS_TO_PASS", [])),
            }
            for t in selected_eval
        ],
    }

    return {
        "metadata": cohort_metadata,
        "safe_rows": selected_safe,
    }


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    cohort = select_cohort()

    jsonl_path = OUTPUT_DIR / "P04_matched_100tasks_cohort.jsonl"
    json_path = OUTPUT_DIR / "P04_matched_100tasks_cohort.json"

    # Write JSONL
    jsonl_content = "\n".join(json.dumps(r, sort_keys=True) for r in cohort["safe_rows"]) + "\n"
    jsonl_path.write_text(jsonl_content, encoding="utf-8")
    jsonl_sha = sha256_bytes(jsonl_content.encode("utf-8"))
    (OUTPUT_DIR / "P04_matched_100tasks_cohort.jsonl.sha256").write_text(f"{jsonl_sha}  P04_matched_100tasks_cohort.jsonl\n", encoding="utf-8")

    # Update metadata with jsonl sha
    cohort["metadata"]["manifest_jsonl_sha256"] = jsonl_sha
    json_content = json.dumps(cohort["metadata"], indent=2, sort_keys=True) + "\n"
    json_path.write_text(json_content, encoding="utf-8")
    json_sha = sha256_bytes(json_content.encode("utf-8"))
    (OUTPUT_DIR / "P04_matched_100tasks_cohort.json.sha256").write_text(f"{json_sha}  P04_matched_100tasks_cohort.json\n", encoding="utf-8")

    print(f"Cohort selected successfully:")
    print(f"  Tasks count: {cohort['metadata']['task_count']}")
    print(f"  JSONL: {jsonl_path} (SHA-256: {jsonl_sha})")
    print(f"  JSON:  {json_path} (SHA-256: {json_sha})")
    print(f"  Repositories: {cohort['metadata']['repository_distribution']}")
    print(f"  P2P Ratio Percentiles: {cohort['metadata']['pass_to_pass_ratio_percentiles']}")


if __name__ == "__main__":
    main()
