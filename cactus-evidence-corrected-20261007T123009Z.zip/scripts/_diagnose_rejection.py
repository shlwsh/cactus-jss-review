"""Diagnose why the model's R4-13033 output was rejected as 'replacement not valid Python'."""
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

import importlib.util
spec = importlib.util.spec_from_file_location("cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# The actual model output (one of the edits)
helper_edit_replacement = (
    "        def as_scalar_or_list_str(obj):"
    "            if not hasattr(obj, '__len__'):"
    "                return f'{{obj}}'"
    "            elif len(obj) == 1:"
    "                return f'{{obj[0]}}'"
    "            else:"
    "                return str(obj)"
    "        if not self._required_columns_enabled:"
)
print("=" * 60)
print("REPLACEMENT (model output, newlines lost):")
print(repr(helper_edit_replacement))
print()

# Step 1: try _try_parse_with_quote_recovery as-is
import ast
tree, parsed = mod._try_parse_with_quote_recovery(helper_edit_replacement + "\n")
print(f"Step 1 - _try_parse_with_quote_recovery: tree={tree}, parsed chars={len(parsed)}")
if tree:
    print(f"  body count: {len(tree.body)}")
    for i, node in enumerate(tree.body):
        print(f"  body[{i}] type={type(node).__name__}")
print()

# Step 2: try with {{ → { and }} → } substitution (JSON escape recovery)
fixed_brace = helper_edit_replacement.replace("{{", "{").replace("}}", "}")
print(f"After {{ }} fix: chars={len(fixed_brace)}")
tree2, parsed2 = mod._try_parse_with_quote_recovery(fixed_brace + "\n")
print(f"Step 2 - recovery on brace-fixed: tree={tree2}")
if tree2:
    print(f"  body count: {len(tree2.body)}")
    for i, node in enumerate(tree2.body):
        print(f"  body[{i}] type={type(node).__name__}")

# Step 3: try splitting on double-spaces (likely newline replacements)
import re
split_attempt = re.sub(r"  +", "\n", helper_edit_replacement)
print(f"\nStep 3 - split on double-spaces: chars={len(split_attempt)}")
print(repr(split_attempt[:200]))
try:
    tree3 = ast.parse(split_attempt)
    print(f"Step 3 - ast.parse: SUCCESS, body={len(tree3.body)}")
    for i, node in enumerate(tree3.body):
        print(f"  body[{i}] type={type(node).__name__}")
except SyntaxError as e:
    print(f"Step 3 - ast.parse: FAIL {e}")

# Step 4: combine all fixes
combined = re.sub(r"  +", "\n", fixed_brace)
print(f"\nStep 4 - combined (brace fix + double-space split): chars={len(combined)}")
try:
    tree4 = ast.parse(combined)
    print(f"Step 4 - ast.parse: SUCCESS, body={len(tree4.body)}")
    for i, node in enumerate(tree4.body):
        print(f"  body[{i}] type={type(node).__name__}")
except SyntaxError as e:
    print(f"Step 4 - ast.parse: FAIL {e}")
