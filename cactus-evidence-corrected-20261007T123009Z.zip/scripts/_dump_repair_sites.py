import json, sys
fn = sys.argv[1]
with open(fn, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]
target_types = sys.argv[2].split(',') if len(sys.argv) > 2 else ['repair_sites', 'model_call', 'observe', 'v3_dual_insurance_result', 'repair_plan_rejected']
for e in events:
    t = e.get('type', '?')
    p = e.get('payload', {})
    if t in target_types:
        s = json.dumps(p, ensure_ascii=False, indent=2)
        if len(s) > 1500:
            s = s[:1500] + '\n...'
        seq = e.get('seq')
        print(f'=== seq={seq} {t} ===')
        print(s)
        print()
