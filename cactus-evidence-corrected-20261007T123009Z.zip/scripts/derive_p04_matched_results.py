"""P0-4 Frozen Matched Context Study - Deterministic Derivation & Statistical Testing.

Derives RQ3 metrics across 4 context strategies (FACO, BM25, MAXIMAL, STRUCTURAL)
for the 100-task cohort.
Pure Python standard library implementation for reproducible academic reporting.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random
import sys
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent

STRATEGIES = ["FACO", "BM25", "MAXIMAL", "STRUCTURAL"]


def binomial_coeff(n: int, k: int) -> int:
    return math.comb(n, k)


def exact_mcnemar_p_value(b: int, c: int) -> float:
    """Exact two-sided p-value for McNemar test using Binomial distribution under H0: p=0.5."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    # Cumulative probability P(X <= k) with p = 0.5
    prob_less_equal = sum(binomial_coeff(n, i) * (0.5 ** n) for i in range(k + 1))
    # Two-sided p-value
    p_val = min(1.0, 2.0 * prob_less_equal)
    return p_val


def mcnemar_chi2(b: int, c: int) -> tuple[float, float]:
    """McNemar Chi-Square statistic with continuity correction."""
    n = b + c
    if n == 0:
        return 0.0, 1.0
    stat = ((abs(b - c) - 1.0) ** 2) / n
    # For df=1, p-value can be approximated via complementary error function
    # chi2(1) p-value = erfc(sqrt(stat / 2))
    p_val = math.erfc(math.sqrt(stat / 2.0))
    return round(stat, 4), p_val


def cochrans_q_test(matrix: list[list[int]]) -> tuple[float, int, float]:
    """Cochran's Q test for k matched samples (binary outcome 0/1).
    
    matrix: list of rows (tasks), each row has k columns (strategies).
    """
    N = len(matrix)
    if N == 0:
        return 0.0, 0, 1.0
    k = len(matrix[0])
    if k < 2:
        return 0.0, 0, 1.0

    # Column sums (total successes per strategy)
    C = [sum(matrix[i][j] for i in range(N)) for j in range(k)]
    # Row sums (total successes per task)
    R = [sum(matrix[i][j] for j in range(k)) for i in range(N)]

    sum_C_sq = sum(c ** 2 for c in C)
    sum_C = sum(C)
    sum_R = sum(R)
    sum_R_sq = sum(r ** 2 for r in R)

    numerator = (k - 1) * (k * sum_C_sq - (sum_C ** 2))
    denominator = k * sum_R - sum_R_sq

    if denominator == 0:
        return 0.0, k - 1, 1.0

    Q = numerator / denominator
    df = k - 1

    # Approximate p-value using chi2 distribution with df degrees of freedom
    # Using Wilson-Hilferty transformation or gamma approximation
    # For df=3, chi2 cdf = 1 - (1 + sqrt(2*Q/3)...)
    # Simple Monte-Carlo / approximation or incomplete gamma function
    # Let's compute p-value via regularized gamma function:
    p_val = chi2_sf(Q, df)
    return round(Q, 4), df, p_val


def gamma_log(z: float) -> float:
    return math.lgamma(z)


def lower_gamma(s: float, x: float) -> float:
    """Lower incomplete gamma function by series expansion."""
    if x <= 0:
        return 0.0
    if x < s + 1.0:
        sum_val = 1.0 / s
        term = 1.0 / s
        for n in range(1, 100):
            term = term * x / (s + n)
            sum_val += term
            if abs(term) < abs(sum_val) * 1e-12:
                break
        return sum_val * (x ** s) * math.exp(-x)
    else:
        # Lentz's method for continued fraction (upper gamma)
        # Gamma(s, x)
        b = x + 1.0 - s
        c = 1.0 / 1e-30
        d = 1.0 / b
        h = d
        for i in range(1, 100):
            an = -i * (i - s)
            b += 2.0
            d = an * d + b
            if abs(d) < 1e-30:
                d = 1e-30
            c = b + an / c
            if abs(c) < 1e-30:
                c = 1e-30
            d = 1.0 / d
            del_val = d * c
            h *= del_val
            if abs(del_val - 1.0) < 1e-12:
                break
        upper_g = math.exp(-x + s * math.log(x)) * h
        return math.gamma(s) - upper_g


def chi2_sf(x: float, df: int) -> float:
    """Survival function (1 - CDF) for chi2 distribution."""
    if x <= 0:
        return 1.0
    s = df / 2.0
    gam_val = lower_gamma(s, x / 2.0) / math.gamma(s)
    sf = 1.0 - gam_val
    return max(0.0, min(1.0, sf))


def percentile(vals: list[float], p: float) -> float:
    if not vals:
        return 0.0
    s = sorted(vals)
    k = (len(s) - 1) * p
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return s[int(k)]
    d0 = s[int(f)] * (c - k)
    d1 = s[int(c)] * (k - f)
    return d0 + d1


def bootstrap_ci_diff(success_a: list[int], success_b: list[int], n_boot: int = 2000, seed: int = 20261006) -> tuple[float, float, float]:
    """Bootstrap 95% confidence interval for difference in proportions (p_a - p_b)."""
    assert len(success_a) == len(success_b)
    n = len(success_a)
    if n == 0:
        return 0.0, 0.0, 0.0
    rng = random.Random(seed)
    diffs = []
    for _ in range(n_boot):
        indices = [rng.randint(0, n - 1) for _ in range(n)]
        mean_a = sum(success_a[i] for i in indices) / n
        mean_b = sum(success_b[i] for i in indices) / n
        diffs.append(mean_a - mean_b)
    diffs.sort()
    observed_diff = (sum(success_a) - sum(success_b)) / n
    ci_low = percentile(diffs, 0.025)
    ci_high = percentile(diffs, 0.975)
    return round(observed_diff, 4), round(ci_low, 4), round(ci_high, 4)


def load_p04_results(runs_root: Path) -> dict[str, dict[str, Any]]:
    """Loads results organized by task_id -> strategy -> result."""
    data_by_task: dict[str, dict[str, Any]] = {}

    for strat in STRATEGIES:
        strat_dir = runs_root / strat
        if not strat_dir.exists():
            continue
        for task_dir in strat_dir.iterdir():
            if not task_dir.is_dir():
                continue
            task_id = task_dir.name
            pred_file = task_dir / "prediction.jsonl"
            patch_text = ""
            is_valid_patch = False
            patch_len = 0

            if pred_file.exists() and pred_file.stat().st_size > 0:
                try:
                    for line in pred_file.read_text(encoding="utf-8").splitlines():
                        if not line.strip():
                            continue
                        record = json.loads(line)
                        if "model_patch" in record and record["model_patch"]:
                            patch_text = record["model_patch"]
                            patch_len = len(patch_text)
                            if "diff --git" in patch_text or "---" in patch_text:
                                is_valid_patch = True
                except Exception:
                    pass

            if task_id not in data_by_task:
                data_by_task[task_id] = {}

            data_by_task[task_id][strat] = {
                "valid_patch": is_valid_patch,
                "patch_len": patch_len,
            }

    return data_by_task


def derive_metrics(data_by_task: dict[str, dict[str, Any]]) -> dict[str, Any]:
    tasks = sorted(data_by_task.keys())
    N = len(tasks)
    if N == 0:
        return {"error": "No tasks loaded"}

    # Strategy individual metrics
    strategy_metrics = {}
    binary_matrix = []  # N x 4

    for strat in STRATEGIES:
        valid_count = sum(1 for t in tasks if data_by_task[t].get(strat, {}).get("valid_patch", False))
        valid_rate = valid_count / N
        patch_lens = [
            data_by_task[t].get(strat, {}).get("patch_len", 0)
            for t in tasks
            if data_by_task[t].get(strat, {}).get("valid_patch", False)
        ]
        strategy_metrics[strat] = {
            "evaluated_tasks": N,
            "valid_patches": valid_count,
            "valid_rate": round(valid_rate, 4),
            "patch_len_median": round(percentile([float(l) for l in patch_lens], 0.5), 1) if patch_lens else 0,
            "patch_len_iqr": round(percentile([float(l) for l in patch_lens], 0.75) - percentile([float(l) for l in patch_lens], 0.25), 1) if patch_lens else 0,
        }

    for t in tasks:
        row = [1 if data_by_task[t].get(strat, {}).get("valid_patch", False) else 0 for strat in STRATEGIES]
        binary_matrix.append(row)

    # Pairwise comparison vs FACO
    faco_scores = [1 if data_by_task[t].get("FACO", {}).get("valid_patch", False) else 0 for t in tasks]
    pairwise = {}
    for other in ["BM25", "MAXIMAL", "STRUCTURAL"]:
        other_scores = [1 if data_by_task[t].get(other, {}).get("valid_patch", False) else 0 for t in tasks]
        # Contingency
        # b: FACO=1, other=0 (FACO advantage)
        # c: FACO=0, other=1 (other advantage)
        # a: both 1, d: both 0
        a = sum(1 for i in range(N) if faco_scores[i] == 1 and other_scores[i] == 1)
        b = sum(1 for i in range(N) if faco_scores[i] == 1 and other_scores[i] == 0)
        c = sum(1 for i in range(N) if faco_scores[i] == 0 and other_scores[i] == 1)
        d = sum(1 for i in range(N) if faco_scores[i] == 0 and other_scores[i] == 0)

        exact_p = exact_mcnemar_p_value(b, c)
        chi2_stat, chi2_p = mcnemar_chi2(b, c)
        diff, ci_l, ci_h = bootstrap_ci_diff(faco_scores, other_scores)

        pairwise[f"FACO_vs_{other}"] = {
            "both_valid": a,
            "faco_only": b,
            "other_only": c,
            "both_invalid": d,
            "mcnemar_exact_p": round(exact_p, 5),
            "mcnemar_chi2": chi2_stat,
            "mcnemar_chi2_p": round(chi2_p, 5),
            "difference_in_proportions": diff,
            "ci_95_diff": [ci_l, ci_h],
        }

    # Cochran's Q test across all 4 strategies
    q_stat, df, q_p = cochrans_q_test(binary_matrix)

    return {
        "schema_version": "2.0",
        "cohort_size": N,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "strategy_metrics": strategy_metrics,
        "cochran_q_test": {
            "q_statistic": q_stat,
            "df": df,
            "p_value": round(q_p, 6),
            "statistically_significant": q_p < 0.05,
        },
        "pairwise_comparisons": pairwise,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Derive P0-4 results and statistical tests")
    parser.add_argument("--runs-dir", type=str, default="experiments/runs/P04-MATCHED-100TASKS")
    parser.add_argument("--output", type=str, default="experiments/derived/p04_matched_derived_metrics.json")
    args = parser.parse_args()

    runs_path = PROJECT_ROOT / args.runs_dir
    data = load_p04_results(runs_path)
    metrics = derive_metrics(data)

    out_path = PROJECT_ROOT / args.output
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"Metrics derived successfully for {metrics.get('cohort_size', 0)} tasks.")
    print(f"Saved to {out_path}")
    print("\nSummary Metrics:")
    for s, m in metrics.get("strategy_metrics", {}).items():
        print(f"  {s}: Valid={m['valid_patches']}/{m['evaluated_tasks']} ({m['valid_rate']*100:.1f}%), Median Len={m['patch_len_median']}")


if __name__ == "__main__":
    main()
