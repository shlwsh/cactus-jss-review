"""Real-time monitor for CACTUS R4 RUN bundles.

Listens to ``experiments/runs/RUN-*/trace/events.jsonl`` and the
``logs/predict.stdout.log`` / ``logs/predict.stderr.log`` files. Whenever a new
line appears, prints the event (model_call, prediction_rejected, observe,
heartbeat-like) with truncated payload so the operator can react *before* a
task finishes.

Design goals
------------
1. **Single-pass file tailing**: track the byte offset read for each log file.
   Only new bytes are decoded.
2. **Append-only safety**: never overwrite or rewrite the immutable RUN bundle.
3. **Heartbeat summarisation**: collapse duplicate ``model_call`` / heartbeat
   events into a one-line roll-up per ~5 s window.
4. **Live budget guard**: alert when ``output_tokens`` approaches the model
   ``max_output_tokens`` cap (deepseek v4 has a habit of finishing the entire
   budget in CoT without producing a usable response).
5. **No background tools required**: pure stdlib, runs inside the project venv.

Usage
-----

    python scripts/monitor_r4_live.py --runs experiments/runs --interval 2.0

The script writes a human-readable stream to stdout and a JSONL snapshot to
``--log``. Both streams are independent.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def safe_loads(line: str) -> dict | None:
    line = line.strip()
    if not line:
        return None
    try:
        return json.loads(line)
    except json.JSONDecodeError:
        return None


def render_event(event: dict) -> str:
    """Render a single trace event as a one-line summary + optional tail."""
    et = event.get("type", "?")
    ts = event.get("timestamp", "")
    pl = event.get("payload", {}) or {}
    if et == "model_call":
        fr = pl.get("finish_reason") or "?"
        it = pl.get("input_tokens") or 0
        ot = pl.get("output_tokens") or 0
        rc = len(pl.get("response_text") or "")
        budget = pl.get("max_tokens") or 0
        head = f"[model_call] finish={fr} in={it} out={ot}/{budget} resp_chars={rc}"
        rt = (pl.get("response_text") or "")[:280]
        if rt:
            head += f"\n    RESP[0:280]: {rt!r}"
        return head
    if et == "prediction_rejected":
        reason = (pl.get("reason") or "")[:240]
        return f"[prediction_rejected] class={pl.get('reason_class')} reason={reason}"
    if et == "prediction_exhausted":
        return f"[prediction_exhausted] attempts={pl.get('attempts')} last_reason={(pl.get('last_reason') or '')[:160]}"
    if et == "prediction_accepted":
        return f"[prediction_accepted] bytes={pl.get('patch_bytes')} apply_ms={pl.get('apply_ms')}"
    if et == "context_selected":
        return f"[context_selected] units={pl.get('unit_count')} paths={len(pl.get('paths', []) or [])}"
    if et == "context_candidates_pruned":
        return f"[context_candidates_pruned] before={pl.get('before')} after={pl.get('after')}"
    if et == "context_summary":
        return f"[context_summary] turn={pl.get('turn_id', '')[:40]}"
    if et == "issue_symbol_anchors":
        return f"[issue_symbol_anchors] count={pl.get('count')}"
    if et == "issue_symbol_module_contexts":
        return f"[issue_symbol_module_contexts] count={pl.get('count')}"
    if et == "literal_source_anchors":
        return f"[literal_source_anchors] count={pl.get('count')}"
    if et == "literal_anchor_candidates":
        return f"[literal_anchor_candidates] count={pl.get('count')}"
    if et == "context_hash_verified":
        return f"[context_hash_verified] match={pl.get('match')}"
    if et == "observe":
        return f"[observe] turn={pl.get('turn_id', '')[:40]} usage={pl.get('usage')} finish={pl.get('finish_reason')}"
    return f"[{et}] {json.dumps(pl, ensure_ascii=False)[:200]}"


def tail_file(path: Path, state: dict) -> Iterator[str]:
    """Yield new lines from ``path`` based on last-read offset in ``state``."""
    if not path.exists():
        return iter([])
    offset = state.get(path, 0)
    try:
        size = path.stat().st_size
    except FileNotFoundError:
        return iter([])
    if size < offset:
        offset = 0
    if size == offset:
        return iter([])
    with path.open("r", encoding="utf-8", errors="replace") as fp:
        fp.seek(offset)
        new_data = fp.read()
        state[path] = offset + len(new_data.encode("utf-8", errors="replace"))
    return iter(new_data.splitlines())


def collect_events(runs_root: Path, state: dict, since: float) -> Iterator[tuple[Path, dict]]:
    """Walk RUN-* directories and yield (run_dir, parsed_event) for new events.

    ``since`` is the epoch seconds when the monitor was started; any file with
    mtime < since is treated as historical and skipped. New appends to those
    files (after monitor start) are still streamed because the file pointer
    keeps moving forward past ``since``.
    """
    for run_dir in sorted(runs_root.glob("RUN-*")):
        if not run_dir.is_dir():
            continue
        events_path = run_dir / "trace" / "events.jsonl"
        if not events_path.exists():
            continue
        try:
            mtime = events_path.stat().st_mtime
        except FileNotFoundError:
            continue
        # Skip historical event files entirely; we only care about fresh appends.
        if mtime < since - 5:
            continue
        for line in tail_file(events_path, state):
            parsed = safe_loads(line)
            if parsed is None:
                continue
            yield run_dir, parsed


def collect_stderr(runs_root: Path, state: dict, since: float) -> Iterator[tuple[Path, str]]:
    """Yield new stderr/stdout lines that appear after monitor start."""
    for run_dir in sorted(runs_root.glob("RUN-*")):
        for fname in ("predict.stderr.log", "predict.stdout.log"):
            path = run_dir / "logs" / fname
            if not path.exists():
                continue
            try:
                mtime = path.stat().st_mtime
            except FileNotFoundError:
                continue
            if mtime < since - 5:
                # Snap the offset to current size so we never replay history.
                try:
                    state[path] = path.stat().st_size
                except FileNotFoundError:
                    pass
                continue
            for line in tail_file(path, state):
                yield run_dir, f"[{fname}] {line[:300]}"


def format_run_header(run_dir: Path) -> str:
    return f"  >>> {run_dir.name} | {utc_now()}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, default=Path("experiments/runs"))
    parser.add_argument("--interval", type=float, default=2.0)
    parser.add_argument("--log", type=Path, default=None,
                        help="Optional JSONL sidecar of every emitted event")
    parser.add_argument("--idle-exit-sec", type=float, default=0.0,
                        help="If >0, exit after this many seconds with no new event (for CI smoke)")
    args = parser.parse_args()

    state: dict[Path, int] = {}
    log_fp = args.log.open("a", encoding="utf-8") if args.log else None
    last_event_ts = time.time()
    since = time.time() - 60.0
    print(f"[monitor] CACTUS R4 live monitor started @ {utc_now()}; runs={args.runs}", flush=True)
    try:
        while True:
            had_new = False
            for run_dir, event in collect_events(args.runs, state, since):
                had_new = True
                last_event_ts = time.time()
                header = format_run_header(run_dir)
                rendered = render_event(event)
                print(f"{header}\n    {rendered}", flush=True)
                if log_fp is not None:
                    log_fp.write(json.dumps({
                        "ts": utc_now(),
                        "run_id": run_dir.name,
                        "event": event,
                    }, ensure_ascii=False) + "\n")
                    log_fp.flush()
            for run_dir, line in collect_stderr(args.runs, state, since):
                had_new = True
                last_event_ts = time.time()
                print(f"{format_run_header(run_dir)}\n    {line}", flush=True)
                if log_fp is not None:
                    log_fp.write(json.dumps({
                        "ts": utc_now(),
                        "run_id": run_dir.name,
                        "stderr": line,
                    }, ensure_ascii=False) + "\n")
                    log_fp.flush()
            if args.idle_exit_sec and time.time() - last_event_ts > args.idle_exit_sec:
                print(f"[monitor] idle for {args.idle_exit_sec}s, exiting", flush=True)
                return 0
            time.sleep(max(0.2, args.interval))
    except KeyboardInterrupt:
        print("[monitor] interrupted by user", flush=True)
        return 0
    finally:
        if log_fp is not None:
            log_fp.close()


if __name__ == "__main__":
    sys.exit(main())
