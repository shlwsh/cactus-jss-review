#!/usr/bin/env python3
"""Fail closed on historical-trace leakage into primary Phase C1 evidence."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TRACE_ROOT = ROOT / "experiments" / "runs"
FREEZE = datetime.fromisoformat("2026-09-22T13:04:05+08:00")


def records(root: Path) -> list[tuple[Path, dict[str, object]]]:
    """Return declared historical-trace inputs, not the RUNs that consume them.

    A Phase C1 run's ``created_at`` is not the timestamp of historical evidence
    it consumed.  Consumer provenance must be declared explicitly as
    ``historical_trace_inputs`` in the run manifest or resolved config.  Each
    entry is then checked below; ordinary run/event timestamps are irrelevant.
    """
    found: list[tuple[Path, dict[str, object]]] = []
    for path in sorted(root.rglob("run_manifest.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(data, dict):
            continue
        if not _is_primary_c1(data):
            continue
        declared = data.get("historical_trace_inputs")
        resolved = path.with_name("resolved_config.json")
        if declared is None:
            try:
                config = json.loads(resolved.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                config = {}
            if isinstance(config, dict):
                declared = config.get("historical_trace_inputs")
        if declared is None:
            found.append((path, {"trace_input_error": "primary C1 run does not declare historical_trace_inputs"}))
        elif not isinstance(declared, list):
            found.append((path, {"trace_input_error": "historical_trace_inputs must be a list"}))
        else:
            for item in declared:
                if isinstance(item, dict):
                    found.append((path, item))
                else:
                    found.append((path, {"trace_input_error": "trace input entry must be an object"}))
    # Explicit corpus manifests may also be audited directly.  JSONL event
    # logs are intentionally excluded: their utc_ts values describe the
    # current run, not the historical trace source.
    for path in sorted(root.rglob("historical_trace_manifest.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(data, dict):
            inputs = data.get("historical_trace_inputs", [])
            if isinstance(inputs, list):
                found.extend((path, item) for item in inputs if isinstance(item, dict))
            else:
                found.append((path, {"trace_input_error": "historical_trace_inputs must be a list"}))
    return found


def audit(root: Path = DEFAULT_TRACE_ROOT) -> dict[str, object]:
    failures: list[str] = []
    inspected = records(root)
    for path, data in inspected:
        if data.get("trace_input_error"):
            failures.append(f"{path}: {data['trace_input_error']}")
            continue
        task_id = str(data.get("task_id", ""))
        source_task = str(data.get("trace_task_id", data.get("source_task_id", "")))
        if task_id and source_task and task_id == source_task:
            failures.append(f"{path}: same-task history consumed by {task_id}")
        timestamp = str(data.get("trace_timestamp", ""))
        if not timestamp:
            failures.append(f"{path}: declared historical trace input has no trace_timestamp")
            continue
        if timestamp:
            try:
                parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                if parsed.tzinfo is None:
                    parsed = parsed.astimezone()
                if parsed > FREEZE:
                    failures.append(f"{path}: trace timestamp {timestamp} is after freeze")
            except ValueError:
                failures.append(f"{path}: invalid trace timestamp {timestamp!r}")
        if data.get("phase_c0_outcome_derived") is True or data.get("outcome_derived") is True:
            failures.append(f"{path}: outcome-derived trace is forbidden in primary C1")
        if data.get("task_order_dependent") is True:
            failures.append(f"{path}: task-order-dependent history is forbidden in primary C1")
    return {
        "policy": "TRACE-C1-FROZEN-V1",
        "freeze_timestamp": FREEZE.isoformat(),
        "inspected_inputs": len(inspected),
        "primary_run_declarations": sum(
            1 for path in sorted(root.rglob("run_manifest.json"))
            if _is_primary_c1_manifest(path)
        ),
        "status": "fail" if failures else "pass",
        "scope_note": "Only explicitly declared cross-run historical trace inputs are checked; current RUN/event creation timestamps are not treated as source-trace timestamps.",
        "failures": failures,
    }


def _is_primary_c1(data: dict[str, object]) -> bool:
    metadata = data.get("_metadata", {})
    is_pilot = (
        isinstance(metadata, dict) and metadata.get("candidate_scope") == "pilot"
    ) or "pilot" in str(data.get("campaign_id", "")).lower() or "pilot" in str(data.get("experiment_id", "")).lower()
    if is_pilot:
        return False

    # Campaign names are not an execution-purpose contract: engineering and
    # retry-validation campaigns may use the historical ``phase-c1`` prefix.
    # Count only explicit formal C1 evidence, while retaining legacy manifests
    # whose exact phase is C1 so a missing trace declaration still fails closed.
    phase = str(data.get("protocol_phase", data.get("phase", ""))).upper()
    purpose = str(data.get("purpose", "")).strip().lower()
    publishable = data.get("publishable_result")
    if purpose and purpose != "formal_phase_c1":
        return False
    if publishable is False:
        return False
    return phase == "C1" or purpose == "formal_phase_c1" or publishable is True


def _is_primary_c1_manifest(path: Path) -> bool:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return isinstance(data, dict) and _is_primary_c1(data)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace-root", type=Path, default=DEFAULT_TRACE_ROOT)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = audit(args.trace_root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(2 if args.strict and result["failures"] else 0)
