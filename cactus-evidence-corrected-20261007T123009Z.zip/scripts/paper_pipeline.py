"""Offline, source-verified publication build. Never starts model/evaluator calls."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
# Direct script invocation and module invocation both resolve project modules.
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
PAPER = ROOT / "paper"
BUILD = PAPER / "build"
DIST = PAPER / "dist"


def run(command, *, cwd=PAPER):
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONPATH": os.pathsep.join([str(ROOT), str(ROOT / "src")])}
    completed = subprocess.run(command, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if completed.returncode:
        (BUILD / "last_failed_command.log").write_bytes(completed.stdout)
        raise RuntimeError("publication command failed; see paper/build/last_failed_command.log")


def publication_styles(root: Path = ROOT):
    """Require the manuscript to use the exact pinned class and BibTeX style."""
    from scripts.generate_publication_values import pinned
    sources = pinned(root)["sources"]
    paper = root / "paper"
    document_class = root / sources["document_class"]["path"]
    bibliography_style = root / sources["bibliography_style"]["path"]
    source = (paper / "main.tex").read_text(encoding="utf-8")
    import re
    for label, pattern, path in [
        ("document class", r"\\documentclass(?:\[[^\]]*\])?\{([^}]+)\}", document_class),
        ("bibliography style", r"\\bibliographystyle\{([^}]+)\}", bibliography_style),
    ]:
        expected = path.relative_to(paper).with_suffix("").as_posix()
        actual = re.search(pattern, source)
        if actual is None or actual.group(1) != expected:
            raise ValueError(f"manuscript {label} differs from pinned publication style")
    return document_class, bibliography_style


def inputs():
    from scripts.generate_publication_values import pinned, verify_sources
    from scripts.verify_cited_papers import verify as verify_citations
    pinned()
    publication_styles()
    citations = verify_citations()
    sources = verify_sources()
    return {"status": "PASS", "citations": citations, "source_admission": sources,
            "scope": "admitted retry observations; historical effectiveness claims withdrawn"}


def validate():
    from scripts.generate_publication_values import verify, scan
    from cactus.tools.datactl import verify_sidecar
    summary = inputs()
    summary["values"] = verify()
    summary["latex"] = scan()
    summary["language_scope"] = "English manuscript; historical Chinese edition is not rebuilt or released"
    errors = list(summary["latex"]["errors"])
    seen = set()
    for path in [ROOT / "paper/data/publication_values.json", *sorted((PAPER / "generated/values").glob("*.tex")),
                 *(PAPER / graphic for graphic in summary["latex"]["graphics"])]:
        errors.extend(verify_sidecar(ROOT, path, seen=seen))
    if errors:
        raise RuntimeError("publication gate failed: " + "; ".join(errors))
    if (BUILD / 'main.pdf').is_file():
        from scripts.check_publication_pdf import check
        summary['rendering'] = check(BUILD / 'main.pdf', BUILD / 'main.log')
    BUILD.mkdir(parents=True, exist_ok=True)
    (BUILD / "data_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


def audit_independence():
    text = (PAPER / "main.tex").read_text(encoding="utf-8")
    violations = [marker for marker in ("E:\\work", "C:\\Users", "/home/", "/Users/") if marker in text]
    if violations:
        raise RuntimeError("publication contains workstation paths")
    return {"status": "PASS", "checked": ["paper/main.tex"]}


def bibliography():
    from scripts.verify_cited_papers import cited
    from scripts.artifact_provenance import write
    keys = cited()
    _, style = publication_styles()
    style_name = style.relative_to(PAPER).with_suffix("").as_posix()
    source = PAPER / "data/publication_bibtex_input.aux"
    source.write_text("\\relax\n\\citation{" + ",".join(keys) + "}\n\\bibstyle{" + style_name + "}\n\\bibdata{references}\n", encoding="utf-8", newline="\n")
    bib = PAPER / "references.bib"
    manifest = PAPER / "data/scholar/cited_papers_manifest.json"
    parser = ROOT / "scripts/verify_cited_papers.py"
    write(source, [PAPER / "main.tex", bib, manifest, style, parser], Path(__file__),
          transform={"activity": "derive BibTeX input from actual cited keys", "citation_keys": keys}, kind="derived_dataset")
    shutil.copyfile(source, BUILD / "publication_refs.aux")
    run(["bibtex", "build/publication_refs"])
    raw = PAPER / "data/publication_bibliography.bbl"
    # Store clean BBL: strip BibTeX comment lines (%), preserve everything else as-is.
    # The BBL content is placed inside \DataValue{...} which uses \texttt, so bare _ is
    # fine in regular text but NOT in macro arguments like \def\showCODEN#1{...}.
    # We remove the comment lines only; DO NOT escape underscores.
    bbl_src = (BUILD / "publication_refs.bbl").read_text(encoding="utf-8")
    bbl_clean = "\n".join(line for line in bbl_src.splitlines() if not line.startswith("%"))
    (BUILD / "main.bbl").write_text(bbl_clean, encoding="utf-8", newline="\n")
    shutil.copyfile(BUILD / "publication_refs.bbl", raw)
    executable = Path(shutil.which("bibtex") or "")
    write(raw, [source, bib, manifest, style, parser], Path(__file__),
          transform={"activity": "actual BibTeX execution", "citation_keys": keys,
                     "tool_sha256": hashlib.sha256(executable.read_bytes()).hexdigest()}, kind="derived_dataset")
    return raw


def build():
    from scripts.generate_publication_values import generate, verify, scan
    from scripts.artifact_provenance import write
    summary = inputs()
    BUILD.mkdir(parents=True, exist_ok=True)
    bibliography()
    generate()
    verify()
    run([sys.executable, str(PAPER / "figures/generate_admission_values.py")], cwd=ROOT)
    for script in ['generate_fig_system_overview.py', 'generate_fig_dual_lens_workflow.py', 'generate_fig_failure_taxonomy.py','generate_fig_semantic_admission.py']:
        run([sys.executable, str(PAPER / 'figures' / script)], cwd=ROOT)
    # English paper only (paper-cn uses ../paper/references which conflicts with BBL pipeline)
    paper_folders = [(PAPER, "pdflatex")]
    paper_cn = ROOT / "paper-cn"
    for folder, _compiler in paper_folders:
        target = folder / "build"
        target.mkdir(parents=True, exist_ok=True)
        # bibliography() already writes clean BBL to BUILD/main.bbl; do NOT overwrite it here
    # Figures and their provenance are regenerated together, never rebound post hoc.
    result = scan(entry="paper/main.tex")
    if result["errors"]:
        raise RuntimeError("numeric gate failed: " + "; ".join(result["errors"]))
    for folder, compiler in paper_folders:
        for _ in range(3):
            run([compiler, "-interaction=nonstopmode", "-halt-on-error", "-output-directory=build", "main.tex"], cwd=folder)
        pdf = folder / "build/main.pdf"
        if not pdf.is_file() or not pdf.stat().st_size:
            raise RuntimeError("PDF was not generated")
        from scripts.check_publication_pdf import check
        summary['rendering'] = check(pdf, target / 'main.log')
        publication_inputs = [folder / "main.tex", PAPER / "references.bib", PAPER / "publication_sources.json",
                              PAPER / "data/publication_values.json", PAPER / "data/publication_bibliography.bbl",
                              *sorted((PAPER / "generated/values").glob("*.tex")),
                              *(PAPER / graphic for graphic in result['graphics']),
                              *((PAPER / graphic).with_name(Path(graphic).name + '.provenance.json') for graphic in result['graphics']),
                              *publication_styles()]
        write(pdf, publication_inputs, Path(__file__), transform={"commands": [compiler] * 3,
              "source_admission": summary["source_admission"], "scope": summary["scope"]}, kind="main_paper")
    (BUILD / "data_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return None


def package():
    summary = validate()
    DIST.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = DIST / ("cactus-evidence-corrected-" + stamp + ".zip")
    from scripts.generate_publication_values import pinned
    files = {PAPER / "main.tex", PAPER / "references.bib",
             PAPER / "publication_sources.json", PAPER / "PIPELINE.md", BUILD / "main.pdf", BUILD / "main.pdf.provenance.json"}
    files.update((PAPER / "generated/values").glob("*"))
    files.update((PAPER / "data").glob("publication_*"))
    for graphic in summary['latex']['graphics']:
        path = PAPER / graphic
        files.update([path, path.with_name(path.name + '.provenance.json')])
        png = path.with_suffix('.png')
        if png.is_file():
            files.update([png, png.with_name(png.name + '.provenance.json')])
    files.update((PAPER / 'figures').glob('generate*.py'))
    files.update([PAPER / "figures/plot_style.py", *publication_styles()])
    if (PAPER / "submission/highlights.txt").is_file():
        files.add(PAPER / "submission/highlights.txt")
    for source in pinned()["sources"].values():
        path = ROOT / source["path"]
        files.add(path)
        if path.with_name(path.name + ".provenance.json").is_file():
            files.add(path.with_name(path.name + ".provenance.json"))
    for directory in (ROOT / "scripts", ROOT / "src/cactus", ROOT / "configs/policies", ROOT / "experiments/schemas"):
        files.update(p for p in directory.rglob("*") if p.is_file() and p.suffix in {".py", ".json"})
    cited_manifest = json.loads((PAPER / "data/scholar/cited_papers_manifest.json").read_text(encoding="utf-8"))
    files.update(ROOT / record["file_path"] for record in cited_manifest["records"])
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, path.relative_to(ROOT).as_posix())
        archive.writestr("REGENERATION_SCOPE.txt", "The package preserves publication inputs. Complete source admission additionally requires the original RUN archive and source Git history; these are not bundled. No end-to-end replay is claimed.\n")
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("validate", "audit", "build", "package", "all"))
    args = parser.parse_args()
    if args.command == "build":
        build(); print("built English evidence-corrected paper; Chinese archive unchanged")
    elif args.command == "validate":
        print(json.dumps(validate(), ensure_ascii=False, indent=2))
    elif args.command == "audit":
        summary = validate()
        summary['independence'] = audit_independence()
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    elif args.command == "package":
        print(package())
    else:
        build(); print(package())
