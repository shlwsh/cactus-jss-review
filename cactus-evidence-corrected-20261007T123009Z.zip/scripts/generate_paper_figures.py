"""Stable project-local entry point for ACM figure generation.

The canonical plotting implementation lives beside the manuscript.  This
wrapper keeps the documented ``scripts/`` interface while allowing callers to
copy exports into a requested paper-results directory.  It never synthesizes
experimental measurements; the plotting module reads only project-local
evidence and protocol files.
"""

from __future__ import annotations

import argparse
import runpy
import shutil
import sys
from pathlib import Path


def generate(output: Path | None = None) -> Path:
    script = Path(__file__).resolve().parents[1] / "paper" / "figures" / "generate_figures.py"
    figure_dir = str(script.parent)
    sys.path.insert(0, figure_dir)
    try:
        namespace = runpy.run_path(str(script), run_name="__main__")
    finally:
        if sys.path and sys.path[0] == figure_dir:
            sys.path.pop(0)
    source = Path(namespace["OUT"])
    if output is None:
        return source
    output.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        if item.is_file():
            shutil.copy2(item, output / item.name)
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, help="reserved for interface compatibility; inputs remain project-local")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    destination = generate(args.output)
    print(f"generated figures in {destination}")
