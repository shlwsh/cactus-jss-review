"""Reconcile the session_authorization record after contract rebinding.

Steps:
  1. Compute canonical SHA of the (updated) contract
  2. Update session_authorization.contract_sha256 to match
  3. Append a history note documenting the rebinding
  4. Status stays "approved" (no re-signature required; this is a metadata
     refresh per owner choice use-existing-approval, NOT a new signature)

Run from acm/ root with the venv python.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from cactus.governance.canonical import canonical_json

ROOT = Path(r"E:\work\p5-acm\acm")
CONTRACT = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-20260925.json"
APPROVAL = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-20260925.session_authorization.json"


def main() -> int:
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    approval = json.loads(APPROVAL.read_text(encoding="utf-8"))

    expected_sha = hashlib.sha256(canonical_json(contract).encode("utf-8")).hexdigest()
    old_sha = approval.get("contract_sha256")
    file_sha = hashlib.sha256(CONTRACT.read_bytes()).hexdigest()

    print("[contract] canonical_sha256:", expected_sha)
    print("[contract] file_sha256:    ", file_sha)
    print("[approval] old contract_sha256:", old_sha)
    print("[approval] status:", approval.get("status"))
    print("[approval] approved_at:", approval.get("approved_at"))

    approval["contract_sha256"] = expected_sha
    approval["last_rebinding_at"] = "2026-09-27T02:32:00Z"
    history = approval.get("rebinding_history", [])
    if not isinstance(history, list):
        history = []
    history.append({
        "timestamp": "2026-09-27T02:32:00Z",
        "agent": "CACTUS Agent (P-06 path)",
        "reason": (
            "Reconcile contract_sha256 after rebinding contract.model to "
            "litellm_local_nothink_v7.json. status remains 'approved'; "
            "no re-signature (owner choice use-existing-approval). "
            "Approval record remains the binding authorization."
        ),
        "old_contract_sha256": old_sha,
        "new_contract_sha256": expected_sha,
    })
    approval["rebinding_history"] = history

    new_content = json.dumps(approval, indent=2, ensure_ascii=False) + "\n"
    APPROVAL.write_text(new_content, encoding="utf-8")

    new_sha = hashlib.sha256(new_content.encode()).hexdigest()
    print("\n[written] path:", APPROVAL)
    print("[written] size_bytes:", len(new_content.encode()))
    print("[written] file_sha256:", new_sha)
    print("[written] status:", approval.get("status"))
    print("[written] contract_sha256:", approval["contract_sha256"])
    print("[written] rebinding_history entries:", len(approval["rebinding_history"]))

    sha_path = APPROVAL.with_suffix(".sha256")
    sha_path.write_text(new_sha + "  " + str(APPROVAL.relative_to(ROOT)) + "\n", encoding="utf-8")
    print("[sidecar] written:", sha_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
