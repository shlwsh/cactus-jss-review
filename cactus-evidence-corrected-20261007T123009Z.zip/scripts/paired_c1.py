#!/usr/bin/env python3
"""CLI entry point for frozen matched C1 planning and gated execution."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = str(ROOT / "src")
if SOURCE not in sys.path:
    sys.path.insert(0, SOURCE)

from cactus.runner.paired_c1 import main


if __name__ == "__main__":
    raise SystemExit(main())
