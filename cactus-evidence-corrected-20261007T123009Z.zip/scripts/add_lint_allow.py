#!/usr/bin/env python3
"""Add data-lint exemption comments to the 4 remaining bare-digit lines in main.tex."""
from pathlib import Path

tex = Path(r'e:\work\p5-acm\acm\paper\main.tex')
lines = tex.read_text(encoding='utf-8').splitlines(keepends=True)

# L75: add exemption at end (after 'alone.')
# L91: add exemption at end (after "...fair comparison.'")  
# L321: add exemption at end (after "...pass_rate}).")
# L349: add exemption at end (after "...effectiveness claims.")

exemptions = {
    74: "% data-lint: allow-next-line reason=cited SWE-bench task identifiers (django-10924, astropy-14365) in citation context",
    90: "% data-lint: allow-next-line reason=cited empirical study counts (640 LLM-for-SE papers; 5,300 Docker builds)",
    320: "% data-lint: allow-next-line reason=cited SWE-bench task identifiers (django-10924, astropy-14365) in citation context",
    348: "% data-lint: allow-next-line reason=standard SHA-256 cryptographic reference (RFC 6234)",
}

for lineno, comment in exemptions.items():
    lines[lineno] = lines[lineno].rstrip('\n\r') + comment + '\n'
    print(f"L{lineno+1}: added exemption")

tex.write_text(''.join(lines), encoding='utf-8')
print("Done")
