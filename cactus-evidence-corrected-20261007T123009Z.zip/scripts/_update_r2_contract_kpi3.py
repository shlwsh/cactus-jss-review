"""Update R2 contract with pending PRE snapshot, then recompute contract SHA.

This script:
1. Updates environment_snapshot_path/sha256/status to the freshly captured
   pending_dacl PRE snapshot.
2. Adds dacl_baseline_* fields for the baseline ACL backup.
3. Updates metadata_paths and _metadata with new artifacts.
4. Recomputes compose_sha256 (which currently holds zeros) with the actual
   SHA of the contract body.
5. Writes the updated contract back atomically.
6. Updates the .sha256 sidecar.
7. Updates session_authorization.linked_contract_sha256.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path

CONTRACT_PATH = Path(
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
)
AUTH_PATH = CONTRACT_PATH.with_name(CONTRACT_PATH.stem + ".session_authorization.json")
SHA_SIDECAR = CONTRACT_PATH.with_suffix(".sha256")

NEW_SNAPSHOT = "experiments/snapshots/C1-pre-r2-20260925T071721Z_pending_dacl.json"
NEW_SNAPSHOT_SHA = "f56fede8bf2bcde24cd6a1bb4c420193d8d96a1d2a151ca105b8b6c6c9a54e60"
DACL_BASELINE = "experiments/snapshots/dacl_baseline_R2_20260925-151621.json"
DACL_BASELINE_SHA = "f5528851cc19e0554602defbe52c341482b7cd995a842f92fd9a7d3666b1d2cb"


def main() -> int:
    data = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))

    # 1. update environment snapshot fields
    exec_block = data.setdefault("execution", {})
    exec_block["environment_snapshot_path"] = NEW_SNAPSHOT
    exec_block["environment_snapshot_sha256"] = NEW_SNAPSHOT_SHA
    exec_block["environment_snapshot_status"] = (
        "PENDING_OWNER_DACL_APPLY — captured by CACTUS Agent 2026-09-25T07:17Z; "
        "data_roots.read_only=False because deny ACE has not yet been applied. "
        "Owner must run `python scripts/apply_r2_dacl.py --apply` then "
        "`python scripts/capture_r2_pre.py --dacl-status observed_with_readonly_true` "
        "and re-run this updater to swap snapshot to the observed one before R2 launch."
    )
    exec_block["dacl_baseline_path"] = DACL_BASELINE
    exec_block["dacl_baseline_sha256"] = DACL_BASELINE_SHA
    exec_block["dacl_baseline_status"] = (
        "BASELINE_CAPTURED — pre-DACL ACL snapshot, used to restore original "
        "permissions after R2 RUN; deny ACE to be stacked on top."
    )

    # 2. update metadata_paths
    paths = data.setdefault("metadata_paths", [])
    for entry in (
        "acm/scripts/capture_r2_pre.py (NEW — captures R2 PRE snapshot)",
        "acm/scripts/apply_r2_dacl.py (NEW — owner step B: applies deny ACE)",
        "experiments/snapshots/dacl_baseline_R2_20260925-151621.json (NEW — baseline ACL)",
        "experiments/snapshots/C1-pre-r2-20260925T071721Z_pending_dacl.json (NEW — pending PRE snapshot)",
        "experiments/snapshots/C1-pre-20260925T025700Z.json (R1 PRE snapshot; superseded for R2)",
    ):
        if entry not in paths:
            paths.append(entry)

    # 3. _metadata addendum
    md = data.setdefault("_metadata", {})
    md["r2_signoff_completed_at"] = "2026-09-25T07:15:39Z"
    md["r2_signoff_quote"] = (
        "授权完成签字，代理 owner 推进卡点3（DACL + snapshot）。批准 R2 "
        "engineering_validation 在 3 任务上继续，吞 USD 0.4（覆盖 USD 2.0 "
        "上限内），paper_supporting tier。"
    )
    md["r2_kpi3_progress"] = {
        "step_a_dacl_baseline_captured": True,
        "step_a_dacl_baseline_path": DACL_BASELINE,
        "step_a_dacl_baseline_sha256": DACL_BASELINE_SHA,
        "step_b_owner_dacl_apply": False,
        "step_c_pre_snapshot_captured_pending": True,
        "step_c_pre_snapshot_pending_path": NEW_SNAPSHOT,
        "step_c_pre_snapshot_pending_sha256": NEW_SNAPSHOT_SHA,
        "step_d_owner_dacl_apply_then_agent_re_capture": False,
        "step_e_contract_update_after_step_d": False,
    }
    md["last_updated_at"] = "2026-09-25T07:17:00Z"

    # 4. recompute compose_sha256 (the file body's actual SHA, not a digest)
    body_bytes = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    body_sha = hashlib.sha256(body_bytes).hexdigest()

    rt = data.setdefault("runtime", {})
    rt["compose_sha256"] = body_sha
    rt["compose_sha256_reason"] = (
        "R2 is single-task engineering dry-run (1 process at a time); no docker "
        "compose manifest required for the prediction pipeline itself. "
        f"compose_sha256 holds the contract body digest for integrity binding."
    )

    # 5. write back atomically
    final_bytes = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    tmp_path = CONTRACT_PATH.with_suffix(".json.tmp")
    tmp_path.write_bytes(final_bytes)
    final_sha = hashlib.sha256(final_bytes).hexdigest()
    tmp_path.replace(CONTRACT_PATH)

    # 6. update .sha256 sidecar
    SHA_SIDECAR.write_text(
        f"{final_sha}  {CONTRACT_PATH.name}\n", encoding="utf-8"
    )

    # 7. update session_authorization.linked_contract_sha256
    if AUTH_PATH.is_file():
        auth = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        auth_meta = auth.setdefault("_metadata", {})
        auth_meta["linked_contract_sha256"] = final_sha
        auth_meta["linked_environment_snapshot_path"] = NEW_SNAPSHOT
        auth_meta["linked_environment_snapshot_sha256"] = NEW_SNAPSHOT_SHA
        auth_meta["linked_dacl_baseline_path"] = DACL_BASELINE
        auth_meta["linked_dacl_baseline_sha256"] = DACL_BASELINE_SHA
        auth_bytes = json.dumps(auth, ensure_ascii=False, sort_keys=True, indent=2).encode(
            "utf-8"
        ) + b"\n"
        auth_tmp = AUTH_PATH.with_suffix(".json.tmp")
        auth_tmp.write_bytes(auth_bytes)
        auth_tmp.replace(AUTH_PATH)

    print(f"contract updated: {CONTRACT_PATH}")
    print(f"contract SHA-256: {final_sha}")
    print(f"compose_sha256  : {body_sha}")
    print(f"PRE snapshot    : {NEW_SNAPSHOT}")
    print(f"PRE sha256      : {NEW_SNAPSHOT_SHA}")
    print(f"DACL baseline   : {DACL_BASELINE}")
    print(f"DACL sha256     : {DACL_BASELINE_SHA}")
    print(f"auth updated    : {AUTH_PATH.is_file()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())