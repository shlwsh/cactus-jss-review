"""Sequential runner for Phase 2 Lite-10 engineering validation with fast-fail."""
from __future__ import annotations

import json
import argparse
import os
import re
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from run_single_task_predict import run_single_task

TASKS = [
    {"task_id": "django__django-10914", "focus": "wrong_module (ORM responsibility chain)"},
    {"task_id": "django__django-10924", "focus": "wrong_module (same package multi-file)"},
    {"task_id": "django__django-11039", "focus": "wrong_module (SQL compiler)"},
    {"task_id": "django__django-11049", "focus": "bracket_mismatch (nested quotes AST)"},
    {"task_id": "django__django-12708", "focus": "bracket_mismatch (embedded quotes)"},
    {"task_id": "astropy__astropy-14365", "focus": "no_op_edit (astropy logic diff)"},
    {"task_id": "django__django-12453", "focus": "no_op_edit (django logic diff)"},
    {"task_id": "django__django-11620", "focus": "TRUNCATED BY TIMEOUT (large file 600s)"},
    {"task_id": "django__django-11815", "focus": "TRUNCATED BY TIMEOUT (context 600s)"},
    {"task_id": "astropy__astropy-6938", "focus": "edge case / exception handling"},
]

STATUS_FILE = PROJECT_ROOT / "experiments/logs/validation_10_status.json"


def update_status(data: dict, status_file: Path = STATUS_FILE) -> None:
    status_file.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(data, ensure_ascii=False, indent=2)
    for _ in range(5):
        try:
            status_file.write_text(content, encoding="utf-8")
            break
        except Exception:
            time.sleep(0.1)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--start-from", type=int, default=1, choices=range(1, len(TASKS) + 1))
    parser.add_argument("--validation-id", default="VALIDATION-10")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", args.validation_id):
        parser.error("--validation-id must use 1-64 letters, digits, dots, underscores, or hyphens")
    status_file = (
        STATUS_FILE if args.validation_id == "VALIDATION-10"
        else PROJECT_ROOT / "experiments/logs" / f"{args.validation_id.lower()}_status.json"
    )
    state = {
        "status": "running",
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "total_tasks": len(TASKS),
        "invocation_task_count": len(TASKS) - args.start_from + 1,
        "start_from": args.start_from,
        "validation_id": args.validation_id,
        "current_index": args.start_from - 1,
        "current_task": None,
        "passed_count": 0,
        "failed_count": 0,
        "results": [],
    }
    update_status(state, status_file)

    for idx, item in enumerate(TASKS, start=1):
        if idx < args.start_from:
            continue
        task_id = item["task_id"]
        focus = item["focus"]
        state["current_index"] = idx
        state["current_task"] = task_id
        state["current_focus"] = focus
        update_status(state, status_file)

        print(f"\n=======================================================", flush=True)
        print(f"[{idx}/{len(TASKS)}] Starting Validation Task: {task_id}", flush=True)
        print(f"Focus: {focus}", flush=True)
        print(f"=======================================================", flush=True)

        runs_dir = PROJECT_ROOT / "experiments/runs" / args.validation_id / task_id
        pred_file = runs_dir / "prediction.jsonl"
        if pred_file.exists() and pred_file.stat().st_size > 0:
            print(f"[CACHE] Task {task_id} already has completed prediction.jsonl, skipping.", flush=True)
            res = {
                "task_id": task_id,
                "status": "passed",
                "cached": True,
                "patch_bytes": pred_file.stat().st_size,
            }
        else:
            res = run_single_task(task_id, validation_id=args.validation_id)
        res["focus"] = focus
        state["results"].append(res)

        if res.get("status") == "passed":
            state["passed_count"] += 1
            update_status(state, status_file)
            run_position = idx - args.start_from + 1
            print(f"[PROGRESS] Task {task_id} PASSED! ({state['passed_count']}/{run_position})", flush=True)
        else:
            state["failed_count"] += 1
            state["status"] = "halted_on_failure"
            state["failure_reason"] = res.get("error", "Unknown error")
            state["failed_task"] = task_id
            update_status(state, status_file)
            print(f"[FAST-FAIL] Task {task_id} FAILED! Halting execution per Rule 5.", flush=True)
            print(f"Error detail: {res.get('error')}", flush=True)
            return 1

    state["status"] = "completed"
    state["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    update_status(state, status_file)
    print(
        f"\n[ALL DONE] Selected validation tasks {args.start_from}-{len(TASKS)} passed!",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
