#!/usr/bin/env python3
"""probe_current_state.py — Check current SHA/DACL consistency."""

import hashlib
import json
import pathlib
import subprocess
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(r"E:\work\p5-acm\acm")
FILES = [
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json",
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.session_authorization.json",
    "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json",
    "experiments/snapshots/C1-pre-r2-20260925T071721Z_pending_dacl.json",
    "experiments/snapshots/dacl_baseline_R2_20260925-151621.json",
]
SIDECAR_HASH_FIELDS = {
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.sha256": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json",
    "experiments/snapshots/C1-pre-r2-20260925T075208Z_observed.json.sha256": "C1-pre-r2-20260925T075208Z_observed.json",
    "experiments/snapshots/C1-pre-r2-20260925T071721Z_pending_dacl.json.sha256": "C1-pre-r2-20260925T071721Z_pending_dacl.json",
    "experiments/snapshots/dacl_baseline_R2_20260925-151621.json.sha256": "dacl_baseline_R2_20260925-151621.json",
}

def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def main() -> int:
    print("=" * 70)
    print("File-body SHA256 (raw bytes)")
    print("=" * 70)
    body_sha = {}
    for rel in FILES:
        p = ROOT / rel
        if not p.exists():
            print(f"MISSING: {rel}")
            continue
        b = p.read_bytes()
        body_sha[rel] = sha_bytes(b)
        print(f"  {body_sha[rel]}  size={len(b)}  {rel}")

    print()
    print("=" * 70)
    print("Canonical-JSON SHA256 (sort_keys, ensure_ascii=False, no spaces)")
    print("=" * 70)
    canonical_sha = {}
    for rel in FILES:
        p = ROOT / rel
        if not p.exists() or not rel.endswith(".json"):
            continue
        text = p.read_text(encoding="utf-8-sig")
        obj = json.loads(text)
        body = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        canonical_sha[rel] = sha_bytes(body)
        print(f"  {canonical_sha[rel]}  size={len(body)}  canonical {rel}")

    print()
    print("=" * 70)
    print("Sidecar .sha256 contents")
    print("=" * 70)
    for sidecar_rel, basename in SIDECAR_HASH_FIELDS.items():
        sp = ROOT / sidecar_rel
        if not sp.exists():
            print(f"  MISSING: {sidecar_rel}")
            continue
        text = sp.read_text(encoding="utf-8").strip()
        print(f"  {text}  {sidecar_rel}")
        # Find the body hash for the matching file
        for rel in FILES:
            if rel.endswith(basename):
                actual = body_sha.get(rel, "")
                expected = text.split()[0]
                match = "OK" if actual == expected else "MISMATCH"
                print(f"     -> actual body sha for {basename}: {actual}  [{match}]")
                break

    print()
    print("=" * 70)
    print("DACL current state on 3 roots (icacls)")
    print("=" * 70)
    for p in [r"E:\docker-bak\cactus\pilot50", r"E:\cactus-data\repo-cache", r"E:\cactus-data\swebench"]:
        try:
            r = subprocess.run(["icacls", p], capture_output=True, text=True, timeout=30)
            print(f"--- {p} ---")
            for line in r.stdout.splitlines():
                if line.strip():
                    print(f"  {line.strip()}")
            if r.returncode != 0:
                print(f"  [stderr] {r.stderr.strip()}")
        except Exception as exc:
            print(f"--- {p} ---")
            print(f"  exc: {exc}")

    return 0

if __name__ == "__main__":
    sys.exit(main())
