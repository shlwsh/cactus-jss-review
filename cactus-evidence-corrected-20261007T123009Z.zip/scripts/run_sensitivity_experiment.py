"""P1.3 FACO Weight Sensitivity Analysis: Compare different scoring weight configurations.

Runs 5 weight configurations on the 10-task ablation cohort:
  1. baseline  (cactus_full: lexical=0.30, symbol=0.25, graph=0.20, test=0.10, path=0.10)
  2. sym_heavy  (lexical=0.20, symbol=0.50, graph=0.15, test=0.10, path=0.05)
  3. lex_heavy  (lexical=0.50, symbol=0.20, graph=0.15, test=0.10, path=0.05)
  4. flat       (all=0.20)
  5. no_graph    (lexical=0.35, symbol=0.30, graph=0.00, test=0.20, path=0.15)

Usage:
    python scripts/run_sensitivity_experiment.py [--limit N] [--dry-run] [--variant NAME]
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RUNS_DIR = PROJECT_ROOT / "experiments" / "runs"
MANIFEST = PROJECT_ROOT / "data/manifests/swebench_lite50_b0dde109_test_inference_safe.jsonl"
MODEL_CONFIG = PROJECT_ROOT / "configs/models/lite50_v3_dual_insurance.json"

# Sensitivity weight configurations mapped to engine variant names
SENSITIVITY_VARIANTS = [
    "sensitivity_sym_heavy",
    "sensitivity_lex_heavy",
    "sensitivity_flat",
    "sensitivity_no_graph",
]

WEIGHT_DESCRIPTIONS = {
    "sensitivity_sym_heavy": "Sym-heavy (lex=0.20, sym=0.50, gra=0.15, tst=0.10, pth=0.05)",
    "sensitivity_lex_heavy": "Lex-heavy (lex=0.50, sym=0.20, gra=0.15, tst=0.10, pth=0.05)",
    "sensitivity_flat":       "Flat (all=0.20)",
    "sensitivity_no_graph":   "No-graph (lex=0.35, sym=0.30, gra=0.00, tst=0.20, pth=0.15)",
}

# 10-task ablation cohort (same as the 10 tasks in ablation_results_*.json)
ABLATION_10_TASKS = [
    "astropy__astropy-12907", "astropy__astropy-14182", "astropy__astropy-14365",
    "astropy__astropy-14995", "astropy__astropy-6938",  "astropy__astropy-7746",
    "django__django-10914",    "django__django-10924",   "django__django-11001",
    "django__django-11019",
]


def get_best_patch(run_dir: Path, task_id: str) -> tuple[bool, int, str | None]:
    """Return (has_patch, patch_len, run_name) for the best patch across runs."""
    best_len = 0
    best_run = None
    for run_name in sorted(run_dir.iterdir()):
        if not run_name.is_dir():
            continue
        pred_path = run_name / task_id / "prediction.jsonl"
        if pred_path.exists():
            try:
                with open(pred_path, encoding="utf-8") as f:
                    data = json.loads(f.readline())
                patch = data.get("model_patch", "")
                if patch and patch.strip() and len(patch) > best_len:
                    best_len = len(patch)
                    best_run = run_name.name
            except Exception:
                pass
    return best_len > 0, best_len, best_run


def run_one(task_id: str, variant: str, validation_id: str, dry_run: bool) -> dict:
    """Run a single task prediction."""
    output_dir = RUNS_DIR / validation_id / task_id
    output_dir.mkdir(parents=True, exist_ok=True)
    trace_path = output_dir / "trace.jsonl"

    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_single_task_predict.py"),
        "--task-id", task_id,
        "--variant", variant,
        "--validation-id", validation_id,
    ]

    if dry_run:
        print(f"  [DRY RUN] {' '.join(cmd)}")
        return {"task_id": task_id, "variant": variant, "status": "dry_run", "duration": 0}

    started = time.time()
    try:
        env = subprocess.os.environ.copy()
        env["PYTHONPATH"] = str(PROJECT_ROOT)
        result = subprocess.run(
            cmd,
            cwd=str(PROJECT_ROOT),
            env=env,
            capture_output=True,
            text=True,
            timeout=900,
        )
        duration = time.time() - started
        success = result.returncode == 0
        has_patch = False
        patch_len = 0
        if success:
            has_patch, patch_len, _ = get_best_patch(RUNS_DIR, task_id)
        return {
            "task_id": task_id,
            "variant": variant,
            "status": "PASS" if has_patch else "FAIL",
            "patch_len": patch_len,
            "duration": round(duration, 1),
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        duration = time.time() - started
        return {
            "task_id": task_id,
            "variant": variant,
            "status": "TIMEOUT",
            "duration": round(duration, 1),
            "returncode": -1,
        }
    except Exception as e:
        duration = time.time() - started
        return {
            "task_id": task_id,
            "variant": variant,
            "status": "ERROR",
            "error": str(e),
            "duration": round(duration, 1),
            "returncode": -2,
        }


def run_variant(variant: str, tasks: list[str], limit: int | None, dry_run: bool) -> list[dict]:
    """Run all tasks for a given variant."""
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    validation_id = f"SENSITIVITY-{variant.upper()}-{ts}"
    desc = WEIGHT_DESCRIPTIONS.get(variant, variant)
    print(f"\n=== Variant: {variant} [{desc}] ===")
    print(f"Validation ID: {validation_id}")
    print(f"Tasks: {len(tasks)}")

    results = []
    for i, task_id in enumerate(tasks):
        if limit and i >= limit:
            break
        print(f"  [{i+1}/{len(tasks)}] {task_id}...", end=" ", flush=True)
        result = run_one(task_id, variant, validation_id, dry_run)
        results.append(result)
        print(f"{result['status']} ({result.get('duration', 0):.0f}s)")
        if not dry_run:
            time.sleep(2)  # Rate limiting

    return results


def summarize(results: list[dict], variant: str) -> dict:
    """Summarize results for a variant."""
    total = len(results)
    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    timeout = sum(1 for r in results if r["status"] == "TIMEOUT")
    error = sum(1 for r in results if r["status"] == "ERROR")
    durations = [r["duration"] for r in results if r.get("duration")]
    avg_duration = sum(durations) / len(durations) if durations else 0
    return {
        "variant": variant,
        "description": WEIGHT_DESCRIPTIONS.get(variant, ""),
        "total": total,
        "passed": passed,
        "failed": failed,
        "timeout": timeout,
        "error": error,
        "pass_rate": f"{passed}/{total}",
        "avg_duration": round(avg_duration, 1),
    }


def print_summary_table(all_summaries: list[dict]):
    """Print a comparison table."""
    print("\n" + "=" * 80)
    print("FACO Weight Sensitivity Analysis Results (10-task cohort)")
    print("=" * 80)
    print(f"{'Variant':<28} {'Description':<45} {'PASS':>6} {'Avg Time':>10}")
    print("-" * 80)
    for s in sorted(all_summaries, key=lambda x: -x["passed"]):
        print(f"{s['variant']:<28} {s['description']:<45} {s['pass_rate']:>6} {s['avg_duration']:>9.1f}s")
    print("=" * 80)


def main():
    parser = argparse.ArgumentParser(description="FACO Weight Sensitivity Analysis")
    parser.add_argument("--variant", default=None, help="Run a single variant only")
    parser.add_argument("--limit", type=int, default=None, help="Limit tasks per variant")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    variants_to_run = [args.variant] if args.variant else SENSITIVITY_VARIANTS

    all_results = []
    all_summaries = []

    for variant in variants_to_run:
        if variant not in SENSITIVITY_VARIANTS:
            print(f"Unknown variant: {variant}")
            print(f"Available: {SENSITIVITY_VARIANTS}")
            sys.exit(1)

        results = run_variant(variant, ABLATION_10_TASKS, args.limit, args.dry_run)
        summary = summarize(results, variant)
        all_results.extend(results)
        all_summaries.append(summary)

    print_summary_table(all_summaries)

    # Save results
    if not args.dry_run:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        output_file = PROJECT_ROOT / "experiments" / "derived" / f"sensitivity_results_{ts}.json"
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output = {
            "summaries": {s["variant"]: {
                "variant": s["variant"],
                "description": s["description"],
                "total": s["total"],
                "passed": s["passed"],
                "failed": s["failed"],
                "timeout": s["timeout"],
                "error": s["error"],
                "pass_rate": s["pass_rate"],
                "avg_duration": s["avg_duration"],
            } for s in all_summaries},
            "detailed": all_results,
            "generated_at": ts,
        }
        output_file.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"\nResults saved to: {output_file}")


if __name__ == "__main__":
    main()
