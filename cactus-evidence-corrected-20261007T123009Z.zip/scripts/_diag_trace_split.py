"""Trace _recover_flattened_indent split for the inner-helper test case."""
import re

s = (
    "        def as_scalar_or_list_str(obj):"
    "            if not hasattr(obj, '__len__'):"
    "                return f'{{obj}}'"
    "            elif len(obj) == 1:"
    "                return f'{{obj[0]}}'"
    "            else:"
    "                return str(obj)"
    "        if not self._required_columns_enabled:"
)

print("=== split by (:\\s{2,}) ===")
raw_parts = re.split(r"(:\s{2,})", s)
for i, p in enumerate(raw_parts):
    print(f"  part {i}: {p!r}")

print("\n=== split part 4 by (\\s{4,}) ===")
part4 = raw_parts[8]  # last text fragment
print(f"  part4 raw: {part4!r}")
sub = re.split(r"(\s{4,})", part4)
for i, p in enumerate(sub):
    print(f"  sub {i}: {p!r}")