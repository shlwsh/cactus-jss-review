"""Evidence-first RQ3 failure attribution for sealed CACTUS RUN bundles.

The classifier emits A-D only when the bundle contains direct supporting
signals. Ambiguous cases remain ``pending_evidence`` for manual review.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from cactus.adapters.benchmark import load_manifest

_QUOTED_SYMBOL = re.compile(r"`([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)`")
_DIFF_HEADER = re.compile(r"^diff --git a/(.+?) b/(.+?)$")
_NEW_FILE_HEADER = re.compile(r"^\+\+\+ b/(.+)$")
_HUNK_HEADER = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@")


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def _report_payloads(bundle: Path) -> list[dict[str, Any]]:
    reports: list[dict[str, Any]] = []
    for path in bundle.rglob("*.json"):
        if path.name in {"result.json", "run_manifest.json", "contract.json", "resolved_config.json", "environment.pre.json", "environment.post.json"}:
            continue
        payload = _read_json(path)
        if payload is not None and any(key in payload for key in ("infra_failure_instances", "resolved_instances", "unresolved_instances")):
            reports.append(payload)
    return reports


def _selected_unit_metadata(trace_path: Path) -> tuple[list[dict[str, Any]], bool]:
    selected: dict[str, dict[str, Any]] = {}
    complete = False
    final_selection_seen = False
    if not trace_path.is_file():
        return [], complete
    for line in trace_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        payload = event.get("payload") if isinstance(event, dict) and isinstance(event.get("payload"), dict) else {}
        if event.get("type") == "prediction_patch_context":
            units = payload.get("selected_units")
            if isinstance(units, list):
                selected = {str(row["unit_id"]): row for row in units if isinstance(row, dict) and isinstance(row.get("unit_id"), str)}
                complete = payload.get("metadata_complete") is True
                final_selection_seen = True
        elif final_selection_seen:
            continue
        elif event.get("type") == "context_selection_metadata":
            units = payload.get("selected_units")
            if isinstance(units, list):
                selected.update({str(row["unit_id"]): row for row in units if isinstance(row, dict) and isinstance(row.get("unit_id"), str)})
                complete = payload.get("metadata_complete") is True
        elif event.get("type") == "repair_sites":
            units = payload.get("selected_units")
            ids = payload.get("selected_unit_ids")
            if isinstance(units, list) and isinstance(ids, list):
                selected.update({str(row["unit_id"]): row for row in units if isinstance(row, dict) and isinstance(row.get("unit_id"), str)})
                complete = len(selected) >= len(ids)
    return list(selected.values()), complete


def _prediction_patch(path: Path) -> str:
    if not path.is_file():
        return ""
    patches: list[str] = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(row, dict):
            continue
        value = row.get("model_patch", row.get("patch"))
        if isinstance(value, str):
            patches.append(value)
    return "\n".join(patches)


def _patch_hunks(patch: str) -> list[tuple[str, int, int]]:
    hunks: list[tuple[str, int, int]] = []
    current_path: str | None = None
    for line in patch.splitlines():
        diff_match = _DIFF_HEADER.match(line)
        if diff_match:
            current_path = diff_match.group(2)
            continue
        file_match = _NEW_FILE_HEADER.match(line)
        if file_match:
            current_path = file_match.group(1)
            continue
        hunk_match = _HUNK_HEADER.match(line)
        if hunk_match and current_path and current_path != "/dev/null":
            start = int(hunk_match.group(1))
            count = int(hunk_match.group(2) or "1")
            hunks.append((current_path.replace("\\", "/").casefold(), start, max(1, count)))
    return hunks


def _hunk_is_selected(path: str, start: int, count: int, units: list[dict[str, Any]]) -> bool:
    end = start + count - 1
    for unit in units:
        unit_path = str(unit.get("path", "")).replace("\\", "/").casefold()
        if unit_path != path:
            continue
        if unit.get("kind") == "file":
            return True
        first, last = unit.get("start_line"), unit.get("end_line")
        if isinstance(first, int) and isinstance(last, int) and start <= last and end >= first:
            return True
    return False


def classify_bundle(bundle: Path, *, issue_by_task: dict[str, str] | None = None) -> dict[str, Any]:
    manifest = _read_json(bundle / "run_manifest.json") or {}
    result = _read_json(bundle / "raw" / "result.json") or {}
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    error = result.get("error") if isinstance(result.get("error"), dict) else manifest.get("error") or {}
    reports = _report_payloads(bundle)
    trace_path = bundle / "trace" / "events.jsonl"
    selected_units, selection_metadata_complete = _selected_unit_metadata(trace_path)
    issue_text = ""
    task_id = str(manifest.get("task_id") or data.get("task_id") or bundle.name)
    issue_text = (issue_by_task or {}).get(task_id, issue_text)
    resolved = bool(data.get("resolved"))
    category = "pending_evidence"
    evidence: list[str] = []
    infra_reports = [
        report for report in reports
        if any(int(report.get(field) or 0) > 0 for field in (
            "infra_failure_instances", "ambiguous_failure_instances", "unstopped_instances"
        ))
    ]
    if resolved:
        category = "resolved"
        evidence.append("raw/result.json:data.resolved=true")
    elif infra_reports:
        # Infrastructure evidence remains useful even when the evaluator marks
        # the task result invalid.  Requiring evaluator_valid here would make
        # environment failures impossible to attribute to category D.
        category = "D"
        evidence.append("official evaluator report records infrastructure, ambiguous, or unstopped-container failures")
    elif data.get("evaluator_valid") is not True:
        evidence.append("evaluator_valid is not true; task failure attribution is withheld")
    else:
        if manifest.get("status") == "failed" and not reports:
            evidence.append("run failed before a valid evaluator report; failure stage is not sufficient to attribute D")
        else:
            patch = _prediction_patch(bundle / "raw" / "prediction.jsonl")
            hunks = _patch_hunks(patch)
            selected_symbols = {str(unit.get("symbol_id")).casefold() for unit in selected_units if unit.get("symbol_id")}
            has_whole_file_unit = any(unit.get("kind") == "file" for unit in selected_units)
            if issue_text and selected_units and selection_metadata_complete and not has_whole_file_unit:
                symbols = {match.group(1).rsplit(".", 1)[-1].casefold() for match in _QUOTED_SYMBOL.finditer(issue_text)}
                if symbols and not symbols.intersection(selected_symbols):
                    category = "A"
                    evidence.append("quoted issue symbols are absent from complete selected symbol-unit metadata")
            if category == "pending_evidence" and hunks and selected_units and selection_metadata_complete:
                selected_hunks = [_hunk_is_selected(path, start, count, selected_units) for path, start, count in hunks]
                if not all(selected_hunks):
                    category = "B"
                    evidence.append("one or more predicted patch hunks fall outside selected file/symbol spans")
                else:
                    category = "C"
                    evidence.append("all predicted patch hunks overlap selected file/symbol spans; expert review is needed to assess reasoning")
            if category == "pending_evidence":
                evidence.append("complete selected-unit source locations and patch hunk ranges are unavailable")
    return {
        "run_id": manifest.get("run_id", bundle.name),
        "campaign_id": manifest.get("campaign_id"),
        "task_id": task_id,
        "variant_id": manifest.get("variant_id"),
        "status": manifest.get("status"),
        "resolved": resolved,
        "category": category,
        "evidence": evidence,
        "manual_review_required": category == "pending_evidence" or category == "C",
        "source_run_manifest_sha256": hashlib.sha256((bundle / "run_manifest.json").read_bytes()).hexdigest() if (bundle / "run_manifest.json").is_file() else None,
        "error_code": error.get("code") if isinstance(error, dict) else None,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="Directory containing sealed RUN-* bundles")
    parser.add_argument("--tasks", type=Path, help="Inference-safe JSONL, used only to recover issue text for A-class screening")
    parser.add_argument("--campaign-id", help="Limit analysis to one frozen campaign")
    parser.add_argument("--output", type=Path, required=True, help="Derived JSONL destination")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if args.output.exists() and not args.overwrite:
        parser.error(f"output exists; pass --overwrite to replace it: {args.output}")
    bundles = sorted(path for path in args.runs.glob("RUN-*") if path.is_dir() and (path / "run_manifest.json").is_file())
    issue_by_task = {task.task_id: task.issue_text for task in load_manifest(args.tasks)} if args.tasks else {}
    rows = [
        row for bundle in bundles
        if (row := classify_bundle(bundle, issue_by_task=issue_by_task)).get("campaign_id") == args.campaign_id
    ] if args.campaign_id else [classify_bundle(bundle, issue_by_task=issue_by_task) for bundle in bundles]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8", newline="\n")
    counts: dict[str, int] = {}
    for row in rows:
        counts[row["category"]] = counts.get(row["category"], 0) + 1
    print(json.dumps({"bundles": len(rows), "category_counts": counts, "output": str(args.output)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
