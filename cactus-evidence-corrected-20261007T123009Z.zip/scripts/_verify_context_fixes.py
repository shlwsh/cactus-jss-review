"""Verify context selector fixes for R4 tasks.

Tests the three fixes:
1. Symbol extraction: len>=8 and "." not in name filters removed
2. Parent class propagation via INHERIT edges
3. Manifest completeness verification

Usage:
    & .\.venv\Scripts\python.exe scripts\_verify_context_fixes.py
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

# Add src to path
ROOT = Path("E:/work/p5-acm/acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.task.parser import parse_task


def test_fix1_symbol_extraction():
    """Verify Fix 1: Short names and dotted names are now extracted."""
    print("\n=== Fix 1: 符号提取 ===")

    test_cases = [
        # (issue_text, expected_symbols, task_name)
        (
            # Task 13033: issue mentions _check_required_columns
            """
            The error occurs in _check_required_columns method.
            The TimeSeries class has a required columns check.
            Call _check_required_columns() after column removal.
            """,
            {"_check_required_columns", "TimeSeries"},  # These should be extracted
            "task_13033_private_method",
        ),
        (
            # Task with dotted symbol
            """
            The error is in BaseTimeSeries._check_required_columns.
            This method validates the required columns.
            """,
            {"_check_required_columns", "BaseTimeSeries"},
            "task_dotted_symbol",
        ),
        (
            # Short name (3 chars)
            """
            The bug is in the `min` function call.
            The `max` value is incorrect.
            """,
            {"min", "max"},
            "task_short_names",
        ),
    ]

    # Load actual task 13033 issue text
    manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
    task_13033_text = None
    task_13236_text = None
    with open(manifest) as f:
        for line in f:
            t = json.loads(line)
            if t["task_id"] == "astropy__astropy-13033":
                task_13033_text = t["issue_text"]
            if t["task_id"] == "astropy__astropy-13236":
                task_13236_text = t["issue_text"]

    all_passed = True

    # Test with actual task 13033
    print(f"\n  任务 astropy__astropy-13033 实际 issue:")
    intent = parse_task(task_13033_text)
    symbols = list(intent.mentioned_symbols)
    files = list(intent.mentioned_files)
    print(f"    提取的符号: {symbols[:10]}")
    print(f"    提取的文件: {files[:5]}")

    # Check if _check_required_columns is mentioned in the issue
    has_check = any("check" in s.lower() for s in symbols)
    print(f"    包含 check 相关符号: {has_check}")

    # Check if core.py or timeseries is mentioned
    has_core = any("core" in f or "timeseries" in f for f in files)
    print(f"    包含 timeseries/core 路径: {has_core}")

    # Test with synthetic cases
    for issue_text, expected, name in test_cases:
        intent = parse_task(issue_text)
        extracted = set(intent.mentioned_symbols)
        matched = extracted & expected
        missing = expected - extracted

        if missing:
            print(f"  FAIL {name}: 缺少 {missing}")
            all_passed = False
        else:
            print(f"  PASS {name}: 提取了 {matched}")

    return all_passed


def test_fix1_regex_pattern():
    """Verify the new regex pattern extracts dotted names."""
    print("\n=== Fix 1: 正则表达式 ===")

    # The new pattern from engine.py
    pattern = r"`\s*([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\s*`"

    test_cases = [
        ('`BaseTimeSeries._check_required_columns`', ['BaseTimeSeries._check_required_columns']),
        ('`_check_required_columns`', ['_check_required_columns']),
        ('`min` and `max`', ['min', 'max']),
        ('`Table.__init__`', ['Table.__init__']),
        ('`TimeSeries`', ['TimeSeries']),
        ('`separability_matrix`', ['separability_matrix']),
    ]

    all_passed = True
    for text, expected in test_cases:
        found = [m.strip() for m in re.findall(pattern, text)]
        if set(found) == set(expected):
            print(f"  PASS: {text[:50]} -> {found}")
        else:
            print(f"  FAIL: {text[:50]} -> got {found}, expected {expected}")
            all_passed = False

    return all_passed


def test_fix1_length_filter():
    """Verify the length filter is now >= 3 (was >= 8)."""
    print("\n=== Fix 1: 长度过滤 ===")

    names_3_chars = ["min", "max", "abs"]
    names_5_chars = ["round", "split", "merge"]

    # Old filter: len >= 8
    old_filter = lambda n: len(n) >= 8 and "." not in n
    # New filter: len >= 3
    new_filter = lambda n: len(n) >= 3

    print(f"  旧过滤 (len>=8): 3字符={any(old_filter(n) for n in names_3_chars)}, 5字符={any(old_filter(n) for n in names_5_chars)}")
    print(f"  新过滤 (len>=3): 3字符={any(new_filter(n) for n in names_3_chars)}, 5字符={any(new_filter(n) for n in names_5_chars)}")

    return not any(old_filter(n) for n in names_3_chars) and any(new_filter(n) for n in names_3_chars)


def test_fix2_propagation_anchors():
    """Verify Fix 2: propagated_mandatory_ids variable is properly declared."""
    print("\n=== Fix 2: 传播锚点变量 ===")

    engine_src = (ROOT / "src" / "cactus" / "engine.py").read_text(encoding="utf-8")

    # Check that propagated_mandatory_ids is declared
    has_propagated_var = "propagated_mandatory_ids" in engine_src
    print(f"  propagated_mandatory_ids 变量存在: {has_propagated_var}")

    # Check that mandatory.update(propagated_mandatory_ids) exists
    has_update = "mandatory.update(propagated_mandatory_ids)" in engine_src
    print(f"  mandatory.update(propagated_mandatory_ids) 存在: {has_update}")

    # Check that INHERIT propagation logic exists
    has_inherit = "INHERIT" in engine_src and "inherit_adj" in engine_src
    print(f"  INHERIT 传播逻辑存在: {has_inherit}")

    return has_propagated_var and has_update and has_inherit


def test_fix3_manifest_coverage():
    """Verify Fix 3: Manifest completeness script exists and works."""
    print("\n=== Fix 3: Manifest 完整性脚本 ===")

    script = ROOT / "scripts" / "_verify_context_completeness.py"
    exists = script.exists()
    print(f"  脚本存在: {exists}")

    if exists:
        # Check it can be imported
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("_verify", str(script))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            print(f"  脚本可导入: True")
            return True
        except Exception as e:
            print(f"  脚本导入失败: {e}")
            return False
    return False


def test_inference_safe_manifest():
    """Verify inference-safe manifest structure."""
    print("\n=== Manifest 结构验证 ===")

    manifest = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
    tasks = {}
    with open(manifest) as f:
        for line in f:
            t = json.loads(line)
            tasks[t["task_id"]] = t

    # Check R4 tasks exist
    r4_tasks = ["astropy__astropy-13033", "astropy__astropy-13236", "astropy__astropy-12907"]
    for tid in r4_tasks:
        exists = tid in tasks
        print(f"  {tid}: {'存在' if exists else '不存在'}")

    # Check fields
    for tid in r4_tasks:
        t = tasks.get(tid, {})
        has_text = "issue_text" in t or "problem_statement" in t
        has_repo = "repo" in t or "repo_id" in t
        has_commit = "base_commit" in t
        print(f"  {tid} - issue: {has_text}, repo: {has_repo}, commit: {has_commit}")

    return all(tid in tasks for tid in r4_tasks)


def test_engine_import():
    """Verify engine module imports without errors."""
    print("\n=== Engine 导入测试 ===")

    try:
        from cactus.engine import ContextEngine
        print(f"  ContextEngine 导入成功: True")
        return True
    except Exception as e:
        print(f"  ContextEngine 导入失败: {e}")
        return False


def main():
    print("=" * 70)
    print("R4 上下文选择器修复验证")
    print("=" * 70)

    results = {}

    results["fix1_regex"] = test_fix1_regex_pattern()
    results["fix1_length"] = test_fix1_length_filter()
    results["fix1_extraction"] = test_fix1_symbol_extraction()
    results["fix2_propagation"] = test_fix2_propagation_anchors()
    results["fix3_script"] = test_fix3_manifest_coverage()
    results["manifest_structure"] = test_inference_safe_manifest()
    results["engine_import"] = test_engine_import()

    print("\n" + "=" * 70)
    print("验证结果汇总")
    print("=" * 70)

    for name, passed in results.items():
        emoji = "PASS" if passed else "FAIL"
        print(f"  [{emoji}] {name}")

    passed_count = sum(1 for v in results.values() if v)
    print(f"\n通过: {passed_count}/{len(results)}")

    if passed_count == len(results):
        print("\n所有修复验证通过！R4 可以重新执行。")
        print("\n建议: 运行完整预测验证:")
        print("  & .\\.venv\\Scripts\\python.exe scripts\\_test_r4_prediction.py")
    else:
        failed = [k for k, v in results.items() if not v]
        print(f"\n失败的验证: {failed}")

    return 0 if passed_count == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
