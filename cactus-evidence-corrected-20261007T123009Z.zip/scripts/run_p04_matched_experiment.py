"""P0-4 Frozen Matched Context Study Batch Runner.

Executes 100 tasks x 4 strategies (FACO, BM25, MAXIMAL, STRUCTURAL) = 400 runs.
Using DeepSeek-Coding via LiteLLM gateway with budget=16384 tokens.

Usage:
    bun run docs/llm/mykey.ts -- python scripts/run_p04_matched_experiment.py --limit 1 --strategy FACO
    bun run docs/llm/mykey.ts -- python scripts/run_p04_matched_experiment.py --strategy ALL
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

# Add src to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from cactus.adapters.benchmark import BenchmarkTask, load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit


COHORT_MANIFEST = PROJECT_ROOT / "experiments" / "plans" / "P04_matched_100tasks_cohort.jsonl"
MODEL_CONFIG = PROJECT_ROOT / "configs" / "models" / "litellm_local_nothink_v7.json"
REPO_CACHE_DIR = Path(os.environ.get("CACTUS_REPO_CACHE_ROOT", r"E:\cactus-data\repo-cache"))
SCRATCH_BASE = Path(os.environ.get("CACTUS_SCRATCH_ROOT", r"E:\cactus-data\lite50\scratch"))

STRATEGY_MAP = {
    "FACO": "cactus_full",
    "BM25": "lexical_bm25",
    "MAXIMAL": "maximal_context",
    "STRUCTURAL": "cactus_no_semantic",
}


def load_cohort_tasks(manifest_path: Path) -> list[BenchmarkTask]:
    if not manifest_path.exists():
        raise FileNotFoundError(f"Cohort manifest not found: {manifest_path}")
    return load_manifest(manifest_path)


def run_single_prediction(
    task: BenchmarkTask,
    strategy: str,
    variant: str,
    output_dir: Path,
    dry_run: bool = False,
) -> dict[str, Any]:
    task_id = task.task_id
    pred_file = output_dir / "prediction.jsonl"
    trace_file = output_dir / "events.jsonl"
    log_file = output_dir / "predict.log"

    # Skip if already completed and valid
    if pred_file.exists() and pred_file.stat().st_size > 0:
        try:
            line = pred_file.read_text(encoding="utf-8").strip()
            data = json.loads(line)
            if "model_patch" in data:
                return {
                    "task_id": task_id,
                    "strategy": strategy,
                    "variant": variant,
                    "status": "skipped_already_done",
                    "patch_length": len(data.get("model_patch", "")),
                    "duration_sec": 0.0,
                }
        except Exception:
            pass

    if dry_run:
        print(f"  [DRY-RUN] Would run {task_id} with strategy={strategy} ({variant})")
        return {
            "task_id": task_id,
            "strategy": strategy,
            "variant": variant,
            "status": "dry_run",
            "duration_sec": 0.0,
        }

    output_dir.mkdir(parents=True, exist_ok=True)
    temp_workspace = SCRATCH_BASE / f"p04_{task_id}_{strategy}_{int(time.time())}"
    temp_workspace.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    try:
        # 1. Checkout base commit from local cache
        print(f"  [{task_id} | {strategy}] Materializing base commit {task.base_commit[:8]}...", flush=True)
        repo_root = checkout_base_commit(
            task,
            cache_root=REPO_CACHE_DIR,
            workspace_root=temp_workspace,
            allow_network_fetch=False,
        )

        # 2. Invoke cactus_swebench_predict.py
        cmd = [
            sys.executable,
            str(PROJECT_ROOT / "scripts" / "cactus_swebench_predict.py"),
            "--tasks", str(COHORT_MANIFEST),
            "--task-id", task_id,
            "--repo-root", str(repo_root),
            "--model-config", str(MODEL_CONFIG),
            "--trace", str(trace_file),
            "--output", str(pred_file),
            "--budget", "16384",
            "--request-timeout-sec", "600",
            "--variant", variant,
        ]

        child_env = os.environ.copy()
        child_env["PYTHONPATH"] = f"{PROJECT_ROOT / 'src'};{PROJECT_ROOT}"

        print(f"  [{task_id} | {strategy}] Running prediction model call...", flush=True)
        proc = subprocess.run(
            cmd,
            cwd=str(PROJECT_ROOT),
            capture_output=True,
            text=True,
            timeout=1200,
            env=child_env,
        )

        elapsed = time.time() - t0
        log_file.write_text(f"STDOUT:\n{proc.stdout}\n\nSTDERR:\n{proc.stderr}\n", encoding="utf-8")

        success = proc.returncode == 0 and pred_file.exists() and pred_file.stat().st_size > 0
        patch_len = 0
        if success:
            try:
                line = pred_file.read_text(encoding="utf-8").strip()
                data = json.loads(line)
                patch_len = len(data.get("model_patch", ""))
            except Exception:
                pass

        status = "success" if success else "failed"
        print(f"  [{task_id} | {strategy}] -> {status.upper()} (patch_len={patch_len}, elapsed={elapsed:.1f}s)", flush=True)

        return {
            "task_id": task_id,
            "strategy": strategy,
            "variant": variant,
            "status": status,
            "patch_length": patch_len,
            "duration_sec": elapsed,
            "error": proc.stderr[:300] if not success else None,
        }

    except Exception as exc:
        elapsed = time.time() - t0
        print(f"  [{task_id} | {strategy}] -> EXCEPTION: {exc}", flush=True)
        return {
            "task_id": task_id,
            "strategy": strategy,
            "variant": variant,
            "status": "exception",
            "duration_sec": elapsed,
            "error": str(exc),
        }
    finally:
        # Clean temporary workspace to reclaim disk space
        shutil.rmtree(temp_workspace, ignore_errors=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="P0-4 Matched Context Study Runner")
    parser.add_argument("--strategy", choices=["FACO", "BM25", "MAXIMAL", "STRUCTURAL", "ALL"], default="ALL")
    parser.add_argument("--limit", type=int, default=None, help="Limit number of tasks to execute")
    parser.add_argument("--task-id", type=str, default=None, help="Specific task ID to run")
    parser.add_argument("--dry-run", action="store_true", help="Preview execution plan without calling model")
    parser.add_argument("--campaign-dir", type=str, default="P04-MATCHED-100TASKS", help="Subdirectory under experiments/runs")
    args = parser.parse_args()

    tasks = load_cohort_tasks(COHORT_MANIFEST)
    print(f"Loaded {len(tasks)} tasks from cohort manifest.")

    if args.task_id:
        tasks = [t for t in tasks if t.task_id == args.task_id]
        if not tasks:
            print(f"Task {args.task_id} not found in cohort!")
            sys.exit(1)

    if args.limit is not None and args.limit > 0:
        tasks = tasks[:args.limit]
        print(f"Limited execution to first {len(tasks)} task(s).")

    strategies = list(STRATEGY_MAP.keys()) if args.strategy == "ALL" else [args.strategy]

    base_runs_dir = PROJECT_ROOT / "experiments" / "runs" / args.campaign_dir
    base_runs_dir.mkdir(parents=True, exist_ok=True)

    total_runs = len(tasks) * len(strategies)
    print(f"\n=== P0-4 Execution Plan: {len(tasks)} tasks x {len(strategies)} strategies = {total_runs} runs ===")
    print(f"Output root: {base_runs_dir}")

    results = []
    run_idx = 0
    t_start = time.time()
    summary_path = PROJECT_ROOT / "experiments" / "derived" / "p04_progress_summary.json"
    summary_path.parent.mkdir(parents=True, exist_ok=True)

    def write_summary() -> None:
        t_elapsed = time.time() - t_start
        s_count = sum(1 for r in results if r["status"] in ("success", "skipped_already_done"))
        strat_stats = {}
        for s in strategies:
            strat_runs = [r for r in results if r["strategy"] == s]
            strat_s = sum(1 for r in strat_runs if r["status"] in ("success", "skipped_already_done"))
            strat_stats[s] = {
                "total": len(strat_runs),
                "success": strat_s,
                "success_rate": round(strat_s / max(1, len(strat_runs)), 4),
            }
        summary_data = {
            "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "campaign_dir": args.campaign_dir,
            "total_runs": len(results),
            "planned_runs": total_runs,
            "success_runs": s_count,
            "elapsed_sec": round(t_elapsed, 2),
            "strategy_stats": strat_stats,
            "results": results,
        }
        summary_path.write_text(json.dumps(summary_data, indent=2), encoding="utf-8")

    for task in tasks:
        for strat in strategies:
            run_idx += 1
            variant = STRATEGY_MAP[strat]
            out_dir = base_runs_dir / strat / task.task_id
            print(f"\n[{run_idx}/{total_runs}] Starting {task.task_id} with strategy={strat} ({variant})...", flush=True)
            res = run_single_prediction(task, strat, variant, out_dir, dry_run=args.dry_run)
            results.append(res)
            write_summary()

    t_total = time.time() - t_start
    success_count = sum(1 for r in results if r["status"] in ("success", "skipped_already_done"))

    print(f"\n=== P0-4 Batch Execution Complete ===")
    print(f"Completed {len(results)} runs in {t_total:.1f}s.")
    print(f"Success/Skipped: {success_count}/{len(results)} ({success_count/max(1, len(results))*100:.1f}%)")
    print(f"Progress summary written to {summary_path}")


if __name__ == "__main__":
    main()
