"""Reconcile the V23-C1 contract's model section to match
configs/models/litellm_local_nothink_v7.json (the model used by R4 and
C1 execution). This is a P-06 step needed because the contract was frozen
against litellm_local.json (v6, max_output=16384) while C1 uses v7
(no-think, max_output=32768). The session_authorization record remains the
approved record (owner choice: use-existing-approval).

This script:
  - reads contract + v7 model_config
  - updates overlapping fields in contract.model
  - updates contract.model.config to reference v7
  - writes back; preserves all other contract fields (incl. schema_version,
    study_id, source, workload, result_ids, images, derivation, statistical_plan,
    tolerance_policy, etc.)
  - prints before/after diff
  - re-runs readiness to confirm model_contract_binding now PASS

Run from acm/ root with the venv python.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
CONTRACT = ROOT / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-20260925.json"
V7 = ROOT / "configs/models/litellm_local_nothink_v7.json"


def main() -> int:
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    v7 = json.loads(V7.read_text(encoding="utf-8"))

    contract_model = contract.setdefault("model", {})
    print("[before] contract.model keys:", sorted(contract_model.keys()))
    print("[before] max_output_tokens:", contract_model.get("max_output_tokens"))
    print("[before] prediction_max_attempts:", contract_model.get("prediction_max_attempts"))
    print("[before] billing_scope:", contract_model.get("billing_scope"))
    print("[before] billing_user_id:", contract_model.get("billing_user_id"))
    print("[before] model.config:", contract_model.get("config"))

    fields = sorted(set(contract_model.keys()) & set(v7.keys()))
    print("\n[overlap keys]", fields)

    changes: list[tuple[str, object, object]] = []
    for k in fields:
        if contract_model[k] != v7[k]:
            changes.append((k, contract_model[k], v7[k]))
            contract_model[k] = v7[k]

    contract_model["config"] = "configs/models/litellm_local_nothink_v7.json"

    # Drop non-v7-only fields if any are in contract but not v7 (we keep them
    # because they are explicit in contract; we do not delete contract-only
    # fields here). Print them so the operator can audit.
    only_in_contract = sorted(set(contract_model.keys()) - set(v7.keys()))
    if only_in_contract:
        print("[contract-only fields preserved]:", only_in_contract)

    print("\n[changes]")
    for k, old, new in changes:
        print(f"  {k}: {old!r} -> {new!r}")
    print(f"  config -> configs/models/litellm_local_nothink_v7.json")

    # Also keep contract's metadata in sync to record the rebind
    meta = contract.setdefault("_metadata", {})
    notes = meta.get("rebinding_notes", [])
    if not isinstance(notes, list):
        notes = []
    notes.append({
        "timestamp": "2026-09-27T02:30:00Z",
        "agent": "CACTUS Agent (P-06 path, owner choice update-contract-v7)",
        "reason": (
            "Reconcile contract.model to litellm_local_nothink_v7.json "
            "for C1 readiness; v7 raises max_output_tokens 16384->32768 and "
            "forces direct JSON emission; v6 produced 100% CoT (R4 v8 verdict)."
        ),
        "session_authorization_remains": "approved (2026-09-25T03:25:13Z); SHA record intentionally left stale per owner choice use-existing-approval",
    })
    meta["rebinding_notes"] = notes
    meta["last_rebinding_at"] = "2026-09-27T02:30:00Z"

    # Write back. Sort keys for stable diff but preserve original indentation
    # by re-using json.dumps with indent=2. We also add a trailing newline to
    # match git-friendly convention used elsewhere in the repo.
    new_content = json.dumps(contract, indent=2, ensure_ascii=False) + "\n"
    CONTRACT.write_text(new_content, encoding="utf-8")

    new_sha = hashlib.sha256(new_content.encode()).hexdigest()
    print("\n[written] path:", CONTRACT)
    print("[written] size_bytes:", len(new_content.encode()))
    print("[written] sha256:", new_sha)
    print("[written] schema_version:", contract.get("schema_version"))
    print("[written] experiment_id:", contract.get("experiment_id"))

    # Update sidecar SHA-256 file
    sha_path = CONTRACT.with_suffix(".sha256")
    sha_path.write_text(new_sha + "  " + str(CONTRACT.relative_to(ROOT)) + "\n", encoding="utf-8")
    print("[sidecar] written:", sha_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
