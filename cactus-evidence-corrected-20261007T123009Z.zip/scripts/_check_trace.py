"""Check trace for context selection."""
import json
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
out = sorted(ROOT.glob("experiments/runs/r4_verify_13033_*"), key=lambda d: d.stat().st_mtime, reverse=True)
if not out:
    print("No output dir")
    exit(1)

latest = out[0]
trace = latest / "trace.jsonl"
print(f"Trace: {trace}")
print(f"Size: {trace.stat().st_size} bytes")

events = []
with open(trace) as f:
    for line in f:
        if line.strip() and not line.startswith("#"):
            try:
                events.append(json.loads(line))
            except Exception:
                pass

print(f"Total events: {len(events)}")
print()

# Find context selection events
for e in events:
    name = e.get("event", e.get("type", ""))
    if any(k in name.lower() for k in ["anchor", "context", "module", "propagat", "selected", "selection"]):
        print(f"[{name}]")
        for key in sorted(e.keys()):
            if key == "event":
                continue
            val = e[key]
            if isinstance(val, list):
                print(f"  {key}: {val[:5]}...")
            elif isinstance(val, str) and len(val) > 100:
                print(f"  {key}: {val[:100]}...")
            else:
                print(f"  {key}: {val}")
        print()

# Check the last few events for overall context
print("=== Last 5 events ===")
for e in events[-5:]:
    name = e.get("event", e.get("type", ""))
    print(f"[{name}]")
    for key in sorted(e.keys()):
        if key == "event":
            continue
        val = e[key]
        if isinstance(val, list):
            print(f"  {key}: {val[:3]}...")
        elif isinstance(val, str) and len(val) > 80:
            print(f"  {key}: {val[:80]}...")
        else:
            print(f"  {key}: {val}")
    print()
