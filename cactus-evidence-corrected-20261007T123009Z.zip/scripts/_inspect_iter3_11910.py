"""查 11910 ITER3 的 site kinds 与 selected sites 详情"""

import json

p = 'experiments/runs/ITER3-11910-20261004T065000Z/django__django-11910/events.jsonl'
with open(p, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]

print('Event types:')
from collections import Counter
c = Counter(e.get('type', '?') for e in events)
for k, v in c.most_common():
    print(f'  {v:3d} {k}')

print()
print('repair_sites:')
for e in events:
    if e.get('type') == 'repair_sites':
        p2 = e.get('payload', {})
        print(f'  site_count={p2.get("site_count")} kinds={p2.get("site_kinds")}')

print()
print('Site selections (attempts with rejected or successful):')
for e in events:
    t = e.get('type', '')
    if t in ('prediction_sites_rejected', 'prediction_rejected'):
        p2 = e.get('payload', {})
        seq = e.get('seq', '?')
        sites = p2.get('site_ids', [])
        reason = p2.get('reason', '')[:100]
        print(f'  seq={seq} {t} sites={sites}')
        print(f'    reason: {reason}')

print()
print('Sequence of dual_insurance / plan / diagnose results:')
for e in events:
    t = e.get('type', '')
    if t in ('v3_dual_insurance_result',):
        p2 = e.get('payload', {})
        seq = e.get('seq', '?')
        print(f'  seq={seq} {t} attempt={p2.get("attempt")} success={p2.get("success")} corrections={p2.get("correction_rounds")}')