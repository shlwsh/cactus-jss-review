"""Warmup task repositories and persistent index cache to accelerate execution."""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit
from cactus.repository.index import build_index

TASKS = [
    "django__django-11039",
    "django__django-11049",
    "django__django-12708",
    "astropy__astropy-14365",
    "django__django-12453",
    "django__django-11620",
    "django__django-11815",
    "astropy__astropy-6938",
]


def warmup_task(task_id: str, manifest_tasks: dict) -> None:
    task = manifest_tasks.get(task_id)
    if not task:
        print(f"[WARMUP-SKIP] {task_id} not in manifest", flush=True)
        return

    commit = task.base_commit
    cache_dir = Path("E:/cactus-data/lite50/index_cache")
    cache_dir.mkdir(parents=True, exist_ok=True)
    commit_cache_path = cache_dir / f"{commit}.pkl"

    if commit_cache_path.exists():
        print(f"[WARMUP-HIT] {task_id} commit {commit[:8]} index already cached ({commit_cache_path.stat().st_size} bytes)", flush=True)
        return

    repo_cache = PROJECT_ROOT / "experiments/repo_cache"
    warmup_dir = Path("E:/cactus-data/lite50/scratch/warmup") / task_id
    warmup_dir.mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    print(f"[WARMUP] Checking out {task_id} ({commit[:8]})...", flush=True)
    repo_root = checkout_base_commit(task, cache_root=repo_cache, workspace_root=warmup_dir, allow_network_fetch=False)

    print(f"[WARMUP] Building index and warming cache for {task_id}...", flush=True)
    idx = build_index(repo_root)
    elapsed = time.time() - t0
    print(f"[WARMUP-DONE] {task_id} index cached ({len(idx.units)} units) in {elapsed:.1f}s", flush=True)


def main() -> None:
    manifest_path = PROJECT_ROOT / "data/manifests/swebench_lite50_b0dde109_test_inference_safe.jsonl"
    manifest_tasks = {t.task_id: t for t in load_manifest(manifest_path)}

    target_tasks = sys.argv[1:] if len(sys.argv) > 1 else TASKS
    for tid in target_tasks:
        try:
            warmup_task(tid, manifest_tasks)
        except Exception as e:
            print(f"[WARMUP-ERR] {tid}: {e}", flush=True)


if __name__ == "__main__":
    main()
