"""CLI for a formal CACTUS campaign using the public SWE-bench evaluator."""

from __future__ import annotations

import argparse
from pathlib import Path

from cactus.runner.swebench_campaign import run_campaign
from _dataset_resolver import export_data_roots
from _env_wrapper import verify_session_env


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--approval", type=Path, required=True)
    parser.add_argument("--model-config", type=Path, required=True)
    parser.add_argument("--tasks", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--repo-cache", type=Path)
    parser.add_argument("--scratch-root", type=Path, help="Task checkout scratch directory; use the configured E: data disk for experiments")
    parser.add_argument("--evaluator-dataset", required=True)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--task-id", action="append", dest="task_ids")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--batch-index", type=int, help="Zero-based deterministic task batch index")
    parser.add_argument("--batch-count", type=int, help="Number of deterministic task batches")
    parser.add_argument("--variant", default="cactus_full", choices=("maximal_context", "lexical_bm25", "cactus_full", "cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density", "cactus_test_aware", "cactus_no_test_aware", "cactus_no_semantic", "cactus_no_iteration"))
    parser.add_argument("--campaign-id", help="Frozen campaign identity recorded in every RUN manifest")
    parser.add_argument("--warmup-lookahead", type=int, choices=(0, 1, 2), default=0)
    parser.add_argument("--pair-plan", type=Path, help="Execute a frozen cactus_full:maximal_context matched-pair plan")
    parser.add_argument("--feedback-manifest", type=Path, help="Run E7 retries from a frozen task/parent-run/evaluator-feedback JSONL")
    args = parser.parse_args()
    verify_session_env()
    # The F: archive is user-managed backup storage and may be exFAT, which
    # has no ACL-based read-only mode.  Its immutable identity is instead
    # enforced per task by archive SHA-256, content-addressed image ID, and
    # the frozen evaluator digest.  Repository and benchmark roots remain
    # fail-closed OS-read-only inputs.
    roots = export_data_roots(
        require_all=True,
        writable_keys=frozenset({"CACTUS_DOCKER_CACHE_ROOT"}),
    )
    repo_cache = args.repo_cache or Path(roots["CACTUS_REPO_CACHE_ROOT"])
    result = run_campaign(contract_path=args.contract, approval_path=args.approval, model_config_path=args.model_config, task_manifest=args.tasks, output_root=args.output_root, project_root=args.project_root, evaluator_dataset=args.evaluator_dataset, repo_cache=repo_cache, scratch_root=args.scratch_root, task_ids=set(args.task_ids) if args.task_ids else None, limit=args.limit, batch_index=args.batch_index, batch_count=args.batch_count, variant=args.variant, campaign_id=args.campaign_id, warmup_lookahead=args.warmup_lookahead, pair_plan_path=args.pair_plan, feedback_manifest_path=args.feedback_manifest)
    print(f"campaign={result.campaign_id} tasks={result.task_count} completed={result.completed} failed={result.failed}")
    print("run_ids=" + ",".join(result.run_ids))
    return 0 if not result.failed else 2


if __name__ == "__main__":
    raise SystemExit(main())
