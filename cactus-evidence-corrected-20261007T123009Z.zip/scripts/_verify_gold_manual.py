"""Manually apply gold patch and test 13033."""
from pathlib import Path
import tempfile
import subprocess
import sys

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "src"))

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest = list(load_manifest(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"))
task = next(t for t in manifest if t.task_id == "astropy__astropy-13033")
ws = Path(tempfile.mkdtemp(prefix="cactus-gold-manual-"))
repo = checkout_base_commit(task, cache_root=Path(r"E:\cactus-data\repo-cache"), workspace_root=ws, allow_network_fetch=True)

# Apply gold patch manually using string replace
core_path = repo / "astropy" / "timeseries" / "core.py"
core_text = core_path.read_text(encoding="utf-8")

# 1. Add as_scalar_or_list_str helper after `def _check_required_columns(self):`
old_def = "    def _check_required_columns(self):\n\n        if not self._required_columns_enabled:"
new_def = (
    "    def _check_required_columns(self):\n"
    "        def as_scalar_or_list_str(obj):\n"
    "            if not hasattr(obj, \"__len__\"):\n"
    "                return f\"'{obj}'\"\n"
    "            elif len(obj) == 1:\n"
    "                return f\"'{obj[0]}'\"\n"
    "            else:\n"
    "                return str(obj)\n"
    "\n"
    "        if not self._required_columns_enabled:"
)
assert old_def in core_text, "old_def not found"
core_text = core_text.replace(old_def, new_def, 1)

# 2. Change the error message format
old_raise = (
    "                raise ValueError(\"{}\" \"\"\n"
    "                                 \"as the first column{} but found '{}'\"\n"
)
# The actual format string has braces. Let me search differently.
old_pattern = 'as the first column{} but found'
print(f"Found old pattern in core_text: {old_pattern in core_text}")

# Find the line and replace
old_lines = [
    '                raise ValueError("{} object is invalid - expected \'{}\' "',
    "                                 \"as the first column{} but found '{}'\"",
    "                                 .format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))",
]
new_lines = [
    '                raise ValueError("{} object is invalid - expected {} "',
    "                                 \"as the first column{} but found {}\"",
    "                                 .format(self.__class__.__name__, as_scalar_or_list_str(required_columns),",
    "                                            plural, as_scalar_or_list_str(self.colnames[:len(required_columns)])))",
]

# Read current text
text_lines = core_text.splitlines(keepends=True)
# Find the raise line
raise_idx = None
for i, line in enumerate(text_lines):
    if "as the first column{} but found '{}'" in line:
        raise_idx = i - 1  # the line before is `raise ValueError(...)`
        break
print(f"raise_idx: {raise_idx}")

# Replace 3 lines
if raise_idx is not None:
    new_text_lines = (
        text_lines[:raise_idx]
        + ['                raise ValueError("{} object is invalid - expected {} "\n',
           '                                 "as the first column{} but found {}"\n',
           '                                 .format(self.__class__.__name__, as_scalar_or_list_str(required_columns),\n',
           '                                            plural, as_scalar_or_list_str(self.colnames[:len(required_columns)])))\n']
        + text_lines[raise_idx + 3:]
    )
    core_text = "".join(new_text_lines)

core_path.write_text(core_text, encoding="utf-8")

# Apply test patch (manually insert before @pytest.mark.parametrize)
test_path = repo / "astropy" / "timeseries" / "tests" / "test_sampled.py"
test_text = test_path.read_text(encoding="utf-8")

# Find the position
target = '@pytest.mark.parametrize(\'cls\', [BoxLeastSquares, LombScargle])\ndef test_periodogram(cls):'
insertion = (
    '    # https://github.com/astropy/astropy/issues/13009\n'
    '    ts_2cols_required = ts.copy()\n'
    "    ts_2cols_required._required_columns = ['time', 'a']\n"
    '    with pytest.raises(ValueError) as exc:\n'
    "        ts_2cols_required.remove_column('a')\n"
    '    assert exc.value.args[0] == ("TimeSeries object is invalid - expected "\n'
    "                                 \"['time', 'a'] as the first columns but found ['time', 'b']\")\n"
    '\n'
    '\n'
)
assert target in test_text
test_text = test_text.replace(target, insertion + target, 1)
test_path.write_text(test_text, encoding="utf-8")

# Show patched core.py
print("\n=== Patched core.py lines 58-92 ===")
patched_lines = core_path.read_text(encoding="utf-8").splitlines()
for i, line in enumerate(patched_lines[57:92], 58):
    print(f"  {i:3d}: {line}")

print("\n=== Patched test_sampled.py lines 392-410 ===")
test_lines = test_path.read_text(encoding="utf-8").splitlines()
for i, line in enumerate(test_lines[391:410], 392):
    print(f"  {i:3d}: {line}")

# Install setuptools_scm if needed
import os
print("\n=== Trying to install setuptools_scm ===")
result = subprocess.run(
    [r"C:\Python313\python.exe", "-m", "pip", "install", "--quiet", "setuptools_scm"],
    capture_output=True, text=True, timeout=60,
)
print(f"pip install: rc={result.returncode}")

# Run pytest
print("\n=== Running pytest test_required_columns ===")
result = subprocess.run(
    [r"C:\Python313\python.exe", "-m", "pytest",
     "astropy/timeseries/tests/test_sampled.py::test_required_columns",
     "-xvs", "--tb=short", "--no-header"],
    cwd=str(repo),
    capture_output=True, text=True,
    timeout=180,
    env={**os.environ, "PYTHONPATH": "."},
)
print("--- stdout ---")
print(result.stdout[:5000])
print("--- stderr ---")
print(result.stderr[:1500])