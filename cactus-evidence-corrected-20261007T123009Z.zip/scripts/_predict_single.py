"""Run single R4 task prediction directly (bypassing campaign orchestration).

This script:
1. Creates a git worktree for the task's base_commit
2. Runs cactus_swebench_predict.py directly
3. Reports the result

Usage:
    & .\.venv\Scripts\python.exe scripts\_predict_single.py --task-id astropy__astropy-13033
"""
from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("E:/work/p5-acm/acm")
VENV_PY = ROOT / ".venv" / "Scripts" / "python.exe"
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
MODEL_CONFIG = ROOT / "configs" / "models" / "litellm_local_nothink_v7.json"
REPO_CACHE = ROOT / "experiments" / "repo_cache"
OUTPUT_DIR = ROOT / "experiments" / "runs"


def load_tasks():
    tasks = {}
    with open(TASK_MANIFEST) as f:
        for line in f:
            t = json.loads(line)
            tasks[t["task_id"]] = t
    return tasks


def load_eval_tasks():
    dataset = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
    tasks = {}
    if dataset.exists():
        with open(dataset) as f:
            for line in f:
                t = json.loads(line)
                tasks[t["instance_id"]] = t
    return tasks


def get_repo_worktree(task_id: str) -> Path | None:
    """Get or create a git worktree for the task's base_commit."""
    eval_tasks = load_eval_tasks()
    task = eval_tasks.get(task_id)
    if not task:
        print(f"  ERROR: {task_id} not in eval dataset")
        return None

    repo_id = task.get("repo", "")
    base_commit = task.get("base_commit", "")
    if not repo_id or not base_commit:
        return None

    mirror = REPO_CACHE / f"{repo_id.replace('/', '__')}.git"
    if not mirror.exists():
        print(f"  ERROR: mirror not found: {mirror}")
        return None

    # Check base commit exists
    r = subprocess.run(
        ["git", "-C", str(mirror), "cat-file", "-e", f"{base_commit}{{commit}}"],
        capture_output=True, timeout=30,
    )
    if r.returncode != 0:
        print(f"  ERROR: base commit {base_commit} not in mirror")
        return None

    # Create/find worktree
    wt_root = ROOT / "tmp" / "repos"
    wt_root.mkdir(parents=True, exist_ok=True)
    wt = wt_root / repo_id.replace("/", "_")

    if wt.exists():
        # Update worktree to the correct commit
        subprocess.run(["git", "-C", str(wt), "fetch", "origin", base_commit],
                      capture_output=True, timeout=60)
        subprocess.run(["git", "-C", str(wt), "checkout", "--detach", base_commit],
                      capture_output=True, timeout=30)
    else:
        r = subprocess.run(
            ["git", "clone", "--shared", str(mirror), str(wt)],
            capture_output=True, timeout=120,
        )
        if r.returncode != 0:
            print(f"  ERROR: clone failed: {r.stderr.decode()[:200]}")
            return None
        subprocess.run(["git", "-C", str(wt), "checkout", "--detach", base_commit],
                      capture_output=True, timeout=30)

    print(f"  Worktree: {wt}")
    return wt


def run_prediction(task_id: str, variant: str = "cactus_full", timeout_sec: int = 1200) -> dict:
    """Run prediction for a single task."""
    print(f"\n{'='*60}")
    print(f"  任务: {task_id} | variant: {variant}")
    print(f"{'='*60}")

    # Get repo worktree
    repo_root = get_repo_worktree(task_id)
    if not repo_root:
        return {"status": "error", "reason": "no_repo", "task_id": task_id}

    # Create output directory
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = OUTPUT_DIR / f"_r4_direct_{task_id.replace('__', '_')}_{ts}"
    out_dir.mkdir(parents=True, exist_ok=True)
    output_file = out_dir / "prediction.jsonl"
    trace_file = out_dir / "trace.jsonl"

    # Build command
    cmd = [
        str(VENV_PY),
        str(ROOT / "scripts" / "cactus_swebench_predict.py"),
        "--tasks", str(TASK_MANIFEST),
        "--task-id", task_id,
        "--repo-root", str(repo_root),
        "--model-config", str(MODEL_CONFIG),
        "--trace", str(trace_file),
        "--output", str(output_file),
        "--budget", "14000",
        "--request-timeout-sec", str(timeout_sec),
        "--variant", variant,
    ]

    print(f"\n  Command:")
    print(f"    python scripts/cactus_swebench_predict.py \\")
    print(f"      --task-id {task_id}")
    print(f"      --variant {variant}")
    print(f"      --repo-root {repo_root}")
    print(f"      --timeout {timeout_sec}s")
    print(f"\n  Output: {out_dir}")
    print(f"\n  开始预测... (预计 5-15 分钟)")

    # Build environment
    env = os.environ.copy()
    env["CACTUS_LITELLM_API_KEY"] = env.get("CACTUS_LITELLM_API_KEY", "sk-dgx-local-2026")
    env["CACTUS_LITELLM_BILLING_API_KEY"] = env.get("CACTUS_LITELLM_BILLING_API_KEY", "sk-fw8MS3ly9sLOd0nK75j-mA")
    env["CACTUS_LITELLM_LOG_KEY_ALIAS"] = env.get("CACTUS_LITELLM_LOG_KEY_ALIAS", "cactus-billing")
    env["CACTUS_LITELLM_BILLING_KEY_ALIAS"] = env.get("CACTUS_LITELLM_BILLING_KEY_ALIAS", "cactus-billing")
    env["CACTUS_LITELLM_BILLING_SSH_HOST"] = env.get("CACTUS_LITELLM_BILLING_SSH_HOST", "172.19.50.70")
    env["CACTUS_LITELLM_BILLING_SSH_USER"] = env.get("CACTUS_LITELLM_BILLING_SSH_USER", "winbot")
    env["CACTUS_LITELLM_BILLING_SSH_PASSWORD"] = env.get("CACTUS_LITELLM_BILLING_SSH_PASSWORD", "winbot")

    # Redirect output to files
    stdout_file = out_dir / "predict.stdout.log"
    stderr_file = out_dir / "predict.stderr.log"

    started = time.monotonic()
    try:
        with open(stdout_file, "w", encoding="utf-8") as sout, \
             open(stderr_file, "w", encoding="utf-8") as serr:
            result = subprocess.run(
                cmd,
                cwd=str(ROOT),
                env=env,
                stdout=sout,
                stderr=serr,
                timeout=timeout_sec + 60,
            )
        elapsed = time.monotonic() - started

    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - started
        return {
            "status": "timeout",
            "task_id": task_id,
            "variant": variant,
            "elapsed_sec": round(elapsed, 1),
            "reason": f"timeout after {timeout_sec}s",
        }

    elapsed = time.monotonic() - started

    # Analyze stderr
    stderr_text = stderr_file.read_text(encoding="utf-8", errors="replace") if stderr_file.exists() else ""
    stdout_text = stdout_file.read_text(encoding="utf-8", errors="replace") if stdout_file.exists() else ""

    # Check for specific errors
    if "symbol '_check_required_columns' not found" in stderr_text:
        status = "fail_context"  # Context selector still missing the symbol
        reason = "symbol not in context (fix not working)"
    elif "old_statement must exactly match" in stderr_text:
        status = "fail_context"
        reason = "old_statement mismatch (context issue)"
    elif "RuntimeError: prediction generation exhausted" in stderr_text:
        status = "fail_model"
        reason = "prediction exhausted"
    elif result.returncode == 0:
        status = "success"
        reason = "prediction generated successfully"
    else:
        status = "error"
        reason = stderr_text[-200:] if stderr_text else f"exit {result.returncode}"

    # Cleanup worktree
    try:
        shutil.rmtree(repo_root)
    except Exception:
        pass

    return {
        "status": status,
        "task_id": task_id,
        "variant": variant,
        "reason": reason,
        "elapsed_sec": round(elapsed, 1),
        "returncode": result.returncode,
        "output_dir": str(out_dir),
        "stdout_lines": len(stdout_text.split("\n")) if stdout_text else 0,
        "stderr_lines": len(stderr_text.split("\n")) if stderr_text else 0,
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Run single R4 task prediction")
    parser.add_argument("--task-id", default="astropy__astropy-13033")
    parser.add_argument("--variant", default="cactus_full")
    parser.add_argument("--timeout", type=int, default=1200)
    args = parser.parse_args()

    task_id = args.task_id
    variant = args.variant

    print(f"R4 直接预测验证")
    print(f"Time: {dt.datetime.now(dt.timezone.utc).isoformat()}")
    print(f"Task: {task_id}")
    print(f"Variant: {variant}")

    result = run_prediction(task_id, variant, args.timeout)

    print(f"\n{'='*60}")
    print(f"  结果")
    print(f"{'='*60}")
    emoji = {"success": "OK", "fail_context": "CTX", "fail_model": "MOD", "error": "ERR", "timeout": "TMO"}.get(result["status"], "?")
    print(f"  {emoji} {result['status']}")
    print(f"  原因: {result['reason']}")
    print(f"  耗时: {result.get('elapsed_sec', '?')}s")
    print(f"  输出: {result.get('output_dir', '?')}")

    return 0 if result["status"] == "success" else 1


if __name__ == "__main__":
    sys.exit(main())
