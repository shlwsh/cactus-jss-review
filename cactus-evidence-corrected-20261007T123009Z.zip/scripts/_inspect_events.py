import json
import sys

p = sys.argv[1]
with open(p, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]
for e in events:
    t = e.get('type', '')
    seq = e.get('seq','?')
    if t in ('prediction_rejected','prediction_sites_rejected','prediction_exhausted','v3_dual_insurance_result'):
        p2 = e.get('payload', {})
        print(f'seq={seq} [{t}] attempt={p2.get("attempt")}')
        if 'site_ids' in p2:
            print(f'    sites: {p2.get("site_ids")}')
        if 'reason' in p2:
            print(f'    reason: {p2.get("reason")[:250]}')
        if 'success' in p2:
            print(f'    success: {p2.get("success")} corrections={p2.get("correction_rounds")}')
        if 'final_rejection' in p2:
            print(f'    final: {p2.get("final_rejection")[:200]}')
        print()