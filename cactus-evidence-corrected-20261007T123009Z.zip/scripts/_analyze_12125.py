"""Analyze 12125 events."""
import json
fpath = 'experiments/runs/ITER3-12125-20261004T065000Z/django__django-12125/events.jsonl'
with open(fpath, encoding='utf-8') as f:
    for line in f:
        e = json.loads(line); t = e.get('type','')
        p = e.get('payload',{})
        if t in ('prediction_site_accepted','prediction_patch_context','responsibility_chain','repair_sites','prediction_sites_rejected','v3_dual_insurance_result'):
            print(f'seq={e.get("seq")} t={t}')
            print(json.dumps(p, indent=2)[:1500])
            print('---')
            if t == 'v3_dual_insurance_result':
                break
