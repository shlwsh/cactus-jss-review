"""launch_r4_think.py — R4 think-mode smoke test launcher.

Strategy:
  - thinking=true (cluster DEEPSEEK_THINKING=true is active per verify_thinking_active.py)
  - max_output_tokens=16384 (leave room for reasoning + final answer)
  - Run 1 task as smoke test, monitor in real-time
  - If pass → run full R4 (3 tasks × 2 variants = 6 RUNs)
  - If pass → propose 500-task C1 expansion

This addresses the root cause identified in the v3-v7 (no-think) failures:
all 8 previous RUNs hit empty_response / length_limit / placeholder_replacement /
symbol_hallucination because thinking was disabled in local config while the
cluster container has DEEPSEEK_THINKING=true.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
sys.path.insert(0, str(ROOT / "scripts"))

from inject_session_keys import REQUIRED_KEYS, load_resolved  # noqa: E402

CONTRACT = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
APPROVAL = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.session_authorization.json"
PLAN = ROOT / "experiments" / "plans" / "C1_primary_pairs_20260925_R4.json"
MODEL_CONFIG = ROOT / "configs" / "models" / "litellm_local_think.json"
TASK_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
OUTPUT_ROOT = ROOT / "experiments" / "runs"
REPO_CACHE = ROOT / "experiments" / "repo_cache"
DATASET = Path(r"E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
CAMPAIGN_ID = "phase-c1-engineering-validation-r4-think-20260925"

RUNNER = ROOT / "scripts" / "run_swebench_campaign.py"
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"


def main() -> int:
    env_path, resolved = load_resolved()
    env = {**os.environ, **{k: resolved[k]["value"] for k in REQUIRED_KEYS}}
    for required in (CONTRACT, APPROVAL, PLAN, MODEL_CONFIG, TASK_MANIFEST, RUNNER, DATASET):
        if not required.exists():
            print(f"ERROR: required path missing: {required}", file=sys.stderr)
            return 2

    log_path = OUTPUT_ROOT / f"_r4_think_launch_{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.log"
    cmd = [
        str(PYTHON),
        "-m", "scripts.run_swebench_campaign",
        "--contract", str(CONTRACT),
        "--approval", str(APPROVAL),
        "--model-config", str(MODEL_CONFIG),
        "--tasks", str(TASK_MANIFEST),
        "--output-root", str(OUTPUT_ROOT),
        "--repo-cache", str(REPO_CACHE),
        "--evaluator-dataset", str(DATASET),
        "--project-root", str(ROOT),
        "--pair-plan", str(PLAN),
        "--campaign-id", CAMPAIGN_ID,
        "--task-id", "astropy__astropy-12907",
        "--limit", "1",
    ]

    print("=" * 70)
    print("R4 THINK-MODE SINGLE-TASK SMOKE TEST")
    print("=" * 70)
    cfg = json.loads(MODEL_CONFIG.read_text(encoding="utf-8"))
    print(f"contract    : {CONTRACT.name}")
    print(f"plan        : {PLAN.name}")
    print(f"model_cfg   : {MODEL_CONFIG.name}")
    print(f"  thinking          = {cfg.get('thinking')}                ← KEY FIX (was False)")
    print(f"  max_output_tokens = {cfg.get('max_output_tokens')}                ← was 8192")
    print(f"  reasoning_effort  = {cfg.get('reasoning_effort')}")
    print(f"  temperature       = {cfg.get('temperature')}")
    print(f"  repetition_penalty = {cfg.get('repetition_penalty')}")
    print(f"campaign    : {CAMPAIGN_ID}")
    print(f"log         : {log_path}")
    print()
    print("$ " + " ".join(cmd))
    print("=" * 70)

    with log_path.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"# R4 think-mode single-task smoke test\n# started: {dt.datetime.now(dt.timezone.utc).isoformat()}\n")
        fh.write("# cmd: " + " ".join(cmd) + "\n")
        fh.write("# model_config: " + str(MODEL_CONFIG) + "\n")
        fh.write(f"# thinking = {cfg.get('thinking')}\n")
        fh.write(f"# max_output_tokens = {cfg.get('max_output_tokens')}\n")
        fh.write(f"# reasoning_effort = {cfg.get('reasoning_effort')}\n\n")
        fh.flush()
        proc = subprocess.Popen(
            cmd,
            cwd=str(ROOT.parent),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            fh.write(line)
            fh.flush()
        rc = proc.wait()
        fh.write(f"\n# finished: {dt.datetime.now(dt.timezone.utc).isoformat()}  exit={rc}\n")

    print()
    print("=" * 70)
    print(f"R4 think-mode smoke finished with exit code {rc}")
    print(f"log: {log_path}")
    print("=" * 70)
    return rc


if __name__ == "__main__":
    sys.exit(main())
