"""Create a new pending SWE-bench candidate from an existing observed candidate.

This rebind path preserves the parent's image-digest observation and immutable
task inputs while freezing a newer source commit and corrected primary pair.
It never edits the parent candidate or creates an approval record.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cactus.governance.contract import validate_contract

from cactus.governance.contract import validate_contract


_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_SHA1 = re.compile(r"^[0-9a-f]{40}$")
_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
_GOLD_FIELDS = frozenset({"patch", "test_patch"})


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def _verify_sidecar(path: Path) -> None:
    sidecar = path.with_suffix(path.suffix + ".sha256")
    expected = f"{_sha256(path)}  {path.name}\n"
    if not sidecar.is_file() or sidecar.read_text(encoding="utf-8") != expected:
        raise ValueError(f"source candidate SHA-256 sidecar is missing or invalid: {sidecar}")


def _manifest_task_ids(path: Path, *, expected_sha256: str, expected_count: int) -> set[str]:
    if not _SHA256.fullmatch(expected_sha256) or _sha256(path) != expected_sha256:
        raise ValueError(f"task manifest SHA-256 does not match the parent candidate: {path}")
    count = 0
    task_ids: set[str] = set()
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid task manifest JSON on line {line_number}") from exc
            if not isinstance(row, dict) or _GOLD_FIELDS.intersection(row):
                raise ValueError(f"task manifest contains an invalid row or gold patch field on line {line_number}")
            task_id = row.get("task_id") or row.get("instance_id")
            if not isinstance(task_id, str) or not task_id or task_id in task_ids:
                raise ValueError(f"task manifest has a missing or duplicate task id on line {line_number}")
            task_ids.add(task_id)
            count += 1
    if count != expected_count:
        raise ValueError(f"task manifest has {count} task(s), expected {expected_count}")
    return task_ids


def _repository_paths(project_root: Path, snapshot: Path, output: Path) -> list[str]:
    repo_root = project_root.parent.resolve()
    snapshot_resolved = snapshot.resolve()
    output_resolved = output.resolve()
    paths = [snapshot_resolved, snapshot_resolved.with_suffix(snapshot_resolved.suffix + ".sha256"), output_resolved.with_suffix(output_resolved.suffix + ".sha256")]
    normalized: list[str] = []
    for path in paths:
        try:
            relative = path.relative_to(repo_root)
        except ValueError as exc:
            raise ValueError(f"metadata path must stay inside the repository: {path}") from exc
        normalized.append(relative.as_posix())
    return sorted(set(normalized))


def rebind_candidate(
    *,
    source_candidate_path: Path,
    output_path: Path,
    project_root: Path,
    source_commit: str,
    experiment_id: str,
    primary_pair: list[str],
) -> dict[str, Any]:
    """Copy immutable evidence into a new candidate bound to the current source."""
    source_candidate_path = source_candidate_path.resolve()
    output_path = output_path.resolve()
    project_root = project_root.resolve()
    if source_candidate_path == output_path or output_path.exists() or output_path.with_suffix(output_path.suffix + ".sha256").exists():
        raise ValueError("output candidate or sidecar already exists")
    contract_dir = (project_root / "experiments" / "contracts").resolve()
    if not source_candidate_path.is_relative_to(contract_dir) or not output_path.is_relative_to(contract_dir):
        raise ValueError("source and output candidates must remain under experiments/contracts")
    if not _SHA1.fullmatch(source_commit):
        raise ValueError("source commit must be a 40-character lowercase SHA-1")
    actual_head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=project_root, check=True, capture_output=True, text=True,
    ).stdout.strip()
    if source_commit != actual_head:
        raise ValueError("source commit must equal the current HEAD")
    status = subprocess.run(
        ["git", "status", "--porcelain=v1"], cwd=project_root, check=True, capture_output=True, text=True,
    ).stdout
    if status.strip():
        raise ValueError("source tree must be clean before candidate rebinding")

    _verify_sidecar(source_candidate_path)
    parent = _read_json(source_candidate_path)
    metadata = parent.get("_metadata")
    if not isinstance(metadata, dict) or metadata.get("candidate_status") != "pending_owner_review":
        raise ValueError("source must be an unapproved pending candidate")
    if not re.fullmatch(r"EXP-[A-Z0-9][A-Z0-9_-]*", experiment_id):
        raise ValueError("experiment_id is invalid")
    if experiment_id == parent.get("experiment_id"):
        raise ValueError("new experiment_id must differ from the parent candidate")

    execution = parent.get("execution")
    workload = parent.get("workload")
    if not isinstance(execution, dict) or not isinstance(workload, dict):
        raise ValueError("source candidate is missing execution or workload data")
    matrix = workload.get("variant_matrix")
    if not isinstance(matrix, list) or not matrix or any(not isinstance(item, str) for item in matrix):
        raise ValueError("source candidate must contain a frozen workload.variant_matrix")
    if len(primary_pair) != 2 or primary_pair[0] == primary_pair[1] or any(item not in matrix for item in primary_pair):
        raise ValueError("primary pair must contain two distinct variants from the frozen matrix")
    if "maximal_context" not in primary_pair:
        raise ValueError("primary pair must retain maximal_context as the full-context comparator")

    task_count = execution.get("task_count")
    manifest = workload.get("task_manifest")
    if not isinstance(task_count, int) or task_count <= 0 or not isinstance(manifest, dict):
        raise ValueError("source candidate must bind a positive task count and task manifest")
    manifest_path = Path(str(manifest.get("path", "")))
    if not manifest_path.is_absolute():
        manifest_path = project_root / manifest_path
    task_ids = _manifest_task_ids(manifest_path, expected_sha256=str(manifest.get("sha256", "")), expected_count=task_count)

    images = parent.get("images")
    image_count = metadata.get("image_catalog_count")
    if not isinstance(images, dict) or len(images) != task_count or image_count != task_count:
        raise ValueError("source candidate image catalog is incomplete")
    for image_id, image in images.items():
        if not isinstance(image, dict) or not isinstance(image.get("repository"), str):
            raise ValueError(f"image digest observation is incomplete: {image_id}")
        if not isinstance(image.get("digest"), str) or not _IMAGE_DIGEST.fullmatch(image["digest"]):
            raise ValueError(f"image digest is invalid: {image_id}")
    observation_sha = metadata.get("candidate_digest_observation_sha256")
    observation_manifest_sha = metadata.get("candidate_digest_observation_manifest_sha256")
    if not isinstance(observation_sha, str) or not _SHA256.fullmatch(observation_sha):
        raise ValueError("parent candidate lacks an immutable image-observation hash")
    evaluator_value = execution.get("evaluator_dataset")
    if not isinstance(evaluator_value, str):
        raise ValueError("source candidate lacks an image-observation manifest binding")
    evaluator_path = Path(evaluator_value)
    if not evaluator_path.is_absolute():
        evaluator_path = project_root / evaluator_path
    evaluator_ids = _manifest_task_ids(evaluator_path, expected_sha256=str(observation_manifest_sha), expected_count=task_count)
    if task_ids != evaluator_ids:
        raise ValueError("inference-safe and image-observation manifests do not contain the same task IDs")

    snapshot_value = execution.get("environment_snapshot_path")
    snapshot_sha = execution.get("environment_snapshot_sha256")
    if not isinstance(snapshot_value, str) or not isinstance(snapshot_sha, str) or not _SHA256.fullmatch(snapshot_sha):
        raise ValueError("source candidate lacks a bound environment snapshot")
    snapshot_path = Path(snapshot_value)
    if not snapshot_path.is_absolute():
        snapshot_path = project_root / snapshot_path
    if not snapshot_path.is_file() or _sha256(snapshot_path) != snapshot_sha:
        raise ValueError("environment snapshot is missing or does not match the parent candidate")
    _verify_sidecar(snapshot_path)

    candidate = copy.deepcopy(parent)
    candidate["experiment_id"] = experiment_id
    candidate["source"]["git_commit"] = source_commit
    candidate["variants"] = list(primary_pair)
    candidate["statistical_plan"]["primary_pair"] = list(primary_pair)
    candidate_metadata = candidate["_metadata"]
    candidate_metadata["supersedes"] = parent.get("experiment_id")
    candidate_metadata["rebinding_parent_candidate_sha256"] = _sha256(source_candidate_path)
    candidate_metadata["candidate_status"] = "pending_owner_review"
    candidate_metadata["candidate_generated_at"] = _utc_now()
    candidate_metadata["candidate_source_commit"] = source_commit
    candidate_metadata["candidate_expected_run_count"] = task_count * len(matrix) * int(execution.get("repetitions", 1))
    candidate_metadata["candidate_note"] = (
        "Rebound pending candidate. Parent image digests, image-observation hash, environment snapshot, "
        "and inference-safe task manifest are preserved unchanged. The primary pair is aligned to the "
        "test-aware treatment and maximal-context comparator; explicit owner review and confirmation remain required."
    )
    candidate["source"]["require_clean_tree"] = True
    candidate["execution"]["metadata_paths"] = _repository_paths(project_root, snapshot_path, output_path)
    contract_errors = validate_contract(candidate)
    if contract_errors:
        raise ValueError("rebound candidate contract is invalid: " + "; ".join(contract_errors))
    contract_errors = validate_contract(candidate)
    if contract_errors:
        raise ValueError("rebound candidate contract is invalid: " + "; ".join(contract_errors))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(candidate, ensure_ascii=False, indent=2) + "\n"
    output_path.write_text(serialized, encoding="utf-8", newline="\n")
    digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
    sidecar = output_path.with_suffix(output_path.suffix + ".sha256")
    sidecar.write_text(f"{digest}  {output_path.name}\n", encoding="utf-8", newline="\n")
    return {
        "candidate_written": True,
        "candidate_path": output_path.as_posix(),
        "candidate_sha256": digest,
        "source_commit": source_commit,
        "parent_candidate_sha256": _sha256(source_candidate_path),
        "image_count": len(images),
        "task_count": task_count,
        "variants": matrix,
        "primary_pair": primary_pair,
        "planned_run_count": candidate_metadata["candidate_expected_run_count"],
        "status": candidate_metadata["candidate_status"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--experiment-id", required=True)
    parser.add_argument("--primary-pair", nargs=2, required=True)
    args = parser.parse_args()
    try:
        result = rebind_candidate(
            source_candidate_path=args.source_candidate,
            output_path=args.output,
            project_root=args.project_root,
            source_commit=args.source_commit,
            experiment_id=args.experiment_id,
            primary_pair=args.primary_pair,
        )
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.error(str(exc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
