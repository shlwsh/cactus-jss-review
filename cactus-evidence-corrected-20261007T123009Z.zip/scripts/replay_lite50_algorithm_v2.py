"""Read-only no-gold shadow replay for the ten frozen Lite-50 RUNs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from cactus.tools.lite50_shadow import replay_runs


FROZEN_RUN_IDS = (
    "RUN-20260928T074448Z-E760B470",
    "RUN-20260928T074533Z-CECFE8B9",
    "RUN-20260928T075706Z-19B36F1C",
    "RUN-20260928T080456Z-B06D6C37",
    "RUN-20260928T080822Z-7CC6A251",
    "RUN-20260928T081419Z-E484EA4D",
    "RUN-20260928T081556Z-435E238E",
    "RUN-20260928T081717Z-218CD33F",
    "RUN-20260928T081845Z-3545FC1C",
    "RUN-20260928T082048Z-60A6C37C",
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, default=Path("experiments/runs"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--per-task-hard-limit", type=int, default=12000)
    args = parser.parse_args()
    run_root = args.run_root.resolve()
    output = args.output.resolve()
    if any(output.is_relative_to((run_root / run_id).resolve()) for run_id in FROZEN_RUN_IDS):
        raise ValueError("shadow output must not be written inside a historical RUN")
    result = replay_runs(
        run_root,
        FROZEN_RUN_IDS,
        per_task_hard_limit=args.per_task_hard_limit,
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"output": output.as_posix(), "run_count": result["run_count"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
