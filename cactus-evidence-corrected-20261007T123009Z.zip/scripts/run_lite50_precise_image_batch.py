"""Sequentially build, align, archive, and clean Lite-50 evaluator images.

This driver is deliberately fail-closed: an image is never recorded as ready
until its task commit, clean tracked tree, archive hash, and loaded runtime ID
have all been verified.  Docker's large archive is first written to E: and
then copied as a stream to a fresh F: directory, avoiding the Docker Desktop
external-drive save path that previously returned device I/O errors.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from build_lite50_image_archive_manifest import _runtime_image_ids


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def run(command: list[str], *, env: dict[str, str], timeout: int = 3600) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, env=env, text=True, capture_output=True, timeout=timeout, check=False)


def docker_run(docker_bin: str, image: str, command: list[str], env: dict[str, str]) -> str:
    result = run([docker_bin, "run", "--rm", "--pull=never", image, *command], env=env, timeout=300)
    if result.returncode:
        raise RuntimeError(f"docker run failed: {result.stderr[-1000:]}")
    return result.stdout.strip()


def verify_image(docker_bin: str, image: str, base_commit: str, env: dict[str, str]) -> dict[str, str]:
    head = docker_run(docker_bin, image, ["git", "-C", "/testbed", "rev-parse", "HEAD"], env)
    status = docker_run(docker_bin, image, ["git", "-C", "/testbed", "status", "--porcelain", "--untracked-files=no"], env)
    tree = docker_run(docker_bin, image, ["git", "-C", "/testbed", "rev-parse", "HEAD^{tree}"], env)
    if head != base_commit or status:
        raise RuntimeError(f"source alignment failed: head={head!r}, status={status!r}")
    image_id = run([docker_bin, "image", "inspect", image, "--format={{.Id}}"], env=env, timeout=60)
    if image_id.returncode or not image_id.stdout.strip().startswith("sha256:"):
        raise RuntimeError("local Docker image ID is unavailable")
    return {"head": head, "tree": tree, "local_image_id": image_id.stdout.strip()}


def archive_one(*, source: Path, destination: Path, env: dict[str, str]) -> str:
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".partial")
    if partial.exists() or destination.exists():
        raise RuntimeError(f"immutable archive target exists: {destination}")
    try:
        with source.open("rb") as src, partial.open("wb") as dst:
            for chunk in iter(lambda: src.read(16 * 1024 * 1024), b""):
                dst.write(chunk)
            dst.flush()
            os.fsync(dst.fileno())
    except OSError as exc:
        partial.unlink(missing_ok=True)
        raise RuntimeError(f"F: archive copy failed: {exc}") from exc
    if not partial.exists() or partial.stat().st_size != source.stat().st_size:
        partial.unlink(missing_ok=True)
        raise RuntimeError("F: archive copy size mismatch")
    source_hash = sha256(source)
    target_hash = sha256(partial)
    if source_hash != target_hash:
        partial.unlink(missing_ok=True)
        raise RuntimeError(f"F: archive SHA-256 mismatch: {source_hash} != {target_hash}")
    partial.replace(destination)
    return target_hash


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-repo", type=Path, required=True)
    parser.add_argument("--task-manifest", type=Path, required=True)
    parser.add_argument("--archive-root", type=Path, required=True)
    parser.add_argument("--start-index", type=int, default=2)
    args = parser.parse_args()
    docker_bin = os.environ.get("CACTUS_DOCKER_BIN", r"D:\Docker\resources\bin\docker.exe")
    env = dict(os.environ)
    # Keep SWE-bench's subprocess-based buildx invocation bound to the same
    # explicitly selected Docker installation after a Desktop repair.
    env["PATH"] = str(Path(docker_bin).parent) + ";" + env.get("PATH", "")
    env["DOCKER_HOST"] = "npipe:////./pipe/docker_engine"
    tasks = [json.loads(line) for line in args.task_manifest.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(tasks) != 50:
        raise RuntimeError(f"expected 50 inference-safe tasks, found {len(tasks)}")
    if args.archive_root.exists():
        if not args.archive_root.is_dir():
            raise RuntimeError(f"archive root is not a directory: {args.archive_root}")
    else:
        args.archive_root.mkdir(parents=True, exist_ok=False)
    temp_root = Path(r"E:\cactus-data\lite50\temp\precise-archive-batch")
    temp_root.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, object]] = []
    for index, task in enumerate(tasks[args.start_index - 1 :], start=args.start_index):
        instance = task["task_id"]
        image = f"sweb.eval.x86_64.{instance}:latest"
        build = run([sys.executable, "scripts/build_lite50_precise_image.py", "--task-repo", str(args.task_repo), "--instance", instance], env=env, timeout=7200)
        if build.returncode:
            raise RuntimeError(f"image build failed for {instance}: {build.stderr[-2000:]}")
        verified = verify_image(docker_bin, image, task["base_commit"], env)
        stamp = utc_stamp()
        local_tar = temp_root / f"eval_{index:03d}-{stamp}.tar.partial"
        save = run([docker_bin, "save", "--output", str(local_tar), image], env=env, timeout=3600)
        if save.returncode or not local_tar.exists():
            raise RuntimeError(f"docker save failed for {instance}: {save.stderr[-1000:]}")
        archive = args.archive_root / f"batch-{index - 1:03d}-eval{index:03d}.tar"
        archive_hash = archive_one(source=local_tar, destination=archive, env=env)
        runtime_ids = _runtime_image_ids(archive)
        if len(runtime_ids) != 1 or runtime_ids[0] != verified["local_image_id"]:
            raise RuntimeError(f"runtime ID mismatch for {instance}: {runtime_ids} != {verified['local_image_id']}")
        record = {"eval_id": f"eval_{index:03d}", "task_id": instance, "base_commit": task["base_commit"], "archive_path": archive.as_posix(), "archive_sha256": archive_hash, "archive_size_bytes": archive.stat().st_size, "local_image_id": verified["local_image_id"], "runtime_id": runtime_ids[0], "source_tree": verified["tree"], "completed_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
        records.append(record)
        (args.archive_root / f"eval_{index:03d}.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        run([docker_bin, "image", "rm", image], env=env, timeout=300)
        local_tar.unlink(missing_ok=True)
        print(json.dumps(record, ensure_ascii=False), flush=True)
    (args.archive_root / "build_records.json").write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
