"""Test 13033 with gold patch via Docker eval.

Uses the known-gold-patch injection path of _run_r4_v3.py to verify gold patch resolves.
"""
from __future__ import annotations
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl")
ENV_FILE = ROOT / "docs" / "llm" / ".env"
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
TASKS_MANIFEST = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"

sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

# Gold patch (from _run_r4_v3.py)
GOLD_PATCH = (
    "diff --git a/astropy/timeseries/core.py b/astropy/timeseries/core.py\n"
    "--- a/astropy/timeseries/core.py\n"
    "+++ b/astropy/timeseries/core.py\n"
    "@@ -55,6 +55,13 @@ class BaseTimeSeries(QTable):\n"
    "     _required_columns_relax = False\n"
    " \n"
    "     def _check_required_columns(self):\n"
    "+        def as_scalar_or_list_str(obj):\n"
    "+            if not hasattr(obj, \"__len__\"):\n"
    "+                return f\"'{obj}'\"\n"
    "+            elif len(obj) == 1:\n"
    "+                return f\"'{obj[0]}'\"\n"
    "+            else:\n"
    "+                return str(obj)\n"
    " \n"
    "         if not self._required_columns_enabled:\n"
    "             return\n"
    "@@ -76,9 +83,10 @@ def _check_required_columns(self):\n"
    " \n"
    "             elif self.colnames[:len(required_columns)] != required_columns:\n"
    " \n"
    "-                raise ValueError(\"{} object is invalid - expected '{}' \"\n"
    "-                                 \"as the first column{} but found '{}'\"\n"
    "-                                 .format(self.__class__.__name__, required_columns[0], plural, self.colnames[0]))\n"
    "+                raise ValueError(\"{} object is invalid - expected {} \"\n"
    "+                                 \"as the first column{} but found {}\"\n"
    "+                                 .format(self.__class__.__name__, as_scalar_or_list_str(required_columns),\n"
    "+                                            plural, as_scalar_or_list_str(self.colnames[:len(required_columns)])))\n"
    " \n"
    "             if (self._required_columns_relax\n"
    "                     and self._required_columns == self.colnames[:len(self._required_columns)]):\n"
    "                 self._required_columns_relax = False\n"
)

# Step 1: verify gold patch applies cleanly via git apply --check
TASK_ID = "astropy__astropy-13033"
PINNED_IMAGE = "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de"

# Load task and setup workspace
task = next(t for t in load_manifest(TASKS_MANIFEST) if t.task_id == TASK_ID)
ws = Path(tempfile.mkdtemp(prefix="cactus-gold-docker-"))
print(f"workspace: {ws}")
repo = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)
print(f"repo: {repo}")
print(f"HEAD: {(repo / '.git' / 'HEAD').read_text().strip()}")

# Apply gold patch via git apply --check
print("\n=== git apply --check (gold patch) ===")
check = subprocess.run(
    ["git", "-C", str(repo), "apply", "--check", "--whitespace=nowarn"],
    input=GOLD_PATCH.encode("utf-8"),
    capture_output=True,
)
print(f"exit code: {check.returncode}")
if check.returncode != 0:
    print(f"stderr: {check.stderr.decode('utf-8')}")
    sys.exit(1)

# Apply for real
result = subprocess.run(
    ["git", "-C", str(repo), "apply", "--whitespace=nowarn"],
    input=GOLD_PATCH.encode("utf-8"),
    capture_output=True,
)
print(f"git apply: rc={result.returncode} stderr={result.stderr.decode('utf-8')[:300]}")

# Write prediction.jsonl
ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
run_id = f"RUN-{ts}-GOLD"

run_root = ROOT / "experiments" / "runs" / run_id
(run_root / "raw").mkdir(parents=True, exist_ok=True)
(run_root / "trace").mkdir(parents=True, exist_ok=True)
(run_root / "logs").mkdir(parents=True, exist_ok=True)
(run_root / "evaluation").mkdir(parents=True, exist_ok=True)

prediction = {
    "instance_id": TASK_ID,
    "model_name_or_path": "gold-patch-direct",
    "model_patch": GOLD_PATCH,
}
pred_path = run_root / "raw" / "prediction.jsonl"
pred_path.write_text(json.dumps(prediction, ensure_ascii=False) + "\n", encoding="utf-8")
print(f"prediction written: {pred_path}")

# Run eval
eval_log_stdout = run_root / "logs" / "evaluate.stdout.log"
eval_log_stderr = run_root / "logs" / "evaluate.stderr.log"

# Load env
env = os.environ.copy()
if ENV_FILE.exists():
    for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if "LITELLM" in k.upper() or "API_KEY" in k.upper():
            env[k] = v.strip()

cmd = [
    str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
    str(ROOT / "scripts" / "swebench_eval_lf.py"),
    str(DATASET),
    "--predictions", str(pred_path),
    "--instance", TASK_ID,
    "--pinned-image", PINNED_IMAGE,
    "--run-id", run_id,
    "--workers", "1",
    "--timeout", "900",
    "--report-dir", str(run_root / "evaluation"),
]

print("\n=== Running eval (gold patch) ===")
t0 = time.monotonic()
proc = subprocess.run(cmd, cwd=str(ROOT), env=env, capture_output=True, text=True, timeout=1800)
eval_log_stdout.write_text(proc.stdout, encoding="utf-8")
eval_log_stderr.write_text(proc.stderr, encoding="utf-8")
elapsed = time.monotonic() - t0
print(f"eval elapsed: {elapsed:.0f}s rc={proc.returncode}")
print("--- stdout (last 1500) ---")
print(proc.stdout[-1500:])

# Check report
report_files = list((run_root / "evaluation").glob(f"*.{run_id}.json"))
if report_files:
    rep = json.loads(report_files[0].read_text(encoding="utf-8"))
    print(f"\n=== Eval Report ===")
    print(f"  total: {rep.get('total_instances')}")
    print(f"  resolved: {rep.get('resolved_instances')}")
    print(f"  unresolved: {rep.get('unresolved_instances')}")
    print(f"  IDs: resolved={rep.get('resolved_ids')} unresolved={rep.get('unresolved_ids')}")