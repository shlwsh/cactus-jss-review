"""Check django-11019 progress."""
import json
from pathlib import Path
from collections import Counter

p = Path("experiments/runs/FACO-FULL-LITE50-POSTFIX-20261003T214359Z/django__django-11019/events.jsonl")
if p.exists():
    with p.open() as f:
        events = [json.loads(line) for line in f]
    print(f"django-11019 events: {len(events)}")
    print(f"  last: type={events[-1].get('type')} seq={events[-1].get('seq')} utc={events[-1].get('utc_ts')}")
    types = Counter(ev.get('type','?') for ev in events)
    print(f"  types: {dict(types)}")
    # show all model_call count + last reject
    n_model = sum(1 for ev in events if ev.get('type') == 'model_call')
    n_rej = sum(1 for ev in events if ev.get('type') in ('prediction_sites_rejected','prediction_rejected','prediction_exhausted'))
    print(f"  model_call={n_model} rejected={n_rej}")
else:
    print("no events.jsonl yet")
