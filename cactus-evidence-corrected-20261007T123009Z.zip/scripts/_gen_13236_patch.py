"""Generate correct patch for 13236 using difflib."""
import difflib

# Read actual file from Docker
import subprocess
result = subprocess.run([
    'docker', 'run', '--rm',
    'swebench/sweb.eval.x86_64.astropy_1776_astropy-13236:latest',
    'cat', '/testbed/astropy/table/table.py'
], capture_output=True, text=True, timeout=120)
original_text = result.stdout
print(f'Original file size: {len(original_text)} bytes')

# Find the structured ndarray block (lines 1242-1247)
lines = original_text.splitlines(keepends=True)
# We want to remove lines 1242-1247 (inclusive), keep the blank lines 1241 and 1248
# In 0-indexed: remove indices 1241-1246
start_idx = 1241  # 0-indexed start (line 1242)
end_idx = 1247    # 0-indexed end (exclusive, line 1248)

print(f'Structured ndarray block: lines {start_idx+1}-{end_idx} (0-indexed: {start_idx}-{end_idx-1})')
print('Content to remove:')
for i in range(start_idx, end_idx):
    print(f'  {i+1}: {lines[i].rstrip()}')

# Build modified content
new_lines = lines[:start_idx] + lines[end_idx:]

# Generate unified diff
diff = list(difflib.unified_diff(
    lines,
    new_lines,
    fromfile='a/astropy/table/table.py',
    tofile='b/astropy/table/table.py',
    lineterm='',
    n=3  # 3 lines context
))

patch_text = '\n'.join(diff) + '\n'
print('\n=== GENERATED PATCH ===')
print(patch_text)

# Save to a temp file
with open('E:/work/p5-acm/acm/experiments/runs/_13236_gold_patch.diff', 'w', encoding='utf-8') as f:
    f.write(patch_text)

print('\n=== PATCH STATS ===')
print(f'Patch length: {len(patch_text)} bytes')
