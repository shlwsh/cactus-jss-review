"""Decode a CACTUS trace events.jsonl with full text."""
import json
import sys
from pathlib import Path

trace = Path(sys.argv[1])
events = [json.loads(l) for l in trace.read_text(encoding="utf-8").splitlines() if l.strip()]

for i, e in enumerate(events):
    t = e.get("type", "?")
    p = e.get("payload", {})
    print(f"\n[{i}] {t}")
    if t == "model_call":
        rt = p.get("response_text", "")
        print(f"  prompt_chars={len(p.get('prompt_text',''))}")
        print(f"  prompt_head={p.get('prompt_text','')[:300]!r}")
        print(f"  resp_chars={len(rt)}")
        print(f"  resp={rt}")
    elif t == "prediction_rejected":
        reason = p.get("reason") if isinstance(p, dict) else None
        if reason is None:
            # Fall back to top-level
            for k, v in p.items():
                print(f"  payload[{k}]={str(v)[:600]}")
        else:
            print(f"  reason={reason[:1500]}")
    else:
        for k, v in p.items():
            print(f"  payload[{k}]={str(v)[:300]}")
