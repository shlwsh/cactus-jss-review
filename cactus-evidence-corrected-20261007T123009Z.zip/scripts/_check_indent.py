lines = open(r'E:\work\p5-acm\acm\scripts\cactus_swebench_predict.py').readlines()
for i in range(590, 612):
    l = lines[i]
    indent = len(l) - len(l.lstrip())
    print(f"{i+1:4d} {indent:2d}  {l[:70]!r}")
