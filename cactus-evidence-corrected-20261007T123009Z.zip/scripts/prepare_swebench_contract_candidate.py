"""Build an unapproved 500-task SWE-bench contract candidate.

The source contract remains immutable.  This utility combines the complete,
inference-safe image digest observation with the source contract and writes a
new candidate that must be reviewed and explicitly authorized before formal
execution.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_CAMPAIGN_VARIANTS = frozenset({
    "maximal_context", "lexical_bm25", "cactus_full", "cactus_no_symbol_graph",
    "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density",
    "cactus_test_aware", "cactus_no_test_aware", "cactus_no_semantic", "cactus_no_iteration",
})


def _read(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _ensure_sha256_sidecar(path: Path) -> Path:
    """Write a full SHA-256 sidecar, refusing to overwrite conflicting evidence."""
    digest = _sha256(path)
    sidecar = path.with_suffix(path.suffix + ".sha256")
    expected = f"{digest}  {path.name}\n"
    if sidecar.exists():
        if sidecar.read_text(encoding="utf-8") != expected:
            raise ValueError(f"existing SHA-256 sidecar does not match: {sidecar}")
    else:
        sidecar.write_text(expected, encoding="utf-8", newline="\n")
    return sidecar


def build_candidate(
    source_contract: dict[str, Any],
    observation: dict[str, Any],
    *,
    source_contract_sha256: str,
    observation_sha256: str,
    source_commit: str,
    experiment_id: str | None = None,
    task_manifest_path: str,
    task_manifest_sha256: str,
    cost_budget_usd: float,
    campaign_variants: list[str] | None = None,
    repetitions: int = 1,
    total_token_budget: int | None = None,
    environment_snapshot_path: str | None = None,
    environment_snapshot_sha256: str | None = None,
    pilot_id: str | None = None,
    pilot_task_ids: list[str] | None = None,
) -> dict[str, Any]:
    if observation.get("status") != "READY_FOR_CONTRACT_CANDIDATE":
        raise ValueError("digest observation is not ready for a contract candidate")
    records = observation.get("images")
    if not isinstance(records, list) or len(records) != observation.get("expected_image_count"):
        raise ValueError("digest observation does not contain the expected image count")
    if len(task_manifest_sha256) != 64 or any(char not in "0123456789abcdef" for char in task_manifest_sha256):
        raise ValueError("task manifest SHA-256 must be 64 lowercase hexadecimal characters")
    if not math.isfinite(cost_budget_usd) or cost_budget_usd <= 0:
        raise ValueError("cost budget must be a finite positive USD amount")
    if not isinstance(repetitions, int) or repetitions < 1:
        raise ValueError("repetitions must be a positive integer")
    if total_token_budget is not None and (not isinstance(total_token_budget, int) or total_token_budget < 1):
        raise ValueError("total token budget must be a positive integer")
    if (environment_snapshot_path is None) != (environment_snapshot_sha256 is None):
        raise ValueError("environment snapshot path and SHA-256 must be supplied together")
    if environment_snapshot_sha256 is not None and (
        len(environment_snapshot_sha256) != 64
        or any(char not in "0123456789abcdef" for char in environment_snapshot_sha256)
    ):
        raise ValueError("environment snapshot SHA-256 must be 64 lowercase hexadecimal characters")

    images: dict[str, dict[str, str]] = {}
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("invalid image observation record")
        repository = record.get("repository")
        digest = record.get("digest")
        image_ref = record.get("image_ref")
        if not isinstance(repository, str) or not isinstance(image_ref, str):
            raise ValueError("image observation is missing repository or image_ref")
        if not isinstance(digest, str) or len(digest) != 71 or not digest.startswith("sha256:"):
            raise ValueError(f"incomplete image digest for {repository}")
        key = str(record.get("id") or repository.rsplit("/", 1)[-1])
        if key in images:
            raise ValueError(f"duplicate image catalog key: {key}")
        images[key] = {
            "repository": repository,
            "tag": "sha256-" + digest.removeprefix("sha256:")[:12],
            "digest": digest,
            "status": "OBSERVED_PENDING_OWNER_REVIEW",
        }

    candidate = copy.deepcopy(source_contract)
    if pilot_id is not None:
        if not re.fullmatch(r"[A-Z0-9][A-Z0-9_-]{0,31}", pilot_id):
            raise ValueError("pilot_id must contain 1-32 uppercase letters, digits, '_' or '-' and start alphanumeric")
        candidate["experiment_id"] = f"EXP-CACTUS-SWEBENCH-PILOT-{pilot_id}"
        candidate["study_id"] = f"MSCC-PILOT-{pilot_id}"
        candidate["purpose"] = "exploratory"
    elif campaign_variants is not None:
        if not isinstance(experiment_id, str) or not re.fullmatch(r"EXP-[A-Z0-9][A-Z0-9_-]*", experiment_id):
            raise ValueError("a new EXP-prefixed experiment_id is required for a multi-variant candidate")
        candidate["experiment_id"] = experiment_id
    candidate["images"] = dict(sorted(images.items()))
    candidate.setdefault("source", {})["git_commit"] = source_commit
    if campaign_variants is not None:
        if not campaign_variants or not all(isinstance(item, str) and item for item in campaign_variants):
            raise ValueError("campaign variants must be a non-empty list of variant IDs")
        if len(set(campaign_variants)) != len(campaign_variants):
            raise ValueError("campaign variants must be a non-empty unique list")
        unknown = sorted(set(campaign_variants) - _CAMPAIGN_VARIANTS)
        if unknown:
            raise ValueError("unsupported campaign variants: " + ", ".join(unknown))
    cost_budget = candidate.setdefault("execution", {}).setdefault("cost_budget", {})
    cost_budget["amount"] = cost_budget_usd
    cost_budget["status"] = "PENDING_OWNER_REVIEW"
    workload = candidate.setdefault("workload", {})
    workload["task_manifest"] = {
        "path": task_manifest_path,
        "sha256": task_manifest_sha256,
        "source_attestation": "data/manifests/swebench_verified_78f471b_source.json",
        "inference_safe": True,
    }
    if campaign_variants is not None:
        workload["variant_matrix"] = list(campaign_variants)
    if pilot_task_ids is not None:
        if pilot_id is None or not pilot_task_ids or len(set(pilot_task_ids)) != len(pilot_task_ids):
            raise ValueError("pilot task IDs require a pilot contract and must be non-empty and unique")
        execution = candidate.setdefault("execution", {})
        execution["task_count"] = len(pilot_task_ids)
    if campaign_variants is not None:
        workload["repetitions"] = repetitions
        execution = candidate.setdefault("execution", {})
        # This is a set of independent campaigns, not the legacy paired C1
        # workload. Leaving pair_plan_path would silently force the old
        # cactus_full:maximal_context design and its stale execution state.
        execution.pop("pair_plan_path", None)
        if environment_snapshot_path is not None and environment_snapshot_sha256 is not None:
            execution["environment_snapshot_path"] = environment_snapshot_path
            execution["environment_snapshot_sha256"] = environment_snapshot_sha256
            execution["environment_snapshot_status"] = "OBSERVED_PENDING_OWNER_REVIEW"
        task_count = int(execution.get("task_count", 0))
        if task_count < 1:
            raise ValueError("source contract must define a positive execution.task_count")
        expected_run_count = task_count * len(campaign_variants) * repetitions
        per_run_tokens = int(execution.get("agent_turn_budget_tokens", 0))
        if per_run_tokens < 1:
            raise ValueError("source contract must define a positive execution.agent_turn_budget_tokens")
        execution["total_token_budget"] = total_token_budget or expected_run_count * per_run_tokens
        if execution["total_token_budget"] < 1:
            raise ValueError("campaign total token budget must be positive")
    elif total_token_budget is not None:
        candidate.setdefault("execution", {})["total_token_budget"] = total_token_budget
    metadata = candidate.setdefault("_metadata", {})
    metadata["candidate_status"] = "pending_owner_review"
    metadata["candidate_generated_at"] = _utc_now()
    metadata["candidate_source_contract_sha256"] = source_contract_sha256
    metadata["candidate_digest_observation_sha256"] = observation_sha256
    metadata["candidate_digest_observation_manifest_sha256"] = str(observation["source_manifest"].get("sha256", ""))
    metadata["candidate_task_manifest_sha256"] = task_manifest_sha256
    if pilot_id is not None:
        metadata["candidate_scope"] = "pilot"
        metadata["pilot_note"] = "Small-sample validation only; pilot outcomes are excluded from formal manuscript task outcomes."
        metadata["pilot_task_ids"] = list(pilot_task_ids or [])
        metadata["pilot_task_count"] = len(pilot_task_ids or [])
    task_count = len(pilot_task_ids) if pilot_task_ids is not None else int(candidate.get("execution", {}).get("task_count", 500))
    metadata["candidate_note"] = (
        f"Unapproved {task_count}-task {'exploratory pilot' if pilot_id is not None else 'contract'} candidate. Image digests were observed "
        "from local cache, local Docker metadata, or the registry. Review, "
        "source-commit freeze, budget confirmation, and fresh owner authorization "
        "are required before formal execution."
    )
    metadata["image_catalog_count"] = len(images)
    metadata["cost_budget_override_usd"] = cost_budget_usd
    if campaign_variants is not None:
        metadata["candidate_expected_run_count"] = int(candidate["execution"]["task_count"]) * len(campaign_variants) * repetitions
        if pilot_id is None:
            metadata["candidate_scope"] = "multi_variant_campaign"
    return candidate


def prepare(
    source_contract_path: Path,
    observation_path: Path,
    output_path: Path,
    *,
    source_commit: str,
    experiment_id: str | None = None,
    task_manifest_path: str,
    cost_budget_usd: float,
    campaign_variants: list[str] | None = None,
    repetitions: int = 1,
    total_token_budget: int | None = None,
    environment_snapshot_path: Path | None = None,
    pilot_id: str | None = None,
    pilot_task_ids: list[str] | None = None,
    pilot_manifest_output: Path | None = None,
) -> dict[str, Any]:
    if output_path.exists():
        raise FileExistsError(f"refusing to overwrite candidate: {output_path}")
    if output_path.with_suffix(output_path.suffix + ".sha256").exists():
        raise FileExistsError(f"refusing to overwrite candidate SHA-256 sidecar: {output_path}.sha256")
    project_root = source_contract_path.resolve().parents[2]
    if campaign_variants is not None and pilot_id is None and not output_path.resolve().is_relative_to(project_root):
        raise ValueError("multi-variant candidate output must be inside the project root")
    source_contract_sha256 = _sha256(source_contract_path)
    observation_sha256 = _sha256(observation_path)
    effective_task_manifest_path = Path(task_manifest_path).resolve()
    effective_task_manifest_value = task_manifest_path
    pilot_root = source_contract_path.resolve().parents[2]
    if pilot_task_ids is not None:
        if pilot_id is None or pilot_manifest_output is None:
            raise ValueError("pilot task IDs require --pilot-id and --pilot-manifest-output")
        if pilot_manifest_output.is_absolute():
            output_manifest = pilot_manifest_output.resolve()
            if not output_manifest.is_relative_to(pilot_root):
                raise ValueError("pilot manifest output must be inside the project root")
            effective_task_manifest_value = output_manifest.relative_to(pilot_root).as_posix()
        else:
            effective_task_manifest_value = pilot_manifest_output.as_posix()
            output_manifest = (pilot_root / pilot_manifest_output).resolve()
            if not output_manifest.is_relative_to(pilot_root):
                raise ValueError("pilot manifest output must be inside the project root")
        if output_manifest.exists():
            raise FileExistsError(f"refusing to overwrite pilot task manifest: {output_manifest}")
        source_rows: dict[str, dict[str, Any]] = {}
        for line_number, line in enumerate(effective_task_manifest_path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            row = json.loads(line)
            if not isinstance(row, dict) or not isinstance(row.get("task_id"), str):
                raise ValueError(f"invalid inference-safe task row at line {line_number}")
            task_id = row["task_id"]
            if task_id in source_rows:
                raise ValueError(f"duplicate task ID in source manifest: {task_id}")
            if "patch" in row or "test_patch" in row:
                raise ValueError(f"gold patch field detected in source manifest row {line_number}")
            source_rows[task_id] = row
        missing_ids = [task_id for task_id in pilot_task_ids if task_id not in source_rows]
        if missing_ids:
            raise ValueError("pilot task IDs missing from inference-safe manifest: " + ", ".join(missing_ids))
        output_manifest.parent.mkdir(parents=True, exist_ok=True)
        output_manifest.write_text(
            "".join(json.dumps(source_rows[task_id], ensure_ascii=False, sort_keys=True) + "\n" for task_id in pilot_task_ids),
            encoding="utf-8",
            newline="\n",
        )
        effective_task_manifest_path = output_manifest
    snapshot_relative_path: str | None = None
    snapshot_sha256: str | None = None
    if environment_snapshot_path is not None:
        resolved_snapshot = environment_snapshot_path.resolve()
        if not resolved_snapshot.is_relative_to(project_root) or not resolved_snapshot.is_file():
            raise ValueError("environment snapshot must be an existing file inside the project root")
        snapshot = _read(resolved_snapshot)
        if snapshot.get("capture_mode") not in {"observed", "reconstructed"} or not isinstance(snapshot.get("generated_at"), str):
            raise ValueError("environment snapshot is missing capture_mode or generated_at")
        snapshot_relative_path = resolved_snapshot.relative_to(project_root).as_posix()
        snapshot_sha256 = _sha256(resolved_snapshot)
        snapshot_sidecar = _ensure_sha256_sidecar(resolved_snapshot)
        snapshot_sidecar_relative_path = snapshot_sidecar.relative_to(project_root).as_posix()
    else:
        snapshot_sidecar_relative_path = None
    task_manifest_sha256 = _sha256(effective_task_manifest_path)
    observation = _read(observation_path)
    candidate = build_candidate(
        _read(source_contract_path),
        observation,
        source_contract_sha256=source_contract_sha256,
        observation_sha256=observation_sha256,
        source_commit=source_commit,
        experiment_id=experiment_id,
        task_manifest_path=effective_task_manifest_value,
        task_manifest_sha256=task_manifest_sha256,
        cost_budget_usd=cost_budget_usd,
        campaign_variants=campaign_variants,
        repetitions=repetitions,
        total_token_budget=total_token_budget,
        environment_snapshot_path=snapshot_relative_path,
        environment_snapshot_sha256=snapshot_sha256,
        pilot_id=pilot_id,
        pilot_task_ids=pilot_task_ids,
    )
    if pilot_task_ids is not None:
        image_by_task_id = {
            str(record.get("task_id")): candidate["images"].get(str(record.get("id")))
            for record in observation.get("images", [])
            if isinstance(record, dict) and record.get("task_id") and record.get("id")
        }
        pilot_images: dict[str, dict[str, str]] = {}
        for index, task_id in enumerate(pilot_task_ids, start=1):
            image = image_by_task_id.get(task_id)
            if not isinstance(image, dict):
                raise ValueError(f"image observation is missing a pinned digest for pilot task: {task_id}")
            pilot_images[f"eval_{index:03d}"] = copy.deepcopy(image)
        candidate["images"] = pilot_images
        candidate["_metadata"]["image_catalog_count"] = len(pilot_images)
        execution = candidate.setdefault("execution", {})
        metadata_paths = list(execution.get("metadata_paths", []))
        metadata_path = f"{pilot_root.name}/{effective_task_manifest_value}"
        execution["metadata_paths"] = sorted(set(metadata_paths + [metadata_path]))
    driver = candidate.get("workload", {}).get("driver")
    if isinstance(driver, str) and driver:
        project_root = source_contract_path.resolve().parents[2]
        driver_path = (project_root / driver).resolve()
        if not driver_path.is_relative_to(project_root) or not driver_path.is_file():
            raise ValueError("workload driver must resolve to a file inside the project root")
        candidate["workload"]["sha256"] = _sha256(driver_path)
    if campaign_variants is not None and pilot_id is None:
        if snapshot_relative_path is None:
            raise ValueError("a current environment snapshot is required for a multi-variant campaign candidate")
        resolved_output = output_path.resolve()
        # The contract itself and its authorization record are allowed by the
        # source guard. Bind only the snapshot and sidecars as additional
        # metadata so unrelated post-freeze changes remain blocked.
        candidate["execution"]["metadata_paths"] = [
            f"{project_root.name}/{snapshot_relative_path}",
            f"{project_root.name}/{snapshot_sidecar_relative_path}",
            f"{project_root.name}/{resolved_output.relative_to(project_root).as_posix()}.sha256",
        ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(candidate, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    _ensure_sha256_sidecar(output_path)
    return {
        "candidate_written": True,
        "candidate_path": output_path.as_posix(),
        "candidate_sha256": _sha256(output_path),
        "image_count": len(candidate["images"]),
        "status": candidate["_metadata"]["candidate_status"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-contract", type=Path, required=True)
    parser.add_argument("--observation", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-commit", required=True, help="40-character commit to freeze after candidate review")
    parser.add_argument("--experiment-id", help="new experiment ID, required for multi-variant non-pilot candidates")
    parser.add_argument("--task-manifest-path", required=True, help="path used by the formal runner and readiness audit")
    parser.add_argument("--cost-budget-usd", type=float, required=True, help="reviewed campaign-wide spend cap; no implicit default")
    parser.add_argument("--campaign-variant", action="append", dest="campaign_variants", help="freeze one allowed variant in workload.variant_matrix; may be repeated")
    parser.add_argument("--repetitions", type=int, default=1)
    parser.add_argument("--total-token-budget", type=int, help="explicit campaign-wide token cap; otherwise derive from run count and per-task turn budget")
    parser.add_argument("--environment-snapshot", type=Path, help="current observed snapshot, required for multi-variant non-pilot candidates")
    parser.add_argument("--pilot-id", help="create an exploratory pilot contract that remains separately accounted")
    parser.add_argument("--pilot-task-id", action="append", dest="pilot_task_ids", help="include one task in the explicitly scoped pilot; may be repeated")
    parser.add_argument("--pilot-manifest-output", type=Path, help="write a new inference-safe manifest containing only the selected pilot tasks")
    args = parser.parse_args()
    if len(args.source_commit) != 40 or any(char not in "0123456789abcdef" for char in args.source_commit):
        raise SystemExit("--source-commit must be a 40-character lowercase SHA-1")
    if args.cost_budget_usd <= 0:
        raise SystemExit("--cost-budget-usd must be positive")
    if args.campaign_variants and not args.pilot_id and args.environment_snapshot is None:
        raise SystemExit("--environment-snapshot is required for multi-variant campaign candidates")
    print(json.dumps(prepare(args.source_contract, args.observation, args.output, source_commit=args.source_commit, experiment_id=args.experiment_id, task_manifest_path=args.task_manifest_path, cost_budget_usd=args.cost_budget_usd, campaign_variants=args.campaign_variants, repetitions=args.repetitions, total_token_budget=args.total_token_budget, environment_snapshot_path=args.environment_snapshot, pilot_id=args.pilot_id, pilot_task_ids=args.pilot_task_ids, pilot_manifest_output=args.pilot_manifest_output), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
