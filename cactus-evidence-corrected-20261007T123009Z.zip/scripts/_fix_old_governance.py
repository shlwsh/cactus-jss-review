#!/usr/bin/env python3
"""Regenerate provenance for old governance files with correct paths."""
import sys
sys.path.insert(0, 'src')
sys.path.insert(0, '.')

import json
import hashlib
from pathlib import Path
from scripts.artifact_provenance import write

ROOT = Path('.')

# The old governance snapshot has provenance files with incorrect paths
# We need to regenerate them with the correct paths

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

# Regenerate provenance for historical_task_admission.jsonl
old_governance = ROOT / 'experiments/derived/governance_20261004T093000Z'
hist_file = old_governance / 'historical_task_admission.jsonl'
run_inv = old_governance / 'run_inventory.jsonl'

# Get all inputs from the old governance run_inventory
inputs = []
if run_inv.exists():
    for line in run_inv.read_text(encoding='utf-8').splitlines():
        if line.strip():
            record = json.loads(line)
            run_path = ROOT / record['path']
            if run_path.exists():
                inputs.append(run_path)

# Get all other derived files from lite50_retry_integration
lite50_dir = ROOT / 'experiments/derived/lite50_retry_integration_20261002T225306Z'
if lite50_dir.exists():
    for f in lite50_dir.rglob('*.jsonl'):
        if 'archived' not in str(f):
            inputs.append(f)
    for f in lite50_dir.rglob('*.json'):
        if f.name not in ['integration_summary.json']:
            inputs.append(f)

# Add the correct final_task_outcomes.csv
final_task = ROOT / 'paper/data/final_task_outcomes.csv'
if final_task.exists():
    inputs.append(final_task)

# Regenerate provenance
print(f'Re-generating provenance for {hist_file.name}')
write(hist_file, inputs, Path('scripts/audit_evidence_corpus.py'),
      transform={'scope': 'historical_task_admission'}, kind='derived_dataset')
print('Done!')
