"""Build a deterministic synthetic development set without resolution labels."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "data" / "fixtures" / "dev_set" / "tasks.jsonl"


def build(output: Path = OUTPUT, count: int = 24) -> dict[str, object]:
    categories = ("single_file", "multi_file", "call_chain", "test_association", "config_dependency", "multi_file")
    records = []
    for index in range(count):
        number = index + 1
        category = categories[index % len(categories)]
        query = f"Fix parser behavior for handler_{number} in src/pkg{number % 4}/core.py and test_parser_{number}"
        units = [
            {"unit_id": f"dev{number}-issue", "kind": "issue", "path": "issue.txt", "token_count": 18, "text": query, "coverage_keys": [f"task:DEV-{number:03d}"]},
            {"unit_id": f"dev{number}-core", "kind": "function", "path": f"src/pkg{number % 4}/core.py", "token_count": 72, "text": f"def handler_{number}(): return parse_{number}()", "symbol_id": f"handler_{number}", "start_line": 10, "end_line": 18, "lexical_score": 0.9, "coverage_keys": [f"symbol:handler_{number}", f"call:parse_{number}"]},
            {"unit_id": f"dev{number}-parent", "kind": "class", "path": f"src/pkg{number % 4}/core.py", "token_count": 80, "text": f"class Handler{number}: ...", "symbol_id": f"Handler{number}", "start_line": 1, "end_line": 8, "lexical_score": 0.4},
            {"unit_id": f"dev{number}-test", "kind": "test", "path": f"tests/test_parser_{number}.py", "token_count": 68, "text": f"def test_parser_{number}(): assert handler_{number}()", "symbol_id": f"test_parser_{number}", "start_line": 1, "end_line": 9, "lexical_score": 0.8, "coverage_keys": [f"test:test_parser_{number}"]},
            {"unit_id": f"dev{number}-tiny", "kind": "fragment", "path": f"src/pkg{number % 4}/helpers.py", "token_count": 8, "text": "return value", "lexical_score": 0.95},
        ]
        units[1]["parent_unit_id"] = units[2]["unit_id"]
        records.append({"task_id": f"DEV-{number:03d}", "category": category, "query": query, "units": units})
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    return {"output": output.relative_to(ROOT).as_posix(), "task_count": len(records), "resolution_labels": False}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--count", type=int, default=24)
    args = parser.parse_args()
    print(json.dumps(build(args.output, args.count), ensure_ascii=False))
