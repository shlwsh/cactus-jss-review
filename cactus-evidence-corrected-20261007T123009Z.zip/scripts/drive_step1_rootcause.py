"""
Step 1: Root-cause analysis of all R4 model interactions.
Reads every R4 RUN's trace/events.jsonl, extracts model_call + prediction_rejected,
and saves a unified analysis JSON.
"""
import json
from pathlib import Path
from collections import Counter

RUNS = [
    "RUN-20260925T105655Z-4B606E26",
    "RUN-20260925T111245Z-ED516428",
    "RUN-20260925T113558Z-0D213BFD",
    "RUN-20260925T120939Z-9F868CEF",
    "RUN-20260925T122119Z-500AC775",
    "RUN-20260925T122938Z-66CC37F3",
    "RUN-20260925T124001Z-5F41C11D",
    "RUN-20260925T124946Z-31DC4349",
]


def task_of(events):
    for e in events:
        if e.get("type") == "observe":
            turn_id = e["payload"].get("turn_id", "")
            if turn_id.startswith("predict-"):
                return turn_id[len("predict-"):]
    return None


def safe_edit_parse(resp):
    """Parse edits JSON; tolerate malformed output."""
    try:
        obj = json.loads(resp)
        edits = obj.get("edits", []) or []
        return [
            {
                "path": (ed.get("path") or "")[:200],
                "symbol": (ed.get("symbol") or "")[:80],
                "old_statement_head": (ed.get("old_statement") or "")[:120],
                "old_statement_len": len(ed.get("old_statement") or ""),
                "replacement_head": (ed.get("replacement") or "")[:120],
                "replacement_len": len(ed.get("replacement") or ""),
            }
            for ed in edits
        ]
    except Exception as exc:
        return [{"parse_error": str(exc)[:200], "raw_head": resp[:200]}]


def analyze_run(rid: str):
    path = Path(f"experiments/runs/{rid}/trace/events.jsonl")
    if not path.exists():
        return None
    events = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    task_id = task_of(events)
    mcalls = [e for e in events if e.get("type") == "model_call"]
    rejects = [e for e in events if e.get("type") == "prediction_rejected"]
    out = {
        "run_id": rid,
        "task_id": task_id,
        "n_model_calls": len(mcalls),
        "n_rejections": len(rejects),
        "interactions": [],
    }
    for idx, mc in enumerate(mcalls):
        p = mc["payload"]
        # find matching reject
        rj = rejects[idx]["payload"] if idx < len(rejects) else {}
        out["interactions"].append(
            {
                "attempt": idx + 1,
                "finish_reason": p.get("finish_reason"),
                "input_tokens": p.get("input_tokens"),
                "output_tokens": p.get("output_tokens"),
                "prompt_chars": len(p.get("prompt_text") or ""),
                "response_chars": len(p.get("response_text") or ""),
                "response_text": p.get("response_text", "")[:400],
                "edits_parsed": safe_edit_parse(p.get("response_text") or ""),
                "reject_reason_class": rj.get("reason_class"),
                "reject_reason": rj.get("reason"),
                "prompt_sha256_short": (p.get("prompt_sha256") or "")[:16],
            }
        )
    return out


def main():
    summary = []
    by_task = Counter()
    by_reason = Counter()
    by_symbol = Counter()
    placeholder_counter = Counter()
    for rid in RUNS:
        info = analyze_run(rid)
        if not info:
            print(f"[skip] {rid}: no trace events.jsonl")
            continue
        summary.append(info)
        by_task[info["task_id"]] += len(info["interactions"])
        for inter in info["interactions"]:
            by_reason[inter.get("reject_reason_class") or "<none>"] += 1
            for ed in inter["edits_parsed"]:
                if "parse_error" not in ed:
                    by_symbol[(ed["symbol"], ed["path"])] += 1
                    repl = ed["replacement_head"].strip()
                    if repl in {".placeholder", "placeholder", "...", ".", "..."}:
                        placeholder_counter[repl] += 1

    out_path = Path("experiments/runs/_r4_rootcause_analysis.json")
    out_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print("=" * 80)
    print("STEP 1: ROOT-CAUSE ANALYSIS — R4 MODEL INTERACTIONS")
    print("=" * 80)
    print(f"Runs analyzed: {len(summary)}")
    print(f"Total model interactions: {sum(s['n_model_calls'] for s in summary)}")
    print(f"Total rejections: {sum(s['n_rejections'] for s in summary)}")
    print()
    print("By task_id:")
    for t, c in by_task.most_common():
        print(f"  {t}: {c}")
    print()
    print("By reject reason_class:")
    for r, c in by_reason.most_common():
        print(f"  {r}: {c}")
    print()
    print("By (symbol, path):")
    for (s, p), c in by_symbol.most_common():
        print(f"  {s} @ {p}: {c}")
    print()
    print("Placeholder-like replacements:")
    for k, c in placeholder_counter.most_common():
        print(f"  {k!r}: {c}")
    print()
    print(f"Saved analysis to: {out_path}")


if __name__ == "__main__":
    main()
