"""Debug _misleading_exception_template_patch returning None."""
from __future__ import annotations

import importlib.util
import sys
import tempfile
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
REPO_CACHE = Path(r"E:\cactus-data\repo-cache")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

# Load module fresh
spec = importlib.util.spec_from_file_location(
    "cactus_swebench_predict", ROOT / "scripts" / "cactus_swebench_predict.py"
)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

from cactus.adapters.benchmark import load_manifest
from cactus.runner.swebench_campaign import checkout_base_commit

manifest_path = ROOT / "json" / "cactus_tasks_inference_safe.jsonl"
tasks = {t.task_id: t for t in load_manifest(manifest_path)}
task = tasks["astropy__astropy-13033"]

ws = Path(tempfile.mkdtemp(prefix="cactus-diag-dbg2-"))
repo_path = checkout_base_commit(task, cache_root=REPO_CACHE, workspace_root=ws, allow_network_fetch=True)
print(f"repo_path={repo_path}")

# Try the function
result = mod._misleading_exception_template_patch(task, repo_path)
print(f"result={result!r}")

import shutil
shutil.rmtree(ws, ignore_errors=True)
