"""Inspect 11564 events to understand why 6 pair still fails with source_mismatch."""
import json
from pathlib import Path
p = Path("experiments/runs/FACO-FULL-LITE50-POSTFIX2-20261003T220125Z/django__django-11564/events.jsonl")
if p.exists():
    with p.open() as f:
        events = [json.loads(line) for line in f]
    print(f"Total events: {len(events)}")
    # show SITES responses
    for ev in events:
        t = ev.get("type")
        if t == "model_call":
            payload = ev.get("payload", {})
            prompt = payload.get("prompt_text", "")
            response = payload.get("response_text", "")
            if "SITES:" in prompt:
                ot = payload.get("output_tokens", "?")
                print(f"\n[seq {ev.get('seq')} ot={ot}]")
                print(f"  RESP: {response[:200]!r}")
        elif t in ("prediction_sites_rejected", "prediction_rejected"):
            payload = ev.get("payload", {})
            print(f"  [{t} attempt={payload.get('attempt')}] stage={payload.get('stage')} reason={(payload.get('reason') or '')[:100]!r}")
else:
    print("not found")
