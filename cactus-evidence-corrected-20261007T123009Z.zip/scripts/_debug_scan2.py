#!/usr/bin/env python3
"""Debug scan for specific lines."""
import re

lines = [
    (330, "Cochran's Q test for paired binary outcomes rejects the global null hypothesis of no strategy difference: $Q=$\\DataValue{p04.cochran.q} (df$=${p04.cochran.df}), $p=$\\DataValue{p04.cochran.p} ($<0.01$)."),
    (350, "FACO significantly outperforms MAXIMAL: paired difference \\DataValue{p04.faco_vs_maximal.diff} (95\\% CI: \\DataValue{p04.faco_vs_maximal.ci_low} to \\DataValue{p04.faco_vs_maximal.ci_high}), McNemar exact $p=$\\DataValue{p04.faco_vs_maximal.p} ($<0.01$). FACO significantly outperforms STRUCTURAL: paired difference \\DataValue{p04.faco_vs_structural.diff} (95\\% CI: \\DataValue{p04.faco_vs_structural.ci_low} to \\DataValue{p04.faco_vs_structural.ci_high}), McNemar exact $p=$\\DataValue{p04.faco_vs_structural.p} ($<0.01$). FACO and BM25 are statistically indistinguishable: paired difference \\DataValue{p04.faco_vs_bm25.diff} (95\\% CI: \\DataValue{p04.faco_vs_bm25.ci_low} to \\DataValue{p04.faco_vs_bm25.ci_high}), McNemar exact $p=$\\DataValue{p04.faco_vs_bm25.p} ($>0.05$)."),
    (352, "These results support three conclusions. First, greedy context maximization (MAXIMAL) significantly underperforms FACO, suggesting that filling the context budget with irrelevant code dilutes model attention. Second, static structural retrieval without semantic pruning (STRUCTURAL) also significantly underperforms FACO, indicating that call-graph proximity alone is insufficient for fault localization. Third, the absence of a significant difference between FACO and BM25 at $n=100$ suggests that lexical retrieval provides a competitive baseline; further investigation with larger cohorts is warranted."),
    (361, ""),  # Will read from file
    (363, ""),  # Will read from file
    (378, ""),  # Will read from file
    (380, ""),  # Will read from file
    (390, ""),  # Will read from file
    (395, ""),  # Will read from file
    (400, ""),  # Will read from file
]

def process_line(line):
    digit_check = line
    digit_check = re.sub(r"\b(?:flake8|mypy|pyright|ruff)\s+[A-Z]\d+", "TOOL_CODE", digit_check)
    digit_check = re.sub(r"\$\\[gl]e\$\d+", "INEQUALITY_ZERO", digit_check)
    digit_check = re.sub(r"\\(?:DataValue|input|label|ref|cite[a-zA-Z*]*|bibliography|bibliographystyle)\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\includegraphics(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\(?:documentclass|usepackage)(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\email\{[^}]*\}", "", digit_check)
    digit_check = re.sub(r"\\(?:emergencystretch|setlength)\s*(?:=\s*)?(?:\{[^}]*\})?\s*\{?\d+(?:\.\d+)?(?:pt|em|mm|cm)\}?", "", digit_check)
    digit_check = re.sub(r"\\b(?:BM25|§\d+)\b", "ALLOWED_ID", digit_check)
    digit_check = re.sub(r"\\[a-zA-Z]+\{[^}]*\}", "", digit_check)
    return digit_check

for lineno, line in lines:
    if not line:
        continue
    result = process_line(line)
    if re.search(r"\d", result):
        print(f"Line {lineno}: FOUND DIGITS")
        for m in re.finditer(r"\d+", result):
            start = max(0, m.start() - 30)
            end = min(len(result), m.end() + 30)
            print(f"  Digit at position {m.start()}: '{m.group()}'")
            print(f"  Context: ...{result[start:end]}...")
    else:
        print(f"Line {lineno}: OK")
