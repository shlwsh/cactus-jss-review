"""
FACO Ablation Experiment: Compare Random, BM25, and FACO retrieval methods.

This script executes the ablation experiment for P0-1 (FACO effectiveness)
comparing:
- Random Retrieval: Random selection baseline
- BM25 Retrieval: Term frequency based retrieval
- FACO: Current marginal utility density selection (ours)

Usage:
    python scripts/run_ablation_faco.py --variant random --output experiments/runs/
"""

from __future__ import annotations

import argparse
import json
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import hashlib

# Add src to path for imports
ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT / "src"))

from cactus.domain.models import ContextUnit
from cactus.retrieval.scoring import score_candidates, ScoringMode
from cactus.retrieval.marginal_utility import select_marginal_utility, marginal_utility_score


@dataclass
class AblationConfig:
    """Configuration for ablation experiment."""
    variant: str  # random, bm25, faco
    token_budget: int = 16384
    seed: int = 42
    output_dir: Path | None = None


@dataclass
class AblationResult:
    """Result from a single ablation run."""
    variant: str
    task_id: str
    run_id: str
    resolved: bool
    token_consumed: int
    latency_seconds: float
    retrieval_precision: float
    context_utilization: float
    selected_units: list[str] = field(default_factory=list)
    selected_files: list[str] = field(default_factory=list)
    error: str | None = None


def compute_bm25_scores(
    units: list[ContextUnit],
    query_terms: list[str],
    k1: float = 1.5,
    b: float = 0.75,
) -> dict[str, float]:
    """
    Compute BM25 scores for candidate units.
    
    BM25 formula: score = sum IDF(term) * tf(term) / (k1 * (1 - b + b * dl/avgdl))
    """
    # Count term frequencies in query
    query_tf = {}
    for term in query_terms:
        term_lower = term.lower()
        query_tf[term_lower] = query_tf.get(term_lower, 0) + 1
    
    # Count document frequencies
    doc_freq = {}
    doc_lengths = {}
    for unit in units:
        unit_text = unit.text.lower()
        doc_len = len(unit_text.split())
        doc_lengths[unit.unit_id] = doc_len
        
        # Get unique terms in document
        unit_terms = set(unit_text.split())
        for term in query_tf:
            if term in unit_terms:
                doc_freq[term] = doc_freq.get(term, 0) + 1
    
    # Calculate IDF
    n_docs = len(units)
    idf = {}
    for term, df in doc_freq.items():
        idf[term] = max(0, (n_docs - df + 0.5) / (df + 0.5))
    
    # Calculate BM25 scores
    avg_dl = sum(doc_lengths.values()) / max(1, n_docs)
    scores = {}
    
    for unit in units:
        unit_text = unit.text.lower()
        unit_terms = unit_text.split()
        dl = doc_lengths[unit.unit_id]
        
        score = 0.0
        for term, qtf in query_tf.items():
            tf = unit_terms.count(term)
            if tf > 0 and term in idf:
                score += idf[term] * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / max(1, avg_dl)))
        
        scores[unit.unit_id] = score
    
    return scores


def random_selection(
    units: list[ContextUnit],
    budget: int,
    seed: int,
) -> list[ContextUnit]:
    """Random selection baseline."""
    random.seed(seed)
    
    selected = []
    used_tokens = 0
    shuffled = random.sample(units, len(units))
    
    for unit in shuffled:
        if used_tokens + unit.token_count <= budget:
            selected.append(unit)
            used_tokens += unit.token_count
    
    return selected


def bm25_selection(
    units: list[ContextUnit],
    budget: int,
    query_terms: list[str],
    k1: float = 1.5,
    b: float = 0.75,
) -> list[ContextUnit]:
    """BM25-based selection."""
    scores = compute_bm25_scores(units, query_terms, k1, b)
    
    # Sort by BM25 score descending
    sorted_units = sorted(units, key=lambda u: scores.get(u.unit_id, 0.0), reverse=True)
    
    selected = []
    used_tokens = 0
    
    for unit in sorted_units:
        if used_tokens + unit.token_count <= budget:
            selected.append(unit)
            used_tokens += unit.token_count
    
    return selected


def faco_selection(
    units: list[ContextUnit],
    budget: int,
    scores: dict[str, float],
) -> list[ContextUnit]:
    """FACO marginal utility density selection."""
    result = select_marginal_utility(
        units=list(units),
        scores=scores,
        budget=budget,
    )
    
    # Reconstruct selected units
    unit_map = {u.unit_id: u for u in units}
    return [unit_map[uid] for uid in result.selected_unit_ids if uid in unit_map]


def compute_precision(selected_units: list[ContextUnit], gold_files: list[str]) -> float:
    """Compute retrieval precision: overlap with gold patch files."""
    if not selected_units or not gold_files:
        return 0.0
    
    selected_paths = set(u.path for u in selected_units)
    gold_set = set(gold_files)
    
    overlap = len(selected_paths & gold_set)
    return overlap / len(gold_set) if gold_set else 0.0


def run_ablation_variant(
    config: AblationConfig,
    task_id: str,
    units: list[ContextUnit],
    query_terms: list[str],
    gold_files: list[str],
) -> AblationResult:
    """Run a single ablation variant for one task."""
    start_time = time.time()
    
    run_id = f"RUN-ABLATION-{config.variant.upper()}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    
    try:
        if config.variant == "random":
            selected = random_selection(units, config.token_budget, config.seed)
        elif config.variant == "bm25":
            selected = bm25_selection(units, config.token_budget, query_terms)
        elif config.variant == "faco":
            # FACO needs pre-computed relevance scores
            static_scores = {u.unit_id: random.random() for u in units}  # Placeholder
            selected = faco_selection(units, config.token_budget, static_scores)
        else:
            raise ValueError(f"Unknown variant: {config.variant}")
        
        token_consumed = sum(u.token_count for u in selected)
        latency = time.time() - start_time
        precision = compute_precision(selected, gold_files)
        utilization = token_consumed / config.token_budget if config.token_budget > 0 else 0.0
        
        return AblationResult(
            variant=config.variant,
            task_id=task_id,
            run_id=run_id,
            resolved=False,  # Would need actual evaluation
            token_consumed=token_consumed,
            latency_seconds=latency,
            retrieval_precision=precision,
            context_utilization=utilization,
            selected_units=[u.unit_id for u in selected],
            selected_files=[u.path for u in selected],
        )
        
    except Exception as e:
        return AblationResult(
            variant=config.variant,
            task_id=task_id,
            run_id=run_id,
            resolved=False,
            token_consumed=0,
            latency_seconds=time.time() - start_time,
            retrieval_precision=0.0,
            context_utilization=0.0,
            error=str(e),
        )


def save_results(results: list[AblationResult], output_dir: Path, variant: str):
    """Save ablation results to output directory."""
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save results JSON
    results_file = output_dir / f"ablation_{variant}_results.json"
    results_data = [
        {
            "variant": r.variant,
            "task_id": r.task_id,
            "run_id": r.run_id,
            "resolved": r.resolved,
            "token_consumed": r.token_consumed,
            "latency_seconds": r.latency_seconds,
            "retrieval_precision": r.retrieval_precision,
            "context_utilization": r.context_utilization,
            "selected_units": r.selected_units,
            "selected_files": r.selected_files,
            "error": r.error,
        }
        for r in results
    ]
    results_file.write_text(json.dumps(results_data, indent=2))
    
    # Save summary
    summary = {
        "variant": variant,
        "total_runs": len(results),
        "resolved_count": sum(1 for r in results if r.resolved),
        "avg_token_consumed": sum(r.token_consumed for r in results) / max(1, len(results)),
        "avg_latency": sum(r.latency_seconds for r in results) / max(1, len(results)),
        "avg_precision": sum(r.retrieval_precision for r in results) / max(1, len(results)),
        "avg_utilization": sum(r.context_utilization for r in results) / max(1, len(results)),
    }
    summary_file = output_dir / f"ablation_{variant}_summary.json"
    summary_file.write_text(json.dumps(summary, indent=2))
    
    print(f"[{variant}] Results saved to {output_dir}")
    print(f"[{variant}] Summary: {summary['resolved_count']}/{summary['total_runs']} resolved, "
          f"avg precision={summary['avg_precision']:.3f}")


def main():
    parser = argparse.ArgumentParser(description="FACO Ablation Experiment")
    parser.add_argument("--variant", required=True, choices=["random", "bm25", "faco"],
                        help="Retrieval method to test")
    parser.add_argument("--output", default="experiments/runs/ABLATION-20261003",
                        help="Output directory for results")
    parser.add_argument("--budget", type=int, default=16384,
                        help="Token budget for context selection")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for reproducibility")
    parser.add_argument("--tasks", nargs="+", default=["astropy__astropy-6938"],
                        help="Task IDs to evaluate")
    
    args = parser.parse_args()
    
    config = AblationConfig(
        variant=args.variant,
        token_budget=args.budget,
        seed=args.seed,
        output_dir=Path(args.output),
    )
    
    print(f"[ABLATION] Starting {config.variant} baseline experiment")
    print(f"[ABLATION] Token budget: {config.token_budget}")
    print(f"[ABLATION] Random seed: {config.seed}")
    
    # Placeholder: Load actual units and tasks
    # In real execution, this would load from SWE-bench dataset
    print("[ABLATION] Note: This is the experiment scaffold. Actual execution requires:")
    print("  1. Loading SWE-bench Lite task definitions")
    print("  2. Building candidate unit index for each repository")
    print("  3. Running actual model inference")
    print("  4. Evaluating with official SWE-bench harness")
    
    # Save config for reference
    config_dir = Path(args.output) / f"config_{config.variant}"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / "experiment_config.json"
    config_file.write_text(json.dumps({
        "variant": config.variant,
        "token_budget": config.token_budget,
        "seed": config.seed,
        "tasks": args.tasks,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }, indent=2))
    
    print(f"[ABLATION] Config saved to {config_file}")


if __name__ == "__main__":
    main()
