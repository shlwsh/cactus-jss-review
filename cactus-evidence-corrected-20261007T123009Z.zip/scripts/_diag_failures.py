"""Diagnose 13 failed tasks - correct field names: type, payload."""
import json
from pathlib import Path
from collections import Counter

BASE = Path("experiments/runs/FACO-FULL-LITE50-RESUME-20261003T203555Z")
FAILED = [
    "astropy__astropy-12907",
    "django__django-10924", "django__django-11019", "django__django-11179",
    "django__django-11564", "django__django-11797", "django__django-11910",
    "django__django-12125", "django__django-12284", "django__django-12470",
    "django__django-12708", "django__django-13028", "django__django-13158",
]

stage_counter = Counter()
reason_counter = Counter()
per_task = {}

for tid in FAILED:
    p = BASE / tid / "events.jsonl"
    if not p.exists():
        per_task[tid] = ["missing events.jsonl"]
        continue
    with p.open("r", encoding="utf-8") as f:
        events = [json.loads(line) for line in f]

    # extract rejected + exhausted events
    rej_types = ("prediction_rejected", "prediction_exhausted", "final_outcome", "candidate_rejected")
    for ev in events:
        if ev.get("type") in rej_types:
            payload = ev.get("payload", {})
            rclass = payload.get("reason_class", "?")
            stage = payload.get("stage", "?")
            reason_counter[rclass] += 1
            stage_counter[(stage, rclass)] += 1

    # last 4 events
    last = events[-4:] if len(events) >= 4 else events
    per_task[tid] = []
    for ev in last:
        payload = ev.get("payload", {})
        per_task[tid].append({
            "type": ev.get("type", ""),
            "stage": payload.get("stage", ""),
            "reason_class": payload.get("reason_class", ""),
            "reason": (payload.get("reason") or payload.get("final_rejection") or "")[:200],
            "attempt": payload.get("attempt", ""),
            "excerpt": (payload.get("response_excerpt") or "")[:200],
        })

print("=== reason_class frequency ===")
for r, c in reason_counter.most_common():
    print(f"  {r}: {c}")

print("\n=== (stage, reason_class) frequency ===")
for k, c in stage_counter.most_common():
    print(f"  {k}: {c}")

print("\n=== Per task last events ===")
for tid, evs in per_task.items():
    print(f"\n[{tid}]")
    if isinstance(evs[0], str):
        print(f"  {evs[0]}")
        continue
    for ev in evs:
        print(f"  - type={ev['type']:<22} stage={ev['stage']:<12} rclass={ev['reason_class']:<22} attempt={ev['attempt']}")
        if ev['reason']:
            print(f"      reason: {ev['reason'][:200]!r}")
        if ev['excerpt']:
            print(f"      excerpt: {ev['excerpt'][:200]!r}")
