"""Generate a deterministic inventory of the CACTUS source tree."""

from __future__ import annotations

import ast
import subprocess
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src" / "cactus"
DEFAULT_OUTPUT = ROOT / "artifacts" / "repo_inventory.md"


def _git(args: list[str]) -> str:
    return subprocess.run(["git", *args], cwd=ROOT, text=True, capture_output=True, check=False).stdout.strip()


def _symbols(path: Path) -> tuple[list[str], list[str]]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=path.as_posix())
    except (OSError, SyntaxError, UnicodeDecodeError):
        return [], []
    classes = sorted(node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef))
    functions = sorted(node.name for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)))
    return classes, functions


def generate(output: Path = DEFAULT_OUTPUT) -> dict[str, object]:
    files = sorted(SOURCE.rglob("*.py"))
    rows: list[dict[str, object]] = []
    for path in files:
        classes, functions = _symbols(path)
        relative = path.relative_to(ROOT).as_posix()
        area = path.relative_to(SOURCE).parts[0] if len(path.relative_to(SOURCE).parts) > 1 else "cactus"
        rows.append({"path": relative, "area": area, "classes": classes, "functions": functions})
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines = [
        "# CACTUS 仓库盘点",
        "",
        f"> 生成时间：{generated_at}",
        f"> Git 提交：`{_git(['rev-parse', 'HEAD'])}`",
        f"> Git 分支：`{_git(['branch', '--show-current'])}`",
        f"> 源文件数：{len(rows)}",
        "",
        "## 目标模块映射",
        "",
        "| v2.1 目标模块 | 当前实现目录/文件 | 状态 |",
        "|---|---|---|",
        "| task / repository / retrieval | `src/cactus/task/`, `repository/`, `retrieval/` | 已有，待接入边际效用选择 |",
        "| selection | `src/cactus/selection/` | 本轮新增正式变体入口 |",
        "| execution / failure recovery | `src/cactus/execution/`, `failure_recovery/` | 已有，待补齐 A/X/E/G 映射 |",
        "| evaluation / replay | `src/cactus/evaluation/`, `scripts/` | 已有，待补齐历史回放证据 |",
        "| governance / telemetry | `src/cactus/governance/`, `telemetry/` | 已有，保持证据与密钥隔离 |",
        "| analysis | `src/cactus/analysis/` | 已有统计原语，待接入主实验结果 |",
        "",
        "## 文件清单",
        "",
        "| 文件 | 功能区 | 类 | 函数 |",
        "|---|---|---|---|",
    ]
    for row in rows:
        classes = ", ".join(f"`{item}`" for item in row["classes"]) or "—"
        functions = ", ".join(f"`{item}`" for item in row["functions"]) or "—"
        lines.append(f"| `{row['path']}` | `{row['area']}` | {classes} | {functions} |")
    lines.extend([
        "",
        "## 冻结边界",
        "",
        "- `experiments/runs/RUN-*` 历史运行制品只读，不覆盖、不重写。",
        "- 论文数值只能由真实 RUN、确定性派生和治理脚本生成。",
        "- v2.1 新增选择器和故障分类器必须保持确定性并提供可验证哈希。",
        "",
    ])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    return {"output": output.relative_to(ROOT).as_posix(), "files": len(rows), "generated_at": generated_at}


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    print(json.dumps(generate(args.output), ensure_ascii=False))
