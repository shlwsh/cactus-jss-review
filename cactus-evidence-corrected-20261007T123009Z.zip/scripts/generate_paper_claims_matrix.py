"""Generate a fail-closed claim-to-evidence matrix for the TOSEM manuscript."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "docs" / "tosem" / "paper_claims_matrix.md"


def _sha256(path: Path) -> str | None:
    if not path.is_file():
        return None
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _relative(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _status(path: Path, *, observed: bool = False) -> str:
    if not path.is_file():
        return "PENDING_EVIDENCE"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return "PENDING_EVIDENCE"
    return "VERIFIED" if observed and payload.get("status") in {"pass", "observed", "generated"} else "PENDING_EVIDENCE"


def generate(output: Path = OUTPUT) -> dict[str, object]:
    if (ROOT / "paper/publication_sources.json").is_file():
        raise ValueError("Legacy snapshot claims withdrawn; current claims and sources are in publication_values.json and the integrity handoff")
    from generate_evidence_catalog import derive, verify
    verify()
    catalog, _, _ = derive()
    frozen = catalog["cohorts"][0]["counts"]
    retry = catalog["cohorts"][1]["counts"]
    selector = ROOT / "analysis" / "context_selector_validation.json"
    taxonomy = ROOT / "analysis" / "historical_failure_summary.json"
    replay = ROOT / "analysis" / "failure_recovery_summary.json"
    statistics = ROOT / "analysis" / "statistics_summary.json"
    outcomes = ROOT / "paper" / "data" / "final_task_outcomes.csv"
    entries = [
        {
            "claim_id": "C1",
            "claim": "选择器在无分辨率标签的开发集上保持确定性，并完成参数敏感性检查",
            "manuscript_scope": "方法与内部验证",
            "status": "VERIFIED_DEV_ONLY" if _status(selector, observed=True) == "VERIFIED" else "PENDING_EVIDENCE",
            "evidence": [_relative(selector), _relative(ROOT / "analysis" / "context_selector_sensitivity.csv")],
            "allowed_in_abstract": False,
        },
        {
            "claim_id": "C2",
            "claim": "选择器降低碎片化并提高修复率",
            "manuscript_scope": "主实验效果",
            "status": "PENDING_EVIDENCE",
            "evidence": [_relative(ROOT / "results" / "main_task_level_metrics.csv")],
            "allowed_in_abstract": False,
        },
        {
            "claim_id": "C3",
            "claim": "CACTUS 相对于 full_context、lexical_bm25 的修复率或成本更优",
            "manuscript_scope": "RQ1/RQ2 主结论",
            "status": "PENDING_EVIDENCE",
            "evidence": [_relative(ROOT / "results" / "main_task_level_metrics.csv")],
            "allowed_in_abstract": False,
        },
        {
            "claim_id": "C4",
            "claim": "四项消融能够归因于符号图、预算控制器、失败恢复和静态密度组件",
            "manuscript_scope": "RQ2 消融",
            "status": "PENDING_EVIDENCE",
            "evidence": [_relative(ROOT / "results" / "ablation_results.csv")],
            "allowed_in_abstract": False,
        },
        {
            "claim_id": "C5",
            "claim": f"当前快照的 {frozen['error']} 个未裁定结果已完成任务级归因与评估器回放",
            "manuscript_scope": "RQ3",
            "status": "VERIFIED" if _status(taxonomy, observed=True) == "VERIFIED" and _status(replay, observed=True) == "VERIFIED" else "PENDING_EVIDENCE",
            "evidence": [_relative(taxonomy), _relative(replay)],
            "allowed_in_abstract": False,
        },
        {
            "claim_id": "C6",
            "claim": "500 任务上的 EVR、ORR、CRR、成本和词元差异已经统计显著",
            "manuscript_scope": "RQ1/RQ2/RQ4 统计结论",
            "status": "PENDING_EVIDENCE",
            "evidence": [_relative(statistics), _relative(ROOT / "results" / "main_task_level_metrics.csv")],
            "allowed_in_abstract": False,
        },
        {
            "claim_id": "C7",
            "claim": f"冻结历史快照含 {frozen['unique_tasks']} 个唯一任务、{frozen['resolved']} 个 resolved、{frozen['unresolved']} 个 unresolved 和 {frozen['error']} 个未裁定结果；不等价于全库来源准入通过",
            "manuscript_scope": "历史测量管线描述",
            "status": "VERIFIED" if outcomes.is_file() else "PENDING_EVIDENCE",
            "evidence": [_relative(outcomes)],
            "allowed_in_abstract": True,
        },
    ]
    entries.extend([
        {"claim_id": "C8", "claim": f"失败任务重试 {retry['sealed_run_count']} 个 RUN 中 {retry['admitted_run_count']} 个完整准入，解决 {len(retry['resolved_task_ids'])} 个不同任务；仅描述性 supporting 证据",
         "manuscript_scope": "摘要、重试结果、结论", "status": "VERIFIED", "allowed_in_abstract": True,
         "evidence": ["paper/data/evidence_catalog.json", "paper/data/admitted_retry_results.csv"]},
        {"claim_id": "C9", "claim": f"发现 {retry['exclusion_reason_counts'].get('contract_driver_source_hash_mismatch', 0)} 个合同 driver/source 摘要不一致 RUN；不得作为效果证据",
         "manuscript_scope": "来源审计", "status": "VERIFIED", "allowed_in_abstract": True,
         "evidence": ["paper/data/evidence_catalog.json", catalog['sources']['retry_inventory']['path']]},
        {"claim_id": "C10", "claim": "源码绑定与多位点事务提高任务解决率", "manuscript_scope": "组件效果归因", "status": "PENDING_EVIDENCE", "allowed_in_abstract": False,
         "evidence": ["src/cactus/context/repair_sites.py", "src/cactus/validation/repair_transaction.py", "src/cactus/validation/sequence_ordering.py"]},
    ])
    output.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# CACTUS TOSEM 论文主张矩阵",
        "",
        f"> 版本：{output.name.split('_')[0] if output.name.startswith('v') else 'generated'}",
        f"> 生成时间（UTC）：{datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}",
        "> 规则：只有 `VERIFIED` 主张可进入摘要或结论；`VERIFIED_DEV_ONLY` 仅限方法/内部验证，`PENDING_EVIDENCE` 不得写成效果结论。",
        "",
        "| ID | 主张 | 论文范围 | 状态 | 证据 | 可进摘要 |",
        "|---|---|---|---|---|---|",
    ]
    for entry in entries:
        evidence = "；".join(f"`{item}`" for item in entry["evidence"])
        allowed = "是" if entry["allowed_in_abstract"] and entry["status"] == "VERIFIED" else "否"
        lines.append(f"| {entry['claim_id']} | {entry['claim']} | {entry['manuscript_scope']} | `{entry['status']}` | {evidence} | {allowed} |")
    lines.extend([
        "",
        "## 生成输入哈希",
        "",
        "| 文件 | SHA-256 |",
        "|---|---|",
    ])
    sources = sorted({source for entry in entries for source in entry["evidence"]})
    for source in sources:
        lines.append(f"| `{source}` | `{_sha256(ROOT / source) or 'missing'}` |")
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    summary = {
        "schema_version": "2.1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "output": _relative(output),
        "entry_count": len(entries),
        "verified_count": sum(entry["status"] == "VERIFIED" for entry in entries),
        "pending_count": sum(entry["status"] == "PENDING_EVIDENCE" for entry in entries),
        "abstract_allowed_count": sum(entry["allowed_in_abstract"] and entry["status"] == "VERIFIED" for entry in entries),
        "entries": entries,
        "status": "generated",
    }
    output.with_suffix(".json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    print(json.dumps(generate(), ensure_ascii=False))
