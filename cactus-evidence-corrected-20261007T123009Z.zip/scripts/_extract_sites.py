"""查每个 site_id 对应的 site kind (从 preference 或 raw 文件)"""

import json
import sys
import re
from pathlib import Path

events_path = sys.argv[1]
events_file = Path(events_path)
# 看事件对应的 raw 文件或 event details
with open(events_file, encoding='utf-8') as f:
    events = [json.loads(l) for l in f]

# 找 site_id -> kind 映射 (从 model_call 事件响应中)
import re

# 抓所有 SITES: 行
sites_seen = []
for e in events:
    t = e.get('type', '')
    if t == 'model_call':
        p = e.get('payload', {})
        prompt = p.get('prompt', '')[:3000]
        response = p.get('response', '')
        if 'SITES:' in response:
            m = re.search(r'SITES:\s*(.*?)(?:\n|$)', response)
            if m:
                sites_seen.append(m.group(1))

print('Sites in model responses:')
for s in sites_seen:
    print(' ', s)