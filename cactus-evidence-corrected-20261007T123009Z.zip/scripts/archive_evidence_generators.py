"""Preserve an exact existing generator byte binding from a verified Git blob."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

from scripts.artifact_provenance import write
from cactus.governance.evidence_locations import confined

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sidecar", required=True)
    parser.add_argument("--capture-commit", required=True)
    args = parser.parse_args()
    sidecar = confined(ROOT, args.sidecar)
    generator = json.loads(sidecar.read_text(encoding="utf-8"))["generator"]
    script = generator["script"]
    confined(ROOT, script)
    result = subprocess.run(["git", "rev-parse", args.capture_commit], cwd=ROOT, capture_output=True, text=True, check=True)
    commit = result.stdout.strip()
    original = subprocess.run(["git", "show", commit + ":acm/" + script], cwd=ROOT, capture_output=True, check=True).stdout
    digest = hashlib.sha256(original).hexdigest()
    if digest != generator["script_sha256"]:
        raise ValueError("Git blob is not the exact generator recorded by the frozen sidecar")
    directory = ROOT / "experiments/quarantine/generator_sources"
    directory.mkdir(parents=True, exist_ok=True)
    snapshot = directory / (digest + ".py")
    if snapshot.exists():
        raise FileExistsError(snapshot)
    snapshot.write_bytes(original)
    write(snapshot, [sidecar], Path(__file__), transform={"activity": "preserve_existing_generator_byte_binding",
          "capture_commit": commit, "source_path": script, "original_recorded_commit": generator["source_commit"],
          "original_metadata_unchanged": True}, kind="derived_dataset")
    index_path = directory / "index.json"
    index = json.loads(index_path.read_text(encoding="utf-8")) if index_path.exists() else {"schema_version": "1.0", "bindings": {}}
    index["bindings"][digest] = {"script": script, "snapshot_path": snapshot.relative_to(ROOT).as_posix(),
                                  "capture_commit": commit, "captured_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    write(index_path, [snapshot, sidecar], Path(__file__), transform={"activity": "index_hash_verified_generator_archives"}, kind="derived_dataset")
    print(json.dumps({"status": "PASS", "snapshot": snapshot.relative_to(ROOT).as_posix(), "sha256": digest}))


if __name__ == "__main__":
    main()
