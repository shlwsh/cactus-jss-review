"""Optimized R4 predict+eval pipeline — each task gets unique RUN ID, concurrent predict.

Key improvements:
  - Unique RUN IDs per task (UUID-based, not timestamp-based)
  - Concurrent predict (both tasks simultaneously)
  - Docker images pre-warmed in parallel before any eval
  - Per-phase timeout: predict=600s, eval=900s
  - Docker image cleanup after each eval (saves ~2.9GB per task)
  - Full token/timing tracking + bundle seal on completion

Usage:
  & E:\\work\\p5-acm\\acm\\.venv\\Scripts\\python.exe -u scripts\\_run_r4_v2.py
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import uuid
import threading
import platform
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"E:\work\p5-acm\acm")
DATASET = Path(r"E:\cactus-data\swebench\verified\78f471bf655a3137b2e8a75af1501690ec009ec3\cactus_tasks_eval_augmented.jsonl")
ENV_FILE = ROOT / "docs" / "llm" / ".env"
MODEL_CONFIG = "configs/models/litellm_local_nothink_v7.json"
TRUSTED_COMMIT = "9ea4f04f96f27c6e668c4a33e6ecfd3030013a3c"

TASKS = [
    {
        "task_id": "astropy__astropy-13033",
        "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13033@sha256:22f4f193fbf69d61c59e285494be18041934f8b528190dfe8c6c0d8051d8d6de",
    },
    {
        "task_id": "astropy__astropy-13236",
        "pinned_image": "swebench/sweb.eval.x86_64.astropy_1776_astropy-13236@sha256:dede759cb182b28dc949fe9ee05d6fd09d032df5a802af190121a8f9cec36b9e",
    },
]

PREDICT_TIMEOUT = 1800   # 30 min per task; API may be slow
EVAL_TIMEOUT = 900      # 15 min
PREWARM_WORKERS = 2
PREDICT_WORKERS = 1     # run tasks sequentially to avoid concurrent API overload
CLEANUP_AFTER_EVAL = True


@dataclass
class TaskResult:
    task_id: str
    run_id: str
    pinned_image: str
    predict_ok: bool = False
    eval_resolved: bool = False
    eval_rc: int = -1
    tokens_in: int = 0
    tokens_out: int = 0
    predict_elapsed: float = 0.0
    eval_elapsed: float = 0.0
    error: str = ""


# ── Helpers ──────────────────────────────────────────────────────────────────

def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(p: Path) -> str:
    import hashlib
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _write_json(p: Path, data: dict) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8", newline="\n",
    )


def _load_env() -> tuple[dict, int]:
    env = os.environ.copy()
    n = 0
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            if "LITELLM" in k.upper() or "API_KEY" in k.upper():
                env[k] = v.strip()
                n += 1
    return env, n


def _run_subprocess(cmd: list[str], cwd: Path, env: dict, timeout: int,
                    stdout_path: Path, stderr_path: Path) -> tuple[int, float]:
    """Run cmd, write stdout/stderr, return (rc, elapsed_sec)."""
    t0 = time.monotonic()
    try:
        proc = subprocess.run(cmd, cwd=str(cwd), env=env,
                             capture_output=True, text=True,
                             timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        elapsed = time.monotonic() - t0
        out = (exc.stdout or b"").decode("utf-8", errors="replace")
        err = (exc.stderr or b"").decode("utf-8", errors="replace")
        stdout_path.write_text(out + "\n[__TIMEOUT__]", encoding="utf-8")
        stderr_path.write_text(err + f"\n[__TIMEOUT__ after {timeout}s]", encoding="utf-8")
        return -1, elapsed
    stdout_path.write_text(proc.stdout, encoding="utf-8")
    stderr_path.write_text(proc.stderr, encoding="utf-8")
    return proc.returncode, time.monotonic() - t0


# ── Docker ────────────────────────────────────────────────────────────────────

def prewarm_image(image: str) -> bool:
    print(f"[docker:prewarm] {image}", flush=True)
    t0 = time.monotonic()
    r = subprocess.run(["docker", "pull", image],
                        capture_output=True, text=True, timeout=300)
    ok = r.returncode == 0
    print(f"[docker:prewarm] {'OK' if ok else 'already-local'} {image} ({time.monotonic()-t0:.0f}s)", flush=True)
    return True  # if pull fails, assume already loaded


def cleanup_image(image: str) -> None:
    if not CLEANUP_AFTER_EVAL:
        return
    repo = image.split("@")[0]
    print(f"[docker:cleanup] {repo}", flush=True)
    for tag in [image, repo]:
        subprocess.run(["docker", "rmi", "-f", tag],
                       capture_output=True, text=True, timeout=60)
    subprocess.run(["docker", "image", "prune", "-f"],
                   capture_output=True, text=True, timeout=30)


# ── Bundle ────────────────────────────────────────────────────────────────────

def setup_bundle(task_id: str, run_id: str) -> Path:
    run_root = ROOT / "experiments" / "runs" / run_id
    for sub in ("logs", "raw", "trace", "evaluation", "billing"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)

    now = utc_now()
    _write_json(run_root / "environment.pre.json", {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "pre", "run_id": run_id,
        "platform": platform.platform(), "architecture": platform.machine(),
        "python": platform.python_version(),
    })

    cfg = json.loads((ROOT / MODEL_CONFIG).read_text(encoding="utf-8"))
    safe_cfg = {k: v for k, v in cfg.items()
                if k not in {"api_key", "token", "password"}}

    task_entry = None
    if DATASET.exists():
        for line in DATASET.read_text(encoding="utf-8", errors="ignore").splitlines():
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
                if obj.get("instance_id") == task_id:
                    task_entry = obj
                    break
            except Exception:
                pass

    base_commit = ("78f471bf655a3137b2e8a75af1501690ec009ec3"
                   if not task_entry else task_entry.get("base_commit",
                   "78f471bf655a3137b2e8a75af1501690ec009ec3"))
    repo_id = (task_entry.get("repo", "astropy/astropy") if task_entry
                else "astropy/astropy")

    _write_json(run_root / "resolved_config.json", {
        "command": [str(ROOT / ".venv" / "Scripts" / "python.exe"),
                     "scripts/cactus_swebench_predict.py", "--task-id", task_id],
        "contract": {},
        "model": safe_cfg,
        "task": {"task_id": task_id, "repo_id": repo_id, "base_commit": base_commit},
        "variant": "cactus_full",
        "evaluator_image": next(t["pinned_image"] for t in TASKS if t["task_id"] == task_id),
    })

    contract_src = ROOT / "experiments" / "contracts" / "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925.json"
    if contract_src.exists():
        shutil.copy2(contract_src, run_root / "contract.json")
        (run_root / "contract.sha256").write_text(
            f"{_sha256(run_root / 'contract.json')}  contract.json\n", encoding="utf-8")

    print(f"[bundle] {run_id} ready for {task_id}", flush=True)
    return run_root


# ── Predict ───────────────────────────────────────────────────────────────────

def run_predict(result: TaskResult) -> None:
    run_root = ROOT / "experiments" / "runs" / result.run_id
    trace_path = run_root / "trace" / "events.jsonl"
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "cactus_swebench_predict.py"),
        "--tasks", str(ROOT / "json" / "cactus_tasks_inference_safe.jsonl"),
        "--task-id", result.task_id,
        "--repo-root", "",
        "--model-config", str(ROOT / MODEL_CONFIG),
        "--trace", str(trace_path),
        "--output", str(pred_path),
        "--budget", "12000",
        "--request-timeout-sec", str(PREDICT_TIMEOUT - 30),
        "--variant", "cactus_full",
    ]
    print(f"[predict:{result.task_id}] cmd --timeout={PREDICT_TIMEOUT}s", flush=True)

    env, n = _load_env()
    print(f"[predict:{result.task_id}] env injected={n}", flush=True)

    rc, elapsed = _run_subprocess(
        cmd, ROOT, env, PREDICT_TIMEOUT,
        logs_dir / "predict.stdout.log",
        logs_dir / "predict.stderr.log",
    )
    result.predict_elapsed = elapsed

    # Extract tokens from events.jsonl
    if trace_path.exists():
        try:
            for ln in trace_path.read_text(encoding="utf-8").splitlines():
                if not ln.strip():
                    continue
                e = json.loads(ln)
                if e.get("type") == "model_call":
                    p = e.get("payload", {})
                    result.tokens_in = p.get("input_tokens", 0)
                    result.tokens_out = p.get("output_tokens", 0)
                    break
        except Exception:
            pass

    if rc == 0 and pred_path.exists():
        result.predict_ok = True
        print(f"[predict:{result.task_id}] OK {result.tokens_in}in/{result.tokens_out}out {elapsed:.0f}s", flush=True)
    else:
        # Capture the actual error from stderr
        err_log = (logs_dir / "predict.stderr.log").read_text("utf-8", errors="replace")
        # Extract the meaningful error line
        lines = [l for l in err_log.splitlines() if l.strip()]
        result.error = lines[-1][:200] if lines else f"rc={rc}"
        print(f"[predict:{result.task_id}] FAIL rc={rc} {result.error}", flush=True)


# ── Eval ──────────────────────────────────────────────────────────────────────

def run_eval(result: TaskResult) -> None:
    run_root = ROOT / "experiments" / "runs" / result.run_id
    pred_path = run_root / "raw" / "prediction.jsonl"
    logs_dir = run_root / "logs"
    eval_dir = run_root / "evaluation"

    cmd = [
        str(ROOT / ".venv" / "Scripts" / "python.exe"), "-u",
        str(ROOT / "scripts" / "swebench_eval_lf.py"),
        str(DATASET),
        "--predictions", str(pred_path),
        "--instance", result.task_id,
        "--pinned-image", result.pinned_image,
        "--run-id", result.run_id,
        "--workers", "1",
        "--timeout", "1800",
        "--report-dir", str(eval_dir),
    ]
    print(f"[eval:{result.task_id}] starting", flush=True)

    env, _ = _load_env()
    rc, elapsed = _run_subprocess(
        cmd, ROOT, env, EVAL_TIMEOUT,
        logs_dir / "evaluate.stdout.log",
        logs_dir / "evaluate.stderr.log",
    )
    result.eval_rc = rc
    result.eval_elapsed = elapsed

    reports = sorted(eval_dir.glob(f"*.{result.run_id}.json"))
    if reports:
        try:
            rep = json.loads(reports[0].read_text(encoding="utf-8"))
            result.eval_resolved = int(rep.get("resolved_instances", 0)) > 0
        except Exception:
            pass

    print(f"[eval:{result.task_id}] rc={rc} resolved={result.eval_resolved} {elapsed:.0f}s", flush=True)


# ── Seal ─────────────────────────────────────────────────────────────────────

def seal_bundle(result: TaskResult) -> None:
    run_root = ROOT / "experiments" / "runs" / result.run_id
    now = utc_now()

    _write_json(run_root / "environment.post.json", {
        "schema_version": "2.0", "capture_mode": "observed",
        "generated_at": now, "phase": "post", "run_id": result.run_id,
        "platform": platform.platform(), "architecture": platform.machine(),
        "python": platform.python_version(),
    })

    trace_path = run_root / "trace" / "events.jsonl"
    cb_hash = None
    if trace_path.exists():
        try:
            for ln in trace_path.read_text(encoding="utf-8").splitlines():
                if not ln.strip():
                    continue
                e = json.loads(ln)
                if e.get("type") == "context_summary":
                    cb_hash = e.get("payload", {}).get("context_bundle_hash")
                    break
        except Exception:
            pass

    _write_json(run_root / "billing" / "litellm_spend.json",
                {"status": "not_requested", "source": "litellm_spend_logs"})

    pred_path = run_root / "raw" / "prediction.jsonl"
    raw = {
        "schema_version": "2.0",
        "run_id": result.run_id,
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "generated_at": now,
        "data": {
            "task_id": result.task_id,
            "repo_id": "astropy/astropy",
            "base_commit": "78f471bf655a3137b2e8a75af1501690ec009ec3",
            "evaluator_exit_code": result.eval_rc,
            "evaluator_valid": result.eval_rc == 0,
            "resolved": result.eval_resolved,
            "input_tokens": result.tokens_in,
            "output_tokens": result.tokens_out,
            "verified_usd_spend": None,
            "wall_clock_seconds": None,
            "selected_file_count": 0,
            "selected_context_tokens": 0,
            "full_context_tokens": 0,
            "selected_context_ratio": 0.0,
            "context_bundle_hash": cb_hash,
            "prediction_hash": _sha256(pred_path) if pred_path.exists() else None,
        },
        "evidence": {
            "origin_type": "measured", "test_scope": "end_to_end",
            "integrity_status": "verified" if result.predict_ok and result.eval_rc == 0 else "incomplete",
            "reproducibility_status": "partial", "statistics_status": "not_required",
        },
    }
    _write_json(run_root / "raw" / "result.json", raw)

    pre = {}
    pre_path = run_root / "environment.pre.json"
    if pre_path.exists():
        pre = json.loads(pre_path.read_text(encoding="utf-8"))

    status = ("completed" if result.eval_resolved
              else "failed" if result.predict_ok else "failed")

    outputs = []
    for item in sorted(run_root.rglob("*")):
        if item.is_file() and item.name != "run_manifest.json":
            outputs.append({
                "path": item.relative_to(run_root).as_posix(),
                "sha256": _sha256(item),
                "media_type": "application/json" if item.suffix == ".json" else "text/plain",
            })

    manifest = {
        "schema_version": "2.0",
        "study_id": "MSCC-RQ1",
        "experiment_id": "EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R4-20260925",
        "campaign_id": f"phase-c1-r4-singletask-20260926T000000Z-{result.task_id}",
        "protocol_phase": "C1_ENGINEERING",
        "protocol_version": "2.0",
        "historical_trace_inputs": [],
        "variant_id": "cactus_full",
        "task_id": result.task_id,
        "attempt_index": 0,
        "parent_attempt_id": None,
        "retry_reason": None,
        "run_id": result.run_id,
        "status": status,
        "started_at": pre.get("generated_at", now),
        "finished_at": now,
        "command": [str(ROOT / ".venv" / "Scripts" / "python.exe"),
                     "scripts/cactus_swebench_predict.py", "--task-id", result.task_id],
        "environment": {
            "capture_mode": "observed",
            "pre_path": "environment.pre.json",
            "pre_sha256": _sha256(pre_path) if pre_path.exists() else None,
            "post_path": "environment.post.json",
            "post_sha256": _sha256(run_root / "environment.post.json"),
        },
        "configuration": {
            "path": "resolved_config.json",
            "sha256": (_sha256(run_root / "resolved_config.json")
                      if (run_root / "resolved_config.json").exists() else None),
        },
        "code": {"commit": TRUSTED_COMMIT, "dirty": False, "patch_sha256": None},
        "outputs": outputs,
        "context_bundle_hash": cb_hash,
        "prediction_hash": _sha256(pred_path) if pred_path.exists() else None,
        "evaluator_status": "validated" if result.eval_rc == 0 else "not_validated",
        "purpose": "engineering_validation",
        "publishable_result": False,
        "error": result.error or None,
        "paired_c1": None,
    }
    _write_json(run_root / "run_manifest.json", manifest)

    sys.path.insert(0, str(ROOT / "src"))
    from cactus.trace.bundle import RunBundle
    RunBundle(run_root).seal()
    print(f"[seal:{result.task_id}] sealed status={status}", flush=True)


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> int:
    now = utc_now()
    ts = now.replace(":", "").replace("-", "")[:15]  # "20260926T070000Z"
    short_ts = ts[2:]  # "260926T070000Z" for shorter run IDs

    print(f"\n{'='*60}", flush=True)
    print(f"[{now}] R4 v2 Pipeline — {len(TASKS)} tasks", flush=True)
    print(f"{'='*60}", flush=True)

    # Phase 0: Pre-warm Docker images in parallel
    print(f"\n[Phase 0] Pre-warming {len(TASKS)} Docker images ...", flush=True)
    all_images = [t["pinned_image"] for t in TASKS]
    with ThreadPoolExecutor(max_workers=PREWARM_WORKERS) as ex:
        futs = {ex.submit(prewarm_image, img): img for img in all_images}
        for f in as_completed(futs):
            img = futs[f]
            try:
                ok = f.result()
                print(f"  {'✅' if ok else '❌'} {img}", flush=True)
            except Exception as exc:
                print(f"  ❌ {img}: {exc}", flush=True)

    # Phase 1: Setup bundles with UNIQUE run IDs (UUID-based)
    results: list[TaskResult] = []
    for cfg in TASKS:
        task_id = cfg["task_id"]
        uid = uuid.uuid4().hex[:8].upper()   # 8-char unique suffix
        run_id = f"RUN-{ts}Z-{uid}"
        run_root = setup_bundle(task_id, run_id)
        results.append(TaskResult(
            task_id=task_id,
            run_id=run_id,
            pinned_image=cfg["pinned_image"],
        ))

    # Phase 2: Run all predicts concurrently
    print(f"\n[Phase 1] Predict — running {len(results)} tasks concurrently", flush=True)
    with ThreadPoolExecutor(max_workers=PREDICT_WORKERS) as ex:
        futs = {ex.submit(run_predict, r): r for r in results}
        for f in as_completed(futs):
            r = futs[f]
            try:
                f.result()
            except Exception as exc:
                r.error = str(exc)
                print(f"[predict:{r.task_id}] EXCEPTION: {exc}", flush=True)

    print("\n[Phase 1] Predict summary:", flush=True)
    for r in results:
        icon = "✅" if r.predict_ok else "❌"
        print(f"  {icon} {r.task_id}: {r.error or 'OK'} "
              f"({r.tokens_in}in/{r.tokens_out}out {r.predict_elapsed:.0f}s)", flush=True)

    # Phase 3: Eval — sequential; cleanup Docker image after each
    print(f"\n[Phase 2] Eval — sequential with cleanup", flush=True)
    for r in results:
        if not r.predict_ok:
            print(f"[eval:{r.task_id}] skipping (predict failed)", flush=True)
            _write_json(
                ROOT / "experiments" / "runs" / r.run_id / "evaluation"
                / f"deepseek-coding.{r.run_id}.json",
                {"total_instances": 0, "resolved_instances": 0, "error": r.error},
            )
            seal_bundle(r)
            if CLEANUP_AFTER_EVAL:
                cleanup_image(r.pinned_image)
            continue

        run_eval(r)
        seal_bundle(r)
        if CLEANUP_AFTER_EVAL:
            cleanup_image(r.pinned_image)

    # Summary
    total = len(results)
    n_ok = sum(1 for r in results if r.eval_resolved)
    print(f"\n{'='*60}", flush=True)
    print(f"[{utc_now()}] FINAL: {n_ok}/{total} resolved", flush=True)
    for r in results:
        icon = "✅" if r.eval_resolved else "❌"
        print(f"  {icon} {r.task_id}: pred={'OK' if r.predict_ok else 'FAIL'} "
              f"eval={'PASS' if r.eval_resolved else 'FAIL'} "
              f"pred={r.predict_elapsed:.0f}s eval={r.eval_elapsed:.0f}s", flush=True)
    print(f"{'='*60}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
