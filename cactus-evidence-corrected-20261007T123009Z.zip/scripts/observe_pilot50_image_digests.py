"""Observe complete Docker RepoDigests for the planning-only 50-task Pilot."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PLAN = ROOT / "artifacts" / "phase_c_pilot50_plan.json"
DEFAULT_OUTPUT = ROOT / "artifacts" / "pilot50_image_digest_observation.json"
_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _inspect_repo_digests(image_ref: str) -> tuple[list[str], str | None]:
    result = subprocess.run(
        ["docker", "image", "inspect", image_ref],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        detail = (result.stderr or result.stdout).strip().splitlines()
        return [], detail[-1] if detail else "docker image inspect failed"
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        return [], f"invalid docker inspect JSON: {exc}"
    digests: set[str] = set()
    for image in payload if isinstance(payload, list) else []:
        if not isinstance(image, dict):
            continue
        for repo_digest in image.get("RepoDigests", []):
            if isinstance(repo_digest, str) and "@" in repo_digest:
                digest = repo_digest.rsplit("@", 1)[1]
                if _IMAGE_DIGEST.fullmatch(digest):
                    digests.add(digest)
    return sorted(digests), None


def observe(plan_path: Path = DEFAULT_PLAN, output: Path = DEFAULT_OUTPUT) -> dict[str, Any]:
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes.decode("utf-8"))
    planned_images = plan.get("evaluator_images") if isinstance(plan, dict) else None
    if not isinstance(planned_images, list) or not planned_images:
        raise ValueError("pilot50 plan has no evaluator_images")

    observations: list[dict[str, Any]] = []
    all_available = True
    for item in planned_images:
        if not isinstance(item, dict) or not str(item.get("image", "")):
            raise ValueError("every evaluator image must have a non-empty image reference")
        image_ref = str(item["image"])
        digests, error = _inspect_repo_digests(image_ref)
        candidate = digests[0] if len(digests) == 1 else None
        all_available = all_available and candidate is not None
        repository = image_ref.rsplit(":", 1)[0] if ":" in image_ref.rsplit("/", 1)[-1] else image_ref
        observations.append(
            {
                "image_ref": image_ref,
                "repository": repository,
                "repo_digests": digests,
                "candidate_digest": candidate,
                "status": "OBSERVED" if candidate else "MISSING_OR_AMBIGUOUS",
                **({"inspect_error": error} if error else {}),
            }
        )

    observed_at = _utc_now()
    result = {
        "schema_version": "1.0",
        "observed_at": observed_at,
        "status": "READY_FOR_CONTRACT_CANDIDATE" if all_available else "BLOCKED_MISSING_IMAGE_DIGEST",
        "source_plan": plan_path.as_posix(),
        "source_plan_sha256": hashlib.sha256(plan_bytes).hexdigest(),
        "planned_task_count": plan.get("task_count"),
        "planned_image_count": len(planned_images),
        "observed_image_count": sum(item["candidate_digest"] is not None for item in observations),
        "execution_performed": False,
        "approval_marker_created": False,
        "images": observations,
        "next_action": (
            "Generate an unapproved 50-task contract candidate from these complete digests; review and session-confirm it before formal preflight."
            if all_available
            else "Pull or otherwise materialize every missing evaluator image, then rerun this observation."
        ),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, default=DEFAULT_PLAN)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    result = observe(args.plan, args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "READY_FOR_CONTRACT_CANDIDATE" else 2


if __name__ == "__main__":
    raise SystemExit(main())
