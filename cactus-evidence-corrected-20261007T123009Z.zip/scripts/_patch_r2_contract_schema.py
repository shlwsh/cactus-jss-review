"""Patch R2 contract to satisfy validate_contract schema (study_id, result_ids, workload.*)."""

import hashlib
import json
from pathlib import Path

CONTRACT_PATH = Path(
    "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V23-C1-R2-20260925.json"
)
AUTH_PATH = CONTRACT_PATH.with_name(CONTRACT_PATH.stem + ".session_authorization.json")
SHA_SIDECAR = CONTRACT_PATH.with_suffix(".sha256")

# predict_bridge SHA after R1 path-filter fix (1609-1653)
PREDICT_BRIDGE_SHA = "9bbbb23b3204c2feda1d545ce7879f7ed14f3a3fda20a24fdb7f52eab628bb8b"


def main() -> int:
    data = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))

    # ---- study_id ----
    data["study_id"] = "MSCC-RQ1"

    # ---- result_ids: empty for engineering_validation ----
    data["result_ids"] = []

    # ---- workload: synthesize from existing fields ----
    # current workload has task_manifest fields (pair_plan_path, task_manifest_sha256, etc.)
    workload = data.get("workload", {})
    workload["driver"] = "scripts/cactus_swebench_predict.py"
    workload["sha256"] = PREDICT_BRIDGE_SHA
    workload["measure_sec"] = 180
    workload["seed"] = 20260925
    workload["repetitions"] = 1  # R2 = 1 rep per task for engineering_validation
    workload["inference_safe"] = True
    workload["repository_cache_root_env"] = "CACTUS_REPO_CACHE_ROOT"
    workload["benchmark_root_env"] = "CACTUS_SWEBENCH_ROOT"
    workload["image_cache_root_env"] = "CACTUS_DOCKER_CACHE_ROOT"
    # task_manifest is already populated
    data["workload"] = workload

    # ---- images._note → move to a non-iterated sibling (images._note is not an image) ----
    images = data.get("images", {})
    if "_note" in images:
        note = images.pop("_note")
        data["_images_note"] = note

    # ---- write back ----
    out_bytes = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    tmp = CONTRACT_PATH.with_suffix(".json.tmp")
    tmp.write_bytes(out_bytes)
    tmp.replace(CONTRACT_PATH)
    final_sha = hashlib.sha256(out_bytes).hexdigest()
    SHA_SIDECAR.write_text(f"{final_sha}  {CONTRACT_PATH.name}\n", encoding="utf-8")

    # ---- update compose_sha256 inside contract to file body SHA ----
    data["runtime"]["compose_sha256"] = final_sha
    out_bytes = json.dumps(
        data, ensure_ascii=False, sort_keys=True, indent=2
    ).encode("utf-8") + b"\n"
    tmp = CONTRACT_PATH.with_suffix(".json.tmp")
    tmp.write_bytes(out_bytes)
    final_sha = hashlib.sha256(out_bytes).hexdigest()
    tmp.replace(CONTRACT_PATH)
    SHA_SIDECAR.write_text(f"{final_sha}  {CONTRACT_PATH.name}\n", encoding="utf-8")

    # ---- update session_authorization linked_contract_sha256 ----
    if AUTH_PATH.is_file():
        auth = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        auth["_metadata"]["linked_contract_sha256"] = final_sha
        auth_bytes = json.dumps(
            auth, ensure_ascii=False, sort_keys=True, indent=2
        ).encode("utf-8") + b"\n"
        auth_tmp = AUTH_PATH.with_suffix(".json.tmp")
        auth_tmp.write_bytes(auth_bytes)
        auth_tmp.replace(AUTH_PATH)

    # ---- verify ----
    from cactus.governance.contract import validate_contract
    reloaded = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    errs = validate_contract(reloaded)
    print(f"validate_contract errors after patch: {errs}")
    print(f"contract SHA-256: {final_sha}")
    print(f"workload.driver : {reloaded['workload']['driver']}")
    print(f"workload.sha256 : {reloaded['workload']['sha256']}")
    print(f"study_id        : {reloaded['study_id']}")
    print(f"result_ids      : {reloaded['result_ids']}")
    return 0 if not errs else 2


if __name__ == "__main__":
    raise SystemExit(main())