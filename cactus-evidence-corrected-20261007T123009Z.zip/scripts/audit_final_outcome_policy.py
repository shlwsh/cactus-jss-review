#!/usr/bin/env python3
"""Audit immutable RUN manifests for deterministic, non-best-attempt selection."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
FORMAL_EXPERIMENT = "EXP-CACTUS-SWEBENCH-VERIFIED-V2"
MAX_REPORTED_ERRORS = 25
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


def _truth(value: object) -> bool:
    return value is True or str(value).strip().lower() in {"1", "true", "yes"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sealed_identity_documents(run_dir: Path, manifest_path: Path, record: dict[str, Any]) -> tuple[dict[str, Any] | None, dict[str, Any] | None, str | None]:
    """Load identity sources only when the manifest and both seal layers agree."""
    checksum_path = run_dir / "checksums.sha256"
    try:
        checksum_rows: dict[str, str] = {}
        for line in checksum_path.read_text(encoding="utf-8").splitlines():
            digest, separator, relative = line.partition("  ")
            if not separator or not _SHA256.fullmatch(digest):
                return None, None, "invalid checksums.sha256 format"
            checksum_rows[relative] = digest
    except OSError:
        return None, None, "checksums.sha256 is missing or unreadable"

    manifest_digest = checksum_rows.get("run_manifest.json")
    if manifest_digest is None or _sha256(manifest_path) != manifest_digest:
        return None, None, "run_manifest.json is not anchored by checksums.sha256"

    outputs = record.get("outputs")
    if not isinstance(outputs, list):
        return None, None, "manifest output hashes are missing"
    output_hashes = {
        item.get("path"): item.get("sha256")
        for item in outputs
        if isinstance(item, dict) and isinstance(item.get("path"), str)
    }
    documents: dict[str, dict[str, Any]] = {}
    for relative in ("raw/result.json", "resolved_config.json"):
        expected = output_hashes.get(relative)
        checksum = checksum_rows.get(relative)
        relative_path = Path(relative)
        if (
            not isinstance(expected, str)
            or not _SHA256.fullmatch(expected)
            or checksum != expected
            or relative_path.is_absolute()
            or ".." in relative_path.parts
        ):
            return None, None, f"{relative} is not sealed by both output hash lists"
        source = (run_dir / relative_path).resolve()
        if run_dir.resolve() not in source.parents or not source.is_file() or _sha256(source) != expected:
            return None, None, f"{relative} hash does not match its sealed digest"
        try:
            document = json.loads(source.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None, None, f"{relative} is not valid JSON"
        if not isinstance(document, dict):
            return None, None, f"{relative} is not a JSON object"
        documents[relative] = document
    return documents["raw/result.json"], documents["resolved_config.json"], None


def _resolve_identity(record: dict[str, Any], run_dir: Path, manifest_path: Path) -> tuple[str, str, str | None]:
    task_id = str(record.get("task_id") or "")
    variant = str(record.get("variant_id") or record.get("variant") or "")
    if task_id and variant:
        return task_id, variant, None

    result, config, seal_error = _sealed_identity_documents(run_dir, manifest_path, record)
    if seal_error or result is None or config is None:
        return task_id, variant, seal_error or "sealed identity documents are unavailable"
    raw_data = result.get("data")
    raw_task = raw_data.get("task_id") if isinstance(raw_data, dict) else None
    config_task_data = config.get("task")
    config_task = config_task_data.get("task_id") if isinstance(config_task_data, dict) else None
    config_variant = config.get("variant")
    task_candidates = {str(value) for value in (task_id, raw_task, config_task) if isinstance(value, str) and value}
    variant_candidates = {str(value) for value in (variant, config_variant) if isinstance(value, str) and value}
    if len(task_candidates) > 1 or len(variant_candidates) > 1:
        return task_id, variant, "sealed task/variant identity conflicts across RUN evidence"
    return (
        next(iter(task_candidates), task_id),
        next(iter(variant_candidates), variant),
        None,
    )


def audit(runs_root: Path = ROOT / "experiments/runs") -> dict[str, Any]:
    by_task: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    errors: list[str] = []
    manifests = 0
    identities_recovered = 0
    for path in sorted(runs_root.glob("RUN-*/run_manifest.json")):
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"{path}: unreadable manifest ({exc})")
            continue
        manifests += 1
        if not isinstance(record, dict) or record.get("experiment_id") != FORMAL_EXPERIMENT:
            continue
        task_id, variant, identity_error = _resolve_identity(record, path.parent, path)
        if not task_id or not variant:
            detail = f" ({identity_error})" if identity_error else ""
            errors.append(f"{path}: in-scope record lacks task_id or variant{detail}")
            continue
        if not (record.get("task_id") and (record.get("variant_id") or record.get("variant"))):
            identities_recovered += 1
        record["task_id"] = task_id
        record["variant_id"] = variant
        record["_path"] = path.as_posix()
        by_task[(variant, task_id)].append(record)

    checked_chains = 0
    for (variant, task_id), attempts in sorted(by_task.items()):
        checked_chains += 1
        try:
            attempts.sort(key=lambda row: (int(row.get("attempt_index", 0)), str(row.get("started_at", "")), str(row.get("run_id", ""))))
            indexes = [int(row.get("attempt_index", 0)) for row in attempts]
        except (TypeError, ValueError):
            errors.append(f"{variant}/{task_id}: invalid attempt_index")
            continue
        if len(indexes) != len(set(indexes)):
            errors.append(f"{variant}/{task_id}: duplicate attempt_index")
        if indexes != list(range(len(indexes))):
            errors.append(f"{variant}/{task_id}: attempt indexes are not contiguous from zero")
        for position, row in enumerate(attempts):
            if position == 0:
                if row.get("parent_attempt_id") not in (None, ""):
                    errors.append(f"{variant}/{task_id}: first attempt unexpectedly has a parent")
                continue
            prior = attempts[position - 1]
            if not row.get("parent_attempt_id"):
                errors.append(f"{variant}/{task_id}: retry has no parent pointer")
            elif row.get("parent_attempt_id") != prior.get("run_id"):
                errors.append(f"{variant}/{task_id}: retry parent does not identify preceding attempt")
            if not row.get("retry_reason"):
                errors.append(f"{variant}/{task_id}: retry has no reason")
            if _truth(prior.get("evaluator_valid")):
                errors.append(f"{variant}/{task_id}: algorithm retry followed a terminal valid evaluator state")
            if row.get("retry_authorized") is not True:
                errors.append(f"{variant}/{task_id}: retry lacks explicit authorization")
        terminal = attempts[-1]
        if terminal.get("final_outcome_selected_by") in {"best", "best_resolved", "best_score", "lowest_cost"}:
            errors.append(f"{variant}/{task_id}: best-result selection is forbidden")

    error_counts: dict[str, int] = defaultdict(int)
    for error in errors:
        error_counts[error.split(": ", 1)[-1]] += 1
    return {
        "status": "fail" if errors else "pass",
        "scope_experiment_id": FORMAL_EXPERIMENT,
        "run_manifests_seen": manifests,
        "task_variant_chains_checked": checked_chains,
        "identities_recovered_from_sealed_outputs": identities_recovered,
        "error_count": len(errors),
        "error_categories": dict(sorted(error_counts.items())),
        "errors": errors[:MAX_REPORTED_ERRORS],
        "errors_truncated": max(0, len(errors) - MAX_REPORTED_ERRORS),
        "selection_rule": "select a terminal record only from a chain whose identity, order, parent links, retry reason, and authorization validate; invalid historical chains are not publication-eligible; current retry caps are not applied retroactively",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=ROOT / "experiments/runs")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit(args.runs)
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 2 if args.strict and result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
