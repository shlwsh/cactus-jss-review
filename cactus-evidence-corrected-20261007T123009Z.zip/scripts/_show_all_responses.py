"""Show all model responses across all R4 RUNs to spot patterns."""
import json
from pathlib import Path

RUNS = [
    "RUN-20260925T105655Z-4B606E26",
    "RUN-20260925T111245Z-ED516428",
    "RUN-20260925T113558Z-0D213BFD",
    "RUN-20260925T120939Z-9F868CEF",
    "RUN-20260925T122119Z-500AC775",
    "RUN-20260925T122938Z-66CC37F3",
    "RUN-20260925T124001Z-5F41C11D",
    "RUN-20260925T124946Z-31DC4349",
]

print("=" * 80)
print("ALL MODEL RESPONSES — R4 RUNS (chronological)")
print("=" * 80)

for rid in RUNS:
    path = Path(f"experiments/runs/{rid}/trace/events.jsonl")
    if not path.exists():
        continue
    events = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    mcalls = [e for e in events if e.get("type") == "model_call"]
    rejects = [e for e in events if e.get("type") == "prediction_rejected"]
    if not mcalls:
        continue
    print(f"\n[{rid}]")
    for j, mc in enumerate(mcalls):
        p = mc["payload"]
        resp = p.get("response_text", "")
        rj = rejects[j]["payload"] if j < len(rejects) else {}
        print(f"\n  attempt #{j+1}: finish_reason={p.get('finish_reason')}, in_tok={p.get('input_tokens')}, out_tok={p.get('output_tokens')}")
        print(f"  response_text ({len(resp)} chars): {resp[:600]}")
        print(f"  reject: class={rj.get('reason_class')}, reason={rj.get('reason')}")
