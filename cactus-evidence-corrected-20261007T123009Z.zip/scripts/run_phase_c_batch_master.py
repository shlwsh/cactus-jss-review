#!/usr/bin/env python3
"""Phase C Master Batch Runner with real-time logging, error resilience, and progress tracking."""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from cactus.runner.bundle_validator import validate_bundle

REPO = Path(__file__).resolve().parents[1]
CONTRACT = REPO / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V2-OWNER-20260922.json"
APPROVAL = REPO / "experiments/contracts/EXP-CACTUS-SWEBENCH-VERIFIED-V2-OWNER-20260922.session_authorization.json"
TASK_MANIFEST = REPO / "json/cactus_tasks_inference_safe.jsonl"
MODEL_CONFIG = REPO / "configs/models/litellm_local.json"
RUNNER = REPO / "scripts/run_swebench_campaign.py"
OUTPUT_ROOT = REPO / "experiments/runs"
REPO_CACHE = REPO / "experiments/repo_cache"
PROGRESS_FILE = REPO / "analysis/phase_c_progress.jsonl"

LOCAL_DATASET = Path("E:/cactus-data/swebench/verified/78f471bf655a3137b2e8a75af1501690ec009ec3/cactus_tasks_eval_augmented.jsonl")
DATASET = str(LOCAL_DATASET) if LOCAL_DATASET.exists() else "SWE-bench/SWE-bench_Verified"

# Ensure PYTHONPATH in environment
src_path = str(REPO / "src")
if src_path not in sys.path:
    sys.path.insert(0, src_path)
os.environ["PYTHONPATH"] = f"{src_path};{REPO};" + os.environ.get("PYTHONPATH", "")

def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def log_progress(entry: dict) -> None:
    PROGRESS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with PROGRESS_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

def get_already_completed_tasks(
    campaign_id: str,
    variant_id: str,
    progress_file: Path = PROGRESS_FILE,
    runs_root: Path = OUTPUT_ROOT,
) -> set[str]:
    """Return only tasks backed by a sealed RUN for this campaign/variant."""
    completed = set()
    if not progress_file.exists():
        return completed
    for line in progress_file.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            d = json.loads(line)
            if not (
                d.get("status") == "completed"
                and d.get("campaign_id") == campaign_id
                and d.get("variant_id", d.get("variant")) == variant_id
                and d.get("task_id")
                and re.fullmatch(r"RUN-\d{8}T\d{6}Z-[0-9A-F]{6,8}", str(d.get("run_id", "")))
            ):
                continue
            run_dir = runs_root / d["run_id"]
            manifest_path = run_dir / "run_manifest.json"
            if not run_dir.is_dir() or not manifest_path.is_file():
                continue
            if validate_bundle(run_dir):
                continue
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            identity = (manifest.get("campaign_id"), manifest.get("variant_id"), manifest.get("task_id"), manifest.get("status"))
            if identity == (campaign_id, variant_id, d["task_id"], "completed"):
                completed.add(d["task_id"])
        except Exception:
            continue
    return completed

def run_single_task(task_id: str, variant: str, campaign_id: str) -> dict:
    started_ts = utc_now()
    t0 = time.monotonic()
    existing_run_ids = {path.name for path in OUTPUT_ROOT.glob("RUN-*") if path.is_dir()}
    cmd = [
        sys.executable, str(RUNNER),
        "--contract", str(CONTRACT),
        "--approval", str(APPROVAL),
        "--model-config", str(MODEL_CONFIG),
        "--tasks", str(TASK_MANIFEST),
        "--output-root", str(OUTPUT_ROOT),
        "--repo-cache", str(REPO_CACHE),
        "--evaluator-dataset", DATASET,
        "--project-root", str(REPO),
        "--task-id", task_id,
        "--variant", variant,
        "--campaign-id", campaign_id,
    ]
    
    print(f"\n[PHASE-C][{started_ts}] >>> STARTING TASK: {task_id} (variant={variant}) <<<", flush=True)
    res = subprocess.run(cmd, cwd=REPO, env=os.environ.copy())
    elapsed = round(time.monotonic() - t0, 1)
    
    # Only accept a new, exact identity match from this invocation.
    latest_runs = sorted(
        (path for path in OUTPUT_ROOT.glob("RUN-*") if path.is_dir() and path.name not in existing_run_ids),
        key=lambda p: p.stat().st_mtime,
    )
    run_id = ""
    eval_resolved = False
    eval_status = "unknown"
    empty_patch = False
    
    for rdir in reversed(latest_runs):
        mfile = rdir / "run_manifest.json"
        if not mfile.exists():
            continue
        try:
            mdata = json.loads(mfile.read_text(encoding="utf-8"))
        except Exception:
            continue
        if (
            mdata.get("campaign_id") == campaign_id
            and mdata.get("variant_id") == variant
            and mdata.get("task_id") == task_id
        ):
            run_id = rdir.name
            
            # Read eval report if present
            eval_dir = rdir / "evaluation"
            for ef in eval_dir.glob("*.json"):
                try:
                    edata = json.loads(ef.read_text(encoding="utf-8"))
                    eval_resolved = edata.get("resolved_instances", 0) > 0 or task_id in edata.get("resolved_ids", [])
                    empty_patch = edata.get("empty_patch_instances", 0) > 0 or task_id in edata.get("empty_patch_ids", [])
                    eval_status = "resolved" if eval_resolved else ("empty_patch" if empty_patch else "unresolved")
                except Exception:
                    pass
            break

    success = (res.returncode == 0 and bool(run_id))
    entry = {
        "timestamp": utc_now(),
        "campaign_id": campaign_id,
        "task_id": task_id,
        "variant": variant,
        "variant_id": variant,
        "run_id": run_id,
        "exit_code": res.returncode,
        "status": "completed" if success else "failed",
        "eval_status": eval_status,
        "eval_resolved": eval_resolved,
        "elapsed_sec": elapsed
    }
    log_progress(entry)
    print(f"[PHASE-C] FINISHED TASK: {task_id} -> status={entry['status']}, eval={eval_status}, run_id={run_id}, elapsed={elapsed}s", flush=True)
    return entry

def main() -> int:
    parser = argparse.ArgumentParser(description="Phase C Master Batch Runner")
    parser.add_argument("--repo-id", help="Filter tasks by repo_id (e.g. astropy/astropy)")
    parser.add_argument("--limit", type=int, help="Limit number of tasks to run in this batch")
    parser.add_argument("--variant", default="cactus_full", choices=("maximal_context", "lexical_bm25", "cactus_full", "cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density"))
    parser.add_argument("--campaign-id", required=True, help="Unique, preregistered identity shared by matched variants")
    parser.add_argument("--tasks", nargs="*", help="Specific task_ids to run")
    parser.add_argument("--plan-only", action="store_true", help="Show task selection and resume exclusions without running model/evaluator")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", args.campaign_id):
        parser.error("--campaign-id must be 1-128 ASCII letters, digits, '.', '_' or '-'")

    # Load tasks
    all_tasks = [json.loads(line) for line in TASK_MANIFEST.read_text(encoding="utf-8").splitlines() if line.strip()]
    if args.tasks:
        target_tasks = [t for t in all_tasks if t["task_id"] in args.tasks]
        found = {t["task_id"] for t in target_tasks}
        missing = sorted(set(args.tasks) - found)
        if missing:
            parser.error("unknown task id(s): " + ", ".join(missing))
    elif args.repo_id:
        target_tasks = [t for t in all_tasks if t["repo_id"] == args.repo_id]
    else:
        target_tasks = all_tasks

    already_done = get_already_completed_tasks(args.campaign_id, args.variant)
    todo_tasks = [t for t in target_tasks if t["task_id"] not in already_done]
    
    if args.limit is not None:
        if args.limit < 1:
            parser.error("--limit must be a positive integer")
        todo_tasks = todo_tasks[:args.limit]

    print(f"==================================================")
    print(f"PHASE C BATCH MASTER: {len(todo_tasks)} tasks to execute (already done for this variant: {len(already_done)})")
    print(f"Campaign ID: {args.campaign_id}")
    print(f"Variant: {args.variant}")
    print(f"==================================================")

    if args.plan_only:
        print("[PLAN-ONLY] no model, evaluator, image, or RUN bundle was started")
        return 0
    if not todo_tasks:
        print("[NO-WORK] this exact campaign/variant already has completed records")
        return 0

    results = []
    for i, t in enumerate(todo_tasks, 1):
        tid = t["task_id"]
        print(f"\n[{i}/{len(todo_tasks)}] Processing {tid} ({t.get('repo_id', '')})...")
        try:
            res = run_single_task(tid, variant=args.variant, campaign_id=args.campaign_id)
            results.append(res)
        except Exception as e:
            print(f"[ERROR] Task {tid} raised unhandled exception: {e}", flush=True)
            failure = {
                "timestamp": utc_now(),
                "campaign_id": args.campaign_id,
                "task_id": tid,
                "variant": args.variant,
                "variant_id": args.variant,
                "status": "exception",
                "error": str(e)
            }
            log_progress(failure)
            results.append(failure)

    # Summary
    success_count = sum(1 for r in results if r.get("status") == "completed")
    resolved_count = sum(1 for r in results if r.get("eval_resolved", False))
    print("\n" + "=" * 50)
    print(f"PHASE C BATCH SUMMARY: {success_count}/{len(todo_tasks)} completed, {resolved_count} resolved")
    print("=" * 50)
    return 0 if success_count == len(results) else 1

if __name__ == "__main__":
    sys.exit(main())
