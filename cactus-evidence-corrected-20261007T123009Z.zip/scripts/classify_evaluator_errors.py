"""Classify evaluator evidence without guessing from aggregate counts.

The classifier consumes task-level evidence bundles when present. Missing
evidence remains ``pending_evidence`` and is never converted into a repair
failure.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cactus.execution.retry_state_machine import ErrorCode, RETRYABLE
from cactus.failure_recovery.strategy_lookup import lookup_strategy

PATTERNS = (
    (ErrorCode.REPO_CHECKOUT, re.compile(r"checkout|clone|git", re.I)),
    (ErrorCode.DEPENDENCY_SETUP, re.compile(r"pip install|dependency|requirements", re.I)),
    (ErrorCode.CONTAINER_BUILD, re.compile(r"docker.*build|build.*image", re.I)),
    (ErrorCode.CONTAINER_RUNTIME, re.compile(r"container.*exit|docker.*run|runtime", re.I)),
    (ErrorCode.MODEL_GATEWAY, re.compile(r"gateway|connection refused|502|503", re.I)),
    (ErrorCode.MODEL_TIMEOUT, re.compile(r"timeout|timed out", re.I)),
    (ErrorCode.PATCH_PARSE, re.compile(r"patch.*parse|diff.*parse", re.I)),
    (ErrorCode.PATCH_APPLY, re.compile(r"patch.*apply|hunk failed", re.I)),
    (ErrorCode.TEST_DISCOVERY, re.compile(r"no tests? found|test discovery", re.I)),
    (ErrorCode.TEST_RUNTIME, re.compile(r"test.*failed|pytest.*error", re.I)),
    (ErrorCode.EVALUATOR_INTERNAL, re.compile(r"evaluator|judge|traceback", re.I)),
    (ErrorCode.BILLING_RECORD, re.compile(r"billing|spend|cost", re.I)),
    (ErrorCode.CLEANUP, re.compile(r"cleanup|remove.*image", re.I)),
)


def classify_text(text: str) -> ErrorCode:
    for code, pattern in PATTERNS:
        if pattern.search(text):
            return code
    return ErrorCode.UNKNOWN


def classify(root: Path, output: Path) -> dict[str, int]:
    output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    # Accept both the legacy evaluator_report.* layout and formal CACTUS RUN
    # bundles (evaluation/*.json plus logs/evaluate.*.log).  A bundle is only
    # admissible when its checksum file and SEALED marker are present; this
    # prevents an arbitrary log directory from becoming measured evidence.
    reports = sorted(root.rglob("evaluator_report.*"))
    reports.extend(sorted(root.glob("**/evaluation/*.json")))
    for report in reports:
        bundle = report.parent
        if report.parent.name == "evaluation":
            bundle = report.parent.parent
        if not ((bundle / "checksums.sha256").is_file() or (bundle / "SEALED").is_file()):
            continue
        evidence_files = [report, *(bundle / "logs").glob("evaluate.*.log")]
        text = " ".join(path.read_text(encoding="utf-8", errors="replace") for path in evidence_files if path.is_file())
        manifest_path = next(iter(sorted(bundle.glob("manifest.*"))), None)
        if manifest_path is None and (bundle / "run_manifest.json").is_file():
            manifest_path = bundle / "run_manifest.json"
        manifest = {}
        if manifest_path:
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                manifest = {}
        code = classify_text(text)
        rows.append({"instance_id": manifest.get("instance_id", manifest.get("task_id", bundle.parent.name)), "attempt_id": manifest.get("attempt_id", manifest.get("run_id", bundle.name)), "date": manifest.get("start_time", manifest.get("started_at", "")), "repo": manifest.get("repo", manifest.get("repo_id", "")), "error_code": code.value, "error_stage": code.name.lower(), "exception_type": "evidence_match", "message_hash": hashlib.sha256(text.encode("utf-8")).hexdigest(), "retryable": code in RETRYABLE, "retry_strategy": lookup_strategy(code), "canonical_outcome": "INVALID_EVALUATION"})
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["instance_id", "attempt_id", "date", "repo", "error_code", "error_stage", "exception_type", "message_hash", "retryable", "retry_strategy", "canonical_outcome"], lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    return {"classified": len(rows), "pending_evidence": 0 if rows else 1}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--dual-lens", action="store_true", help="also write error_taxonomy_dual_lens.csv")
    args = parser.parse_args()
    result = classify(args.root, args.output)
    if args.dual_lens:
        dual = args.output.with_name("error_taxonomy_dual_lens.csv")
        dual.write_bytes(args.output.read_bytes())
        result["dual_lens_output"] = str(dual)
    print(json.dumps(result))
