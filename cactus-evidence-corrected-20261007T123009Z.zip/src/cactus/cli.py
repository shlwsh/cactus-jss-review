"""Local, side-effect-free P0 validation entry point."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from cactus.governance.schema import (
    validate_approval_marker,
    validate_environment_snapshot,
    validate_raw_result,
    validate_run_manifest,
)
from cactus.governance.session_auth import (
    confirm_authorization,
    get_authorization_path,
    has_valid_authorization,
    preview_authorization_request,
)
from cactus.analysis.report import build_report
from cactus.analysis.artifact import write_result_table
from cactus.evaluation.derive import derive_stats
from cactus.evaluation.gold import evaluate_gold
from cactus.runner.bundle_validator import validate_bundle
from cactus.runner.loop import OfflineAgentLoop
from cactus.runner.formal import formal_execution_errors
from cactus.runner.matrix import expand_matrix
from cactus.runner.readiness import audit_readiness
from cactus.trace.replay import replay
from cactus.trace.store import TraceStore


def main() -> int:
    parser = argparse.ArgumentParser(prog="cactus")
    subcommands = parser.add_subparsers(dest="command", required=True)
    subcommands.add_parser("validate-schemas", help="validate bundled schema JSON syntax")
    validate = subcommands.add_parser("validate", help="validate one P0 evidence JSON file")
    validate.add_argument("kind", choices=("manifest", "environment", "raw", "approval", "bundle"))
    validate.add_argument("path", type=Path)
    report = subcommands.add_parser("report", help="build a deterministic trace report")
    report.add_argument("events", type=Path)
    report.add_argument("output", type=Path)
    report.add_argument("run_id")
    replay_cmd = subcommands.add_parser("replay", help="replay trace events without network")
    replay_cmd.add_argument("events", type=Path)
    replay_cmd.add_argument("run_id")
    evaluate = subcommands.add_parser("evaluate", help="derive stats from one raw JSON")
    evaluate.add_argument("raw", type=Path)
    evaluate.add_argument("output", type=Path)
    gold = subcommands.add_parser("gold-evaluate", help="evaluate ranked units against an explicit gold set")
    gold.add_argument("input", type=Path, help="JSON object with ranked_ids, gold_ids and budget")
    gold.add_argument("output", type=Path)
    artifact = subcommands.add_parser("artifact-table", help="build deterministic paper-input tables")
    artifact.add_argument("records", type=Path, help="JSON array of result records")
    artifact.add_argument("csv", type=Path)
    artifact.add_argument("markdown", type=Path)
    preflight_cmd = subcommands.add_parser("preflight", help="check formal experiment authorization without executing")
    preflight_cmd.add_argument("contract", type=Path)
    preflight_cmd.add_argument("approval", type=Path)
    preflight_cmd.add_argument("--project-root", type=Path, default=Path.cwd())
    readiness_cmd = subcommands.add_parser("readiness", help="audit formal experiment readiness without executing")
    readiness_cmd.add_argument("contract", type=Path)
    readiness_cmd.add_argument("approval", type=Path)
    readiness_cmd.add_argument("environment", type=Path)
    readiness_cmd.add_argument("model_config", type=Path)
    readiness_cmd.add_argument("task_manifest", type=Path)
    readiness_cmd.add_argument("--project-root", type=Path, default=Path.cwd())
    readiness_cmd.add_argument("--task-sha256")
    readiness_cmd.add_argument("--allow-dirty", action="store_true")
    matrix_cmd = subcommands.add_parser("matrix-expand", help="expand an Agent x model plan without executing")
    matrix_cmd.add_argument("spec", type=Path)
    matrix_cmd.add_argument("output", type=Path)
    record = subcommands.add_parser("record", help="run one offline mock turn")
    record.add_argument("repo", type=Path)
    record.add_argument("events", type=Path)
    record.add_argument("run_id")
    record.add_argument("task")
    record.add_argument("--budget", type=int, default=100)

    # session-auth: proactive authorization workflow
    auth = subcommands.add_parser("session-auth", help="proactive session-based authorization")
    auth_sub = auth.add_subparsers(dest="auth_action", required=True)
    auth_req = auth_sub.add_parser("request", help="preview authorization scope for owner confirmation")
    auth_req.add_argument("contract", type=Path)
    auth_confirm = auth_sub.add_parser("confirm", help="write session_authorization.json after owner confirms")
    auth_confirm.add_argument("contract", type=Path)
    auth_confirm.add_argument("--quote", required=True, help="owner's verbatim confirmation statement")
    auth_confirm.add_argument("--force", action="store_true", help="overwrite existing authorization file")
    auth_check = auth_sub.add_parser("status", help="check whether a valid authorization exists")
    auth_check.add_argument("contract", type=Path)
    args = parser.parse_args()

    if args.command == "validate-schemas":
        schema_root = Path(__file__).resolve().parents[2] / "experiments" / "schemas"
        for path in sorted(schema_root.glob("*.schema.json")):
            json.loads(path.read_text(encoding="utf-8"))
            print(f"PASS {path.relative_to(schema_root.parent.parent)}")
        return 0

    if args.command == "report":
        build_report(args.events, args.output, run_id=args.run_id)
        return 0
    if args.command == "replay":
        store = TraceStore(args.events, args.run_id)
        print(replay(store.read(), lambda event: None))
        return 0
    if args.command == "evaluate":
        derived = derive_stats(json.loads(args.raw.read_text(encoding="utf-8")))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(derived, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
        return 0
    if args.command == "gold-evaluate":
        payload = json.loads(args.input.read_text(encoding="utf-8"))
        result = evaluate_gold(payload["ranked_ids"], set(payload["gold_ids"]), budget=int(payload["budget"]), ace_expected=int(payload.get("ace_expected", 0)), ace_preserved=int(payload.get("ace_preserved", 0)))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
        return 0
    if args.command == "artifact-table":
        records = json.loads(args.records.read_text(encoding="utf-8"))
        if not isinstance(records, list) or not all(isinstance(record, dict) for record in records):
            print("records must be a JSON array of objects")
            return 2
        write_result_table(records, args.csv, args.markdown)
        return 0
    if args.command == "preflight":
        contract = json.loads(args.contract.read_text(encoding="utf-8"))
        errors = formal_execution_errors(contract, project_root=args.project_root, approval_path=args.approval)
        for error in errors:
            print(f"FAIL {error}")
        if errors:
            return 2
        print("PASS formal execution preflight")
        return 0
    if args.command == "readiness":
        result = audit_readiness(
            project_root=args.project_root,
            contract_path=args.contract,
            approval_path=args.approval,
            environment_path=args.environment,
            model_config_path=args.model_config,
            task_manifest_path=args.task_manifest,
            expected_task_sha256=args.task_sha256,
            require_clean_tree=not args.allow_dirty,
        )
        for item in result["checks"]:
            print(f"{item['status']} {item['name']}: {item['detail']}")
        return 0 if result["status"] == "PASS" else 2
    if args.command == "matrix-expand":
        spec = json.loads(args.spec.read_text(encoding="utf-8"))
        try:
            cells = expand_matrix(spec)
        except (TypeError, ValueError) as error:
            print(f"FAIL {error}")
            return 2
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(cells, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
        print(f"PASS matrix cells: {len(cells)}")
        return 0
    if args.command == "record":
        loop = OfflineAgentLoop(args.repo, TraceStore(args.events, args.run_id))
        print(loop.run_turn(args.task, turn_id="cli-turn-1", budget=args.budget))
        return 0

    # ---- session-auth handlers ----
    if args.command == "session-auth":
        if args.auth_action == "request":
            print(preview_authorization_request(args.contract))
            return 0
        if args.auth_action == "confirm":
            try:
                auth_path = confirm_authorization(args.contract, args.quote, force=args.force)
                print(f"OK authorization written: {auth_path}")
                return 0
            except FileExistsError as exc:
                print(f"FAIL {exc}")
                return 2
            except ValueError as exc:
                print(f"FAIL invalid contract: {exc}")
                return 2
        if args.auth_action == "status":
            ok = has_valid_authorization(args.contract)
            auth_path = get_authorization_path(args.contract)
            if ok:
                print(f"PASS valid authorization exists: {auth_path}")
                return 0
            else:
                print(f"FAIL no valid authorization found for {args.contract.name}")
                print("  Run: cactus session-auth request <contract>  to preview scope")
                print("  Then: cactus session-auth confirm <contract> --quote '<owner confirmation>'")
                return 2
    if args.kind == "bundle":
        errors = validate_bundle(args.path)
        if errors:
            for error in errors:
                print(f"FAIL {error}")
            return 2
        print("PASS")
        return 0
    value = json.loads(args.path.read_text(encoding="utf-8"))
    checker = {"manifest": validate_run_manifest, "environment": validate_environment_snapshot, "raw": validate_raw_result, "approval": validate_approval_marker}[args.kind]
    errors = checker(value)
    if errors:
        for error in errors:
            print(f"FAIL {error}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
