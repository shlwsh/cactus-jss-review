"""Lite-50 v3.0 自我修正预测器（工程验证与生产完全相同）.

双保险架构：
1. Multi-Candidate：生成多个候选
2. Self-Correction：检测不完整/截断 → 反馈 → 重试
"""

from __future__ import annotations

import concurrent.futures
from dataclasses import dataclass, field
import json
import re
import sys
from typing import Any, Optional

from cactus.validation.completeness_validator import CompletenessValidator
from cactus.validation.feedback_generator import generate_correction_feedback
from cactus.validation.truncation_detector import detect_truncation


@dataclass
class CandidateResult:
    candidate_id: int
    raw_output: str
    is_complete: bool
    score: int
    error_type: Optional[str] = None
    error_detail: Optional[str] = None
    layer: int = 0
    attempt: int = 1


@dataclass
class SelfCorrectionResult:
    success: bool
    final_output: str
    final_score: int
    attempts: int
    candidates: list[CandidateResult] = field(default_factory=list)
    error_type: Optional[str] = None
    error_detail: Optional[str] = None
    total_tokens_used: int = 0


class SelfCorrectingPredictor:
    """自我修正预测器（工程验证与生产完全相同）."""

    def __init__(
        self,
        num_candidates: int = 3,
        max_correction_attempts: int = 2,
        max_output_tokens: int = 8192,
        temperature: float = 0.2,
        frequency_penalty: float = 0.25,
        validator: Optional[CompletenessValidator] = None,
    ):
        self.num_candidates = num_candidates
        self.max_correction_attempts = max_correction_attempts
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        self.frequency_penalty = frequency_penalty
        self.validator = validator or CompletenessValidator()

    def predict(
        self,
        task: dict,
        model_client: Any,
        sites: list[dict],
        context: str,
    ) -> SelfCorrectionResult:
        """主预测入口."""
        all_candidates: list[CandidateResult] = []
        total_tokens = 0
        best_candidate: Optional[CandidateResult] = None

        # Phase A: Multi-Candidate 生成
        print(f"[predict] 开始 Phase A: 生成 {self.num_candidates} 个候选", file=sys.stderr)

        candidates = self._generate_candidates(
            task, model_client, sites, context, seed_offset=100
        )
        all_candidates.extend(candidates)

        for c in candidates:
            total_tokens += self._estimate_tokens(c.raw_output)
            if best_candidate is None:
                best_candidate = c
            elif c.is_complete and not best_candidate.is_complete:
                best_candidate = c
            elif c.is_complete == best_candidate.is_complete and c.score > best_candidate.score:
                best_candidate = c

        phase_a_score = best_candidate.score if best_candidate else 0
        print(f"[predict] Phase A 完成: 最佳候选 score={phase_a_score}", file=sys.stderr)

        # Phase B: 自我修正循环
        if best_candidate and not best_candidate.is_complete:
            print("[predict] Phase B 开始: 触发修正循环", file=sys.stderr)

            for attempt in range(1, self.max_correction_attempts + 1):
                feedback = generate_correction_feedback(
                    error_type=best_candidate.error_type or "incomplete",
                    error_detail=best_candidate.error_detail or "完整性验证失败",
                    layer=best_candidate.layer,
                    original_output=best_candidate.raw_output,
                    suggestions=self.validator._get_suggestions(
                        best_candidate.raw_output,
                        best_candidate.error_type or "unknown",
                    ),
                    attempt=attempt,
                    max_attempts=self.max_correction_attempts,
                )

                retry_candidates = self._generate_candidates(
                    task,
                    model_client,
                    sites,
                    context,
                    feedback=feedback,
                    seed_offset=1000 + attempt * 100,
                    attempt=attempt + 1,
                )

                all_candidates.extend(retry_candidates)

                for c in retry_candidates:
                    total_tokens += self._estimate_tokens(c.raw_output)
                    if not best_candidate.is_complete and c.is_complete:
                        best_candidate = c
                    elif c.is_complete == best_candidate.is_complete and c.score > best_candidate.score:
                        best_candidate = c

                if best_candidate and best_candidate.is_complete:
                    print(f"[predict] 修正尝试 {attempt} 成功", file=sys.stderr)
                    break

        # 最终决策
        if best_candidate and best_candidate.is_complete:
            return SelfCorrectionResult(
                success=True,
                final_output=best_candidate.raw_output,
                final_score=best_candidate.score,
                attempts=len(all_candidates),
                candidates=all_candidates,
                total_tokens_used=total_tokens,
            )
        else:
            return SelfCorrectionResult(
                success=False,
                final_output=best_candidate.raw_output if best_candidate else "",
                final_score=best_candidate.score if best_candidate else 0,
                attempts=len(all_candidates),
                candidates=all_candidates,
                error_type=best_candidate.error_type if best_candidate else "no_candidate",
                error_detail=best_candidate.error_detail if best_candidate else "无法生成有效候选",
                total_tokens_used=total_tokens,
            )

    def _generate_candidates(
        self,
        task: dict,
        model_client: Any,
        sites: list[dict],
        context: str,
        feedback: str = "",
        seed_offset: int = 0,
        attempt: int = 1,
    ) -> list[CandidateResult]:
        """生成多个候选（支持并行）."""
        candidates: list[Optional[CandidateResult]] = [None] * self.num_candidates

        def generate_single(seed: int, idx: int) -> CandidateResult:
            try:
                prompt = self._build_prompt(task, sites, context, feedback=feedback, seed=seed)

                # 支持 OpenAI API 结构或直接调用
                if hasattr(model_client, "chat") and hasattr(model_client.chat, "completions"):
                    model_name = getattr(model_client, "model", None) or getattr(model_client, "model_id", "deepseek-chat")
                    response = model_client.chat.completions.create(
                        model=model_name,
                        messages=[{"role": "user", "content": prompt}],
                        max_tokens=self.max_output_tokens,
                        temperature=self.temperature,
                        frequency_penalty=self.frequency_penalty,
                        seed=seed,
                    )
                    raw_output = response.choices[0].message.content
                elif callable(model_client):
                    raw_output = str(model_client(prompt=prompt, seed=seed))
                else:
                    raise TypeError(f"Unsupported model_client type: {type(model_client)}")

                # 检测截断
                is_truncated, trunc_detail = detect_truncation(raw_output, max_tokens=self.max_output_tokens)
                if is_truncated:
                    return CandidateResult(
                        candidate_id=idx,
                        raw_output=raw_output,
                        is_complete=False,
                        score=20,
                        error_type="truncation_detected",
                        error_detail=trunc_detail,
                        layer=1,
                        attempt=attempt,
                    )

                # 提取目标代码或 replacement 进行四层完整性验证
                code_to_validate = self._extract_code_to_validate(raw_output)
                result = self.validator.validate(code_to_validate)

                return CandidateResult(
                    candidate_id=idx,
                    raw_output=raw_output,
                    is_complete=result.is_complete,
                    score=result.score,
                    error_type=result.error_type,
                    error_detail=result.error_detail,
                    layer=result.layer,
                    attempt=attempt,
                )

            except Exception as e:
                return CandidateResult(
                    candidate_id=idx,
                    raw_output="",
                    is_complete=False,
                    score=0,
                    error_type="generation_error",
                    error_detail=str(e),
                    attempt=attempt,
                )

        seeds = [seed_offset + i * 17 for i in range(self.num_candidates)]

        if self.num_candidates <= 1:
            candidates = [generate_single(seeds[0], 0)]
        else:
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.num_candidates) as executor:
                futures = {
                    executor.submit(generate_single, seed, idx): idx
                    for idx, seed in enumerate(seeds)
                }

                for future in concurrent.futures.as_completed(futures):
                    idx = futures[future]
                    try:
                        result = future.result(timeout=300)
                        candidates[idx] = result
                    except Exception as e:
                        print(f"[generate_candidates] 候选生成失败: {e}", file=sys.stderr)
                        candidates[idx] = CandidateResult(
                            candidate_id=idx,
                            raw_output="",
                            is_complete=False,
                            score=0,
                            error_type="thread_timeout_or_error",
                            error_detail=str(e),
                            attempt=attempt,
                        )

        return [c for c in candidates if c is not None]

    def _build_prompt(
        self,
        task: dict,
        sites: list[dict],
        context: str,
        feedback: str = "",
        seed: int = 0,
    ) -> str:
        """构建 Prompt（含修正反馈）."""
        base_prompt = self._build_base_prompt(task, sites, context)

        if feedback:
            base_prompt += f"\n\n{feedback}"

        return base_prompt

    def _build_base_prompt(self, task: dict, sites: list[dict], context: str) -> str:
        """构建基础 Prompt."""
        return f"""你是一名专业的 Python 软件工程师。请针对以下问题生成精确的修复代码。

## 任务: {task.get('instance_id', 'unknown')}

## 可修复位置 (Sites):
{self._format_sites(sites)}

## 问题上下文:
{context[:6000]}

## 输出格式规范（必须严格遵守）:
直接输出合法的 JSON 对象，不要输出任何额外的废话，格式如下：
```json
{{
  "edits": [
    {{
      "file_path": "对应文件路径",
      "replacement": "完整的Python替换语句或代码块（必须语法完整，能被 ast.parse 解析）"
    }}
  ]
}}
```

请直接输出 JSON 修复方案:
"""

    def _format_sites(self, sites: list[dict]) -> str:
        """格式化 site 列表."""
        lines = []
        for i, site in enumerate(sites, 1):
            lines.append(f"[{i}] {site.get('file_path', '')}:{site.get('start_line', '')}")
            lines.append(f"    {site.get('context', '')[:200]}")
        return "\n".join(lines)

    def _estimate_tokens(self, text: str) -> int:
        """估算 token 数量."""
        chinese_chars = sum(1 for c in text if "\u4e00" <= c <= "\u9fff")
        other_chars = len(text) - chinese_chars
        return int(chinese_chars / 2 + other_chars / 4)

    def _extract_code_to_validate(self, text: str) -> str:
        """从模型输出中提取用于验证的代码或 replacement."""
        if not text:
            return ""

        stripped = text.strip()

        # 1. 尝试提取 JSON 中的 replacement
        if "{" in stripped and "}" in stripped:
            try:
                # 寻找外层 JSON
                start = stripped.find("{")
                end = stripped.rfind("}") + 1
                payload = json.loads(stripped[start:end])
                if isinstance(payload, dict):
                    rows = payload.get("replacements") or payload.get("edits")
                    if isinstance(rows, list) and rows:
                        replacements = [e.get("replacement", "") for e in rows if isinstance(e, dict)]
                        if replacements:
                            return "\n".join(replacements)
            except Exception:
                pass

        # 2. 尝试提取 Markdown 代码块
        match = re.search(r"```(?:python)?\s*(.*?)\s*```", text, re.DOTALL)
        if match:
            return match.group(1).strip()

        return stripped
