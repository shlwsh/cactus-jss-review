"""Contract loader with explicit JSON/YAML dependency boundaries."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_contract(path: Path) -> dict[str, Any]:
    if path.suffix.lower() == ".json":
        value = json.loads(path.read_text(encoding="utf-8"))
    elif path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore[import-not-found]
        except ImportError as error:
            raise RuntimeError("YAML contract loading requires the optional PyYAML dependency") from error
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
    else:
        raise ValueError("contract must use .json, .yaml or .yml")
    if not isinstance(value, dict):
        raise ValueError("contract root must be an object")
    return value
