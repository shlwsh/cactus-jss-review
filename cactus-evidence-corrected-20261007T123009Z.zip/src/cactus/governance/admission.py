"""Shared, read-only admission semantics for publication and mutation validation.

Cryptographic integrity is checked first. Source bytes and authorization are
independent inputs, never inferred from a bundle's self-declared hashes.
"""
from __future__ import annotations

from functools import lru_cache
import hashlib
import json
from pathlib import Path
import subprocess
import time
from typing import Any, Callable

from cactus.governance.canonical import canonical_json
from cactus.governance.schema import validate_session_authorization
from cactus.runner.bundle_validator import validate_bundle


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("expected JSON object")
    return value


@lru_cache(maxsize=None)
def source_hash(root: Path, commit: str, relative: str) -> str:
    source = subprocess.run(["git", "show", f"{commit}:acm/{relative}"],
                            cwd=root, capture_output=True, check=True).stdout
    return hashlib.sha256(source).hexdigest()


def valid_evaluator(report: dict[str, Any], task_id: str | None = None) -> bool:
    if not isinstance(report, dict) or not report:
        return False
    counts = ("completed_instances", "resolved_instances", "unresolved_instances", "error_instances",
              "infra_failure_instances", "ambiguous_failure_instances", "unstopped_instances", "empty_patch_instances")
    if any(type(report.get(name)) is not int or report[name] < 0 for name in counts):
        return False
    if report["completed_instances"] != 1 or report["resolved_instances"] + report["unresolved_instances"] != 1:
        return False
    if any(report[name] for name in counts[3:]) or report.get("unstopped_containers"):
        return False
    completed, resolved, unresolved = (report.get(k) for k in ("completed_ids", "resolved_ids", "unresolved_ids"))
    if not isinstance(completed, list) or len(completed) != 1 or not isinstance(completed[0], str):
        return False
    if not isinstance(resolved, list) or not isinstance(unresolved, list):
        return False
    if len(resolved) != report["resolved_instances"] or len(unresolved) != report["unresolved_instances"]:
        return False
    if resolved + unresolved != completed or task_id is not None and completed != [task_id]:
        return False
    return not any(report.get(k) for k in ("error_ids", "infra_failure_ids", "ambiguous_failure_ids", "empty_patch_ids", "incomplete_ids"))


def valid_patch(bundle: Path, task_id: str) -> bool:
    try:
        records = [json.loads(line) for line in (bundle / "raw/prediction.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    except (OSError, json.JSONDecodeError):
        return False
    matched = [r for r in records if isinstance(r, dict) and r.get("instance_id") == task_id]
    if len(matched) != 1 or not isinstance(matched[0].get("model_patch"), str):
        return False
    patch = matched[0]["model_patch"]
    return patch.startswith("diff --git ") and "\n--- " in patch and "\n+++ " in patch and "\n@@" in patch


def evaluate_admission(root: Path, bundle: Path, contract: dict[str, Any], *,
                       authorization: dict[str, Any],
                       source_lookup: Callable[[Path, str, str], str] = source_hash) -> dict[str, Any]:
    """Return staged decisions; do not modify bundles or grant authorization.

    The resolver must supply bytes from the independently bound source revision
    (Git in the research workspace, a hash-pinned source capsule in the artifact).
    """
    started = time.perf_counter()
    integrity_errors = validate_bundle(bundle)
    decision = {"admitted": False, "integrity_passed": not integrity_errors,
                "stage": "integrity" if integrity_errors else "semantic", "reasons": integrity_errors,
                "evaluator_valid": False, "resolved": False,
                "source_driver_sha256": None, "source_derivation_sha256": None}
    if integrity_errors:
        decision["elapsed_sec"] = time.perf_counter() - started
        return decision
    errors: list[str] = []
    try:
        manifest = read_json(bundle / "run_manifest.json")
        raw = read_json(bundle / "raw/result.json")
        config = read_json(bundle / "resolved_config.json")
        frozen = read_json(bundle / "contract.json")
        data, evidence = raw["data"], raw["evidence"]
        if canonical_json(frozen) != canonical_json(contract):
            errors.append("contract_frozen_mismatch")
        contract_digest = hashlib.sha256(canonical_json(contract).encode()).hexdigest()
        if (validate_session_authorization(authorization) or authorization.get("status") != "approved"
                or authorization.get("experiment_id") != contract.get("experiment_id")
                or authorization.get("contract_sha256") != contract_digest):
            errors.append("authorization_contract_mismatch")
        if manifest.get("experiment_id") != contract.get("experiment_id"):
            errors.append("experiment_contract_mismatch")
        if manifest.get("code", {}).get("commit") != contract.get("source", {}).get("git_commit"):
            errors.append("source_commit_mismatch")
        if manifest.get("code", {}).get("dirty"):
            errors.append("dirty_tree_execution")
        for part, path_key, result_key, reason in [
            ("workload", "driver", "source_driver_sha256", "contract_driver_source_hash_mismatch"),
            ("derivation", "script", "source_derivation_sha256", "contract_derivation_source_hash_mismatch"),
        ]:
            actual = source_lookup(root, manifest["code"]["commit"], contract[part][path_key])
            decision[result_key] = actual
            if actual != contract[part]["sha256"]:
                errors.append(reason)
        task_id = data.get("task_id")
        if not isinstance(task_id, str) or not task_id:
            errors.append("task_identity_mismatch")
        elif manifest.get("task_id") != task_id or config.get("task", {}).get("task_id") != task_id:
            errors.append("task_identity_mismatch")
        reports = sorted((bundle / "evaluation").glob("*.json"))
        report = read_json(reports[0]) if len(reports) == 1 else {}
        evaluator_valid = valid_evaluator(report, task_id)
        resolved = evaluator_valid and report["resolved_instances"] == 1
        decision.update(evaluator_valid=evaluator_valid, resolved=resolved)
        if not evaluator_valid:
            errors.append("no_valid_official_evaluator")
        if bool(data.get("evaluator_valid")) != evaluator_valid or bool(data.get("resolved")) != resolved:
            errors.append("raw_evaluator_result_mismatch")
        if not valid_patch(bundle, task_id):
            errors.append("no_valid_prediction_patch")
        billing = read_json(bundle / "billing/litellm_spend.json")
        reconciliation = billing.get("provider_usage_reconciliation", {})
        matched = (reconciliation.get("status") == "matched"
                   and reconciliation.get("provider_tokens") == reconciliation.get("billing_tokens") == billing.get("total_tokens"))
        if billing.get("status") != "verified_cost" or not matched:
            errors.append("billing_not_reconciled")
        # Cross-object checks catch a self-consistent record from another attempt.
        if matched and billing.get("status") == "verified_cost" and data.get("input_tokens") is not None and data.get("output_tokens") is not None:
            if data["input_tokens"] + data["output_tokens"] != billing.get("total_tokens"):
                errors.append("billing_attempt_usage_mismatch")
        if matched and billing.get("status") == "verified_cost" and data.get("verified_usd_spend") is not None and data["verified_usd_spend"] != billing.get("total_spend"):
            errors.append("billing_attempt_spend_mismatch")
        if evidence.get("origin_type") != "measured" or evidence.get("integrity_status") != "verified":
            errors.append("raw_evidence_not_verified_measured")
        if manifest.get("environment", {}).get("capture_mode") != "observed":
            errors.append("environment_not_observed")
        # Version assertions are checked when retained, never reconstructed.
        model = config.get("model", {})
        expected_model = contract.get("model", {})
        if expected_model.get("model_version") and model.get("model_version") != expected_model["model_version"]:
            errors.append("model_version_contract_mismatch")
        if isinstance(task_id, str) and config.get("evaluator_image"):
            suffix = "." + task_id.replace("__", "_1776_").lower()
            images = [image for image in contract.get("images", {}).values()
                      if image.get("repository", "").lower().endswith(suffix)]
            if len(images) != 1 or config["evaluator_image"] != images[0]["repository"] + "@" + images[0]["digest"]:
                errors.append("evaluator_image_contract_mismatch")
    except (OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError):
        errors.append("admission_evidence_unreadable")
    decision.update(admitted=not errors, stage="semantic" if errors else "none", reasons=errors,
                    elapsed_sec=time.perf_counter() - started)
    return decision
