"""Offline contract checks shared by future preflight and runner commands."""

from __future__ import annotations

import re
from collections.abc import Mapping

from .canonical import SHA256_RE, safe_relative_path


def validate_contract(contract: Mapping[str, object]) -> list[str]:
    errors: list[str] = []
    required = ("schema_version", "experiment_id", "study_id", "source", "workload", "derivation", "result_ids")
    errors.extend(f"missing required field: {field}" for field in required if field not in contract)
    if contract.get("schema_version") != "2.0":
        errors.append("schema_version must be '2.0'")
    experiment_id = contract.get("experiment_id")
    if not isinstance(experiment_id, str) or not re.fullmatch(r"EXP-[A-Z0-9][A-Z0-9_-]*", experiment_id):
        errors.append("experiment_id does not match EXP format")
    source = contract.get("source")
    if not isinstance(source, Mapping) or not isinstance(source.get("git_commit"), str) or not re.fullmatch(r"[0-9a-f]{40}", source["git_commit"]):
        errors.append("source.git_commit must be a 40-character lowercase SHA-1")
    workload = contract.get("workload")
    if not isinstance(workload, Mapping):
        errors.append("workload must be an object")
    else:
        _check_hashed_path(workload, "workload", errors)
        if not isinstance(workload.get("seed"), int) or workload["seed"] < 0:
            errors.append("workload.seed must be a non-negative integer")
        if not isinstance(workload.get("measure_sec"), int) or workload["measure_sec"] < 30:
            errors.append("workload.measure_sec must be at least 30 seconds")
        variant_matrix = workload.get("variant_matrix")
        if variant_matrix is not None and (
            not isinstance(variant_matrix, list)
            or not variant_matrix
            or not all(isinstance(item, str) and item for item in variant_matrix)
            or len(set(variant_matrix)) != len(variant_matrix)
        ):
            errors.append("workload.variant_matrix must be a non-empty list of unique variant IDs")
    derivation = contract.get("derivation")
    if not isinstance(derivation, Mapping):
        errors.append("derivation must be an object")
    else:
        _check_hashed_path(derivation, "derivation", errors)
    images = contract.get("images", {})
    if isinstance(images, Mapping):
        for name, image in images.items():
            if not isinstance(image, Mapping) or not isinstance(image.get("digest"), str) or not image["digest"].startswith("sha256:"):
                errors.append(f"images.{name}.digest must be pinned")
            if isinstance(image, Mapping) and image.get("tag") == "latest":
                errors.append(f"images.{name}.tag cannot be latest")
    model = contract.get("model")
    execution = contract.get("execution")
    if isinstance(model, Mapping) and model.get("algorithm_revision") in {"lite50_v2", "lite50_v3_dual_insurance"}:
        rev = model.get("algorithm_revision")
        if not isinstance(execution, Mapping):
            errors.append(f"execution must be an object for {rev}")
        else:
            total_token_budget = execution.get("total_token_budget")
            if not isinstance(total_token_budget, int) or isinstance(total_token_budget, bool) or total_token_budget < 1:
                errors.append(f"execution.total_token_budget must be positive for {rev}")
            architecture = execution.get("token_architecture")
            if not isinstance(architecture, Mapping):
                errors.append(f"execution.token_architecture is required for {rev}")
            else:
                soft = architecture.get("per_task_soft_limit")
                hard = architecture.get("per_task_hard_limit")
                reserve = architecture.get("per_call_min_reserve")
                factor = architecture.get("estimator_safety_factor")
                if not isinstance(soft, int) or soft < 1:
                    errors.append("execution.token_architecture.per_task_soft_limit must be positive")
                if not isinstance(hard, int) or not isinstance(soft, int) or hard < soft:
                    errors.append("execution.token_architecture.per_task_hard_limit must be at least the soft limit")
                if not isinstance(reserve, int) or reserve < 1:
                    errors.append("execution.token_architecture.per_call_min_reserve must be positive")
                if not isinstance(factor, (int, float)) or isinstance(factor, bool) or factor < 1:
                    errors.append("execution.token_architecture.estimator_safety_factor must be at least 1")
            stop_on = execution.get("stop_on")
            if not isinstance(stop_on, list) or "per_task_token_exceeded" not in stop_on:
                errors.append(f"execution.stop_on must include per_task_token_exceeded for {rev}")
    return errors


def _check_hashed_path(value: Mapping[str, object], label: str, errors: list[str]) -> None:
    path, digest = value.get("driver" if label == "workload" else "script"), value.get("sha256")
    if not isinstance(path, str) or not safe_relative_path(path):
        errors.append(f"{label} path must be relative and safe")
    if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
        errors.append(f"{label}.sha256 must be a full SHA-256")
