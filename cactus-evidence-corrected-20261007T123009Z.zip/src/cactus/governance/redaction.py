"""Conservative snapshot redaction for secrets and credentials."""

from __future__ import annotations

import re
from typing import Any


SENSITIVE_KEY = re.compile(r"(token|password|passwd|secret|private[_-]?key|api[_-]?key|authorization|credential)", re.I)


def redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: "[REDACTED]" if SENSITIVE_KEY.search(str(key)) else redact(item) for key, item in value.items()}
    if isinstance(value, list):
        return [redact(item) for item in value]
    if isinstance(value, str):
        value = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._-]+", r"\1[REDACTED]", value)
        return re.sub(r"(?i)(https?://[^\s:/]+:)[^@\s]+(@)", r"\1[REDACTED]\2", value)
    return value
