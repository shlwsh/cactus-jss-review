"""Policy-derived publication status; callers cannot set claim flags by hand."""

from __future__ import annotations

from collections.abc import Mapping
import json
from pathlib import Path


def derive_claim_status(evidence: Mapping[str, str], *, requested: str = "primary") -> tuple[str, list[str]]:
    if requested not in {"primary", "supporting", "context_only"}:
        return "blocked", ["unknown requested status"]
    policy_path = Path(__file__).resolve().parents[3] / "configs/policies/publication_policy.json"
    policy = json.loads(policy_path.read_text(encoding="utf-8"))
    state = {**evidence, "requested": requested}
    status, reason = policy["default"], "default-block"
    for rule in policy["rules"]:
        if all(state.get(k) in v if isinstance(v, list) else state.get(k) == v
               for k, v in rule["when"].items()):
            status, reason = rule["claim_status"], rule["id"]
            break
    rank = {"blocked": 0, "context_only": 1, "supporting": 2, "primary": 3}
    if rank[status] > rank[requested]:
        status = requested
    return status, ([] if status == requested else [reason])
