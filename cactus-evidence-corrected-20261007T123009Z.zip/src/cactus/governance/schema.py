"""Minimal offline validators for P0 evidence schemas.

The validators deliberately fail closed. Full JSON Schema tooling may be
introduced only with an explicit dependency decision in a later ADR.
"""

from __future__ import annotations

from typing import Any
import re

from .canonical import RUN_ID_RE, SHA256_RE, safe_relative_path

REQUIRED_MANIFEST = {
    "schema_version", "study_id", "experiment_id", "run_id", "started_at",
    "status", "code", "configuration", "environment", "command", "outputs",
}
ARTIFACT_ID_RE = re.compile(r"^(FIG|TAB|MAIN|DATA)-[A-Z][A-Z0-9_-]*$")
ARTIFACT_TYPES = {"figure", "table", "main_paper", "appendix", "derived_dataset"}


def _require(value: dict[str, Any], field: str, errors: list[str]) -> None:
    if field not in value:
        errors.append(f"missing required field: {field}")


def validate_run_manifest(value: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(value, dict):
        return ["manifest must be a JSON object"]
    for field in REQUIRED_MANIFEST:
        _require(value, field, errors)
    if value.get("schema_version") != "2.0":
        errors.append("schema_version must be '2.0'")
    if not isinstance(value.get("run_id"), str) or not RUN_ID_RE.fullmatch(value["run_id"]):
        errors.append("run_id does not match canonical RUN format")
    code = value.get("code")
    if not isinstance(code, dict) or not isinstance(code.get("commit"), str) or len(code["commit"]) != 40:
        errors.append("code.commit must be a 40-character commit identifier")
    configuration = value.get("configuration")
    if not isinstance(configuration, dict):
        errors.append("configuration must be an object")
    else:
        _validate_path_hash(configuration, "configuration", errors)
    environment = value.get("environment")
    if not isinstance(environment, dict) or environment.get("capture_mode") not in {"observed", "reconstructed"}:
        errors.append("environment.capture_mode must be observed or reconstructed")
    outputs = value.get("outputs")
    if not isinstance(outputs, list):
        errors.append("outputs must be a list")
    else:
        for index, output in enumerate(outputs):
            if not isinstance(output, dict):
                errors.append(f"outputs[{index}] must be an object")
                continue
            _validate_path_hash(output, f"outputs[{index}]", errors)
    retry_chain = value.get("retry_chain")
    if retry_chain is not None:
        if not isinstance(retry_chain, list):
            errors.append("retry_chain must be a list")
        else:
            for index, attempt in enumerate(retry_chain):
                label = f"retry_chain[{index}]"
                if not isinstance(attempt, dict):
                    errors.append(f"{label} must be an object")
                    continue
                if not isinstance(attempt.get("attempt_id"), str) or not attempt["attempt_id"]:
                    errors.append(f"{label}.attempt_id is required")
                if not isinstance(attempt.get("attempt"), int) or attempt["attempt"] < 1:
                    errors.append(f"{label}.attempt must be a positive integer")
                if attempt.get("outcome") not in {"VALID_RESOLVED", "VALID_UNRESOLVED", "INVALID_EVALUATION"}:
                    errors.append(f"{label}.outcome is invalid")
                if not isinstance(attempt.get("error_code"), str) or not attempt["error_code"]:
                    errors.append(f"{label}.error_code is required")
                for field in ("task_id", "model_alias", "context_bundle_hash", "budget_policy", "evaluator_version"):
                    if not isinstance(attempt.get(field), str) or not attempt[field]:
                        errors.append(f"{label}.{field} is required")
            numbers = [item.get("attempt") for item in retry_chain if isinstance(item, dict)]
            if numbers and numbers != list(range(1, len(numbers) + 1)):
                errors.append("retry_chain.attempt values must be contiguous starting at 1")
    return errors


def _validate_path_hash(value: dict[str, Any], label: str, errors: list[str]) -> None:
    path = value.get("path")
    digest = value.get("sha256")
    if not isinstance(path, str) or not safe_relative_path(path):
        errors.append(f"{label}.path must be a safe relative path")
    if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
        errors.append(f"{label}.sha256 must be a 64-character SHA-256")


def validate_environment_snapshot(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return ["snapshot must be a JSON object"]
    errors: list[str] = []
    if value.get("schema_version") != "2.0":
        errors.append("schema_version must be '2.0'")
    if value.get("capture_mode") not in {"observed", "reconstructed"}:
        errors.append("capture_mode must be observed or reconstructed")
    if not isinstance(value.get("generated_at"), str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", value["generated_at"]):
        errors.append("generated_at must be a UTC timestamp string")
    if value.get("capture_mode") == "reconstructed":
        for field in ("reconstructed_at", "reconstruction_confidence", "evidence_sources", "unknown_fields"):
            _require(value, field, errors)
    return errors


def validate_raw_result(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return ["raw result must be a JSON object"]
    errors: list[str] = []
    for field in ("schema_version", "run_id", "experiment_id", "generated_at", "data"):
        _require(value, field, errors)
    if value.get("schema_version") != "2.0":
        errors.append("schema_version must be '2.0'")
    if not isinstance(value.get("run_id"), str) or not RUN_ID_RE.fullmatch(value["run_id"]):
        errors.append("run_id does not match canonical RUN format")
    return errors


def validate_artifact_provenance(value: Any) -> list[str]:
    """Validate provenance sidecars without adding a JSON Schema dependency."""
    if not isinstance(value, dict):
        return ["provenance must be a JSON object"]
    errors: list[str] = []
    required = (
        "schema_version", "artifact_id", "artifact_type", "artifact_path",
        "artifact_sha256", "generated_at", "generator", "inputs", "transform",
    )
    for field in required:
        _require(value, field, errors)
    if value.get("schema_version") != "2.0":
        errors.append("schema_version must be '2.0'")
    if not isinstance(value.get("artifact_id"), str) or not ARTIFACT_ID_RE.fullmatch(value["artifact_id"]):
        errors.append("artifact_id does not match FIG/TAB/MAIN/DATA identifier format")
    if value.get("artifact_type") not in ARTIFACT_TYPES:
        errors.append("artifact_type is not supported")
    if not isinstance(value.get("artifact_path"), str):
        errors.append("artifact_path must be a string")
    if not isinstance(value.get("artifact_sha256"), str) or not SHA256_RE.fullmatch(value["artifact_sha256"]):
        errors.append("artifact_sha256 must be a 64-character SHA-256")
    generated_at = value.get("generated_at")
    if not isinstance(generated_at, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", generated_at):
        errors.append("generated_at must be a UTC timestamp string")
    if not isinstance(value.get("generator"), dict):
        errors.append("generator must be an object")
    if not isinstance(value.get("inputs"), list):
        errors.append("inputs must be a list")
    if not isinstance(value.get("transform"), dict):
        errors.append("transform must be an object")
    return errors


def validate_approval_marker(value: Any) -> list[str]:
    """Validate the human approval artifact required by formal execution."""
    if not isinstance(value, dict):
        return ["approval marker must be a JSON object"]
    errors: list[str] = []
    if value.get("schema_version") != "1.0":
        errors.append("approval marker schema_version must be '1.0'")
    if value.get("status") != "approved":
        errors.append("approval marker status must be 'approved'")
    if not isinstance(value.get("experiment_id"), str) or not re.fullmatch(r"EXP-[A-Z0-9][A-Z0-9_-]*", value.get("experiment_id", "")):
        errors.append("approval marker experiment_id is invalid")
    if not isinstance(value.get("approved_by"), str) or not value.get("approved_by"):
        errors.append("approval marker approved_by is required")
    if not isinstance(value.get("approved_at"), str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", value.get("approved_at", "")):
        errors.append("approval marker approved_at must be UTC second-precision")
    return errors


def validate_session_authorization(value: Any) -> list[str]:
    """Validate an explicit owner authorization recorded in the Codex session."""
    if not isinstance(value, dict):
        return ["session authorization must be a JSON object"]
    errors: list[str] = []
    if value.get("schema_version") != "1.0":
        errors.append("session authorization schema_version must be '1.0'")
    if value.get("authorization_type") != "session_confirmation":
        errors.append("authorization_type must be 'session_confirmation'")
    if value.get("status") != "approved":
        errors.append("session authorization status must be 'approved'")
    if not isinstance(value.get("experiment_id"), str) or not re.fullmatch(r"EXP-[A-Z0-9][A-Z0-9_-]*", value.get("experiment_id", "")):
        errors.append("session authorization experiment_id is invalid")
    if value.get("approved_by") != "project_owner":
        errors.append("session authorization approved_by must be 'project_owner'")
    if not isinstance(value.get("approved_at"), str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", value.get("approved_at", "")):
        errors.append("session authorization approved_at must be UTC second-precision")
    if not isinstance(value.get("confirmation_quote"), str) or not value["confirmation_quote"].strip():
        errors.append("session authorization confirmation_quote is required")
    if not isinstance(value.get("scope"), str) or not value["scope"].strip():
        errors.append("session authorization scope is required")
    if "contract_sha256" in value and (not isinstance(value["contract_sha256"], str) or not SHA256_RE.fullmatch(value["contract_sha256"])):
        errors.append("session authorization contract_sha256 must be a full SHA-256")
    return errors
