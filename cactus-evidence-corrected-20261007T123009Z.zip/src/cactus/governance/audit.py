"""Read-only data quality audit for CACTUS project assets."""

from __future__ import annotations

import re
import json
import ast
from pathlib import Path
from typing import Any

from cactus.runner.bundle_validator import validate_bundle
from cactus.governance.evidence_locations import iter_runs


def _image_alias_findings(path: Path, text: str) -> list[str]:
    """Separate actual bindings from prose and pinned observed aliases.

    A snapshot can record the label observed at capture time alongside both
    immutable identities. It is still a warning; an unpinned reference in a
    snapshot or executable configuration remains critical.
    """
    if ":latest" not in text:
        return []
    try:
        if path.suffix.lower() == ".jsonl":
            value = [json.loads(line) for line in text.splitlines() if line.strip()]
        else:
            value = json.loads(text)
    except ValueError:
        return ["warning" if _non_executable_evidence(path) else "critical"]
    severities = []
    observed_snapshot = (isinstance(value, dict) and value.get("capture_mode") == "observed"
                         and any(path.parts[index:index + 2] == ("experiments", "snapshots")
                                 for index in range(len(path.parts) - 1)))
    historical_evidence = _non_executable_evidence(path)
    def visit(node):
        if isinstance(node, dict):
            for key, item in node.items():
                # These fields document behavior and cannot supply a runtime
                # binding. Continue scanning all other fields recursively.
                if key.endswith(("_note", "_notes")) or key in {"description", "purpose", "notes"}:
                    continue
                if isinstance(item, str) and ":latest" in item:
                    stem = key.removesuffix("_ref") if key.endswith("_ref") else None
                    digest = node.get(stem + "_digest", "") if stem else ""
                    local_id_key = stem.removesuffix("_image") + "_local_image_id" if stem else ""
                    local_id = node.get(local_id_key, "")
                    pinned_observation = (observed_snapshot and key.endswith("_image_ref")
                                          and item.endswith(":latest")
                                          and re.fullmatch(r"sha256:[0-9a-f]{64}", str(digest))
                                          and re.fullmatch(r"sha256:[0-9a-f]{64}", str(local_id)))
                    severities.append("warning" if pinned_observation or historical_evidence else "critical")
                else:
                    visit(item)
        elif isinstance(node, list):
            for item in node:
                visit(item)
        elif isinstance(node, str) and ":latest" in node:
            severities.append("warning" if historical_evidence else "critical")
    visit(value)
    return severities


def _historical_run_artifact(root: Path, path: Path) -> bool:
    """Treat immutable failed-run diagnostics as warnings, not current defects."""

    try:
        relative = path.relative_to(root)
    except ValueError:
        return False
    parts = relative.parts
    if len(parts) >= 3 and parts[0:2] == ("experiments", "runs") and parts[2].startswith("RUN-"):
        return True
    # Quarantined runs are also historical (not current active runs)
    if len(parts) >= 3 and parts[0:2] == ("experiments", "quarantine") and parts[2].startswith("RUN-"):
        return True
    return False


def _non_executable_evidence(path: Path) -> bool:
    """Benchmark manifests and evaluator outputs record image labels; they do
    not select an image for a new run. Contracts/configs still bind execution.
    """
    parts = path.parts
    return (("data" in parts and "manifests" in parts)
            or ("experiments" in parts and any(part.startswith("eval_") for part in parts)
                and "report" in parts)
            or ("experiments" in parts and "evaluations" in parts))


def _sensitive_field_matches(value: Any) -> bool:
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).lower().replace("-", "_")
            if (re.fullmatch(r"(?:api_?key|password|private_?key|access_token|refresh_token|authorization)", normalized)
                    and isinstance(item, str) and item.strip()
                    and not re.fullmatch(r"(?i)(?:dummy|redacted|<[^>]+>|\$\{[^}]+\}|CACTUS_[A-Z0-9_]*(?:KEY|TOKEN))", item.strip())):
                return True
            if _sensitive_field_matches(item):
                return True
    elif isinstance(value, list):
        return any(_sensitive_field_matches(item) for item in value)
    return False


def _sensitive_text(path: Path, text: str) -> bool:
    """Inspect literal credentials, not runtime expressions or type annotations.

    No file or directory whitelist is applied. Credential-shaped literals are
    checked even inside vendored source. Values are never returned in findings.
    """
    if re.search(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bsk-[A-Za-z0-9_-]{20,}", text):
        return True
    if path.suffix.lower() == ".py":
        try:
            tree = ast.parse(text)
        except SyntaxError:
            tree = None
        if tree is not None:
            for node in ast.walk(tree):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target] if isinstance(node, ast.AnnAssign) else []
                value = getattr(node, "value", None)
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    for target in targets:
                        name = target.id if isinstance(target, ast.Name) else target.attr if isinstance(target, ast.Attribute) else ""
                        if _sensitive_field_matches({name: value.value}):
                            return True
            # Also check literal dictionaries and keyword arguments.
            for node in ast.walk(tree):
                if isinstance(node, ast.Dict):
                    try:
                        if _sensitive_field_matches(ast.literal_eval(node)):
                            return True
                    except (ValueError, TypeError, SyntaxError):
                        pass
                if isinstance(node, ast.keyword) and isinstance(node.value, ast.Constant):
                    if _sensitive_field_matches({node.arg: node.value.value}):
                        return True
            return False
    source_format = path.suffix.lower() in {".c", ".h", ".cpp", ".js", ".ts", ".java"}
    pattern = (r"(?im)^\s*(api[_-]?key|password|private[_-]?key|access[_-]?token|authorization)"
               r"\s*[:=]\s*(['\"])([^'\"\r\n]+)\2")
    for match in re.finditer(pattern, text):
        # A literal anonymous FTP placeholder is not a live authentication
        # secret. Require both the explicit guest username and an exact
        # conventional placeholder; no path or arbitrary-value whitelist.
        before = text[max(0, match.start() - 100):match.start()]
        if (source_format and match[1].lower() == "password"
                and match[3] in {"user@host.com", "user@localhost", "anonymous@example.com", "anonymous@localhost"}
                and re.search(r"username\s*=\s*['\"]anonymous['\"]\s*;\s*$", before)):
            continue
        if _sensitive_field_matches({match[1]: match[3]}):
            return True
    if not source_format:
        for match in re.finditer(r"(?im)^\s*(api[_-]?key|password|private[_-]?key|access[_-]?token|authorization)\s*[:=]\s*([^\r\n]+)", text):
            if _sensitive_field_matches({match[1]: match[2].strip().strip("'\"")}):
                return True
    return False


def _run_status(path: Path) -> str | None:
    manifest = path / "run_manifest.json"
    if not manifest.is_file():
        return None
    try:
        import json
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return str(payload.get("status")) if payload.get("status") is not None else None


def audit_project(root: Path) -> dict[str, Any]:
    findings: list[dict[str, str]] = []
    scan_roots = [root / name for name in ("configs", "experiments", "data", "docker")]
    scan_paths = [(path.relative_to(root).as_posix(), path) for scan_root in scan_roots if scan_root.exists() for path in scan_root.rglob("*")]
    archive_runs = list(iter_runs(root))
    for logical, physical in archive_runs:
        if physical.resolve().is_relative_to(root.resolve()):
            continue
        scan_paths.extend((logical + "/" + path.relative_to(physical).as_posix(), path) for path in physical.rglob("*"))
    for logical, path in scan_paths:
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        logical_path = root / logical
        for severity in _image_alias_findings(logical_path, text):
            findings.append({"code": "DQ-LATEST-001", "path": logical,
                             "severity": "warning" if _historical_run_artifact(root, logical_path) else severity})
        sensitive = False
        try:
            if path.suffix.lower() == ".json":
                sensitive = _sensitive_field_matches(json.loads(text))
            elif path.suffix.lower() == ".jsonl":
                sensitive = any(_sensitive_field_matches(json.loads(line))
                                for line in text.splitlines() if line.strip())
            else:
                # For human text/config formats, require an actual credential
                # assignment key; *_env and *_alias settings are references.
                sensitive = _sensitive_text(path, text)
        except (ValueError, TypeError):
            sensitive = False
        if sensitive:
            findings.append({"code": "DQ-SENSITIVE-001", "path": logical,
                             "severity": "critical"})
    runs = root / "experiments" / "runs"
    if runs.exists():
        for logical, run in archive_runs:
            if not run.name.startswith("RUN-"):
                continue
            for error in validate_bundle(run):
                findings.append({"code": "DQ-RUN-001", "path": logical, "severity": "critical", "message": error})
    return {"status": "FAIL" if any(item["severity"] == "critical" for item in findings) else "PASS", "finding_count": len(findings), "warning_count": sum(item["severity"] == "warning" for item in findings), "findings": findings}
