"""Proactive session-based authorization flow for formal experiment execution.

This module enables the Agent to **initiate** an authorization request in the
session and the owner to **confirm** it, generating the
``*.session_authorization.json`` file without any manual JSON editing.

Workflow
--------
1. Agent calls ``request_authorization(contract_path)`` to preview scope and
   surface a human-readable confirmation prompt.
2. Owner confirms with a natural-language statement in the session
   (e.g. "我审批同意，可继续" or "proceed with Phase C Pilot").
3. Agent calls ``confirm_authorization(contract_path, confirmation_quote)`` to
   write the ``*.session_authorization.json`` file.
4. The file is automatically picked up by ``formal_execution_errors`` and
   ``audit_readiness`` (fallback from ``*.approval_marker.json``).

Both marker and session-authorization files are accepted; the former requires
physical owner action on the filesystem, the latter requires only a verbal
confirmation captured in the session.
"""

from __future__ import annotations

import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cactus.governance.canonical import canonical_json
from cactus.governance.contract import validate_contract


# ---------------------------------------------------------------------------
# Schema constants (mirrors session_authorization.schema.json)
# ---------------------------------------------------------------------------

SESSION_AUTH_SCHEMA_VERSION = "1.0"
AUTHORIZATION_TYPE = "session_confirmation"
APPROVED_STATUS = "approved"
APPROVED_BY = "project_owner"

# UTC timestamp for now (seconds precision)
def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------

def build_authorization_request(contract_path: Path) -> dict[str, Any]:
    """Return a human-readable preview of the experiment scope.

    This function is called by the Agent *before* asking the owner for
    confirmation.  The returned dict is suitable for printing in the session.

    Parameters
    ----------
    contract_path:
        Path to the contract JSON file (e.g.
        ``experiments/contracts/EXP-CACTUS-PILOT-V2.json``).

    Returns
    -------
    dict with keys: ``experiment_id``, ``scope``, ``budget``, ``cost_budget``,
    ``model``, ``task_count``, ``pilot_tasks``, ``purpose``, ``git_commit``.
    """
    contract = json.loads(contract_path.read_text(encoding="utf-8"))

    cost = contract.get("execution", {}).get("cost_budget", {})
    task_count = contract.get("execution", {}).get("task_count", "?")
    pilot_tasks = contract.get("execution", {}).get("pilot_tasks", [])
    model_info = contract.get("model", {})
    workload = contract.get("workload", {})
    variants = workload.get("variant_matrix") if isinstance(workload, dict) else None
    if not isinstance(variants, list):
        variants = contract.get("variants", [])
    metadata = contract.get("_metadata", {})
    planned_runs = metadata.get("candidate_expected_run_count") if isinstance(metadata, dict) else None
    statistical_plan = contract.get("statistical_plan", {})
    primary_pair = statistical_plan.get("primary_pair", []) if isinstance(statistical_plan, dict) else []

    scope_parts = [
        f"Task count: {task_count}",
    ]
    if pilot_tasks:
        scope_parts.append(f"Tasks: {', '.join(pilot_tasks)}")
    if model_info:
        scope_parts.append(f"Model: {model_info.get('model_id', '?')} ({model_info.get('model_version', '?')})")
    if variants:
        scope_parts.append(f"Variants: {', '.join(str(item) for item in variants)}")
    if planned_runs is not None:
        scope_parts.append(f"Planned runs: {planned_runs}")

    return {
        "experiment_id": contract.get("experiment_id", "UNKNOWN"),
        "purpose": contract.get("purpose", "UNKNOWN"),
        "scope": "; ".join(scope_parts),
        "budget": f"{cost.get('currency', 'USD')} {cost.get('amount', '?')}",
        "cost_budget": cost,
        "model": model_info.get("model_id", "?"),
        "model_version": model_info.get("model_version", "?"),
        "task_count": task_count,
        "pilot_tasks": pilot_tasks,
        "git_commit": contract.get("source", {}).get("git_commit", "?"),
        "contract_sha256": hashlib.sha256(canonical_json(contract).encode("utf-8")).hexdigest(),
        "require_clean_tree": contract.get("source", {}).get("require_clean_tree", True),
        "result_ids": contract.get("result_ids", []),
        "stop_conditions": contract.get("execution", {}).get("stop_on", []),
        "variants": variants,
        "planned_runs": planned_runs,
        "candidate_status": metadata.get("candidate_status") if isinstance(metadata, dict) else None,
        "primary_pair": primary_pair,
    }


def preview_authorization_request(contract_path: Path) -> str:
    """Return a formatted human-readable summary for the session.

    This is the text shown to the owner before asking for confirmation.
    """
    req = build_authorization_request(contract_path)
    lines = [
        f"## 授权申请预览：{req['experiment_id']}",
        "",
        f"- **实验目的**: {req['purpose']}",
        f"- **授权范围**: {req['scope']}",
        f"- **费用上限**: {req['budget']}",
        f"- **模型**: {req['model']} ({req['model_version']})",
        f"- **Git commit**: `{req['git_commit']}`",
        f"- **Contract SHA-256**: `{req['contract_sha256']}`",
        f"- **变体矩阵**: {', '.join(str(item) for item in req['variants']) if req['variants'] else '未声明'}",
        f"- **主比较**: {' vs '.join(str(item) for item in req['primary_pair']) if req['primary_pair'] else '未声明'}",
        f"- **计划 RUN 数**: {req['planned_runs'] if req['planned_runs'] is not None else '未声明'}",
        f"- **候选状态**: {req['candidate_status'] or '未声明'}",
        f"- **清理工作树**: {'是' if req['require_clean_tree'] else '否'}",
        f"- **Result IDs**: {', '.join(req['result_ids']) if req['result_ids'] else '无'}",
        f"- **自动停止条件**: {', '.join(req['stop_conditions']) if req['stop_conditions'] else '无'}",
        "",
        f"请确认后回复（如：\"我审批同意，可继续\"），Agent 将自动写入授权文件。",
    ]
    return "\n".join(lines)


def confirm_authorization(contract_path: Path, confirmation_quote: str, *, force: bool = False) -> Path:
    """Write the ``*.session_authorization.json`` file after owner confirmation.

    Parameters
    ----------
    contract_path:
        Path to the contract JSON file.
    confirmation_quote:
        The owner's verbatim confirmation statement (e.g.
        ``"我审批同意，可继续"``).

    Returns
    -------
    Path to the generated authorization file.

    Raises
    ------
    FileExistsError
        If the authorization file already exists (prevents accidental overwrite).
    ValueError
        If the contract file is invalid.
    """
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    experiment_id: str = contract.get("experiment_id", "")
    if not experiment_id:
        raise ValueError("contract has no experiment_id")
    if not confirmation_quote.strip():
        raise ValueError("owner confirmation quote must not be empty")

    auth_path = contract_path.with_name(f"{contract_path.stem}.session_authorization.json")
    if auth_path.exists() and not force:
        raise FileExistsError(
            f"Authorization file already exists: {auth_path}\n"
            "Delete it first or use --force to overwrite."
        )

    # A verbal confirmation approves the exact pending candidate whose scope
    # was previewed. Freeze the budget and candidate status before hashing the
    # authorization so the contract and record cannot disagree.
    metadata = contract.get("_metadata")
    if isinstance(metadata, dict) and metadata.get("candidate_status") == "pending_owner_review":
        contract_errors = validate_contract(contract)
        if contract_errors:
            raise ValueError("pending candidate contract is invalid: " + "; ".join(contract_errors))
        execution = contract.get("execution")
        if not isinstance(execution, dict):
            raise ValueError("pending candidate has no execution section")
        cost = execution.get("cost_budget")
        if not isinstance(cost, dict) or not isinstance(cost.get("amount"), (int, float)) or cost["amount"] <= 0:
            raise ValueError("pending candidate requires a positive frozen cost budget")
        status = cost.get("status")
        if status not in {"PENDING_OWNER_REVIEW", "FROZEN"}:
            raise ValueError("pending candidate cost budget has an unsupported status")
        now = _utc_now()
        metadata["candidate_status"] = "approved"
        metadata["owner_confirmation_status"] = "confirmed_in_session_" + now[:10]
        metadata["candidate_approved_at"] = now
        cost["status"] = "FROZEN"
        serialized = json.dumps(contract, ensure_ascii=False, indent=2) + "\n"
        contract_path.write_text(serialized, encoding="utf-8", newline="\n")
        digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
        sidecar = contract_path.with_suffix(contract_path.suffix + ".sha256")
        sidecar.write_text(f"{digest}  {contract_path.name}\n", encoding="utf-8", newline="\n")

    # Build scope summary
    execution = contract.get("execution", {})
    cost = execution.get("cost_budget", {})
    workload = contract.get("workload", {})
    variants = workload.get("variant_matrix", []) if isinstance(workload, dict) else []
    statistical_plan = contract.get("statistical_plan", {})
    primary_pair = statistical_plan.get("primary_pair", []) if isinstance(statistical_plan, dict) else []
    candidate_metadata = contract.get("_metadata", {})
    planned_runs = candidate_metadata.get("candidate_expected_run_count") if isinstance(candidate_metadata, dict) else None
    scope = (
        f"{experiment_id}: "
        f"{execution.get('task_count', '?')} task(s), "
        f"USD {cost.get('amount', '?')} ceiling, "
        f"model {contract.get('model', {}).get('model_id', '?')}, "
        f"variants {', '.join(str(item) for item in variants) if variants else 'unspecified'}, "
        f"primary pair {' vs '.join(str(item) for item in primary_pair) if primary_pair else 'unspecified'}, "
        f"planned runs {planned_runs if planned_runs is not None else 'unspecified'}. "
        f"Excludes any experiment not explicitly listed in this contract."
    )

    payload: dict[str, Any] = {
        "schema_version": SESSION_AUTH_SCHEMA_VERSION,
        "authorization_type": AUTHORIZATION_TYPE,
        "status": APPROVED_STATUS,
        "experiment_id": experiment_id,
        "approved_by": APPROVED_BY,
        "approved_at": _utc_now(),
        "confirmation_quote": confirmation_quote.strip(),
        "scope": scope,
        "contract_sha256": hashlib.sha256(canonical_json(contract).encode("utf-8")).hexdigest(),
    }

    auth_path.parent.mkdir(parents=True, exist_ok=True)
    auth_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return auth_path


def get_authorization_path(contract_path: Path) -> Path:
    """Return the path where the session authorization file should live.

    Checks for an existing file and returns the path; does not validate
    content (that is done by ``formal_execution_errors``).
    """
    marker_path = contract_path.with_name(f"{contract_path.stem}.approval_marker.json")
    session_path = contract_path.with_name(f"{contract_path.stem}.session_authorization.json")
    if session_path.is_file():
        return session_path
    return marker_path


def has_valid_authorization(contract_path: Path) -> bool:
    """Return True if a valid marker or session-authorization file exists."""
    auth_path = get_authorization_path(contract_path)
    if not auth_path.is_file():
        return False
    try:
        from cactus.governance.schema import (
            validate_approval_marker,
            validate_session_authorization,
        )
        data = json.loads(auth_path.read_text(encoding="utf-8"))
        if "session_confirmation" in auth_path.name:
            return not validate_session_authorization(data)
        return not validate_approval_marker(data)
    except Exception:
        return False
