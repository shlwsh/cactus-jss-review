"""Offline governance primitives for CACTUS experimental evidence."""
