"""Resolve immutable historical logical paths after external quarantine.

The project keeps the manifest and its digest. Machine-specific storage roots
live outside the repository. Quarantine never grants publication admission.
"""
from __future__ import annotations

from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat

from cactus.governance.canonical import canonical_json


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def relative_path(value: str) -> str:
    if (not isinstance(value, str) or not value or "\\" in value or ":" in value
            or value.startswith("/") or any(p in {"", ".", ".."} for p in value.split("/"))):
        raise ValueError("unsafe evidence relative path")
    return PurePosixPath(value).as_posix()


def no_links(path: Path) -> None:
    """Reject Windows reparse points as well as POSIX symbolic links."""
    if path.exists() or path.is_symlink():
        info = path.lstat()
        if path.is_symlink() or getattr(info, "st_file_attributes", 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise ValueError("linked evidence path: " + str(path))


def confined(base: Path, relative: str) -> Path:
    base = base.absolute()
    relative = relative_path(relative)
    for ancestor in [*reversed(base.parents), base]:
        no_links(ancestor)
    target = base / relative
    current = base
    for part in PurePosixPath(relative).parts:
        current = current / part
        no_links(current)
    target.resolve().relative_to(base.resolve())
    return target


def fingerprint(directory: Path) -> dict:
    no_links(directory)
    if not directory.is_dir():
        raise ValueError("missing evidence directory: " + str(directory))
    members = sorted(directory.rglob("*"))
    for path in members:
        no_links(path)
        path.resolve().relative_to(directory.resolve())
    hashes = {p.relative_to(directory).as_posix(): sha256(p) for p in members if p.is_file()}
    return {"file_hashes_relative_to_directory": hashes,
            "content_sha256": hashlib.sha256(canonical_json(hashes).encode()).hexdigest(),
            "file_count": len(hashes), "bytes": sum(p.stat().st_size for p in members if p.is_file()),
            "directories": [p.relative_to(directory).as_posix() for p in members if p.is_dir()]}


def location_config_path() -> Path:
    override = os.environ.get("CACTUS_EVIDENCE_LOCATIONS")
    if override:
        return Path(override).absolute()
    return Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local/share"))) / "CACTUS/evidence_locations.json"


class EvidenceLocations:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.entries: dict[str, tuple[Path, dict]] = {}
        catalog_path = confined(self.root, "experiments/quarantine/catalog.json")
        if not catalog_path.exists():
            return
        catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
        config = json.loads(location_config_path().read_text(encoding="utf-8"))
        from jsonschema import Draft202012Validator
        for name, payload in (("quarantine_catalog", catalog),):
            schema = json.loads((self.root / f"experiments/schemas/{name}.schema.json").read_text(encoding="utf-8"))
            Draft202012Validator(schema).validate(payload)
        for batch in catalog["batches"]:
            manifest_path = confined(self.root, batch["manifest_path"])
            if not batch["manifest_path"].startswith("experiments/quarantine/") or sha256(manifest_path) != batch["manifest_sha256"]:
                raise ValueError("quarantine manifest binding mismatch")
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            schema = json.loads((self.root / "experiments/schemas/quarantine_manifest.schema.json").read_text(encoding="utf-8"))
            Draft202012Validator(schema).validate(manifest)
            if manifest["storage_id"] != batch["storage_id"]:
                raise ValueError("quarantine storage identity mismatch")
            base = Path(config["storage_roots"][batch["storage_id"]])
            if not base.is_absolute():
                raise ValueError("storage root must be absolute")
            base.resolve().relative_to(base.anchor)
            if base.resolve() == Path(base.anchor) or base.resolve().is_relative_to(self.root):
                raise ValueError("quarantine must use a dedicated external directory")
            for row in manifest["entries"]:
                logical = relative_path(row["original_path"])
                if logical != "experiments/runs/" + row["run_id"] or logical in self.entries:
                    raise ValueError("duplicate or invalid quarantine logical identity")
                physical = confined(base, row["storage_relative_path"])
                if physical.name != row["run_id"]:
                    raise ValueError("quarantine directory identity mismatch")
                actual = fingerprint(physical)
                if any(actual[key] != row[key] for key in actual):
                    raise ValueError("quarantine bytes or directory set drift: " + row["run_id"])
                original = confined(self.root, logical)
                if original.exists() and fingerprint(original) != actual:
                    raise ValueError("conflicting active/quarantine evidence: " + row["run_id"])
                self.entries[logical] = physical, row

    def resolve(self, relative: str) -> Path:
        relative = relative_path(relative)
        parts = PurePosixPath(relative).parts
        logical = "/".join(parts[:3])
        if logical in self.entries:
            physical, row = self.entries[logical]
            if len(parts) == 3:
                return physical
            suffix = "/".join(parts[3:])
            path = confined(physical, suffix)
            expected = row["file_hashes_relative_to_directory"].get(suffix)
            if path.is_file() and (expected is None or sha256(path) != expected):
                raise ValueError("quarantined source hash mismatch: " + relative)
            return path
        return confined(self.root, relative)

    def logical(self, physical: Path) -> str:
        physical = physical.resolve()
        if physical.is_relative_to(self.root):
            return physical.relative_to(self.root).as_posix()
        for logical, (base, _) in self.entries.items():
            if physical == base.resolve():
                return logical
            if physical.is_relative_to(base.resolve()):
                return logical + "/" + physical.relative_to(base.resolve()).as_posix()
        raise ValueError("unregistered external evidence path")

    def runs(self):
        active = self.root / "experiments/runs"
        logicals = {"experiments/runs/" + p.name for p in active.iterdir() if p.is_dir()} if active.exists() else set()
        # Preserve the original host Path ordering (case-insensitive on Windows)
        # so relocation can replay frozen JSONL snapshots byte-for-byte.
        for logical in sorted(logicals | self.entries.keys(), key=Path):
            yield logical, self.resolve(logical)


@lru_cache(maxsize=8)
def locations(root: Path) -> EvidenceLocations:
    return EvidenceLocations(root)


def resolve_source(root: Path, relative: str) -> Path:
    return locations(root.resolve()).resolve(relative)


def logical_source(root: Path, physical: Path) -> str:
    return locations(root.resolve()).logical(physical)


def iter_runs(root: Path):
    return locations(root.resolve()).runs()
