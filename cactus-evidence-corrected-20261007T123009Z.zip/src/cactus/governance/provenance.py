"""Generation-time provenance sidecar writer and verifier."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .canonical import utc_now
from .schema import validate_artifact_provenance


def write_sidecar(artifact: Path, *, artifact_id: str, artifact_type: str, generator_path: str, inputs: list[dict[str, str]], transform_id: str, commit: str = "") -> Path:
    payload: dict[str, Any] = {
        "schema_version": "2.0", "artifact_id": artifact_id, "artifact_type": artifact_type,
        "artifact_path": artifact.as_posix(), "artifact_sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
        "generated_at": utc_now(), "generator": {"path": generator_path, "commit": commit, "version": "0.1.0", "arguments": []},
        "inputs": inputs, "transform": {"transform_id": transform_id, "parameters": {}},
    }
    errors = validate_artifact_provenance(payload)
    if errors:
        raise ValueError("invalid artifact provenance sidecar: " + "; ".join(errors))
    sidecar = artifact.with_name(f"{artifact.stem}_provenance.json")
    sidecar.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    return sidecar


def verify_sidecar(artifact: Path) -> list[str]:
    sidecar = artifact.with_name(f"{artifact.stem}_provenance.json")
    if not sidecar.exists():
        return ["missing provenance sidecar"]
    data = json.loads(sidecar.read_text(encoding="utf-8"))
    actual = hashlib.sha256(artifact.read_bytes()).hexdigest()
    return [] if data.get("artifact_sha256") == actual else ["artifact hash mismatch"]
