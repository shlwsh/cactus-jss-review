"""Machine-readable G0-G8 pre/post gate aggregation."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from cactus.governance.contract import validate_contract
from cactus.governance.schema import validate_raw_result, validate_run_manifest


@dataclass(frozen=True, slots=True)
class GateResult:
    gate: str
    code: str
    verdict: str
    message: str


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_gates(contract: dict[str, Any], *, project_root: Path, manifest: dict[str, Any] | None = None, raw_result: dict[str, Any] | None = None, stats: dict[str, Any] | None = None, artifacts: list[dict[str, str]] | None = None) -> list[dict[str, str]]:
    results: list[GateResult] = []
    contract_errors = validate_contract(contract)
    results.append(GateResult("G0", "G0-CONTRACT", "PASS" if not contract_errors else "FAIL", "contract valid" if not contract_errors else "; ".join(contract_errors)))
    source = contract.get("source", {})
    if isinstance(source, dict) and source.get("git_commit"):
        results.append(GateResult("G0", "G0-COMMIT", "PASS" if len(str(source["git_commit"])) == 40 else "FAIL", "commit identifier shape checked"))
    workload = contract.get("workload", {})
    derivation = contract.get("derivation", {})
    for label, item in (("workload", workload), ("derivation", derivation)):
        if not isinstance(item, dict):
            results.append(GateResult("G1", f"G1-{label}", "FAIL", f"{label} missing"))
            continue
        path_value = item.get("driver" if label == "workload" else "script")
        path = project_root / str(path_value) if isinstance(path_value, str) else None
        expected = item.get("sha256")
        passed = bool(path and path.exists() and isinstance(expected, str) and _hash(path) == expected)
        results.append(GateResult("G1", f"G1-{label}", "PASS" if passed else "FAIL", f"{label} hash checked"))
    host_profile = contract.get("host_profile")
    host_snapshot = (manifest or {}).get("environment") if isinstance(manifest, dict) else None
    if isinstance(host_profile, dict) and isinstance(host_snapshot, dict):
        passed = host_snapshot.get("architecture") == host_profile.get("architecture")
        results.append(GateResult("G2", "G2-HOST", "PASS" if passed else "FAIL", "host architecture checked"))
    else:
        results.append(GateResult("G2", "G2-HOST", "FAIL", "host profile and observed snapshot are required"))
    results.append(GateResult("G3", "G3-PROVISION", "PASS", "provision check delegated to runtime runner"))
    if isinstance(workload, dict):
        valid_workload = isinstance(workload.get("seed"), int) and workload.get("seed", -1) >= 0 and isinstance(workload.get("measure_sec"), int) and workload.get("measure_sec", 0) >= 30 and isinstance(workload.get("repetitions"), int) and workload.get("repetitions", 0) >= 1
        results.append(GateResult("G4", "G4-WORKLOAD", "PASS" if valid_workload else "FAIL", "workload parameters checked"))
    if manifest is not None:
        errors = validate_run_manifest(manifest)
        results.append(GateResult("G5", "G5-MANIFEST", "PASS" if not errors else "FAIL", "manifest valid" if not errors else "; ".join(errors)))
    if raw_result is not None:
        errors = validate_raw_result(raw_result)
        results.append(GateResult("G5", "G5-RAW", "PASS" if not errors else "FAIL", "raw result valid" if not errors else "; ".join(errors)))
    if manifest is not None and raw_result is not None:
        results.append(GateResult("G6", "G6-DERIVATION", "PASS", "derivation input available for deterministic check"))
    # G7 is deliberately fail-closed: publication claims require derived
    # statistics with a positive sample count and explicit uncertainty.
    stats_payload = stats.get("statistics") if isinstance(stats, dict) and isinstance(stats.get("statistics"), dict) else stats
    stats_ok = isinstance(stats_payload, dict) and isinstance(stats_payload.get("n"), int) and stats_payload["n"] > 0 and isinstance(stats_payload.get("mean"), (int, float)) and isinstance(stats_payload.get("ci95"), list) and len(stats_payload["ci95"]) == 2
    results.append(GateResult("G7", "G7-STATS", "PASS" if stats_ok else "FAIL", "statistical summary checked" if stats_ok else "n, mean and ci95 are required"))
    # G8 verifies that every declared artifact exists and carries a full hash.
    artifact_ok = isinstance(artifacts, list) and bool(artifacts)
    if artifact_ok:
        for item in artifacts:
            path = project_root / item.get("path", "")
            artifact_ok = artifact_ok and path.is_file() and isinstance(item.get("sha256"), str) and len(item["sha256"]) == 64 and _hash(path) == item["sha256"]
    results.append(GateResult("G8", "G8-ARTIFACT", "PASS" if artifact_ok else "FAIL", "artifact hashes checked" if artifact_ok else "declared artifacts with matching SHA-256 are required"))
    return [asdict(result) for result in results]
