"""Deterministic serialization and identifiers used by experiment evidence."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import PurePosixPath
from uuid import uuid4

RUN_ID_RE = re.compile(r"^RUN-\d{8}T\d{6}Z-[0-9A-F]{6,8}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def canonical_json(value: object) -> str:
    """Serialize JSON deterministically for configuration hashing."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def sha256_json(value: object) -> str:
    return sha256_text(canonical_json(value))


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_run_id(now: datetime | None = None) -> str:
    current = now or datetime.now(timezone.utc)
    return f"RUN-{current.strftime('%Y%m%dT%H%M%SZ')}-{uuid4().hex[:8].upper()}"


def safe_relative_path(path: str) -> bool:
    """Reject absolute and traversal paths before a manifest is persisted."""
    normalized = path.replace("\\", "/")
    candidate = PurePosixPath(normalized)
    has_windows_drive = bool(re.match(r"^[A-Za-z]:/", normalized))
    return not candidate.is_absolute() and not has_windows_drive and ".." not in candidate.parts and bool(candidate.parts)
