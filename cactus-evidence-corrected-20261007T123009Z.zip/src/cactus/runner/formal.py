"""Fail-closed authorization gate for formal experiment execution.

This module deliberately does not start agents or models.  It only verifies
that a reviewed contract is authorized and passes the existing integrity
preflight before a future formal runner may be invoked.

Authorization may be supplied by either of two mechanisms:

1. Legacy physical marker: owner manually creates
   ``*.approval_marker.json`` on the filesystem (schema: approval_marker.schema.json).

2. Session confirmation (preferred): owner confirms verbally in the session,
   and the Agent writes ``*.session_authorization.json`` by running:

       cactus session-auth request <contract>   # preview scope
       # owner confirms (e.g. "我审批同意，可继续")
       cactus session-auth confirm <contract> --quote "我审批同意，可继续"

   Both mechanisms are accepted; the session path requires no filesystem
   editing by the owner.
"""

from __future__ import annotations

import json
import hashlib
import re
from pathlib import Path
from typing import Any

from cactus.governance.canonical import canonical_json
from cactus.governance.contract import validate_contract
from cactus.governance.schema import validate_approval_marker, validate_session_authorization
from cactus.runner.preflight import preflight


_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _formal_image_errors(contract: dict[str, Any]) -> list[str]:
    """Require immutable image provenance at the formal execution boundary."""

    images = contract.get("images")
    if not isinstance(images, dict) or not images:
        return ["formal execution requires a non-empty images catalog with complete SHA-256 digests"]
    errors: list[str] = []
    for name, image in sorted(images.items(), key=lambda item: str(item[0])):
        digest = image.get("digest") if isinstance(image, dict) else None
        if not isinstance(digest, str) or not _IMAGE_DIGEST.fullmatch(digest):
            errors.append(f"images.{name}.digest must be a complete sha256 digest for formal execution")
    return errors


def formal_execution_errors(
    contract: dict[str, Any],
    *,
    project_root: Path,
    approval_path: Path | None = None,
    require_clean_tree: bool = True,
) -> list[str]:
    """Return blocking errors; an empty list is the only executable state.

    Authorization may be supplied by the legacy physical marker or by an
    explicit session-confirmation record. Either form must contain ``status:
    approved`` and the exact experiment id; absence of both remains blocking.
    """

    errors = preflight(contract, project_root=project_root, require_clean_tree=require_clean_tree)
    metadata = contract.get("_metadata", {}) if isinstance(contract, dict) else {}
    candidate_status = metadata.get("candidate_status") if isinstance(metadata, dict) else None
    if candidate_status is not None and candidate_status != "approved":
        errors.append("formal execution is blocked: contract candidate is pending owner review")
    errors.extend(_formal_image_errors(contract))
    if approval_path is None:
        errors.append("formal execution requires an explicit approval marker; session authorization record is also accepted")
        return errors
    authorization_path = approval_path
    authorization_kind = "marker"
    if not authorization_path.is_file():
        session_path = approval_path.with_name(approval_path.name.replace(".approval_marker.json", ".session_authorization.json"))
        if session_path.is_file():
            authorization_path = session_path
            authorization_kind = "session"
        else:
            errors.append(f"approval record does not exist: {approval_path} or {session_path}")
            return errors
    try:
        approval = json.loads(authorization_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"approval record is not valid JSON: {exc}")
        return errors
    if not isinstance(approval, dict):
        errors.append("approval record must be a JSON object")
    else:
        errors.extend(validate_session_authorization(approval) if authorization_kind == "session" else validate_approval_marker(approval))
    if isinstance(approval, dict) and approval.get("experiment_id") != contract.get("experiment_id"):
        errors.append("approval marker experiment_id does not match contract" if authorization_kind == "marker" else "session authorization experiment_id does not match contract")
    if authorization_kind == "session" and isinstance(approval, dict) and approval.get("contract_sha256"):
        expected_contract_sha256 = hashlib.sha256(canonical_json(contract).encode("utf-8")).hexdigest()
        if approval.get("contract_sha256") != expected_contract_sha256:
            errors.append("session authorization contract_sha256 does not match contract")
    return errors


def assert_formal_execution_allowed(*args: Any, **kwargs: Any) -> None:
    """Raise ``RuntimeError`` unless :func:`formal_execution_errors` is clean."""

    errors = formal_execution_errors(*args, **kwargs)
    if errors:
        raise RuntimeError("formal execution blocked: " + "; ".join(errors))
