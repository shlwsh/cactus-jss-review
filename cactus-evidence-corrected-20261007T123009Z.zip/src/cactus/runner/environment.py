"""Local environment snapshots with explicit capture mode and redaction."""

from __future__ import annotations

import platform
import sys
from pathlib import Path
from typing import Any

from cactus.governance.redaction import redact
from cactus.governance.canonical import utc_now


def capture_environment(*, capture_mode: str = "observed", extra: dict[str, Any] | None = None) -> dict[str, Any]:
    if capture_mode not in {"observed", "reconstructed"}:
        raise ValueError("capture_mode must be observed or reconstructed")
    snapshot: dict[str, Any] = {"schema_version": "2.0", "capture_mode": capture_mode, "generated_at": utc_now(), "python": sys.version.split()[0], "platform": platform.platform(), "architecture": platform.machine(), "processor": platform.processor()}
    if capture_mode == "reconstructed":
        snapshot.update({"reconstructed_at": utc_now(), "reconstruction_confidence": "low", "evidence_sources": [], "unknown_fields": ["runtime_processes", "container_digest"]})
    if extra:
        snapshot["extra"] = redact(extra)
    return redact(snapshot)


def validate_host_profile(snapshot: dict[str, Any], profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if snapshot.get("architecture") != profile.get("architecture"):
        errors.append("architecture mismatch")
    if profile.get("python_min") and tuple(map(int, str(snapshot.get("python", "0")).split(".")[:2])) < tuple(map(int, str(profile["python_min"]).split(".")[:2])):
        errors.append("python version below profile minimum")
    return errors


def main() -> int:
    """Capture a redacted local snapshot without provisioning or network access."""
    import argparse
    import json
    parser = argparse.ArgumentParser(prog="cactus-environment")
    parser.add_argument("phase", choices=("pre", "post"))
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--capture-mode", choices=("observed", "reconstructed"), default="observed")
    args = parser.parse_args()
    snapshot = capture_environment(capture_mode=args.capture_mode, extra={"phase": args.phase})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(snapshot, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(snapshot, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
