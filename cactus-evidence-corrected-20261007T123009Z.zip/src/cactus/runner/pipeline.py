"""Offline fixture pipeline from simulated raw data to derived report."""

from __future__ import annotations

import json
from pathlib import Path

from cactus.analysis.report import build_report
from cactus.evaluation.derive import derive_stats
from cactus.runner.bundle_validator import validate_bundle
from cactus.runner.exploratory import create_simulated_run
from cactus.trace.store import TraceStore


def run_fixture_pipeline(root: Path, *, commit: str = "0" * 40) -> dict[str, object]:
    run_root = create_simulated_run(root / "runs", study_id="MSCC-RQ1", experiment_id="EXP-FIXTURE", commit=commit, values=[1, 2, 3], seal=False)
    raw = json.loads((run_root / "raw" / "result.json").read_text(encoding="utf-8"))
    derived = derive_stats(raw)
    derived_path = run_root / "derived" / "stats.json"
    derived_path.parent.mkdir(parents=True, exist_ok=True)
    derived_path.write_text(json.dumps(derived, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    from cactus.trace.bundle import RunBundle
    RunBundle(run_root).seal()
    bundle_errors = validate_bundle(run_root)
    report_path = build_report(run_root / "events.jsonl", root / "report.md", run_id=run_root.name) if (run_root / "events.jsonl").exists() else None
    return {"run_id": run_root.name, "bundle_errors": bundle_errors, "derived_path": str(derived_path), "report_path": str(report_path) if report_path else None, "origin_type": "simulated"}
