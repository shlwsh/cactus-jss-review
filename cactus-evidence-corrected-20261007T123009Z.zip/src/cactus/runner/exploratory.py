"""Explicitly simulated, non-public exploratory RUN creation for fixtures."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from cactus.governance.canonical import new_run_id, utc_now
from cactus.trace.manifest import initialize_bundle


def create_simulated_run(root: Path, *, study_id: str, experiment_id: str, commit: str, values: list[float], seal: bool = True) -> Path:
    """Create a clearly simulated bundle for pipeline tests only.

    The bundle has no publication result and must never be promoted to an
    observed/measured baseline by the registry layer.
    """
    run_id = new_run_id()
    bundle = initialize_bundle(root / run_id, study_id=study_id, experiment_id=experiment_id, run_id=run_id, commit=commit, config={"mode": "simulated"}, environment={"capture_mode": "observed"}, command=["cactus", "exploratory" ])
    bundle.write_json("raw/result.json", {"schema_version": "2.0", "run_id": run_id, "experiment_id": experiment_id, "generated_at": utc_now(), "data": {"values": values}, "evidence": {"origin_type": "simulated"}})
    if seal:
        bundle.seal()
    return bundle.root
