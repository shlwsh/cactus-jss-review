"""Prediction checkout and evaluator image source-alignment gate."""

from __future__ import annotations

import hashlib
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


CommandRunner = Callable[[list[str], Path, int], subprocess.CompletedProcess[str]]


class SourceAlignmentError(RuntimeError):
    code = "source_alignment_error"


@dataclass(frozen=True, slots=True)
class SourceSnapshot:
    head: str
    tracked_clean: bool
    tracked_status: str
    manifest_sha256: str
    tracked_files: tuple[dict[str, str], ...]


def _require(result: subprocess.CompletedProcess[str], label: str) -> str:
    if result.returncode:
        raise SourceAlignmentError(f"source_alignment_error: {label} failed")
    return result.stdout


def _manifest(ls_tree: str) -> tuple[str, tuple[dict[str, str], ...]]:
    records: list[dict[str, str]] = []
    canonical: list[str] = []
    for line in ls_tree.splitlines():
        if not line.strip():
            continue
        prefix, separator, path = line.partition("\t")
        fields = prefix.split()
        if not separator or len(fields) != 3:
            raise SourceAlignmentError("source_alignment_error: malformed tracked-file manifest")
        mode, object_type, object_id = fields
        record_text = f"{mode}\0{object_type}\0{object_id}\0{path}"
        record_sha = hashlib.sha256(record_text.encode("utf-8")).hexdigest()
        records.append({
            "path": path,
            "mode": mode,
            "object_type": object_type,
            "object_id": object_id,
            "sha256": record_sha,
        })
        canonical.append(record_text)
    if not records:
        raise SourceAlignmentError("source_alignment_error: tracked-file manifest is empty")
    digest = hashlib.sha256("\n".join(canonical).encode("utf-8")).hexdigest()
    return digest, tuple(records)


def _snapshot_checkout(checkout: Path, runner: CommandRunner) -> SourceSnapshot:
    head = _require(runner(["git", "-C", str(checkout), "rev-parse", "HEAD"], checkout, 30), "checkout HEAD").strip()
    status = _require(
        runner(["git", "-C", str(checkout), "status", "--porcelain", "--untracked-files=no"], checkout, 30),
        "checkout tracked status",
    ).strip()
    tree = _require(
        runner(["git", "-C", str(checkout), "ls-tree", "-r", "--full-tree", "HEAD"], checkout, 60),
        "checkout tracked manifest",
    )
    digest, records = _manifest(tree)
    return SourceSnapshot(head, not bool(status), status, digest, records)


def _snapshot_image(image: str, project_root: Path, runner: CommandRunner) -> SourceSnapshot:
    prefix = [os.environ.get("CACTUS_DOCKER_BIN", "docker"), "run", "--rm", "--pull=never", image, "git", "-C", "/testbed"]
    head = _require(runner(prefix + ["rev-parse", "HEAD"], project_root, 120), "image HEAD").strip()
    status = _require(
        runner(prefix + ["status", "--porcelain", "--untracked-files=no"], project_root, 120),
        "image tracked status",
    ).strip()
    tree = _require(
        runner(prefix + ["ls-tree", "-r", "--full-tree", "HEAD"], project_root, 180),
        "image tracked manifest",
    )
    digest, records = _manifest(tree)
    return SourceSnapshot(head, not bool(status), status, digest, records)


def verify_source_alignment(
    *,
    checkout: Path,
    image: str,
    base_commit: str,
    project_root: Path,
    command_runner: CommandRunner,
) -> dict[str, object]:
    """Compare immutable Git trees and tracked cleanliness before prediction."""
    local = _snapshot_checkout(checkout, command_runner)
    evaluator = _snapshot_image(image, project_root, command_runner)
    errors: list[str] = []
    if local.head != base_commit:
        errors.append("checkout_head_mismatch")
    if evaluator.head != base_commit:
        errors.append("evaluator_head_mismatch")
    if not local.tracked_clean:
        errors.append("checkout_tracked_drift")
    if not evaluator.tracked_clean:
        errors.append("evaluator_tracked_drift")
    if local.manifest_sha256 != evaluator.manifest_sha256 or local.tracked_files != evaluator.tracked_files:
        errors.append("tracked_manifest_mismatch")
    result: dict[str, object] = {
        "schema_version": "1.0",
        "status": "passed" if not errors else "source_alignment_error",
        "base_commit": base_commit,
        "image": image,
        "checkout": {
            "head": local.head,
            "tracked_clean": local.tracked_clean,
            "tracked_status": local.tracked_status,
            "manifest_sha256": local.manifest_sha256,
            "tracked_file_count": len(local.tracked_files),
            "tracked_files": list(local.tracked_files),
        },
        "evaluator": {
            "head": evaluator.head,
            "tracked_clean": evaluator.tracked_clean,
            "tracked_status": evaluator.tracked_status,
            "manifest_sha256": evaluator.manifest_sha256,
            "tracked_file_count": len(evaluator.tracked_files),
            "tracked_files": list(evaluator.tracked_files),
        },
        "errors": errors,
        "model_call_allowed": not errors,
    }
    if errors:
        error = SourceAlignmentError("source_alignment_error: " + ", ".join(errors))
        error.result = result  # type: ignore[attr-defined]
        raise error
    return result
