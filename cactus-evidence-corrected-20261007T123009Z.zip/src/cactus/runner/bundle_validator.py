"""Fail-closed validator for CACTUS RUN bundles and clean-room readiness."""

from __future__ import annotations

import hashlib
import json
import subprocess
import re
from pathlib import Path
from typing import Any

from cactus.governance.canonical import canonical_json
from cactus.governance.schema import validate_raw_result, validate_run_manifest


REQUIRED_RUN_FILES = ("run_manifest.json", "resolved_config.json", "checksums.sha256")


def validate_bundle(root: Path) -> list[str]:
    errors: list[str] = []
    for name in REQUIRED_RUN_FILES:
        if not (root / name).exists():
            errors.append(f"missing required bundle file: {name}")
    if errors:
        return errors
    try:
        manifest = json.loads((root / "run_manifest.json").read_text(encoding="utf-8"))
        config = json.loads((root / "resolved_config.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return [f"invalid manifest/config JSON: {error}"]
    errors.extend(validate_run_manifest(manifest))
    if manifest.get("run_id") != root.name:
        errors.append("manifest run_id differs from directory identity")
    expected_config_hash = hashlib.sha256(canonical_json(config).encode("utf-8")).hexdigest()
    if manifest.get("configuration", {}).get("sha256") != expected_config_hash:
        errors.append("configuration canonical hash mismatch")
    raw_path = root / "raw" / "result.json"
    if raw_path.exists():
        try:
            raw = json.loads(raw_path.read_text(encoding="utf-8"))
            errors.extend(validate_raw_result(raw))
            for field in ("run_id", "experiment_id"):
                if raw.get(field) != manifest.get(field):
                    errors.append(f"raw/manifest identity mismatch: {field}")
        except (OSError, json.JSONDecodeError) as error:
            errors.append(f"invalid raw result JSON: {error}")
    errors.extend(_verify_existing_bundle(root))
    for item in manifest.get("outputs", []):
        if not isinstance(item, dict):
            continue
        path = _safe_path(root, item.get("path"))
        if path is None or not path.is_file() or _sha(path) != item.get("sha256"):
            errors.append(f"manifest output mismatch: {item.get('path', '<missing>')}")
    env = manifest.get("environment", {})
    for phase in ("pre", "post"):
        relative = env.get(f"{phase}_path")
        if relative:
            path = _safe_path(root, relative)
            if path is None or not path.is_file() or _sha(path) != env.get(f"{phase}_sha256"):
                errors.append(f"environment snapshot binding mismatch: {phase}")
    return errors


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_path(root: Path, relative: object) -> Path | None:
    if not isinstance(relative, str) or not relative or "\\" in relative:
        return None
    path = Path(relative)
    if path.is_absolute() or ":" in relative or ".." in path.parts:
        return None
    target = (root / path).resolve()
    return target if root.resolve() in target.parents else None


def _verify_existing_bundle(root: Path) -> list[str]:
    checksums = root / "checksums.sha256"
    expected: set[str] = set()
    errors: list[str] = []
    for line in checksums.read_text(encoding="utf-8").splitlines():
        if not line.strip() or "  " not in line:
            errors.append("invalid checksum line")
            continue
        digest, relative = line.split("  ", 1)
        if not re.fullmatch(r"[0-9a-f]{64}", digest) or relative in expected:
            errors.append("invalid or duplicate checksum entry")
            continue
        expected.add(relative)
        path = _safe_path(root, relative)
        if path is None:
            errors.append("unsafe checksum path")
            continue
        if not path.is_file() or _sha(path) != digest:
            errors.append(f"checksum mismatch: {relative}")
    actual = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file() and path.name != "checksums.sha256"}
    errors.extend(f"unlisted file: {path}" for path in sorted(actual - expected))
    return errors


def clean_room_ready(project_root: Path) -> tuple[bool, list[str]]:
    """Check only local prerequisites; never clones, pulls or executes workloads."""
    errors: list[str] = []
    git = subprocess.run(["git", "status", "--porcelain"], cwd=project_root, capture_output=True, text=True, check=False)
    if git.returncode != 0:
        errors.append("git status unavailable")
    elif git.stdout.strip():
        errors.append("working tree is not clean")
    if not (project_root / "pyproject.toml").exists():
        errors.append("pyproject.toml missing")
    return not errors, errors
