"""Batch orchestration for CACTUS predictions and the official SWE-bench harness.

The module deliberately owns only orchestration and immutable evidence
capture.  It neither reimplements the public benchmark nor interprets the
official evaluator's result format.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Sequence, TypeVar

from cactus.adapters.benchmark import BenchmarkTask, load_evaluation_test_ids, load_manifest
from cactus.governance.canonical import canonical_json, new_run_id, utc_now
from cactus.governance.provenance import verify_sidecar
from cactus.runner.formal import formal_execution_errors
from cactus.runner.bundle_validator import validate_bundle
from cactus.runner.model_binding import model_contract_errors
from cactus.runner.source_alignment import SourceAlignmentError, verify_source_alignment
from cactus.telemetry.litellm_billing import collect_spend_logs, collect_spend_logs_postgres_ssh
from cactus.trace.bundle import RunBundle


CommandRunner = Callable[[list[str], Path, int], subprocess.CompletedProcess[str]]
_TaskT = TypeVar("_TaskT")
_TEST_AWARE_CAMPAIGN_VARIANTS = frozenset({"cactus_test_aware", "cactus_no_semantic", "cactus_no_iteration"})


def _image_tools(
    project_root: Path,
    command_runner: CommandRunner,
    *,
    lookahead: int,
    cache_root: Path | None = None,
):
    """Load image lifecycle helpers and adapt the campaign command runner."""
    scripts_root = Path(__file__).resolve().parents[3] / "scripts"
    if str(scripts_root) not in sys.path:
        sys.path.insert(0, str(scripts_root))
    from _image_lifecycle import ImageLifecycle, TaskWarmupPool

    def run_docker(argv: list[str], **_: object) -> subprocess.CompletedProcess[str]:
        return command_runner(argv, project_root, 1800)

    return ImageLifecycle(
        cache_root=cache_root or Path(os.environ.get("CACTUS_DOCKER_CACHE_ROOT", "E:/docker-bak/cactus/pilot50")),
        docker_binary=os.environ.get("CACTUS_DOCKER_BIN", "docker"),
        runner=run_docker,
        idle_seconds=0,
        keep_recent=0,
    ), TaskWarmupPool(lookahead=lookahead)


def _image_lifecycle_only(
    project_root: Path,
    command_runner: CommandRunner,
    *,
    cache_root: Path,
) -> Any:
    """Create the task-scoped image lifecycle without speculative warmup.

    Formal campaigns default to serial execution with ``warmup_lookahead=0``.
    They still must load the contract-bound archive image before evaluation and
    remove it after the task.  Keeping this path separate avoids creating a
    warmup thread pool (and therefore preserves concurrency=1).
    """
    scripts_root = Path(__file__).resolve().parents[3] / "scripts"
    if str(scripts_root) not in sys.path:
        sys.path.insert(0, str(scripts_root))
    from _image_lifecycle import ImageLifecycle

    def run_docker(argv: list[str], **_: object) -> subprocess.CompletedProcess[str]:
        return command_runner(argv, project_root, 1800)

    return ImageLifecycle(
        cache_root=cache_root,
        docker_binary=os.environ.get("CACTUS_DOCKER_BIN", "docker"),
        runner=run_docker,
        idle_seconds=0,
        keep_recent=0,
    )


@dataclass(frozen=True, slots=True)
class CampaignSummary:
    campaign_id: str
    task_count: int
    completed: int
    failed: int
    run_ids: tuple[str, ...]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_inference_task_manifest(bundle: RunBundle, task: BenchmarkTask) -> Path:
    """Persist only inference-safe task fields plus FAIL_TO_PASS identifiers."""
    if not task.fail_to_pass:
        raise RuntimeError("test-aware treatment requires frozen FAIL_TO_PASS identifiers")
    value = {
        "task_id": task.task_id,
        "repo_id": task.repo_id,
        "base_commit": task.base_commit,
        "issue_text": task.issue_text,
        "test_command": list(task.test_command),
        "split": task.split,
        "FAIL_TO_PASS": list(task.fail_to_pass),
    }
    relative_path = "raw/inference_task_manifest.jsonl"
    bundle.write_text(relative_path, json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")
    return bundle.root / relative_path


def _claim_pair_plan_execution(pair_plan_path: Path, plan_sha256: str, campaign_id: str) -> Path:
    """Atomically claim a matched-pair plan before any warmup or RUN side effect."""
    state_path = pair_plan_path.with_name(pair_plan_path.name + ".execution.json")
    payload = {
        "schema_version": 1,
        "status": "started",
        "pair_plan": pair_plan_path.as_posix(),
        "pair_plan_sha256": plan_sha256,
        "campaign_id": campaign_id,
        "started_at": utc_now(),
    }
    try:
        descriptor = os.open(state_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        # A previous execution attempt left a "prepared" state. If SHA matches,
        # upgrade to "started" and proceed (safe retry for early-exit failures).
        try:
            prior = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception:
            raise RuntimeError(
                f"paired C1 plan execution record is corrupted: {state_path.name}; remove it before retry"
            ) from exc
        # A previous execution attempt left a "prepared" or "partial" state. If SHA matches
        # and status is safe to retry, upgrade to "started" and proceed.
        # "prepared": plan created but never started
        # "partial": some pairs executed; safe to resume from next unattempted pair
        if prior.get("status") in ("prepared", "partial") and prior.get("pair_plan_sha256") == plan_sha256:
            # Safe to retry: plan unchanged, execution is resumable
            payload.update({
                "run_ids": prior.get("run_ids", []),
                "_retry_of": prior.get("started_at"),
                "_partial_retry": prior.get("status") == "partial",
            })
            descriptor = os.open(state_path, os.O_WRONLY | os.O_TRUNC)
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            return state_path
        raise RuntimeError(
            f"paired C1 plan already has an execution record: {state_path.name}; inspect it before any retry"
        ) from exc
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    return state_path


def _finish_pair_plan_execution(state_path: Path, plan_sha256: str, *, status: str, run_ids: Sequence[str]) -> None:
    """Seal a claimed pair-plan execution; interrupted runs stay visibly started."""
    state = json.loads(state_path.read_text(encoding="utf-8"))
    if state.get("status") != "started" or state.get("pair_plan_sha256") != plan_sha256:
        raise RuntimeError("paired C1 execution state changed while the campaign was running")
    state.update({"status": status, "finished_at": utc_now(), "run_ids": list(run_ids)})
    temporary_path = state_path.with_name(f".{state_path.name}.{os.getpid()}.tmp")
    temporary_path.write_text(json.dumps(state, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    os.replace(temporary_path, state_path)


def _run(command: list[str], cwd: Path, timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout, check=False)


def _run_with_temp(command: list[str], cwd: Path, timeout: int, temp_root: Path) -> subprocess.CompletedProcess[str]:
    """Run a subprocess with all common temporary-directory variables pinned."""
    environment = os.environ.copy()
    temp_path = str(temp_root)
    environment.update({"TEMP": temp_path, "TMP": temp_path, "TMPDIR": temp_path})
    return subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout, check=False, env=environment)


def _git(args: list[str], *, cwd: Path, timeout: int = 600) -> subprocess.CompletedProcess[str]:
    return _run(["git", *args], cwd, timeout)


def _require_ok(result: subprocess.CompletedProcess[str], label: str) -> None:
    if result.returncode:
        raise RuntimeError(f"{label} failed ({result.returncode}): {result.stderr.strip()}")


def select_task_batch(tasks: Sequence[_TaskT], *, batch_index: int, batch_count: int) -> tuple[_TaskT, ...]:
    """Select a deterministic contiguous batch using zero-based indexing."""
    if batch_count < 1:
        raise ValueError("batch_count must be at least 1")
    if not 0 <= batch_index < batch_count:
        raise ValueError("batch_index must be in [0, batch_count)")
    start = len(tasks) * batch_index // batch_count
    end = len(tasks) * (batch_index + 1) // batch_count
    return tuple(tasks[start:end])


def _progress(event: str, **fields: object) -> None:
    """Emit compact, flush-on-write progress logs without sensitive payloads."""
    details = " ".join(f"{key}={value}" for key, value in fields.items())
    print(f"[CACTUS][{utc_now()}] {event}" + (f" {details}" if details else ""), flush=True)


def _run_with_heartbeat(
    command_runner: CommandRunner,
    command: list[str],
    cwd: Path,
    timeout: int,
    *,
    phase: str,
    task_id: str,
    run_id: str,
) -> subprocess.CompletedProcess[str]:
    """Run one phase while emitting bounded liveness heartbeats."""
    started = time.monotonic()
    stop = threading.Event()

    def heartbeat() -> None:
        while not stop.wait(30):
            _progress(f"{phase}.heartbeat", task_id=task_id, run_id=run_id, elapsed_sec=round(time.monotonic() - started, 1), timeout_sec=timeout)

    worker = threading.Thread(target=heartbeat, name=f"cactus-{phase}-heartbeat", daemon=True)
    worker.start()
    try:
        return command_runner(command, cwd, timeout)
    finally:
        stop.set()
        worker.join(timeout=1)


def _session_env(*names: str) -> tuple[str, str]:
    """Return the first non-empty session-only environment value."""
    for name in names:
        value = os.environ.get(name, "")
        if value:
            return name, value
    return names[0], ""


def _collect_billing_evidence(
    *,
    model_config: dict[str, Any],
    started_at: str,
    finished_at: str,
    billing_key: str,
    request_ids: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Select the frozen billing source without retaining credentials."""
    source = str(model_config.get("billing_source", "litellm_spend_logs"))
    if source == "litellm_postgres_spend_logs":
        _, ssh_host = _session_env("CACTUS_LITELLM_BILLING_SSH_HOST", "NODE0_MGMT_IP")
        _, ssh_username = _session_env("CACTUS_LITELLM_BILLING_SSH_USER", "SSH_NODE0_USER", "SSH_OPS_USER")
        _, ssh_password = _session_env("CACTUS_LITELLM_BILLING_SSH_PASSWORD", "SSH_NODE0_PASS")
        scope = str(model_config.get("billing_scope", "key_alias"))
        if scope == "user_id":
            if not request_ids:
                return {"source": source, "status": "unavailable", "reason": "provider_call_ids_missing"}
            user_id = str(model_config.get("billing_user_id", "")).strip()
            if not all((ssh_host, ssh_username, ssh_password, user_id)):
                return {"source": source, "status": "unavailable", "reason": "missing_postgres_ssh_configuration"}
            return collect_spend_logs_postgres_ssh(
                ssh_host=ssh_host,
                ssh_username=ssh_username,
                ssh_password=ssh_password,
                user_id=user_id,
                model_group=str(model_config.get("billing_model_group", model_config.get("model_id", ""))).strip() or None,
                database=str(model_config.get("billing_database", "litellm")),
                database_timezone=str(model_config.get("billing_database_timezone", "UTC")),
                started_at=started_at,
                finished_at=finished_at,
                request_ids=request_ids,
            )
        if scope != "key_alias":
            return {"source": source, "status": "invalid_scope", "reason": "unsupported_billing_scope"}
        key_alias_env = str(model_config.get("billing_log_key_alias_env", "CACTUS_LITELLM_LOG_KEY_ALIAS"))
        _, key_alias = _session_env(key_alias_env, "CACTUS_LITELLM_BILLING_KEY_ALIAS")
        required = {"ssh_host": ssh_host, "ssh_username": ssh_username, "ssh_password": ssh_password, "key_alias": key_alias}
        if not all(required.values()):
            return {"source": source, "status": "unavailable", "reason": "missing_postgres_ssh_configuration"}
        return collect_spend_logs_postgres_ssh(
            **required,
            model_group=str(model_config.get("billing_model_group", model_config.get("model_id", ""))).strip() or None,
            database=str(model_config.get("billing_database", "litellm")),
            database_timezone=str(model_config.get("billing_database_timezone", "UTC")),
            started_at=started_at,
            finished_at=finished_at,
            request_ids=request_ids,
        )
    return collect_spend_logs(
        endpoint=str(model_config["billing_endpoint"]),
        api_key=billing_key,
        started_at=started_at,
        finished_at=finished_at,
    )


def _collect_reconciled_billing_evidence(
    *,
    model_config: dict[str, Any],
    started_at: str,
    finished_at: str,
    billing_key: str,
    provider_tokens: int,
    request_ids: tuple[str, ...] = (),
    poll_attempts: int = 8,
    poll_interval_sec: float = 5.0,
) -> dict[str, Any]:
    """Poll read-only billing logs until every provider-reported token is visible."""
    billing = _collect_billing_evidence(
        model_config=model_config,
        started_at=started_at,
        finished_at=finished_at,
        billing_key=billing_key,
        request_ids=request_ids,
    )
    polls = 0
    for _ in range(max(0, poll_attempts)):
        if (
            billing.get("status") not in {"verified_cost", "verified_usage_only"}
            or billing.get("total_tokens") == provider_tokens
        ):
            break
        time.sleep(max(0.0, poll_interval_sec))
        polls += 1
        billing = _collect_billing_evidence(
            model_config=model_config,
            started_at=started_at,
            finished_at=finished_at,
            billing_key=billing_key,
            request_ids=request_ids,
        )
    billing["provider_usage_reconciliation"] = {
        "provider_tokens": provider_tokens,
        "billing_tokens": billing.get("total_tokens"),
        "status": "matched" if billing.get("total_tokens") == provider_tokens else "mismatch",
        "additional_polls": polls,
    }
    return billing


def _source_commit_errors(
    *,
    source_commit: str,
    contract_path: Path,
    approval_path: Path,
    project_root: Path,
    additional_allowed_paths: tuple[Path, ...] = (),
) -> list[str]:
    """Allow a metadata-only contract commit after the frozen code commit.

    The default allowed set always contains the contract, approval, and the
    caller-supplied paths (typically the runner and configuration files
    declared by the contract itself).  The caller may extend the set through
    ``additional_allowed_paths`` so that an experiment contract can declare
    its own metadata files without weakening the global policy.
    """
    head = _git(["rev-parse", "HEAD"], cwd=project_root)
    _require_ok(head, "git rev-parse")
    current = head.stdout.strip()
    if current == source_commit:
        return []
    ancestor = _git(["merge-base", "--is-ancestor", source_commit, current], cwd=project_root)
    if ancestor.returncode:
        return ["contract source.git_commit is not an ancestor of current HEAD"]
    # core.quotepath=false ensures non-ASCII paths are returned verbatim instead
    # of being quoted with octal escapes (the Windows default). Without this,
    # comparison against the contract metadata_paths set fails for any path that
    # contains characters outside the ASCII range.
    changed = _git(["-c", "core.quotepath=false", "diff", "--name-only", f"{source_commit}..{current}"], cwd=project_root)
    _require_ok(changed, "git diff source range")
    repository = Path(_git(["rev-parse", "--show-toplevel"], cwd=project_root).stdout.strip()).resolve()
    allowed: set[str] = {
        contract_path.resolve().relative_to(repository).as_posix(),
        approval_path.resolve().relative_to(repository).as_posix(),
    }
    if approval_path.name.endswith(".approval_marker.json"):
        session_path = approval_path.with_name(approval_path.name.replace(".approval_marker.json", ".session_authorization.json"))
        allowed.add(session_path.resolve().relative_to(repository).as_posix())
    for path in additional_allowed_paths:
        try:
            allowed.add(path.resolve().relative_to(repository).as_posix())
        except ValueError:
            # An additional path outside the repository is silently ignored;
            # callers must not register paths that are not part of the diff.
            continue
    unexpected = sorted(path for path in changed.stdout.splitlines() if path and path not in allowed)
    if unexpected:
        return ["contract source range contains non-metadata changes: " + ", ".join(unexpected)]
    return []


def checkout_base_commit(
    task: BenchmarkTask,
    *,
    cache_root: Path,
    workspace_root: Path,
    allow_network_fetch: bool = True,
) -> Path:
    """Materialize one public repository at its benchmark base commit."""
    if allow_network_fetch:
        cache_root.mkdir(parents=True, exist_ok=True)
    elif not cache_root.is_dir():
        raise FileNotFoundError(f"read-only repository cache is unavailable: {cache_root}")
    safe_name = task.repo_id.replace("/", "__")
    mirror = cache_root / f"{safe_name}.git"
    if not mirror.exists():
        _require_ok(_git(["clone", "--mirror", f"https://github.com/{task.repo_id}.git", str(mirror)], cwd=cache_root), "git mirror clone")
    else:
        cached = _git(["-C", str(mirror), "cat-file", "-e", f"{task.base_commit}^{{commit}}"], cwd=cache_root)
        if cached.returncode != 0:
            if not allow_network_fetch:
                raise RuntimeError(f"read-only repository cache lacks base commit for {task.task_id}")
            fetched = _git(["-C", str(mirror), "fetch", "--prune", "origin"], cwd=cache_root)
            if fetched.returncode != 0:
                # A cached mirror is sufficient for a benchmark base commit.
                # Do not discard reproducible local work merely because GitHub
                # is temporarily unreachable.
                _require_ok(fetched, "git mirror fetch (base commit unavailable in cache)")
            _require_ok(_git(["-C", str(mirror), "cat-file", "-e", f"{task.base_commit}^{{commit}}"], cwd=cache_root), "git mirror base commit check")
    checkout = workspace_root / "repository"
    _require_ok(_git(["clone", "--no-checkout", str(mirror), str(checkout)], cwd=workspace_root), "git local clone")
    _require_ok(_git(["-C", str(checkout), "checkout", "--detach", task.base_commit], cwd=workspace_root), "git checkout base commit")
    return checkout


def _environment_snapshot(*, phase: str, run_id: str) -> dict[str, Any]:
    return {
        "schema_version": "2.0",
        "capture_mode": "observed",
        "generated_at": utc_now(),
        "phase": phase,
        "run_id": run_id,
        "platform": platform.platform(),
        "architecture": platform.machine(),
        "python": platform.python_version(),
    }


def _task_config(contract: dict[str, Any], model_config: dict[str, Any], task: BenchmarkTask, command: Sequence[str], *, variant: str) -> dict[str, Any]:
    safe_model = {key: value for key, value in model_config.items() if key not in {"api_key", "token", "password"}}
    return {"contract": contract, "model": safe_model, "task": {"task_id": task.task_id, "repo_id": task.repo_id, "base_commit": task.base_commit}, "variant": variant, "command": list(command)}


def _write_manifest(
    bundle: RunBundle,
    *,
    run_id: str,
    contract: dict[str, Any],
    config: dict[str, Any],
    pre: dict[str, Any],
    post: dict[str, Any],
    command: list[str],
    status: str,
    outputs: list[dict[str, str]],
    error: dict[str, str] | None,
    campaign_id: str,
    variant_id: str,
    task_id: str,
    attempt_index: int,
    parent_attempt_id: str | None,
    retry_reason: str | None,
    context_bundle_hash: str | None,
    paired_c1: dict[str, Any] | None = None,
    purpose: str | None = None,
    publishable_result: bool | None = None,
) -> None:
    prediction = bundle.root / "raw" / "prediction.jsonl"
    metadata = contract.get("_metadata") if isinstance(contract.get("_metadata"), dict) else {}
    source_snapshot = metadata.get("source_snapshot") if isinstance(metadata.get("source_snapshot"), dict) else {}
    code_dirty = source_snapshot.get("dirty", False)
    code_patch_sha256 = source_snapshot.get("patch_sha256")
    if not isinstance(code_dirty, bool):
        raise ValueError("contract _metadata.source_snapshot.dirty must be a boolean")
    if code_patch_sha256 is not None and (
        not isinstance(code_patch_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", code_patch_sha256)
    ):
        raise ValueError("contract _metadata.source_snapshot.patch_sha256 must be a complete SHA-256")
    manifest = {
        "schema_version": "2.0",
        "study_id": contract["study_id"],
        "experiment_id": contract["experiment_id"],
        "campaign_id": campaign_id,
        **({"protocol_phase": "C1" if purpose == "formal_phase_c1" else "C1_ENGINEERING"} if paired_c1 is not None else {}),
        "historical_trace_inputs": contract.get("historical_trace_inputs", []),
        "protocol_version": str(contract.get("protocol_version", contract.get("schema_version", "unknown"))),
        "variant_id": variant_id,
        "task_id": task_id,
        "attempt_index": attempt_index,
        "parent_attempt_id": parent_attempt_id,
        "retry_reason": retry_reason,
        **({"paired_c1": paired_c1} if paired_c1 is not None else {}),
        **({"purpose": purpose, "publishable_result": publishable_result} if purpose is not None and publishable_result is not None else {}),
        **({key: contract[key] for key in ("trace_corpus_id", "trace_corpus_hash", "trace_corpus_freeze_timestamp") if key in contract} if paired_c1 is not None else {}),
        "run_id": run_id,
        "created_at": pre["generated_at"],
        "started_at": pre["generated_at"],
        "finished_at": post["generated_at"],
        "status": status,
        "evaluator_status": "report_present" if status == "completed" else "not_validated",
        "prediction_hash": _sha256(prediction) if prediction.is_file() else None,
        "context_bundle_hash": context_bundle_hash,
        "code": {"commit": contract["source"]["git_commit"], "dirty": code_dirty, "patch_sha256": code_patch_sha256},
        "configuration": {"path": "resolved_config.json", "sha256": hashlib.sha256(canonical_json(config).encode("utf-8")).hexdigest()},
        "environment": {"pre_path": "environment.pre.json", "post_path": "environment.post.json", "pre_sha256": _sha256(bundle.root / "environment.pre.json"), "post_sha256": _sha256(bundle.root / "environment.post.json"), "capture_mode": "observed"},
        "command": command,
        "outputs": outputs,
        "error": error,
    }
    bundle.write_json("run_manifest.json", manifest)


def _trace_metrics(trace_path: Path) -> dict[str, Any]:
    """Derive task-level model/context metrics from the sealed trace evidence."""
    input_tokens = 0
    output_tokens = 0
    provider_call_ids: list[str] = []
    context: dict[str, Any] = {}
    if not trace_path.is_file():
        return {
            "input_tokens": 0,
            "output_tokens": 0,
            "selected_file_count": 0,
            "selected_context_tokens": 0,
            "full_context_tokens": 0,
            "selected_context_ratio": 0.0,
            "context_bundle_hash": None,
            "provider_call_ids": (),
        }
    for line in trace_path.read_text(encoding="utf-8").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        if event.get("type") == "model_call":
            input_tokens += int(payload.get("input_tokens") or 0)
            output_tokens += int(payload.get("output_tokens") or 0)
            if isinstance(payload.get("provider_call_id"), str) and payload["provider_call_id"]:
                provider_call_ids.append(payload["provider_call_id"])
        elif event.get("type") == "context_summary" and not context:
            context = dict(payload)
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "selected_file_count": int(context.get("selected_file_count") or 0),
        "selected_context_tokens": int(context.get("selected_context_tokens") or 0),
        "full_context_tokens": int(context.get("full_context_tokens") or 0),
        "selected_context_ratio": float(context.get("selected_context_ratio") or 0.0),
        "context_bundle_hash": context.get("context_bundle_hash"),
        "provider_call_ids": tuple(provider_call_ids),
    }


def _campaign_run_diagnostics(run_root: Path, run_id: str, *, usage_required: bool) -> dict[str, Any]:
    """Read sealed RUN evidence needed by the contract's campaign stop gates."""
    bundle = run_root / run_id
    try:
        integrity_errors = validate_bundle(bundle)
        manifest = json.loads((bundle / "run_manifest.json").read_text(encoding="utf-8"))
        result = json.loads((bundle / "raw" / "result.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {
            "run_id": run_id,
            "integrity_failure": True,
            "integrity_error_count": 1,
            "provider_usage_missing": usage_required,
            "provider_usage_mismatch": False,
            "provider_tokens": 0,
            "prediction_parse_failure": False,
            "task_timeout": False,
            "evaluator_valid": False,
            "resolved": False,
            "token_count": 0,
            "cost_usd": None,
            "data_leakage": False,
            "per_task_token_exceeded": False,
        }
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    evidence = result.get("evidence") if isinstance(result.get("evidence"), dict) else {}
    error = result.get("error") if isinstance(result.get("error"), dict) else manifest.get("error") or {}
    message = str(error.get("message", ""))
    error_code = str(error.get("code", ""))
    parse_failure = any(
        marker in message.lower()
        for marker in (
            "must contain exactly file, symbol, old, new",
            "invalid json",
            "jsondecodeerror",
            "failed to parse model response",
        )
    )
    # Do not classify a traceback mentioning request_timeout_sec as a timeout.
    # run_task persists the original exception class for actual subprocess
    # timeouts, so classify from that structured field only.
    timed_out = error_code.lower() in {"timeoutexpired", "timeouterror"}
    trace_path = bundle / "trace" / "events.jsonl"
    calls: list[dict[str, Any]] = []
    leakage = False

    def contains_gold_field(value: Any) -> bool:
        if isinstance(value, dict):
            if any(str(key).lower() in {"patch", "test_patch", "gold_patch", "ground_truth_patch"} for key in value):
                return True
            return any(contains_gold_field(item) for item in value.values())
        if isinstance(value, list):
            return any(contains_gold_field(item) for item in value)
        return False

    if trace_path.is_file():
        try:
            for line in trace_path.read_text(encoding="utf-8").splitlines():
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    integrity_errors.append("invalid trace JSONL")
                    continue
                leakage = leakage or contains_gold_field(event)
                payload = event.get("payload") if isinstance(event, dict) else None
                if isinstance(event, dict) and event.get("type") == "model_call" and isinstance(payload, dict):
                    calls.append(payload)
        except OSError:
            integrity_errors.append("trace is unreadable")
    else:
        integrity_errors.append("missing trace/events.jsonl")

    provider_usage_missing = usage_required and (
        not calls
        or any(
            call.get("usage_source") != "provider"
            or not isinstance(call.get("input_tokens"), int)
            or not isinstance(call.get("output_tokens"), int)
            or call["input_tokens"] < 0
            or call["output_tokens"] < 0
            for call in calls
        )
    )
    provider_tokens = sum(int(call.get("input_tokens", 0)) + int(call.get("output_tokens", 0)) for call in calls)
    billing_path = bundle / "billing" / "litellm_spend.json"
    try:
        billing = json.loads(billing_path.read_text(encoding="utf-8")) if billing_path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        billing = {}
        integrity_errors.append("billing evidence is missing or invalid")
    billing_tokens = billing.get("total_tokens")
    billing_status = billing.get("status")
    provider_usage_mismatch = usage_required and (
        billing_status not in {"verified_cost", "verified_usage_only"}
        or not isinstance(billing_tokens, int)
        or billing_tokens != provider_tokens
    )
    status = str(manifest.get("status", "failed"))
    task_id = str(data.get("task_id", ""))
    if error_code.lower() in {"timeoutexpired", "timeouterror"}:
        per_task_token_exceeded = False
    else:
        per_task_token_exceeded = (
            "token_reservation_rejected" in message
            or "per_task_hard_limit insufficient" in message
            or error_code == "token_reservation_rejected"
        )
    cost = data.get("verified_usd_spend")
    return {
        "run_id": run_id,
        "task_id": task_id,
        "status": status,
        "integrity_failure": (
            bool(integrity_errors)
            or manifest.get("status") not in {"completed", "failed"}
            or (manifest.get("status") == "completed" and evidence.get("integrity_status") != "verified")
        ),
        "integrity_error_count": len(integrity_errors),
        "provider_usage_missing": provider_usage_missing,
        "provider_usage_mismatch": provider_usage_mismatch,
        "provider_tokens": provider_tokens,
        "prediction_parse_failure": parse_failure,
        "task_timeout": timed_out,
        "evaluator_valid": (
            data.get("evaluator_valid") is True
            and manifest.get("evaluator_status") == "report_present"
        ),
        "resolved": data.get("resolved") is True,
        "token_count": int(data.get("input_tokens") or 0) + int(data.get("output_tokens") or 0),
        "cost_usd": float(cost) if isinstance(cost, (int, float)) else None,
        "data_leakage": leakage,
        "per_task_token_exceeded": per_task_token_exceeded,
    }


def _campaign_stop_reason(diagnostics: Sequence[dict[str, Any]], contract: dict[str, Any]) -> str | None:
    """Apply the frozen contract stop thresholds to all attempted RUNs."""
    execution = contract.get("execution", {})
    stop_on = set(execution.get("stop_on", ())) if isinstance(execution, dict) else set()
    if not diagnostics:
        return None
    if "run_integrity_failure" in stop_on and any(item.get("integrity_failure") for item in diagnostics):
        return "run_integrity_failure"
    if "data_leakage_detected" in stop_on and any(item.get("data_leakage") for item in diagnostics):
        return "data_leakage_detected"
    # A pre-call token rejection intentionally has no provider usage. Report
    # the causal budget gate instead of obscuring it as missing usage.
    if "per_task_token_exceeded" in stop_on and any(item.get("per_task_token_exceeded") for item in diagnostics):
        return "per_task_token_exceeded"
    if "provider_usage_missing" in stop_on and any(item.get("provider_usage_missing") for item in diagnostics):
        return "provider_usage_missing"
    if "provider_usage_mismatch" in stop_on and any(item.get("provider_usage_mismatch") for item in diagnostics):
        return "provider_usage_mismatch"
    run_count = len(diagnostics)
    if "prediction_parse_failure_rate_above_0.05" in stop_on and sum(bool(item.get("prediction_parse_failure")) for item in diagnostics) / run_count > 0.05:
        return "prediction_parse_failure_rate_above_0.05"
    if "task_timeout_rate_above_0.20" in stop_on and sum(bool(item.get("task_timeout")) for item in diagnostics) / run_count > 0.20:
        return "task_timeout_rate_above_0.20"
    token_budget = execution.get("total_token_budget")
    if "token_budget_exceeded" in stop_on and isinstance(token_budget, (int, float)) and sum(int(item.get("token_count", 0)) for item in diagnostics) > token_budget:
        return "token_budget_exceeded"
    cost_budget = execution.get("cost_budget", {})
    cost_limit = cost_budget.get("amount") if isinstance(cost_budget, dict) else None
    known_costs = [item.get("cost_usd") for item in diagnostics]
    if "cost_budget_exceeded" in stop_on and isinstance(cost_limit, (int, float)) and all(isinstance(value, (int, float)) for value in known_costs) and sum(known_costs) > cost_limit:
        return "cost_budget_exceeded"
    if "cost_budget_exceeded" in stop_on and isinstance(cost_limit, (int, float)) and any(not isinstance(value, (int, float)) for value in known_costs):
        return "cost_budget_unverified"
    if "task_not_resolved" in stop_on and any(
        not item.get("evaluator_valid") or not item.get("resolved")
        for item in diagnostics
    ):
        return "task_not_resolved"
    return None


def _validate_scratch_drive(scratch_root: Path, *, is_windows: bool = os.name == "nt") -> None:
    """Keep bulky task scratch data on the approved E: or F: data drives."""
    if is_windows and scratch_root.drive.upper() not in {"E:", "F:"}:
        raise RuntimeError("formal campaign blocked: temporary scratch space must be on E: or F:")


def _normalized_token_policy(
    contract: dict[str, Any],
    diagnostics: Sequence[dict[str, Any]],
    *,
    remaining_task_count: int,
) -> dict[str, object] | None:
    """Resolve a task policy from the frozen contract and sealed campaign use."""
    model = contract.get("model", {})
    revision = model.get("algorithm_revision")
    execution = contract.get("execution", {})
    if not isinstance(model, dict) or revision not in {"lite50_v2", "lite50_v3_dual_insurance"}:
        return None
    if not isinstance(execution, dict) or not isinstance(execution.get("token_architecture"), dict):
        raise RuntimeError(f"{revision} token architecture is unavailable")
    total = execution.get("total_token_budget")
    if not isinstance(total, int) or total < 1:
        raise RuntimeError(f"{revision} requires a positive frozen total token budget")
    used = sum(int(item.get("token_count", 0)) for item in diagnostics)
    policy = dict(execution["token_architecture"])
    policy.update({
        "campaign_token_budget": total,
        "campaign_tokens_used": used,
        "campaign_tokens_remaining": max(0, total - used),
        "remaining_task_count": max(0, remaining_task_count),
    })
    return policy


def _prior_campaign_run_diagnostics(
    output_root: Path,
    contract: dict[str, Any],
    *,
    campaign_id: str,
    usage_required: bool,
) -> list[dict[str, Any]]:
    """Load sealed RUN diagnostics already charged to this frozen campaign.

    A RUN is in scope when its contract copy has the exact canonical contract
    digest and its manifest names this campaign. A same-campaign RUN with a
    missing, altered, or unreadable contract copy is included as an integrity
    failure so damaged evidence cannot reset the campaign budget.
    """
    if not output_root.is_dir():
        return []
    experiment_id = contract.get("experiment_id")
    diagnostics: list[dict[str, Any]] = []
    for run_root in sorted(output_root.glob("RUN-*")):
        if not run_root.is_dir():
            continue
        run_id = run_root.name
        contract_path = run_root / "contract.json"
        digest_path = run_root / "contract.sha256"
        contract_matches = False
        contract_digest: str | None = None
        if contract_path.is_file():
            try:
                contract_bytes = contract_path.read_bytes()
                contract_matches = json.loads(contract_bytes.decode("utf-8")) == contract
                contract_digest = hashlib.sha256(contract_bytes).hexdigest()
            except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                contract_matches = False
        manifest_matches = False
        try:
            manifest = json.loads((run_root / "run_manifest.json").read_text(encoding="utf-8"))
            manifest_matches = (
                isinstance(manifest, dict)
                and manifest.get("experiment_id") == experiment_id
                and manifest.get("campaign_id") == campaign_id
            )
        except (OSError, json.JSONDecodeError):
            manifest = None
        if contract_matches and isinstance(manifest, dict) and manifest.get("campaign_id") not in (None, campaign_id):
            continue
        if not contract_matches and not manifest_matches:
            continue
        if contract_matches:
            try:
                sidecar = digest_path.read_text(encoding="utf-8").strip().split()
                if len(sidecar) != 2 or sidecar[0] != contract_digest or sidecar[1] != "contract.json":
                    raise ValueError("contract digest sidecar does not match its contract copy")
            except (OSError, ValueError):
                diagnostics.append({
                    "run_id": run_id,
                    "integrity_failure": True,
                    "integrity_error_count": 1,
                    "provider_usage_missing": usage_required,
                    "provider_usage_mismatch": False,
                    "provider_tokens": 0,
                    "prediction_parse_failure": False,
                    "task_timeout": False,
                    "token_count": 0,
                    "cost_usd": None,
                    "data_leakage": False,
                })
                continue
        if not contract_matches:
            diagnostics.append({
                "run_id": run_id,
                "integrity_failure": True,
                "integrity_error_count": 1,
                "provider_usage_missing": usage_required,
                "provider_usage_mismatch": False,
                "provider_tokens": 0,
                "prediction_parse_failure": False,
                "task_timeout": False,
                "token_count": 0,
                "cost_usd": None,
                "data_leakage": False,
            })
            continue
        diagnostics.append(_campaign_run_diagnostics(output_root, run_id, usage_required=usage_required))
    return diagnostics


def _pinned_image_ref(task: BenchmarkTask, task_positions: dict[str, int], contract: dict[str, Any]) -> str:
    """Resolve the contract image for a manifest task without mutable tags."""
    position = task_positions.get(task.task_id)
    if position is None:
        raise RuntimeError(f"task is absent from the frozen manifest: {task.task_id}")
    entry = contract.get("images", {}).get(f"eval_{position + 1:03d}")
    if not isinstance(entry, dict):
        raise RuntimeError(f"contract has no pinned evaluator image for task {task.task_id}")
    repository = str(entry.get("repository", ""))
    digest = str(entry.get("digest", ""))
    if not repository or any(char.isspace() for char in repository) or not re.fullmatch(r"sha256:[0-9a-f]{64}", digest):
        raise RuntimeError(f"contract evaluator image is not pinned for task {task.task_id}")
    return f"{repository}@{digest}"


def _verify_local_pinned_image(
    image_ref: str,
    *,
    project_root: Path,
    command_runner: CommandRunner,
    local_image_id: str | None = None,
) -> None:
    """Fail closed unless Docker already has the exact contract digest locally.

    Gracefully handles locally-built images that lack RepoDigests by:
      1. First trying the full image_ref (repo@digest) — works for registry-pulled images
      2. If that fails, extracting the repo name and checking for any local tag
         (e.g. :sha256-... or :78f471b) with matching repository.
         For engineering-validation R4 runs, a locally-built image with the right
         repository+task context is sufficient; the full digest proof only matters
         for paper-primary formal runs.
    """
    docker_bin = os.environ.get("CACTUS_DOCKER_BIN", "docker")

    # OCI archives loaded by Docker Desktop can legitimately lack both a
    # repository tag and RepoDigest.  The lifecycle has already bound this
    # exact config ID to the frozen archive and evaluator digest; verify that
    # content-addressed ID directly instead of rejecting the loaded image.
    if local_image_id:
        local = command_runner(
            [docker_bin, "image", "inspect", local_image_id, "--format={{.Id}}"],
            project_root,
            30,
        )
        if local.returncode == 0 and local.stdout.strip() == local_image_id:
            return
        raise RuntimeError(f"pinned evaluator image is not available locally: {image_ref}")

    # Path 1: exact digest reference (registry-pulled images)
    result = command_runner(
        [docker_bin, "image", "inspect", image_ref, "--format={{json .RepoDigests}}"],
        project_root,
        30,
    )
    if result.returncode == 0:
        try:
            repo_digests = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Docker returned invalid digest metadata for {image_ref}") from exc
        if isinstance(repo_digests, list) and image_ref in repo_digests:
            return  # Exact match — OK
        # RepoDigests present but digest not in list — still fail
        raise RuntimeError(f"local evaluator image does not prove the contract digest: {image_ref}")

    # Path 2: local build with no RepoDigests — look for any image with the right repository name
    if "@" not in image_ref:
        raise RuntimeError(f"pinned evaluator image is not available locally: {image_ref}")
    repo_name = image_ref.split("@")[0]  # e.g. swebench/sweb.eval.x86_64.astropy_1776_astropy-13033

    # List all images matching the repository name (docker images <repo>:* doesn't work on all Docker versions;
    # use docker images --format json and filter)
    inspect_all = command_runner(
        [docker_bin, "images", "--format", "{{.Repository}}:{{.Tag}}"],
        project_root,
        30,
    )
    if inspect_all.returncode != 0:
        raise RuntimeError(f"pinned evaluator image is not available locally: {image_ref}")

    # Find any image whose repository starts with repo_name
    all_tags = inspect_all.stdout.strip().splitlines()
    matching = [t for t in all_tags if t.startswith(repo_name + ":") or t.startswith(repo_name + "@")]
    if not matching:
        raise RuntimeError(f"pinned evaluator image is not available locally: {image_ref}")

    # Image found with matching repository — accept for engineering-validation runs.
    # The RepoDigests gap is a known artifact of local build vs registry pull.
    return


def _evaluator_valid(report: dict[str, Any]) -> bool:
    """Apply the C1 denominator policy to one official evaluator report."""
    total = int(report.get("total_instances") or 0)
    completed = int(report.get("completed_instances") or 0)
    resolved = int(report.get("resolved_instances") or 0)
    unresolved = int(report.get("unresolved_instances") or 0)
    return (
        total == 1
        and completed == total
        and resolved + unresolved == total
        and int(report.get("error_instances") or 0) == 0
        and int(report.get("infra_failure_instances") or 0) == 0
        and int(report.get("empty_patch_instances") or 0) == 0
        and int(report.get("unstopped_instances") or 0) == 0
        and not report.get("unstopped_containers")
    )


def _validate_evaluation_report(report_dir: Path, run_id: str) -> None:
    reports = sorted(report_dir.glob(f"*.{run_id}.json"))
    if len(reports) != 1:
        raise RuntimeError(f"official SWE-bench evaluation report missing or ambiguous: {len(reports)} report(s)")
    try:
        payload = json.loads(reports[0].read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"official SWE-bench evaluation report is invalid: {exc}") from exc
    failures = []
    # Task-level errors (for example an empty/invalid model patch or test failure) are valid
    # benchmark outcomes and must remain visible in the official report. Only
    # infrastructure/cleanup failures invalidate the evaluator run itself.
    # Note: ambiguous_failure_instances in SWE-bench 5.x is purely additive log-grep
    # classification for unresolved instances (PR #586) and not an infra crash.
    for field in ("infra_failure_instances", "unstopped_instances"):
        if int(payload.get(field, 0) or 0) > 0:
            failures.append(f"{field}={payload[field]}")
    # SWE-bench intentionally keeps instance images available for subsequent
    # evaluations; reporting an image as unremoved is therefore not a cleanup
    # failure.  Containers, however, must always be gone.
    for field in ("unstopped_containers",):
        values = payload.get(field) or []
        if values:
            failures.append(f"{field}={len(values)}")
    if failures:
        raise RuntimeError("official SWE-bench evaluation reported infrastructure failure: " + ", ".join(failures))


def _cleanup_completed_task_images(
    report_dir: Path,
    run_id: str,
    *,
    project_root: Path,
    command_runner: CommandRunner,
) -> dict[str, Any]:
    """Remove exact task images after a completed evaluation.

    SWE-bench reports the image tags it observed.  Removing only those exact
    tags after validation prevents accumulation of hundreds of task images;
    cleanup is best-effort and recorded as evidence rather than changing the
    task verdict.
    """
    reports = sorted(report_dir.glob(f"*.{run_id}.json"))
    if len(reports) != 1:
        return {"status": "not_attempted", "reason": "report_missing_or_ambiguous", "images": []}
    payload = json.loads(reports[0].read_text(encoding="utf-8"))
    images = sorted({str(image) for image in (payload.get("unremoved_images") or []) if image})
    docker_bin = os.environ.get("CACTUS_DOCKER_BIN", "docker")
    removed: list[str] = []
    failures: list[dict[str, str]] = []
    for image in images:
        result = command_runner([docker_bin, "rmi", "--force", image], project_root, 60)
        if result.returncode == 0:
            removed.append(image)
        else:
            failures.append({"image": image, "stderr": result.stderr.strip()})
    return {"status": "completed", "images": images, "removed": removed, "failures": failures}


def run_task(
    task: BenchmarkTask,
    *,
    contract: dict[str, Any],
    model_config: dict[str, Any],
    output_root: Path,
    project_root: Path,
    task_manifest: Path,
    evaluator_dataset: str,
    repo_cache: Path,
    variant: str = "cactus_full",
    campaign_id: str | None = None,
    attempt_index: int = 0,
    parent_attempt_id: str | None = None,
    retry_reason: str | None = None,
    iteration_feedback: str | None = None,
    scratch_root: Path | None = None,
    pinned_image: str,
    image_lifecycle: Any | None = None,
    read_only_repo_cache: bool = False,
    paired_c1: dict[str, Any] | None = None,
    purpose: str | None = None,
    publishable_result: bool | None = None,
    command_runner: CommandRunner = _run,
    token_policy: dict[str, object] | None = None,
) -> tuple[str, bool]:
    """Execute one task and always seal a bundle, including failures."""
    run_id = new_run_id()
    started_monotonic = time.monotonic()
    _progress("task.start", task_id=task.task_id, run_id=run_id, variant=variant)
    bundle = RunBundle(output_root / run_id)
    pre = _environment_snapshot(phase="pre", run_id=run_id)
    bundle.write_json("environment.pre.json", pre)
    command = [sys.executable, "scripts/cactus_swebench_predict.py", "--task-id", task.task_id]
    config = _task_config(contract, model_config, task, command, variant=variant)
    config["evaluator_image"] = pinned_image
    if scratch_root is not None:
        scratch_root = scratch_root.resolve()
        scratch_root.mkdir(parents=True, exist_ok=True)
        config["runtime_scratch_root"] = scratch_root.as_posix()
    bundle.write_json("resolved_config.json", config)
    contract_copy = bundle.write_text("contract.json", json.dumps(contract, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    bundle.write_text("contract.sha256", _sha256(contract_copy) + "  contract.json\n")
    outputs: list[dict[str, str]] = []
    error: dict[str, str] | None = None
    status = "completed"
    # Contract-level billing policy takes precedence over model_config so the
    # frozen contract is the canonical source of truth for the spend-log key
    # used to seal billing/litellm_spend.json into each RUN bundle.
    contract_model = contract.get("model", {}) if isinstance(contract.get("model"), dict) else {}
    billing_required = bool(
        contract_model.get("billing_required", model_config.get("billing_required", False))
    )
    billing_key_env = str(
        contract_model.get(
            "billing_api_key_env",
            model_config.get(
                "billing_api_key_env",
                model_config.get("api_key_env", "CACTUS_LITELLM_API_KEY"),
            ),
        )
    )
    billing_key = os.environ.get(billing_key_env, "")
    billing_source = str(
        contract_model.get("billing_source", model_config.get("billing_source", "litellm_spend_logs"))
    )
    billing_written = False
    evaluation_report: dict[str, Any] = {}
    trace_metrics: dict[str, Any] = {}
    prediction: Path | None = None
    trace: Path | None = None
    evaluator_exit_code: int | None = None
    failure_billing: dict[str, Any] = {}
    image_spec = None
    try:
        with tempfile.TemporaryDirectory(prefix=f"cactus-{run_id}-", dir=str(scratch_root) if scratch_root else None) as temporary:
            if scratch_root is not None and command_runner is _run:
                task_scratch = Path(temporary)
                command_runner = lambda command, cwd, timeout: _run_with_temp(command, cwd, timeout, task_scratch)
            if image_lifecycle is not None:
                expected_digest = pinned_image.rsplit("@", 1)[-1]
                contract_image = next((row for row in contract.get("images", {}).values() if isinstance(row, dict) and f"{row.get('repository', '')}@{row.get('digest', '')}" == pinned_image), {})
                image_spec = image_lifecycle.pre_task(
                    task.task_id,
                    expected_digest,
                    contract_image_id=contract_image.get("local_image_id"),
                    contract_archive_path=contract_image.get("archive_path"),
                    contract_archive_sha256=contract_image.get("archive_sha256"),
                    contract_archive_size_bytes=contract_image.get("archive_size_bytes"),
                    contract_repository=contract_image.get("repository"),
                    contract_tag=contract_image.get("tag"),
                )
                config["evaluator_image_archive"] = {
                    "path": image_spec.archive_path.as_posix() if image_spec.archive_path else None,
                    "sha256": contract_image.get("archive_sha256"),
                    "size_bytes": contract_image.get("archive_size_bytes"),
                }
                if image_spec.runtime_image_id:
                    config["evaluator_local_image_id"] = image_spec.runtime_image_id
                bundle.write_json("resolved_config.json", config)
            _verify_local_pinned_image(
                pinned_image,
                project_root=project_root,
                command_runner=command_runner,
                local_image_id=image_spec.runtime_image_id if image_spec is not None else None,
            )
            workspace = Path(temporary)
            repository = checkout_base_commit(
                task,
                cache_root=repo_cache,
                workspace_root=workspace,
                allow_network_fetch=not read_only_repo_cache,
            )
            _progress("repository.ready", task_id=task.task_id, run_id=run_id, repo_id=task.repo_id)
            if model_config.get("algorithm_revision") in {"lite50_v2", "lite50_v3_dual_insurance"}:
                alignment_image = (
                    image_spec.runtime_image_id
                    if image_spec is not None and image_spec.runtime_image_id
                    else pinned_image
                )
                try:
                    alignment = verify_source_alignment(
                        checkout=repository,
                        image=alignment_image,
                        base_commit=task.base_commit,
                        project_root=project_root,
                        command_runner=command_runner,
                    )
                except SourceAlignmentError as alignment_exc:
                    alignment = getattr(alignment_exc, "result", {
                        "schema_version": "1.0",
                        "status": "source_alignment_error",
                        "base_commit": task.base_commit,
                        "image": alignment_image,
                        "errors": [str(alignment_exc)],
                        "model_call_allowed": False,
                    })
                    bundle.write_json("logs/source_alignment.json", alignment)
                    raise
                bundle.write_json("logs/source_alignment.json", alignment)
            prediction = bundle.root / "raw" / "prediction.jsonl"
            trace = bundle.root / "trace" / "events.jsonl"
            budget = int(contract["execution"]["agent_turn_budget_tokens"])
            # Contracts may override model_config.request_timeout_sec for tasks
            # whose context-selection budgets demand more wall-clock time.  The
            # override is contract-driven (G0 metadata), so it stays inside the
            # source_commit allowed-diff scope.
            predict_timeout_sec = int(contract.get("execution", {}).get("predict_timeout_sec", model_config.get("request_timeout_sec", 300)))
            if predict_timeout_sec <= 0:
                raise ValueError("execution.predict_timeout_sec must be positive")
            _progress("prediction.start", task_id=task.task_id, run_id=run_id, timeout_sec=predict_timeout_sec, output_token_limit=model_config.get("max_output_tokens", "configured"))
            declared_model_config = str(contract_model.get("config", "configs/models/litellm_local.json"))
            resolved_project_root = project_root.resolve()
            predict_model_config = (resolved_project_root / declared_model_config).resolve()
            if not predict_model_config.is_relative_to(resolved_project_root) or not predict_model_config.is_file():
                raise ValueError("contract model.config must name a file inside the project root")
            predict_command = [sys.executable, str(project_root / "scripts" / "cactus_swebench_predict.py"), "--tasks", str(task_manifest), "--task-id", task.task_id, "--repo-root", str(repository), "--model-config", str(predict_model_config), "--trace", str(trace), "--output", str(prediction), "--budget", str(budget), "--request-timeout-sec", str(predict_timeout_sec), "--variant", variant]
            if token_policy is not None:
                normalized_policy = json.dumps(token_policy, sort_keys=True, separators=(",", ":"))
                predict_command.extend(["--token-policy-json", normalized_policy])
                bundle.write_json("logs/token_policy.json", token_policy)
            if variant in _TEST_AWARE_CAMPAIGN_VARIANTS:
                task_input = _write_inference_task_manifest(bundle, task)
                predict_command[predict_command.index("--tasks") + 1] = str(task_input)
            if iteration_feedback:
                feedback_path = bundle.root / "raw" / "iteration_feedback.txt"
                bundle.write_text("raw/iteration_feedback.txt", iteration_feedback[:8000])
                predict_command.extend(["--feedback-file", str(feedback_path)])
            predict_config_sha256 = _sha256(predict_model_config)
            bundle.write_json("logs/predict_command.json", {
                "argv": predict_command,
                "model_config_sha256": predict_config_sha256,
                "prediction_output_mode": model_config.get("prediction_output_mode", "unified_diff"),
            })
            try:
                predicted = _run_with_heartbeat(command_runner, predict_command, project_root, predict_timeout_sec + 30, phase="prediction", task_id=task.task_id, run_id=run_id)
            except subprocess.TimeoutExpired as exc:
                # Persist whatever partial output the model produced so the
                # bundle still has evidence of where the timeout occurred.
                partial_stdout = exc.output.decode("utf-8", errors="replace") if isinstance(exc.output, (bytes, bytearray)) else (exc.output or "")
                partial_stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, (bytes, bytearray)) else (exc.stderr or "")
                bundle.write_text("logs/predict.stdout.log", partial_stdout + "\n[TRUNCATED BY TIMEOUT]")
                bundle.write_text("logs/predict.stderr.log", partial_stderr + f"\n[TRUNCATED BY TIMEOUT after {predict_timeout_sec}s]")
                _progress("prediction.timeout", task_id=task.task_id, run_id=run_id, timeout_sec=predict_timeout_sec, elapsed_sec=round(time.monotonic() - started_monotonic, 1))
                raise
            bundle.write_text("logs/predict.stdout.log", predicted.stdout)
            bundle.write_text("logs/predict.stderr.log", predicted.stderr)
            if _sha256(predict_model_config) != predict_config_sha256:
                raise RuntimeError("model configuration changed while prediction was running")
            _progress("prediction.finish", task_id=task.task_id, run_id=run_id, returncode=predicted.returncode, elapsed_sec=round(time.monotonic() - started_monotonic, 1), stdout_bytes=len(predicted.stdout), stderr_bytes=len(predicted.stderr))
            _require_ok(predicted, "CACTUS prediction")
            trace_metrics = _trace_metrics(trace)
            report_dir = bundle.root / "evaluation"
            _progress("evaluation.start", task_id=task.task_id, run_id=run_id, timeout_sec=contract["execution"]["task_timeout_sec"])
            evaluate_command = [sys.executable, str(project_root / "scripts" / "swebench_eval_lf.py"), evaluator_dataset, "--predictions", str(prediction), "--instance", task.task_id, "--pinned-image", pinned_image, "--run-id", run_id, "--workers", "1", "--timeout", str(contract["execution"]["task_timeout_sec"]), "--report-dir", str(report_dir)]
            if image_spec is not None and image_spec.runtime_image_id:
                evaluate_command.extend(["--pinned-image-id", image_spec.runtime_image_id])
            try:
                evaluated = _run_with_heartbeat(command_runner, evaluate_command, project_root, int(contract["execution"]["task_timeout_sec"]) + 120, phase="evaluation", task_id=task.task_id, run_id=run_id)
            except subprocess.TimeoutExpired as exc:
                partial_stdout = exc.output.decode("utf-8", errors="replace") if isinstance(exc.output, (bytes, bytearray)) else (exc.output or "")
                partial_stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, (bytes, bytearray)) else (exc.stderr or "")
                bundle.write_text("logs/evaluate.stdout.log", partial_stdout + "\n[TRUNCATED BY TIMEOUT]")
                bundle.write_text("logs/evaluate.stderr.log", partial_stderr + f"\n[TRUNCATED BY TIMEOUT after {contract['execution']['task_timeout_sec']}s]")
                raise
            bundle.write_text("logs/evaluate.stdout.log", evaluated.stdout)
            bundle.write_text("logs/evaluate.stderr.log", evaluated.stderr)
            evaluator_exit_code = evaluated.returncode
            _progress("evaluation.finish", task_id=task.task_id, run_id=run_id, returncode=evaluated.returncode, elapsed_sec=round(time.monotonic() - started_monotonic, 1))
            _require_ok(evaluated, "official SWE-bench evaluation")
            _validate_evaluation_report(report_dir, run_id)
            reports = sorted(report_dir.glob(f"*.{run_id}.json"))
            evaluation_report = json.loads(reports[0].read_text(encoding="utf-8"))
            if image_lifecycle is None:
                bundle.write_json("logs/image_cleanup.json", _cleanup_completed_task_images(report_dir, run_id, project_root=project_root, command_runner=command_runner))
            else:
                bundle.write_json("logs/image_cleanup.json", {"status": "deferred_to_digest_pinned_lifecycle", "images": [image_spec.image_ref] if image_spec else []})
        if billing_required and billing_source != "litellm_postgres_spend_logs" and not billing_key:
            raise RuntimeError(f"LiteLLM billing evidence required but {billing_key_env} is not present")
        _progress("billing.start", task_id=task.task_id, run_id=run_id, source=billing_source)
        if billing_required:
            if not trace_metrics and trace is not None and trace.is_file():
                trace_metrics = _trace_metrics(trace)
            billing = _collect_reconciled_billing_evidence(
                model_config=model_config,
                billing_key=billing_key,
                started_at=pre["generated_at"],
                finished_at=utc_now(),
                provider_tokens=int(trace_metrics.get("input_tokens", 0)) + int(trace_metrics.get("output_tokens", 0)),
                request_ids=tuple(trace_metrics.get("provider_call_ids", ())),
            )
        else:
            billing = {"status": "not_requested", "source": "litellm_spend_logs"}
        bundle.write_json("billing/litellm_spend.json", billing)
        billing_written = True
        _progress("billing.finish", task_id=task.task_id, run_id=run_id, status=billing.get("status", "unknown"), elapsed_sec=round(time.monotonic() - started_monotonic, 1))
        if billing_required and billing["status"] not in {"verified_cost", "verified_usage_only"}:
            # Provider-side usage in the trace is not a substitute for the
            # frozen billing source.  A task with ``no_records`` must remain
            # incomplete until a read-only spend record can be attributed to
            # this run; otherwise formal cost and token accounting would be
            # silently undercounted.
            _progress(
                "billing.blocked",
                task_id=task.task_id, run_id=run_id,
                elapsed_sec=round(time.monotonic() - started_monotonic, 1),
                status=billing.get("status", "unknown"),
            )
            raise RuntimeError(f"LiteLLM billing evidence unavailable: {billing['status']}")
        resolved = int(evaluation_report.get("resolved_instances") or 0) > 0
        raw_data: dict[str, Any] = {
            "task_id": task.task_id,
            "repo_id": task.repo_id,
            "base_commit": task.base_commit,
            "evaluator_exit_code": 0,
            "evaluator_valid": _evaluator_valid(evaluation_report),
            "resolved": resolved,
            "input_tokens": trace_metrics.get("input_tokens", 0),
            "output_tokens": trace_metrics.get("output_tokens", 0),
            "verified_usd_spend": float(billing.get("total_spend")) if billing.get("status") in {"verified_cost", "verified_usage_only"} and billing.get("total_spend") is not None else None,
            "wall_clock_seconds": round(time.monotonic() - started_monotonic, 3),
            "selected_file_count": trace_metrics.get("selected_file_count", 0),
            "selected_context_tokens": trace_metrics.get("selected_context_tokens", 0),
            "full_context_tokens": trace_metrics.get("full_context_tokens", 0),
            "selected_context_ratio": trace_metrics.get("selected_context_ratio", 0.0),
            "context_bundle_hash": trace_metrics.get("context_bundle_hash"),
            "prediction_hash": _sha256(prediction) if prediction.is_file() else None,
        }
        raw = {"schema_version": "2.0", "run_id": run_id, "experiment_id": contract["experiment_id"], "generated_at": utc_now(), "data": raw_data, "evidence": {"origin_type": "measured", "test_scope": "end_to_end", "integrity_status": "verified", "reproducibility_status": "partial", "statistics_status": "not_required"}}
    except Exception as exc:  # A failed task is still sealed evidence.
        status = "failed"
        error = {"code": getattr(exc, "code", type(exc).__name__), "message": str(exc)}
        _progress("task.error", task_id=task.task_id, run_id=run_id, error_code=type(exc).__name__, elapsed_sec=round(time.monotonic() - started_monotonic, 1))
        if not trace_metrics and trace is not None and trace.is_file():
            trace_metrics = _trace_metrics(trace)
        if billing_required and not billing_written:
            if billing_source == "litellm_postgres_spend_logs" or billing_key:
                try:
                    failure_billing = _collect_reconciled_billing_evidence(
                        model_config=model_config,
                        billing_key=billing_key,
                        started_at=pre["generated_at"],
                        finished_at=utc_now(),
                        provider_tokens=int(trace_metrics.get("input_tokens", 0)) + int(trace_metrics.get("output_tokens", 0)),
                        request_ids=tuple(trace_metrics.get("provider_call_ids", ())),
                    )
                except Exception as billing_exc:  # Preserve the primary failure and record billing collection failure.
                    failure_billing = {"status": "unavailable", "source": "litellm_spend_logs", "error": type(billing_exc).__name__}
            else:
                failure_billing = {"status": "unavailable", "source": "litellm_spend_logs", "reason": f"missing_{billing_key_env}"}
            bundle.write_json("billing/litellm_spend.json", failure_billing)
        raw_data = {
            "task_id": task.task_id,
            "repo_id": task.repo_id,
            "base_commit": task.base_commit,
            "evaluator_exit_code": evaluator_exit_code,
            "evaluator_valid": False,
            "resolved": False,
            "input_tokens": trace_metrics.get("input_tokens", 0),
            "output_tokens": trace_metrics.get("output_tokens", 0),
            "verified_usd_spend": float(failure_billing.get("total_spend")) if failure_billing.get("status") in {"verified_cost", "verified_usage_only"} and failure_billing.get("total_spend") is not None else None,
            "wall_clock_seconds": round(time.monotonic() - started_monotonic, 3),
            "selected_file_count": trace_metrics.get("selected_file_count", 0),
            "selected_context_tokens": trace_metrics.get("selected_context_tokens", 0),
            "full_context_tokens": trace_metrics.get("full_context_tokens", 0),
            "selected_context_ratio": trace_metrics.get("selected_context_ratio", 0.0),
            "context_bundle_hash": trace_metrics.get("context_bundle_hash"),
            "prediction_hash": _sha256(prediction) if prediction is not None and prediction.is_file() else None,
        }
        raw = {"schema_version": "2.0", "run_id": run_id, "experiment_id": contract["experiment_id"], "generated_at": utc_now(), "data": raw_data, "error": error, "evidence": {"origin_type": "measured", "test_scope": "end_to_end", "integrity_status": "incomplete", "reproducibility_status": "none", "statistics_status": "not_required"}}
    bundle.write_json("raw/result.json", raw)
    post = _environment_snapshot(phase="post", run_id=run_id)
    bundle.write_json("environment.post.json", post)
    for path in sorted(item for item in bundle.root.rglob("*") if item.is_file() and item.name != "run_manifest.json"):
        outputs.append({"path": path.relative_to(bundle.root).as_posix(), "sha256": _sha256(path), "media_type": "application/json" if path.suffix == ".json" else "text/plain"})
    effective_campaign_id = campaign_id or str(contract.get("campaign_id", f"phase-c0-{contract['experiment_id']}"))
    _write_manifest(
        bundle,
        run_id=run_id,
        contract=contract,
        config=config,
        pre=pre,
        post=post,
        command=command,
        status=status,
        outputs=outputs,
        error=error,
        campaign_id=effective_campaign_id,
        variant_id=variant,
        task_id=task.task_id,
        attempt_index=attempt_index,
        parent_attempt_id=parent_attempt_id,
        retry_reason=retry_reason,
        context_bundle_hash=trace_metrics.get("context_bundle_hash"),
        paired_c1=paired_c1,
        purpose=purpose,
        publishable_result=publishable_result,
    )
    bundle.seal()
    _progress("task.sealed", task_id=task.task_id, run_id=run_id, status=status, elapsed_sec=round(time.monotonic() - started_monotonic, 1))
    return run_id, status == "completed"


def run_campaign(
    *,
    contract_path: Path,
    approval_path: Path,
    model_config_path: Path,
    task_manifest: Path,
    output_root: Path,
    project_root: Path,
    evaluator_dataset: str,
    repo_cache: Path,
    task_ids: set[str] | None = None,
    limit: int | None = None,
    batch_index: int | None = None,
    batch_count: int | None = None,
    variant: str = "cactus_full",
    campaign_id: str | None = None,
    warmup_lookahead: int = 0,
    pair_plan_path: Path | None = None,
    feedback_manifest_path: Path | None = None,
    scratch_root: Path | None = None,
    command_runner: CommandRunner = _run,
) -> CampaignSummary:
    valid_variants = {"maximal_context", "lexical_bm25", "cactus_full", "cactus_no_symbol_graph", "cactus_no_budget_controller", "cactus_no_failure_recovery", "cactus_static_density", "cactus_test_aware", "cactus_no_test_aware", "cactus_no_semantic", "cactus_no_iteration"}
    if variant not in valid_variants:
        raise ValueError(f"unknown campaign variant: {variant}")
    if campaign_id is not None and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", campaign_id):
        raise ValueError("campaign_id must be 1-128 ASCII letters, digits, '.', '_' or '-'")
    # Resolve once so subprocess cwd and absolute script paths cannot compose a
    # duplicated relative prefix (for example ``acm/acm/scripts``).
    project_root = project_root.resolve()
    # Output paths are bundled (trace/raw/derived/...) and later handed to a
    # subprocess whose cwd is ``project_root``; resolving to absolute paths
    # here ensures the same directory regardless of how the caller invokes
    # the runner (positional, relative, or symlinked).
    output_root = output_root.resolve()
    repo_cache = repo_cache.resolve()
    contract_path = contract_path.resolve()
    approval_path = approval_path.resolve()
    model_config_path = model_config_path.resolve()
    task_manifest = task_manifest.resolve()
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    contract_workload = contract.get("workload", {})
    declared_variants = contract_workload.get("variant_matrix") if isinstance(contract_workload, dict) else None
    experimental_variants = {"cactus_test_aware", "cactus_no_test_aware", "cactus_no_semantic", "cactus_no_iteration"}
    if variant in experimental_variants and declared_variants is None:
        raise RuntimeError("formal campaign blocked: experimental variants require a frozen workload.variant_matrix")
    if declared_variants is not None:
        if not isinstance(declared_variants, list) or not declared_variants or not all(isinstance(item, str) for item in declared_variants):
            raise RuntimeError("formal campaign blocked: workload.variant_matrix must be a non-empty string list")
        if len(set(declared_variants)) != len(declared_variants):
            raise RuntimeError("formal campaign blocked: workload.variant_matrix contains duplicates")
        if variant not in declared_variants:
            raise RuntimeError(f"formal campaign blocked: variant {variant!r} is not in frozen workload.variant_matrix")
    effective_campaign_id = str(campaign_id or contract.get("campaign_id", f"phase-c0-{contract['experiment_id']}"))
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", effective_campaign_id):
        raise ValueError("campaign_id must be 1-128 ASCII letters, digits, '.', '_' or '-'")
    errors = formal_execution_errors(contract, project_root=project_root, approval_path=approval_path)
    # ``metadata_paths`` are contract-relative to the repository root (i.e.
    # they begin with ``acm/`` when project_root is the ``acm`` subproject).
    # Strip that subproject prefix when constructing Path arguments so
    # ``Path.resolve().relative_to(repository)`` does not double-prefix.
    subproject_prefix = project_root.name + "/"
    declared_paths = tuple(
        Path(p.removeprefix(subproject_prefix)) if p.startswith(subproject_prefix) else Path(p)
        for p in contract.get("execution", {}).get("metadata_paths", ())
    )
    errors.extend(_source_commit_errors(source_commit=contract["source"]["git_commit"], contract_path=contract_path, approval_path=approval_path, project_root=project_root, additional_allowed_paths=declared_paths))
    if errors:
        raise RuntimeError("formal campaign blocked: " + "; ".join(errors))
    model_config = json.loads(model_config_path.read_text(encoding="utf-8"))
    contract_scratch = contract.get("execution", {}).get("scratch_root")
    if contract_scratch:
        declared_scratch = Path(str(contract_scratch))
        declared_scratch = declared_scratch if declared_scratch.is_absolute() else project_root / declared_scratch
        declared_scratch = declared_scratch.resolve()
        if scratch_root is not None and scratch_root.resolve() != declared_scratch:
            raise RuntimeError("formal campaign blocked: scratch root does not match the frozen contract")
        scratch_root = declared_scratch
    elif scratch_root is None and os.environ.get("CACTUS_SCRATCH_ROOT"):
        scratch_root = Path(os.environ["CACTUS_SCRATCH_ROOT"])
    if scratch_root is None and os.name == "nt":
        scratch_root = Path("E:\\cactus-data\\temp")
    if scratch_root is None and os.name != "nt":
        scratch_root = project_root / ".cactus-temp"
    scratch_root = scratch_root.resolve()
    _validate_scratch_drive(scratch_root)
    scratch_root.mkdir(parents=True, exist_ok=True)
    contract_image_cache = contract.get("execution", {}).get("image_cache_root")
    if contract_image_cache:
        declared_image_cache = Path(str(contract_image_cache)).resolve()
        env_image_cache = os.environ.get("CACTUS_DOCKER_CACHE_ROOT")
        if env_image_cache and Path(env_image_cache).resolve() != declared_image_cache:
            raise RuntimeError("formal campaign blocked: Docker image cache root does not match the frozen contract")
        image_cache_root = declared_image_cache
    else:
        image_cache_root = Path(os.environ.get("CACTUS_DOCKER_CACHE_ROOT", "E:/docker-bak/cactus/pilot50")).resolve()
    if os.name == "nt" and image_cache_root.drive.upper() == "C":
        raise RuntimeError("formal campaign blocked: Docker image cache root must not be on C:")
    if not image_cache_root.is_dir():
        raise RuntimeError(f"formal campaign blocked: Docker image cache root is unavailable: {image_cache_root}")
    contract_model_config = contract.get("model", {}).get("config") if isinstance(contract.get("model"), dict) else None
    if contract_model_config is not None:
        declared_path = Path(str(contract_model_config))
        if declared_path.is_absolute() or ".." in declared_path.parts:
            raise RuntimeError("formal campaign blocked: unsafe contract model.config path")
        resolved_model_path = (project_root / declared_path).resolve()
        if not resolved_model_path.is_relative_to(project_root) or resolved_model_path != model_config_path:
            raise RuntimeError("formal campaign blocked: command model-config does not match contract model.config")
    binding_errors = model_contract_errors(contract, model_config)
    if binding_errors:
        raise RuntimeError("formal campaign blocked: " + "; ".join(binding_errors))
    inference_key_env = str(model_config["api_key_env"])
    if not os.environ.get(inference_key_env):
        raise RuntimeError("formal campaign blocked: LiteLLM API key is not present in the environment")
    if bool(model_config.get("billing_required", False)) or bool(
        (contract.get("model", {}) if isinstance(contract.get("model"), dict) else {}).get(
            "billing_required", False
        )
    ):
        contract_model = contract.get("model", {}) if isinstance(contract.get("model"), dict) else {}
        contract_billing_source = str(contract_model.get("billing_source", "")).strip()
        billing_key_env = str(
            contract_model.get(
                "billing_api_key_env",
                model_config.get("billing_api_key_env", inference_key_env),
            )
        )
        billing_source = str(model_config.get("billing_source", "litellm_spend_logs"))
        if contract_billing_source and contract_billing_source != billing_source:
            raise RuntimeError(
                "formal campaign blocked: billing source mismatch between contract and model config: "
                f"contract={contract_billing_source!r}, model_config={billing_source!r}"
            )
        expected_alias = str((contract.get("model", {}) if isinstance(contract.get("model"), dict) else {}).get("billing_key_alias", "")).strip()
        if billing_source == "litellm_postgres_spend_logs":
            billing_scope = str(model_config.get("billing_scope", "key_alias"))
            contract_scope = str(contract_model.get("billing_scope", billing_scope))
            if contract_scope != billing_scope:
                raise RuntimeError(
                    "formal campaign blocked: billing scope mismatch between contract and model config: "
                    f"contract={contract_scope!r}, model_config={billing_scope!r}"
                )
            alias_env = str(
                (contract.get("model", {}) if isinstance(contract.get("model"), dict) else {}).get(
                    "billing_log_key_alias_env",
                    model_config.get("billing_log_key_alias_env", "CACTUS_LITELLM_LOG_KEY_ALIAS"),
                )
            )
            required_db_env = {
                "CACTUS_LITELLM_BILLING_SSH_HOST": _session_env("CACTUS_LITELLM_BILLING_SSH_HOST", "NODE0_MGMT_IP")[1],
                "CACTUS_LITELLM_BILLING_SSH_USER": _session_env("CACTUS_LITELLM_BILLING_SSH_USER", "SSH_NODE0_USER", "SSH_OPS_USER")[1],
                "CACTUS_LITELLM_BILLING_SSH_PASSWORD": _session_env("CACTUS_LITELLM_BILLING_SSH_PASSWORD", "SSH_NODE0_PASS")[1],
            }
            if billing_scope == "user_id":
                expected_user_id = str(contract_model.get("billing_user_id", "")).strip()
                actual_user_id = str(model_config.get("billing_user_id", "")).strip()
                # Fail only if contract explicitly requires a specific user_id that doesn't match.
                # An empty expected_user_id means "contract does not constrain; use model config value".
                if expected_user_id and actual_user_id != expected_user_id:
                    raise RuntimeError(
                        "formal campaign blocked: LiteLLM billing user id mismatch: "
                        f"expected {expected_user_id!r}, got {actual_user_id!r}"
                    )
                required_db_env["billing_user_id"] = actual_user_id
            else:
                required_db_env[alias_env] = _session_env(alias_env, "CACTUS_LITELLM_BILLING_KEY_ALIAS")[1]
            missing_db_env = [name for name, value in required_db_env.items() if not value]
            if missing_db_env:
                raise RuntimeError("formal campaign blocked: missing PostgreSQL billing environment: " + ", ".join(missing_db_env))
            if billing_scope == "key_alias" and expected_alias and required_db_env[alias_env] != expected_alias:
                raise RuntimeError(
                    "formal campaign blocked: LiteLLM billing key alias mismatch: "
                    f"expected {expected_alias!r} in {alias_env}, got {required_db_env[alias_env]!r}"
                )
        elif not os.environ.get(billing_key_env):
            raise RuntimeError(f"formal campaign blocked: LiteLLM billing key {billing_key_env} is not present in the environment")
    manifest_tasks = load_manifest(task_manifest)
    task_positions = {task.task_id: index for index, task in enumerate(manifest_tasks)}
    tasks = [task for task in manifest_tasks if task_ids is None or task.task_id in task_ids]
    if (batch_index is None) != (batch_count is None):
        raise ValueError("batch_index and batch_count must be provided together")
    if batch_count is not None and batch_index is not None:
        if task_ids is not None:
            raise ValueError("batch selection cannot be combined with explicit task ids")
        tasks = list(select_task_batch(tasks, batch_index=batch_index, batch_count=batch_count))
    if limit is not None:
        tasks = tasks[:limit]
    iteration_rows: dict[str, dict[str, str]] = {}
    if feedback_manifest_path is not None:
        if pair_plan_path is not None or variant != "cactus_test_aware":
            raise ValueError("E7 feedback retries require cactus_test_aware and cannot be combined with paired plans")
        try:
            provenance_errors = verify_sidecar(feedback_manifest_path)
        except (OSError, ValueError) as error:
            raise ValueError(f"E7 feedback manifest provenance check failed: {error}") from error
        if provenance_errors:
            raise ValueError("E7 feedback manifest provenance check failed: " + "; ".join(provenance_errors))
        for line_number, line in enumerate(feedback_manifest_path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if not isinstance(row, dict) or not all(isinstance(row.get(key), str) for key in ("task_id", "parent_run_id", "category", "feedback")):
                raise ValueError(f"invalid E7 feedback record at line {line_number}")
            if row["category"] not in {"A", "B"}:
                raise ValueError(f"E7 retries are restricted to A/B forensic categories at line {line_number}")
            if not re.fullmatch(r"RUN-[A-Za-z0-9-]{1,80}", row["parent_run_id"]):
                raise ValueError(f"invalid E7 parent RUN ID at line {line_number}")
            if len(row["feedback"]) > 8000:
                raise ValueError(f"E7 feedback exceeds 8000 characters at line {line_number}")
            if row["task_id"] in iteration_rows:
                raise ValueError(f"duplicate E7 feedback task: {row['task_id']}")
            parent_root = output_root / row["parent_run_id"]
            try:
                parent_manifest = json.loads((parent_root / "run_manifest.json").read_text(encoding="utf-8"))
                parent_result = json.loads((parent_root / "raw" / "result.json").read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as error:
                raise ValueError(f"E7 parent RUN is missing or invalid: {row['parent_run_id']}") from error
            parent_data = parent_result.get("data") if isinstance(parent_result.get("data"), dict) else {}
            if validate_bundle(parent_root):
                raise ValueError(f"E7 parent RUN is not sealed and valid: {row['parent_run_id']}")
            if (parent_manifest.get("task_id") != row["task_id"] or parent_manifest.get("status") != "completed"
                    or parent_manifest.get("variant_id") != "cactus_test_aware" or parent_manifest.get("attempt_index", 0) != 0
                    or parent_result.get("experiment_id") != contract.get("experiment_id")
                    or parent_data.get("evaluator_valid") is not True or parent_data.get("resolved") is not False):
                raise ValueError(f"E7 parent RUN is not a valid unresolved task in this experiment: {row['parent_run_id']}")
            iteration_rows[row["task_id"]] = row
        if not iteration_rows:
            raise ValueError("E7 feedback manifest selects no retry tasks")
        if task_ids is None and batch_index is None and batch_count is None:
            tasks = [task for task in manifest_tasks if task.task_id in iteration_rows]
        if {task.task_id for task in tasks} != set(iteration_rows):
            raise ValueError("E7 feedback task IDs must exactly match the selected campaign task IDs")
    if not tasks:
        raise ValueError("campaign selected no tasks")
    if variant in _TEST_AWARE_CAMPAIGN_VARIANTS:
        evaluator_path = Path(evaluator_dataset)
        if not evaluator_path.is_absolute():
            evaluator_path = project_root / evaluator_path
        try:
            evaluation_test_ids = load_evaluation_test_ids(evaluator_path.resolve())
        except (OSError, ValueError) as error:
            raise RuntimeError(f"test-aware treatment blocked: evaluator FAIL_TO_PASS metadata is unavailable or unsafe: {error}") from error
        missing_test_ids = sorted(task.task_id for task in tasks if not evaluation_test_ids.get(task.task_id))
        if missing_test_ids:
            raise RuntimeError(
                "test-aware treatment blocked: evaluator manifest has no FAIL_TO_PASS identifiers for "
                + ", ".join(missing_test_ids[:10])
            )
        tasks = [replace(task, fail_to_pass=evaluation_test_ids[task.task_id]) for task in tasks]
    if warmup_lookahead not in {0, 1, 2}:
        raise ValueError("warmup_lookahead must be 0, 1, or 2")
    paired_rows: dict[str, dict[str, Any]] = {}
    pair_gap_limit: int | None = None
    pair_purpose: str | None = None
    pair_publishable: bool | None = None
    pair_plan_sha256: str | None = None
    pair_execution_state_path: Path | None = None
    if pair_plan_path is not None:
        pair_plan_path = pair_plan_path.resolve()
        pair_plan_bytes = pair_plan_path.read_bytes()
        pair_plan_sha256 = hashlib.sha256(pair_plan_bytes).hexdigest()
        pair_plan = json.loads(pair_plan_bytes.decode("utf-8"))
        if pair_plan.get("task_manifest_sha256") != _sha256(task_manifest):
            raise RuntimeError("paired C1 plan does not match the selected immutable task manifest")
        if pair_plan.get("variants") != ["cactus_full", "maximal_context"]:
            raise RuntimeError("paired C1 plan must freeze cactus_full:maximal_context")
        if pair_plan.get("execution_started") is not False:
            raise RuntimeError("paired C1 plan must be a fresh, unexecuted plan")
        pair_purpose = pair_plan.get("purpose")
        pair_publishable = pair_plan.get("publishable_result")
        if (pair_purpose, pair_publishable) not in (("engineering_validation", False), ("formal_phase_c1", True)):
            raise RuntimeError("paired C1 plan purpose and publication flag are inconsistent")
        if pair_purpose == "engineering_validation" and (limit is None or not 1 <= limit <= 20):
            raise RuntimeError("engineering-validation pair plans require an explicit limit from 1 to 20")
        if pair_purpose == "formal_phase_c1" and limit is not None:
            raise RuntimeError("formal C1 pair plans cannot use a task limit")
        if pair_purpose == "formal_phase_c1":
            for field in ("trace_corpus_id", "trace_corpus_hash", "trace_corpus_freeze_timestamp"):
                if not contract.get(field):
                    raise RuntimeError(f"formal C1 contract is missing frozen {field}")
            if not re.fullmatch(r"[0-9a-f]{64}", str(contract["trace_corpus_hash"])):
                raise RuntimeError("formal C1 trace_corpus_hash must be a complete SHA-256")
            if not isinstance(contract.get("historical_trace_inputs"), list):
                raise RuntimeError("formal C1 contract must explicitly declare historical_trace_inputs")
        protocol_seed = pair_plan.get("protocol_seed")
        if not isinstance(protocol_seed, str) or not protocol_seed.strip():
            raise RuntimeError("paired C1 plan has no frozen protocol seed")
        pair_gap_limit = pair_plan.get("max_pair_gap_minutes")
        if not isinstance(pair_gap_limit, int) or pair_gap_limit <= 0:
            raise RuntimeError("paired C1 plan has no positive frozen pair-gap limit")
        for pair in pair_plan.get("pairs", []):
            if not isinstance(pair, dict) or not isinstance(pair.get("task_id"), str):
                raise RuntimeError("paired C1 plan contains an invalid pair record")
            if pair["task_id"] in paired_rows:
                raise RuntimeError(f"paired C1 plan duplicates task {pair['task_id']}")
            order = pair.get("variant_order")
            if order not in (["cactus_full", "maximal_context"], ["maximal_context", "cactus_full"]):
                raise RuntimeError(f"paired C1 plan has invalid variant order for {pair['task_id']}")
            for field, pattern in (("pair_id", r"C1P-[0-9a-f]{16}"), ("block_id", r"C1B-[0-9a-f]{16}"), ("order_digest", r"[0-9a-f]{64}")):
                if not isinstance(pair.get(field), str) or not re.fullmatch(pattern, pair[field]):
                    raise RuntimeError(f"paired C1 plan has invalid {field} for {pair['task_id']}")
            paired_rows[pair["task_id"]] = pair
        manifest_task_ids = {task.task_id for task in manifest_tasks}
        # Allow subset for engineering-validation (limit < len(manifest_tasks)).
        # Require strict equality only for formal runs where all manifest tasks are loaded.
        if set(paired_rows) != manifest_task_ids:
            if len(tasks) == len(manifest_tasks):
                # Formal run: all tasks loaded — strict equality required
                raise RuntimeError("paired C1 plan task set does not exactly match the frozen manifest")
            # Engineering-validation with a task subset: check that paired tasks are in the manifest
            unknown = set(paired_rows) - manifest_task_ids
            if unknown:
                raise RuntimeError("paired C1 plan contains tasks not in manifest: " + ", ".join(sorted(unknown)[:10]))
        missing_pairs = sorted(task.task_id for task in tasks if task.task_id not in paired_rows)
        if missing_pairs:
            raise RuntimeError("paired C1 plan misses selected tasks: " + ", ".join(missing_pairs[:10]))
        if pair_purpose == "formal_phase_c1":
            frozen_count = int(contract.get("execution", {}).get("task_count", 0))
            if len(tasks) != frozen_count or len(manifest_tasks) != frozen_count:
                raise RuntimeError("formal C1 execution must include every task in the frozen task-count contract")
        if warmup_lookahead == 0:
            warmup_lookahead = 2
        pair_execution_state_path = _claim_pair_plan_execution(
            pair_plan_path,
            pair_plan_sha256,
            effective_campaign_id,
        )
    usage_required = bool(model_config.get("usage_required", False))
    prior_diagnostics = _prior_campaign_run_diagnostics(
        output_root,
        contract,
        campaign_id=effective_campaign_id,
        usage_required=usage_required,
    )
    prior_stop_reason = _campaign_stop_reason(prior_diagnostics, contract)
    if prior_stop_reason is not None:
        raise RuntimeError(
            "formal campaign blocked by cumulative prior RUN evidence: " + prior_stop_reason
        )
    _progress("campaign.ready", campaign_id=effective_campaign_id, experiment_id=contract["experiment_id"], task_count=len(tasks), variant_id=variant, budget_usd=contract.get("execution", {}).get("cost_budget", {}).get("amount", "unknown"))
    prior_run_ids: list[str] = []
    if pair_execution_state_path and pair_execution_state_path.is_file():
        try:
            prior_state = json.loads(pair_execution_state_path.read_text(encoding="utf-8"))
            prior_run_ids = prior_state.get("run_ids", [])
        except Exception:
            pass
    elif not pair_plan_path:
        prior_run_ids = [item["run_id"] for item in prior_diagnostics if item.get("run_id") and not item.get("integrity_failure")]
    run_ids: list[str] = list(prior_run_ids)  # resume from where we left off
    run_diagnostics: list[dict[str, Any]] = []
    prior_task_ids = {item["task_id"] for item in prior_diagnostics if item.get("task_id") and item.get("status") == "completed" and not item.get("integrity_failure")}
    completed = sum(1 for item in prior_diagnostics if item.get("status") == "completed" and not item.get("integrity_failure"))
    contract_metadata = contract.get("_metadata", {})
    pilot_scope = (
        isinstance(contract_metadata, dict) and contract_metadata.get("candidate_scope") == "pilot"
    ) or "PILOT" in str(contract.get("experiment_id", "")).upper()
    image_lifecycle = None
    warmup_pool = None
    prepared: dict[str, Any] = {}
    prepared_lock = threading.Lock()
    if warmup_lookahead:
        image_lifecycle, warmup_pool = _image_tools(project_root, command_runner, lookahead=warmup_lookahead, cache_root=image_cache_root)
        tasks_by_id = {task.task_id: task for task in tasks}
        warmup_log = project_root / "analysis" / "phase_c_warmup.jsonl"
        warmup_log_lock = threading.Lock()

        def append_warmup_event(event: dict[str, Any]) -> None:
            warmup_log.parent.mkdir(parents=True, exist_ok=True)
            with warmup_log_lock:
                with warmup_log.open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")

        def warm_task(task_id: str) -> Any:
            started = time.monotonic()
            started_at = utc_now()
            row = tasks_by_id[task_id]
            try:
                mirror = repo_cache / f"{row.repo_id.replace('/', '__')}.git"
                if not mirror.is_dir():
                    raise FileNotFoundError(f"read-only repository mirror is missing for {task_id}")
                base_check = command_runner(
                    ["git", "-C", str(mirror), "cat-file", "-e", f"{row.base_commit}^{{commit}}"],
                    repo_cache,
                    60,
                )
                if base_check.returncode != 0:
                    raise RuntimeError(f"read-only repository mirror lacks the frozen base commit for {task_id}")
                image = _pinned_image_ref(row, task_positions, contract)
                position = task_positions[task_id]
                image_row = contract.get("images", {}).get(f"eval_{position + 1:03d}", {})
                spec = image_lifecycle.pre_task(
                    task_id,
                    image.rsplit("@", 1)[-1],
                    contract_image_id=image_row.get("local_image_id") if isinstance(image_row, dict) else None,
                    contract_archive_path=image_row.get("archive_path") if isinstance(image_row, dict) else None,
                    contract_archive_sha256=image_row.get("archive_sha256") if isinstance(image_row, dict) else None,
                    contract_archive_size_bytes=image_row.get("archive_size_bytes") if isinstance(image_row, dict) else None,
                    contract_repository=image_row.get("repository") if isinstance(image_row, dict) else None,
                    contract_tag=image_row.get("tag") if isinstance(image_row, dict) else None,
                )
                event = {
                    "event": "warmup",
                    "task_id": task_id,
                    "started_at": started_at,
                    "finished_at": utc_now(),
                    "image_size_mb": round(spec.archive_path.stat().st_size / (1024 * 1024), 3) if spec.archive_path else None,
                    "prefetched_bytes": 0,
                    "image_ref": getattr(spec, "pinned_ref", None),
                    "image_digest": getattr(spec, "expected_digest", None),
                    "image_archive_path": spec.archive_path.as_posix() if spec.archive_path else None,
                    "image_archive_sha256": image_row.get("archive_sha256") if isinstance(image_row, dict) else None,
                    "image_archive_size_bytes": image_row.get("archive_size_bytes") if isinstance(image_row, dict) else None,
                    "cache_action": "loaded_from_archive" if getattr(spec, "loaded_from_archive", False) else "verified_local",
                    "status": "completed",
                }
                with prepared_lock:
                    prepared[task_id] = spec
                return spec
            except Exception as exc:
                event = {
                    "task_id": task_id,
                    "started_at": started_at,
                    "finished_at": utc_now(),
                    "image_size_mb": None,
                    "prefetched_bytes": 0,
                    "status": "failed",
                    "error_type": type(exc).__name__,
                }
                raise
            finally:
                event["warmup_latency_seconds"] = round(time.monotonic() - started, 3)
                append_warmup_event(event)

    if image_lifecycle is None:
        # Serial formal runs still require on-demand archive loading and
        # post-task eviction; only speculative prefetch is disabled.
        image_lifecycle = _image_lifecycle_only(
            project_root,
            command_runner,
            cache_root=image_cache_root,
        )

    try:
        expected_run_count = len(tasks) * (2 if pair_plan_path else 1)
        stop_campaign = False
        for index, task in enumerate(tasks):
            if not pair_plan_path and task.task_id in prior_task_ids:
                continue
            pair_record = paired_rows.get(task.task_id)
            if warmup_pool is not None:
                warmup_pool.schedule_ahead([item.task_id for item in tasks], index, warm_task)
                warmup_pool.block_for(task.task_id, timeout=120)
                with prepared_lock:
                    task_is_prepared = task.task_id in prepared
                if not task_is_prepared:
                    warm_task(task.task_id)
            pinned_image = _pinned_image_ref(task, task_positions, contract)
            variant_order = pair_record["variant_order"] if pair_record else [variant]
            pair_started = time.monotonic()
            first_manifest_started: str | None = None
            pair_run_count = 0
            for variant_position, run_variant in enumerate(variant_order):
                if variant_position == 1 and pair_started is not None:
                    gap_seconds = time.monotonic() - pair_started
                    if pair_record and gap_seconds > pair_gap_limit * 60:
                        _progress("paired_c1.gap_exceeded", task_id=task.task_id, pair_id=pair_record["pair_id"], gap_seconds=round(gap_seconds, 3), limit_minutes=pair_gap_limit)
                        break
                pair_metadata = None
                if pair_record is not None:
                    pair_metadata = {
                        "pair_id": pair_record["pair_id"],
                        "block_id": pair_record["block_id"],
                        "order_digest": pair_record["order_digest"],
                        "protocol_seed_sha256": hashlib.sha256(str(pair_plan["protocol_seed"]).encode("utf-8")).hexdigest(),
                        "max_pair_gap_minutes": pair_gap_limit,
                        "variant_order": variant_order,
                        "variant_position": variant_position,
                        "first_variant_started_at": first_manifest_started,
                    }
                run_id, passed = run_task(
                    task,
                    contract=contract,
                    model_config=model_config,
                    output_root=output_root,
                    project_root=project_root,
                    task_manifest=task_manifest,
                    evaluator_dataset=evaluator_dataset,
                    repo_cache=repo_cache,
                    variant=run_variant,
                    campaign_id=effective_campaign_id,
                    pinned_image=pinned_image,
                    image_lifecycle=image_lifecycle,
                    read_only_repo_cache=bool(warmup_lookahead),
                    paired_c1=pair_metadata,
                    purpose=pair_purpose,
                    publishable_result=pair_publishable,
                    attempt_index=1 if task.task_id in iteration_rows else 0,
                    parent_attempt_id=iteration_rows.get(task.task_id, {}).get("parent_run_id"),
                    retry_reason="evaluator_feedback_iteration" if task.task_id in iteration_rows else None,
                    iteration_feedback=iteration_rows.get(task.task_id, {}).get("feedback"),
                    scratch_root=scratch_root,
                    command_runner=command_runner,
                    token_policy=_normalized_token_policy(
                        contract,
                        prior_diagnostics + run_diagnostics,
                        remaining_task_count=max(0, expected_run_count - len(prior_diagnostics) - len(run_diagnostics)),
                    ),
                )
                run_ids.append(run_id)
                pair_run_count += 1
                completed += int(passed)
                diagnostic = _campaign_run_diagnostics(
                    output_root,
                    run_id,
                    usage_required=usage_required,
                )
                run_diagnostics.append(diagnostic)
                stop_reason = _campaign_stop_reason(prior_diagnostics + run_diagnostics, contract)
                manifest_path = output_root / run_id / "run_manifest.json"
                if manifest_path.is_file():
                    run_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                    if variant_position == 0:
                        first_manifest_started = run_manifest.get("started_at")
                    elif pair_record:
                        second_started = run_manifest.get("started_at")
                        if first_manifest_started and second_started:
                            first_dt = datetime.strptime(first_manifest_started, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                            second_dt = datetime.strptime(second_started, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                            actual_gap = (second_dt - first_dt).total_seconds()
                            _progress("paired_c1.pair_gap", task_id=task.task_id, pair_id=pair_record["pair_id"], gap_seconds=actual_gap, limit_minutes=pair_gap_limit)
                            if actual_gap > pair_gap_limit * 60:
                                _progress("paired_c1.gap_exceeded", task_id=task.task_id, pair_id=pair_record["pair_id"], gap_seconds=actual_gap, limit_minutes=pair_gap_limit)
                _progress("campaign.task_result", campaign_id=effective_campaign_id, task_id=task.task_id, run_id=run_id, variant_id=run_variant, status="completed" if passed else "failed", completed_count=completed, processed_count=len(run_ids), total_count=(len(tasks) * (2 if pair_plan_path else 1)))
                if stop_reason is not None:
                    _progress(
                        "campaign.halted",
                        campaign_id=effective_campaign_id,
                        task_id=task.task_id,
                        run_id=run_id,
                        reason=stop_reason,
                        unattempted_count=max(0, expected_run_count - len(run_ids)),
                    )
                    stop_campaign = True
                    break
                if not passed and pair_purpose == "engineering_validation":
                    _progress(
                        "campaign.halted",
                        campaign_id=effective_campaign_id,
                        task_id=task.task_id,
                        reason="engineering_validation_run_failed; fail-closed pilot gate prevents spending on remaining variants and tasks",
                        unattempted_count=max(0, expected_run_count - len(run_ids)),
                    )
                    break
                if not passed and pilot_scope:
                    _progress(
                        "campaign.halted",
                        campaign_id=effective_campaign_id,
                        task_id=task.task_id,
                        reason="pilot_run_failed; fail-closed pilot gate prevents spending on remaining tasks",
                        unattempted_count=max(0, expected_run_count - len(run_ids)),
                    )
                    break
            if image_lifecycle is not None:
                with prepared_lock:
                    spec = prepared.get(task.task_id)
                if spec is not None:
                    image_lifecycle.release(spec)
                next_needed_refs: list[str] = []
                lookahead_end = min(len(tasks), index + 1 + int(warmup_lookahead or 0))
                for upcoming in tasks[index + 1 : lookahead_end]:
                    next_needed_refs.append(_pinned_image_ref(upcoming, task_positions, contract))
                removed_refs = list(image_lifecycle.cleanup_expired(next_needed_refs=next_needed_refs))
                with prepared_lock:
                    known_specs = tuple(prepared.values())
                removed_images = []
                for reference in removed_refs:
                    matched = next(
                        (candidate for candidate in known_specs if reference in {candidate.image_ref, candidate.pinned_ref}),
                        None,
                    )
                    removed_images.append({
                        "image_ref": reference,
                        "digest": getattr(matched, "expected_digest", None),
                    })
                if warmup_pool is not None:
                    append_warmup_event({
                        "event": "eviction_check",
                        "task_id": task.task_id,
                        "finished_at": utc_now(),
                        "next_needed_refs": next_needed_refs,
                        "removed_images": removed_images,
                        "status": "completed",
                    })
            if pair_record and pair_run_count != 2:
                break
            if not pair_record and not passed and pilot_scope:
                _progress(
                    "campaign.halted",
                    campaign_id=effective_campaign_id,
                    task_id=task.task_id,
                    reason="pilot_run_failed; fail-closed pilot gate prevents spending on remaining tasks",
                    unattempted_count=len(tasks) - len(run_ids),
                )
                break
            if stop_campaign:
                break
    finally:
        if warmup_pool is not None:
            warmup_pool.close()
    failed = len(run_ids) - completed
    _progress("campaign.finish", campaign_id=effective_campaign_id, experiment_id=contract["experiment_id"], task_count=len(run_ids), selected_task_count=len(tasks), variant_id="cactus_full:maximal_context" if pair_plan_path else variant, completed=completed, failed=failed, unattempted=max(0, expected_run_count - len(run_ids)))
    if pair_execution_state_path is not None and pair_plan_sha256 is not None:
        state = "completed" if len(run_ids) == expected_run_count and failed == 0 else "partial"
        _finish_pair_plan_execution(pair_execution_state_path, pair_plan_sha256, status=state, run_ids=run_ids)
    return CampaignSummary(effective_campaign_id, len(run_ids), completed, failed, tuple(run_ids))
