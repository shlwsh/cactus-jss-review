"""Fail-closed preflight for JSON-normalized experiment contracts."""

from __future__ import annotations

import subprocess
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any

from cactus.governance.contract import validate_contract


_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_IMAGE_ID = re.compile(r"^sha256:[0-9a-f]{64}$")


def _archive_binding_errors(
    name: str,
    image: dict[str, Any],
    verified_archives: dict[tuple[Path, str, int], list[str]],
) -> list[str] | None:
    """Validate a complete on-demand archive binding without loading Docker.

    A ``None`` result means that the image has no complete archive binding and
    therefore must retain the legacy local-image preflight.  A list (possibly
    empty) means archive-mode is applicable and its validation is authoritative.
    """
    archive_keys = ("archive_path", "archive_sha256", "archive_size_bytes")
    keys = (*archive_keys, "local_image_id")
    if not any(key in image for key in archive_keys):
        return None
    provided = [key for key in keys if key in image]
    errors: list[str] = []
    if len(provided) != len(keys):
        return [f"image_archive_binding: images.{name} has incomplete archive binding"]
    archive_path = image["archive_path"]
    archive_sha256 = image["archive_sha256"]
    archive_size = image["archive_size_bytes"]
    runtime_id = image["local_image_id"]
    if not isinstance(archive_path, str) or not archive_path:
        errors.append(f"image_archive_binding: images.{name}.archive_path is invalid")
    if not isinstance(archive_sha256, str) or not _SHA256.fullmatch(archive_sha256):
        errors.append(f"image_archive_binding: images.{name}.archive_sha256 is invalid")
    if not isinstance(archive_size, int) or isinstance(archive_size, bool) or archive_size <= 0:
        errors.append(f"image_archive_binding: images.{name}.archive_size_bytes is invalid")
    if not isinstance(runtime_id, str) or not _IMAGE_ID.fullmatch(runtime_id):
        errors.append(f"image_archive_binding: images.{name}.local_image_id is invalid")
    if errors:
        return errors
    path = Path(archive_path)
    cache_key = (path, archive_sha256, archive_size)
    if cache_key in verified_archives:
        return verified_archives[cache_key]
    if not path.is_file():
        result = [f"image_archive_binding: images.{name} archive is missing: {path}"]
        verified_archives[cache_key] = result
        return result
    observed_size = path.stat().st_size
    if observed_size != archive_size:
        result = [f"image_archive_binding: images.{name} archive size mismatch: expected {archive_size}, got {observed_size}"]
        verified_archives[cache_key] = result
        return result
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != archive_sha256:
        result = [f"image_archive_binding: images.{name} archive SHA-256 mismatch"]
        verified_archives[cache_key] = result
        return result
    verified_archives[cache_key] = []
    return []


def image_locally_present_errors(contract: dict[str, Any]) -> list[str]:
    """Check local images, or verify complete on-demand archive bindings offline."""
    errors: list[str] = []
    images = contract.get("images", {})
    if not isinstance(images, dict):
        return errors
    docker = os.environ.get("CACTUS_DOCKER_BIN", "docker")
    verified_archives: dict[tuple[Path, str, int], list[str]] = {}
    for name, image in images.items():
        if not isinstance(image, dict) or not image.get("local_image_id"):
            continue
        archive_errors = _archive_binding_errors(name, image, verified_archives)
        if archive_errors is not None:
            errors.extend(archive_errors)
            continue
        expected = image["local_image_id"]
        repository, tag = image.get("repository"), image.get("tag")
        if not isinstance(repository, str) or not isinstance(tag, str):
            errors.append(f"image_locally_present: images.{name} lacks repository/tag")
            continue
        try:
            result = subprocess.run(
                [docker, "image", "inspect", f"{repository}:{tag}", "--format", "{{json .Id}}"],
                capture_output=True, text=True, check=False, timeout=30,
            )
        except (OSError, subprocess.TimeoutExpired):
            errors.append(f"image_locally_present: unable to inspect images.{name}")
            continue
        try:
            observed = json.loads(result.stdout) if result.returncode == 0 else None
        except json.JSONDecodeError:
            observed = None
        if observed != expected:
            errors.append(f"image_locally_present: images.{name} expected local image ID {expected}, got {observed or 'missing'}")
    return errors


def preflight(contract: dict[str, Any], *, project_root: Path, require_clean_tree: bool = True) -> list[str]:
    errors = validate_contract(contract)
    errors.extend(image_locally_present_errors(contract))
    # Honor contract.source.require_clean_tree when explicitly false.
    # Default callers still opt in via the kwarg for backwards compatibility.
    source = contract.get("source", {}) if isinstance(contract, dict) else {}
    if isinstance(source, dict) and source.get("require_clean_tree") is False:
        require_clean_tree = False
    if require_clean_tree:
        result = subprocess.run(["git", "status", "--porcelain"], cwd=project_root, check=False, capture_output=True, text=True)
        if result.returncode != 0:
            errors.append("unable to inspect git tree")
        elif result.stdout.strip():
            errors.append("formal experiment requires a clean git tree")
    return errors
