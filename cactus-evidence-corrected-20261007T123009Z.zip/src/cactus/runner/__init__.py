"""Dry-run and preflight orchestration."""
