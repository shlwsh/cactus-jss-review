"""Tier-aware formal execution authorization gate.

v2.0: 替代原来的完全阻塞模型，改为 tier 分级处理：
  - paper_primary:   全票否决，owner 必须人工签字
  - paper_supporting: AUTO_COMMIT dirty tree，AUTO_REFRESH SHA，commit range 自动续期
  - exploratory:     跳过 G0 检查

使用方式（替换原来 formal.py 中的调用）:
    from cactus.runner.formal_v2 import formal_execution_errors_tier

    errors = formal_execution_errors_tier(
        contract,
        project_root=Path("."),
        tier="paper_supporting",
        auth_path=Path("experiments/contracts/xxx.session_authorization.json"),
    )
    if errors:
        raise RuntimeError("; ".join(errors))
"""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from pathlib import Path
from typing import Any

from cactus.governance.canonical import canonical_json
from cactus.governance.contract import validate_contract
from cactus.governance.schema import (
    validate_approval_marker,
    validate_session_authorization,
)
from cactus.runner.preflight import preflight

_IMAGE_DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{64}$")

# ---- tier_policy.yaml 加载（惰性缓存） ---------------------------------------
_tier_policy_cache: dict[str, Any] | None = None


def _load_tier_policy(policy_path: Path | None = None) -> dict[str, Any]:
    """Load tier_policy.yaml with lazy caching."""
    global _tier_policy_cache
    if _tier_policy_cache is not None:
        return _tier_policy_cache

    if policy_path is None:
        # 尝试从标准路径加载
        candidates = [
            Path("experiments/catalog/tier_policy.yaml"),
            Path("../experiments/catalog/tier_policy.yaml"),
        ]
        for p in candidates:
            if p.exists():
                policy_path = p
                break

    if policy_path and policy_path.exists():
        import yaml

        _tier_policy_cache = yaml.safe_load(policy_path.read_text(encoding="utf-8"))
        return _tier_policy_cache

    # fallback：内嵌默认值
    _tier_policy_cache = {
        "tiers": {
            "paper_primary": {
                "require_clean_tree": True,
                "require_owner_signature": True,
                "approval_mode": "manual",
            },
            "paper_supporting": {
                "require_clean_tree": False,
                "require_owner_signature": False,
                "approval_mode": "range",
                "auto_renew_on_commit": True,
            },
            "exploratory": {
                "require_clean_tree": False,
                "require_owner_signature": False,
                "approval_mode": "none",
            },
        }
    }
    return _tier_policy_cache


def _get_git_head() -> str:
    """Get current git HEAD commit SHA."""
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ""


def _get_git_status() -> bool:
    """Return True if tree is dirty."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return bool(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def _auto_commit(reason: str) -> str:
    """Auto git add + commit. Returns commit SHA."""
    try:
        subprocess.run(["git", "add", "-A"], check=True, capture_output=True)
        commit_msg = f"wip: auto-commit by formal_v2 [reason: {reason}] [{_get_git_head()[:8]}]"
        result = subprocess.run(
            ["git", "commit", "-m", commit_msg],
            capture_output=True,
            text=True,
            check=True,
        )
        return _get_git_head()
    except subprocess.CalledProcessError as e:
        return f"AUTO_COMMIT_FAILED: {e.stderr}"


def _auto_refresh_contract_sha(contract_path: Path) -> str:
    """Rehash contract and update compose_sha256 field. Returns new SHA."""
    content = contract_path.read_bytes()
    new_sha = hashlib.sha256(content).hexdigest()

    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return new_sha

    if isinstance(data, dict) and "runtime" in data:
        data["runtime"]["compose_sha256"] = new_sha
        contract_path.write_bytes(canonical_json(data).encode("utf-8"))
    return new_sha


def _is_commit_in_range(commit: str, range_str: str) -> bool:
    """Check if commit is within git range. range_str like 'abc123..def456'."""
    if not commit or not range_str or ".." not in range_str:
        return False
    try:
        result = subprocess.run(
            ["git", "merge-base", "--is-ancestor", commit, range_str.split("..")[1]],
            capture_output=True,
        )
        return result.returncode == 0
    except subprocess.CalledProcessError:
        return False


def formal_execution_errors_tier(
    contract: dict[str, Any],
    *,
    project_root: Path,
    tier: str = "paper_supporting",
    auth_path: Path | None = None,
    dry_run: bool = False,
) -> list[tuple[str, str]]:
    """Tier-aware formal execution gate.

    Returns list of (code, message) tuples.
    Empty list = PASS.
    code = "AUTO_FIX" means the issue was auto-fixed and gate passed.
    code = "BLOCK" means the issue blocks execution (owner required).

    Examples:
        errors = formal_execution_errors_tier(contract, project_root=Path("."), tier="paper_supporting")
        for code, msg in errors:
            if code == "AUTO_FIX":
                print(f"[AUTO_FIXED] {msg}")
            elif code == "BLOCK":
                print(f"[BLOCKED] {msg}")
    """
    policy = _load_tier_policy()
    tier_config = policy.get("tiers", {}).get(tier, {})
    g0_behavior = policy.get("g0_behavior_by_tier", {}).get(tier, {})
    errors: list[tuple[str, str]] = []

    # ---- G0: git commit exact -----------------------------------------------
    git_commit_behavior = g0_behavior.get("git_commit_exact", "STRICT")
    source = contract.get("source", {})
    declared_commit = source.get("git_commit", "")

    if git_commit_behavior == "STRICT":
        current_head = _get_git_head()
        if declared_commit and declared_commit != current_head:
            errors.append(
                ("BLOCK", f"G0/GIT_COMMIT: declared={declared_commit[:8]} current={current_head[:8]} — paper_primary requires exact match. Owner signature required.")
            )
        elif not declared_commit:
            errors.append(
                ("BLOCK", "G0/GIT_COMMIT: git_commit field is empty — paper_primary requires exact commit SHA")
            )
        else:
            errors.append(
                ("AUTO_FIX", f"G0/GIT_COMMIT: PASS (exact match {current_head[:8]})")
            )

    elif git_commit_behavior == "RANGE":
        # paper_supporting: 允许 range，检查 auth_path 中的 approved_commit_range
        current_head = _get_git_head()
        if auth_path and auth_path.exists():
            auth_data = json.loads(auth_path.read_text(encoding="utf-8"))
            tier_auth = auth_data.get(tier, {})
            approved_range = tier_auth.get("approved_commit_range", "")
            auto_renew = tier_auth.get("auto_renew_on_commit", False)

            if approved_range and ".." in approved_range:
                base_commit = approved_range.split("..")[0]
                # 越界：HEAD 不在 range 内
                try:
                    in_range = subprocess.run(
                        ["git", "merge-base", "--is-ancestor", base_commit, current_head],
                        capture_output=True,
                    ).returncode == 0
                except subprocess.CalledProcessError:
                    in_range = False

                if not in_range:
                    if auto_renew and not dry_run:
                        _auto_commit(f"approved_commit_range extended by auto_renew (tier={tier})")
                        errors.append(
                            ("AUTO_FIX", f"G0/GIT_COMMIT: AUTO_COMMIT applied, range extended to HEAD {current_head[:8]}")
                        )
                    else:
                        errors.append(
                            ("BLOCK", f"G0/GIT_COMMIT: HEAD {current_head[:8]} out of approved range {approved_range[:16]}... — owner signature required")
                        )
                else:
                    errors.append(
                        ("AUTO_FIX", f"G0/GIT_COMMIT: PASS (in range {approved_range[:16]}...)")
                    )
            else:
                errors.append(
                    ("AUTO_FIX", f"G0/GIT_COMMIT: PASS (no range restriction, HEAD={current_head[:8]})")
                )
        else:
            # 无 auth_path → exploratory 行为，直接通过
            errors.append(
                ("AUTO_FIX", f"G0/GIT_COMMIT: PASS (no auth required, tier={tier})")
            )

    else:  # SKIP
        errors.append(
            ("AUTO_FIX", "G0/GIT_COMMIT: SKIP (tier=exploratory)")
        )

    # ---- G0: tree clean ----------------------------------------------------
    tree_clean_behavior = g0_behavior.get("tree_clean", "BLOCK")
    is_dirty = _get_git_status()

    if tree_clean_behavior == "BLOCK":
        if is_dirty:
            errors.append(
                ("BLOCK", "G0/TREE_CLEAN: dirty tree detected — paper_primary requires owner signature. Run 'git add -A && git commit' first.")
            )
        else:
            errors.append(
                ("AUTO_FIX", "G0/TREE_CLEAN: PASS (tree clean)")
            )

    elif tree_clean_behavior == "AUTO_COMMIT":
        if is_dirty:
            if not dry_run:
                new_sha = _auto_commit(f"dirty tree auto-fixed by formal_v2 (tier={tier})")
                errors.append(
                    ("AUTO_FIX", f"G0/TREE_CLEAN: AUTO_COMMIT applied, new HEAD={new_sha[:8]}")
                )
            else:
                errors.append(
                    ("AUTO_FIX", "G0/TREE_CLEAN: AUTO_COMMIT pending (dry_run=true)")
                )
        else:
            errors.append(
                ("AUTO_FIX", "G0/TREE_CLEAN: PASS (tree clean)")
            )

    else:  # SKIP
        errors.append(
            ("AUTO_FIX", "G0/TREE_CLEAN: SKIP (tier=exploratory)")
        )

    # ---- G0: contract SHA --------------------------------------------------
    contract_sha_behavior = g0_behavior.get("contract_sha", "STRICT")
    runtime = contract.get("runtime", {})
    declared_sha = runtime.get("compose_sha256", "")

    if contract_sha_behavior == "STRICT":
        if isinstance(contract.get("_source_path"), Path):
            contract_path: Path = contract["_source_path"]
            actual_sha = hashlib.sha256(contract_path.read_bytes()).hexdigest()
            if declared_sha and declared_sha != actual_sha:
                errors.append(
                    ("BLOCK", f"G0/CONTRACT_SHA: declared={declared_sha[:16]}... actual={actual_sha[:16]}... — paper_primary requires exact SHA. Run 'make autofix-contract'.")
                    )
            elif not declared_sha:
                errors.append(
                    ("BLOCK", "G0/CONTRACT_SHA: compose_sha256 is empty — paper_primary requires SHA")
                )
            else:
                errors.append(
                    ("AUTO_FIX", f"G0/CONTRACT_SHA: PASS (exact SHA {actual_sha[:16]}...)")
                )

    elif contract_sha_behavior == "AUTO_REFRESH":
        if isinstance(contract.get("_source_path"), Path):
            contract_path = contract["_source_path"]
            actual_sha = hashlib.sha256(contract_path.read_bytes()).hexdigest()
            if declared_sha and declared_sha != actual_sha:
                if not dry_run:
                    new_sha = _auto_refresh_contract_sha(contract_path)
                    errors.append(
                        ("AUTO_FIX", f"G0/CONTRACT_SHA: AUTO_REFRESH applied, SHA updated to {new_sha[:16]}...")
                    )
                else:
                    errors.append(
                        ("AUTO_FIX", f"G0/CONTRACT_SHA: AUTO_REFRESH pending (dry_run=true, new SHA={actual_sha[:16]}...)")
                    )
            else:
                errors.append(
                    ("AUTO_FIX", f"G0/CONTRACT_SHA: PASS (SHA={actual_sha[:16]}...)")
                )

    else:  # SKIP
        errors.append(
            ("AUTO_FIX", "G0/CONTRACT_SHA: SKIP (tier=exploratory)")
        )

    # ---- G1: image digest (always strict, non-negotiable) -----------------
    images = contract.get("images", {})
    if isinstance(images, dict):
        for name, image in sorted(images.items()):
            digest = image.get("digest") if isinstance(image, dict) else None
            if not isinstance(digest, str) or not _IMAGE_DIGEST_RE.fullmatch(digest):
                errors.append(
                    ("BLOCK", f"G1/IMAGE_DIGEST: images.{name}.digest must be sha256:... (got '{digest}') — non-negotiable")
                )

    return errors


def print_g0_report(errors: list[tuple[str, str]]) -> None:
    """Pretty-print G0 gate report."""
    has_block = any(code == "BLOCK" for code, _ in errors)
    color = "\033[0;31m" if has_block else "\033[0;32m"
    status = "FAIL" if has_block else "PASS"
    reset = "\033[0m"

    print(f"\n{color}=== G0 Gate Report ==={reset}")
    for code, msg in errors:
        icon = "⚡" if code == "AUTO_FIX" else "🔒"
        print(f"  {icon} [{code:10s}] {msg}")
    print(f"\n  → G0 Overall: {color}{status}{reset}")
    if has_block:
        print("  → Action required: owner signature needed")
