"""Plan matched Phase C1 task pairs and execute only after gated preflight.

The default command writes a deterministic plan. ``--execute`` delegates to
the campaign runner, which enforces authorization, integrity, resource, and
publication-purpose gates before starting work.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


PAIR = ("cactus_full", "maximal_context")


@dataclass(frozen=True, slots=True)
class TaskPair:
    task_id: str
    pair_id: str
    block_id: str
    variant_order: tuple[str, str]
    order_digest: str


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def make_pair(task_id: str, protocol_seed: str) -> TaskPair:
    """Create stable identifiers and balanced order from frozen inputs."""
    if not task_id.strip() or not protocol_seed.strip():
        raise ValueError("task_id and protocol_seed must be non-empty")
    source = f"{task_id}{protocol_seed}"
    digest = _digest(source)
    order = PAIR if int(digest[:2], 16) % 2 == 0 else (PAIR[1], PAIR[0])
    identity = digest[:16]
    return TaskPair(
        task_id=task_id,
        pair_id=f"C1P-{identity}",
        block_id=f"C1B-{identity}",
        variant_order=order,
        order_digest=digest,
    )


def _read_manifest(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        row = json.loads(line)
        if not isinstance(row, dict) or not isinstance(row.get("task_id"), str):
            raise ValueError(f"manifest line {number} has no string task_id")
        task_id = row["task_id"]
        if task_id in seen:
            raise ValueError(f"duplicate task_id in manifest: {task_id}")
        seen.add(task_id)
        rows.append(row)
    if not rows:
        raise ValueError("task manifest is empty")
    return rows


def build_plan(
    manifest: Path,
    *,
    protocol_seed: str,
    max_pair_gap_minutes: int | None,
    purpose: str = "engineering_validation",
) -> dict[str, Any]:
    """Build metadata only; unknown freeze parameters fail closed."""
    if max_pair_gap_minutes is None or max_pair_gap_minutes <= 0:
        raise ValueError("approved max_pair_gap_minutes is required")
    if not protocol_seed.strip():
        raise ValueError("frozen protocol_seed is required")
    if purpose not in {"engineering_validation", "formal_phase_c1"}:
        raise ValueError("purpose must be engineering_validation or formal_phase_c1")
    rows = _read_manifest(manifest)
    manifest_hash = hashlib.sha256(manifest.read_bytes()).hexdigest()
    pairs = [asdict(make_pair(str(row["task_id"]), protocol_seed)) for row in rows]
    return {
        "schema_version": 1,
        "purpose": purpose,
        "publishable_result": purpose == "formal_phase_c1",
        "execution_started": False,
        "task_manifest": manifest.resolve().as_posix(),
        "task_manifest_sha256": manifest_hash,
        "protocol_seed": protocol_seed,
        "max_pair_gap_minutes": max_pair_gap_minutes,
        "variants": list(PAIR),
        "pairs": pairs,
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-manifest", type=Path, required=True)
    parser.add_argument("--protocol-seed")
    parser.add_argument("--max-pair-gap-minutes", type=int)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--purpose", choices=("engineering_validation", "formal_phase_c1"), default="engineering_validation")
    parser.add_argument("--execute", action="store_true", help="run the paired task sequence after formal preflight")
    parser.add_argument("--campaign-id")
    parser.add_argument("--contract", type=Path)
    parser.add_argument("--approval", type=Path)
    parser.add_argument("--model-config", type=Path)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--project-root", type=Path)
    parser.add_argument("--evaluator-dataset")
    parser.add_argument("--repo-cache", type=Path)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    if not args.protocol_seed:
        parser.error("--protocol-seed must be supplied after owner freeze")
    try:
        plan = build_plan(
            args.task_manifest,
            protocol_seed=args.protocol_seed,
            max_pair_gap_minutes=args.max_pair_gap_minutes,
            purpose=args.purpose,
        )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"Wrote {args.purpose} pair plan for {len(plan['pairs'])} tasks; no execution started.")
    if not args.execute:
        return 0
    required = (args.campaign_id, args.contract, args.approval, args.model_config, args.output_root, args.project_root, args.evaluator_dataset)
    if any(value is None for value in required):
        parser.error("--execute requires campaign, contract, approval, model, output, project-root, and evaluator-dataset options")
    if args.purpose == "formal_phase_c1" and args.limit is not None:
        parser.error("formal_phase_c1 does not accept --limit")
    if args.purpose == "engineering_validation" and (args.limit is None or args.limit < 1 or args.limit > 20):
        parser.error("engineering_validation requires --limit between 1 and 20")
    from cactus.runner.swebench_campaign import run_campaign

    scripts_root = Path(__file__).resolve().parents[3] / "scripts"
    if str(scripts_root) not in __import__("sys").path:
        __import__("sys").path.insert(0, str(scripts_root))
    from _dataset_resolver import export_data_roots
    from _env_wrapper import verify_session_env

    verify_session_env()
    roots = export_data_roots(require_all=True)
    result = run_campaign(
        contract_path=args.contract,
        approval_path=args.approval,
        model_config_path=args.model_config,
        task_manifest=args.task_manifest,
        output_root=args.output_root,
        project_root=args.project_root,
        evaluator_dataset=args.evaluator_dataset,
        repo_cache=args.repo_cache or Path(roots["CACTUS_REPO_CACHE_ROOT"]),
        limit=args.limit,
        variant="cactus_full",
        campaign_id=args.campaign_id,
        warmup_lookahead=2,
        pair_plan_path=args.output,
    )
    print(f"campaign={result.campaign_id} paired_runs={result.task_count} completed={result.completed} failed={result.failed}")
    print("run_ids=" + ",".join(result.run_ids))
    return 0 if not result.failed else 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
