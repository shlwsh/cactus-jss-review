"""Deterministic Agent x model campaign matrix planning (no execution)."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from typing import Any


def validate_matrix(spec: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    for field in ("schema_version", "campaign_id", "agents", "models", "conditions"):
        if field not in spec:
            errors.append(f"missing matrix field: {field}")
    if spec.get("schema_version") != "2.0":
        errors.append("matrix schema_version must be 2.0")
    if not isinstance(spec.get("campaign_id"), str) or not re.fullmatch(r"CMP-[A-Z0-9][A-Z0-9_-]*", spec.get("campaign_id", "")):
        errors.append("matrix.campaign_id does not match CMP format")
    for field in ("agents", "models", "conditions"):
        value = spec.get(field)
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or not value:
            errors.append(f"matrix.{field} must be a non-empty list")
        elif any(not isinstance(item, str) or not item.strip() for item in value):
            errors.append(f"matrix.{field} entries must be non-empty strings")
        elif len(set(value)) != len(value):
            errors.append(f"matrix.{field} entries must be unique")
    return errors


def expand_matrix(spec: Mapping[str, Any]) -> list[dict[str, str]]:
    """Expand a validated matrix in stable order with deterministic cell IDs."""
    errors = validate_matrix(spec)
    if errors:
        raise ValueError("invalid matrix: " + "; ".join(errors))
    cells: list[dict[str, str]] = []
    for agent in spec["agents"]:
        for model in spec["models"]:
            for condition in spec["conditions"]:
                payload = {"agent": agent, "model": model, "condition": condition}
                digest = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()[:12]
                cells.append({**payload, "cell_id": f"{spec['campaign_id']}-{digest}"})
    return cells
