"""Fail-closed binding between a formal contract and its model configuration."""

from __future__ import annotations

from typing import Any


# These fields influence either what reaches the provider or how formal usage
# evidence is collected.  A contract that declares one of them must agree with
# the runtime configuration; otherwise the sealed RUN cannot represent the
# approved experiment.
_BOUND_MODEL_FIELDS = (
    "algorithm_revision",
    "model_id",
    "max_output_tokens",
    "prediction_max_attempts",
    "prediction_retry_strategy",
    "prediction_output_mode",
    "thinking",
    "usage_required",
    "billing_required",
    "billing_source",
    "billing_endpoint",
    "billing_api_key_env",
    "billing_log_key_alias_env",
    "billing_scope",
    "billing_user_id",
    "reasoning_effort",
)


def model_contract_errors(contract: dict[str, Any], model_config: dict[str, Any]) -> list[str]:
    """Return deterministic errors for declared model fields that drifted."""
    contract_model = contract.get("model")
    if not isinstance(contract_model, dict):
        return ["model config enables algorithm_revision without a contract model binding"] if model_config.get("algorithm_revision") else []
    errors: list[str] = []
    if model_config.get("algorithm_revision") and "algorithm_revision" not in contract_model:
        errors.append("model config enables algorithm_revision without a contract binding")
    for field in _BOUND_MODEL_FIELDS:
        if field not in contract_model:
            continue
        if field not in model_config:
            errors.append(f"model config missing contract-bound field {field!r}")
        elif contract_model[field] != model_config[field]:
            errors.append(
                f"model config mismatch for {field!r}: "
                f"contract={contract_model[field]!r}, model_config={model_config[field]!r}"
            )
    return errors
