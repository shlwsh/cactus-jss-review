"""Machine-readable readiness report for a formal local main experiment.

This module performs a non-mutating readiness audit: it checks that the
contract, environment snapshot, model configuration, task manifest, and
authorization files are all present and valid — without downloading images,
connecting to LiteLLM, or executing any workload.

Authorization
-------------
Accepts either ``*.approval_marker.json`` (legacy physical marker) or
``*.session_authorization.json`` (session confirmation written by
``cactus session-auth confirm``).  The formal execution gate
(``formal_execution_errors``) accepts both interchangeably.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from cactus.adapters.benchmark import load_manifest
from cactus.governance.contract import validate_contract
from cactus.governance.schema import validate_approval_marker, validate_environment_snapshot, validate_session_authorization
from cactus.runner.formal import formal_execution_errors
from cactus.runner.model_binding import model_contract_errors


def _task_manifest_path_matches(bound_path: object, task_manifest_path: Path) -> bool:
    """Match a contract path across hosts while retaining SHA-256 binding.

    Contracts can be prepared on a Linux runner and executed on Windows.  The
    content hash remains the authoritative identity check; this helper only
    recognizes the same repository-relative suffix when absolute roots differ.
    """
    if not isinstance(bound_path, str) or not bound_path:
        return False
    actual = task_manifest_path.resolve()
    try:
        if Path(bound_path).resolve() == actual:
            return True
    except OSError:
        pass
    bound = bound_path.replace("\\", "/")
    actual_text = actual.as_posix()
    for marker in ("/json/", "/data/", "/experiments/"):
        if marker in bound and actual_text.endswith(marker + bound.split(marker, 1)[1]):
            return True
    return False


def audit_readiness(
    *, project_root: Path, contract_path: Path, approval_path: Path, environment_path: Path,
    model_config_path: Path, task_manifest_path: Path, expected_task_sha256: str | None = None,
    require_clean_tree: bool = True,
) -> dict[str, Any]:
    """Return PASS/FAIL checks without downloading, executing or mutating data."""
    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool, detail: str) -> None:
        checks.append({"name": name, "status": "PASS" if passed else "FAIL", "detail": detail})

    try:
        contract = json.loads(contract_path.read_text(encoding="utf-8"))
        check("contract", not validate_contract(contract), "contract schema and integrity")
    except (OSError, json.JSONDecodeError) as exc:
        contract = {}
        check("contract", False, str(exc))
    try:
        environment = json.loads(environment_path.read_text(encoding="utf-8"))
        check("environment", not validate_environment_snapshot(environment), "observed/reconstructed snapshot schema")
    except (OSError, json.JSONDecodeError) as exc:
        environment = {}
        check("environment", False, str(exc))
    execution = contract.get("execution", {}) if isinstance(contract.get("execution"), dict) else {}
    bound_environment_path = execution.get("environment_snapshot_path")
    bound_environment_sha256 = execution.get("environment_snapshot_sha256")
    try:
        actual_environment_sha256 = hashlib.sha256(environment_path.read_bytes()).hexdigest()
    except OSError:
        actual_environment_sha256 = ""
    bound_environment_matches = False
    if isinstance(bound_environment_path, str) and bound_environment_path:
        bound_path = Path(bound_environment_path)
        resolved_bound_path = bound_path if bound_path.is_absolute() else project_root / bound_path
        try:
            bound_environment_matches = resolved_bound_path.resolve() == environment_path.resolve()
        except OSError:
            bound_environment_matches = False
    check(
        "contract_environment_binding",
        bound_environment_matches
        and isinstance(bound_environment_sha256, str)
        and bound_environment_sha256 == actual_environment_sha256,
        "contract environment snapshot path and SHA-256 checked"
        if bound_environment_matches and bound_environment_sha256 == actual_environment_sha256
        else "contract environment snapshot path or SHA-256 does not match the supplied snapshot",
    )
    model_ok = model_config_path.is_file()
    model_detail = "model configuration exists"
    if model_ok:
        try:
            model = json.loads(model_config_path.read_text(encoding="utf-8"))
            required = ("base_url", "api_key_env", "model_id", "usage_required")
            missing = [key for key in required if key not in model]
            model_ok = not missing and isinstance(model.get("usage_required"), bool)
            model_detail = "model configuration semantics checked" if model_ok else f"missing/invalid fields: {', '.join(missing) or 'usage_required'}"
        except (OSError, json.JSONDecodeError) as exc:
            model_ok = False
            model_detail = str(exc)
    check("model_config", model_ok, model_detail)
    binding_errors = model_contract_errors(contract, model) if model_ok else ["model configuration unavailable"]
    check(
        "model_contract_binding",
        not binding_errors,
        "model configuration matches contract" if not binding_errors else "; ".join(binding_errors),
    )
    try:
        tasks = load_manifest(task_manifest_path)
        check("task_manifest", bool(tasks), f"{len(tasks)} validated task(s)")
    except (OSError, ValueError) as exc:
        check("task_manifest", False, str(exc))
    if expected_task_sha256:
        actual = hashlib.sha256(task_manifest_path.read_bytes()).hexdigest() if task_manifest_path.is_file() else ""
        check("task_manifest_sha256", actual == expected_task_sha256, "manifest digest checked")
    contract_binding = contract.get("workload", {}).get("task_manifest", {}) if isinstance(contract.get("workload"), dict) else {}
    if isinstance(contract_binding, dict) and contract_binding:
        bound_path = contract_binding.get("path")
        bound_sha = contract_binding.get("sha256")
        actual = hashlib.sha256(task_manifest_path.read_bytes()).hexdigest() if task_manifest_path.is_file() else ""
        path_matches = _task_manifest_path_matches(bound_path, task_manifest_path)
        check("contract_task_binding", path_matches and bound_sha == actual, "contract task manifest binding checked")
    authorization_path = approval_path
    authorization_kind = "marker"
    if not authorization_path.is_file():
        session_path = approval_path.with_name(approval_path.name.replace(".approval_marker.json", ".session_authorization.json"))
        if session_path.is_file():
            authorization_path = session_path
            authorization_kind = "session"
    try:
        approval = json.loads(authorization_path.read_text(encoding="utf-8"))
        validator = validate_session_authorization if authorization_kind == "session" else validate_approval_marker
        check("approval", not validator(approval), f"{authorization_kind} authorization checked")
    except (OSError, json.JSONDecodeError) as exc:
        check("approval", False, str(exc))
    formal_errors = formal_execution_errors(contract, project_root=project_root, approval_path=approval_path, require_clean_tree=require_clean_tree) if contract else ["contract unavailable"]
    check("formal_preflight", not formal_errors, "formal preflight passed" if not formal_errors else "; ".join(formal_errors))
    source_errors: list[str] = []
    if contract:
        try:
            # Keep the readiness report aligned with the campaign's stronger
            # source freeze check. A clean tree alone does not prove that the
            # candidate was prepared for the code currently at HEAD.
            from cactus.runner.swebench_campaign import _source_commit_errors

            metadata_paths = execution.get("metadata_paths", [])
            subproject_prefix = project_root.resolve().name + "/"
            source_binding = contract.get("source", {})
            source_commit = source_binding.get("git_commit", "") if isinstance(source_binding, dict) else ""
            declared_paths = tuple(
                Path(path.removeprefix(subproject_prefix))
                for path in metadata_paths
                if isinstance(path, str)
            ) if isinstance(metadata_paths, list) else ()
            source_errors = _source_commit_errors(
                source_commit=str(source_commit),
                contract_path=contract_path,
                approval_path=approval_path,
                project_root=project_root,
                additional_allowed_paths=declared_paths,
            )
        except (OSError, RuntimeError, ValueError) as exc:
            source_errors = [f"unable to verify contract source binding: {exc}"]
    check(
        "source_commit_binding",
        not source_errors,
        "contract source commit and metadata-only changes checked"
        if not source_errors
        else "; ".join(source_errors),
    )
    return {"status": "PASS" if all(item["status"] == "PASS" for item in checks) else "FAIL", "checks": checks}


def main() -> int:
    """CLI for the non-mutating readiness audit described in the handoff."""
    import argparse
    parser = argparse.ArgumentParser(prog="cactus-readiness")
    parser.add_argument("audit", choices=("audit",))
    parser.add_argument("--contract", required=True, type=Path)
    parser.add_argument("--approval", required=True, type=Path)
    parser.add_argument("--environment", required=True, type=Path)
    parser.add_argument("--model-config", required=True, type=Path)
    parser.add_argument("--task-manifest", required=False, type=Path)
    parser.add_argument("--expected-task-sha256")
    parser.add_argument("--allow-dirty", action="store_true")
    args = parser.parse_args()
    project_root = Path(__file__).resolve().parents[3]
    contract = json.loads(args.contract.read_text(encoding="utf-8"))
    task_manifest = args.task_manifest
    if task_manifest is None:
        binding = contract.get("workload", {}).get("task_manifest", {})
        task_manifest = Path(binding.get("path", ""))
    report = audit_readiness(
        project_root=project_root,
        contract_path=args.contract,
        approval_path=args.approval,
        environment_path=args.environment,
        model_config_path=args.model_config,
        task_manifest_path=task_manifest,
        expected_task_sha256=args.expected_task_sha256,
        require_clean_tree=not args.allow_dirty,
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
