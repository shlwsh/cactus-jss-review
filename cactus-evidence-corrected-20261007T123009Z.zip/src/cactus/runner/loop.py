"""A provider-neutral, trace-first offline Agent loop."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from pathlib import Path

from cactus.adapters.mock import MockProvider
from cactus.adapters.protocols import ModelResponse
from cactus.budgeting.reservation import TokenPolicy, reserve_tokens
from cactus.context.packer import pack_context, verify_retry_context
from cactus.domain.models import ModelUsage, SelectionPlan
from cactus.engine import ContextEngine
from cactus.telemetry.usage import CostLedger
from cactus.trace.store import TraceStore


class OfflineAgentLoop:
    def __init__(self, repo_root: Path, trace_store: TraceStore, provider: MockProvider | None = None, *, max_output_tokens: int | None = None, token_policy: Mapping[str, object] | TokenPolicy | None = None, algorithm_revision: str | None = None) -> None:
        self.engine = ContextEngine(repo_root, trace_store)
        self.trace_store = trace_store
        self.provider = provider or MockProvider()
        self.ledger = CostLedger()
        # Provider-agnostic output budget.  The LiteLLM adapter reads this from
        # ``metadata["max_tokens"]``; other adapters may forward or ignore it.
        # ``None`` falls back to the adapter default (currently 8192).
        self._max_output_tokens = max_output_tokens
        self._token_policy = (
            token_policy
            if isinstance(token_policy, TokenPolicy)
            else TokenPolicy.from_mapping(token_policy)
            if token_policy is not None
            else None
        )
        self.algorithm_revision = algorithm_revision
        self.last_response: ModelResponse | None = None
        self._last_plan: SelectionPlan | None = None
        self._last_context: str | None = None
        self._last_context_bundle: dict[str, object] | None = None

    def _context_bundle(self, plan: SelectionPlan, selection_query: str) -> dict[str, object]:
        units = tuple(getattr(self.engine, "_last_units", ()) or ())
        by_id = {unit.unit_id: unit for unit in units}
        selected = [by_id[unit_id] for unit_id in plan.selected_unit_ids if unit_id in by_id]
        if len(selected) != len(plan.selected_unit_ids):
            raise ValueError("cannot hash context: selected unit is missing from the current repository snapshot")
        task_id = hashlib.sha256(selection_query.encode("utf-8")).hexdigest()
        return pack_context(selected, task_id=task_id, budget=plan.budget)

    def run_turn(self, task_text: str, *, turn_id: str, budget: int, metadata: Mapping[str, str] | None = None, reuse_context: bool = False, context_char_limit: int | None = None, variant: str = "cactus_full", selection_text: str | None = None, context_override: str | None = None) -> str:
        self.trace_store.append("observe", {"task": task_text, "turn_id": turn_id})
        selection_query = selection_text if selection_text is not None else task_text
        if reuse_context and self._last_plan is not None and self._last_context is not None:
            plan, context = self._last_plan, self._last_context
            candidate_bundle = self._context_bundle(plan, selection_query)
            if self._last_context_bundle is None:
                raise ValueError("frozen context hash is missing; retry is not permitted")
            context_hash = verify_retry_context(self._last_context_bundle, candidate_bundle)
            if context_char_limit is not None and context_char_limit > 0 and len(context) > context_char_limit:
                raise ValueError("retry context truncation is forbidden for a frozen selection")
            self.trace_store.append("context_hash_verified", {
                "turn_id": turn_id,
                "context_bundle_hash": context_hash,
                "task_id": candidate_bundle["task_id"],
                "budget": candidate_bundle["budget"],
                "chunk_count": len(candidate_bundle["chunks"]),
            })
            # Reuse the selected repository units, but replace the previous
            # turn's instruction.  Without this, a retry receives the first
            # prompt verbatim and never sees the rejection reason or the
            # stricter output requirements from the retry prompt.
            if selection_query:
                header = f"Task: {selection_query}"
                unit_idx = context.find("<!-- cactus-unit:")
                if unit_idx != -1:
                    context = header + "\n\n" + context[unit_idx:]
                elif context.startswith("Task: "):
                    _, separator, units_context = context.partition("\n\n")
                    context = header + (separator + units_context if separator else "")
                else:
                    context = header + "\n\n" + context
        else:
            if self.algorithm_revision in {"lite50_v2", "lite50_v3_dual_insurance"}:
                plan, context = self.engine.propose(
                    selection_query,
                    turn_id,
                    budget,
                    variant=variant,
                    responsibility_hint=task_text,
                )
            else:
                plan, context = self.engine.propose(selection_query, turn_id, budget, variant=variant)
            self._last_plan, self._last_context = plan, context
            self._last_context_bundle = self._context_bundle(plan, selection_query)
        self.trace_store.append("context_selected", {
            "turn_id": turn_id,
            "status": plan.status,
            "tokens": plan.token_count,
            "selected": list(plan.selected_unit_ids),
            "context_bundle_hash": self._last_context_bundle["context_bundle_hash"],
        })
        units_by_id = {
            unit.unit_id: unit
            for unit in (getattr(self.engine, "_last_units", ()) or ())
        }
        selected_metadata = [
            {
                "unit_id": unit_id,
                "path": units_by_id[unit_id].path,
                "kind": units_by_id[unit_id].kind,
                "symbol_id": units_by_id[unit_id].symbol_id,
                "start_line": units_by_id[unit_id].start_line,
                "end_line": units_by_id[unit_id].end_line,
            }
            for unit_id in plan.selected_unit_ids
            if unit_id in units_by_id
        ]
        self.trace_store.append("context_selection_metadata", {
            "turn_id": turn_id,
            "selected_units": selected_metadata,
            "metadata_complete": len(selected_metadata) == len(plan.selected_unit_ids),
        })
        if context_override is not None:
            if not reuse_context or self._last_plan is None or not context_override.strip():
                raise ValueError("context override requires a selected, reusable context")
            context = context_override
            self.trace_store.append("context_override", {
                "turn_id": turn_id,
                "sha256": hashlib.sha256(context.encode("utf-8")).hexdigest(),
                "characters": len(context),
                "source": "selected_unit_subset",
            })
        if plan.status != "ok" or not plan.selected_unit_ids:
            self.trace_store.append("context_selection_rejected", {
                "turn_id": turn_id,
                "status": plan.status,
                "selected_unit_count": len(plan.selected_unit_ids),
                "selected_context_tokens": plan.token_count,
                "model_call_skipped": True,
            })
            raise RuntimeError(
                "context selection failed; model call skipped "
                f"(status={plan.status}, selected_units={len(plan.selected_unit_ids)})"
            )
        merged_metadata: dict[str, str] = {"turn_id": turn_id}
        if metadata:
            merged_metadata.update(metadata)
        if "max_tokens" not in merged_metadata and self._max_output_tokens is not None:
            merged_metadata["max_tokens"] = str(self._max_output_tokens)
        prompt_context = context
        if task_text and ("<!-- cactus-unit:" in context or context_override is not None) and not context.rstrip().endswith(task_text.strip()):
            prompt_context = f"[SOURCE CONTEXT]\n{context}\n\n---\n[TASK INSTRUCTION]\n{task_text}\n"
        reservation = None
        if self._token_policy is not None:
            try:
                reservation = reserve_tokens(
                    self._token_policy,
                    prompt=prompt_context,
                    max_output_tokens=int(merged_metadata.get("max_tokens", 0)) or None,
                    task_tokens_used=self.ledger.total_tokens,
                )
            except RuntimeError as exc:
                self.trace_store.append("token_reservation_rejected", {
                    "turn_id": turn_id,
                    "reason": str(exc),
                    "task_tokens_used": self.ledger.total_tokens,
                    "per_task_hard_limit": self._token_policy.per_task_hard_limit,
                    "campaign_tokens_remaining": self._token_policy.campaign_tokens_remaining,
                    "model_call_skipped": True,
                })
                raise
            self.trace_store.append("token_reserved", {
                "turn_id": turn_id,
                "estimated_input_tokens": reservation.estimated_input_tokens,
                "requested_output_tokens": reservation.requested_output_tokens,
                "reserved_tokens": reservation.reserved_tokens,
                "task_tokens_used": reservation.task_tokens_used,
                "task_tokens_remaining": reservation.task_tokens_remaining,
                "campaign_tokens_remaining": reservation.campaign_tokens_remaining,
            })
        response = self.provider.complete(prompt_context, metadata=merged_metadata)
        self.last_response = response
        self.ledger.add(response.usage)
        if self._token_policy is not None:
            total = self.ledger.total_tokens
            self.trace_store.append("token_reservation_settled", {
                "turn_id": turn_id,
                "actual_call_tokens": response.usage.total_tokens,
                "reserved_tokens": None if reservation is None else reservation.reserved_tokens,
                "task_tokens_used": total,
                "soft_limit_exceeded": total > self._token_policy.per_task_soft_limit,
                "hard_limit_reached": total >= self._token_policy.per_task_hard_limit,
            })
        # ``prompt_context`` is allowed to be ``None`` only when the engine
        # explicitly declined to inject source units; in that case we still
        # record the model call but skip the prompt-text metadata so the
        # trace schema stays uniform.
        response_text = response.text if response.text is not None else ""
        prompt_for_trace = prompt_context if isinstance(prompt_context, str) else ""
        self.trace_store.append("model_call", {"turn_id": turn_id, "input_tokens": response.usage.input_tokens, "output_tokens": response.usage.output_tokens, "usage_source": response.usage.usage_source, "provider_call_id": response.usage.provider_call_id, "max_tokens": int(merged_metadata.get("max_tokens", 0)) or None, "temperature": float(merged_metadata["temperature"]) if merged_metadata.get("temperature") else None, "frequency_penalty": float(merged_metadata["frequency_penalty"]) if merged_metadata.get("frequency_penalty") else None, "presence_penalty": float(merged_metadata["presence_penalty"]) if merged_metadata.get("presence_penalty") else None, "repetition_penalty": float(merged_metadata["repetition_penalty"]) if merged_metadata.get("repetition_penalty") else None, "finish_reason": response.finish_reason, "response_text": response_text, "response_chars": len(response_text), "prompt_chars": len(prompt_for_trace), "prompt_sha256": hashlib.sha256(prompt_for_trace.encode("utf-8")).hexdigest() if prompt_for_trace else "", "prompt_text": prompt_for_trace, "seed": int(merged_metadata["seed"]) if merged_metadata.get("seed") is not None else None, "metadata_keys": sorted(merged_metadata.keys())})
        return response_text
