"""Lite-50 v3.0 工程验证报告生成器.

根据方案 3.5 节标准判定：
- 严格门槛：≥ 7/10 resolved
- 输出详细指标统计与生产准入建议
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sys
from typing import Any, Optional


def load_explore_summary(input_path: Path) -> dict[str, Any]:
    """从目录或具体文件中加载工程验证摘要数据."""
    if input_path.is_file():
        target = input_path
    elif input_path.is_dir():
        latest = input_path / "latest_explore_run.json"
        if latest.exists():
            target = latest
        else:
            files = sorted(input_path.glob("explore_run_*.json"))
            if not files:
                raise FileNotFoundError(f"目录中未找到 explore_run 结果文件: {input_path}")
            target = files[-1]
    else:
        raise FileNotFoundError(f"路径不存在: {input_path}")

    with open(target, encoding="utf-8") as f:
        return json.load(f)


def generate_report(summary: dict[str, Any]) -> str:
    """生成格式化文本报告."""
    total = summary.get("total_tasks", 0)
    passed = summary.get("passed_tasks", 0)
    failed = summary.get("failed_tasks", 0)
    rate = summary.get("pass_rate", 0.0)
    tier = summary.get("tier", "exploratory")
    algorithm = summary.get("algorithm", "unknown")
    start = summary.get("start_time", "")
    end = summary.get("end_time", "")

    # 错误分类统计
    error_counts: Counter[str] = Counter()
    results = summary.get("results", [])
    total_tokens = 0
    for r in results:
        total_tokens += r.get("total_tokens_used", 0)
        if not r.get("success"):
            etype = r.get("error_type") or "unknown_error"
            error_counts[etype] += 1

    lines = [
        "=" * 65,
        f"        Lite-50 v3.0 工程验证评估报告 (Tier: {tier})",
        "=" * 65,
        f"算法版本:   {algorithm}",
        f"执行时间:   {start} -> {end}",
        f"总任务数:   {total}",
        f"通过任务数: {passed}",
        f"未通过数:   {failed}",
        f"通过率:     {passed}/{total} ({rate:.1%})",
        f"总Token数:  {total_tokens:,}",
        "-" * 65,
        "【任务明细】",
    ]

    for idx, r in enumerate(results, 1):
        status_mark = "✅ PASS" if r.get("success") else "❌ FAIL"
        score = r.get("score", 0)
        attempts = r.get("attempts", 1)
        tid = r.get("task_id", f"task_{idx}")
        err = f" [{r.get('error_type')}]" if not r.get("success") else ""
        lines.append(f"  {idx:2d}. {tid:<28} {status_mark} (分值: {score:3d}, 尝试: {attempts}){err}")

    if error_counts:
        lines.append("-" * 65)
        lines.append("【未通过原因分布】")
        for etype, count in error_counts.most_common():
            lines.append(f"  - {etype:<25}: {count} 次")

    lines.append("=" * 65)
    # 判定门禁标准：>= 7/10
    threshold_met = passed >= 7 if total >= 10 else (rate >= 0.7 if total > 0 else False)

    if threshold_met:
        lines.append("决策建议: ✅ 【通过】算法有效性验证达标（≥ 7/10）")
        lines.append("          可直接进入正式生产路径（Phase 1: 合同创建与正式执行）")
    else:
        lines.append("决策建议: ⚠️ 【未通过】未达到严格门槛（≥ 7/10）")
        lines.append("          建议根据未通过原因进一步优化算法后重新验证")
    lines.append("=" * 65)

    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Lite-50 v3.0 工程验证报告生成器")
    parser.add_argument("--input", default=Path("experiments/explore/"), type=Path, help="结果目录或文件路径")

    args = parser.parse_args()

    summary = load_explore_summary(args.input)
    report_text = generate_report(summary)
    print(report_text)


if __name__ == "__main__":
    main()
