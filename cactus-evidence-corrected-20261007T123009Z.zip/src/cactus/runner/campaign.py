"""Campaign manifest validation without executing workloads."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


def validate_campaign(campaign: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    for field in ("schema_version", "campaign_id", "paper_version", "tier_primary"):
        if field not in campaign:
            errors.append(f"missing campaign field: {field}")
    if campaign.get("schema_version") != "2.0":
        errors.append("campaign schema_version must be 2.0")
    for tier in ("tier_primary", "tier_supporting", "tier_context_only"):
        items = campaign.get(tier, {}).get("items", []) if isinstance(campaign.get(tier), Mapping) else []
        if not isinstance(items, Sequence) or isinstance(items, (str, bytes)):
            errors.append(f"{tier}.items must be a list")
        else:
            for index, item in enumerate(items):
                if not isinstance(item, Mapping) or not isinstance(item.get("result_id"), str):
                    errors.append(f"{tier}.items[{index}] requires result_id")
    return errors
