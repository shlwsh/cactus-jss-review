"""Read-only benchmark task manifest adapter; never downloads task data."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class BenchmarkTask:
    task_id: str
    repo_id: str
    base_commit: str
    issue_text: str
    test_command: tuple[str, ...]
    split: str = "unspecified"
    fail_to_pass: tuple[str, ...] = ()


def load_manifest(path: Path) -> tuple[BenchmarkTask, ...]:
    tasks: list[BenchmarkTask] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise ValueError(f"invalid manifest JSONL at line {line_number}: {error}") from error
        errors = validate_task(value)
        if errors:
            raise ValueError(f"invalid task at line {line_number}: {'; '.join(errors)}")
        tasks.append(BenchmarkTask(
            value["task_id"],
            value["repo_id"],
            value["base_commit"],
            value["issue_text"],
            tuple(value.get("test_command", [])),
            value.get("split", "unspecified"),
            tuple(value.get("FAIL_TO_PASS", value.get("fail_to_pass", []))),
        ))
    return tuple(tasks)


def load_evaluation_test_ids(path: Path) -> dict[str, tuple[str, ...]]:
    """Read only task IDs and FAIL_TO_PASS identifiers from a safe eval manifest.

    Gold patches are unnecessary for test-aware context. Refuse evaluator data
    that contains either patch field so it can never be copied into prediction
    inputs by this adapter.
    """
    test_ids: dict[str, tuple[str, ...]] = {}
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as error:
            raise ValueError(f"invalid evaluator manifest JSONL at line {line_number}: {error}") from error
        if not isinstance(value, dict):
            raise ValueError(f"invalid evaluator manifest row at line {line_number}: expected an object")
        if {"patch", "test_patch"} & value.keys():
            raise ValueError(f"unsafe evaluator manifest at line {line_number}: gold patch fields are prohibited")
        task_id = value.get("instance_id", value.get("task_id"))
        identifiers = value.get("FAIL_TO_PASS", value.get("fail_to_pass"))
        if not isinstance(task_id, str) or not task_id.strip():
            raise ValueError(f"invalid evaluator manifest at line {line_number}: task ID is missing")
        if not isinstance(identifiers, list) or not all(isinstance(item, str) and item.strip() for item in identifiers):
            raise ValueError(f"invalid evaluator manifest at line {line_number}: FAIL_TO_PASS must be a string list")
        if task_id in test_ids:
            raise ValueError(f"duplicate task ID in evaluator manifest at line {line_number}: {task_id}")
        test_ids[task_id] = tuple(identifiers)
    return test_ids


def validate_task(value: object) -> list[str]:
    if not isinstance(value, dict):
        return ["task must be an object"]
    errors: list[str] = []
    for field in ("task_id", "repo_id", "base_commit", "issue_text"):
        if not isinstance(value.get(field), str) or not value[field].strip():
            errors.append(f"{field} must be non-empty")
    if not isinstance(value.get("base_commit"), str) or not re.fullmatch(r"[0-9a-f]{40}", value.get("base_commit", "")):
        errors.append("base_commit must be a 40-character lowercase SHA-1")
    if not isinstance(value.get("test_command", []), list) or not all(isinstance(item, str) for item in value.get("test_command", [])):
        errors.append("test_command must be a string list")
    fail_to_pass = value.get("FAIL_TO_PASS", value.get("fail_to_pass", []))
    if not isinstance(fail_to_pass, list) or not all(isinstance(item, str) and item.strip() for item in fail_to_pass):
        errors.append("FAIL_TO_PASS must be a list of non-empty test identifiers")
    return errors
