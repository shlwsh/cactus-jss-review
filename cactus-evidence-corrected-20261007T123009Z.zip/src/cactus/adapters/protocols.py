"""Protocols separating CACTUS from Agent and provider implementations."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Protocol

from cactus.domain.models import ModelUsage, SelectionPlan, TraceEvent


@dataclass(frozen=True, slots=True)
class ModelResponse:
    text: str
    usage: ModelUsage
    finish_reason: str | None = None


class ProviderAdapter(Protocol):
    model_id: str

    def complete(self, context: str, *, metadata: Mapping[str, str]) -> ModelResponse: ...


class AgentAdapter(Protocol):
    agent_id: str

    def observe(self) -> Mapping[str, object]: ...

    def propose_context(self, plan: SelectionPlan) -> str: ...

    def call_model(self, context: str) -> ModelResponse: ...

    def execute_tool(self, action: Mapping[str, object]) -> Sequence[TraceEvent]: ...
