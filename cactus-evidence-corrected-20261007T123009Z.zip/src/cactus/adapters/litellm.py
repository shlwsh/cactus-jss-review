"""OpenAI-compatible LiteLLM adapter using only the Python standard library."""

from __future__ import annotations

import json
from collections.abc import Mapping
from urllib import request

from cactus.domain.models import ModelUsage
from .protocols import ModelResponse


class LiteLLMProvider:
    """Small synchronous adapter for a local LiteLLM `/v1/chat/completions` gateway."""

    def __init__(self, base_url: str, api_key: str, model_id: str, *, timeout: float = 300.0) -> None:
        if not base_url.startswith(("http://", "https://")) or not model_id:
            raise ValueError("base_url and model_id are required")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model_id = model_id
        self.timeout = timeout

    def complete(self, context: str, *, metadata: Mapping[str, str]) -> ModelResponse:
        # ``max_tokens`` controls the model's *output* budget.  CACTUS callers
        # must surface this from ``model_config.max_output_tokens`` (or a
        # higher-priority override such as a CLI flag).  The previous hard
        # fallback of ``256`` silently truncated every SWE-bench style diff.
        # The per-call safety cap keeps a misbehaving caller from requesting
        # something larger than the gateway's ``DEFAULT_MAX_TOKENS`` (8192).
        default_output_tokens = 8192
        try:
            max_tokens = int(metadata.get("max_tokens") or default_output_tokens)
        except (TypeError, ValueError):
            max_tokens = default_output_tokens
        if max_tokens <= 0:
            max_tokens = default_output_tokens
        if metadata.get("prediction_output_mode") == "site_plan":
            system_prompt = (
                "You are a Python repair planner. Analyze the public issue and verified source. "
                "State the root cause, required interface changes, invariants, and complete algorithm in prose. "
                "Follow the requested length limit. Do not output code, a diff, site IDs, or Markdown fences."
            )
        elif metadata.get("prediction_output_mode") == "site_select":
            system_prompt = (
                "You are a Python bug localizer. Read the issue and ranked source excerpts. "
                "Choose one to four listed immutable candidate IDs needed for a complete atomic fix. "
                "Return only SITES: <candidate-ID>[, <candidate-ID>...]. "
                "Never calculate or return a path or line number. Do not return code, a patch, or an explanation."
            )
        elif metadata.get("prediction_output_mode") == "site_diagnose":
            system_prompt = (
                "You are a Python bug analyst. Trace the actual input value and branch behavior from the selected source. "
                "Explain the defect in at most two sentences. Do not output code or a patch."
            )
        elif metadata.get("prediction_output_mode") == "site_replace_json":
            system_prompt = (
                'Return only JSON: {"replacements":[{"site_id":"...","replacement":"..."}]}. '
                "Each replacement must be a complete corrected Python statement or function definition. "
                "Implement the task instruction across every selected site; never copy unchanged source as the answer. "
                "When a helper interface changes, update its selected callers in the same response."
            )
        elif metadata.get("prediction_output_mode") == "site_replace":
            system_prompt = (
                "You are a Python bug fixer. The exact existing source statement has been selected and verified. "
                "Return only NEW: followed by one corrected complete Python statement, which may span multiple lines. "
                "No Markdown, diff, prose, or unchanged statement."
            )
        elif metadata.get("prediction_output_mode") == "statement_edit_replacement_plain":
            system_prompt = (
                "You are an expert Python bug fixer. The source path, function, and old statement have already been selected. "
                "Return only NEW: followed by one corrected Python statement. No JSON, diff, prose, or unchanged statement."
            )
        elif metadata.get("prediction_output_mode") == "statement_edit_plain":
            system_prompt = (
                "You are an expert Python bug fixer. Trace the supplied source value flow and return exactly "
                "FILE: path; SYMBOL: function; OLD: `existing statement`; NEW: `corrected statement`. "
                "No JSON, diff, prose, or unchanged replacement."
            )
        elif metadata.get("prediction_output_mode") == "statement_edit":
            system_prompt = (
                "You are a careful code-editing model. Reason privately before producing the edit. "
                "The very first character of your reply MUST be '{'. The very last character of your reply MUST be '}'. "
                "Output exactly one JSON object matching this schema and nothing else:\n"
                '{"edits":[{"path":"<selected .py path>","symbol":"<exact function or Class.method>","old_statement":"<verbatim copy of one complete existing statement>","replacement":"<corrected replacement that materially changes runtime behavior>"}]}\n'
                "Rules:\n"
                "- Copy `old_statement` character-for-character from the SOURCE CONTEXT block (watch whitespace, quotes, indentation).\n"
                "- `replacement` MUST be semantically different from `old_statement`; identical old/replacement is a hard failure.\n"
                "- Trace the changed value through its existing consumers and preserve required runtime behavior. Do not replace a live value or collection with an empty placeholder merely to suppress the reported symptom.\n"
                "- Keep required objects and state intact; a fix is invalid if existing callers can no longer use them.\n"
                "- Never calculate line numbers, write a diff, or output Markdown fences.\n"
                "- Never repeat the issue text, paraphrase the bug, or explain your reasoning.\n"
                "- If you cannot locate the exact statement, output exactly {\"edits\": []} — never produce prose instead.\n"
                "- Up to four edits are allowed; return every necessary distinct edit."
            )
        elif metadata.get("prediction_output_mode") == "symbol_edit":
            system_prompt = (
                "You are an expert software engineer fixing repository bugs. Return only JSON edits naming the exact "
                "Python definition and its complete corrected replacement. Do not reproduce old source text or write a diff."
            )
        elif metadata.get("prediction_output_mode") == "structured_edit":
            system_prompt = (
                "You are an expert software engineer fixing repository bugs. Return only the exact JSON source edit "
                'requested by the user: path, old, and new. Copy old source lines verbatim; do not write a diff.'
            )
        else:
            system_prompt = (
                "You are an expert software engineer fixing bugs via git unified diff patches. "
                "Given the bug description and codebase context, produce a minimal, applicable git unified diff patch. "
                "Start immediately with standard headers: 'diff --git a/... b/...', '--- a/...', '+++ b/...'. "
                "In each '@@ -start,count +start,count @@' hunk, specify exact 1-based decimal starting lines and line counts. "
                "Use '-' to delete defective lines and '+' to add corrected lines. "
                "Output ONLY the git diff patch."
            )
        payload: dict[str, object] = {
            "model": self.model_id,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": context},
            ],
            "max_tokens": max_tokens,
            "temperature": float(metadata.get("temperature", "0.0") or "0.0"),
            # Repetition penalty is safe to always set: vLLM uses it only when > 1.0.
            "repetition_penalty": float(metadata.get("repetition_penalty") or 1.05),
        }
        # ``thinking`` and ``reasoning_effort`` go through ``extra_body.chat_template_kwargs``,
        # which vLLM reads at chat-template resolution time (before the per-token loop).
        # Without this wrapper, ``thinking`` at the top level of extra_body is accepted by
        # vLLM but does NOT suppress the thinking-mode instructions in the system prompt,
        # resulting in ~5x more prompt tokens and ~10x more completion tokens.
        # Measured: thinking=false via top-level extra_body → 96 prompt / 19 completion / 0.6s;
        #           thinking=false via chat_template_kwargs   → 17 prompt / 2 completion / 0.3s.
        extra_body: dict[str, object] = {}
        if metadata.get("seed") is not None:
            payload["seed"] = int(metadata["seed"])
        thinking_raw = str(metadata.get("thinking", "")).strip().lower()
        reasoning_effort_raw = str(metadata.get("reasoning_effort", "")).strip().lower()
        if thinking_raw in {"enabled", "disabled", "true", "false", "1", "0"} or reasoning_effort_raw in {"low", "medium", "high", "max"}:
            ctk: dict[str, object] = {}
            if thinking_raw in {"enabled", "disabled", "true", "false", "1", "0"}:
                ctk["thinking"] = thinking_raw not in {"disabled", "false", "0"}
            if reasoning_effort_raw in {"low", "medium", "high", "max"}:
                ctk["reasoning_effort"] = reasoning_effort_raw
            extra_body["chat_template_kwargs"] = ctk
        # guided_decoding: prefer JSON schema (vLLM enforces complete valid JSON),
        # fall back to regex (vLLM uses incremental token-level constraint).
        # JSON schema is tried first when available; on rejection the caller can
        # fall back to the regex-only entry from model_config.
        guided_json_raw = str(metadata.get("guided_decoding_json_schema", "")).strip()
        guided_regex = str(metadata.get("guided_decoding", "")).strip()
        if guided_json_raw:
            try:
                schema = json.loads(guided_json_raw)
                # LiteLLM accepts the OpenAI-compatible response_format at
                # the proxy boundary.  Sending it in addition to vLLM's
                # guided_decoding preserves the constraint when the proxy
                # does not forward nested extra_body fields to the backend.
                payload["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": "cactus_patch",
                        "strict": True,
                        "schema": schema,
                    },
                }
                extra_body["guided_decoding"] = {"json": schema}
            except (json.JSONDecodeError, TypeError):
                # Malformed schema — fall back to regex.
                if guided_regex:
                    extra_body["guided_decoding"] = guided_regex
        elif guided_regex:
            extra_body["guided_decoding"] = guided_regex
        if extra_body:
            payload["extra_body"] = extra_body
        # LiteLLM forwards these OpenAI-compatible sampling controls to the
        # vLLM backend.  Keep them opt-in so the normal contract remains
        # deterministic; the predictor enables them only for a retry after a
        # repetitive or truncated patch.
        for parameter in ("frequency_penalty", "presence_penalty", "repetition_penalty"):
            value = metadata.get(parameter)
            if value is not None and value != "":
                try:
                    payload[parameter] = float(value)
                except (TypeError, ValueError):
                    raise ValueError(f"invalid {parameter}: {value!r}") from None
        stop_raw = metadata.get("stop")
        if stop_raw:
            if isinstance(stop_raw, list):
                payload["stop"] = stop_raw
            elif isinstance(stop_raw, str):
                if stop_raw.startswith("[") and stop_raw.endswith("]"):
                    try:
                        payload["stop"] = json.loads(stop_raw)
                    except Exception:
                        payload["stop"] = stop_raw
                else:
                    payload["stop"] = stop_raw
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = request.Request(self.base_url + "/chat/completions", data=body, method="POST", headers={"Authorization": "Bearer " + self.api_key, "Content-Type": "application/json"})
        try:
            call_timeout = float(metadata.get("request_timeout_sec", self.timeout))
        except (TypeError, ValueError):
            call_timeout = self.timeout
        if call_timeout <= 0:
            call_timeout = self.timeout
        with request.urlopen(req, timeout=call_timeout) as response:
            decoded = json.loads(response.read().decode("utf-8"))
            reported_cost = response.headers.get("x-litellm-response-cost")
            request_id = response.headers.get("x-request-id")
        choices = decoded.get("choices") or []
        choice = choices[0] if choices and isinstance(choices[0], dict) else {}
        message = choice.get("message", {}) if choice else {}
        text = message.get("content", "") if message else ""
        # DeepSeek-V4 (and other reasoning models) always emits a
        # ``reasoning_content`` field and may leave ``content`` empty when
        # the model hits its reasoning budget.  Without this fallback the
        # downstream validator sees an empty response and rejects every
        # prediction.  Prefer the visible ``content`` when it is non-empty;
        # otherwise fall back to ``reasoning_content``.
        if not (isinstance(text, str) and text.strip()):
            reasoning_text = message.get("reasoning_content", "")
            if isinstance(reasoning_text, str) and reasoning_text.strip():
                text = reasoning_text
        finish_reason = choice.get("finish_reason") if choice else None
        usage = decoded.get("usage") or {}
        try:
            provider_cost = float(reported_cost) if reported_cost is not None else None
        except ValueError:
            provider_cost = None
        return ModelResponse(text=text, usage=ModelUsage(int(usage.get("prompt_tokens", 0)), int(usage.get("completion_tokens", 0)), int(usage.get("prompt_tokens_details", {}).get("cached_tokens", 0)) if isinstance(usage.get("prompt_tokens_details"), dict) else int(usage.get("cached_tokens", 0)), usage_source="provider", provider_cost=provider_cost, provider_cost_currency="USD" if provider_cost is not None else None, provider_call_id=str(decoded.get("id")) if decoded.get("id") else request_id), finish_reason=str(finish_reason) if finish_reason else None)
