"""Sandbox-facing tool adapter with explicit timeout and redacted output."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from cactus.governance.redaction import redact


@dataclass(frozen=True, slots=True)
class ToolResult:
    argv: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool = False


class SubprocessTool:
    def __init__(self, *, project_root: Path, timeout_seconds: int = 30) -> None:
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        self.project_root = project_root
        self.timeout_seconds = timeout_seconds

    def run(self, argv: list[str]) -> ToolResult:
        if not argv or any("\x00" in part for part in argv):
            raise ValueError("argv must be non-empty and NUL-free")
        try:
            completed = subprocess.run(argv, cwd=self.project_root, capture_output=True, text=True, timeout=self.timeout_seconds, check=False)
            return ToolResult(tuple(argv), completed.returncode, str(redact(completed.stdout)), str(redact(completed.stderr)))
        except subprocess.TimeoutExpired as error:
            return ToolResult(tuple(argv), -1, str(redact(error.stdout or "")), str(redact(error.stderr or "")), True)
