"""Stable adapter protocols; concrete SDKs remain optional dependencies."""
