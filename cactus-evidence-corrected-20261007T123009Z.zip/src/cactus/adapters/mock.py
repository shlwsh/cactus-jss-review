"""Deterministic offline provider used by fixtures and replay tests."""

from __future__ import annotations

from collections.abc import Mapping

from cactus.domain.models import ModelUsage
from cactus.adapters.protocols import ModelResponse


class MockProvider:
    model_id = "mock-offline-v1"

    def complete(self, context: str, *, metadata: Mapping[str, str]) -> ModelResponse:
        return ModelResponse("offline-response", ModelUsage(len(context.split()), 1, usage_source="mock"))
