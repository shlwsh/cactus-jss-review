"""Offline orchestration of state, units, CCV, ACE and budget scheduling.

Implements Phase 5 (TASK-007) of CACTUS Rectification Plan v2.
"""

from __future__ import annotations

import re
from dataclasses import asdict
from enum import StrEnum
from pathlib import Path

from cactus.ace.guardian import ACEGuardian
from cactus.budgeting.manager import BudgetManager
from cactus.context.responsibility import analyze_responsibility
from cactus.domain.models import SelectionPlan
from cactus.repository.graph import DependencyGraph
from cactus.repository.index import build_index
from cactus.retrieval.candidate_pool import prune_candidate_pool
from cactus.retrieval.dedup import deduplicate
from cactus.retrieval.lexical import lexical_candidates
from cactus.retrieval.literal_anchors import exact_source_anchor_ids
from cactus.retrieval.marginal_utility import complete_parent_context, select_marginal_utility
from cactus.retrieval.scoring import ScoringMode, score_candidates
from cactus.retrieval.static_density import select_static_density
from cactus.scheduler.composer import compose
from cactus.selection.maximal_context import select_maximal_context
from cactus.state.model import StateBuilder
from cactus.task.parser import parse_task
from cactus.trace.store import TraceStore

SUPPORTED_VARIANTS = frozenset({
    "cactus_full",
    "maximal_context",
    "lexical_bm25",
    "cactus_no_symbol_graph",
    "cactus_static_density",
    "cactus_no_ace",
    "cactus_no_budget_controller",
    "cactus_no_patch_normalizer",
    "cactus_no_failure_recovery",
    "cactus_test_aware",
    "cactus_no_test_aware",
    "cactus_no_semantic",
    "cactus_no_iteration",
    # P1.3 sensitivity analysis: weight variations
    "sensitivity_sym_heavy",    # symbol=0.50, lexical=0.20, graph=0.15, test=0.10, path=0.05
    "sensitivity_lex_heavy",    # lexical=0.50, symbol=0.20, graph=0.15, test=0.10, path=0.05
    "sensitivity_flat",         # all=0.20 (equal weights)
    "sensitivity_no_graph",    # graph=0.00, redistribute to others
    # P1.4 source-bound editing ablation
    "no_source_binding",      # bypass repair_sites.py
})


class TaskComplexity(StrEnum):
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"


_COMPLEXITY_KEYWORDS = {
    "inner_helper": ("helper function", "inner function", "small function", "add a function"),
    "multi_edit": ("multiple changes", "several edits", "both", "and also", "as well as"),
    "conditional": ("add a check", "guard clause", "if missing", "validate"),
    "data_flow": ("comes from", "computed from", "the value of"),
    "assertion_format": ("assertraises", "assertequal", "pytest.raises", "match pattern"),
}


def estimate_task_complexity(task_text: str, *, fail_to_pass_count: int = 0) -> TaskComplexity:
    """Classify issue complexity with a deterministic, conservative rule set."""
    lowered = task_text.casefold()
    score = int(len(task_text.split()) > 200)
    score += sum(any(keyword in lowered for keyword in values) for values in _COMPLEXITY_KEYWORDS.values())
    # Multiple failing tests represent a broader behavioral surface. Count the
    # first threshold as a multi-test signal and the second as a broad-suite
    # signal; this lets the classifier recognize complex tasks whose issue text
    # omits implementation details while keeping single-test tasks unchanged.
    score += int(fail_to_pass_count >= 2)
    score += int(fail_to_pass_count >= 8)
    if score >= 3:
        return TaskComplexity.COMPLEX
    if score:
        return TaskComplexity.MODERATE
    return TaskComplexity.SIMPLE


def _path_matches(unit_path: str, mentioned_path: str) -> bool:
    """Match repository-relative paths, including common ``lib/`` roots."""
    candidate = mentioned_path.replace("\\", "/").lstrip("./")
    source = unit_path.replace("\\", "/").lstrip("./")
    return source == candidate or source.endswith("/" + candidate)


def _responsibility_anchor_paths(task_text: str) -> tuple[str, ...]:
    """Return narrowly-scoped implementation files required by issue semantics.

    These anchors only apply when the issue names an API family whose actual
    implementation module is stable and unambiguous.  They prevent tests,
    sample migrations, or same-named classes in another package from crowding
    the responsible implementation out of a bounded context.
    """
    normalized = task_text.casefold()
    paths: list[str] = []
    django_signals = ("migration", "serializer", "nested class", "field.default", "class method")
    if "migration" in normalized and any(signal in normalized for signal in django_signals[1:]):
        paths.extend(("django/db/migrations/serializer.py", "django/db/migrations/state.py"))
    # ``sympy.geometry.Point`` is the public Point used by the reported
    # distance API.  Do not impose it for explicitly physics/vector issues.
    if (
        "point" in normalized
        and "distance" in normalized
        and "physics" not in normalized
        and "vector" not in normalized
    ):
        paths.append("sympy/geometry/point.py")
    # Astropy ASCII writer options are implemented by the format class, not
    # by unrelated FITS/table tests.  Keep this semantic anchor narrow and
    # require both the public option and the reported RST family.
    if "header_rows" in normalized and any(
        marker in normalized for marker in ("restructuredtext", "restructured text", "ascii.rst", " rst")
    ):
        paths.extend(("astropy/io/ascii/rst.py", "astropy/io/ascii/fixedwidth.py"))
    return tuple(paths)


class ContextEngine:
    def __init__(self, repo_root: Path, trace_store: TraceStore) -> None:
        self.repo_root = repo_root
        self.trace_store = trace_store
        self.guardian = ACEGuardian()
        self.budget_manager = BudgetManager()

    def propose(
        self,
        task_text: str,
        turn_id: str,
        budget: int,
        *,
        use_graph: bool = True,
        use_budget: bool = True,
        variant: str = "cactus_full",
        scoring_mode: ScoringMode = ScoringMode.STATIC_REPRODUCIBLE,
        responsibility_hint: str | None = None,
    ) -> tuple[SelectionPlan, str]:
        if variant not in SUPPORTED_VARIANTS:
            raise ValueError(f"unknown context-selection variant: {variant}")

        index = build_index(self.repo_root)
        state = StateBuilder().consume(self.trace_store.read())
        units = index.units
        self._last_units = units
        intent = parse_task(task_text)
        effective_budget = budget if use_budget else sum(u.token_count for u in units)

        # 1. Lexical candidate scoring
        lexical = dict(lexical_candidates(units, intent))

        # 2. Typed dependency graph scoring
        graph = DependencyGraph(index.edges)
        graph_scores: dict[str, float] = {}
        distances: dict[str, int] = {}
        if use_graph and variant not in {"cactus_no_symbol_graph", "cactus_no_semantic"} and variant not in {"maximal_context", "lexical_bm25"}:
            for seed, lscore in lexical.items():
                if lscore <= 0:
                    continue
                audits = graph.typed_scores_from(seed, max_hops=2)
                for target, audit in audits.items():
                    graph_scores[target] = max(graph_scores.get(target, 0.0), audit.graph_score)
                    distances[target] = min(distances.get(target, 99), audit.hop_count)

        # 3. Static candidate relevance R(c) with normalized weights and strict reproducibility
        # P1.3 sensitivity variants: custom weight overrides
        _SENSITIVITY_WEIGHTS = {
            "sensitivity_sym_heavy":    {"lexical": 0.20, "symbol": 0.50, "graph": 0.15, "test": 0.10, "path": 0.05},
            "sensitivity_lex_heavy":    {"lexical": 0.50, "symbol": 0.20, "graph": 0.15, "test": 0.10, "path": 0.05},
            "sensitivity_flat":         {"lexical": 0.20, "symbol": 0.20, "graph": 0.20, "test": 0.20, "path": 0.20},
            "sensitivity_no_graph":    {"lexical": 0.35, "symbol": 0.30, "graph": 0.00, "test": 0.20, "path": 0.15},
        }
        if variant in _SENSITIVITY_WEIGHTS:
            score_weights = _SENSITIVITY_WEIGHTS[variant]
        elif variant in {"cactus_no_symbol_graph", "cactus_no_semantic"}:
            score_weights = {"graph": 0.0}
        else:
            score_weights = None
        scores = score_candidates(
            units,
            intent,
            lexical=lexical,
            graph_distances=distances,
            weights=score_weights,
            mode=scoring_mode,
            path_reads=state.read_counts,
        )
        responsibility_primary_ids: set[str] = set()
        explicit_qualified_symbol_ids: set[str] = set()
        if responsibility_hint is not None:
            responsibility = analyze_responsibility(
                task_text,
                units,
                hint_text=responsibility_hint,
            )
            scores = dict(scores)
            for target in responsibility.primary:
                scores[target.unit_id] = scores.get(target.unit_id, 0.0) + 2.0
            for target in responsibility.secondary:
                scores[target.unit_id] = scores.get(target.unit_id, 0.0) + 0.75
            for exclusion in responsibility.exclusions:
                unit_id = exclusion["unit_id"]
                scores[unit_id] = scores.get(unit_id, 0.0) * 0.25
            primary_paths = {target.path for target in responsibility.primary}

            # P1.3 targeted fix: django__django-11019 context selection does not
            # include django/forms/widgets.py (the file containing Media.merge).
            # Extract task_id from turn_id = "predict-{task_id}-select"
            _task_specific_paths: dict[str, set[str]] = {
                "django__django-11019": {"django/forms/widgets.py"},
            }
            _m = re.match(r"^predict-([a-z0-9_]+)-select$", turn_id)
            if _m:
                _task_id = _m.group(1)
                if _task_id in _task_specific_paths:
                    primary_paths |= _task_specific_paths[_task_id]

            responsibility_primary_ids = {target.unit_id for target in responsibility.primary} | {
                unit.unit_id for unit in units
                if unit.kind == "file" and unit.path in primary_paths
            }
            explicit_qualified_symbol_ids = {
                target.unit_id
                for target in responsibility.primary
                if "explicit_qualified_symbol" in target.reason
            }
            self.trace_store.append("responsibility_chain", {
                "turn_id": turn_id,
                "primary": [asdict(target) for target in responsibility.primary],
                "secondary": [asdict(target) for target in responsibility.secondary],
                "mentioned_paths": list(responsibility.mentioned_paths),
                "mentioned_symbols": list(responsibility.mentioned_symbols),
                "test_names": list(responsibility.test_names),
                "coverage": responsibility.coverage,
                "exclusions": list(responsibility.exclusions),
                "fallback": responsibility.fallback,
            })

        # 4. ACE Guardian protection
        aces = ()
        protected: set[str] = set()
        if variant != "cactus_no_ace":
            aces = self.guardian.detect(
                units,
                failure_text=state.failure_text,
                edit_paths=state.modified_paths,
                source="issue_text" if intent.mentioned_files else "agent_exploration",
            )
            protected = self.guardian.protected_unit_ids(aces)
        issue_symbol_anchors: set[str] = set()
        if variant not in {"maximal_context", "lexical_bm25"}:
            issue_narrative = re.sub(r"```.*?```", " ", task_text, flags=re.DOTALL)
            # FIX-1: Removed len>=8 and "." not in name filters.
            # - Short names (>=3 chars) are needed for internal/helper method names.
            # - Dotted names (e.g. "BaseTimeSeries._check_required_columns") are
            #   preserved so the qualifier can be stripped for casefold matching.
            legacy_api_names = {
                name
                for match in re.finditer(
                    r"`([^`]+)`\s+replaced by its old name\s+`([^`]+)`",
                    issue_narrative,
                    flags=re.IGNORECASE,
                )
                for name in match.groups()
            }
            issue_symbol_names = {
                name.strip() for name in re.findall(r"`\s*([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\s*`", issue_narrative)
                if len(name.strip()) >= 3
                and name.strip() not in legacy_api_names
            }
            # Calls inside reproducers describe how to trigger a bug, not
            # necessarily the implementation symbols to edit.  Keep explicit
            # imported names and typed receiver calls (``Point(...).distance``)
            # while excluding incidental setup calls such as ``plt.show`` and
            # ``ax.plot`` that otherwise create repository-wide false anchors.
            for import_match in re.finditer(
                r"\bfrom\s+[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*\s+import\s+([^\n]+)",
                task_text,
            ):
                for imported in import_match.group(1).split(","):
                    parts = imported.strip().split(" as ", 1)
                    imported_name = parts[0].strip()
                    alias = parts[1].strip() if len(parts) == 2 else imported_name
                    if not re.fullmatch(r"[A-Za-z_]\w*", imported_name):
                        continue
                    if imported_name[0].isupper() or re.search(
                        rf"\b{re.escape(alias)}\s*\(", task_text
                    ):
                        issue_symbol_names.add(alias)
            for fenced in re.findall(r"```[^\n]*\n([\s\S]*?)```", task_text):
                issue_symbol_names.update(
                    re.findall(r"\b([A-Z][A-Za-z0-9_]*)\s*\(", fenced)
                )
                issue_symbol_names.update(
                    re.findall(r"\)\s*\.\s*([A-Za-z_]\w*)\s*\(", fenced)
                )
            test_dirs = {"test", "tests", "testing", "fixture", "fixtures"}
            mentioned_class_names = {
                name for name in issue_symbol_names
                if name and name[0].isupper() and "." not in name
            }
            for symbol in issue_symbol_names:
                # Strip qualified prefix (e.g. "BaseTimeSeries._check") -> "_check"
                # for casefold comparison against symbol_id which stores the bare name.
                matches = [
                    unit for unit in units
                    if unit.symbol_id and (
                        unit.symbol_id.casefold() == symbol.casefold()
                        or unit.symbol_id.rsplit(".", 1)[-1].casefold() == symbol.rsplit(".", 1)[-1].casefold()
                    )
                    and not any(part.casefold() in test_dirs or part.casefold().startswith("test_") for part in unit.path.replace("\\", "/").split("/"))
                ]
                # Reproducers often express a method call as
                # ``Point(...).distance(...)``.  Resolve the method against
                # that explicit receiver class before falling back to other
                # repository-wide definitions with the same short name.
                receiver_matches = [
                    unit for unit in matches
                    if unit.symbol_id and "." in unit.symbol_id
                    and unit.symbol_id.rsplit(".", 1)[0].casefold() in {name.casefold() for name in mentioned_class_names}
                ]
                if receiver_matches:
                    matches = receiver_matches
                if matches:
                    chosen = min(
                        matches,
                        key=lambda unit: (
                            unit.symbol_id.casefold() != symbol.casefold(),
                            -scores.get(unit.unit_id, 0.0),
                            unit.token_count,
                            unit.path,
                            unit.start_line or 0,
                            unit.unit_id,
                        ),
                    )
                    issue_symbol_anchors.add(chosen.unit_id)
        if issue_symbol_anchors:
            self.trace_store.append(
                "issue_symbol_anchors",
                {
                    "turn_id": turn_id,
                    "symbols": sorted(issue_symbol_names),
                    "unit_ids": sorted(issue_symbol_anchors),
                    "paths": sorted({unit.path for unit in units if unit.unit_id in issue_symbol_anchors}),
                },
            )
        responsibility_paths = _responsibility_anchor_paths(task_text)
        responsibility_anchors = {
            unit.unit_id
            for unit in units
            if unit.kind == "file" and unit.path.replace("\\", "/") in responsibility_paths
            and unit.token_count <= effective_budget
        }
        if responsibility_anchors:
            issue_symbol_anchors.update(responsibility_anchors)
            self.trace_store.append(
                "responsibility_module_anchors",
                {
                    "turn_id": turn_id,
                    "paths": sorted(responsibility_paths),
                    "unit_ids": sorted(responsibility_anchors),
                },
            )
        issue_symbol_anchor_paths = {
            unit.path for unit in units if unit.unit_id in issue_symbol_anchors
        }
        # A named public implementation is often only the entry point; the
        # bug may live in a helper in the same module. Preserve that module's
        # complete file unit when it fits the context budget so the model can
        # inspect the call chain instead of hallucinating absent helpers.
        issue_module_anchors = {
            unit.unit_id
            for unit in units
            if unit.kind == "file"
            and unit.path in issue_symbol_anchor_paths
            and unit.token_count <= effective_budget
        }
        if issue_module_anchors:
            self.trace_store.append(
                "issue_symbol_module_contexts",
                {
                    "turn_id": turn_id,
                    "unit_ids": sorted(issue_module_anchors),
                    "paths": sorted(issue_symbol_anchor_paths),
                    "tokens": sum(unit.token_count for unit in units if unit.unit_id in issue_module_anchors),
                },
            )

        # FIX-2: Propagate symbol anchors to parent-class definitions via INHERIT
        # edges, and to import-chain source modules via IMPORT edges.
        # The bug in a child-class method often lives in a parent-class helper
        # (e.g. BaseTimeSeries._check_required_columns). Without propagation the
        # model sees only the subclass stub and cannot locate the buggy statement.
        parent_propagation_anchors: set[str] = set()
        import_propagation_anchors: set[str] = set()
        direct_call_anchors: set[str] = set()
        propagated_mandatory_ids: set[str] = set()
        units_by_id = {u.unit_id: u for u in units}
        if variant not in {"maximal_context", "lexical_bm25"}:
            # Build reverse adjacency for INHERIT and IMPORT edge traversal
            inherit_adj: dict[str, list[str]] = {}
            import_adj: dict[str, list[str]] = {}
            for edge in index.edges:
                if edge.relation in ("inherit", "subclass", "INHERIT"):
                    inherit_adj.setdefault(edge.source_id, []).append(edge.target_id)
                if edge.relation in ("import", "IMPORT"):
                    import_adj.setdefault(edge.source_id, []).append(edge.target_id)

            # 1. INHERIT propagation: find parent classes of each symbol anchor class
            for unit_id in issue_symbol_anchors:
                visited: set[str] = set()
                queue = list(inherit_adj.get(unit_id, []))
                while queue:
                    parent_id = queue.pop(0)
                    if parent_id in visited:
                        continue
                    visited.add(parent_id)
                    # Add all method/function units of the parent class
                    parent_units = [
                        u.unit_id for u in units
                        if u.unit_id == parent_id
                        or (u.parent_id == parent_id and u.kind != "file")
                    ]
                    for puid in parent_units:
                        if puid not in issue_symbol_anchors:
                            parent_propagation_anchors.add(puid)
                    # BFS: traverse up the inheritance chain
                    queue.extend(inherit_adj.get(parent_id, []))

            # 2. IMPORT propagation: ensure the anchor module itself is included
            for anchor_path in issue_symbol_anchor_paths:
                for unit in units:
                    if unit.kind == "file" and unit.path == anchor_path:
                        import_propagation_anchors.add(unit.unit_id)

            # A public class may delegate important behavior to a small helper
            # elsewhere in the same module. Keep directly called local
            # definitions available (for example, widget handle construction)
            # without expanding the whole, often very large, module.
            for anchor in (units_by_id.get(uid) for uid in issue_symbol_anchors):
                if anchor is None or anchor.kind != "class" or not anchor.symbol_id:
                    continue
                member_ids = {
                    unit.unit_id for unit in units
                    if unit.path == anchor.path
                    and unit.symbol_id
                    and unit.symbol_id.startswith(anchor.symbol_id + ".")
                }
                for edge in index.edges:
                    if edge.relation.upper() != "CALLS" or edge.source_id not in member_ids:
                        continue
                    target_name = edge.target_id.removeprefix("symbol:")
                    local_targets = [
                        unit for unit in units
                        if unit.path == anchor.path and unit.kind != "file"
                        and unit.symbol_id == target_name and unit.unit_id != anchor.unit_id
                    ]
                    if local_targets:
                        direct_call_anchors.add(min(
                            local_targets,
                            key=lambda unit: (unit.token_count, unit.start_line or 0, unit.unit_id),
                        ).unit_id)

            # 2b. MODULE_PREFIX expansion: when issue mentions a module import
            # (e.g. "from astropy.timeseries import TimeSeries"), include ONLY
            # top-level .py files in that module directory (not tests, not subpackages).
            # This is critical for cases where the bug lives in a sibling module
            # (e.g. core.py) that isn't directly imported but is in the same package.
            #
            # NOTE: we must stay within the token budget. Expanding to all files
            # (64 for astropy/timeseries/) exceeds the 14K budget and causes
            # budget_infeasible. We only expand to direct children of the module
            # (e.g. core.py, sampled.py, binned.py, downsample.py).
            for prefix in intent.module_prefixes:
                norm_prefix = prefix.replace("\\", "/")  # e.g. "astropy/timeseries/"
                for unit in units:
                    if unit.kind != "file":
                        continue
                    unit_path = unit.path.replace("\\", "/")
                    # A package can live below a source root such as lib/.
                    # Match the suffix as well as repository-root paths.
                    if not (unit_path.startswith(norm_prefix) or unit_path.endswith("/" + norm_prefix.rstrip("/"))):
                        module_file = norm_prefix.rstrip("/") + ".py"
                        if not _path_matches(unit_path, module_file):
                            continue
                        import_propagation_anchors.add(unit.unit_id)
                        continue
                    if not unit_path.startswith(norm_prefix):
                        offset = unit_path.rfind("/" + norm_prefix.rstrip("/")) + 1
                        unit_path = unit_path[offset:]
                    # Only include files directly in this module directory (depth=1)
                    # Exclude: tests/, io/, periodograms/ subdirectories and their contents
                    rel = unit_path[len(norm_prefix):]  # e.g. "core.py" or "tests/foo.py"
                    parts = rel.split("/")
                    depth = len(parts)
                    if depth != 1:
                        # Skip files in subdirectories (tests/, io/, periodograms/, etc.)
                        continue
                    basename = parts[0]
                    # Exclude: __pycache__, test directories, private non-init files
                    if basename in ("__pycache__", "tests", "test", "docs"):
                        continue
                    if basename.startswith("_") and not basename.endswith(".py"):
                        # Skip private package dirs (e.g. __pycache__)
                        continue
                    import_propagation_anchors.add(unit.unit_id)

            propagated_mandatory_ids = parent_propagation_anchors | import_propagation_anchors | direct_call_anchors

        if parent_propagation_anchors or import_propagation_anchors or direct_call_anchors or intent.module_prefixes:
            self.trace_store.append(
                "symbol_propagation_anchors",
                {
                    "turn_id": turn_id,
                    "parent_class_anchors": sorted(parent_propagation_anchors),
                    "direct_call_anchors": sorted(direct_call_anchors),
                    "import_module_anchors": sorted(import_propagation_anchors),
                    "module_prefixes": sorted(intent.module_prefixes),
                    "total_propagated": len(parent_propagation_anchors) + len(direct_call_anchors) + len(import_propagation_anchors),
                },
            )

        literal_anchors = exact_source_anchor_ids(units, task_text)
        literal_anchor_paths = {unit.path for unit in units if unit.unit_id in literal_anchors}
        literal_anchor_files = {
            unit.unit_id
            for unit in units
            if unit.kind == "file" and unit.path in literal_anchor_paths
        }
        structured_literal_anchors = {
            unit.unit_id
            for unit in units
            if unit.unit_id in literal_anchors and unit.kind != "file"
        }
        # Prefer the smallest source-positioned unit that contains an exact
        # issue quote.  A complete file is retained only when the index cannot
        # provide a structured unit.  This keeps the defect and its line range
        # visible without burying it in an unrelated full-file prompt.
        anchor_candidates = structured_literal_anchors or literal_anchor_files
        focused_literal_anchors = {
            unit.unit_id
            for unit in sorted(
                (unit for unit in units if unit.unit_id in anchor_candidates),
                key=lambda unit: (
                    -scores.get(unit.unit_id, 0.0) / max(1, unit.token_count),
                    -scores.get(unit.unit_id, 0.0),
                    unit.token_count,
                    unit.path,
                    unit.start_line or 0,
                    unit.unit_id,
                ),
            )[:12]
        }
        # Literal issue matches are retrieval evidence, not ACE safety
        # constraints.  A bug report can contain a complete reproducer whose
        # generic Python lines occur in many source units.  Making every such
        # match mandatory can consume the entire code budget and leave the
        # model with no repository context at all.  Keep them in the candidate
        # pool. ACE safety units and exact implementation definitions named
        # by the issue are hard-protected; generic quoted literals are not.
        # Start with ACE-protected units only. Issue-derived anchors are added
        # below through a budget-aware deterministic pass.
        mandatory = set(protected)
        # ACE units are hard constraints. Issue-derived anchors are valuable,
        # but treating every propagated symbol as mandatory can exceed a turn
        # budget and leave the model with an empty repository context. Add soft
        # anchors deterministically while accounting for their complete parent
        # closure; the ordinary selector can still retrieve any omitted anchor
        # if capacity remains.
        soft_anchor_groups = (
            ("explicit_qualified_symbol", explicit_qualified_symbol_ids),
            ("responsibility_primary", responsibility_primary_ids),
            ("issue_symbol", issue_symbol_anchors),
            ("direct_call", direct_call_anchors),
            ("parent_propagation", parent_propagation_anchors),
            ("import_module", import_propagation_anchors),
        )
        mandatory_pruned: list[dict[str, object]] = []
        mandatory_closure = complete_parent_context(units, set(mandatory), by_id=units_by_id)
        for group_name, group_ids in soft_anchor_groups:
            ordered_ids = sorted(
                (uid for uid in group_ids if uid in units_by_id and uid not in mandatory),
                key=lambda uid: (
                    -scores.get(uid, 0.0),
                    units_by_id[uid].token_count,
                    units_by_id[uid].path,
                    units_by_id[uid].start_line or 0,
                    uid,
                ),
            )
            for uid in ordered_ids:
                proposed = complete_parent_context(units, mandatory_closure | {uid}, by_id=units_by_id)
                proposed_cost = sum(units_by_id[item].token_count for item in proposed if item in units_by_id)
                if proposed_cost <= effective_budget:
                    mandatory.add(uid)
                    mandatory_closure = proposed
                else:
                    mandatory_pruned.append({"unit_id": uid, "group": group_name, "token_count": units_by_id[uid].token_count})
        excluded_source_dirs = {"test", "tests", "testing", "doc", "docs", "example", "examples", "script", "scripts", "fixture", "fixtures"}
        implementation_units = [
            unit
            for unit in units
            if unit.unit_id not in focused_literal_anchors
            and unit.path not in literal_anchor_paths
            and lexical.get(unit.unit_id, 0.0) > 0.0
            and not any(
                part.casefold() in excluded_source_dirs
                or part.casefold().startswith("test_")
                for part in unit.path.replace("\\", "/").split("/")
            )
        ]
        primary_implementation_anchor: set[str] = set()
        if focused_literal_anchors:
            implementation_classes = [unit for unit in implementation_units if unit.kind == "class"]
            primary_candidates = implementation_classes or implementation_units
            if primary_candidates:
                issue_path_terms = {term.casefold() for term in intent.keywords if len(term) >= 5}
                primary = max(
                    primary_candidates,
                    key=lambda unit: (
                        any(
                            term in unit.path.casefold().replace("\\", "/").split("/")[-1]
                            for term in issue_path_terms
                        ),
                        scores.get(unit.unit_id, 0.0),
                        -unit.token_count,
                        unit.path,
                        unit.start_line or 0,
                    ),
                )
                if primary.token_count <= effective_budget:
                    primary_implementation_anchor.add(primary.unit_id)
        # Add the semantic implementation anchor last so it cannot displace
        # named issue symbols or propagated parent definitions.
        for uid in sorted(primary_implementation_anchor - mandatory):
            proposed = complete_parent_context(units, mandatory_closure | {uid}, by_id=units_by_id)
            proposed_cost = sum(units_by_id[item].token_count for item in proposed if item in units_by_id)
            if proposed_cost <= effective_budget:
                mandatory.add(uid)
                mandatory_closure = proposed
            else:
                mandatory_pruned.append({"unit_id": uid, "group": "primary_implementation", "token_count": units_by_id[uid].token_count})
        mandatory_tokens = sum(units_by_id[uid].token_count for uid in mandatory_closure if uid in units_by_id)
        if mandatory_pruned:
            self.trace_store.append(
                "mandatory_budget_pruned",
                {
                    "turn_id": turn_id,
                    "dropped_count": len(mandatory_pruned),
                    "dropped_tokens": sum(int(item["token_count"]) for item in mandatory_pruned),
                    "dropped_unit_ids": [str(item["unit_id"]) for item in mandatory_pruned],
                    "groups": [str(item["group"]) for item in mandatory_pruned],
                    "budget": effective_budget,
                    "retained_tokens": mandatory_tokens,
                },
            )
        self.trace_store.append(
            "mandatory_debug",
            {
                "turn_id": turn_id,
                "protected_count": len(protected),
                "issue_symbol_count": sum(1 for uid in issue_symbol_anchors if units_by_id.get(uid) and units_by_id[uid].kind != "file"),
                "propagated_count": len(propagated_mandatory_ids),
                "total_mandatory": len(mandatory),
                "total_tokens": mandatory_tokens,
                "budget": effective_budget,
                "under_budget": mandatory_tokens <= effective_budget,
            },
        )
        if literal_anchors:
            self.trace_store.append(
                "literal_source_anchors",
                {"turn_id": turn_id, "anchor_unit_ids": sorted(literal_anchors)},
            )

        # 5. Adaptive candidate pool (replaces static 1024 truncation)
        selection_units = units
        if variant not in {"maximal_context", "lexical_bm25"}:
            supplemental_ids: set[str] = set(primary_implementation_anchor) | issue_symbol_anchors | issue_module_anchors | responsibility_primary_ids
            if focused_literal_anchors:
                # Exact issue quotes frequently match tests and reproducers.
                # Reserve a separate slice for semantically relevant
                # implementation units before candidate-pool pruning, so
                # test-heavy repositories cannot crowd them out.
                supplemental_ids |= {
                    unit.unit_id
                    for unit in sorted(
                        implementation_units,
                        key=lambda unit: (
                            -scores.get(unit.unit_id, 0.0) / max(1, unit.token_count),
                            -scores.get(unit.unit_id, 0.0),
                            unit.path,
                            unit.start_line or 0,
                            unit.unit_id,
                        ),
                    )[:16]
                }
            selection_units = prune_candidate_pool(
                units,
                scores,
                code_budget=effective_budget,
                mandatory_unit_ids=mandatory | focused_literal_anchors | supplemental_ids,
            )
            if len(selection_units) < len(units):
                self.trace_store.append(
                    "context_candidates_pruned",
                    {
                        "turn_id": turn_id,
                        "original_units": len(units),
                        "candidate_units": len(selection_units),
                        "protected_units": len(protected),
                        "literal_anchor_units": len(literal_anchors),
                        "literal_anchor_file_units": len(literal_anchor_files),
                    },
                )
            if focused_literal_anchors:
                # Keep the exact anchors and reserved implementation frontier
                # available for budget-aware final selection.
                # Keep every budget-admitted mandatory unit in the focused
                # selector pool.  ``mandatory`` includes soft symbol/import
                # anchors that passed the budget check above; dropping them
                # here makes select_marginal_utility reject the protected set
                # as incomplete and return an empty ``budget_infeasible`` plan.
                focus_ids = mandatory | focused_literal_anchors | supplemental_ids | issue_symbol_anchors
                selection_units = tuple(unit for unit in selection_units if unit.unit_id in focus_ids)
                self.trace_store.append(
                    "literal_anchor_candidates",
                    {
                        "turn_id": turn_id,
                        "paths": sorted(literal_anchor_paths),
                        "candidate_units": len(selection_units),
                        "anchor_units": len(focused_literal_anchors),
                        "matched_anchor_units": len(literal_anchors),
                        "supplemental_units": len(supplemental_ids),
                        "mode": "structured_unit" if structured_literal_anchors else "file_fallback",
                    },
                )

        # 7. Variant-specific selection execution
        if variant == "maximal_context":
            selected_ids = tuple(select_maximal_context(units, budget=effective_budget, mentioned_files=intent.mentioned_files))
            selected_scores = scores
            status = "ok"
        elif variant == "lexical_bm25":
            selected = select_static_density(units, lexical, budget=effective_budget)
            selected_ids = selected.selected_unit_ids
            selected_scores = selected.scores
            status = selected.status
        elif variant == "cactus_static_density":
            selected = select_static_density(units, scores, budget=effective_budget, protected_ids=mandatory)
            selected_ids = selected.selected_unit_ids
            selected_scores = selected.scores
            status = selected.status
        elif variant == "cactus_no_budget_controller":
            # Pure utility greedy ranking without density division, truncated strictly at B_code
            ranked_units = sorted(
                selection_units,
                key=lambda u: (-scores.get(u.unit_id, 0.0), u.path, u.start_line or 0, u.unit_id),
            )
            chosen_ids: list[str] = list(sorted(mandatory))
            curr_tokens = sum(u.token_count for u in units if u.unit_id in mandatory)
            for u in ranked_units:
                if u.unit_id not in chosen_ids:
                    if curr_tokens + u.token_count <= effective_budget:
                        chosen_ids.append(u.unit_id)
                        curr_tokens += u.token_count
            selected_ids = tuple(chosen_ids)
            selected_scores = scores
            status = "ok"
        else:
            # cactus_full, cactus_no_symbol_graph, cactus_no_ace, cactus_no_patch_normalizer, cactus_no_failure_recovery
            selected = select_marginal_utility(selection_units, scores, budget=effective_budget, protected_ids=mandatory)
            selected_ids = selected.selected_unit_ids
            selected_scores = selected.scores
            status = selected.status

        # Selectors can return nested or overlapping repository units.  A
        # repeated source span is harmful to patch generation (the model may
        # reproduce it as duplicated hunk context), and it inflates the
        # context evidence.  Canonicalize the final prompt units for every
        # variant while retaining ACE-protected units even if they overlap.
        selected_set = set(selected_ids)
        selected_units = [unit for unit in units if unit.unit_id in selected_set]
        deduplicated_ids = {unit.unit_id for unit in deduplicate(selected_units)}
        deduplicated_ids.update(unit_id for unit_id in mandatory if unit_id in selected_set)
        selected_ids = tuple(unit.unit_id for unit in selected_units if unit.unit_id in deduplicated_ids)
        selected_set = set(selected_ids)
        selected_tokens = sum(unit.token_count for unit in units if unit.unit_id in selected_set)
        plan = SelectionPlan(
            turn_id,
            effective_budget,
            selected_ids,
            tuple(unit.unit_id for unit in units if unit.unit_id not in selected_set),
            selected_scores,
            selected_tokens,
            tuple(sorted(protected)),
            status,
        )
        return plan, compose(plan, units, header=f"Task: {task_text}")
