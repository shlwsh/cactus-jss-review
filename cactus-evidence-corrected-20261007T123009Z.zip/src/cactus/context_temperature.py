"""Hot, warm, and cold context retention policy."""

from __future__ import annotations

from enum import StrEnum


class ContextTemperature(StrEnum):
    HOT = "hot"
    WARM = "warm"
    COLD = "cold"


def classify_temperature(
    access_count: int,
    recency_turns: int,
    dependency_degree: int = 0,
) -> ContextTemperature:
    """Classify a context unit using replay-safe integer features."""
    if access_count < 0 or recency_turns < 0 or dependency_degree < 0:
        raise ValueError("temperature features must be non-negative")
    if access_count >= 3 or (access_count >= 2 and recency_turns <= 1) or dependency_degree >= 4:
        return ContextTemperature.HOT
    if access_count >= 1 or recency_turns <= 3 or dependency_degree >= 1:
        return ContextTemperature.WARM
    return ContextTemperature.COLD
