"""Stable context bundle serialization with a content hash."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence

from cactus.domain.models import ContextUnit


def pack_context(units: Sequence[ContextUnit], *, task_id: str, budget: int, actions: Mapping[str, str] | None = None) -> dict[str, object]:
    ordered = sorted(units, key=lambda unit: (unit.path, unit.start_line or 0, unit.symbol_id or "", unit.unit_id))
    token_count = sum(unit.token_count for unit in ordered)
    if token_count > budget:
        raise ValueError("selected context exceeds budget")
    chunks = [{"unit_id": unit.unit_id, "path": unit.path, "symbol_id": unit.symbol_id, "kind": unit.kind, "start_line": unit.start_line, "end_line": unit.end_line, "token_count": unit.token_count, "action": (actions or {}).get(unit.unit_id, "keep_raw"), "snapshot_hash": unit.snapshot_hash} for unit in ordered]
    payload = {"task_id": task_id, "budget": budget, "chunks": chunks}
    return {"task_id": task_id, "budget": budget, "token_count": token_count, "chunks": chunks, "context_bundle_hash": canonical_context_hash(payload)}


def canonical_context_hash(context: Mapping[str, object]) -> str:
    """Hash the canonical task/budget/chunk selection, excluding claimed hashes."""
    payload = {key: context[key] for key in ("task_id", "budget", "chunks") if key in context}
    if set(payload) != {"task_id", "budget", "chunks"}:
        raise ValueError("context hash requires task_id, budget, and chunks")
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def verify_context_hash(context: Mapping[str, object], expected_hash: str | None = None) -> str:
    """Verify a recorded hash before reusing a frozen context for a retry."""
    recorded = expected_hash or context.get("context_bundle_hash")
    if not isinstance(recorded, str) or not recorded:
        raise ValueError("context hash is missing")
    actual = canonical_context_hash(context)
    if actual != recorded:
        raise ValueError("context hash mismatch; frozen context must be quarantined")
    return actual


def verify_retry_context(previous: Mapping[str, object], candidate: Mapping[str, object]) -> str:
    """Require both the original and retry to match the same frozen selection."""
    expected = verify_context_hash(previous)
    verify_context_hash(candidate, expected)
    return expected
