"""Source-anchored repair sites ranked from the inference-safe repository unit pool."""

from __future__ import annotations

import ast
import difflib
import hashlib
import re
import textwrap
from dataclasses import dataclass, replace
from pathlib import Path
from collections.abc import Sequence

from cactus.domain.models import ContextUnit
from cactus.retrieval.lexical import lexical_candidates
from cactus.task.parser import parse_task


@dataclass(frozen=True)
class RepairSite:
    site_id: str
    path: str
    symbol: str
    line: int
    old_statement: str
    source_sha256: str
    branch_condition: str | None = None
    end_line: int | None = None
    kind: str = "function_statement"


def _definitions(tree: ast.Module) -> dict[str, ast.FunctionDef | ast.AsyncFunctionDef]:
    result: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}

    def visit(nodes: Sequence[ast.stmt], parents: tuple[str, ...] = ()) -> None:
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                visit(node.body, (*parents, node.name))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                result[".".join((*parents, node.name))] = node
                visit(node.body, (*parents, node.name))

    visit(tree.body)
    return result


def _semantic_fingerprint(code: str) -> str | None:
    """Return a location-free AST fingerprint for a complete Python snippet."""
    normalized = textwrap.dedent(code).strip()
    if not normalized:
        return None
    try:
        tree = ast.parse(normalized)
    except (SyntaxError, ValueError):
        return None
    return ast.dump(tree, annotate_fields=True, include_attributes=False)


def _dedented_ast_source(source: str, node: ast.AST) -> str:
    """Return a standalone AST slice with its absolute source indentation removed."""
    segment = ast.get_source_segment(source, node, padded=True)
    return textwrap.dedent(segment or "").strip()


def _semantically_equivalent(source: str, proposed: str) -> bool:
    """Compare valid Python snippets without erasing whitespace inside literals.

    AST comparison naturally ignores quote style, indentation, comments, and
    adjacent string-literal spelling while preserving literal values and
    expression structure. Invalid or empty snippets never match.
    """
    if not source.strip() or not proposed.strip():
        return False
    source_fingerprint = _semantic_fingerprint(source)
    return (
        source_fingerprint is not None
        and source_fingerprint == _semantic_fingerprint(proposed)
    )


def _calls(node: ast.AST, names: set[str], dispatch: dict[str, dict[str, str]], issue: str) -> set[str]:
    found: set[str] = set()
    for child in ast.walk(node):
        if not isinstance(child, ast.Call):
            continue
        func = child.func
        if isinstance(func, ast.Name) and func.id in names:
            found.add(func.id)
        elif isinstance(func, ast.Subscript) and isinstance(func.value, ast.Name):
            mapping = dispatch.get(func.value.id, {})
            if isinstance(func.slice, ast.Constant) and isinstance(func.slice.value, str):
                target = mapping.get(func.slice.value)
                if target:
                    found.add(target)
            else:
                # A dynamic key such as ``_operators[transform.op]`` cannot
                # be resolved from issue prose. Keep every statically known
                # target in the local dispatch table so repair-site ranking
                # can traverse the real call neighborhood instead of
                # silently cutting the dependency chain.
                found.update(mapping.values())
    return found


def _is_code_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped or stripped.startswith(("```", "#", "@")):
        return True
    return bool(
        re.match(r"^(?:async\s+)?def\s+[A-Za-z_]\w*\s*\(", stripped)
        or re.match(r"^class\s+[A-Za-z_]\w*(?:\([^)]*\))?\s*:", stripped)
        or re.match(r"^(?:from\s+\S+\s+import|import\s+\S+)", stripped)
        or re.match(r"^[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*\s*=\s*", stripped)
        or re.match(r"^[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*\s*\(", stripped)
        or re.match(r"^[)\]}][,)]?$", stripped)
    )


def _issue_relevance_intent(issue_text: str):
    """Drop reproduction/output code before retrieval and normalize common code vocabulary."""
    prose: list[str] = []
    fenced = False
    for line in issue_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("```"):
            fenced = not fenced
            continue
        if fenced or _is_code_line(line):
            continue
        prose.append(line)
    relevance_text = "\n".join(prose)
    intent = parse_task(relevance_text)
    terms = {term.casefold() for term in intent.keywords}
    expanded = set(terms)
    for term in terms:
        if term.endswith("ies") and len(term) > 4:
            expanded.add(term[:-3] + "y")
        elif term.endswith(("ches", "shes", "sses", "xes", "zes")):
            expanded.add(term[:-2])
        elif term.endswith("s") and len(term) > 3:
            expanded.add(term[:-1])
        elif len(term) > 3:
            expanded.add(term + "s")
    if terms & {"method", "methods", "classmethod", "classmethods"}:
        expanded.update({"function", "functions", "callable", "bound"})
    if terms & {"nested", "nesting"}:
        expanded.update({"qualified", "qualname", "enclosing", "nested"})
    if terms & {"migration", "migrations", "migrate", "migrating"}:
        expanded.update({"migration", "migrations", "serializer", "serialize", "serialization", "writer"})
    return replace(intent, keywords=tuple(sorted(expanded)))


def _quoted_source_spans(
    issue_text: str,
    sources: dict[str, str],
) -> dict[str, list[tuple[int, int]]]:
    """Locate issue code that occurs verbatim in inference-safe source files."""
    spans: dict[str, list[tuple[int, int]]] = {}
    for block in re.findall(r"```[^\n]*\n(.*?)```", issue_text, flags=re.DOTALL):
        quoted_lines = [line.strip() for line in block.splitlines() if line.strip() and not line.lstrip().startswith("#")]
        if not quoted_lines or sum(map(len, quoted_lines)) < 30 or len(quoted_lines) > 30:
            continue
        matches: list[tuple[str, int, int]] = []
        for path, source in sources.items():
            source_lines = [line.strip() for line in source.splitlines()]
            width = len(quoted_lines)
            for offset in range(len(source_lines) - width + 1):
                if source_lines[offset:offset + width] == quoted_lines:
                    matches.append((path, offset + 1, offset + width))
                    if len(matches) > 3:
                        break
            if len(matches) > 3:
                break
        # A frequently repeated snippet is not a reliable localization clue.
        if len(matches) <= 3:
            for path, start, end in matches:
                spans.setdefault(path, []).append((start, end))
    return spans


def _identifier_words(name: str) -> str:
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name)
    spaced = re.sub(r"([A-Z])([A-Z][a-z])", r"\1 \2", spaced)
    return " ".join(re.findall(r"[A-Za-z_][A-Za-z0-9_]+", spaced.replace("_", " ")))


def _get_function_signature(source: str, node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Extract function signature (def line only) for lightweight search text."""
    lines = source.splitlines()
    if node.lineno <= len(lines):
        return lines[node.lineno - 1].strip()
    return ""


def _strip_docstring(source: str, node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Extract function body without docstring to reduce noise in search and context."""
    lines = source.splitlines()
    body_start = node.body[0] if node.body else None
    docstring_span = None
    if (
        isinstance(body_start, ast.Expr)
        and isinstance(body_start.value, ast.Constant)
        and isinstance(body_start.value.value, str)
    ):
        docstring_span = (body_start.lineno, int(body_start.end_lineno or body_start.lineno))
    return "\n".join(
        line
        for line_number, line in enumerate(lines, start=1)
        if node.lineno <= line_number <= node.end_lineno
        and not (docstring_span and docstring_span[0] <= line_number <= docstring_span[1])
    )


def build_repair_sites(
    selected_units: Sequence[ContextUnit],
    issue_text: str,
    *,
    selected_unit_ids: set[str] | frozenset[str] | None = None,
    max_functions: int = 12,
    max_sites: int = 48,
    max_chars: int = 18000,
    extended: bool = False,
) -> tuple[str, dict[str, RepairSite]]:
    """Rank repair functions across the inference-safe pool and expose bounded edit IDs."""
    file_units = {unit.path: unit for unit in selected_units if unit.kind == "file" and unit.path.endswith(".py")}
    if not file_units:
        raise ValueError("no inference-safe Python file units for repair localization")
    selected_ids = set(selected_unit_ids or ())
    selected_paths = (
        {unit.path for unit in selected_units if unit.unit_id in selected_ids}
        if selected_unit_ids is not None else set(file_units)
    )
    candidates: list[tuple[ContextUnit, str, ast.FunctionDef | ast.AsyncFunctionDef, str]] = []
    parsed: dict[str, tuple[str, ast.Module, dict[str, ast.FunctionDef | ast.AsyncFunctionDef], dict[str, dict[str, str]]]] = {}
    for path, unit in sorted(file_units.items()):
        source = unit.text.replace("\r\n", "\n")
        try:
            tree = ast.parse(source)
        except SyntaxError:
            continue
        definitions = _definitions(tree)
        dispatch: dict[str, dict[str, str]] = {}
        for node in tree.body:
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Dict):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        dispatch[target.id] = {
                            key.value: value.id for key, value in zip(node.value.keys, node.value.values)
                            if isinstance(key, ast.Constant) and isinstance(key.value, str)
                            and isinstance(value, ast.Name)
                        }
        parsed[path] = source, tree, definitions, dispatch
        for name, node in definitions.items():
            # B.2: Use lightweight signature + docstring-stripped body for search text
            sig = _get_function_signature(source, node)
            body_no_doc = _strip_docstring(source, node)
            if body_no_doc:
                candidate_id = f"repair:{path}:{node.lineno}:{name}"
                # Lightweight search: signature + stripped body (no docstring noise)
                search_text = f"{path.replace('/', ' ')} {_identifier_words(name)} {sig} {body_no_doc}"
                candidates.append((ContextUnit(candidate_id, "function", path, max(1, len(body_no_doc) // 4), search_text, name, node.lineno, node.end_lineno), path, node, name))
    if not candidates and not extended:
        raise ValueError("no inference-safe Python definitions for repair localization")
    relevance = dict(lexical_candidates((item[0] for item in candidates), _issue_relevance_intent(issue_text)))
    quote_spans = _quoted_source_spans(issue_text, {path: source for path, (source, _, _, _) in parsed.items()})
    # A class-qualified method named by the issue is stronger evidence than
    # a broad selected path or a lexical overlap in an unrelated function.
    qualified_references = {
        value.casefold() for value in re.findall(
            r"\b[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*(?=\s*\(|\b)",
            issue_text,
        )
    }
    issue_source_lines = {
        line.strip().casefold()
        for line in issue_text.splitlines()
        if len(line.strip()) >= 30 and "=" in line and "(" in line
    }
    issue_instance_attrs = {
        value.casefold()
        for value in re.findall(r"\bself\.([A-Za-z_][A-Za-z0-9_]*)\b", issue_text)
    }

    def source_use_evidence(path: str, node: ast.FunctionDef | ast.AsyncFunctionDef) -> tuple[int, int]:
        source = parsed[path][0]
        body_lines = source.splitlines()[node.lineno - 1:int(node.end_lineno or node.lineno)]
        repeated_statement = any(line.strip().casefold() in issue_source_lines for line in body_lines)
        shared_attribute_owner = any(
            isinstance(child, (ast.Assign, ast.AnnAssign))
            and any(
                isinstance(target, ast.Attribute)
                and isinstance(target.value, ast.Name)
                and target.value.id == "self"
                and target.attr.casefold() in issue_instance_attrs
                for target in (child.targets if isinstance(child, ast.Assign) else [child.target])
            )
            for child in ast.walk(node)
        )
        return int(repeated_statement), int(shared_attribute_owner)

    def quoted_function(item: tuple[ContextUnit, str, ast.FunctionDef | ast.AsyncFunctionDef, str]) -> bool:
        _, path, node, _ = item
        return any(node.lineno <= start and int(node.end_lineno or node.lineno) >= end
                   for start, end in quote_spans.get(path, ()))
    graph_distance: dict[tuple[str, str], int] = {}
    graph_relevance: dict[tuple[str, str], float] = {}
    dynamic_dispatch_relevance: dict[tuple[str, str], float] = {}
    call_relevance_decay = 0.7
    # B.1: Increase graph depth to capture nested call chains like _separable -> _cstack
    max_graph_depth = 3
    for _, path, node, name in sorted(candidates, key=lambda item: (-relevance.get(item[0].unit_id, 0.0), item[1], item[2].lineno)):
        seed_relevance = relevance.get(f"repair:{path}:{node.lineno}:{name}", 0.0)
        if seed_relevance <= 0:
            continue
        queue = [(name, 0)]
        visited: set[str] = set()
        _, _, definitions, dispatch = parsed[path]
        simple_names = {candidate_name.split(".")[-1] for candidate_name in definitions}
        while queue:
            current, depth = queue.pop(0)
            if current in visited or depth >= max_graph_depth:
                continue
            visited.add(current)
            current_node = definitions.get(current)
            if current_node is None:
                continue
            dynamic_targets: set[str] = set()
            for child in ast.walk(current_node):
                if not isinstance(child, ast.Call) or not isinstance(child.func, ast.Subscript):
                    continue
                if not isinstance(child.func.value, ast.Name):
                    continue
                if isinstance(child.func.slice, ast.Constant) and isinstance(child.func.slice.value, str):
                    continue
                dynamic_targets.update(dispatch.get(child.func.value.id, {}).values())
            for neighbor in sorted(_calls(current_node, simple_names, dispatch, issue_text)):
                match_name = next((candidate_name for candidate_name in definitions if candidate_name == neighbor), None)
                if match_name is None:
                    choices = [candidate_name for candidate_name in definitions if candidate_name.split(".")[-1] == neighbor]
                    match_name = choices[0] if len(choices) == 1 else None
                if match_name is None:
                    continue
                distance = depth + 1
                key = (path, match_name)
                graph_distance[key] = min(graph_distance.get(key, distance), distance)
                graph_relevance[key] = max(
                    graph_relevance.get(key, 0.0),
                    seed_relevance * call_relevance_decay**distance,
                )
                if neighbor in dynamic_targets:
                    dynamic_dispatch_relevance[key] = max(
                        dynamic_dispatch_relevance.get(key, 0.0),
                        seed_relevance * call_relevance_decay**distance,
                    )
                queue.append((match_name, distance))

    def combined_score(item: tuple[ContextUnit, str, ast.FunctionDef | ast.AsyncFunctionDef, str]) -> tuple[int, int, int, int, int, float]:
        unit, path, node, name = item
        lex_score = relevance.get(unit.unit_id, 0.0)
        graph_score = graph_relevance.get((path, name), 0.0)
        score = lex_score + graph_score * 0.8
        in_selected = int(selected_unit_ids is not None and path in selected_paths)
        repeated_statement, shared_attribute_owner = source_use_evidence(path, node)
        return (-int(name.casefold() in qualified_references), -repeated_statement,
                -shared_attribute_owner, -int(quoted_function(item)), -in_selected, -score)

    eligible = [
        item for item in candidates
        if relevance.get(item[0].unit_id, 0.0) > 0
        or (item[1], item[3]) in graph_distance
        or (selected_unit_ids is not None and item[1] in selected_paths)
        or quoted_function(item)
    ]
    score_ranked = sorted(eligible, key=combined_score)
    dispatch_ranked = sorted(
        (item for item in eligible if (item[1], item[3]) in dynamic_dispatch_relevance),
        key=lambda item: (
            -int(item[1] in selected_paths),
            -dynamic_dispatch_relevance[(item[1], item[3])],
            -relevance.get(item[0].unit_id, 0.0),
            item[1], item[2].lineno, item[3],
        ),
    )
    # Reserve one third of the bounded function pool for statically resolved
    # dynamic-dispatch targets; fill the remainder by combined relevance.
    dispatch_quota = min(len(dispatch_ranked), max(1, max_functions // 3)) if dispatch_ranked else 0
    ranked = dispatch_ranked[:dispatch_quota]
    ranked_ids = {(item[1], item[3]) for item in ranked}
    ranked.extend(
        item for item in score_ranked
        if (item[1], item[3]) not in ranked_ids
    )
    ranked = ranked[:max_functions]
    if not ranked:
        ranked = [item for item in sorted(candidates, key=lambda item: (item[1], item[2].lineno, item[3])) if item[1] in selected_paths][:max_functions]
    if not ranked and not extended:
        raise ValueError("no repair definition has lexical or selected-context evidence")

    fragments: list[str] = []
    sites: dict[str, RepairSite] = {}
    # Extended assignment sites are valuable for settings/constants, but they
    # must not crowd out executable statements from responsibility-ranked
    # functions.  In the initial Lite-50 run, selected-context membership gave
    # many unrelated assignments equal priority and no callable site from the
    # actual repair function survived into the prompt.
    assignment_site_quota = min(12, max(1, max_sites // 3)) if extended else 0
    reserved_definition_quota = 4 if extended else 0
    reserved_import_quota = min(4, max(1, max_sites // 6)) if extended else 0
    function_site_limit = max(
        1,
        max_sites - assignment_site_quota - reserved_definition_quota - reserved_import_quota,
    )
    ranked_assignments: list[tuple[int, str, str, ast.stmt, str, str]] = []

    # Reserve space for the issue and an estimated site table before adding excerpts.
    budget_buffer = 500  # Reserve buffer for site_table and overhead
    available_budget = max(0, max_chars - len(issue_text) - budget_buffer)

    definition_site_ids: list[str] = []
    import_site_ids: list[str] = []
    if extended:
        assignment_candidates: list[tuple[int, str, str, ast.stmt, str, str]] = []
        issue_folded = issue_text.casefold()
        for path, (source, tree, _, _) in parsed.items():
            digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
            parents: dict[int, ast.AST] = {}
            for parent in ast.walk(tree):
                for child in ast.iter_child_nodes(parent):
                    parents[id(child)] = parent
            for statement in ast.walk(tree):
                if not isinstance(statement, (ast.Assign, ast.AnnAssign)):
                    continue
                parent = parents.get(id(statement))
                if not isinstance(parent, (ast.Module, ast.ClassDef)):
                    continue
                target_nodes = statement.targets if isinstance(statement, ast.Assign) else [statement.target]
                target_names = [
                    target.id for target in target_nodes if isinstance(target, ast.Name)
                ]
                if not target_names:
                    continue
                target_name = target_names[0]
                value = statement.value
                # ``AnnAssign.value`` is optional (for example ``SETTING:
                # str``).  These declaration-only nodes have no replacement
                # expression to inspect and must not abort site discovery for
                # the entire repository.
                value_nodes = tuple(ast.walk(value)) if isinstance(value, ast.AST) else ()
                has_string = any(
                    isinstance(node, ast.Constant) and isinstance(node.value, str)
                    for node in value_nodes
                )
                looks_regex = (
                    "regex" in target_name.casefold()
                    or any(
                        isinstance(node, ast.Call)
                        and isinstance(node.func, ast.Attribute)
                        and isinstance(node.func.value, ast.Name)
                        and node.func.value.id == "re"
                        and node.func.attr == "compile"
                        for node in value_nodes
                    )
                )
                if looks_regex and has_string:
                    kind = "regex_literal"
                elif target_name.isupper() or any(part in path.casefold() for part in ("settings", "config")):
                    kind = "config_value"
                elif isinstance(parent, ast.ClassDef):
                    kind = "class_attribute"
                else:
                    kind = "module_assignment"
                old = ast.get_source_segment(source, statement)
                if not old:
                    continue
                end_line = int(statement.end_lineno or statement.lineno)
                symbol = f"{parent.name}.{target_name}" if isinstance(parent, ast.ClassDef) else target_name
                score = 0
                score += 100 if target_name.casefold() in issue_folded else 0
                score += 20 if path in selected_paths else 0
                score += 10 if any(word in issue_folded for word in _identifier_words(target_name).casefold().split()) else 0
                if isinstance(parent, ast.ClassDef):
                    class_name = parent.name.casefold()
                    if class_name in issue_folded:
                        score += 200
                    elif any(word in issue_folded for word in _identifier_words(parent.name).casefold().split() if len(word) >= 4):
                        score += 50
                old_seg = old.casefold()
                issue_kw = set(re.findall(r"\b[a-z_][a-z0-9_]{3,}\b", issue_folded))
                kw_hits = sum(1 for w in issue_kw if w in old_seg)
                score += min(60, kw_hits * 10)
                assignment_candidates.append((score, path, symbol, statement, kind, digest))
        ranked_assignments = sorted(
            assignment_candidates,
            key=lambda item: (-item[0], item[1], item[3].lineno, item[2]),
        )

    for _, path, node, name in ranked:
        source, source_tree, _, _ = parsed[path]
        lines = source.splitlines()
        digest = hashlib.sha256(source.encode("utf-8")).hexdigest()

        first_statement = node.body[0] if node.body else None
        docstring_span = None
        if (
            isinstance(first_statement, ast.Expr)
            and isinstance(first_statement.value, ast.Constant)
            and isinstance(first_statement.value.value, str)
        ):
            docstring_span = (first_statement.lineno, int(first_statement.end_lineno or first_statement.lineno))
        body_lines = []
        for line_no in range(node.lineno, node.end_lineno + 1):
            in_docstring = docstring_span and docstring_span[0] <= line_no <= docstring_span[1]
            if 0 < line_no <= len(lines) and not in_docstring:
                body_lines.append(f"L{line_no}: {lines[line_no - 1]}")
        body = "\n".join(body_lines)
        fragment = f"<!-- cactus-unit:repair path:{path} symbol:{name} lines:{node.lineno}-{node.end_lineno} -->\n{body}"

        current_fragments_len = sum(map(len, fragments))
        estimated_table_size = len(sites) * 80  # Rough estimate per site
        remaining_budget = available_budget - current_fragments_len - estimated_table_size

        if len(fragment) > remaining_budget:
            if path in selected_paths and remaining_budget > 300:
                truncated_lines = body_lines[:max(5, remaining_budget // 60)]
                fragment = f"<!-- cactus-unit:repair path:{path} symbol:{name} lines:{node.lineno}-{node.end_lineno} -->\n" + "\n".join(truncated_lines)
            elif path not in selected_paths:
                continue

        fragments.append(fragment)
        func_statement_count = 0
        max_statements_per_func = 6 if extended else 100
        issue_kw = set(re.findall(r"\b[A-Za-z_][A-Za-z0-9_]{3,}\b", issue_text.casefold()))
        statement_types = (
            ast.Assign, ast.AnnAssign, ast.AugAssign, ast.Return, ast.Raise,
            ast.Expr, ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith,
            ast.If, ast.Try,
        )
        statements_in_node = [
            s for s in ast.walk(node)
            if isinstance(s, statement_types)
            and s is not node
        ]
        def _statement_sort_key(s: ast.stmt) -> tuple[int, int]:
            seg = (ast.get_source_segment(source, s) or "").casefold()
            target_names = []
            if isinstance(s, ast.Assign):
                for t in s.targets:
                    if isinstance(t, ast.Name): target_names.append(t.id.casefold())
                    elif isinstance(t, ast.Attribute): target_names.append(t.attr.casefold())
            elif isinstance(s, ast.AugAssign):
                if isinstance(s.target, ast.Name): target_names.append(s.target.id.casefold())
                elif isinstance(s.target, ast.Attribute): target_names.append(s.target.attr.casefold())
            target_match = any(t in issue_kw for t in target_names)
            matches = sum(1 for w in issue_kw if w in seg)
            end = int(getattr(s, "end_lineno", s.lineno))
            quote_match = max((
                1000 if s.lineno == start and end == stop else
                500 if s.lineno <= start and end >= stop else
                100 if start <= s.lineno and end <= stop else 0
                for start, stop in quote_spans.get(path, ())
            ), default=0)
            return (-int(quote_match + target_match * 10 + matches), getattr(s, "lineno", 0))
        statements_in_node.sort(key=_statement_sort_key)

        for statement in statements_in_node:
            if len(sites) >= function_site_limit or func_statement_count >= max_statements_per_func:
                break
            end_line = int(getattr(statement, "end_lineno", statement.lineno))
            same_span = [
                other for other in ast.walk(source_tree)
                if isinstance(other, statement_types)
                and other.lineno == statement.lineno
                and int(getattr(other, "end_lineno", other.lineno)) == end_line
            ]
            if len(same_span) != 1:
                continue
            old = _dedented_ast_source(source, statement)
            if not old or (isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Constant)):
                continue
            site_id = "S-" + hashlib.sha256(f"{path}:{statement.lineno}:{end_line}:{digest}".encode("utf-8")).hexdigest()[:12]
            branch_conditions: list[str] = []
            for conditional in ast.walk(node):
                if not isinstance(conditional, ast.If):
                    continue
                test = ast.get_source_segment(source, conditional.test)
                if not test:
                    continue
                if any(statement is descendant for branch in conditional.orelse for descendant in ast.walk(branch)):
                    branch_conditions.append(f"else of `{test}`")
                elif any(statement is descendant for branch in conditional.body for descendant in ast.walk(branch)):
                    branch_conditions.append(f"if `{test}`")
            sites[site_id] = RepairSite(
                site_id, path, name, statement.lineno, old,
                digest, "; ".join(branch_conditions) or None, end_line, "function_statement",
            )
            func_statement_count += 1

    # A complete relevant definition can express control-flow repairs that
    # cannot be represented by replacing isolated leaf statements.
    if extended:
        definition_candidates: list[tuple[str, str]] = []
        for _, path, _, name in ranked:
            if path not in selected_paths:
                continue
            definition_candidates.append((path, name))
            # A caller may be responsible for combining several independent
            # inputs before this method runs. Keep its complete definition
            # available alongside the directly named callee.
            if "." in name:
                owner, method = name.rsplit(".", 1)
                for caller_name, caller in parsed[path][2].items():
                    if not caller_name.startswith(owner + ".") or caller_name == name:
                        continue
                    if any(
                        isinstance(child, ast.Call)
                        and isinstance(child.func, ast.Attribute)
                        and isinstance(child.func.value, ast.Name)
                        and child.func.value.id == "self"
                        and child.func.attr == method
                        for child in ast.walk(caller)
                    ):
                        definition_candidates.append((path, caller_name))
        seen_definitions: set[tuple[str, str]] = set()
        for path, name in definition_candidates:
            if len(definition_site_ids) >= reserved_definition_quota:
                break
            if (path, name) in seen_definitions:
                continue
            seen_definitions.add((path, name))
            source, _, definitions, _ = parsed[path]
            node = definitions.get(name)
            if node is None:
                continue
            old = _dedented_ast_source(source, node)
            if not old:
                continue
            end_line = int(node.end_lineno or node.lineno)
            source_digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
            site_id = "S-" + hashlib.sha256(
                f"{path}:{node.lineno}:{end_line}:function_definition:{source_digest}".encode("utf-8")
            ).hexdigest()[:12]
            sites.setdefault(site_id, RepairSite(
                site_id, path, node.name, node.lineno, old, source_digest,
                None, end_line, "function_definition",
            ))
            definition_site_ids.append(site_id)

        # Module imports are source-owned sites too: a semantically complete
        # repair may need to add a standard-library or framework symbol.
        for path, (source, tree, _, _) in sorted(parsed.items()):
            if path not in selected_paths or len(import_site_ids) >= reserved_import_quota:
                continue
            digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
            import_nodes = [
                node for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom))
            ]
            import_nodes.sort(key=lambda node: (
                -sum(
                    1 for token in _identifier_words(
                        (getattr(node, "module", "") or "") + " " + ast.get_source_segment(source, node)
                    ).casefold().split()
                    if token in issue_text.casefold()
                ),
                node.lineno,
            ))
            for node in import_nodes:
                if len(import_site_ids) >= reserved_import_quota:
                    break
                old = _dedented_ast_source(source, node)
                if not old:
                    continue
                end_line = int(node.end_lineno or node.lineno)
                site_id = "S-" + hashlib.sha256(
                    f"{path}:{node.lineno}:{end_line}:import:{digest}".encode("utf-8")
                ).hexdigest()[:12]
                symbol = getattr(node, "module", None) or ", ".join(alias.name for alias in node.names)
                sites.setdefault(site_id, RepairSite(
                    site_id, path, symbol, node.lineno, old, digest,
                    None, end_line, "import_statement",
                ))
                import_site_ids.append(site_id)

    # Add a bounded, source-owned assignment tail only after executable
    # responsibility sites have been reserved.  It retains support for module
    # settings, class attributes, and regex literals without allowing them to
    # erase the function sites needed for ordinary control-flow fixes.
    assignment_count = 0
    for _, path, symbol, statement, kind, digest in ranked_assignments:
        if assignment_count >= assignment_site_quota:
            break
        source = parsed[path][0]
        end_line = int(statement.end_lineno or statement.lineno)
        old = _dedented_ast_source(source, statement)
        if not old:
            continue
        site_id = "S-" + hashlib.sha256(
            f"{path}:{statement.lineno}:{end_line}:{kind}:{digest}".encode("utf-8")
        ).hexdigest()[:12]
        sites[site_id] = RepairSite(
            site_id, path, symbol, statement.lineno, old,
            digest, None, end_line, kind,
        )
        assignment_count += 1
        lines = source.splitlines()
        excerpt = "\n".join(f"L{line_no}: {lines[line_no - 1]}" for line_no in range(statement.lineno, end_line + 1))
        fragment = f"<!-- cactus-unit:repair path:{path} symbol:{symbol} kind:{kind} lines:{statement.lineno}-{end_line} -->\n{excerpt}"
        if sum(map(len, fragments)) + len(fragment) <= available_budget:
            fragments.append(fragment)
    if len(sites) > max_sites:
        reserved_def_sites = set(definition_site_ids[:reserved_definition_quota])
        reserved_import_sites = set(import_site_ids[:reserved_import_quota])
        keep = set()
        # Priority 1: assignment sites in selected_paths matching quota
        for site_id, site in sites.items():
            if site.path in selected_paths and site.kind in ("class_attribute", "config_value", "regex_literal", "module_assignment"):
                keep.add(site_id)
                if len(keep) >= assignment_site_quota:
                    break
        # Priority 2: function statements in selected_paths
        for site_id, site in sites.items():
            if site.path in selected_paths and site.kind == "function_statement":
                keep.add(site_id)
                if len(keep) >= max_sites - len(reserved_def_sites) - len(reserved_import_sites):
                    break
        # Priority 3: other sites in selected_paths
        for site_id, site in sites.items():
            if site.path in selected_paths and site_id not in keep:
                keep.add(site_id)
                if len(keep) >= max_sites - len(reserved_def_sites) - len(reserved_import_sites):
                    break
        for import_id in reserved_import_sites:
            if len(keep) < max_sites - len(reserved_def_sites):
                keep.add(import_id)
        # Priority 4: reserved definition sites
        for ds_id in reserved_def_sites:
            if len(keep) < max_sites:
                keep.add(ds_id)
        # Priority 4: fill remainder
        for site_id in sites:
            if len(keep) >= max_sites:
                break
            keep.add(site_id)
        sites = {site_id: sites[site_id] for site_id in sites if site_id in keep}
    sites = dict(list(sites.items())[:max_sites])
    if not sites:
        raise ValueError("ranked context has no source-anchored repair sites within the context budget")
    site_items = list(sites.items())
    site_heading = (
        "\n\nAllowed edit-site IDs (choose 1-4):\n"
        if extended else "\n\nAllowed edit-site IDs (choose exactly one):\n"
    )

    def render_context(
        selected_sites: dict[str, RepairSite], excerpt_text: str = "",
    ) -> str:
        site_table = "\n".join(
            f"{site.site_id} | {site.path}:L{site.line}-{site.end_line or site.line} | {site.kind} | {site.symbol} | OLD:\n{site.old_statement}"
            for site in selected_sites.values()
        )
        excerpt_section = (
            "\n\nRanked source excerpts from the inference-safe repository index:\n\n"
            + excerpt_text
            if excerpt_text else ""
        )
        return "Task: " + issue_text.strip() + excerpt_section + site_heading + site_table

    # Select sites in their established relevance order, fitting each complete
    # source statement against the actual rendered prompt. A long compound site
    # must not force shorter, lower-ranked alternatives out of the prompt.
    selected_sites: dict[str, RepairSite] = {}
    for site_id, site in site_items:
        trial_sites = {**selected_sites, site_id: site}
        if len(render_context(trial_sites)) <= max_chars:
            selected_sites[site_id] = site
    if not selected_sites:
        if len(render_context({})) > max_chars:
            raise ValueError("task description exceeds configured repair context character budget")
        raise ValueError("no complete source-anchored repair site fits the configured character budget")

    # Source excerpts add useful neighborhood context, but site IDs and their
    # complete OLD statements are the minimum contract needed for a valid edit.
    # Add excerpts only where the remaining prompt budget permits them.
    selected_fragments: list[str] = []
    for fragment in fragments:
        excerpt_text = "\n\n".join((*selected_fragments, fragment))
        if len(render_context(selected_sites, excerpt_text)) <= max_chars:
            selected_fragments.append(fragment)
    context = render_context(selected_sites, "\n\n".join(selected_fragments))
    return context, selected_sites


def site_edit_to_patch(site: RepairSite, replacement: str, repo_root: Path) -> str:
    """Create one patch against the exact selected snapshot and AST statement line."""
    return site_edit_to_patch_many(((site, replacement),), repo_root)


def _validate_regex_replacement(replacement_tree: ast.Module) -> None:
    strings = [
        node.value
        for node in ast.walk(replacement_tree)
        if isinstance(node, ast.Constant) and isinstance(node.value, str)
    ]
    if not strings:
        raise ValueError("regex replacement must contain a string literal")
    for value in strings:
        try:
            literal = ast.literal_eval(repr(value))
            re.compile(literal)
        except (ValueError, TypeError, re.error) as exc:
            raise ValueError(f"replacement contains an invalid regular expression: {exc}") from exc


def normalize_definition_replacement(site: RepairSite, replacement: str, repo_root: Path) -> str:
    """Keep source-owned decorators outside the def-only replacement span."""
    replacement = textwrap.dedent(replacement.replace("\r\n", "\n").replace("\r", "\n")).strip()
    if site.kind != "function_definition":
        return replacement
    tree = ast.parse(replacement)
    if len(tree.body) != 1 or not isinstance(tree.body[0], (ast.FunctionDef, ast.AsyncFunctionDef)):
        return replacement  # The renderer reports the statement-kind error.
    node = tree.body[0]
    if not node.decorator_list:
        return replacement
    relative = Path(site.path.replace("\\", "/"))
    root = repo_root.resolve()
    source_path = (root / relative).resolve()
    if relative.is_absolute() or ".." in relative.parts or not source_path.is_relative_to(root):
        raise ValueError("repair site path is not a safe Python source path")
    source = source_path.read_text(encoding="utf-8")
    if hashlib.sha256(source.encode("utf-8")).hexdigest() != site.source_sha256:
        raise ValueError("repair site source snapshot drifted")
    targets = [n for n in ast.walk(ast.parse(source))
               if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
               and n.lineno == site.line and n.end_lineno == (site.end_line or site.line)]
    if len(targets) != 1 or [ast.dump(d) for d in node.decorator_list] != [ast.dump(d) for d in targets[0].decorator_list]:
        raise ValueError("replacement decorators differ from source-owned decorators")
    # Function sites begin at def, leaving the original decorators in place.
    return "\n".join(replacement.splitlines()[node.lineno - 1:])


def site_edit_to_patch_many(
    edits: Sequence[tuple[RepairSite, str]],
    repo_root: Path,
) -> str:
    """Generate one atomic patch from 1-4 non-overlapping source-owned sites."""
    if not 1 <= len(edits) <= 4:
        raise ValueError("source-owned edit group must contain 1-4 sites")
    site_ids = [site.site_id for site, _ in edits]
    if len(set(site_ids)) != len(site_ids):
        raise ValueError("source-owned edit group contains duplicate sites")
    root = repo_root.resolve()
    by_path: dict[str, list[tuple[RepairSite, str]]] = {}
    for site, replacement in edits:
        by_path.setdefault(site.path, []).append((site, replacement))
    patches: list[str] = []
    for path in sorted(by_path):
        relative = Path(path.replace("\\", "/"))
        if relative.is_absolute() or ".." in relative.parts or relative.suffix != ".py":
            raise ValueError("repair site path is not a safe Python source path")
        source_path = (root / relative).resolve()
        if not source_path.is_relative_to(root) or not source_path.is_file():
            raise ValueError("repair site source is unavailable")
        raw = source_path.read_bytes().decode("utf-8")
        if "\r\n" in raw and "\n" in raw.replace("\r\n", ""):
            raise ValueError("mixed source line endings")
        crlf = "\r\n" in raw
        source = raw.replace("\r\n", "\n")
        digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
        if any(site.source_sha256 != digest for site, _ in by_path[path]):
            raise ValueError("repair site source snapshot drifted")
        ordered = sorted(by_path[path], key=lambda item: item[0].line)
        for (left, _), (right, _) in zip(ordered, ordered[1:]):
            if (left.end_line or left.line) >= right.line:
                raise ValueError("source-owned edit sites overlap")
        tree = ast.parse(source)
        old_lines = source.splitlines(keepends=True)
        new_lines = list(old_lines)
        for site, replacement in reversed(ordered):
            end_line = site.end_line or site.line
            target_types = (
                ast.Assign, ast.AnnAssign, ast.AugAssign, ast.Return, ast.Raise, ast.Expr,
                ast.For, ast.AsyncFor, ast.While, ast.With, ast.AsyncWith, ast.If, ast.Try,
            )
            if site.kind == "function_definition":
                target_types = (ast.FunctionDef, ast.AsyncFunctionDef)
            elif site.kind == "import_statement":
                target_types = (ast.Import, ast.ImportFrom)
            targets = [node for node in ast.walk(tree) if isinstance(node, target_types) and node.lineno == site.line and node.end_lineno == end_line]
            current = _dedented_ast_source(source, targets[0]) if len(targets) == 1 else None
            if len(targets) != 1 or current is None or not _semantically_equivalent(current, site.old_statement):
                raise ValueError("repair site no longer identifies one AST statement")
            target = targets[0]
            end_line_text = source.splitlines()[end_line - 1]
            if target.end_col_offset is not None and end_line_text.encode("utf-8")[target.end_col_offset:].strip():
                raise ValueError("repair site has a trailing inline comment or code outside the AST statement")
            replacement = normalize_definition_replacement(site, replacement, repo_root)
            if not replacement or "\r" in replacement:
                raise ValueError("replacement must be one complete Python statement")
            try:
                replacement_tree = ast.parse(replacement)
            except SyntaxError as exc:
                raise ValueError(f"replacement is not a complete Python statement: {exc.lineno}") from exc
            if len(replacement_tree.body) != 1:
                raise ValueError("replacement must contain exactly one complete Python statement")
            replacement_node = replacement_tree.body[0]
            # Source-owned assignment sites carry state into later execution.
            # Replacing one with a bare expression (for example a model's
            # placeholder token) is syntactically valid but never a complete
            # repair of that state transition.
            assignment_types = (ast.Assign, ast.AnnAssign, ast.AugAssign)
            if isinstance(target, assignment_types):
                has_assignment = any(isinstance(node, assignment_types) for node in ast.walk(replacement_node))
                is_valid_expr = isinstance(replacement_node, ast.Expr) and isinstance(replacement_node.value, ast.Call)
                if not has_assignment and not is_valid_expr and not isinstance(replacement_node, (ast.If, ast.Try, ast.With)):
                    raise ValueError("replacement must preserve an assignment statement for an assignment repair site")
            if site.kind == "function_definition" and not isinstance(replacement_node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                raise ValueError("replacement must preserve a complete function definition")
            if site.kind == "import_statement" and not isinstance(replacement_node, (ast.Import, ast.ImportFrom)):
                raise ValueError("replacement must preserve a complete import statement")
            if site.kind == "regex_literal":
                _validate_regex_replacement(replacement_tree)
            original = old_lines[site.line - 1]
            indent = original[: len(original) - len(original.lstrip())]
            replacement_lines = [
                indent + line if line.strip() else ""
                for line in replacement.splitlines()
            ]
            final_had_newline = old_lines[end_line - 1].endswith("\n")
            segment = [line + "\n" for line in replacement_lines[:-1]]
            segment.append(replacement_lines[-1] + ("\n" if final_had_newline else ""))
            if segment == old_lines[site.line - 1:end_line] or _semantically_equivalent(site.old_statement, replacement):
                raise ValueError("replacement is identical to source")
            new_lines[site.line - 1:end_line] = segment
        try:
            ast.parse("".join(new_lines))
            compile("".join(new_lines), path, "exec")
        except SyntaxError as exc:
            raise ValueError(f"replacement breaks Python syntax: {exc.lineno}") from exc
        diff = "".join(
            difflib.unified_diff(
                old_lines,
                new_lines,
                fromfile=f"a/{path}",
                tofile=f"b/{path}",
                lineterm="\n",
            )
        )
        if not diff:
            raise ValueError("source-owned edit group produced no changes")
        file_patch = f"diff --git a/{path} b/{path}\n" + diff
        patches.append(file_patch.replace("\n", "\r\n") if crlf else file_patch)
    return "".join(patches)
