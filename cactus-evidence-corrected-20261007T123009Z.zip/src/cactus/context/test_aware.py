"""Extract value-free structural hints from SWE-bench failing tests."""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TestHint:
    test_path: str
    assertion_line: int
    expected_error: str | None
    assertion_kind: str


def _qualified_name(node: ast.AST) -> str | None:
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


def _exception_name(call: ast.Call) -> str | None:
    if not call.args:
        return None
    return _qualified_name(call.args[0])


def extract_test_hints(
    test_source: str,
    test_path: str,
    *,
    test_name: str | None = None,
    class_name: str | None = None,
) -> list[TestHint]:
    """Summarize assertion kinds without exposing test values or expected outputs."""
    try:
        tree = ast.parse(test_source)
    except (SyntaxError, ValueError):
        return []

    nodes: list[ast.AST]
    if test_name:
        normalized_name = test_name.split("[", 1)[0]
        owner_path = tuple(
            part for part in re.split(r"::|\.", class_name or "") if part
        )
        matches: list[ast.AST] = []

        def visit_body(body: list[ast.stmt], owner: tuple[str, ...] = ()) -> None:
            for statement in body:
                if isinstance(statement, ast.ClassDef):
                    visit_body(statement.body, (*owner, statement.name))
                elif isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    owner_matches = not owner_path or owner[-len(owner_path):] == owner_path
                    if statement.name == normalized_name and owner_matches:
                        matches.append(statement)
                    visit_body(statement.body, owner)

        visit_body(tree.body)
        if len(matches) != 1:
            return []
        nodes = list(ast.walk(matches[0]))
    else:
        nodes = list(ast.walk(tree))

    hints: list[TestHint] = []
    seen: set[tuple[int, str, str | None]] = set()

    def add(line: int, kind: str, expected_error: str | None = None) -> None:
        key = (line, kind, expected_error)
        if key not in seen:
            seen.add(key)
            hints.append(TestHint(test_path, line, expected_error, kind))

    for node in nodes:
        if isinstance(node, ast.Assert):
            add(node.lineno, "assert")
            continue
        if not isinstance(node, ast.Call):
            continue
        name = _qualified_name(node.func)
        if not name:
            continue
        leaf = name.rsplit(".", 1)[-1]
        if leaf == "raises" and name in {"pytest.raises", "raises"}:
            add(node.lineno, "pytest.raises", _exception_name(node))
        elif leaf in {"assertRaises", "assertRaisesRegex"}:
            add(node.lineno, "assertRaises", _exception_name(node))
        elif leaf.startswith("assert") and len(leaf) > len("assert"):
            add(node.lineno, leaf)

    return sorted(hints, key=lambda hint: (hint.assertion_line, hint.assertion_kind, hint.expected_error or ""))


def format_test_hints(hints: list[TestHint], max_chars: int = 2000) -> str:
    """Format bounded assertion metadata for model prompts."""
    if max_chars <= 0 or not hints:
        return ""
    lines = ["Test expectations (assertion structure only; test values are withheld):"]
    for hint in hints[:30]:
        path = re.sub(r"[\r\n]", "", hint.test_path)
        if hint.expected_error:
            line = f"- {path}:L{hint.assertion_line} {hint.assertion_kind}({hint.expected_error})"
        else:
            line = f"- {path}:L{hint.assertion_line} {hint.assertion_kind}"
        lines.append(line)
    output = "\n".join(lines)
    return output if len(output) <= max_chars else output[:max_chars].rstrip()
