"""Source-only consumer paths for a rejected repair candidate.

This module deliberately reads only units already selected for the model.  It
does not inspect benchmark tests, gold patches, or files outside that context.
"""

from __future__ import annotations

import ast
from collections.abc import Sequence

from cactus.domain.models import ContextUnit


def build_consumer_chain_context(
    selected_units: Sequence[ContextUnit], *, path: str, symbol: str,
    target_attributes: Sequence[str], issue_text: str, max_chars: int = 12000,
) -> str | None:
    """Show reads, callers, constructed helpers, and possible Axes effects."""
    matches = [unit for unit in selected_units if unit.kind == "file" and unit.path == path]
    if len(matches) != 1 or not target_attributes:
        return None
    source = matches[0].text
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None
    class_name = symbol.split(".")[0]
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    target = classes.get(class_name)
    if target is None:
        return None
    methods = {
        node.name: node for node in target.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    attributes = {item.removeprefix("self.") for item in target_attributes}
    lines: list[str] = [
        f"CONSUMER PATH (selected source only): {path}:{class_name}",
        "Trace the side effect of constructing or reading these values before changing their initial value.",
    ]
    read_methods: set[str] = set()
    for name, method in methods.items():
        for node in ast.walk(method):
            if (isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load)
                    and isinstance(node.value, ast.Name) and node.value.id == "self"
                    and node.attr in attributes):
                read_methods.add(name)
                lines.append(f"- self.{node.attr} read in {class_name}.{name} at line {node.lineno}")
    # Follow method calls up to two hops, with a visited set for recursive methods.
    frontier = set(read_methods)
    visited = set(frontier)
    for _ in range(2):
        callers = set()
        for name, method in methods.items():
            if name in visited:
                continue
            if any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                   and isinstance(node.func.value, ast.Name) and node.func.value.id == "self"
                   and node.func.attr in frontier for node in ast.walk(method)):
                callers.add(name)
                lines.append(f"- {class_name}.{name} calls consumer method in {sorted(frontier)}")
        visited.update(callers)
        frontier = callers
        if not frontier:
            break
    # Constructor calls may cross into another class in the same selected file.
    # In widgets.py SpanSelector._setup_edge_handle creates ToolLineHandles,
    # whose constructor calls axvline/axhline and can request autoscaling.
    related: set[str] = set()
    for name, method in methods.items():
        if name not in visited and name != "__init__":
            continue
        for node in ast.walk(method):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in classes:
                related.add(node.func.id)
                lines.append(f"- {class_name}.{name} constructs {node.func.id} at line {node.lineno}")
    # Include helpers constructed by other methods that read target attributes.
    for name in read_methods:
        for node in ast.walk(methods[name]):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in classes:
                related.add(node.func.id)
                lines.append(f"- {class_name}.{name} constructs {node.func.id} at line {node.lineno}")
    for helper_name in sorted(related):
        axes_aliases: dict[str, list[str]] = {}
        for node in ast.walk(classes[helper_name]):
            if isinstance(node, ast.Assign):
                names = [target.id for target in node.targets if isinstance(target, ast.Name)]
                apis = sorted({child.attr for child in ast.walk(node.value)
                               if isinstance(child, ast.Attribute)
                               and child.attr in {"axvline", "axhline", "set_xlim", "set_ylim", "autoscale_view"}})
                for name in names:
                    if apis:
                        axes_aliases[name] = apis
            if isinstance(node, ast.Call):
                api = node.func.attr if isinstance(node.func, ast.Attribute) else None
                if api in {"axvline", "axhline", "set_xlim", "set_ylim", "autoscale_view"}:
                    snippet = ast.get_source_segment(source, node) or api
                    lines.append(f"- {helper_name} calls {api} at line {node.lineno}: {snippet[:240]}")
                elif isinstance(node.func, ast.Name) and node.func.id in axes_aliases:
                    lines.append(f"- {helper_name} calls {node.func.id} at line {node.lineno}, "
                                 f"bound to Axes API {'/'.join(axes_aliases[node.func.id])}")
    if not read_methods and not related:
        return None
    lines.append("Check both the initial Axes bounds and whether interactive handles still work after the change.")
    result = "\n".join(lines)
    return result[:max_chars] if max_chars > 0 else None
