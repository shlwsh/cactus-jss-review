"""Inference-safe responsibility-chain extraction for repository context."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Sequence

from cactus.domain.models import ContextUnit
from cactus.task.parser import _imported_modules_to_paths


@dataclass(frozen=True, slots=True)
class ResponsibilityTarget:
    unit_id: str
    path: str
    symbol_id: str | None
    reason: str


@dataclass(frozen=True, slots=True)
class ResponsibilityChain:
    primary: tuple[ResponsibilityTarget, ...]
    secondary: tuple[ResponsibilityTarget, ...]
    mentioned_paths: tuple[str, ...]
    mentioned_symbols: tuple[str, ...]
    test_names: tuple[str, ...]
    coverage: float
    exclusions: tuple[dict[str, str], ...]
    fallback: bool


def _identifier_terms(text: str) -> set[str]:
    terms = set(re.findall(r"`([A-Za-z_][A-Za-z0-9_.]*)`", text))
    terms.update(re.findall(r"\b(?:test_[A-Za-z0-9_]+|[A-Za-z_]+\.[A-Za-z_][A-Za-z0-9_.]*|[A-Z][A-Za-z0-9]*[A-Z][A-Za-z0-9]*|[A-Za-z]+_[A-Za-z0-9_]+)\b", text))
    return terms


def analyze_responsibility(
    issue_text: str,
    units: Sequence[ContextUnit],
    *,
    hint_text: str | None = None,
) -> ResponsibilityChain:
    """Map public issue anchors to implementation units without gold data."""
    evidence = issue_text + ("\n" + hint_text if hint_text else "")
    imported_paths, _ = _imported_modules_to_paths(evidence)
    extracted_paths = {
        path.replace("\\", "/").lstrip("./")
        for path in re.findall(r"(?<![\w.-])([A-Za-z0-9_./-]+\.py)\b", evidence)
    }
    mentioned_paths = tuple(sorted(extracted_paths | imported_paths))
    identifiers = _identifier_terms(evidence)
    test_names = tuple(sorted(name for name in identifiers if name.startswith("test_")))
    symbol_terms = {term.split(".")[-1].casefold() for term in identifiers if not term.startswith("test_")}
    qualified_symbols = {term.casefold() for term in identifiers if "." in term and not term.startswith("test_")}
    explicit_settings = any(
        token in evidence.casefold()
        for token in ("setting", "settings", "configuration", "config", "secret_key")
    ) or bool(re.search(r"\b[A-Z][A-Z0-9_]{4,}\b", evidence))
    stem_words = {
        w.casefold()
        for w in re.findall(r"\b[A-Za-z_][A-Za-z0-9_]{2,}\b", evidence)
        if len(w) >= 4
    }
    _common_stem_exclusions = {
        "base", "utils", "util", "common", "helper", "helpers",
        "init", "__init__", "test", "tests", "models", "views",
        "forms", "admin", "core", "compat", "constants", "exceptions",
        "types", "typing", "config", "setup",
    }
    primary: list[ResponsibilityTarget] = []
    secondary: list[ResponsibilityTarget] = []
    exclusions: list[dict[str, str]] = []
    matched_anchors: set[str] = set()
    for unit in units:
        path = unit.path.replace("\\", "/")
        symbol = (unit.symbol_id or "").split(".")[-1]
        path_match = next(
            (anchor for anchor in mentioned_paths if path == anchor or path.endswith("/" + anchor)),
            None,
        )
        qualified_symbol_match = bool(
            unit.symbol_id and unit.symbol_id.casefold() in qualified_symbols
        )
        symbol_match = qualified_symbol_match or bool(symbol and symbol.casefold() in symbol_terms)
        is_test_path = any(part.startswith(("test", "doc")) for part in path.split("/"))
        stem = re.sub(r"\.py$", "", path.split("/")[-1]).casefold()
        stem_match = (
            not is_test_path
            and stem in stem_words
            and stem not in _common_stem_exclusions
        )
        if path_match or symbol_match or stem_match:
            reason_parts: list[str] = []
            if path_match:
                reason_parts.append("explicit_module_path")
                matched_anchors.add(path_match)
            if symbol_match:
                reason_parts.append("explicit_api_or_symbol")
                matched_anchors.add(symbol.casefold())
            if qualified_symbol_match:
                reason_parts.append("explicit_qualified_symbol")
            if stem_match:
                reason_parts.append("explicit_module_stem")
                matched_anchors.add(stem)
            target = ResponsibilityTarget(unit.unit_id, unit.path, unit.symbol_id, "+".join(reason_parts))
            if is_test_path:
                secondary.append(target)
            elif (path_match and symbol_match) or (stem_match and (symbol_match or unit.kind in {"class", "function"})):
                primary.append(target)
            elif path_match and unit.kind in {"class", "function"}:
                primary.append(target)
            elif symbol_match and mentioned_paths:
                secondary.append(target)
            elif symbol_match and unit.kind in {"class", "function"}:
                primary.append(target)
            elif stem_match:
                primary.append(target)
            else:
                secondary.append(target)
        elif explicit_settings and any(part in path.casefold() for part in ("settings", "global_settings", "conf/")):
            secondary.append(ResponsibilityTarget(unit.unit_id, unit.path, unit.symbol_id, "explicit_settings_configuration"))
        elif not explicit_settings and any(part in path.casefold() for part in ("settings", "global_settings")):
            exclusions.append({
                "unit_id": unit.unit_id,
                "path": unit.path,
                "reason": "settings_downranked_not_explicitly_mentioned",
            })
    anchors = set(mentioned_paths) | symbol_terms
    coverage = 0.0 if not anchors else min(1.0, len(matched_anchors & anchors) / len(anchors))
    key = lambda item: (item.path, item.symbol_id or "", item.unit_id)
    return ResponsibilityChain(
        primary=tuple(sorted(primary, key=key)),
        secondary=tuple(sorted(secondary, key=key)),
        mentioned_paths=mentioned_paths,
        mentioned_symbols=tuple(sorted(symbol_terms)),
        test_names=test_names,
        coverage=coverage,
        exclusions=tuple(sorted(exclusions, key=lambda item: (item["path"], item["unit_id"]))),
        fallback=not primary and not secondary,
    )
