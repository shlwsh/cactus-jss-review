"""Reacquire a small, source-derived call path after a rejected statement edit."""

from __future__ import annotations

import ast
import textwrap
from collections import Counter
from collections.abc import Sequence

from cactus.domain.models import ContextUnit


def build_focused_context(
    selected_units: Sequence[ContextUnit],
    *,
    path: str,
    symbol: str,
    old_statement: str,
    issue_text: str,
    max_chars: int = 14000,
) -> str | None:
    """Use only an already-selected full-file unit to show the implicated value flow."""
    files = [unit for unit in selected_units if unit.kind == "file" and unit.path == path]
    if len(files) != 1 or not old_statement.strip():
        return None
    source = files[0].text
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None

    definitions: dict[str, list[ast.FunctionDef | ast.AsyncFunctionDef]] = {}

    def visit_definitions(node: ast.AST, parents: tuple[str, ...] = ()) -> None:
        if isinstance(node, ast.ClassDef):
            for child in node.body:
                visit_definitions(child, (*parents, node.name))
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            definitions.setdefault(".".join((*parents, node.name)), []).append(node)
        elif isinstance(node, ast.Module):
            for child in node.body:
                visit_definitions(child, parents)

    visit_definitions(tree)
    target_matches = definitions.get(symbol, [])
    if len(target_matches) != 1:
        return None
    target = target_matches[0]
    normalized_old = textwrap.dedent(old_statement).strip()
    statements = [
        node for node in ast.walk(target)
        if isinstance(node, ast.stmt)
        and node is not target
        and textwrap.dedent(ast.get_source_segment(source, node) or "").strip() == normalized_old
    ]
    if len(statements) != 1:
        return None
    rejected_statement = statements[0]

    branch_parameter: str | None = None
    branch_node: ast.If | None = None
    for node in ast.walk(target):
        if not isinstance(node, ast.If) or not node.orelse:
            continue
        in_else = any(rejected_statement is child for root in node.orelse for child in ast.walk(root))
        if not in_else:
            continue
        test = node.test
        if (
            isinstance(test, ast.Call)
            and isinstance(test.func, ast.Name)
            and test.func.id == "isinstance"
            and test.args
            and isinstance(test.args[0], ast.Name)
        ):
            branch_parameter = test.args[0].id
            branch_node = node
            break

    dispatch_maps: dict[str, list[str]] = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign) or not isinstance(node.value, ast.Dict):
            continue
        for target_name in node.targets:
            if not isinstance(target_name, ast.Name):
                continue
            for key, value in zip(node.value.keys, node.value.values):
                if isinstance(key, ast.Constant) and isinstance(key.value, str) and isinstance(value, ast.Name) and value.id == target.name:
                    dispatch_maps.setdefault(target_name.id, []).append(key.value)

    callers: list[tuple[int, str, ast.FunctionDef | ast.AsyncFunctionDef, ast.Call, str | None]] = []
    for name, nodes in definitions.items():
        for candidate in nodes:
            if candidate is target:
                continue
            for call in (node for node in ast.walk(candidate) if isinstance(node, ast.Call)):
                if isinstance(call.func, ast.Name) and call.func.id == target.name:
                    callers.append((2, name, candidate, call, None))
                elif isinstance(call.func, ast.Subscript) and isinstance(call.func.value, ast.Name):
                    keys = dispatch_maps.get(call.func.value.id, [])
                    if keys:
                        matched = next((key for key in keys if key in issue_text), keys[0])
                        callers.append((3 if matched in issue_text else 1, name, candidate, call, matched))
    callers.sort(key=lambda item: (-item[0], item[1], item[3].lineno))
    caller = callers[0] if callers else None

    by_short_name = {name: nodes[0] for name, nodes in definitions.items() if len(nodes) == 1 and "." not in name}
    called_names = Counter(
        node.func.id for node in ast.walk(target)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in by_short_name
    )
    callees = [name for name, _ in sorted(called_names.items(), key=lambda item: (-item[1], item[0]))]

    chosen: list[tuple[str, ast.FunctionDef | ast.AsyncFunctionDef]] = []
    if caller:
        chosen.append((caller[1], caller[2]))
    chosen.append((symbol, target))
    for name in callees:
        node = by_short_name[name]
        if node not in (item[1] for item in chosen):
            chosen.append((name, node))
            break

    flow: list[str] = []
    if caller:
        _, caller_name, caller_node, call, dispatch_key = caller
        if dispatch_key is not None:
            flow.append(f"The source dispatch maps {dispatch_key!r} to {symbol}.")
        parameters = [item.arg for item in target.args.args]
        indices = list(range(min(len(parameters), len(call.args))))
        if branch_parameter in parameters:
            indices = [parameters.index(branch_parameter)]
        for index in indices:
            argument = call.args[index]
            if not isinstance(argument, ast.Name):
                continue
            assignment = next(
                (
                    node for node in ast.walk(caller_node)
                    if isinstance(node, ast.Assign)
                    and any(isinstance(name, ast.Name) and name.id == argument.id for name in node.targets)
                ),
                None,
            )
            if assignment is not None:
                statement = ast.get_source_segment(source, assignment)
                if statement:
                    flow.append(f"In {caller_name}, `{statement.strip()}` supplies parameter `{parameters[index]}` to {symbol}.")
    if branch_parameter:
        flow.append(
            f"The rejected statement is in the else branch of `isinstance({branch_parameter}, ...)` in {symbol}. "
            "Trace whether that branch preserves the incoming computed value."
        )
        if branch_node is not None:
            for node in ast.walk(ast.Module(body=branch_node.orelse, type_ignores=[])):
                if not isinstance(node, ast.Assign) or not isinstance(node.value, ast.Constant):
                    continue
                if not isinstance(node.value.value, (bool, int, float, str, type(None))):
                    continue
                for assigned_target in node.targets:
                    if not isinstance(assigned_target, ast.Subscript):
                        continue
                    root = assigned_target.value
                    while isinstance(root, ast.Subscript):
                        root = root.value
                    if not isinstance(root, ast.Name):
                        continue
                    statement = ast.get_source_segment(source, node)
                    if statement:
                        flow.append(
                            f"This branch fills part of `{root.id}` with a scalar constant in `{statement.strip()}`. "
                            f"Check whether that intentionally replaces data or should preserve values from `{branch_parameter}`; "
                            "changing the branch condition alone would not restore discarded values."
                        )
                    break

    chunks = [f"Task: {issue_text.strip()}", "Selected source subset (all excerpts come from a previously selected file):"]
    for name, node in chosen:
        excerpt = ast.get_source_segment(source, node)
        if not excerpt:
            return None
        chunks.append(
            f"<!-- cactus-unit:focus-{name} path:{path} lines:{node.lineno}-{node.end_lineno} kind:function -->\n{excerpt}"
        )
    if flow:
        chunks.append("Source-derived value flow:\n" + "\n".join(f"- {item}" for item in flow))
    result = "\n\n".join(chunks)
    return result if len(result) <= max_chars else None
