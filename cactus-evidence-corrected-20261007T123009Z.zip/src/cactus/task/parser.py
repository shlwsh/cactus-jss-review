"""Rule-based parser for SWE-bench-like task descriptions."""

from __future__ import annotations

import re
from collections.abc import Mapping

from cactus.task.schema import TaskIntent

_FILE_RE = re.compile(r"(?<![\w/])(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+(?:\.[A-Za-z0-9_]+)?|\b[A-Za-z0-9_.-]+\.py\b")
_SYMBOL_RE = re.compile(r"\b(?:[A-Za-z_]\w*\.)*[A-Za-z_]\w*\s*\(")
_IMPORT_PATH_RE = re.compile(
    r"(?m)^[ \t]*(?:from\s+|import\s+)"
    r"([A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)+)"
    r"(?=\s+(?:import\b|as\b)|\s*,|\s*$)"
)
_FROM_IMPORT_SYMBOL_RE = re.compile(
    r"\bfrom\s+[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)*\s+import\s+([^\n]+)"
)
_TRACE_RE = re.compile(r"(?:File \"([^\"]+)\", line \d+).*?in ([A-Za-z_]\w*)", re.S)
_TEST_RE = re.compile(r"\b(?:test_[A-Za-z0-9_]+|[A-Za-z_]\w*Test[A-Za-z_]\w*)\b")
_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]{2,}")
_STOP = {"the", "and", "that", "this", "with", "from", "into", "when", "should", "could", "would", "have", "has", "for", "not", "are", "was", "issue", "please"}


def _ordered(values: set[str]) -> tuple[str, ...]:
    return tuple(sorted(values, key=lambda value: (value.casefold(), value)))


def _imported_modules_to_paths(query: str) -> tuple[set[str], set[str]]:
    """Translate ``from a.b.c import x`` and ``import a.b.c`` forms into
    repository-relative ``.py`` paths.

    Returns two sets:
      1. explicit_paths: exact module paths (e.g. astropy/timeseries/__init__.py)
      2. module_prefixes: module directory prefixes (e.g. astropy/timeseries/)
         These are used by the engine to expand to all files in the module.

    SWE-bench issues overwhelmingly reference target files via Python import
    statements (``from astropy.modeling.separable import ...``).  The original
    ``_FILE_RE`` only recognises paths that contain a ``/`` or end in ``.py``,
    so dotted module names slipped through and the mentioned-file priority was
    effectively dead.  This helper keeps that heuristic local to the parser
    and converts ``a.b.c`` into ``a/b/c.py`` without altering ``_FILE_RE``.

    For class-based issues, the bug often lives in a sibling module of the
    imported class (e.g. ``from astropy.timeseries import TimeSeries`` where
    the bug is in ``astropy/timeseries/core.py``).  Returning module prefixes
    allows the engine to expand to all files in the same module directory.
    """

    paths: set[str] = set()
    module_prefixes: set[str] = set()
    for match in _IMPORT_PATH_RE.finditer(query):
        module = match.group(1)
        if not module or module.startswith("."):
            continue
        top = module.split(".", 1)[0]
        if top in {"__future__"}:
            continue
        # Exact module path: e.g. astropy/timeseries/__init__.py
        module_path = module.replace(".", "/")
        paths.add(module_path + ".py")
        # Module directory prefix for expansion: e.g. astropy/timeseries/
        module_prefixes.add(module_path + "/")
    return paths, module_prefixes


def parse_task(task: Mapping[str, object] | str, *, instance_id: str = "", repo: str = "", base_commit: str = "") -> TaskIntent:
    if isinstance(task, Mapping):
        query = str(task.get("problem_statement", task.get("query_text", "")))
        instance_id = str(task.get("instance_id", instance_id))
        repo = str(task.get("repo", repo))
        base_commit = str(task.get("base_commit", base_commit))
    else:
        query = str(task)
    files = set(_FILE_RE.findall(query))
    imported_paths, module_prefixes = _imported_modules_to_paths(query)
    files.update(imported_paths)
    symbols = {match[:-1].strip() for match in _SYMBOL_RE.findall(query)}
    for match in _FROM_IMPORT_SYMBOL_RE.finditer(query):
        for imported in match.group(1).split(","):
            name = imported.strip().split(" as ", 1)[0].strip()
            if re.fullmatch(r"[A-Za-z_]\w*", name) and name != "*":
                symbols.add(name)
    # Keep qualified method calls shown in fenced reproducers.  They are
    # useful localization anchors even when the surrounding code is not prose.
    symbols.update(
        match.group(0)
        for match in re.finditer(r"\b(?:[A-Za-z_]\w*\.)+[A-Za-z_]\w*(?=\s*\()", query)
    )
    tests = set(_TEST_RE.findall(query))
    for file_name, symbol in _TRACE_RE.findall(query):
        files.add(file_name.replace("\\", "/"))
        symbols.add(symbol)
    modules = {value[:-3] for value in files if value.endswith(".py")}
    keywords = {word.lower() for word in _WORD_RE.findall(query) if word.lower() not in _STOP}
    return TaskIntent(instance_id, repo, base_commit, query, _ordered(files), _ordered(symbols), _ordered(modules), _ordered(tests), _ordered(keywords), _ordered(module_prefixes))
