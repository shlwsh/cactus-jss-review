"""Task intent value object used by the CACTUS retrieval pipeline."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TaskIntent:
    instance_id: str
    repo: str
    base_commit: str
    query_text: str
    mentioned_files: tuple[str, ...] = ()
    mentioned_symbols: tuple[str, ...] = ()
    mentioned_modules: tuple[str, ...] = ()
    mentioned_tests: tuple[str, ...] = ()
    keywords: tuple[str, ...] = ()
    # Module directory prefixes for import-chain expansion (e.g. "astropy/timeseries/")
    # These allow the engine to include ALL files in a module directory,
    # not just the one directly imported. Critical for parent-class propagation.
    module_prefixes: tuple[str, ...] = ()
