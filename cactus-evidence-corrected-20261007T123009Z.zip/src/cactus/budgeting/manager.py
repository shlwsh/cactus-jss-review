"""Model-aware code context budgeting and breakdown.

Implements Phase 5 (TASK-007) & Section 12 of CACTUS Rectification Plan v2.
Formula:
B_code = B_model - T_system - T_task - T_tools - T_history - T_output_reserve - T_safety
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class BudgetBreakdown:
    model_window: int
    system_tokens: int
    task_tokens: int
    tool_schema_tokens: int
    history_tokens: int
    output_reserve_tokens: int
    safety_margin_tokens: int
    code_budget_tokens: int


class TokenCounter(Protocol):
    def count(self, text: str) -> int:
        ...


class ApproxTokenCounter:
    """Fast deterministic token counter based on characters-per-token ratio."""

    def __init__(self, chars_per_token: float = 3.8) -> None:
        self.chars_per_token = max(1.0, chars_per_token)

    def count(self, text: str) -> int:
        if not text:
            return 0
        return max(1, int(len(text) / self.chars_per_token))


class BudgetManager:
    """Manages model context allocations and isolates pure code budget B_code."""

    def __init__(
        self,
        *,
        model_window: int = 32768,
        default_output_reserve: int = 4096,
        default_safety_margin: int = 1024,
        counter: TokenCounter | None = None,
    ) -> None:
        self.model_window = model_window
        self.default_output_reserve = default_output_reserve
        self.default_safety_margin = default_safety_margin
        self.counter = counter or ApproxTokenCounter()

    def compute_breakdown(
        self,
        *,
        system_prompt: str = "",
        task_prompt: str = "",
        tool_schemas: str = "",
        history_text: str = "",
        output_reserve: int | None = None,
        safety_margin: int | None = None,
    ) -> BudgetBreakdown:
        reserve = output_reserve if output_reserve is not None else self.default_output_reserve
        safety = safety_margin if safety_margin is not None else self.default_safety_margin

        t_sys = self.counter.count(system_prompt)
        t_task = self.counter.count(task_prompt)
        t_tools = self.counter.count(tool_schemas)
        t_hist = self.counter.count(history_text)

        fixed_overhead = t_sys + t_task + t_tools + t_hist + reserve + safety
        b_code = max(0, self.model_window - fixed_overhead)

        return BudgetBreakdown(
            model_window=self.model_window,
            system_tokens=t_sys,
            task_tokens=t_task,
            tool_schema_tokens=t_tools,
            history_tokens=t_hist,
            output_reserve_tokens=reserve,
            safety_margin_tokens=safety,
            code_budget_tokens=b_code,
        )

    @staticmethod
    def calculate_budget_error(estimated: int, actual: int) -> float:
        """Calculate relative budget prediction error |T_est - T_act| / max(1, T_act)."""
        return abs(estimated - actual) / max(1.0, float(actual))
