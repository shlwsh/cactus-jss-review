"""Fail-closed token reservation performed before provider calls."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class TokenPolicy:
    per_task_soft_limit: int
    per_task_hard_limit: int
    per_call_min_reserve: int
    estimator_safety_factor: float
    campaign_tokens_remaining: int | None = None

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "TokenPolicy":
        required = (
            "per_task_soft_limit",
            "per_task_hard_limit",
            "per_call_min_reserve",
            "estimator_safety_factor",
        )
        missing = [field for field in required if field not in value]
        if missing:
            raise ValueError("token policy missing fields: " + ", ".join(missing))
        policy = cls(
            per_task_soft_limit=int(value["per_task_soft_limit"]),
            per_task_hard_limit=int(value["per_task_hard_limit"]),
            per_call_min_reserve=int(value["per_call_min_reserve"]),
            estimator_safety_factor=float(value["estimator_safety_factor"]),
            campaign_tokens_remaining=(
                None
                if value.get("campaign_tokens_remaining") is None
                else int(value["campaign_tokens_remaining"])
            ),
        )
        policy.validate()
        return policy

    def validate(self) -> None:
        if self.per_task_soft_limit < 1:
            raise ValueError("per_task_soft_limit must be positive")
        if self.per_task_hard_limit < self.per_task_soft_limit:
            raise ValueError("per_task_hard_limit must be at least per_task_soft_limit")
        if self.per_call_min_reserve < 1:
            raise ValueError("per_call_min_reserve must be positive")
        if not math.isfinite(self.estimator_safety_factor) or self.estimator_safety_factor < 1.0:
            raise ValueError("estimator_safety_factor must be finite and at least 1.0")
        if self.campaign_tokens_remaining is not None and self.campaign_tokens_remaining < 0:
            raise ValueError("campaign_tokens_remaining cannot be negative")


@dataclass(frozen=True, slots=True)
class TokenReservation:
    estimated_input_tokens: int
    requested_output_tokens: int
    reserved_tokens: int
    task_tokens_used: int
    task_tokens_remaining: int
    campaign_tokens_remaining: int | None


def estimate_prompt_tokens(prompt: str) -> int:
    """Return a deterministic conservative approximation without a tokenizer."""
    return max(1, math.ceil(len(prompt.encode("utf-8")) / 4))


def reserve_tokens(
    policy: TokenPolicy,
    *,
    prompt: str,
    max_output_tokens: int | None,
    task_tokens_used: int,
) -> TokenReservation:
    """Reserve capacity before a call or raise a stable fail-closed error."""
    if task_tokens_used < 0:
        raise ValueError("task_tokens_used cannot be negative")
    estimated_input = estimate_prompt_tokens(prompt)
    requested_output = max(0, int(max_output_tokens or 0))
    estimated = math.ceil(
        (estimated_input + requested_output) * policy.estimator_safety_factor
    )
    reserved = max(policy.per_call_min_reserve, estimated)
    task_remaining = max(0, policy.per_task_hard_limit - task_tokens_used)
    if reserved > task_remaining:
        raise RuntimeError(
            "token_reservation_rejected: per_task_hard_limit insufficient "
            f"(required={reserved}, remaining={task_remaining})"
        )
    campaign_remaining = (
        None
        if policy.campaign_tokens_remaining is None
        else max(0, policy.campaign_tokens_remaining - task_tokens_used)
    )
    if campaign_remaining is not None and reserved > campaign_remaining:
        raise RuntimeError(
            "token_reservation_rejected: campaign token budget insufficient "
            f"(required={reserved}, remaining={campaign_remaining})"
        )
    return TokenReservation(
        estimated_input_tokens=estimated_input,
        requested_output_tokens=requested_output,
        reserved_tokens=reserved,
        task_tokens_used=task_tokens_used,
        task_tokens_remaining=task_remaining,
        campaign_tokens_remaining=campaign_remaining,
    )
