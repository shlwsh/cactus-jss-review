"""Deterministic lightweight repository index for Python fixtures."""

from __future__ import annotations

import ast
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

from cactus.domain.models import ContextUnit, DependencyEdge
from cactus.units.generator import generate_units


@dataclass(frozen=True, slots=True)
class RepoIndex:
    root: str
    units: tuple[ContextUnit, ...]
    edges: tuple[DependencyEdge, ...]
    parse_failures: tuple[str, ...] = ()
    files: tuple[dict[str, object], ...] = ()
    index_hash: str = ""


def build_index(root: Path) -> RepoIndex:
    import pickle
    import subprocess
    cache_path = root / ".cactus_index_cache.pkl"
    commit_cache_path = None
    try:
        res = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, timeout=5)
        if res.returncode == 0 and res.stdout.strip():
            commit = res.stdout.strip()
            cache_dir = Path("E:/cactus-data/lite50/index_cache")
            cache_dir.mkdir(parents=True, exist_ok=True)
            commit_cache_path = cache_dir / f"{commit}.pkl"
    except Exception:
        pass

    for cp in (commit_cache_path, cache_path):
        if cp is not None and cp.exists():
            try:
                with cp.open("rb") as f:
                    cached = pickle.load(f)
                if isinstance(cached, RepoIndex):
                    return cached
            except Exception:
                pass
    units = generate_units(root)
    unit_by_symbol = {(unit.path, unit.symbol_id): unit.unit_id for unit in units if unit.symbol_id}
    short_symbol_ids: dict[tuple[str, str], set[str]] = {}
    for unit in units:
        if not unit.symbol_id:
            continue
        short_symbol_ids.setdefault((unit.path, unit.symbol_id.rsplit(".", 1)[-1]), set()).add(unit.unit_id)
    # AST dependency extraction sees method names without class qualifiers.
    # Retain graph links for unambiguous short names while preserving qualified
    # IDs for overloaded methods in the same file.
    for key, ids in short_symbol_ids.items():
        if len(ids) == 1:
            unit_by_symbol.setdefault(key, next(iter(ids)))
    edges: list[DependencyEdge] = []
    failures: list[str] = []
    files: list[dict[str, object]] = []
    for path in sorted(root.rglob("*.py")):
        relative = path.relative_to(root).as_posix()
        try:
            raw = path.read_bytes()
            text = raw.decode("utf-8")
            files.append({"path": relative, "language": "python", "token_count": len(text.split()), "line_count": len(text.splitlines()), "sha256": hashlib.sha256(raw).hexdigest(), "is_test": path.name.startswith("test_") or "/tests/" in f"/{relative}"})
        except (OSError, UnicodeDecodeError):
            failures.append(relative)
            continue
        try:
            tree = ast.parse(text, filename=relative)
        except (OSError, UnicodeDecodeError, SyntaxError):
            failures.append(relative)
            continue
        source_id = f"file:{relative}"
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    edges.append(DependencyEdge(source_id, f"module:{alias.name}", "IMPORTS"))
            elif isinstance(node, ast.ImportFrom) and node.module:
                edges.append(DependencyEdge(source_id, f"module:{node.module}", "IMPORTS"))
            elif isinstance(node, ast.ClassDef):
                class_id = unit_by_symbol.get((relative, node.name), f"symbol:{node.name}")
                for base in node.bases:
                    if isinstance(base, ast.Name):
                        edges.append(DependencyEdge(class_id, f"symbol:{base.id}", "EXTENDS"))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                source_symbol = unit_by_symbol.get((relative, node.name), f"symbol:{node.name}")
                relation = "TESTS" if node.name.startswith("test") else "CALLS"
                for child in ast.walk(node):
                    if isinstance(child, ast.Call):
                        target = child.func.id if isinstance(child.func, ast.Name) else child.func.attr if isinstance(child.func, ast.Attribute) else None
                        if target:
                            edges.append(DependencyEdge(source_symbol, f"symbol:{target}", relation))
    index_payload = json.dumps({"files": files, "units": [unit.to_dict() for unit in units], "edges": [edge.__dict__ if hasattr(edge, "__dict__") else {"source_id": edge.source_id, "target_id": edge.target_id, "relation": edge.relation, "confidence": edge.confidence} for edge in edges]}, sort_keys=True, separators=(",", ":"))
    result_index = RepoIndex(root.as_posix(), tuple(units), tuple(edges), tuple(sorted(set(failures))), tuple(files), hashlib.sha256(index_payload.encode("utf-8")).hexdigest())
    for cp in (commit_cache_path, cache_path):
        if cp is not None:
            try:
                with cp.open("wb") as f:
                    pickle.dump(result_index, f, protocol=pickle.HIGHEST_PROTOCOL)
            except Exception:
                pass
    return result_index
