"""Repository snapshot and dependency representation."""

from .index import RepoIndex, build_index

__all__ = ["RepoIndex", "build_index"]
