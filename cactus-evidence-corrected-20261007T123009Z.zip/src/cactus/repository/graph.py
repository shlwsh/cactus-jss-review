"""Typed dependency graph traversal with relation-aware edge weights.

Implements Phase 4 (TASK-006) & Section 8 of CACTUS Rectification Plan v2.
Rules:
1. Edge types: TEST_TARGET, CALL, SYMBOL_REFERENCE, INHERIT, IMPORT.
2. Graph score: G(c) = max_{p: s -> c} prod_{e in p} omega_{type(e)} with max_depth=2.
3. Full provenance audit: records path edges, hop counts, and cumulative scores.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Iterable
from dataclasses import dataclass
from enum import StrEnum

from cactus.domain.models import DependencyEdge


class EdgeType(StrEnum):
    TEST_TARGET = "test_target"
    CALL = "call"
    SYMBOL_REFERENCE = "symbol_reference"
    INHERIT = "inherit"
    IMPORT = "import"


DEFAULT_EDGE_WEIGHTS: dict[EdgeType, float] = {
    EdgeType.TEST_TARGET: 1.00,
    EdgeType.CALL: 0.85,
    EdgeType.SYMBOL_REFERENCE: 0.80,
    EdgeType.INHERIT: 0.75,
    EdgeType.IMPORT: 0.60,
}


def parse_edge_type(relation: str) -> EdgeType:
    clean = relation.lower().replace("-", "_").strip()
    if "test" in clean:
        return EdgeType.TEST_TARGET
    if "call" in clean:
        return EdgeType.CALL
    if "inherit" in clean or "subclass" in clean:
        return EdgeType.INHERIT
    if "import" in clean:
        return EdgeType.IMPORT
    return EdgeType.SYMBOL_REFERENCE


@dataclass(frozen=True, slots=True)
class GraphPathAudit:
    seed_unit_id: str
    target_unit_id: str
    path_edges: tuple[str, ...]
    hop_count: int
    graph_score: float


class DependencyGraph:
    def __init__(
        self,
        edges: Iterable[DependencyEdge],
        edge_weights: dict[EdgeType, float] | None = None,
    ) -> None:
        self.weights = dict(DEFAULT_EDGE_WEIGHTS)
        if edge_weights:
            self.weights.update(edge_weights)

        self._adj: dict[str, list[tuple[str, EdgeType, float]]] = {}
        for edge in edges:
            etype = parse_edge_type(edge.relation)
            w = self.weights.get(etype, 0.50) * edge.confidence
            self._adj.setdefault(edge.source_id, []).append((edge.target_id, etype, w))

    def distances_from(self, source_id: str, *, max_depth: int = 32) -> dict[str, int]:
        """Backward-compatible unweighted hop distance."""
        if max_depth < 0:
            raise ValueError("max_depth must be non-negative")
        distances = {source_id: 0}
        queue = deque([source_id])
        while queue:
            current = queue.popleft()
            if distances[current] >= max_depth:
                continue
            for target, _, _ in sorted(self._adj.get(current, []), key=lambda item: item[0]):
                if target not in distances:
                    distances[target] = distances[current] + 1
                    queue.append(target)
        return distances

    def typed_scores_from(
        self,
        source_id: str,
        *,
        max_hops: int = 2,
    ) -> dict[str, GraphPathAudit]:
        """Compute maximum multiplicative path score within max_hops (Section 8.3)."""
        if max_hops < 1:
            raise ValueError("max_hops must be at least 1")

        # maps target_id -> GraphPathAudit
        best: dict[str, GraphPathAudit] = {
            source_id: GraphPathAudit(source_id, source_id, (), 0, 1.0)
        }
        # queue elements: (current_id, current_score, current_hops, path_edges)
        queue: deque[tuple[str, float, int, tuple[str, ...]]] = deque([(source_id, 1.0, 0, ())])

        while queue:
            curr_id, curr_score, curr_hops, curr_path = queue.popleft()
            if curr_hops >= max_hops:
                continue

            for target, etype, weight in sorted(self._adj.get(curr_id, []), key=lambda item: (-item[2], item[0])):
                cand_score = curr_score * weight
                cand_hops = curr_hops + 1
                cand_path = curr_path + (etype.value,)

                # If found higher score path, or equal score with fewer hops
                existing = best.get(target)
                if existing is None or cand_score > existing.graph_score:
                    audit = GraphPathAudit(source_id, target, cand_path, cand_hops, cand_score)
                    best[target] = audit
                    queue.append((target, cand_score, cand_hops, cand_path))

        return best
