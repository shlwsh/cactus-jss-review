"""Deterministic value model for reacquiring evicted context.

The model implements V' = V + eta * P(reacquire) * C, where C is the
estimated reacquisition cost in tokens. It is intentionally provider-agnostic
so offline replay can use the same calculation as a live runner.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ReacquisitionEstimate:
    base_value: float
    probability: float
    cost_tokens: int
    eta: float
    adjusted_value: float


def estimate_reacquisition(
    base_value: float,
    probability: float,
    cost_tokens: int,
    eta: float = 1.0,
) -> ReacquisitionEstimate:
    """Return an auditable adjusted value without mutating source scores."""
    if not 0.0 <= probability <= 1.0:
        raise ValueError("probability must be in [0, 1]")
    if cost_tokens < 0:
        raise ValueError("cost_tokens must be non-negative")
    if eta < 0.0:
        raise ValueError("eta must be non-negative")
    adjusted = base_value + eta * probability * cost_tokens
    return ReacquisitionEstimate(base_value, probability, cost_tokens, eta, adjusted)
