"""Retrieval layer diagnostic metrics for post-hoc evaluation.

Implements Phase 6 (TASK-009) & Section 17 of CACTUS Rectification Plan v2.
Note: Ground-truth patch information is ONLY used for post-hoc diagnostic evaluation,
NEVER fed into candidate selection.
"""

from __future__ import annotations

from collections.abc import Set


def compute_file_recall(selected_files: Set[str], gold_files: Set[str]) -> float:
    """FileRecall = |SelectedFiles ∩ GoldFiles| / |GoldFiles|."""
    if not gold_files:
        return 1.0
    return len(selected_files & gold_files) / float(len(gold_files))


def compute_file_precision(selected_files: Set[str], gold_files: Set[str]) -> float:
    """FilePrecision = |SelectedFiles ∩ GoldFiles| / |SelectedFiles|."""
    if not selected_files:
        return 0.0
    return len(selected_files & gold_files) / float(len(selected_files))


def compute_symbol_recall(selected_symbols: Set[str], gold_symbols: Set[str]) -> float:
    """SymbolRecall = |SelectedSymbols ∩ GoldSymbols| / |GoldSymbols|."""
    if not gold_symbols:
        return 1.0
    return len(selected_symbols & gold_symbols) / float(len(gold_symbols))


def compute_edit_line_coverage(selected_lines: Set[tuple[str, int]], gold_lines: Set[tuple[str, int]]) -> float:
    """EditLineCoverage = |SelectedLines ∩ GoldEditedLines| / |GoldEditedLines|."""
    if not gold_lines:
        return 1.0
    return len(selected_lines & gold_lines) / float(len(gold_lines))


def compute_context_compression_ratio(selected_tokens: int, maximal_tokens: int) -> float:
    """SCR = SelectedContextTokens / MaximalContextTokens."""
    if maximal_tokens <= 0:
        return 1.0
    return selected_tokens / float(maximal_tokens)
