"""Adaptive candidate pool sizing based on model code budget and repository statistics.

Implements Phase 4 (TASK-006) & Section 10 of CACTUS Rectification Plan v2.
Replaces the static Top-1024 truncation with a budget-adaptive candidate pool.
Rules:
1. Formula: K = min(K_max, max(K_min, rho * (B_code / median_token_count)))
2. Frozen defaults: K_min = 256, K_max = 4096, rho = 8.
3. Unprunable units: ACE MANDATORY, exact file matches, exact symbol matches, test targets.
"""

from __future__ import annotations

import statistics
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from cactus.domain.models import ContextUnit


@dataclass(frozen=True, slots=True)
class CandidatePoolConfig:
    k_min: int = 256
    k_max: int = 4096
    rho: int = 8


DEFAULT_POOL_CONFIG = CandidatePoolConfig()


def calculate_pool_size(
    units: Sequence[ContextUnit],
    code_budget: int,
    config: CandidatePoolConfig = DEFAULT_POOL_CONFIG,
) -> int:
    """Compute adaptive K based on code budget and candidate token distribution."""
    if not units or code_budget <= 0:
        return config.k_min

    token_counts = [max(1, u.token_count) for u in units]
    median_tokens = float(statistics.median(token_counts)) or 64.0

    raw_k = int(config.rho * (code_budget / median_tokens))
    return min(config.k_max, max(config.k_min, raw_k))


def prune_candidate_pool(
    units: Sequence[ContextUnit],
    scores: Mapping[str, float],
    code_budget: int,
    *,
    mandatory_unit_ids: set[str] | frozenset[str] = frozenset(),
    config: CandidatePoolConfig = DEFAULT_POOL_CONFIG,
) -> tuple[ContextUnit, ...]:
    """Select the top K candidates while unconditionally preserving all mandatory units."""
    if len(units) <= config.k_min:
        return tuple(units)

    k = calculate_pool_size(units, code_budget, config)
    if len(units) <= k:
        return tuple(units)

    by_id = {u.unit_id: u for u in units}

    # Rank units by score density (relevance per token) with deterministic tie-breaking
    ranked_ids = sorted(
        by_id.keys(),
        key=lambda uid: (
            -scores.get(uid, 0.0) / max(1, by_id[uid].token_count),
            -scores.get(uid, 0.0),
            by_id[uid].path,
            by_id[uid].start_line or -1,
            uid,
        ),
    )

    selected_ids = set(ranked_ids[:k]) | set(mandatory_unit_ids)
    return tuple(u for u in units if u.unit_id in selected_ids)
