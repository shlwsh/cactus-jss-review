"""Deterministic code-aware retrieval components."""

from cactus.retrieval.lexical import lexical_candidates
from cactus.retrieval.scoring import score_candidates
from cactus.retrieval.dedup import deduplicate

__all__ = ["deduplicate", "lexical_candidates", "score_candidates"]
