"""Dependency-free lexical retrieval with deterministic BM25-like scoring."""

from __future__ import annotations

import math
import re
from collections.abc import Iterable, Mapping

from cactus.domain.models import ContextUnit
from cactus.task.schema import TaskIntent


def _tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z_][A-Za-z0-9_]+", text.casefold())


def lexical_candidates(units: Iterable[ContextUnit], intent: TaskIntent, *, limit: int | None = None) -> list[tuple[str, float]]:
    items = list(units)
    query = set(intent.keywords) | {x.casefold() for x in intent.mentioned_symbols + intent.mentioned_modules + intent.mentioned_files}
    documents = {unit.unit_id: set(_tokens(f"{unit.path} {unit.symbol_id or ''} {unit.text}")) for unit in items}
    document_frequency: dict[str, int] = {}
    for terms in documents.values():
        for term in terms:
            document_frequency[term] = document_frequency.get(term, 0) + 1
    avgdl = sum(len(tokens) for tokens in documents.values()) / max(1, len(documents))
    scores: list[tuple[str, float]] = []
    for unit in items:
        terms = documents[unit.unit_id]
        score = 0.0
        for term in query:
            if term not in terms:
                continue
            df = document_frequency.get(term, 0)
            idf = math.log(1.0 + (len(items) - df + 0.5) / (df + 0.5))
            score += idf * (2.2 / (1.2 * (len(terms) / max(1.0, avgdl)) + 1.0))
        if unit.path in intent.mentioned_files or unit.symbol_id in intent.mentioned_symbols:
            score += 2.0
        scores.append((unit.unit_id, score))
    scores.sort(key=lambda item: (-item[1], item[0]))
    return scores if limit is None else scores[:limit]
