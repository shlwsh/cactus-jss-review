"""Structural coverage and redundancy primitives for the v2.1 selector."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence

from cactus.domain.models import ContextUnit


def coverage_keys(unit: ContextUnit) -> frozenset[str]:
    """Return stable structural features covered by a context unit."""

    keys = {f"file:{unit.path}"}
    if unit.symbol_id:
        keys.add(f"symbol:{unit.symbol_id}")
    if unit.kind in {"test", "test_function"} or unit.path.startswith("tests/"):
        keys.add(f"test:{unit.path}:{unit.symbol_id or unit.unit_id}")
    extra = unit.provenance.get("coverage_keys", ())
    if isinstance(extra, str):
        keys.add(extra)
    elif isinstance(extra, Iterable):
        keys.update(str(value) for value in extra)
    return frozenset(keys)


def compute_coverage_gain(candidate: ContextUnit, selected: set[str]) -> float:
    """Measure the fraction of a candidate's structure not covered by ``selected``.

    ``selected`` is a set of coverage keys rather than unit IDs. This keeps the
    primitive independent of a repository index and makes the calculation
    auditable in isolation.
    """

    keys = coverage_keys(candidate)
    if not keys:
        return 0.0
    return len(keys - selected) / len(keys)


def _line_overlap(left: ContextUnit, right: ContextUnit) -> float:
    if left.path != right.path or left.start_line is None or left.end_line is None or right.start_line is None or right.end_line is None:
        return 0.0
    overlap = max(0, min(left.end_line, right.end_line) - max(left.start_line, right.start_line) + 1)
    span = max(left.end_line - left.start_line + 1, right.end_line - right.start_line + 1)
    return overlap / max(1, span)


def compute_redundancy(candidate: ContextUnit, selected: set[str], selected_units: Sequence[ContextUnit] = ()) -> float:
    """Return a bounded redundancy penalty for selected IDs/units."""

    if candidate.unit_id in selected:
        return 1.0
    if not selected_units:
        return 0.0
    overlaps = [_line_overlap(candidate, unit) for unit in selected_units if unit.unit_id in selected]
    same_symbol = any(candidate.symbol_id and candidate.symbol_id == unit.symbol_id for unit in selected_units if unit.unit_id in selected)
    return min(1.0, max(overlaps or [0.0]) * 0.7 + (0.3 if same_symbol else 0.0))


def compute_fragmentation(candidate: ContextUnit, *, min_chunk_tokens: int = 64) -> float:
    """Penalize undersized or intrinsically fragmented candidates."""

    if min_chunk_tokens < 1:
        raise ValueError("min_chunk_tokens must be positive")
    size_penalty = max(0.0, min(1.0, (min_chunk_tokens - candidate.token_count) / min_chunk_tokens))
    kind_penalty = 0.15 if candidate.kind in {"line", "fragment", "delta"} else 0.0
    return min(1.0, size_penalty + kind_penalty)


def new_file_key(unit: ContextUnit) -> str:
    return f"file:{unit.path}"
