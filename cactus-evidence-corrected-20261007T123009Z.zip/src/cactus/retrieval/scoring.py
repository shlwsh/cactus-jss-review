"""Fixed-weight, explainable static candidate relevance scoring R(c).

Implements Phase 3 (TASK-005) & Section 7 of CACTUS Rectification Plan v2.
Rules:
1. Pure static relevance: removes 'redundancy' from static scoring to eliminate double penalties.
2. Normalized 5-dimension weights: lexical (0.30), symbol (0.25), graph (0.20), test (0.10), path (0.10).
3. Deterministic tie-breaking: (-score, path, start_line, symbol_id, unit_id).
4. ScoringMode.STATIC_REPRODUCIBLE forbids dynamic path-reads score boosts for paper results.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from enum import StrEnum

from cactus.domain.models import ContextUnit
from cactus.task.schema import TaskIntent


class ScoringMode(StrEnum):
    STATIC_REPRODUCIBLE = "static_reproducible"
    ADAPTIVE_INTERACTIVE = "adaptive_interactive"


RAW_WEIGHTS: dict[str, float] = {
    "lexical": 0.30,
    "symbol": 0.25,
    "graph": 0.20,
    "test": 0.10,
    "path": 0.10,
}

# Normalized static weights (sum == 1.0)
_TOTAL_RAW = sum(RAW_WEIGHTS.values())
DEFAULT_WEIGHTS: dict[str, float] = {k: v / _TOTAL_RAW for k, v in RAW_WEIGHTS.items()}


def deterministic_sort_key(unit: ContextUnit, score: float) -> tuple[float, str, int, str, str]:
    """Canonical tie-breaking rule from Section 7.3."""
    start_line = unit.start_line if unit.start_line is not None else -1
    symbol_id = unit.symbol_id or ""
    return (-score, unit.path, start_line, symbol_id, unit.unit_id)


def score_candidates(
    units: Iterable[ContextUnit],
    intent: TaskIntent,
    *,
    lexical: Mapping[str, float] | None = None,
    graph_distances: Mapping[str, int] | None = None,
    test_units: set[str] | None = None,
    weights: Mapping[str, float] | None = None,
    mode: ScoringMode = ScoringMode.STATIC_REPRODUCIBLE,
    path_reads: Mapping[str, int] | None = None,
) -> dict[str, float]:
    """Compute static task relevance R(c) for all candidate units."""
    lexical = lexical or {}
    graph_distances = graph_distances or {}
    test_units = test_units or set()

    w = dict(DEFAULT_WEIGHTS)
    if weights:
        # If customized weights provided, normalize them
        tot = sum(weights.values()) or 1.0
        w = {k: v / tot for k, v in weights.items()}

    symbols = set(intent.mentioned_symbols)
    paths = set(intent.mentioned_files) | set(intent.mentioned_modules)
    result: dict[str, float] = {}

    for unit in units:
        symbol = 1.0 if unit.symbol_id in symbols else 0.0
        graph = 1.0 / (1.0 + graph_distances.get(unit.unit_id, 99))
        test = 1.0 if unit.unit_id in test_units else 0.0
        path = 1.0 if unit.path in paths or any(unit.path.startswith(value.rstrip(".py")) for value in paths) else 0.0

        static_r = (
            w.get("lexical", 0.0) * lexical.get(unit.unit_id, 0.0)
            + w.get("symbol", 0.0) * symbol
            + w.get("graph", 0.0) * graph
            + w.get("test", 0.0) * test
            + w.get("path", 0.0) * path
        )

        # In interactive mode only, allow subtle state feedback. In static mode, strict zero.
        if mode == ScoringMode.ADAPTIVE_INTERACTIVE and path_reads:
            static_r += min(0.05, path_reads.get(unit.path, 0) * 0.01)

        result[unit.unit_id] = static_r

    return result
