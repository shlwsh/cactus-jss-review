"""Frozen pre-v2.1 static density selector used as an ablation."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from cactus.domain.models import ContextUnit
from cactus.retrieval.marginal_utility import SelectedContext, _bundle_hash


def select_static_density(units: Sequence[ContextUnit], scores: Mapping[str, float], *, budget: int, protected_ids: set[str] | frozenset[str] = frozenset()) -> SelectedContext:
    if budget < 0:
        raise ValueError("budget must be non-negative")
    by_id = {unit.unit_id: unit for unit in units}
    selected = [by_id[unit_id] for unit_id in sorted(protected_ids) if unit_id in by_id]
    if len(selected) != len(protected_ids) or sum(unit.token_count for unit in selected) > budget:
        return SelectedContext((), 0, 0, 0, 0.0, _bundle_hash(()), dict(scores), "budget_infeasible")
    remaining = budget - sum(unit.token_count for unit in selected)
    selected_ids = {unit.unit_id for unit in selected}
    candidates = sorted((unit for unit in units if unit.unit_id not in selected_ids), key=lambda unit: (-(scores.get(unit.unit_id, 0.0) / max(1, unit.token_count)), unit.unit_id))
    for unit in candidates:
        if unit.token_count <= remaining:
            selected.append(unit)
            remaining -= unit.token_count
    used = budget - remaining
    files = {unit.path for unit in selected}
    return SelectedContext(tuple(unit.unit_id for unit in selected), used, len(files), len(selected), len(selected) / max(1.0, used / 1000.0), _bundle_hash(tuple(selected)), dict(scores), "ok")
