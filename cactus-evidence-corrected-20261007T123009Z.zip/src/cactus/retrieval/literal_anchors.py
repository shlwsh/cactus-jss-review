"""Issue-text code anchors that must remain available to the selector."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable

from cactus.domain.models import ContextUnit


def _normalized(text: str) -> str:
    return " ".join(text.casefold().split())


def exact_source_anchor_ids(units: Iterable[ContextUnit], task_text: str) -> frozenset[str]:
    """Return units containing code-like literal lines quoted in an issue.

    The anchors are derived only from the inference-safe issue text and the
    checked-out repository.  They are not patch hints: a source occurrence is
    protected only when the issue quotes a nontrivial code-like line verbatim.
    """

    snippets = {
        _normalized(raw_line.strip().strip("`"))
        for raw_line in task_text.splitlines()
        if len(raw_line.strip().strip("`")) >= 8
        and any(marker in raw_line for marker in "=_()[]{}")
    }
    unit_list = tuple(units)
    if not snippets:
        return frozenset()
    anchors: set[str] = set()
    for snippet in sorted(snippets):
        matches: list[tuple[ContextUnit, int | None]] = []
        for unit in unit_list:
            for offset, source_line in enumerate(unit.text.splitlines()):
                if _normalized(source_line) == snippet:
                    line = unit.start_line + offset if unit.start_line is not None else None
                    matches.append((unit, line))
        # A file, class, and function unit can all contain the same source
        # line.  Prefer source-positioned non-file units and collapse the
        # hierarchy to its smallest representative for each real location.
        positioned = [(unit, line) for unit, line in matches if unit.kind != "file" and line is not None]
        candidates = positioned or matches
        by_location: dict[tuple[str, int | None], list[ContextUnit]] = defaultdict(list)
        for unit, line in candidates:
            by_location[(unit.path, line)].append(unit)
        for grouped in by_location.values():
            chosen = min(
                grouped,
                key=lambda unit: (
                    unit.token_count,
                    (unit.end_line or 0) - (unit.start_line or 0),
                    unit.kind,
                    unit.unit_id,
                ),
            )
            anchors.add(chosen.unit_id)
    return frozenset(anchors)
