"""Deterministic budgeted structured selection for CACTUS v2.1."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from collections.abc import Mapping, Sequence

from cactus.domain.models import ACEItem, ContextUnit
from cactus.retrieval.coverage import compute_coverage_gain, compute_fragmentation, compute_redundancy, coverage_keys, new_file_key


DEFAULT_WEIGHTS = {
    "relevance": 1.0,
    "coverage_alpha": 0.20,
    "redundancy_beta": 0.15,
    "fragmentation_gamma": 0.15,
    "new_file_lambda": 0.10,
    "min_chunk_tokens": 64,
    "max_chunks_per_file": 4,
    "max_new_files_soft": 40,
    "parent_context_required": True,
}


@dataclass(frozen=True, slots=True)
class SelectedContext:
    selected_unit_ids: tuple[str, ...]
    total_tokens: int
    selected_files: int
    selected_chunks: int
    fragmentation_index: float
    bundle_hash: str
    scores: Mapping[str, float]
    status: str = "ok"


def _value(unit: ContextUnit, key: str, fallback: float = 0.0) -> float:
    value = unit.provenance.get(key, fallback)
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def marginal_utility_score(candidate: ContextUnit, selected: set[str], weights: Mapping[str, float] | None = None, *, selected_units: Sequence[ContextUnit] = ()) -> float:
    """Compute ``Δ(c|S)`` using relevance and structural penalties."""

    w = dict(DEFAULT_WEIGHTS)
    if weights:
        w.update(weights)
    relevance = _value(candidate, "relevance_score", _value(candidate, "lexical_score")) * w["relevance"]
    coverage = compute_coverage_gain(candidate, selected)
    redundancy = compute_redundancy(candidate, selected, selected_units)
    fragmentation = compute_fragmentation(candidate, min_chunk_tokens=int(w["min_chunk_tokens"]))
    return relevance + w["coverage_alpha"] * coverage - w["redundancy_beta"] * redundancy - w["fragmentation_gamma"] * fragmentation


def budget_density(candidate: ContextUnit, selected: set[str], weights: Mapping[str, float] | None = None, *, selected_units: Sequence[ContextUnit] = ()) -> float:
    """Compute marginal utility per token plus a soft new-file charge."""

    w = dict(DEFAULT_WEIGHTS)
    if weights:
        w.update(weights)
    utility = marginal_utility_score(candidate, selected, w, selected_units=selected_units)
    new_file = 1.0 if new_file_key(candidate) not in selected else 0.0
    denominator = candidate.token_count + w["new_file_lambda"] * max(1, candidate.token_count) * new_file
    return utility / max(1.0, denominator)


def canonical_bundle_hash(units: Sequence[ContextUnit]) -> str:
    payload = [{"unit_id": unit.unit_id, "path": unit.path, "snapshot_hash": unit.snapshot_hash, "token_count": unit.token_count} for unit in units]
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


_bundle_hash = canonical_bundle_hash


def select_marginal_utility(
    units: Sequence[ContextUnit],
    scores: Mapping[str, float],
    *,
    budget: int,
    protected_ids: set[str] | frozenset[str] = frozenset(),
    weights: Mapping[str, float] | None = None,
) -> SelectedContext:
    """Select units by dynamic density while preserving protected ACE units."""

    if budget < 0:
        raise ValueError("budget must be non-negative")
    w = dict(DEFAULT_WEIGHTS)
    if weights:
        w.update(weights)
    by_id = {unit.unit_id: unit for unit in units}
    if len(by_id) != len(tuple(units)):
        return SelectedContext((), 0, 0, 0, 0.0, _bundle_hash(()), dict(scores), "duplicate_unit_ids")
    parent_context = {}
    if w.get("parent_context_required", True) and any(
        "parent_unit_id" in unit.provenance or "parent_unit_ids" in unit.provenance
        for unit in units
    ):
        parent_context = {
            unit.unit_id: complete_parent_context((unit,), {unit.unit_id}, by_id=by_id)
            for unit in units
        }
    protected_seed = {unit_id for unit_id in protected_ids if unit_id in by_id}
    if len(protected_seed) != len(protected_ids):
        return SelectedContext((), 0, 0, 0, 0.0, _bundle_hash(()), dict(scores), "budget_infeasible")
    protected_complete = complete_parent_context(units, protected_seed) if w.get("parent_context_required", True) else protected_seed
    protected = [by_id[unit_id] for unit_id in sorted(protected_complete)]
    if sum(unit.token_count for unit in protected) > budget:
        return SelectedContext((), 0, 0, 0, 0.0, _bundle_hash(()), dict(scores), "budget_infeasible")
    selected_units = list(protected)
    selected_ids = {unit.unit_id for unit in selected_units}
    used = sum(unit.token_count for unit in selected_units)
    covered = set().union(*(coverage_keys(unit) for unit in selected_units)) if selected_units else set()
    file_counts: dict[str, int] = {}
    for unit in selected_units:
        file_counts[unit.path] = file_counts.get(unit.path, 0) + 1
    remaining = [unit for unit in units if unit.unit_id not in selected_ids]
    while remaining:
        ranked = []
        for unit in remaining:
            # Small standalone fragments are excluded, while compact
            # symbol-bearing definitions remain eligible: the latter can be
            # the only executable repair anchor in a small repository.
            if unit.token_count < int(w["min_chunk_tokens"]) and not unit.symbol_id:
                continue
            parent_ids = parent_context.get(unit.unit_id, set()) - selected_ids - {unit.unit_id} if w.get("parent_context_required", True) else set()
            parent_units = sorted((by_id[parent_id] for parent_id in parent_ids), key=lambda item: (item.path, item.start_line or 0, item.unit_id))
            candidate_units = [*parent_units, unit]
            candidate_cost = sum(candidate.token_count for candidate in candidate_units)
            candidate_file_counts = dict(file_counts)
            for candidate in candidate_units:
                candidate_file_counts[candidate.path] = candidate_file_counts.get(candidate.path, 0) + 1
            if candidate_cost > budget - used or any(count > int(w["max_chunks_per_file"]) for count in candidate_file_counts.values()):
                continue
            score = scores.get(unit.unit_id, 0.0)
            if unit.unit_id in covered or selected_ids.isdisjoint(covered):
                redundancy = 0.0
            else:
                redundancy = compute_redundancy(unit, covered, selected_units)
            utility = (
                _value(unit, "relevance_score", _value(unit, "lexical_score"))
                + w["coverage_alpha"] * compute_coverage_gain(unit, covered)
                - w["redundancy_beta"] * redundancy
                - w["fragmentation_gamma"] * compute_fragmentation(unit, min_chunk_tokens=int(w["min_chunk_tokens"]))
            )
            utility += score - _value(unit, "relevance_score", _value(unit, "lexical_score"))
            if unit.path not in file_counts and len(file_counts) >= int(w["max_new_files_soft"]):
                utility -= w["new_file_lambda"]
            new_file_count = sum(1 for path in candidate_file_counts if path not in file_counts)
            density = utility / max(1.0, candidate_cost + (w["new_file_lambda"] * candidate_cost if new_file_count else 0.0))
            ranked.append((density, utility, -candidate_cost, unit.path, unit.start_line or -1, unit.symbol_id or "", unit.unit_id, (unit, parent_units)))
        if not ranked:
            break
        # Negative marginal utility stop condition (Section 11.4)
        best_entry = max(ranked, key=lambda item: (item[0], item[1], item[2], item[3], item[4], item[5], item[6]))
        best_density = best_entry[0]
        best_utility = best_entry[1]
        if best_density <= 0.0 or best_utility <= 0.0:
            break

        chosen, parent_units = best_entry[7]
        for parent in parent_units:
            selected_units.append(parent)
            selected_ids.add(parent.unit_id)
            used += parent.token_count
            covered.update(coverage_keys(parent))
            file_counts[parent.path] = file_counts.get(parent.path, 0) + 1
        selected_units.append(chosen)
        selected_ids.add(chosen.unit_id)
        used += chosen.token_count
        covered.update(coverage_keys(chosen))
        file_counts[chosen.path] = file_counts.get(chosen.path, 0) + 1
        remaining = [unit for unit in remaining if unit.unit_id not in selected_ids]
    ordered = tuple(selected_units)
    fi = len(ordered) / max(1.0, used / 1000.0)
    return SelectedContext(tuple(unit.unit_id for unit in ordered), used, len(file_counts), len(ordered), fi, _bundle_hash(ordered), dict(scores), "ok")


def merge_adjacent_units(units: Sequence[ContextUnit], *, gap_lines: int = 8) -> tuple[ContextUnit, ...]:
    """Merge same-file units whose line gap is within the frozen threshold."""

    if gap_lines < 0:
        raise ValueError("gap_lines must be non-negative")
    ordered = sorted(units, key=lambda unit: (unit.path, unit.start_line or 0, unit.unit_id))
    merged: list[ContextUnit] = []
    for unit in ordered:
        if not merged:
            merged.append(unit)
            continue
        previous = merged[-1]
        gap = (unit.start_line or 0) - (previous.end_line or previous.start_line or 0) - 1
        if unit.path == previous.path and gap <= gap_lines and previous.end_line is not None and unit.start_line is not None:
            provenance = dict(previous.provenance)
            provenance["merged_unit_ids"] = tuple(previous.provenance.get("merged_unit_ids", (previous.unit_id,))) + (unit.unit_id,)
            merged[-1] = ContextUnit(
                unit_id="merge:" + ":".join(provenance["merged_unit_ids"]),
                kind="merged",
                path=unit.path,
                token_count=previous.token_count + unit.token_count,
                text=previous.text + "\n" + unit.text,
                symbol_id=previous.symbol_id or unit.symbol_id,
                start_line=previous.start_line,
                end_line=unit.end_line,
                snapshot_hash=unit.snapshot_hash or previous.snapshot_hash,
                provenance=provenance,
            )
        else:
            merged.append(unit)
    return tuple(merged)


def complete_parent_context(units: Sequence[ContextUnit], selected_ids: set[str], *, by_id: Mapping[str, ContextUnit] | None = None) -> set[str]:
    """Add explicitly recorded parent definitions without guessing relationships."""

    by_id = by_id or {unit.unit_id: unit for unit in units}
    result = set(selected_ids)
    changed = True
    while changed:
        changed = False
        for unit_id in tuple(result):
            unit = by_id.get(unit_id)
            if not unit:
                continue
            parents = unit.provenance.get("parent_unit_ids", ())
            parent = unit.provenance.get("parent_unit_id")
            candidates = [parent] if isinstance(parent, str) else []
            if isinstance(parents, Sequence) and not isinstance(parents, str):
                candidates.extend(str(value) for value in parents)
            for parent_id in candidates:
                if parent_id in by_id and parent_id not in result:
                    result.add(parent_id)
                    changed = True
    return result
