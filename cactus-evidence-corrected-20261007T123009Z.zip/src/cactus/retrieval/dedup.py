"""Deterministic candidate deduplication by symbol and line overlap."""

from __future__ import annotations

from collections.abc import Iterable

from cactus.domain.models import ContextUnit


def deduplicate(units: Iterable[ContextUnit], *, overlap_threshold: float = 0.80) -> list[ContextUnit]:
    if not 0 <= overlap_threshold <= 1:
        raise ValueError("overlap_threshold must be in [0,1]")
    chosen: list[ContextUnit] = []
    seen_symbols: set[str] = set()
    for unit in sorted(units, key=lambda item: (item.path, item.start_line or 0, item.symbol_id or "", item.unit_id)):
        if unit.symbol_id and unit.symbol_id in seen_symbols:
            continue
        duplicate = False
        for other in chosen:
            if unit.path != other.path:
                continue
            # A file-level unit contains every nested symbol in that file.
            # Keeping both repeats source lines in the model prompt and can
            # cause the model to reproduce duplicated diff context.
            if unit.kind == "file" or other.kind == "file":
                duplicate = True
                break
            if unit.start_line is None or unit.end_line is None or other.start_line is None or other.end_line is None:
                continue
            overlap = max(0, min(unit.end_line, other.end_line) - max(unit.start_line, other.start_line) + 1)
            denominator = max(1, min(unit.end_line - unit.start_line + 1, other.end_line - other.start_line + 1))
            if overlap / denominator >= overlap_threshold:
                duplicate = True
                break
        if not duplicate:
            chosen.append(unit)
            if unit.symbol_id:
                seen_symbols.add(unit.symbol_id)
    return chosen
