"""Deterministic legacy code mapping and evidence-based re-attribution.

Translates legacy error codes (E01-E14 and TOSEM 4-family taxonomy) into the
five-family FailureCode taxonomy (ALG, PAT, EXE, EVA, GOV).
"""

from __future__ import annotations

import re
from cactus.failure_recovery.taxonomy import FailureCode, FailureFamily

# Direct mapping from legacy ErrorCode string prefixes/names to FailureCode
LEGACY_ERROR_CODE_MAPPING: dict[str, FailureCode] = {
    "E01": FailureCode.EXE003_REPOSITORY_MIRROR_DOWN,
    "E01_REPO_CHECKOUT": FailureCode.EXE003_REPOSITORY_MIRROR_DOWN,
    "E02": FailureCode.EXE005_NETWORK_ERROR,
    "E02_DEPENDENCY_SETUP": FailureCode.EXE005_NETWORK_ERROR,
    "E03": FailureCode.EXE004_CONTAINER_DAEMON_DOWN,
    "E03_CONTAINER_BUILD": FailureCode.EXE004_CONTAINER_DAEMON_DOWN,
    "E04": FailureCode.EXE004_CONTAINER_DAEMON_DOWN,
    "E04_CONTAINER_RUNTIME": FailureCode.EXE004_CONTAINER_DAEMON_DOWN,
    "E05": FailureCode.EXE001_GATEWAY_TIMEOUT,
    "E05_MODEL_GATEWAY": FailureCode.EXE001_GATEWAY_TIMEOUT,
    "E06": FailureCode.EXE001_GATEWAY_TIMEOUT,
    "E06_MODEL_TIMEOUT": FailureCode.EXE001_GATEWAY_TIMEOUT,
    "E07": FailureCode.ALG003_MALFORMED_DIFF,
    "E07_PATCH_PARSE": FailureCode.ALG003_MALFORMED_DIFF,
    "E08": FailureCode.PAT001_APPLY_FAILED,
    "E08_PATCH_APPLY": FailureCode.PAT001_APPLY_FAILED,
    "E09": FailureCode.EVA005_TEST_DISCOVERY_FAILED,
    "E09_TEST_DISCOVERY": FailureCode.EVA005_TEST_DISCOVERY_FAILED,
    "E10": FailureCode.EVA003_CRASH,
    "E10_TEST_RUNTIME": FailureCode.EVA003_CRASH,
    "E11": FailureCode.EVA003_CRASH,
    "E11_EVALUATOR_INTERNAL": FailureCode.EVA003_CRASH,
    "E12": FailureCode.GOV004_BILLING_EVIDENCE_MISSING,
    "E12_BILLING_RECORD": FailureCode.GOV004_BILLING_EVIDENCE_MISSING,
    "E13": FailureCode.GOV007_HASH_MISMATCH,
    "E13_CLEANUP": FailureCode.GOV007_HASH_MISMATCH,
    "E14": FailureCode.EVA003_CRASH,
    "E14_UNKNOWN": FailureCode.EVA003_CRASH,
}

# Mapping from TOSEM v2.1 4-family codes (A/X/E/G) to FailureCode
TOSEM_4FAMILY_MAPPING: dict[str, FailureCode] = {
    "A01_EMPTY_PATCH": FailureCode.ALG001_EMPTY_OUTPUT,
    "A02_INVALID_PATCH": FailureCode.PAT001_APPLY_FAILED,
    "A03_TOOL_PLAN_FAILURE": FailureCode.ALG005_OUTPUT_CONTRACT_VIOLATION,
    "A04_AGENT_TIMEOUT": FailureCode.ALG005_OUTPUT_CONTRACT_VIOLATION,
    "X01_CONTAINER_DAEMON": FailureCode.EXE004_CONTAINER_DAEMON_DOWN,
    "X02_REPOSITORY_MIRROR": FailureCode.EXE003_REPOSITORY_MIRROR_DOWN,
    "X03_MODEL_GATEWAY": FailureCode.EXE001_GATEWAY_TIMEOUT,
    "X04_RATE_LIMIT": FailureCode.EXE002_RATE_LIMITED,
    "X05_DEPENDENCY_SETUP": FailureCode.EXE005_NETWORK_ERROR,
    "X06_RUNTIME_OOM": FailureCode.EVA002_OOM,
    "E01_TEST_DISCOVERY": FailureCode.EVA005_TEST_DISCOVERY_FAILED,
    "E02_TEST_PATCH_APPLY": FailureCode.EVA003_CRASH,
    "E03_EVALUATOR_CRASH": FailureCode.EVA003_CRASH,
    "E04_EVALUATOR_TIMEOUT": FailureCode.EVA001_TIMEOUT,
    "E05_RESULT_MALFORMED": FailureCode.EVA004_MALFORMED_RESULT,
    "E06_UNKNOWN_EVALUATOR": FailureCode.EVA003_CRASH,
    "G01_BILLING_DELAY": FailureCode.GOV004_BILLING_EVIDENCE_MISSING,
    "G02_BILLING_MISSING": FailureCode.GOV004_BILLING_EVIDENCE_MISSING,
    "G03_CHECKSUM_MISMATCH": FailureCode.GOV007_HASH_MISMATCH,
    "G04_DIRTY_SOURCE": FailureCode.GOV002_DIRTY_SOURCE,
    "G05_MUTABLE_IMAGE": FailureCode.GOV003_MUTABLE_IMAGE_TAG,
    "G06_APPROVAL_MISSING": FailureCode.GOV001_MISSING_APPROVAL,
}


def map_legacy_error_code(code: str) -> FailureCode:
    """Map a legacy error code string to the v2 FailureCode."""
    clean = code.strip()
    if clean in LEGACY_ERROR_CODE_MAPPING:
        return LEGACY_ERROR_CODE_MAPPING[clean]
    if clean in TOSEM_4FAMILY_MAPPING:
        return TOSEM_4FAMILY_MAPPING[clean]
    prefix = clean.split("_", 1)[0]
    if prefix in LEGACY_ERROR_CODE_MAPPING:
        return LEGACY_ERROR_CODE_MAPPING[prefix]
    raise KeyError(f"unrecognized legacy error code: {code}")


def classify_text_v2(text: str) -> tuple[FailureFamily, FailureCode]:
    """Classify free-form evidence text strictly obeying the deterministic priority.

    Priority: GOV -> EXE -> ALG -> PAT -> EVA
    """
    lowered = text.lower()

    # 1. GOV: Governance / Billing / Integrity
    if any(k in lowered for k in ("missing approval", "unauthorized", "approval_missing")):
        return FailureFamily.GOV, FailureCode.GOV001_MISSING_APPROVAL
    if any(k in lowered for k in ("dirty git", "dirty source", "dirty working tree")):
        return FailureFamily.GOV, FailureCode.GOV002_DIRTY_SOURCE
    if any(k in lowered for k in ("mutable image tag", "using :latest tag")):
        return FailureFamily.GOV, FailureCode.GOV003_MUTABLE_IMAGE_TAG
    if any(k in lowered for k in ("billing evidence missing", "spend log missing", "no_records", "no billing")):
        return FailureFamily.GOV, FailureCode.GOV004_BILLING_EVIDENCE_MISSING
    if any(k in lowered for k in ("hash mismatch", "checksum mismatch", "corrupt artifact")):
        return FailureFamily.GOV, FailureCode.GOV007_HASH_MISMATCH
    if any(k in lowered for k in ("ground_truth_leakage", "label leakage", "gold patch referenced")):
        return FailureFamily.GOV, FailureCode.GOV008_LABEL_LEAKAGE_RISK

    # 2. EXE: Infrastructure / Network / Container Daemon
    if any(k in lowered for k in ("gateway timeout", "connection refused", "502 bad gateway", "504 gateway timeout")):
        return FailureFamily.EXE, FailureCode.EXE001_GATEWAY_TIMEOUT
    if any(k in lowered for k in ("rate limit", "429 too many requests", "tokens per min exceeded")):
        return FailureFamily.EXE, FailureCode.EXE002_RATE_LIMITED
    if any(k in lowered for k in ("repository mirror down", "failed to clone repo", "git clone failed")):
        return FailureFamily.EXE, FailureCode.EXE003_REPOSITORY_MIRROR_DOWN
    if any(k in lowered for k in ("docker daemon down", "cannot connect to docker daemon", "container build failed")):
        return FailureFamily.EXE, FailureCode.EXE004_CONTAINER_DAEMON_DOWN
    if any(k in lowered for k in ("connection reset", "network error", "dns resolution failed")):
        return FailureFamily.EXE, FailureCode.EXE005_NETWORK_ERROR

    # 3. ALG: Model generation / format violation
    if any(k in lowered for k in ("empty output", "empty model response", "generation was empty")):
        return FailureFamily.ALG, FailureCode.ALG001_EMPTY_OUTPUT
    if any(k in lowered for k in ("no diff found", "no unified diff", "diff --git missing")):
        return FailureFamily.ALG, FailureCode.ALG002_NO_DIFF
    if any(k in lowered for k in ("malformed diff", "unparseable hunk", "corrupt unified diff")):
        return FailureFamily.ALG, FailureCode.ALG003_MALFORMED_DIFF
    if any(k in lowered for k in ("wrong target file", "target file does not exist in repo")):
        return FailureFamily.ALG, FailureCode.ALG004_WRONG_TARGET

    # 4. PAT: Patch application / normalization
    if any(k in lowered for k in ("semantic change detected", "normalization altered lines")):
        return FailureFamily.PAT, FailureCode.PAT005_SEMANTIC_CHANGE_DETECTED
    if any(k in lowered for k in ("ambiguous alignment", "multiple hunk matches", "alignment ambiguous")):
        return FailureFamily.PAT, FailureCode.PAT002_ALIGNMENT_AMBIGUOUS
    if any(k in lowered for k in ("patch apply failed", "git apply failed", "patch does not apply", "rejected hunk")):
        return FailureFamily.PAT, FailureCode.PAT001_APPLY_FAILED
    if any(k in lowered for k in ("path normalization failed", "cannot locate file on disk")):
        return FailureFamily.PAT, FailureCode.PAT003_PATH_NORMALIZATION_FAILED

    # 5. EVA: Evaluator runtime
    if any(k in lowered for k in ("evaluator timeout", "test run timed out", "execution timed out")):
        return FailureFamily.EVA, FailureCode.EVA001_TIMEOUT
    if any(k in lowered for k in ("oom", "out of memory", "killed process")):
        return FailureFamily.EVA, FailureCode.EVA002_OOM
    if any(k in lowered for k in ("malformed result", "evaluator report invalid json")):
        return FailureFamily.EVA, FailureCode.EVA004_MALFORMED_RESULT
    if any(k in lowered for k in ("no tests found", "test discovery failed")):
        return FailureFamily.EVA, FailureCode.EVA005_TEST_DISCOVERY_FAILED

    # Fallback to EVA Crash
    return FailureFamily.EVA, FailureCode.EVA003_CRASH
