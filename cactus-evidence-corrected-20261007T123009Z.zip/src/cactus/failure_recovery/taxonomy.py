"""Taxonomy V2: Five-family failure classification and multi-stage task outcome models.

Implements the specification from Section 3 & 4 of CACTUS Rectification Plan v2.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any


class FailureFamily(StrEnum):
    ALG = "ALG"  # Algorithm / Generation failure
    PAT = "PAT"  # Patch processing / normalization failure
    EXE = "EXE"  # Infrastructure / execution failure
    EVA = "EVA"  # Evaluator failure
    GOV = "GOV"  # Governance / provenance / audit failure


class FailureCode(StrEnum):
    # ALG: Algorithm / Generation errors (do not count towards evaluator errors)
    ALG001_EMPTY_OUTPUT = "ALG001_EMPTY_OUTPUT"
    ALG002_NO_DIFF = "ALG002_NO_DIFF"
    ALG003_MALFORMED_DIFF = "ALG003_MALFORMED_DIFF"
    ALG004_WRONG_TARGET = "ALG004_WRONG_TARGET"
    ALG005_OUTPUT_CONTRACT_VIOLATION = "ALG005_OUTPUT_CONTRACT_VIOLATION"

    # PAT: Patch handling errors
    PAT001_APPLY_FAILED = "PAT001_APPLY_FAILED"
    PAT002_ALIGNMENT_AMBIGUOUS = "PAT002_ALIGNMENT_AMBIGUOUS"
    PAT003_PATH_NORMALIZATION_FAILED = "PAT003_PATH_NORMALIZATION_FAILED"
    PAT004_CONTEXT_RECONSTRUCTION_FAILED = "PAT004_CONTEXT_RECONSTRUCTION_FAILED"
    PAT005_SEMANTIC_CHANGE_DETECTED = "PAT005_SEMANTIC_CHANGE_DETECTED"

    # EXE: Execution infrastructure errors
    EXE001_GATEWAY_TIMEOUT = "EXE001_GATEWAY_TIMEOUT"
    EXE002_RATE_LIMITED = "EXE002_RATE_LIMITED"
    EXE003_REPOSITORY_MIRROR_DOWN = "EXE003_REPOSITORY_MIRROR_DOWN"
    EXE004_CONTAINER_DAEMON_DOWN = "EXE004_CONTAINER_DAEMON_DOWN"
    EXE005_NETWORK_ERROR = "EXE005_NETWORK_ERROR"

    # EVA: Evaluator errors
    EVA001_TIMEOUT = "EVA001_TIMEOUT"
    EVA002_OOM = "EVA002_OOM"
    EVA003_CRASH = "EVA003_CRASH"
    EVA004_MALFORMED_RESULT = "EVA004_MALFORMED_RESULT"
    EVA005_TEST_DISCOVERY_FAILED = "EVA005_TEST_DISCOVERY_FAILED"

    # GOV: Governance & audit errors
    GOV001_MISSING_APPROVAL = "GOV001_MISSING_APPROVAL"
    GOV002_DIRTY_SOURCE = "GOV002_DIRTY_SOURCE"
    GOV003_MUTABLE_IMAGE_TAG = "GOV003_MUTABLE_IMAGE_TAG"
    GOV004_BILLING_EVIDENCE_MISSING = "GOV004_BILLING_EVIDENCE_MISSING"
    GOV005_BUDGET_VIOLATION = "GOV005_BUDGET_VIOLATION"
    GOV006_PROVENANCE_MISSING = "GOV006_PROVENANCE_MISSING"
    GOV007_HASH_MISMATCH = "GOV007_HASH_MISMATCH"
    GOV008_LABEL_LEAKAGE_RISK = "GOV008_LABEL_LEAKAGE_RISK"


class GenerationStatus(StrEnum):
    NON_EMPTY = "NON_EMPTY"
    EMPTY = "EMPTY"
    MODEL_ERROR = "MODEL_ERROR"


class PatchParseStatus(StrEnum):
    PARSED = "PARSED"
    NO_DIFF_FOUND = "NO_DIFF_FOUND"
    MALFORMED_DIFF = "MALFORMED_DIFF"


class PatchApplyStatus(StrEnum):
    APPLIED = "APPLIED"
    APPLY_FAILED = "APPLY_FAILED"
    AMBIGUOUS_ALIGNMENT = "AMBIGUOUS_ALIGNMENT"
    NOT_ATTEMPTED = "NOT_ATTEMPTED"


class ExecutionStatus(StrEnum):
    OK = "OK"
    MODEL_GATEWAY_TIMEOUT = "MODEL_GATEWAY_TIMEOUT"
    RATE_LIMITED = "RATE_LIMITED"
    REPOSITORY_UNAVAILABLE = "REPOSITORY_UNAVAILABLE"
    CONTAINER_UNAVAILABLE = "CONTAINER_UNAVAILABLE"
    OTHER_EXECUTION_ERROR = "OTHER_EXECUTION_ERROR"


class EvaluatorStatus(StrEnum):
    VALID = "VALID"
    TIMEOUT = "TIMEOUT"
    OOM = "OOM"
    CRASH = "CRASH"
    MALFORMED_RESULT = "MALFORMED_RESULT"
    NOT_RUN = "NOT_RUN"


class RepairStatus(StrEnum):
    RESOLVED = "RESOLVED"
    UNRESOLVED = "UNRESOLVED"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True, slots=True)
class TaskOutcomeV2:
    """Canonical representation of a single task attempt's outcome."""

    task_id: str
    attempt_id: str

    generation_status: str
    patch_parse_status: str
    patch_apply_status: str
    execution_status: str
    evaluator_status: str
    repair_status: str

    failure_family: str | None
    failure_code: str | None

    raw_patch_hash: str | None
    normalized_patch_hash: str | None
    context_bundle_hash: str
    evaluator_report_hash: str | None

    is_algorithm_valid: bool
    is_evaluator_valid: bool
    is_primary_analysis_eligible: bool

    secondary_events: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, object]:
        return {
            "task_id": self.task_id,
            "attempt_id": self.attempt_id,
            "generation_status": self.generation_status,
            "patch_parse_status": self.patch_parse_status,
            "patch_apply_status": self.patch_apply_status,
            "execution_status": self.execution_status,
            "evaluator_status": self.evaluator_status,
            "repair_status": self.repair_status,
            "failure_family": self.failure_family,
            "failure_code": self.failure_code,
            "raw_patch_hash": self.raw_patch_hash,
            "normalized_patch_hash": self.normalized_patch_hash,
            "context_bundle_hash": self.context_bundle_hash,
            "evaluator_report_hash": self.evaluator_report_hash,
            "is_algorithm_valid": self.is_algorithm_valid,
            "is_evaluator_valid": self.is_evaluator_valid,
            "is_primary_analysis_eligible": self.is_primary_analysis_eligible,
            "secondary_events": list(self.secondary_events),
        }


@dataclass(frozen=True, slots=True)
class RetryReplayPermission:
    """Independent policy decisions for algorithm retry and evaluator replay."""

    code: str
    family: str
    algorithm_retryable: bool
    evaluator_replayable: bool
    requires_same_prediction_hash: bool
    requires_same_context_hash: bool


def retry_replay_permission(
    code: str | None,
    *,
    policy_path: Path | None = None,
) -> RetryReplayPermission:
    """Load the frozen submission taxonomy and fail closed on unknown codes."""

    if policy_path is None:
        policy_path = Path(__file__).resolve().parents[3] / "paper" / "error_taxonomy.yaml"
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - dependency is validated by project setup
        raise RuntimeError("PyYAML is required to load the retry/replay policy") from exc
    document: Any = yaml.safe_load(policy_path.read_text(encoding="utf-8"))
    rules = document.get("rules", []) if isinstance(document, dict) else []
    for rule in rules if isinstance(rules, list) else []:
        if not isinstance(rule, dict) or rule.get("code") != code:
            continue
        return RetryReplayPermission(
            code=str(code),
            family=str(rule.get("family", "UNKNOWN")),
            algorithm_retryable=rule.get("algorithm_retryable") is True,
            evaluator_replayable=rule.get("evaluator_replayable") is True,
            requires_same_prediction_hash=rule.get("requires_same_prediction_hash") is True,
            requires_same_context_hash=rule.get("requires_same_context_hash") is True,
        )
    return RetryReplayPermission(
        code=str(code or "UNCLASSIFIED"),
        family="UNKNOWN",
        algorithm_retryable=False,
        evaluator_replayable=False,
        requires_same_prediction_hash=True,
        requires_same_context_hash=True,
    )
