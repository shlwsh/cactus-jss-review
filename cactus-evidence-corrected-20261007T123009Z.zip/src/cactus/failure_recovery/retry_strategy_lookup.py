"""Compatibility name matching the v3.0 implementation task wording."""

from .strategy_lookup import RETRY_STRATEGIES, lookup_strategy

__all__ = ["RETRY_STRATEGIES", "lookup_strategy"]
