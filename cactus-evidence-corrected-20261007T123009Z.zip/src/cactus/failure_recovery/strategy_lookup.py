"""Deterministic retry strategy table from the v3.0 dual-lens protocol."""

from __future__ import annotations

from cactus.execution.retry_state_machine import ErrorCode, RETRYABLE

RETRY_STRATEGIES: dict[ErrorCode, str] = {
    ErrorCode.CONTAINER_BUILD: "rebuild_container + refresh_image_digest",
    ErrorCode.CONTAINER_RUNTIME: "restart_container + check_host_profile",
    ErrorCode.MODEL_GATEWAY: "switch_gateway + rotate_api_key",
    ErrorCode.MODEL_TIMEOUT: "increase_timeout_by_50% + retry",
    ErrorCode.TEST_DISCOVERY: "refresh_test_index + retry",
    ErrorCode.TEST_RUNTIME: "check_resource_limit + retry",
    ErrorCode.EVALUATOR_INTERNAL: "rotate_evaluator_version + retry",
    ErrorCode.BILLING_RECORD: "resync_billing_card + retry",
}


def lookup_strategy(error_code: ErrorCode | str | None) -> str | None:
    if error_code is None:
        return None
    code = ErrorCode(error_code)
    return RETRY_STRATEGIES[code] if code in RETRYABLE else None
