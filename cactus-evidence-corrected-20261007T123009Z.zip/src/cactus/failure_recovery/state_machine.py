"""State Machine V2: Fail-closed recovery with distinct retry and replay mechanisms.

Implements Section 14 of CACTUS Rectification Plan v2.
Differentiates between:
1. generation_retry: re-invoking LLM (consumes model budget)
2. execution_retry: retrying gateway/container infrastructure (fixed prediction)
3. evaluator_replay: re-evaluating sealed prediction without re-running generation
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from cactus.failure_recovery.taxonomy import FailureCode, FailureFamily, TaskOutcomeV2


class RetryMechanism(StrEnum):
    NONE = "none"
    GENERATION_RETRY = "generation_retry"
    EXECUTION_RETRY = "execution_retry"
    EVALUATOR_REPLAY = "evaluator_replay"


RETRYABLE_GENERATION = frozenset({
    FailureCode.ALG001_EMPTY_OUTPUT,
    FailureCode.ALG002_NO_DIFF,
    FailureCode.ALG003_MALFORMED_DIFF,
    FailureCode.ALG005_OUTPUT_CONTRACT_VIOLATION,
})

RETRYABLE_EXECUTION = frozenset({
    FailureCode.EXE001_GATEWAY_TIMEOUT,
    FailureCode.EXE002_RATE_LIMITED,
    FailureCode.EXE003_REPOSITORY_MIRROR_DOWN,
    FailureCode.EXE004_CONTAINER_DAEMON_DOWN,
    FailureCode.EXE005_NETWORK_ERROR,
})

REPLAYABLE_EVALUATOR = frozenset({
    FailureCode.EVA001_TIMEOUT,
    FailureCode.EVA002_OOM,
    FailureCode.EVA003_CRASH,
    FailureCode.EVA004_MALFORMED_RESULT,
    FailureCode.EVA005_TEST_DISCOVERY_FAILED,
})


@dataclass(frozen=True, slots=True)
class RecoveryDecisionV2:
    should_retry: bool
    mechanism: RetryMechanism
    strategy_action: str | None
    canonical_outcome: str
    reason: str


class RecoveryStateMachineV2:
    def __init__(
        self,
        *,
        max_generation_attempts: int = 1,  # Strict paper default: 1 generation attempt for fairness
        max_execution_retries: int = 3,
        max_evaluator_replays: int = 2,
    ) -> None:
        self.max_generation_attempts = max_generation_attempts
        self.max_execution_retries = max_execution_retries
        self.max_evaluator_replays = max_evaluator_replays

    def evaluate_outcome(
        self,
        outcome: TaskOutcomeV2,
        *,
        generation_attempt: int = 1,
        execution_retry: int = 0,
        evaluator_replay: int = 0,
    ) -> RecoveryDecisionV2:
        # A task that reached RESOLVED is terminal success and never retries
        if outcome.repair_status == "RESOLVED":
            return RecoveryDecisionV2(False, RetryMechanism.NONE, None, "VALID_RESOLVED", "Task resolved successfully")

        # If there is an explicit failure code, determine recovery mechanism by taxonomy family priority
        code_str = outcome.failure_code
        if code_str:
            code = FailureCode(code_str)

            # 1. Execution infrastructure failure (EXE)
            if code in RETRYABLE_EXECUTION:
                if execution_retry < self.max_execution_retries:
                    return RecoveryDecisionV2(
                        True,
                        RetryMechanism.EXECUTION_RETRY,
                        f"retry_infra_step:{code.value}",
                        "RETRYABLE_EXECUTION_FAILURE",
                        f"Execution infra failure eligible for retry ({execution_retry + 1}/{self.max_execution_retries})",
                    )
                return RecoveryDecisionV2(
                    False,
                    RetryMechanism.NONE,
                    None,
                    "TERMINAL_EXECUTION_FAILURE",
                    "Execution retry limit exhausted",
                )

            # 2. Evaluator runtime failure (EVA)
            if code in REPLAYABLE_EVALUATOR:
                if evaluator_replay < self.max_evaluator_replays:
                    return RecoveryDecisionV2(
                        True,
                        RetryMechanism.EVALUATOR_REPLAY,
                        f"replay_evaluator_step:{code.value}",
                        "REPLAYABLE_EVALUATOR_FAILURE",
                        f"Evaluator failure eligible for replay ({evaluator_replay + 1}/{self.max_evaluator_replays})",
                    )
                return RecoveryDecisionV2(
                    False,
                    RetryMechanism.NONE,
                    None,
                    "TERMINAL_EVALUATOR_FAILURE",
                    "Evaluator replay limit exhausted",
                )

            # 3. Model generation failure (ALG)
            if code in RETRYABLE_GENERATION:
                if generation_attempt < self.max_generation_attempts:
                    return RecoveryDecisionV2(
                        True,
                        RetryMechanism.GENERATION_RETRY,
                        f"re_invoke_llm:{code.value}",
                        "RETRYABLE_GENERATION_FAILURE",
                        f"Model generation failure eligible for generation retry ({generation_attempt + 1}/{self.max_generation_attempts})",
                    )
                return RecoveryDecisionV2(
                    False,
                    RetryMechanism.NONE,
                    None,
                    "TERMINAL_ALGORITHM_FAILURE",
                    "Model generation attempt limit reached (fair comparison enforced)",
                )

            # 4. Patch apply (PAT) or Governance (GOV) failures (terminal by default)
            return RecoveryDecisionV2(
                False,
                RetryMechanism.NONE,
                None,
                "TERMINAL_NON_RETRYABLE",
                f"Non-retryable failure: {code.value}",
            )

        # No error code: evaluate final task resolution
        if outcome.repair_status == "RESOLVED":
            return RecoveryDecisionV2(False, RetryMechanism.NONE, None, "VALID_RESOLVED", "Task resolved successfully")
        if outcome.is_evaluator_valid and outcome.repair_status == "UNRESOLVED":
            return RecoveryDecisionV2(False, RetryMechanism.NONE, None, "VALID_UNRESOLVED", "Evaluator validated clean unresolved outcome")

        return RecoveryDecisionV2(False, RetryMechanism.NONE, None, "TERMINAL_UNKNOWN", "No error code and unresolved status")


# Backward compatibility bindings for legacy imports
VALID_OUTCOMES = frozenset({"VALID_RESOLVED", "VALID_UNRESOLVED", "INVALID_EVALUATION"})


@dataclass(frozen=True, slots=True)
class AttemptResult:
    attempt_id: str
    attempt_number: int
    outcome: str
    error_code: str | None = None
    context_bundle_hash: str = ""


@dataclass(frozen=True, slots=True)
class RecoveryDecision:
    retry: bool
    strategy: str | None
    canonical_outcome: str
    reason: str


def decide(attempt: AttemptResult, *, max_attempts: int = 3) -> RecoveryDecision:
    if max_attempts < 1:
        raise ValueError("max_attempts must be positive")
    if attempt.outcome in {"VALID_RESOLVED", "VALID_UNRESOLVED"}:
        return RecoveryDecision(False, None, attempt.outcome, "valid evaluator outcome")
    from .strategy_lookup import lookup_strategy
    from cactus.execution.retry_state_machine import RETRYABLE, ErrorCode
    code = ErrorCode(attempt.error_code) if attempt.error_code else ErrorCode.UNKNOWN
    if code not in RETRYABLE:
        return RecoveryDecision(False, None, "INVALID_EVALUATION", "non-retryable evaluator/infrastructure failure")
    if attempt.attempt_number >= max_attempts:
        return RecoveryDecision(False, None, "INVALID_EVALUATION", "retry budget exhausted")
    return RecoveryDecision(True, lookup_strategy(code), "INVALID_EVALUATION", "retryable evaluator/infrastructure failure")


def recover_attempts(attempts: list[AttemptResult], *, max_attempts: int = 3) -> tuple[AttemptResult, RecoveryDecision]:
    if not attempts:
        raise ValueError("at least one attempt is required")
    ordered = sorted(attempts, key=lambda item: (item.attempt_number, item.attempt_id))
    if [item.attempt_number for item in ordered] != list(range(1, len(ordered) + 1)):
        raise ValueError("attempt numbers must form a contiguous chain")
    for item in ordered:
        decision = decide(item, max_attempts=max_attempts)
        if not decision.retry:
            return item, decision
    return ordered[-1], decide(ordered[-1], max_attempts=max_attempts)
