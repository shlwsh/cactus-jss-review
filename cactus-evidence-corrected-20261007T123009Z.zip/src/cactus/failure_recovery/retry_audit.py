"""Integrity checks for immutable retry evidence chains."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping

from cactus.execution.retry_state_machine import ErrorCode, RETRYABLE
from .strategy_lookup import lookup_strategy


def _canonical(rows: list[dict[str, object]]) -> str:
    return json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def build_retry_audit(attempts: Iterable[Mapping[str, object]]) -> dict[str, object]:
    rows = [dict(row) for row in attempts]
    errors = validate_retry_chain(rows)
    if errors:
        raise ValueError("; ".join(errors))
    return {"schema_version": "1.0", "attempts": rows, "chain_sha256": hashlib.sha256(_canonical(rows).encode("utf-8")).hexdigest(), "integrity": "verified"}


def validate_retry_chain(chain: Iterable[Mapping[str, object]]) -> list[str]:
    rows = [dict(row) for row in chain]
    errors: list[str] = []
    ids = [str(row.get("attempt_id", "")) for row in rows]
    if not rows or any(not value for value in ids):
        errors.append("attempt_id is required for every attempt")
    if len(set(ids)) != len(ids):
        errors.append("attempt_id values must be unique")
    numbers = [int(row.get("attempt_number", 0)) for row in rows]
    if numbers != list(range(1, len(rows) + 1)):
        errors.append("attempt_number must be contiguous from 1")
    hashes = {str(row.get("context_bundle_hash", "")) for row in rows}
    if "" in hashes:
        errors.append("context_bundle_hash is required")
    if len(hashes) > 1:
        errors.append("context_bundle_hash must be inherited across retries")
    for row in rows:
        outcome = str(row.get("outcome", ""))
        if outcome not in {"VALID_RESOLVED", "VALID_UNRESOLVED", "INVALID_EVALUATION"}:
            errors.append(f"invalid outcome for {row.get('attempt_id')}")
        if outcome != "INVALID_EVALUATION":
            continue
        try:
            code = ErrorCode(str(row.get("error_code")))
        except ValueError:
            errors.append(f"invalid error_code for {row.get('attempt_id')}")
            continue
        if bool(row.get("retryable", code in RETRYABLE)) != (code in RETRYABLE):
            errors.append(f"retryable flag mismatch for {row.get('attempt_id')}")
        if row.get("strategy") != lookup_strategy(code):
            errors.append(f"strategy mismatch for {row.get('attempt_id')}")
    return errors
