"""Unified Experiment Telemetry Schema.

Implements Phase 6 (TASK-008) & Section 18 of CACTUS Rectification Plan v2.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True, slots=True)
class ExperimentTelemetryRecord:
    task_id: str
    attempt_id: str
    variant: str
    model_alias: str
    model_config_hash: str

    context_bundle_hash: str
    selected_context_tokens: int
    maximal_context_tokens: int
    selected_files: int
    selected_units: int

    prompt_tokens_estimated: int
    prompt_tokens_actual: int
    output_tokens: int

    raw_prediction_hash: str | None
    raw_patch_hash: str | None
    normalized_patch_hash: str | None

    generation_status: str
    patch_parse_status: str
    patch_apply_status: str
    execution_status: str
    evaluator_status: str
    repair_status: str

    failure_family: str | None
    failure_code: str | None

    verified_cost_usd: float | None
    wall_clock_seconds: float

    source_commit: str
    experiment_contract_hash: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)
