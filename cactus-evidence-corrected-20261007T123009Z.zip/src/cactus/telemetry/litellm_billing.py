"""Read-only LiteLLM spend-log collection with secret-safe evidence."""

from __future__ import annotations

import json
import base64
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from urllib import error, parse, request


HttpGet = Callable[[str, dict[str, str], int], tuple[int, bytes]]


def _http_get(url: str, headers: dict[str, str], timeout: int) -> tuple[int, bytes]:
    req = request.Request(url, method="GET", headers=headers)
    try:
        with request.urlopen(req, timeout=timeout) as response:
            return int(response.status), response.read()
    except error.HTTPError as exc:
        return int(exc.code), b""


def _parse_time(value: object) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _in_window(record: dict[str, Any], start: datetime, end: datetime) -> bool:
    for field in ("startTime", "start_time", "created_at", "timestamp"):
        parsed = _parse_time(record.get(field))
        if parsed is not None:
            return start <= parsed <= end
    return False


def _database_wall_time(value: datetime, database_timezone: str) -> str:
    """Format an instant as the wall time stored in a naive PostgreSQL column."""
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(ZoneInfo(database_timezone)).replace(tzinfo=None).isoformat(sep=" ")


def collect_spend_logs(
    *,
    endpoint: str,
    api_key: str,
    started_at: str,
    finished_at: str,
    http_get: HttpGet = _http_get,
) -> dict[str, Any]:
    """Collect a redacted, time-windowed LiteLLM billing snapshot.

    The complete response is never persisted. API keys, hashes, prompts and
    completions are intentionally excluded from the returned evidence.
    """
    start = _parse_time(started_at)
    end = _parse_time(finished_at)
    if start is None or end is None:
        return {"status": "invalid_window", "source": "litellm_spend_logs", "started_at": started_at, "finished_at": finished_at}
    # LiteLLM's spend API accepts calendar dates, not RFC 3339 instants. Ask
    # for detailed records so the existing UTC-window filter can exclude calls
    # outside this run on either boundary day.
    query = parse.urlencode({"start_date": start.date().isoformat(), "end_date": end.date().isoformat(), "summarize": "false"})
    url = endpoint.rstrip("?") + ("&" if "?" in endpoint else "?") + query
    headers = {"Authorization": "Bearer " + api_key}
    status_code, body = http_get(url, headers, 30)
    base = {"source": "litellm_spend_logs", "endpoint": endpoint, "started_at": started_at, "finished_at": finished_at, "http_status": status_code}
    if status_code < 200 or status_code >= 300:
        return {**base, "status": "unavailable"}
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {**base, "status": "invalid_response"}
    records = payload.get("data", payload) if isinstance(payload, dict) else payload
    if not isinstance(records, list):
        records = []
    query_mode = "date_range"
    # Some LiteLLM versions return an empty list for a detailed date-range
    # query even though the same authorized endpoint exposes records without
    # query parameters. Retry read-only and filter the full response locally;
    # never treat an empty response as zero cost.
    if not records:
        fallback_status, fallback_body = http_get(endpoint.rstrip("?"), headers, 30)
        if fallback_status < 200 or fallback_status >= 300:
            return {**base, "http_status": fallback_status, "status": "unavailable", "query_mode": "full_fallback"}
        try:
            fallback_payload = json.loads(fallback_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {**base, "status": "invalid_response", "query_mode": "full_fallback"}
        records = fallback_payload.get("data", fallback_payload) if isinstance(fallback_payload, dict) else fallback_payload
        if not isinstance(records, list):
            records = []
        query_mode = "full_fallback"
    matched = [record for record in records if isinstance(record, dict) and _in_window(record, start, end)]
    if not matched and query_mode == "full_fallback":
        # SpendLogs writes asynchronously on the gateway.  In practice the
        # record can arrive tens of seconds after the model response, so a
        # single short retry creates false ``no_records`` failures.  Poll for
        # at most 30 seconds.  Test doubles are queried once to keep unit tests
        # deterministic and fast.
        retry_count = 6 if http_get is _http_get else 1
        # The gateway timestamps a delayed SpendLog at write time, which can
        # be after the local request window has closed.  Permit a bounded
        # post-window grace period while polling; the lower bound remains the
        # request start, so prior runs cannot be attributed.
        retry_end = end + timedelta(seconds=90)
        for retry_index in range(retry_count):
            time.sleep(5 if retry_index else 2)
            retry_status, retry_body = http_get(endpoint.rstrip("?"), headers, 30)
            if not (200 <= retry_status < 300):
                continue
            try:
                retry_payload = json.loads(retry_body.decode("utf-8"))
                retry_records = retry_payload.get("data", retry_payload) if isinstance(retry_payload, dict) else retry_payload
                if isinstance(retry_records, list):
                    records = retry_records
                    matched = [record for record in records if isinstance(record, dict) and _in_window(record, start, retry_end)]
                    status_code = retry_status
                    if matched:
                        break
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
    spend_values = [record.get("spend", record.get("cost")) for record in matched]
    spends = [float(value) for value in spend_values if isinstance(value, (int, float))]
    token_values = [record.get("total_tokens", record.get("totalTokens")) for record in matched]
    tokens = [int(value) for value in token_values if isinstance(value, (int, float))]
    return {
        **base,
        "status": "verified_cost" if spends else ("verified_usage_only" if matched else "no_records"),
        "query_mode": query_mode,
        "record_count": len(records),
        "matched_record_count": len(matched),
        "total_tokens": sum(tokens) if tokens else None,
        "total_spend": sum(spends) if spends else None,
        "currency": "USD" if spends else None,
        "fields_retained": ["startTime", "model_group", "total_tokens", "spend", "request_duration_ms"],
    }


def collect_spend_logs_postgres_ssh(
    *,
    ssh_host: str,
    ssh_username: str,
    ssh_password: str,
    key_alias: str | None = None,
    user_id: str | None = None,
    request_ids: tuple[str, ...] = (),
    model_group: str | None = None,
    started_at: str,
    finished_at: str,
    database: str = "litellm",
    database_timezone: str = "UTC",
    ssh_port: int = 22,
) -> dict[str, Any]:
    """Collect key-scoped spend evidence from LiteLLM's PostgreSQL store.

    The query runs on the LiteLLM host through SSH and only returns aggregate
    counts/tokens/cost.  The raw token, prompt, completion, and request rows
    never leave PostgreSQL.  A deployment may scope records either by a
    verification-token alias or by the gateway's authenticated ``user``.  The
    latter is required for installations where master-key traffic is recorded
    with an internal ``api_key`` value that cannot be resolved through
    ``LiteLLM_VerificationToken``.
    """
    start = _parse_time(started_at)
    end = _parse_time(finished_at)
    if bool(key_alias) == bool(user_id):
        return {
            "source": "litellm_postgres_spend_logs",
            "status": "invalid_scope",
            "reason": "exactly_one_of_key_alias_or_user_id_required",
            "started_at": started_at,
            "finished_at": finished_at,
        }
    scope = "key_alias" if key_alias else "user_id"
    base = {
        "source": "litellm_postgres_spend_logs",
        "scope": scope,
        "started_at": started_at,
        "finished_at": finished_at,
        "request_id_count": len(request_ids),
    }
    if key_alias:
        base["key_alias"] = key_alias
    if user_id:
        base["user_id"] = user_id
    if model_group:
        base["model_group"] = model_group
    if start is None or end is None:
        return {**base, "status": "invalid_window"}
    try:
        ZoneInfo(database_timezone)
    except (ZoneInfoNotFoundError, ValueError):
        return {**base, "status": "invalid_database_timezone"}
    base["database_timezone"] = database_timezone
    try:
        import paramiko  # type: ignore[import-not-found]
    except ImportError:
        return {**base, "status": "unavailable", "reason": "paramiko_missing"}

    # PostgreSQL spend records may be flushed several seconds after the model
    # call returns.  A single query immediately after eval can report
    # ``no_records`` even though the spend was real, so retry with bounded
    # backoff (mirroring the HTTP billing poll loop) before declaring
    # ``no_records``.  Test doubles and the paramiko_missing branch return
    # immediately, so this only adds latency in the live SSH path.
    import time as _time
    retry_attempts = 6
    retry_end = end if request_ids else end + timedelta(seconds=90)
    last_result: dict[str, Any] = {**base, "status": "unavailable", "reason": "postgres_query_failed"}
    for attempt in range(retry_attempts):
        if attempt:
            _time.sleep(5 if attempt else 2)
        result = _collect_postgres_ssh_once(
            paramiko=paramiko,
            ssh_host=ssh_host,
            ssh_port=ssh_port,
            ssh_username=ssh_username,
            ssh_password=ssh_password,
            database=database,
            key_alias=key_alias,
            user_id=user_id,
            request_ids=request_ids,
            model_group=model_group,
            database_timezone=database_timezone,
            start=start,
            end=retry_end if attempt else end,
            base=base,
        )
        last_result = result
        status = result.get("status")
        if status in {"verified_cost", "verified_usage_only"}:
            return result
        if status not in {"no_records", "pending_records"}:
            # Any other status (unavailable, invalid_*, paramiko_missing)
            # is deterministic and would not change on retry.
            return result
    return last_result


def _collect_postgres_ssh_once(
    *,
    paramiko: Any,
    ssh_host: str,
    ssh_port: int,
    ssh_username: str,
    ssh_password: str,
    database: str,
    key_alias: str | None,
    user_id: str | None,
    model_group: str | None,
    database_timezone: str,
    start: Any,
    end: Any,
    base: dict[str, Any],
    request_ids: tuple[str, ...] = (),
) -> dict[str, Any]:

    def sql_literal(value: str) -> str:
        return "'" + value.replace("'", "''") + "'"

    start_sql = _database_wall_time(start, database_timezone)
    end_sql = _database_wall_time(end, database_timezone)
    key_cte = ""
    if key_alias:
        key_cte = f'''WITH selected_key AS (
    SELECT token FROM "LiteLLM_VerificationToken"
    WHERE key_alias = {sql_literal(key_alias)}
    ORDER BY created_at DESC NULLS LAST LIMIT 1
)
'''
    scope_clauses = [
        "api_key = (SELECT token FROM selected_key)" if key_alias else f'"user" = {sql_literal(user_id or "")}',
    ]
    if model_group:
        scope_clauses.append(f"model_group = {sql_literal(model_group)}")
    if request_ids:
        ids = ", ".join(sql_literal(value) for value in request_ids)
        scope_clauses.append(f"request_id IN ({ids})")
    else:
        scope_clauses.extend((
            f'"startTime" >= {sql_literal(start_sql)}::timestamp',
            f'"startTime" <= {sql_literal(end_sql)}::timestamp',
        ))
    query = f'''{key_cte}
SELECT count(*)::bigint,
       coalesce(sum(spend), 0)::double precision,
       coalesce(sum(total_tokens), 0)::bigint,
       count(DISTINCT api_key)::bigint
FROM "LiteLLM_SpendLogs"
WHERE {' AND '.join(scope_clauses)};'''
    encoded = base64.b64encode(query.encode("utf-8")).decode("ascii")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=ssh_host,
            port=ssh_port,
            username=ssh_username,
            password=ssh_password,
            timeout=20,
            banner_timeout=20,
            auth_timeout=20,
        )
        command = (
            f"echo {encoded} | base64 -d | "
            f"sudo -n -u postgres psql -d {database} -P pager=off -F '|' -Atf -"
        )
        stdin, stdout, stderr = client.exec_command(command, timeout=30)
        output = stdout.read().decode("utf-8", errors="replace").strip()
        error_output = stderr.read().decode("utf-8", errors="replace").strip()
    except Exception as exc:  # pragma: no cover - host integration path
        return {**base, "status": "unavailable", "reason": type(exc).__name__}
    finally:
        client.close()
    if error_output or not output:
        return {**base, "status": "unavailable", "reason": "postgres_query_failed"}
    try:
        record_count, total_spend, total_tokens, distinct_keys = output.split("|", 3)
        records = int(record_count)
        spend = float(total_spend)
        tokens = int(total_tokens)
        key_count = int(distinct_keys)
    except (TypeError, ValueError):
        return {**base, "status": "invalid_response", "reason": "unexpected_postgres_result"}
    if key_count not in {0, 1}:
        return {**base, "status": "invalid_response", "reason": "multiple_key_hashes"}
    if request_ids and records < len(request_ids):
        return {**base, "status": "pending_records", "record_count": records}
    if request_ids and records > len(request_ids):
        return {**base, "status": "invalid_response", "reason": "duplicate_request_ids"}
    return {
        **base,
        "status": "verified_cost" if records and spend else ("verified_usage_only" if records else "no_records"),
        "record_count": records,
        "matched_record_count": records,
        "total_tokens": tokens if records else None,
        "total_spend": spend if records and spend else None,
        "currency": "USD" if records and spend else None,
        "fields_retained": ["startTime", "model_group", "total_tokens", "spend", "request_duration_ms", "api_key_scope"],
    }
