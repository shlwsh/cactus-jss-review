"""Lexical-only BM25 baseline with no graph or CACTUS structural signals."""

from __future__ import annotations

from collections.abc import Sequence

from cactus.domain.models import ContextUnit
from cactus.retrieval.lexical import lexical_candidates
from cactus.retrieval.static_density import select_static_density
from cactus.task.parser import parse_task


def select_lexical_bm25(units: Sequence[ContextUnit], query: str, *, budget: int) -> tuple[str, ...]:
    intent = parse_task(query)
    scores = dict(lexical_candidates(units, intent))
    return select_static_density(units, scores, budget=budget).selected_unit_ids
