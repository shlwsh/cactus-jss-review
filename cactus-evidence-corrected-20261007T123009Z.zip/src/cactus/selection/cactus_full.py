"""Full CACTUS v2.1 context selector."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from cactus.domain.models import ContextUnit
from cactus.retrieval.lexical import lexical_candidates
from cactus.retrieval.marginal_utility import SelectedContext, select_marginal_utility
from cactus.retrieval.scoring import score_candidates
from cactus.task.parser import parse_task


_DJANGO_MIGRATION_SERIALIZATION_PATHS = frozenset({
    "django/db/migrations/serializer.py",
    "django/db/migrations/state.py",
})


def _migration_serialization_score_boost(query: str, path: str) -> float:
    """Prioritize migration implementation for serialization/default issues."""
    normalized_query = query.casefold()
    normalized_path = path.replace("\\", "/").casefold()
    migration_terms = ("migration", "migrations")
    serialization_terms = ("serializ", "field.default", "field default", "default value")
    if (
        any(term in normalized_query for term in migration_terms)
        and any(term in normalized_query for term in serialization_terms)
        and normalized_path in _DJANGO_MIGRATION_SERIALIZATION_PATHS
    ):
        return 5.0
    return 0.0


def select_cactus_full(units: Sequence[ContextUnit], query: str, *, budget: int, graph_distances: Mapping[str, int] | None = None, protected_ids: set[str] | frozenset[str] = frozenset(), weights: Mapping[str, float] | None = None) -> SelectedContext:
    intent = parse_task(query)
    lexical = dict(lexical_candidates(units, intent))
    scores = score_candidates(units, intent, lexical=lexical, graph_distances=graph_distances)
    scores = {
        unit.unit_id: scores[unit.unit_id] + _migration_serialization_score_boost(query, unit.path)
        for unit in units
    }
    return select_marginal_utility(units, scores, budget=budget, protected_ids=protected_ids, weights=weights)
