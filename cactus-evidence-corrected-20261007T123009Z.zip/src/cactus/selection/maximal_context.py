"""Deterministic maximal-context baseline."""

from __future__ import annotations

from collections.abc import Sequence

from cactus.domain.models import ContextUnit


def _matches_mentioned(path: str, mentioned: set[str]) -> bool:
    """Return True when ``path`` aligns with any ``mentioned`` reference.

    Strict equality alone misses the common SWE-bench issue pattern where the
    model output (and the issue itself) include a leading ``<repo>/`` segment
    that the repository snapshot drops (e.g. issue refers to
    ``astropy/modeling/separable.py`` while ``ContextUnit.path`` is
    ``modeling/separable.py``).  Matching by basename plus at least one common
    parent directory component avoids promoting generic files such as
    ``__init__.py`` into the priority group.
    """

    if path in mentioned:
        return True
    path_parts = path.replace("\\", "/").split("/")
    path_basename = path_parts[-1]
    if not path_basename or path_basename == "__init__.py":
        return False
    path_parents = {part for part in path_parts[:-1] if part}
    for reference in mentioned:
        ref_norm = reference.replace("\\", "/")
        ref_basename = ref_norm.rsplit("/", 1)[-1]
        if ref_basename != path_basename or ref_basename == "__init__.py":
            continue
        ref_parents = {part for part in ref_norm.split("/")[:-1] if part}
        if path_parents & ref_parents:
            return True
    return False


def select_maximal_context(units: Sequence[ContextUnit], *, budget: int, mentioned_files: Sequence[str] = ()) -> tuple[str, ...]:
    if budget < 0:
        raise ValueError("budget must be non-negative")
    mentioned = set(mentioned_files)
    ordered = sorted(units, key=lambda unit: (0 if _matches_mentioned(unit.path, mentioned) else 1, 0 if unit.kind.startswith("test") else 1, unit.path, unit.start_line or 0, unit.unit_id))
    selected: list[str] = []
    remaining = budget
    for unit in ordered:
        if unit.token_count <= remaining:
            selected.append(unit.unit_id)
            remaining -= unit.token_count
    return tuple(selected)
