"""Deterministic validation for candidate patches before evaluation."""

from __future__ import annotations

import ast
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Callable, Sequence

from cactus.context.responsibility import ResponsibilityChain


class SQLValidationState(StrEnum):
    PASSED = "passed"
    FAILED = "failed"
    UNAVAILABLE = "unavailable"


@dataclass(frozen=True, slots=True)
class CandidateValidation:
    passed: bool
    rejection_class: str | None
    checks: dict[str, str]
    changed_paths: tuple[str, ...]
    sql_validation: SQLValidationState


CommandRunner = Callable[..., subprocess.CompletedProcess[bytes]]


def _copy_tracked_repository(
    repo_root: Path,
    candidate_root: Path,
    *,
    runner: CommandRunner,
    selected_paths: tuple[str, ...] | None = None,
) -> None:
    """Materialize the tracked checkout without copying caches or Git metadata."""
    listed = runner(
        ["git", "ls-files", "-z"],
        cwd=repo_root,
        capture_output=True,
        check=False,
        timeout=30,
    )
    if listed.returncode:
        raise ValueError("source_mismatch: tracked-file inventory failed")
    raw = listed.stdout
    encoded = raw.encode("utf-8") if isinstance(raw, str) else raw
    for item in encoded.split(b"\0"):
        if not item:
            continue
        try:
            relative_text = item.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("source_mismatch: tracked path is not UTF-8") from exc
        if selected_paths is not None and relative_text not in selected_paths:
            continue
        relative = Path(relative_text)
        source = (repo_root / relative).resolve()
        if not source.is_relative_to(repo_root.resolve()):
            raise ValueError("source_mismatch: tracked path escapes the repository")
        if not source.is_file():
            # Gitlinks and other non-file entries must not pull external data.
            continue
        target = candidate_root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def _changed_paths(patch_text: str) -> tuple[str, ...]:
    paths = []
    for match in re.finditer(r"^diff --git a/(\S+) b/(\S+)$", patch_text, flags=re.MULTILINE):
        if match.group(1) != match.group(2):
            raise ValueError("source_mismatch: renames are not supported by source-owned validation")
        path = match.group(2).replace("\\", "/")
        relative = Path(path)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("source_mismatch: unsafe patch path")
        paths.append(path)
    if not paths:
        raise ValueError("noop: candidate has no changed paths")
    return tuple(dict.fromkeys(paths))


def _reject_media_operand_reversal(patch_text: str) -> None:
    removed = {re.sub(r"\s+", "", line[1:]) for line in patch_text.splitlines() if line.startswith("-") and not line.startswith("---")}
    added = {re.sub(r"\s+", "", line[1:]) for line in patch_text.splitlines() if line.startswith("+") and not line.startswith("+++")}
    reversals = (
        ("self+other", "other+self"),
        ("other+self", "self+other"),
    )
    if any(
        any(old in line for line in removed) and any(new in line for line in added)
        for old, new in reversals
    ):
        raise ValueError("semantic_incomplete: simple Media operand reversal is forbidden")
    for old_line in removed:
        match = re.search(r"self\.(\w+)\+other\.\1", old_line)
        if not match:
            continue
        attribute = re.escape(match.group(1))
        if any(
            re.search(rf"(?:list\()?other\.{attribute}\)?\+self\.{attribute}", new_line)
            for new_line in added
        ):
            raise ValueError("semantic_incomplete: simple Media operand reversal is forbidden")


def _responsibility_check(paths: Sequence[str], chain: ResponsibilityChain | None) -> None:
    if chain is None or chain.fallback:
        return
    allowed = {target.path.replace("\\", "/") for target in (*chain.primary, *chain.secondary)}
    allowed_dirs = set()
    for p in allowed:
        if "/" in p:
            parts = p.split("/")
            for depth in range(max(1, len(parts) - 2), len(parts)):
                allowed_dirs.add("/".join(parts[:depth]))

    def is_allowed_path(path: str) -> bool:
        norm = path.replace("\\", "/")
        if norm in allowed:
            return True
        if any(part.startswith(("test", "doc")) for part in norm.split("/")):
            return False
        if "/" in norm:
            parts = norm.split("/")
            for depth in range(max(1, len(parts) - 2), len(parts)):
                if "/".join(parts[:depth]) in allowed_dirs:
                    return True
        return False

    if any(not is_allowed_path(path) for path in paths):
        raise ValueError("wrong_module: candidate changes a path outside the responsibility chain")


def _run_sql_validation(
    command: Sequence[str] | None,
    *,
    cwd: Path,
    runner: CommandRunner,
) -> SQLValidationState:
    if not command:
        return SQLValidationState.UNAVAILABLE
    result = runner(list(command), cwd=cwd, capture_output=True, check=False, timeout=120)
    return SQLValidationState.PASSED if result.returncode == 0 else SQLValidationState.FAILED


def validate_candidate_patch(
    patch_text: str,
    repo_root: Path,
    *,
    responsibility: ResponsibilityChain | None = None,
    scratch_root: Path | None = None,
    sql_validation_command: Sequence[str] | None = None,
    command_runner: CommandRunner = subprocess.run,
) -> CandidateValidation:
    """Validate applicability, syntax, responsibility, semantics and optional SQL."""
    checks: dict[str, str] = {}
    paths: tuple[str, ...] = ()
    sql_state = SQLValidationState.UNAVAILABLE
    try:
        paths = _changed_paths(patch_text)
        _reject_media_operand_reversal(patch_text)
        checks["semantic_guard"] = "passed"
        _responsibility_check(paths, responsibility)
        checks["responsibility"] = "passed" if responsibility and not responsibility.fallback else "unavailable"
        apply_check = command_runner(
            ["git", "apply", "--check", "--whitespace=nowarn"],
            input=patch_text.encode("utf-8"),
            cwd=repo_root,
            capture_output=True,
            check=False,
            timeout=30,
        )
        if apply_check.returncode:
            raise ValueError("source_mismatch: git apply --check failed")
        checks["git_apply_check"] = "passed"
        scratch_parent = (scratch_root or repo_root.resolve().parent).resolve()
        scratch_parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="cactus-candidate-", dir=scratch_parent) as directory:
            candidate_root = Path(directory)
            # Static AST/compile validation reads only patched files. External
            # SQL validation still needs the complete tracked repository.
            _copy_tracked_repository(
                repo_root, candidate_root, runner=command_runner,
                selected_paths=None if sql_validation_command else paths,
            )
            for relative_text in paths:
                if not (candidate_root / relative_text).is_file():
                    raise ValueError("source_mismatch: changed source file is unavailable")
            applied = command_runner(
                ["git", "apply", "--whitespace=nowarn"],
                input=patch_text.encode("utf-8"),
                cwd=candidate_root,
                capture_output=True,
                check=False,
                timeout=30,
            )
            if applied.returncode:
                raise ValueError("source_mismatch: patch failed in isolated candidate copy")
            for relative_text in paths:
                if not relative_text.endswith(".py"):
                    continue
                content = (candidate_root / relative_text).read_text(encoding="utf-8")
                try:
                    tree = ast.parse(content, filename=relative_text)
                    compile(tree, relative_text, "exec")
                except SyntaxError as exc:
                    raise ValueError(f"syntax_error: {relative_text}:{exc.lineno}") from exc
            checks["python_compile"] = "passed"
            sql_state = _run_sql_validation(
                sql_validation_command,
                cwd=candidate_root,
                runner=command_runner,
            )
            checks["sql_validation"] = sql_state.value
            if sql_state is SQLValidationState.FAILED:
                raise ValueError("semantic_incomplete: frozen SQL validation command failed")
        return CandidateValidation(True, None, checks, paths, sql_state)
    except ValueError as exc:
        reason = str(exc)
        rejection_class = reason.split(":", 1)[0] if ":" in reason else "semantic_incomplete"
        checks.setdefault("failure", reason)
        return CandidateValidation(False, rejection_class, checks, paths, sql_state)
