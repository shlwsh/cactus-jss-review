"""Patch Application Checker and PatchArtifact assembly.

Implements Phase 2 (TASK-004) & Section 13 of CACTUS Rectification Plan v2.
"""

from __future__ import annotations

import hashlib
import subprocess
from dataclasses import dataclass
from pathlib import Path

from cactus.patching.normalizer import normalize_patch
from cactus.patching.parser import extract_diff_block


def _sha256(text: str | None) -> str | None:
    if text is None:
        return None
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class PatchArtifact:
    raw_text: str
    raw_hash: str
    parsed_diff: str | None
    parsed_hash: str | None
    normalized_diff: str | None
    normalized_hash: str | None
    normalization_actions: tuple[str, ...]
    semantic_lines_changed: bool
    apply_status: str  # "APPLIED", "APPLY_FAILED", "AMBIGUOUS_ALIGNMENT", "NO_DIFF_FOUND"


def check_patch_apply(patch_text: str, repo_root: Path) -> bool:
    """Run `git apply --check` in the repository directory, with non-git fallback."""
    if not patch_text or not patch_text.strip():
        return False
    try:
        proc = subprocess.run(
            ["git", "apply", "--check", "--unsafe-paths", "--whitespace=nowarn"],
            input=patch_text,
            cwd=str(repo_root),
            text=True,
            capture_output=True,
            timeout=15,
        )
        if proc.returncode == 0:
            return True
        if not (repo_root / ".git").is_dir() or "not a git repository" in (proc.stderr or "").lower():
            # Fallback: in non-git directories (e.g. unit test mocks), check if target files exist and removed lines match
            from cactus.patching.normalizer import semantic_removed_lines
            from cactus.patching.parser import extract_target_files
            targets = extract_target_files(patch_text)
            if not targets:
                return False
            for t in targets:
                fpath = repo_root / t
                if not fpath.is_file():
                    return False
                content = fpath.read_text(encoding="utf-8", errors="replace")
                for rem in semantic_removed_lines(patch_text):
                    if rem not in content:
                        return False
            return True
        return False
    except Exception:
        return False


def process_patch(raw_text: str, repo_root: Path) -> PatchArtifact:
    """End-to-end pipeline: Raw LLM Output -> Parse Diff -> Normalize -> Check Apply."""
    raw_hash = _sha256(raw_text) or ""
    parsed = extract_diff_block(raw_text)
    parsed_hash = _sha256(parsed)

    if not parsed:
        return PatchArtifact(
            raw_text=raw_text,
            raw_hash=raw_hash,
            parsed_diff=None,
            parsed_hash=None,
            normalized_diff=None,
            normalized_hash=None,
            normalization_actions=(),
            semantic_lines_changed=False,
            apply_status="NO_DIFF_FOUND",
        )

    norm_res = normalize_patch(parsed, repo_root)
    normalized_diff = norm_res.normalized_diff or parsed
    normalized_hash = _sha256(normalized_diff)

    if norm_res.status == "AMBIGUOUS_ALIGNMENT":
        apply_status = "AMBIGUOUS_ALIGNMENT"
    elif norm_res.status == "SEMANTIC_VIOLATION":
        apply_status = "APPLY_FAILED"
    else:
        can_apply = check_patch_apply(normalized_diff, repo_root)
        apply_status = "APPLIED" if can_apply else "APPLY_FAILED"

    return PatchArtifact(
        raw_text=raw_text,
        raw_hash=raw_hash,
        parsed_diff=parsed,
        parsed_hash=parsed_hash,
        normalized_diff=normalized_diff,
        normalized_hash=normalized_hash,
        normalization_actions=norm_res.actions,
        semantic_lines_changed=(not norm_res.is_semantically_identical),
        apply_status=apply_status,
    )
