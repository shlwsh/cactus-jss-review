"""Patch Normalizer: Deterministic context alignment with semantic preservation guarantee.

Implements Phase 2 (TASK-004) & Section 13 of CACTUS Rectification Plan v2.
Rules:
1. Only unique matches (matches == 1) are aligned.
2. If matches != 1, flags AMBIGUOUS_ALIGNMENT (no nearest-line guessing!).
3. Semantic invariance: added and removed line multisets MUST be preserved exactly.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


class SemanticViolationError(Exception):
    """Raised when patch normalization changes semantic addition/deletion lines."""
    pass


def semantic_added_lines(diff_text: str) -> list[str]:
    """Extract semantic addition lines (starts with '+' but not '+++')."""
    return [l[1:] for l in diff_text.splitlines() if l.startswith("+") and not l.startswith("+++ ")]


def semantic_removed_lines(diff_text: str) -> list[str]:
    """Extract semantic deletion lines (starts with '-' but not '---')."""
    return [l[1:] for l in diff_text.splitlines() if l.startswith("-") and not l.startswith("--- ")]


@dataclass(frozen=True, slots=True)
class NormalizationResult:
    normalized_diff: str | None
    status: str  # "APPLIED", "ALIGNMENT_SUCCESS", "AMBIGUOUS_ALIGNMENT", "FILE_NOT_FOUND", "SEMANTIC_VIOLATION", "NO_CHANGE"
    actions: tuple[str, ...]
    is_semantically_identical: bool


def normalize_patch(patch: str, repo_root: Path) -> NormalizationResult:
    """Align hunk starting lines to match repository files with semantic invariance checks."""
    if not patch or not patch.strip():
        return NormalizationResult(None, "EMPTY_PATCH", (), True)

    raw_added = semantic_added_lines(patch)
    raw_removed = semantic_removed_lines(patch)

    lines = patch.splitlines()
    rebuilt: list[str] = []
    actions: list[str] = []
    current_file_lines: list[str] | None = None
    has_ambiguity = False

    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("--- a/"):
            rel_path = line[6:].strip()
            fpath = repo_root / rel_path
            if fpath.is_file():
                try:
                    current_file_lines = fpath.read_text(encoding="utf-8", errors="replace").splitlines()
                except Exception:
                    current_file_lines = None
            else:
                current_file_lines = None
            rebuilt.append(line)
            i += 1
        elif line.startswith("@@ ") and current_file_lines is not None:
            m = re.match(r"^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@(.*)$", line)
            if not m:
                rebuilt.append(line)
                i += 1
                continue

            tail = m.group(5)
            hunk_body: list[str] = []
            j = i + 1
            while j < len(lines) and not lines[j].startswith(("@@ ", "diff --git ", "--- ")):
                hunk_body.append(lines[j])
                j += 1

            old_ctx = [l[1:] for l in hunk_body if l.startswith((" ", "-"))]
            new_cnt = sum(1 for l in hunk_body if l.startswith((" ", "+")))
            chg_indices = [idx for idx, l in enumerate(hunk_body) if l.startswith(("+", "-"))]

            if chg_indices:
                first_chg = chg_indices[0]
                last_chg = chg_indices[-1]
                has_leading_ctx = any(l.startswith(" ") for l in hunk_body[:first_chg])
                has_trailing_ctx = any(l.startswith(" ") for l in hunk_body[last_chg + 1:])
            else:
                has_leading_ctx = False
                has_trailing_ctx = False

            aligned_success = False

            # Sequence matching on context lines
            if old_ctx and (has_leading_ctx or has_trailing_ctx):
                seq_len = len(old_ctx)
                candidates: list[int] = []
                for idx in range(len(current_file_lines) - seq_len + 1):
                    if current_file_lines[idx:idx + seq_len] == old_ctx:
                        candidates.append(idx + 1)

                if len(candidates) == 1:
                    real_start = candidates[0]
                    if real_start != int(m.group(1)):
                        rebuilt.append(f"@@ -{real_start},{len(old_ctx)} +{real_start},{new_cnt} @@{tail}")
                        rebuilt.extend(hunk_body)
                        actions.append(f"unique_align_hunk:L{real_start}")
                        aligned_success = True
                elif len(candidates) > 1:
                    # Multiple occurrences in target file -> Ambiguous alignment!
                    has_ambiguity = True
                    actions.append(f"ambiguous_match_count:{len(candidates)}")

            if not aligned_success:
                rebuilt.append(line)
                rebuilt.extend(hunk_body)

            i = j
        else:
            rebuilt.append(line)
            i += 1

    normalized_str = "\n".join(rebuilt)
    if patch.endswith("\n") and not normalized_str.endswith("\n"):
        normalized_str += "\n"

    # Semantic invariance check
    norm_added = semantic_added_lines(normalized_str)
    norm_removed = semantic_removed_lines(normalized_str)

    if raw_added != norm_added or raw_removed != norm_removed:
        return NormalizationResult(
            normalized_str,
            "SEMANTIC_VIOLATION",
            tuple(actions) + ("semantic_invariance_violated",),
            False,
        )

    if has_ambiguity:
        return NormalizationResult(
            normalized_str,
            "AMBIGUOUS_ALIGNMENT",
            tuple(actions),
            True,
        )

    status = "ALIGNMENT_SUCCESS" if actions else "NO_CHANGE"
    return NormalizationResult(normalized_str, status, tuple(actions), True)
