"""Parser for unified diffs from raw LLM responses.

Implements Phase 2 (TASK-004) of CACTUS Rectification Plan v2.
"""

from __future__ import annotations

import re


def extract_diff_block(raw_text: str) -> str | None:
    """Extract unified diff from model response, stripping markdown code fences."""
    if not raw_text or not raw_text.strip():
        return None

    # Pattern 1: fenced diff block
    fenced_match = re.search(r"```(?:diff|patch)?\s*\n(diff --git [\s\S]*?)```", raw_text)
    if fenced_match:
        return fenced_match.group(1).strip()

    # Pattern 2: naked diff starting with diff --git
    naked_match = re.search(r"(diff --git a/.*)", raw_text, flags=re.DOTALL)
    if naked_match:
        content = naked_match.group(1).strip()
        # If followed by another markdown code fence, truncate
        if "```" in content:
            content = content.split("```")[0].strip()
        return content

    # Pattern 3: starts with --- a/ and +++ b/
    hunk_match = re.search(r"(--- a/[\s\S]*?\n\+\+\+ b/[\s\S]*)", raw_text)
    if hunk_match:
        content = hunk_match.group(1).strip()
        if "```" in content:
            content = content.split("```")[0].strip()
        return content

    return None


def extract_target_files(diff_text: str) -> list[str]:
    """Extract list of modified file paths (relative) from unified diff."""
    paths: list[str] = []
    for line in diff_text.splitlines():
        if line.startswith("--- a/"):
            path = line[6:].strip()
            if path and path != "/dev/null":
                paths.append(path)
    return sorted(set(paths))
