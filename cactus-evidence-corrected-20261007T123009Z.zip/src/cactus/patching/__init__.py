"""CACTUS Patching Subsystem: Parser, Normalizer, and Apply Checker."""

from .apply_check import PatchArtifact, check_patch_apply, process_patch
from .normalizer import NormalizationResult, normalize_patch, semantic_added_lines, semantic_removed_lines
from .parser import extract_diff_block, extract_target_files

__all__ = [
    "NormalizationResult",
    "PatchArtifact",
    "check_patch_apply",
    "extract_diff_block",
    "extract_target_files",
    "normalize_patch",
    "process_patch",
    "semantic_added_lines",
    "semantic_removed_lines",
]
