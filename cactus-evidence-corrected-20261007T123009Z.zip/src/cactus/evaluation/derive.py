"""Deterministic derivation from an immutable raw result payload."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from cactus.governance.schema import validate_raw_result
from .stats import descriptive


def derive_stats(raw: dict[str, Any], values_key: str = "values") -> dict[str, Any]:
    errors = validate_raw_result(raw)
    if errors:
        raise ValueError("invalid raw result: " + "; ".join(errors))
    values = raw["data"].get(values_key)
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)) or not all(isinstance(value, (int, float)) for value in values):
        raise ValueError(f"data.{values_key} must be a numeric sequence")
    return {"schema_version": "2.0", "run_id": raw["run_id"], "experiment_id": raw["experiment_id"], "metric": values_key, "statistics": descriptive([float(value) for value in values])}
