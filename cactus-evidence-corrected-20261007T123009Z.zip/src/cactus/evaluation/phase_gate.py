"""Fail-closed gates for formal Phase C pilot evidence."""

from __future__ import annotations

import json
import math
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path

from cactus.runner.bundle_validator import validate_bundle


@dataclass(frozen=True, slots=True)
class PilotGateSummary:
    expected_task_count: int
    observed_task_count: int
    evaluator_validity_rate: float | None
    sealed_bundle_failure_count: int
    billing_missing_count: int
    budget_violation_count: int
    duplicate_task_count: int
    status: str
    reasons: tuple[str, ...]

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


def _json(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _task_id(bundle: Path, manifest: dict[str, object], raw: dict[str, object]) -> str:
    data = raw.get("data") if isinstance(raw.get("data"), dict) else {}
    task = data.get("task_id")
    if isinstance(task, str) and task:
        return task
    task = manifest.get("task_id") or manifest.get("instance_id")
    if isinstance(task, str) and task:
        return task
    config = _json(bundle / "resolved_config.json")
    config_task = config.get("task") if isinstance(config.get("task"), dict) else {}
    task = config_task.get("task_id")
    return str(task) if task else ""


def _evaluation(bundle: Path) -> dict[str, object] | None:
    reports = sorted((bundle / "evaluation").glob("*.json")) if (bundle / "evaluation").is_dir() else []
    if len(reports) != 1:
        return None
    return _json(reports[0])


def _billing_missing(bundle: Path) -> bool:
    path = bundle / "billing" / "litellm_spend.json"
    if not path.is_file():
        return True
    return _json(path).get("status") not in {"verified_cost", "verified_usage_only"}


def _bundle_rows(runs_root: Path, experiment_id: str | None = None) -> Iterable[tuple[Path, dict[str, object], dict[str, object], dict[str, object] | None]]:
    if not runs_root.is_dir():
        return
    for bundle in sorted(path for path in runs_root.iterdir() if path.is_dir() and path.name.startswith("RUN-")):
        manifest = _json(bundle / "run_manifest.json")
        if not manifest:
            continue
        if experiment_id and manifest.get("experiment_id") != experiment_id:
            continue
        raw = _json(bundle / "raw" / "result.json")
        yield bundle, manifest, raw, _evaluation(bundle)


def _latest_rows(rows: Iterable[tuple[Path, dict[str, object], dict[str, object], dict[str, object] | None]]) -> dict[str, tuple[Path, dict[str, object], dict[str, object], dict[str, object] | None]]:
    """Return the final sealed attempt for each task.

    RUN directories are append-only, so retries must remain visible in the
    audit while gate metrics describe the protocol's final attempt.  Prefer
    the manifest timestamps and use the directory name as a deterministic
    tie-breaker for older bundles without timestamps.
    """
    latest: dict[str, tuple[tuple[str, str], tuple[Path, dict[str, object], dict[str, object], dict[str, object] | None]]] = {}
    for row in rows:
        task_id = _task_id(row[0], row[1], row[2])
        if not task_id:
            continue
        manifest = row[1]
        order = (str(manifest.get("finished_at") or manifest.get("started_at") or ""), row[0].name)
        previous = latest.get(task_id)
        if previous is None or order >= previous[0]:
            latest[task_id] = (order, row)
    return {task_id: value[1] for task_id, value in latest.items()}


def evaluate_pilot(runs_root: Path, *, expected_task_count: int, experiment_id: str | None = None) -> PilotGateSummary:
    if expected_task_count < 1:
        raise ValueError("expected_task_count must be positive")
    rows = list(_bundle_rows(runs_root, experiment_id))
    task_ids = [_task_id(bundle, manifest, raw) for bundle, manifest, raw, _ in rows]
    nonempty_ids = [task_id for task_id in task_ids if task_id]
    unique_ids = set(nonempty_ids)
    duplicate_count = len(nonempty_ids) - len(unique_ids)
    sealed_failures = sum(bool(validate_bundle(bundle)) for bundle, *_ in rows)
    latest_by_task = _latest_rows(rows)
    latest_rows = tuple(latest_by_task.values())
    billing_missing = sum(_billing_missing(bundle) for bundle, *_ in latest_rows)
    budget_violations = 0
    valid_evaluator = 0
    for _, _, raw, report in latest_rows:
        data = raw.get("data") if isinstance(raw.get("data"), dict) else {}
        budget_violations += int(bool(data.get("budget_violation")))
        if report:
            budget_violations += int(bool(report.get("budget_violation")))
            valid_evaluator += int(report.get("completed_instances", 0) or 0)
    evr = valid_evaluator / len(unique_ids) if unique_ids else None
    reasons: list[str] = []
    if len(unique_ids) != expected_task_count:
        reasons.append(f"unique task bundles {len(unique_ids)} != expected {expected_task_count}")
    if sealed_failures:
        reasons.append(f"sealed bundle failures={sealed_failures}")
    if billing_missing / max(1, len(latest_rows)) > 0.05:
        reasons.append(f"billing missing rate={billing_missing / max(1, len(latest_rows)):.3f} > 0.05")
    if budget_violations:
        reasons.append(f"budget violations={budget_violations}")
    if evr is None or not math.isfinite(evr) or evr < 0.95:
        reasons.append(f"EVR={evr if evr is not None else 'missing'} < 0.95")
    return PilotGateSummary(expected_task_count, len(unique_ids), evr, sealed_failures, billing_missing, budget_violations, duplicate_count, "PASS" if not reasons else "BLOCKED", tuple(reasons))
