"""Small dependency-free metric functions used by replay analysis."""

from __future__ import annotations

from collections.abc import Sequence, Set


def recall_at_budget(ranked_ids: Sequence[str], gold_ids: Set[str], budget: int) -> float:
    if not gold_ids:
        return 1.0
    return len(set(ranked_ids[:budget]) & gold_ids) / len(gold_ids)


def average_precision(ranked_ids: Sequence[str], gold_ids: Set[str]) -> float:
    if not gold_ids:
        return 1.0
    hits = 0
    total = 0.0
    for index, value in enumerate(ranked_ids, 1):
        if value in gold_ids:
            hits += 1
            total += hits / index
    return total / len(gold_ids)


def repeated_context_ratio(unit_history: Sequence[Sequence[str]]) -> float:
    total = sum(len(turn) for turn in unit_history)
    if total == 0:
        return 0.0
    seen: set[str] = set()
    repeated = 0
    for turn in unit_history:
        for unit_id in turn:
            if unit_id in seen:
                repeated += 1
            seen.add(unit_id)
    return repeated / total


def resolve_rate(resolved: Sequence[bool]) -> float:
    return sum(bool(item) for item in resolved) / len(resolved) if resolved else 0.0


def reduction_rate(raw: float, optimized: float) -> float:
    if raw < 0 or optimized < 0:
        raise ValueError("token counts cannot be negative")
    return 0.0 if raw == 0 else (raw - optimized) / raw


def tokens_per_solved(total_tokens: float, resolved_count: int) -> float | None:
    if total_tokens < 0 or resolved_count < 0:
        raise ValueError("arguments cannot be negative")
    return None if resolved_count == 0 else total_tokens / resolved_count


def cost_per_solved(total_cost: float, resolved_count: int) -> float | None:
    if total_cost < 0:
        raise ValueError("total_cost cannot be negative")
    return None if resolved_count == 0 else total_cost / resolved_count


def context_efficiency(success: float, token_reduction: float, ace_preservation: float) -> float:
    if not all(0 <= value <= 1 for value in (success, token_reduction, ace_preservation)):
        raise ValueError("CES inputs must be in [0,1]")
    return success * token_reduction * ace_preservation


def ace_preservation(preserved: int, expected: int) -> float:
    if preserved < 0 or expected < 0 or preserved > expected:
        raise ValueError("invalid ACE counts")
    return 1.0 if expected == 0 else preserved / expected
