"""Exploratory trace measurements required by the protocol."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from typing import Any

from cactus.domain.models import TraceEvent


def summarize_trace(events: Iterable[TraceEvent]) -> dict[str, Any]:
    ordered = sorted(events, key=lambda event: event.seq)
    reads = [str(event.payload.get("path")) for event in ordered if event.event_type == "file_read" and event.payload.get("path")]
    selected_turns = [event for event in ordered if event.event_type == "context_selected"]
    model_calls = [event for event in ordered if event.event_type == "model_call"]
    read_counts = Counter(reads)
    selected_ids: list[str] = []
    for event in selected_turns:
        selected_ids.extend(str(item) for item in event.payload.get("selected", []))
    selected_counts = Counter(selected_ids)
    repeated_reads = sum(count - 1 for count in read_counts.values() if count > 1)
    repeated_units = sum(count - 1 for count in selected_counts.values() if count > 1)
    total_input = sum(int(event.payload.get("input_tokens", 0) or 0) for event in model_calls)
    total_output = sum(int(event.payload.get("output_tokens", 0) or 0) for event in model_calls)
    return {
        "event_count": len(ordered),
        "token_composition": {"input_tokens": total_input, "output_tokens": total_output, "total_tokens": total_input + total_output},
        "file_read_count": len(reads), "unique_files_read": len(read_counts), "repeated_file_reads": repeated_reads,
        "context_turn_count": len(selected_turns), "unique_units_selected": len(selected_counts), "repeated_unit_selections": repeated_units,
        "re_read_ratio": repeated_reads / len(reads) if reads else 0.0,
        "repeated_context_ratio": repeated_units / len(selected_ids) if selected_ids else 0.0,
        "reacquisition_events": sum(1 for event in ordered if event.event_type == "reacquisition"),
    }
