"""Gold-label evaluation helpers for an offline, reviewable dev set."""

from __future__ import annotations

from collections.abc import Sequence, Set
from typing import Any

from .metrics import ace_preservation, average_precision, recall_at_budget


def evaluate_gold(ranked_ids: Sequence[str], gold_ids: Set[str], *, budget: int, ace_expected: int = 0, ace_preserved: int = 0) -> dict[str, Any]:
    if budget < 0:
        raise ValueError("budget cannot be negative")
    return {
        "budget": budget,
        "gold_count": len(gold_ids),
        "recall_at_budget": recall_at_budget(ranked_ids, gold_ids, budget),
        "average_precision": average_precision(ranked_ids, gold_ids),
        "ace_preservation": ace_preservation(ace_preserved, ace_expected),
        "label_origin": "human_gold_required",
    }

