"""Machine-checkable result comparison rules for the P0/P1 protocol."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Check:
    check_id: str
    severity: str
    verdict: str
    message: str


def compare_result(baseline: dict[str, Any], actual: dict[str, Any]) -> dict[str, Any]:
    """Apply fixed-direction, CI-overlap and significance checks (G7)."""
    b_value, a_value = baseline.get("estimate"), actual.get("estimate")
    checks: list[Check] = []
    if isinstance(b_value, (int, float)) and isinstance(a_value, (int, float)):
        same_direction = (b_value == 0 or a_value == 0) or ((b_value > 0) == (a_value > 0))
    else:
        same_direction = False
    checks.append(Check("P-V1-001", "critical", "PASS" if same_direction else "FAIL", "direction consistent" if same_direction else "direction differs"))
    b_ci, a_ci = baseline.get("statistics", {}).get("ci95"), actual.get("statistics", {}).get("ci95")
    overlap = bool(isinstance(b_ci, list) and isinstance(a_ci, list) and len(b_ci) == 2 and len(a_ci) == 2 and max(b_ci[0], a_ci[0]) <= min(b_ci[1], a_ci[1]))
    checks.append(Check("P-V1-002", "critical", "PASS" if overlap else "FAIL", "CI overlaps" if overlap else "CI does not overlap"))
    b_sig = baseline.get("statistics", {}).get("p_value")
    a_sig = actual.get("statistics", {}).get("p_value")
    significance = isinstance(b_sig, (int, float)) and isinstance(a_sig, (int, float)) and (b_sig < .05) == (a_sig < .05)
    checks.append(Check("P-V1-003", "critical", "PASS" if significance else "FAIL", "significance consistent" if significance else "significance differs"))
    return {"gate": "G7", "result_verdict": "PASS" if all(item.verdict == "PASS" for item in checks) else "FAIL", "checks": [asdict(item) for item in checks]}
