"""Deterministic first-attempt and canonical-final outcome selection."""

from __future__ import annotations

from collections.abc import Iterable, Mapping

VALID_OUTCOMES = {"VALID_RESOLVED", "VALID_UNRESOLVED", "INVALID_EVALUATION"}


def canonical_attempt(attempts: Iterable[Mapping[str, object]], *, max_attempts: int = 3) -> dict[str, object]:
    rows = sorted((dict(row) for row in attempts), key=lambda row: (int(row.get("attempt_number", 0)), str(row.get("attempt_id", ""))))
    rows = [row for row in rows if 1 <= int(row.get("attempt_number", 0)) <= max_attempts]
    if not rows:
        raise ValueError("at least one attempt is required")
    for row in rows:
        outcome = str(row.get("canonical_outcome", ""))
        if outcome not in VALID_OUTCOMES:
            raise ValueError(f"invalid canonical outcome: {outcome}")
    return rows[-1]


def canonical_summary(attempts: Iterable[Mapping[str, object]], *, max_attempts: int = 3) -> dict[str, object]:
    rows = sorted((dict(row) for row in attempts), key=lambda row: (int(row.get("attempt_number", 0)), str(row.get("attempt_id", ""))))
    final = canonical_attempt(rows, max_attempts=max_attempts)
    return {"first_attempt_outcome": rows[0]["canonical_outcome"], "canonical_final_outcome": final["canonical_outcome"], "first_attempt_id": rows[0].get("attempt_id"), "canonical_final_attempt_id": final.get("attempt_id"), "attempt_count": len(rows)}
