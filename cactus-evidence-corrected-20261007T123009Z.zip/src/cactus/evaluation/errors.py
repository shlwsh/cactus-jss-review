"""Stable failure taxonomy and task-stratified aggregation."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable, Mapping


FAILURE_TYPES = ("context_loss", "ace_loss", "reacquisition", "tool_failure", "test_failure", "timeout", "unknown")


def classify_failure(*, resolved: bool, timeout: bool = False, tool_returncode: int | None = None, ace_preserved: bool = True, reacquired: bool = False, tests_failed: bool = False) -> str:
    if resolved:
        return "resolved"
    if timeout:
        return "timeout"
    if tool_returncode not in (None, 0):
        return "tool_failure"
    if not ace_preserved:
        return "ace_loss"
    if reacquired:
        return "reacquisition"
    if tests_failed:
        return "test_failure"
    return "unknown"


def stratify(records: Iterable[Mapping[str, object]], field: str = "task_type") -> dict[str, dict[str, int]]:
    groups: dict[str, Counter[str]] = {}
    for record in records:
        group = str(record.get(field, "unknown"))
        counter = groups.setdefault(group, Counter())
        counter["total"] += 1
        counter["resolved"] += int(bool(record.get("resolved", False)))
    return {group: dict(sorted(counter.items())) for group, counter in sorted(groups.items())}
