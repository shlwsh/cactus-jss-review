"""Transparent planning calculations for two-proportion comparisons."""

from __future__ import annotations

import math
from statistics import NormalDist


def two_proportion_sample_size(
    baseline_rate: float,
    expected_rate: float,
    alpha: float = 0.05,
    power: float = 0.8,
) -> int:
    """Return a conservative per-arm approximation for a two-sided test."""
    if not 0 < baseline_rate < 1 or not 0 < expected_rate < 1:
        raise ValueError("rates must be strictly between 0 and 1")
    if not 0 < alpha < 1 or not 0 < power < 1:
        raise ValueError("alpha and power must be in (0,1)")
    delta = abs(expected_rate - baseline_rate)
    if delta == 0:
        raise ValueError("expected_rate must differ from baseline_rate")
    pooled = (baseline_rate + expected_rate) / 2
    z_alpha = NormalDist().inv_cdf(1 - alpha / 2)
    z_power = NormalDist().inv_cdf(power)
    numerator = (z_alpha * math.sqrt(2 * pooled * (1 - pooled)) + z_power * math.sqrt(baseline_rate * (1 - baseline_rate) + expected_rate * (1 - expected_rate))) ** 2
    return math.ceil(numerator / (delta**2))
