"""Transparent effect-size and paired-outcome helpers."""

from __future__ import annotations

from collections.abc import Sequence

from .stats import mean, sample_std


def cohens_d(first: Sequence[float], second: Sequence[float]) -> float | None:
    if len(first) != len(second) or not first:
        raise ValueError("paired samples must be non-empty and aligned")
    differences = [a - b for a, b in zip(first, second)]
    deviation = sample_std(differences)
    return None if deviation in (None, 0) else mean(differences) / deviation


def cliffs_delta(first: Sequence[float], second: Sequence[float]) -> float:
    if not first or not second:
        raise ValueError("samples must be non-empty")
    greater = sum(a > b for a in first for b in second)
    less = sum(a < b for a in first for b in second)
    return (greater - less) / (len(first) * len(second))


def paired_contingency(first: Sequence[bool], second: Sequence[bool]) -> dict[str, int]:
    if len(first) != len(second) or not first:
        raise ValueError("paired boolean samples must be non-empty and aligned")
    return {"both_true": sum(a and b for a, b in zip(first, second)), "first_true_second_false": sum(a and not b for a, b in zip(first, second)), "first_false_second_true": sum(not a and b for a, b in zip(first, second)), "both_false": sum(not a and not b for a, b in zip(first, second))}


def approximate_sample_size(*, effect: float, alpha: float = .05, power: float = .8) -> int:
    """Conservative normal-approximation planning number; not a result."""
    if effect <= 0 or not 0 < alpha < 1 or not 0 < power < 1:
        raise ValueError("effect must be positive and alpha/power in (0,1)")
    # Fixed transparent z approximations for protocol planning only.
    z_alpha = 1.96 if alpha <= .05 else 1.645
    z_power = 0.84 if power <= .8 else 1.28
    return int(((z_alpha + z_power) / effect) ** 2 + .9999)
