"""Four-layer failure taxonomy for TOSEM v2.1 evidence attribution."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from cactus.execution.retry_state_machine import ErrorCode


class FailureFamily(StrEnum):
    ALGORITHM = "A"
    EXECUTION = "X"
    EVALUATOR = "E"
    GOVERNANCE = "G"


class FailureCode(StrEnum):
    EMPTY_PATCH = "A01_EMPTY_PATCH"
    INVALID_PATCH = "A02_INVALID_PATCH"
    TOOL_PLAN_FAILURE = "A03_TOOL_PLAN_FAILURE"
    AGENT_TIMEOUT = "A04_AGENT_TIMEOUT"
    CONTAINER_DAEMON = "X01_CONTAINER_DAEMON"
    REPOSITORY_MIRROR = "X02_REPOSITORY_MIRROR"
    MODEL_GATEWAY = "X03_MODEL_GATEWAY"
    RATE_LIMIT = "X04_RATE_LIMIT"
    DEPENDENCY_SETUP = "X05_DEPENDENCY_SETUP"
    RUNTIME_OOM = "X06_RUNTIME_OOM"
    TEST_DISCOVERY = "E01_TEST_DISCOVERY"
    TEST_PATCH_APPLY = "E02_TEST_PATCH_APPLY"
    EVALUATOR_CRASH = "E03_EVALUATOR_CRASH"
    EVALUATOR_TIMEOUT = "E04_EVALUATOR_TIMEOUT"
    RESULT_MALFORMED = "E05_RESULT_MALFORMED"
    UNKNOWN_EVALUATOR = "E06_UNKNOWN_EVALUATOR"
    BILLING_DELAY = "G01_BILLING_DELAY"
    BILLING_MISSING = "G02_BILLING_MISSING"
    CHECKSUM_MISMATCH = "G03_CHECKSUM_MISMATCH"
    DIRTY_SOURCE = "G04_DIRTY_SOURCE"
    MUTABLE_IMAGE = "G05_MUTABLE_IMAGE"
    APPROVAL_MISSING = "G06_APPROVAL_MISSING"


RETRYABLE = frozenset({
    FailureCode.CONTAINER_DAEMON,
    FailureCode.REPOSITORY_MIRROR,
    FailureCode.MODEL_GATEWAY,
    FailureCode.RATE_LIMIT,
    FailureCode.DEPENDENCY_SETUP,
    FailureCode.RUNTIME_OOM,
    FailureCode.EVALUATOR_TIMEOUT,
    FailureCode.BILLING_DELAY,
})

REPLAYABLE = frozenset({
    FailureCode.TEST_DISCOVERY,
    FailureCode.TEST_PATCH_APPLY,
    FailureCode.EVALUATOR_CRASH,
    FailureCode.EVALUATOR_TIMEOUT,
    FailureCode.RESULT_MALFORMED,
    FailureCode.UNKNOWN_EVALUATOR,
})

OLD_TO_NEW: dict[ErrorCode, FailureCode] = {
    ErrorCode.REPO_CHECKOUT: FailureCode.REPOSITORY_MIRROR,
    ErrorCode.DEPENDENCY_SETUP: FailureCode.DEPENDENCY_SETUP,
    ErrorCode.CONTAINER_BUILD: FailureCode.CONTAINER_DAEMON,
    ErrorCode.CONTAINER_RUNTIME: FailureCode.CONTAINER_DAEMON,
    ErrorCode.MODEL_GATEWAY: FailureCode.MODEL_GATEWAY,
    ErrorCode.MODEL_TIMEOUT: FailureCode.MODEL_GATEWAY,
    ErrorCode.PATCH_PARSE: FailureCode.INVALID_PATCH,
    ErrorCode.PATCH_APPLY: FailureCode.INVALID_PATCH,
    ErrorCode.TEST_DISCOVERY: FailureCode.TEST_DISCOVERY,
    ErrorCode.TEST_RUNTIME: FailureCode.EVALUATOR_CRASH,
    ErrorCode.EVALUATOR_INTERNAL: FailureCode.EVALUATOR_CRASH,
    ErrorCode.BILLING_RECORD: FailureCode.BILLING_MISSING,
    ErrorCode.CLEANUP: FailureCode.CHECKSUM_MISMATCH,
    ErrorCode.UNKNOWN: FailureCode.UNKNOWN_EVALUATOR,
}


@dataclass(frozen=True, slots=True)
class FailureClassification:
    failure_family: FailureFamily
    failure_code: FailureCode
    confidence: float
    retryable: bool
    replayable: bool
    needs_manual_review: bool


def generate_signature(event: dict[str, Any]) -> str:
    """Generate the stable failure signature required by the protocol."""

    stage = str(event.get("stage", "unknown"))
    exception_class = str(event.get("exception_class", event.get("exception_type", "unknown")))
    message = str(event.get("normalized_msg", event.get("message", "")))
    normalized_msg = re.sub(r"\s+", " ", message.replace("\\r", " ").replace("\\n", " ")).strip().lower()
    top_frame = str(event.get("top_frame", "unknown"))
    payload = f"{stage}|{exception_class}|{normalized_msg}|{top_frame}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def classification_for_old_code(code: ErrorCode | str) -> FailureClassification:
    old = ErrorCode(code)
    new = OLD_TO_NEW[old]
    confidence = 0.98 if old != ErrorCode.UNKNOWN else 0.35
    return FailureClassification(FailureFamily(new.value[0]), new, confidence, new in RETRYABLE, new in REPLAYABLE, confidence < 0.90)


def classify_text(text: str) -> FailureClassification:
    lowered = text.lower()
    rules: tuple[tuple[FailureCode, tuple[str, ...], float], ...] = (
        (FailureCode.EMPTY_PATCH, ("empty patch", "no patch", "patch is empty"), 0.99),
        (FailureCode.TEST_PATCH_APPLY, ("test patch", "test_patch"), 0.91),
        (FailureCode.INVALID_PATCH, ("corrupt patch", "invalid patch", "diff does not apply", "patch parse", "unified diff", "apply patch", "patch apply failed", "patching file"), 0.96),
        (FailureCode.RATE_LIMIT, ("429", "rate limit", "too many requests"), 0.99),
        (FailureCode.MODEL_GATEWAY, ("gateway", "connection refused", "502", "503", "model timeout"), 0.94),
        (FailureCode.REPOSITORY_MIRROR, ("checkout", "clone", "repository mirror"), 0.93),
        (FailureCode.DEPENDENCY_SETUP, ("pip install", "dependency", "requirements"), 0.93),
        (FailureCode.CONTAINER_DAEMON, ("docker daemon", "container runtime", "container build"), 0.92),
        (FailureCode.RUNTIME_OOM, ("out of memory", "oom", "memoryerror"), 0.98),
        (FailureCode.BILLING_MISSING, ("billing", "spend log", "no_records", "no records"), 0.94),
        (FailureCode.CHECKSUM_MISMATCH, ("checksum", "hash mismatch", "integrity"), 0.97),
        (FailureCode.TEST_DISCOVERY, ("test discovery", "no tests found"), 0.94),
        (FailureCode.EVALUATOR_TIMEOUT, ("evaluator timeout", "evaluation timed out"), 0.96),
        (FailureCode.EVALUATOR_CRASH, ("evaluator", "judge", "traceback"), 0.82),
        (FailureCode.RESULT_MALFORMED, ("malformed result", "invalid json", "result format"), 0.94),
    )
    for code, needles, confidence in rules:
        if any(re.search(rf"\b{re.escape(needle)}\b", lowered) for needle in needles):
            return FailureClassification(FailureFamily(code.value[0]), code, confidence, code in RETRYABLE, code in REPLAYABLE, confidence < 0.90)
    code = FailureCode.UNKNOWN_EVALUATOR
    return FailureClassification(FailureFamily.EVALUATOR, code, 0.20, False, False, True)
