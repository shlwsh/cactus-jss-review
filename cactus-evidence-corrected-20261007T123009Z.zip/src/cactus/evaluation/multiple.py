"""Deterministic multiple-comparison correction helpers."""

from __future__ import annotations

from collections.abc import Sequence


def bonferroni(p_values: Sequence[float]) -> list[float]:
    if any(not 0 <= value <= 1 for value in p_values):
        raise ValueError("p-values must be in [0,1]")
    return [min(1.0, value * len(p_values)) for value in p_values]


def holm(p_values: Sequence[float]) -> list[float]:
    if any(not 0 <= value <= 1 for value in p_values):
        raise ValueError("p-values must be in [0,1]")
    indexed = sorted(enumerate(p_values), key=lambda pair: (pair[1], pair[0]))
    adjusted = [0.0] * len(p_values)
    running = 0.0
    for rank, (index, value) in enumerate(indexed):
        running = max(running, min(1.0, (len(p_values) - rank) * value))
        adjusted[index] = running
    return adjusted


def significant(p_values: Sequence[float], *, alpha: float = .05, method: str = "holm") -> list[bool]:
    if not 0 < alpha < 1:
        raise ValueError("alpha must be in (0,1)")
    corrected = holm(p_values) if method == "holm" else bonferroni(p_values) if method == "bonferroni" else None
    if corrected is None:
        raise ValueError("method must be holm or bonferroni")
    return [value < alpha for value in corrected]
