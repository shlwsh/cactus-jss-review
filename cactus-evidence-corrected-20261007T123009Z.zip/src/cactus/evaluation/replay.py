"""Read-only planning primitives for evaluator-only replay.

The replay planner discovers immutable RUN evidence and records whether a
bundle contains enough information for a future evaluator invocation.  It
never calls a model, changes a source bundle, or treats missing evidence as a
successful replay.
"""

from __future__ import annotations

import json
import hashlib
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from cactus.failure_recovery.taxonomy import retry_replay_permission

_IMAGE_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")


def _first_file(bundle: Path, patterns: tuple[str, ...]) -> Path | None:
    matches = sorted(path for pattern in patterns for path in bundle.glob(pattern) if path.is_file())
    return matches[0] if matches else None


def _manifest(bundle: Path) -> dict[str, Any]:
    for name in ("run_manifest.json", "manifest.json"):
        path = bundle / name
        if not path.is_file():
            continue
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return value if isinstance(value, dict) else {}
    return {}


def _task_id(bundle: Path, manifest: dict[str, Any]) -> str:
    """Resolve the task ID across legacy and current RUN manifest layouts."""

    for value in (manifest.get("instance_id"), manifest.get("task_id")):
        if isinstance(value, str) and value:
            return value
    raw_path = bundle / "raw" / "result.json"
    try:
        raw = json.loads(raw_path.read_text(encoding="utf-8")) if raw_path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        raw = {}
    data = raw.get("data") if isinstance(raw, dict) else {}
    if isinstance(data, dict) and isinstance(data.get("task_id"), str) and data["task_id"]:
        return data["task_id"]
    config_path = bundle / "resolved_config.json"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8")) if config_path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        config = {}
    task = config.get("task") if isinstance(config, dict) else {}
    if isinstance(task, dict) and isinstance(task.get("task_id"), str) and task["task_id"]:
        return task["task_id"]
    return bundle.name


def discover_replay_records(source_runs: Path, *, dual_lens: bool = False) -> list[dict[str, Any]]:
    """Discover replay candidates without opening or modifying model state."""

    bundles = sorted({
        path.parent
        for name in ("run_manifest.json", "manifest.json")
        for path in source_runs.rglob(name)
        if path.is_file()
    })
    records: list[dict[str, Any]] = []
    for bundle in bundles:
        manifest = _manifest(bundle)
        report = _first_file(bundle, ("evaluator_report.*", "evaluation/*.json", "evaluator/*.json"))
        patch = _first_file(bundle, ("patch.diff", "prediction/*.diff", "raw/*.patch", "raw/*.diff", "raw/prediction.jsonl"))
        sealed = (bundle / "SEALED").is_file() or (bundle / "checksums.sha256").is_file()
        report_payload: dict[str, Any] = {}
        if report is not None:
            try:
                loaded_report = json.loads(report.read_text(encoding="utf-8"))
                report_payload = loaded_report if isinstance(loaded_report, dict) else {}
            except (OSError, json.JSONDecodeError):
                report_payload = {}
        nested_error = manifest.get("error") if isinstance(manifest.get("error"), dict) else {}
        failure_code = manifest.get("failure_code") or manifest.get("error_code") or nested_error.get("failure_code") or report_payload.get("failure_code") or report_payload.get("error_code")
        permission = retry_replay_permission(str(failure_code) if failure_code else None)
        manifest_prediction_hash = manifest.get("prediction_hash")
        prediction_hash_valid = bool(
            patch
            and isinstance(manifest_prediction_hash, str)
            and re.fullmatch(r"[0-9a-f]{64}", manifest_prediction_hash)
            and _sha256(patch) == manifest_prediction_hash
        )
        context_hash = manifest.get("context_bundle_hash")
        raw_result = bundle / "raw" / "result.json"
        if raw_result.is_file():
            try:
                raw_payload = json.loads(raw_result.read_text(encoding="utf-8"))
                raw_data = raw_payload.get("data") if isinstance(raw_payload, dict) else None
                raw_context_hash = raw_data.get("context_bundle_hash") if isinstance(raw_data, dict) else None
                if context_hash and raw_context_hash and context_hash != raw_context_hash:
                    context_hash = None
                elif not context_hash:
                    context_hash = raw_context_hash
            except (OSError, json.JSONDecodeError):
                context_hash = None
        context_hash_valid = bool(isinstance(context_hash, str) and re.fullmatch(r"[0-9a-f]{64}", context_hash))
        eligible = bool(
            report
            and patch
            and sealed
            and permission.evaluator_replayable
            and (not permission.requires_same_prediction_hash or prediction_hash_valid)
            and (not permission.requires_same_context_hash or context_hash_valid)
        )
        pending_reasons = []
        if not report:
            pending_reasons.append("missing_evaluator_report")
        if not patch:
            pending_reasons.append("missing_frozen_prediction")
        if not sealed:
            pending_reasons.append("source_run_not_sealed")
        if not permission.evaluator_replayable:
            pending_reasons.append("error_code_not_authorized_for_evaluator_replay")
        if permission.requires_same_prediction_hash and not prediction_hash_valid:
            pending_reasons.append("frozen_prediction_hash_missing_or_mismatched")
        if permission.requires_same_context_hash and not context_hash_valid:
            pending_reasons.append("context_hash_missing_or_mismatched")
        records.append({
            "instance_id": _task_id(bundle, manifest),
            "source_bundle": bundle.as_posix(),
            "evaluator_report": report.as_posix() if report else None,
            "prediction_patch": patch.as_posix() if patch else None,
            "sealed": sealed,
            "status": "ready" if eligible else "pending_evidence",
            "failure_code": failure_code,
            "algorithm_retryable": permission.algorithm_retryable,
            "evaluator_replayable": permission.evaluator_replayable,
            "prediction_hash_valid": prediction_hash_valid,
            "context_hash_valid": context_hash_valid,
            "pending_reasons": pending_reasons,
            "model_call_allowed": False,
            "source_immutable": True,
            "replay_mode": "dual_lens" if dual_lens else "evaluator_only",
            "evaluator_version": manifest.get("evaluator_version"),
            "container_digest": manifest.get("container_digest"),
            "context_bundle_hash": manifest.get("context_bundle_hash"),
        })
    return records


def build_replay_plan(source_runs: Path, *, dual_lens: bool = False) -> dict[str, Any]:
    """Build a fail-closed replay plan from existing RUN evidence."""

    records = discover_replay_records(source_runs, dual_lens=dual_lens)
    return {
        "schema_version": "2.1",
        "source_runs": source_runs.as_posix(),
        "records": records,
        "bundles": len(records),
        "ready": sum(record["status"] == "ready" for record in records),
        "pending_evidence": sum(record["status"] != "ready" for record in records),
        "model_calls": 0,
        "status": "ready" if records and all(record["status"] == "ready" for record in records) else "pending_evidence",
    }


def write_replay_plan(source_runs: Path, output: Path, *, dual_lens: bool = False) -> dict[str, Any]:
    """Write only a derived plan; source RUN directories remain untouched."""

    source_root = source_runs.resolve()
    output_root = output.resolve()
    if output_root == source_root or source_root in output_root.parents:
        raise ValueError("replay output must be outside the immutable source RUN tree")
    plan = build_replay_plan(source_runs, dual_lens=dual_lens)
    output.mkdir(parents=True, exist_ok=True)
    (output / "replay_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return plan


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _tree_snapshot(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): _sha256(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def _verify_sealed_source(root: Path) -> list[str]:
    """Verify every listed source file before allowing a replay."""

    checksums = root / "checksums.sha256"
    if not checksums.is_file():
        return ["missing checksums.sha256"]
    expected: set[str] = set()
    errors: list[str] = []
    for line_number, line in enumerate(checksums.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            digest, relative = line.split("  ", 1)
        except ValueError:
            errors.append(f"malformed checksum line {line_number}")
            continue
        expected.add(relative)
        path = root / relative
        if not path.is_file():
            errors.append(f"missing sealed source file: {relative}")
        elif _sha256(path) != digest:
            errors.append(f"source checksum mismatch: {relative}")
    actual = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.name != "checksums.sha256"
    }
    errors.extend(f"unlisted sealed source file: {relative}" for relative in sorted(actual - expected))
    return errors


def _read_dataset(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        values = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    else:
        values = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(values, list) or not all(isinstance(value, dict) for value in values):
        raise ValueError("replay dataset must contain a list of task objects")
    return values


def _pinned_dataset_record(
    dataset: list[dict[str, Any]],
    task_id: str,
    contract: dict[str, Any],
) -> tuple[dict[str, Any], str]:
    matches = [row for row in dataset if row.get("instance_id") == task_id]
    if len(matches) != 1:
        raise ValueError(f"replay dataset must contain exactly one record for {task_id}: {len(matches)} found")
    record = dict(matches[0])
    image_ref = str(record.get("image", ""))
    repository = image_ref.split("@", 1)[0].rsplit(":", 1)[0]
    images = contract.get("images") if isinstance(contract.get("images"), dict) else {}
    for image in images.values():
        if not isinstance(image, dict) or str(image.get("repository", "")) != repository:
            continue
        digest = image.get("digest")
        if not isinstance(digest, str) or not _IMAGE_DIGEST.fullmatch(digest):
            raise ValueError(f"contract image for {repository} is not pinned to a complete digest")
        record["image"] = f"{repository}@{digest}"
        return record, digest
    raise ValueError(f"no contract image digest matches evaluator repository {repository!r}")


def _prediction_for_task(path: Path, task_id: str) -> dict[str, Any]:
    predictions = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    matches = [value for value in predictions if isinstance(value, dict) and value.get("instance_id") == task_id]
    if len(matches) != 1:
        raise ValueError(f"prediction evidence must contain exactly one record for {task_id}: {len(matches)} found")
    if not isinstance(matches[0].get("model_patch"), str):
        raise ValueError(f"prediction evidence for {task_id} has no model_patch string")
    return matches[0]


def _seal_replay(root: Path) -> None:
    lines = []
    for path in sorted(path for path in root.rglob("*") if path.is_file() and path.name != "checksums.sha256"):
        lines.append(f"{_sha256(path)}  {path.relative_to(root).as_posix()}")
    (root / "checksums.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")


def execute_replay(
    source_runs: Path,
    output: Path,
    *,
    dataset_path: Path,
    contract_path: Path,
    project_root: Path,
    evaluator_script: Path | None = None,
    limit: int | None = None,
    timeout: int = 1800,
    command_runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> dict[str, Any]:
    """Re-run only the official evaluator against sealed predictions.

    The model is never called.  Source RUN trees are snapshotted before and
    after each replay, while all output is written to a separate replay tree.
    Dataset records are materialized transiently with digest-pinned evaluator
    images and are deleted after the evaluator exits.
    """

    source_root = source_runs.resolve()
    output_root = output.resolve()
    if output_root == source_root or source_root in output_root.parents:
        raise ValueError("replay output must be outside the immutable source RUN tree")
    if not dataset_path.is_file() or not contract_path.is_file():
        raise FileNotFoundError("replay dataset and contract are required")
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    dataset = _read_dataset(dataset_path)
    ready_records = [record for record in discover_replay_records(source_runs) if record["status"] == "ready"]
    # A campaign can contain several sealed attempts for one task.  Replay the
    # lexicographically latest sealed attempt per task so the EVR denominator
    # remains task-level and repeated historical attempts do not overweight it.
    latest_by_task: dict[str, dict[str, Any]] = {}
    for record in ready_records:
        latest_by_task[str(record["instance_id"])] = record
    records = [latest_by_task[task_id] for task_id in sorted(latest_by_task)]
    if limit is not None:
        records = records[:limit]
    output_root.mkdir(parents=True, exist_ok=True)
    replay_results: list[dict[str, Any]] = []
    evaluator = (evaluator_script or (project_root / "scripts" / "swebench_eval_lf.py")).resolve()

    for index, record in enumerate(records, start=1):
        task_id = str(record["instance_id"])
        source_bundle = Path(str(record["source_bundle"])).resolve()
        source_before = _tree_snapshot(source_bundle)
        replay_id = f"REPLAY-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}-{index:04d}"
        replay_root = output_root / replay_id
        if replay_root.exists():
            raise FileExistsError(f"replay output already exists: {replay_root}")
        replay_root.mkdir(parents=True)
        (replay_root / "logs").mkdir()
        (replay_root / "evaluation").mkdir()
        status = "failed"
        error: str | None = None
        returncode: int | None = None
        evaluator_image_digest: str | None = None
        report_summary: dict[str, Any] = {}
        try:
            source_integrity_errors = _verify_sealed_source(source_bundle)
            if source_integrity_errors:
                raise ValueError("source RUN seal verification failed: " + "; ".join(source_integrity_errors))
            prediction_path = Path(str(record["prediction_patch"])).resolve()
            if not record.get("evaluator_replayable"):
                raise ValueError("failure taxonomy does not authorize evaluator-only replay")
            source_manifest = _manifest(source_bundle)
            expected_prediction_hash = source_manifest.get("prediction_hash")
            if not isinstance(expected_prediction_hash, str) or _sha256(prediction_path) != expected_prediction_hash:
                raise ValueError("frozen prediction hash does not match the sealed RUN manifest")
            if not isinstance(source_manifest.get("context_bundle_hash"), str) or not re.fullmatch(r"[0-9a-f]{64}", source_manifest["context_bundle_hash"]):
                raise ValueError("source RUN manifest has no verified context bundle hash")
            prediction = _prediction_for_task(prediction_path, task_id)
            task_record, image_digest = _pinned_dataset_record(dataset, task_id, contract)
            evaluator_image_digest = image_digest
            with tempfile.TemporaryDirectory(prefix=f"cactus-{replay_id}-") as temporary:
                temp_root = Path(temporary)
                temp_dataset = temp_root / "task.jsonl"
                temp_prediction = temp_root / "prediction.jsonl"
                temp_dataset.write_text(json.dumps(task_record, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
                temp_prediction.write_text(json.dumps(prediction, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
                command = [
                    sys.executable,
                    str(evaluator),
                    str(temp_dataset),
                    "--predictions",
                    str(temp_prediction),
                    "--instance",
                    task_id,
                    "--run-id",
                    replay_id,
                    "--workers",
                    "1",
                    "--timeout",
                    str(timeout),
                    "--report-dir",
                    str(replay_root / "evaluation"),
                ]
                try:
                    completed = command_runner(command, cwd=temp_root, capture_output=True, text=True, timeout=timeout + 120, check=False)
                    returncode = completed.returncode
                    (replay_root / "logs" / "stdout.log").write_text(completed.stdout or "", encoding="utf-8", newline="\n")
                    (replay_root / "logs" / "stderr.log").write_text(completed.stderr or "", encoding="utf-8", newline="\n")
                except subprocess.TimeoutExpired as exc:
                    returncode = None
                    stdout = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
                    stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
                    (replay_root / "logs" / "stdout.log").write_text(stdout + "\n[REPLAY TIMEOUT]\n", encoding="utf-8", newline="\n")
                    (replay_root / "logs" / "stderr.log").write_text(stderr + "\n[REPLAY TIMEOUT]\n", encoding="utf-8", newline="\n")
                    error = f"evaluator timeout after {timeout + 120}s"
                reports = sorted((replay_root / "evaluation").glob(f"*.{replay_id}.json"))
                if len(reports) == 1:
                    payload = json.loads(reports[0].read_text(encoding="utf-8"))
                    if isinstance(payload, dict):
                        report_summary = {
                            key: payload.get(key)
                            for key in ("completed_instances", "resolved_instances", "unresolved_instances", "error_instances", "infra_failure_instances")
                            if key in payload
                        }
                if returncode == 0 and not error and len(reports) == 1:
                    status = "completed"
                elif not error:
                    error = f"evaluator exited with code {returncode}; reports={len(reports)}"
            if image_digest and not _IMAGE_DIGEST.fullmatch(image_digest):
                raise ValueError("internal image digest validation failed")
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        source_after = _tree_snapshot(source_bundle)
        source_unchanged = source_before == source_after
        if not source_unchanged:
            status = "source_mutated"
            error = "source RUN bundle changed during replay"
        manifest = {
            "schema_version": "2.1",
            "replay_id": replay_id,
            "mode": "evaluator_only",
            "status": status,
            "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "instance_id": task_id,
            "source_bundle": source_bundle.as_posix(),
            "source_bundle_unchanged": source_unchanged,
            "source_prediction_sha256": _sha256(Path(str(record["prediction_patch"])).resolve()),
            "dataset_sha256": _sha256(dataset_path),
            "contract_sha256": _sha256(contract_path),
            "evaluator_image_digest": evaluator_image_digest,
            "model_calls": 0,
            "billing_calls": 0,
            "report": report_summary,
            "returncode": returncode,
            "error": error,
        }
        (replay_root / "replay_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n")
        _seal_replay(replay_root)
        replay_results.append(manifest)

    return {
        "schema_version": "2.1",
        "mode": "evaluator_only",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_runs": source_root.as_posix(),
        "output": output_root.as_posix(),
        "model_calls": 0,
        "replay_count": len(replay_results),
        "completed_count": sum(item["status"] == "completed" for item in replay_results),
        "failed_count": sum(item["status"] != "completed" for item in replay_results),
        "records": replay_results,
        "status": "completed" if replay_results and all(item["status"] == "completed" for item in replay_results) else "pending_evidence",
    }


__all__ = ["build_replay_plan", "discover_replay_records", "execute_replay", "write_replay_plan"]
