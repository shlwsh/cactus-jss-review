"""Policy-level comparisons for replay summaries."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


def compare_policy_summaries(summaries: Mapping[str, Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for policy_id in sorted(summaries):
        summary = summaries[policy_id]
        token = summary.get("token_composition", {})
        rows.append({"policy_id": policy_id, "event_count": summary.get("event_count", 0), "total_tokens": token.get("total_tokens", 0), "repeated_context_ratio": summary.get("repeated_context_ratio", 0.0), "reacquisition_events": summary.get("reacquisition_events", 0)})
    return rows
