"""Seeded bootstrap intervals for task-level analysis."""

from __future__ import annotations

import random
from collections.abc import Callable, Sequence

from .stats import percentile


def bootstrap_ci(values: Sequence[float], statistic: Callable[[Sequence[float]], float], *, seed: int = 1, samples: int = 2000, alpha: float = .05) -> tuple[float, float]:
    if not values or samples <= 0 or not 0 < alpha < 1:
        raise ValueError("invalid bootstrap arguments")
    rng = random.Random(seed)
    draws = [statistic([values[rng.randrange(len(values))] for _ in values]) for _ in range(samples)]
    return percentile(draws, alpha / 2), percentile(draws, 1 - alpha / 2)
