"""Standardized experiment variants and diff assertion validator.

Implements Phase 6 (TASK-008) & Section 15 of CACTUS Rectification Plan v2.
Guarantees strict single-variable ablation isolation across the 9 formal variants.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class VariantConfig:
    name: str
    scoring_mode: str  # static_reproducible
    use_symbol_graph: bool
    use_ace: bool
    marginal_utility_selection: bool  # True: marginal utility, False: static density
    budget_controller_density: bool  # True: utility/cost density, False: pure utility
    normalize_patch: bool
    failure_recovery_enabled: bool


# Canonical frozen variant configurations
FROZEN_VARIANTS: dict[str, VariantConfig] = {
    "cactus_full": VariantConfig(
        name="cactus_full",
        scoring_mode="static_reproducible",
        use_symbol_graph=True,
        use_ace=True,
        marginal_utility_selection=True,
        budget_controller_density=True,
        normalize_patch=True,
        failure_recovery_enabled=True,
    ),
    "maximal_context": VariantConfig(
        name="maximal_context",
        scoring_mode="static_reproducible",
        use_symbol_graph=False,
        use_ace=False,
        marginal_utility_selection=False,
        budget_controller_density=False,
        normalize_patch=True,
        failure_recovery_enabled=True,
    ),
    "lexical_bm25": VariantConfig(
        name="lexical_bm25",
        scoring_mode="static_reproducible",
        use_symbol_graph=False,
        use_ace=False,
        marginal_utility_selection=False,
        budget_controller_density=True,
        normalize_patch=True,
        failure_recovery_enabled=True,
    ),
    "cactus_no_symbol_graph": VariantConfig(
        name="cactus_no_symbol_graph",
        scoring_mode="static_reproducible",
        use_symbol_graph=False,
        use_ace=True,
        marginal_utility_selection=True,
        budget_controller_density=True,
        normalize_patch=True,
        failure_recovery_enabled=True,
    ),
    "cactus_static_density": VariantConfig(
        name="cactus_static_density",
        scoring_mode="static_reproducible",
        use_symbol_graph=True,
        use_ace=True,
        marginal_utility_selection=False,
        budget_controller_density=True,
        normalize_patch=True,
        failure_recovery_enabled=True,
    ),
    "cactus_no_ace": VariantConfig(
        name="cactus_no_ace",
        scoring_mode="static_reproducible",
        use_symbol_graph=True,
        use_ace=False,
        marginal_utility_selection=True,
        budget_controller_density=True,
        normalize_patch=True,
        failure_recovery_enabled=True,
    ),
    "cactus_no_budget_controller": VariantConfig(
        name="cactus_no_budget_controller",
        scoring_mode="static_reproducible",
        use_symbol_graph=True,
        use_ace=True,
        marginal_utility_selection=True,
        budget_controller_density=False,
        normalize_patch=True,
        failure_recovery_enabled=True,
    ),
    "cactus_no_patch_normalizer": VariantConfig(
        name="cactus_no_patch_normalizer",
        scoring_mode="static_reproducible",
        use_symbol_graph=True,
        use_ace=True,
        marginal_utility_selection=True,
        budget_controller_density=True,
        normalize_patch=False,
        failure_recovery_enabled=True,
    ),
    "cactus_no_failure_recovery": VariantConfig(
        name="cactus_no_failure_recovery",
        scoring_mode="static_reproducible",
        use_symbol_graph=True,
        use_ace=True,
        marginal_utility_selection=True,
        budget_controller_density=True,
        normalize_patch=True,
        failure_recovery_enabled=False,
    ),
}


# Expected single-variable ablation difference mappings
EXPECTED_ABLATION_DIFFS: dict[str, set[str]] = {
    "cactus_no_symbol_graph": {"use_symbol_graph"},
    "cactus_static_density": {"marginal_utility_selection"},
    "cactus_no_ace": {"use_ace"},
    "cactus_no_budget_controller": {"budget_controller_density"},
    "cactus_no_patch_normalizer": {"normalize_patch"},
    "cactus_no_failure_recovery": {"failure_recovery_enabled"},
}


def assert_only_expected_differences(
    base_variant_name: str = "cactus_full",
    candidate_variant_name: str = "",
    allowed_keys: set[str] | None = None,
) -> dict[str, tuple[object, object]]:
    """Assert candidate variant differs from base variant ONLY along pre-registered keys."""
    base = FROZEN_VARIANTS[base_variant_name]
    candidate = FROZEN_VARIANTS[candidate_variant_name]

    base_dict = asdict(base)
    cand_dict = asdict(candidate)

    expected_keys = allowed_keys if allowed_keys is not None else EXPECTED_ABLATION_DIFFS.get(candidate_variant_name, set())
    diffs: dict[str, tuple[object, object]] = {}

    for key, base_val in base_dict.items():
        if key == "name":
            continue
        cand_val = cand_dict[key]
        if base_val != cand_val:
            diffs[key] = (base_val, cand_val)

    observed_diff_keys = set(diffs.keys())
    if observed_diff_keys != expected_keys:
        unexpected = observed_diff_keys - expected_keys
        missing = expected_keys - observed_diff_keys
        raise AssertionError(
            f"Variant '{candidate_variant_name}' violates single-variable ablation contract!\n"
            f"Expected diffs: {expected_keys}\n"
            f"Observed diffs: {observed_diff_keys}\n"
            f"Unexpected keys: {unexpected}, Missing keys: {missing}"
        )

    return diffs


def export_variant_diff_report(output_file: Path) -> dict[str, object]:
    """Generate artifacts/contracts/variant_diff_report.json documenting all diffs."""
    report: dict[str, object] = {}
    for var_name in EXPECTED_ABLATION_DIFFS:
        diffs = assert_only_expected_differences("cactus_full", var_name)
        report[var_name] = {k: {"base": v[0], "candidate": v[1]} for k, v in diffs.items()}

    output_file.parent.mkdir(parents=True, exist_ok=True)
    with output_file.open("w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    return report
