"""Immutable value objects shared by all CACTUS layers."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class TaskSpec:
    task_id: str
    benchmark: str
    repo_id: str
    base_commit: str
    issue_text_hash: str
    test_command: tuple[str, ...] = ()
    license: str = "unknown"


@dataclass(frozen=True, slots=True)
class DependencyEdge:
    source_id: str
    target_id: str
    relation: str
    confidence: float = 1.0


@dataclass(frozen=True, slots=True)
class ContextUnit:
    unit_id: str
    kind: str
    path: str
    token_count: int
    text: str = ""
    symbol_id: str | None = None
    start_line: int | None = None
    end_line: int | None = None
    snapshot_hash: str | None = None
    provenance: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ACEItem:
    ace_id: str
    ace_type: str
    unit_id: str
    exact_span: tuple[int, int] | None
    hard: bool
    trigger_event_id: str | None = None
    allowed_actions: tuple[str, ...] = ("keep_raw",)
    detector_version: str = "1.0"


@dataclass(frozen=True, slots=True)
class ModelUsage:
    input_tokens: int
    output_tokens: int
    cached_tokens: int = 0
    usage_source: str = "provider"
    price_version: str | None = None
    provider_cost: float | None = None
    provider_cost_currency: str | None = None
    provider_call_id: str | None = None

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass(frozen=True, slots=True)
class TraceEvent:
    event_id: str
    run_id: str
    seq: int
    utc_ts: str
    event_type: str
    payload: Mapping[str, Any]
    parent_event_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "run_id": self.run_id,
            "seq": self.seq,
            "utc_ts": self.utc_ts,
            "type": self.event_type,
            "payload": dict(self.payload),
            "parent_event_id": self.parent_event_id,
        }


@dataclass(frozen=True, slots=True)
class SelectionPlan:
    turn_id: str
    budget: int
    selected_unit_ids: tuple[str, ...]
    excluded_unit_ids: tuple[str, ...]
    scores: Mapping[str, float]
    token_count: int
    ace_closure: tuple[str, ...]
    status: str = "ok"

