"""Deterministic, provenance-preserving paper-input table generation."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Iterable

from cactus.governance.canonical import sha256_json
from cactus.governance.policy import derive_claim_status

_FIELDS = ("result_id", "study_id", "metric_id", "value", "unit", "claim_status", "source_sha256")


def normalize_records(records: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """Normalize records without allowing a caller-supplied claim status."""
    output: list[dict[str, Any]] = []
    for record in sorted(records, key=lambda item: (str(item.get("study_id", "")), str(item.get("result_id", "")))):
        evidence = record.get("evidence") if isinstance(record.get("evidence"), dict) else {}
        status, _ = derive_claim_status(evidence, requested="supporting")
        output.append({
            "result_id": record.get("result_id"),
            "study_id": record.get("study_id"),
            "metric_id": record.get("metric_id"),
            "value": record.get("value"),
            "unit": record.get("unit"),
            "claim_status": status,
            "source_sha256": sha256_json(record),
        })
    return output


def write_result_table(records: Iterable[dict[str, Any]], csv_path: Path, markdown_path: Path) -> tuple[Path, Path]:
    """Write stable CSV and Markdown artifacts from canonical result records."""
    rows = normalize_records(records)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    markdown_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=_FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    lines = ["| " + " | ".join(_FIELDS) + " |", "|" + "|".join("---" for _ in _FIELDS) + "|"]
    lines.extend("| " + " | ".join("" if row[field] is None else str(row[field]).replace("|", "\\|") for field in _FIELDS) + " |" for row in rows)
    markdown_path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return csv_path, markdown_path

