"""Reproducibility checks for deterministic context selection."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from statistics import variance


def check_reproducibility(run: Callable[[], dict[str, object]], *, repetitions: int = 3) -> dict[str, object]:
    if repetitions < 2:
        raise ValueError("at least two repetitions are required")
    records = [dict(run()) for _ in range(repetitions)]
    hashes = [str(record.get("context_bundle_hash", "")) for record in records]
    token_values = [float(record.get("input_tokens", record.get("context_token_count", 0))) for record in records]
    costs = [float(record.get("verified_cost", 0.0)) for record in records]
    return {"repetitions": repetitions, "context_hashes": hashes, "context_hash_consistency": len(set(hashes)) == 1 and bool(hashes[0]), "token_variance": variance(token_values) if len(token_values) > 1 else 0.0, "cost_variance": variance(costs) if len(costs) > 1 else 0.0, "status": "observed"}
