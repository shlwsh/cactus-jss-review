"""Budget-sensitivity planning utilities."""

from __future__ import annotations

from collections.abc import Callable, Sequence


DEFAULT_RATIOS = (0.25, 0.50, 0.75, 1.00)


def plan_budget_sweep(default_budget: int, *, ratios: Sequence[float] = DEFAULT_RATIOS, selector: Callable[[int], dict[str, object]] | None = None) -> list[dict[str, object]]:
    if default_budget < 0 or any(not 0 < ratio <= 1 for ratio in ratios):
        raise ValueError("invalid budget sweep")
    rows = []
    for ratio in ratios:
        budget = int(default_budget * ratio)
        row = {"budget_ratio": ratio, "budget": budget, "status": "pending"}
        if selector is not None:
            result = dict(selector(budget))
            row.update(result)
            row["status"] = result.get("status", "observed")
        rows.append(row)
    return rows
