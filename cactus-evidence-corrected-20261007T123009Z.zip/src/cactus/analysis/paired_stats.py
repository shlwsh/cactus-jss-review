"""Small dependency-free paired statistics for experiment summaries."""

from __future__ import annotations

import math
import random
from collections.abc import Sequence


def mcnemar_exact(discordant_a_success_b_failure: int, discordant_a_failure_b_success: int) -> float:
    a = int(discordant_a_success_b_failure)
    b = int(discordant_a_failure_b_success)
    if min(a, b) < 0:
        raise ValueError("discordant counts must be non-negative")
    n = a + b
    if n == 0:
        return 1.0
    tail = sum(math.comb(n, k) for k in range(0, min(a, b) + 1)) / (2 ** n)
    return min(1.0, 2.0 * tail)


def paired_bootstrap(values_a: Sequence[float], values_b: Sequence[float], *, samples: int = 2000, seed: int = 0, confidence: float = 0.95) -> dict[str, float]:
    if len(values_a) != len(values_b) or not values_a:
        raise ValueError("paired samples must have equal non-zero length")
    if samples < 100:
        raise ValueError("samples must be at least 100")
    differences = [float(a) - float(b) for a, b in zip(values_a, values_b)]
    rng = random.Random(seed)
    estimates = [sum(rng.choice(differences) for _ in differences) / len(differences) for _ in range(samples)]
    estimates.sort()
    alpha = (1.0 - confidence) / 2.0
    lo = estimates[max(0, int(alpha * samples) - 1)]
    hi = estimates[min(samples - 1, int((1.0 - alpha) * samples))]
    return {"mean_difference": sum(differences) / len(differences), "median_difference": sorted(differences)[len(differences) // 2], "ci_low": lo, "ci_high": hi, "confidence": confidence, "samples": samples, "seed": seed}
