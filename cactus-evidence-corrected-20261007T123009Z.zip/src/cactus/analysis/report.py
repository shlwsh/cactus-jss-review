"""Deterministic Markdown report builder for exploratory traces."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from cactus.evaluation.trajectory import summarize_trace
from cactus.trace.store import TraceStore


def build_report(events_path: Path, output: Path, *, run_id: str) -> Path:
    events = TraceStore(events_path, run_id).read()
    summary = summarize_trace(events)
    payload: dict[str, Any] = {"run_id": run_id, "summary": summary, "event_ids": [event.event_id for event in events]}
    report = "# CACTUS Trace Analysis Report\n\n" + f"- run_id: `{run_id}`\n- event_count: {summary['event_count']}\n- input_tokens: {summary['token_composition']['input_tokens']}\n- output_tokens: {summary['token_composition']['output_tokens']}\n- repeated_file_reads: {summary['repeated_file_reads']}\n- repeated_context_ratio: {summary['repeated_context_ratio']:.6f}\n\n" + "```json\n" + json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n```\n"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(report, encoding="utf-8", newline="\n")
    return output
