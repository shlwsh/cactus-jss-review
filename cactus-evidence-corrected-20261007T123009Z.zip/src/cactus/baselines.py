"""Deterministic offline baseline selectors for context experiments.

These selectors define the common interface and selection semantics required by
the experiment matrix. They produce candidate unit IDs only; benchmark scores
remain unobserved until a sealed runner executes each variant.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Sequence

from cactus.domain.models import ContextUnit

BASELINE_NAMES = (
    "raw_full",
    "fixed_window",
    "random",
    "bm25",
    "embedding_only",
    "structural_neighbors",
    "full_reread",
    "text_diff",
    "ast_entity_diff",
)


def _tokens(text: str) -> set[str]:
    return {token.lower() for token in re.findall(r"[A-Za-z_][A-Za-z0-9_]+", text)}


def _take(ordered: Sequence[ContextUnit], budget: int) -> tuple[str, ...]:
    if budget < 0:
        raise ValueError("budget must be non-negative")
    selected: list[str] = []
    remaining = budget
    for unit in ordered:
        if unit.token_count <= remaining:
            selected.append(unit.unit_id)
            remaining -= unit.token_count
    return tuple(selected)


def select_baseline(
    name: str,
    units: Sequence[ContextUnit],
    query: str = "",
    budget: int = 0,
    seed: int = 0,
) -> tuple[str, ...]:
    """Select context units using one of the nine registered baselines."""
    if name not in BASELINE_NAMES:
        raise ValueError(f"unknown baseline: {name}")
    canonical = sorted(units, key=lambda unit: unit.unit_id)
    if name in {"raw_full", "full_reread"}:
        return _take(canonical, budget)
    if name == "fixed_window":
        return _take(sorted(canonical, key=lambda u: (u.start_line or 0, u.unit_id)), budget)
    if name == "random":
        ordered = sorted(canonical, key=lambda u: hashlib.sha256(f"{seed}:{u.unit_id}".encode()).hexdigest())
        return _take(ordered, budget)
    query_tokens = _tokens(query)
    if name in {"bm25", "embedding_only"}:
        # Embedding-only is a deterministic offline proxy until a frozen encoder
        # is registered; its status must remain non-observed in experiment data.
        ordered = sorted(canonical, key=lambda u: (-len(query_tokens & _tokens(u.text)), u.unit_id))
        return _take(ordered, budget)
    if name == "structural_neighbors":
        ordered = sorted(canonical, key=lambda u: (u.symbol_id is None, u.path, u.start_line or 0, u.unit_id))
        return _take(ordered, budget)
    if name == "text_diff":
        ordered = sorted(canonical, key=lambda u: (u.kind != "delta", -u.token_count, u.unit_id))
        return _take(ordered, budget)
    ordered = sorted(canonical, key=lambda u: (u.kind not in {"delta", "semantic_delta"}, -u.token_count, u.unit_id))
    return _take(ordered, budget)
