"""Anti-fragile Context Engine (ACE) Guardian with Provenance Audit and 3-Tier Protection.

Implements Phase 4 (TASK-006) & Section 9 of CACTUS Rectification Plan v2.
Rules:
1. Sources: issue_text, explicit_file, explicit_symbol, failure_trace, official_test_log, agent_exploration.
2. Leakage Protection: Prohibits gold_patch / ground_truth_edit anchors (GOV008).
3. 3-Tier Protection: MANDATORY (must be in context), STRONG (high-priority), NORMAL.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from enum import IntEnum, StrEnum

from cactus.domain.models import ACEItem, ContextUnit


class LabelLeakageError(ValueError):
    """Raised when ground truth or gold patch is illegitimately fed into context selection."""
    pass


class AnchorSource(StrEnum):
    ISSUE_TEXT = "issue_text"
    EXPLICIT_FILE = "explicit_file"
    EXPLICIT_SYMBOL = "explicit_symbol"
    FAILURE_TRACE = "failure_trace"
    OFFICIAL_TEST_LOG = "official_test_log"
    AGENT_EXPLORATION = "agent_exploration"


PROHIBITED_SOURCES = frozenset({
    "gold_patch",
    "ground_truth_edit",
    "post_hoc_manual_hint",
})


class ProtectionLevel(IntEnum):
    NORMAL = 0
    STRONG = 1
    MANDATORY = 2


class ACEGuardian:
    def __init__(self, detector_version: str = "2.0") -> None:
        self.detector_version = detector_version

    def detect(
        self,
        units: Iterable[ContextUnit],
        *,
        failure_text: str = "",
        edit_paths: Iterable[str] = (),
        source: str = "agent_exploration",
    ) -> tuple[ACEItem, ...]:
        clean_src = source.lower().strip()
        if clean_src in PROHIBITED_SOURCES or any(p in clean_src for p in PROHIBITED_SOURCES):
            raise LabelLeakageError(
                f"GOV008_LABEL_LEAKAGE_RISK: Source '{source}' is strictly forbidden in ACE anchor detection!"
            )

        paths = set(edit_paths)
        result: list[ACEItem] = []

        for unit in units:
            level = ProtectionLevel.NORMAL
            is_trace_hit = bool(failure_text and re.search(r"(error|fail|exception|assert|traceback)", failure_text, re.I))

            if unit.path in paths and (unit.kind in {"function", "class", "file"}):
                level = ProtectionLevel.MANDATORY
                ace_type = "mandatory_anchor"
            elif unit.path in paths:
                level = ProtectionLevel.STRONG
                ace_type = "strong_file_context"
            elif is_trace_hit and unit.symbol_id and unit.symbol_id.lower() in failure_text.lower():
                level = ProtectionLevel.MANDATORY
                ace_type = "mandatory_trace_target"
            elif is_trace_hit:
                level = ProtectionLevel.STRONG
                ace_type = "strong_failure_evidence"
            else:
                continue

            hard = (level == ProtectionLevel.MANDATORY)
            result.append(
                ACEItem(
                    f"ace-{unit.unit_id}",
                    ace_type,
                    unit.unit_id,
                    (0, len(unit.text)),
                    hard,
                    allowed_actions=("keep_raw", "compress" if level != ProtectionLevel.MANDATORY else "keep_raw"),
                )
            )

        return tuple(result)

    @staticmethod
    def protected_unit_ids(items: Iterable[ACEItem]) -> set[str]:
        """Return all mandatory protected unit ids."""
        return {item.unit_id for item in items if item.hard}

    @staticmethod
    def strong_unit_ids(items: Iterable[ACEItem]) -> set[str]:
        """Return strong priority unit ids."""
        return {item.unit_id for item in items if not item.hard}

    @staticmethod
    def validate_selection(selected: set[str], items: Iterable[ACEItem]) -> list[str]:
        return sorted(ACEGuardian.protected_unit_ids(items) - selected)
