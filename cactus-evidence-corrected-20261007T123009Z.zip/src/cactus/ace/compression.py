"""Structural skeleton compression for context units when approaching code budget limits.

Implements Phase 4 (TASK-006) & Section 9.3 of CACTUS Rectification Plan v2.
Allows:
- Preserving class definitions and signatures while collapsing auxiliary bodies.
- Maintaining exact line mappings.
Prohibits:
- Rewriting semantics or using ground-truth answers for compression decisions.
"""

from __future__ import annotations

import re
from cactus.domain.models import ContextUnit


def compress_unit(unit: ContextUnit, max_tokens: int) -> ContextUnit:
    """Compress unit text to fit within max_tokens if needed, preserving headers/signatures."""
    if unit.token_count <= max_tokens or not unit.text:
        return unit

    lines = unit.text.splitlines()
    if len(lines) <= 6:
        return unit

    # Keep leading signatures / decorators (first 4 lines)
    header = lines[:4]
    # Keep trailing lines (last 2 lines)
    footer = lines[-2:]

    placeholder = "    # ... [CACTUS skeleton compression: intermediate body omitted] ..."
    collapsed_lines = header + [placeholder] + footer
    collapsed_text = "\n".join(collapsed_lines) + "\n"

    # Approximate token reduction proportional to line length
    est_tokens = max(32, int(unit.token_count * (len(collapsed_lines) / max(1, len(lines)))))

    return ContextUnit(
        unit_id=unit.unit_id,
        kind=unit.kind,
        path=unit.path,
        token_count=est_tokens,
        text=collapsed_text,
        symbol_id=unit.symbol_id,
        start_line=unit.start_line,
        end_line=unit.end_line,
        snapshot_hash=unit.snapshot_hash,
        provenance={**dict(unit.provenance), "compressed": True, "original_tokens": unit.token_count},
    )
