"""Small state machine for task, edit, failure and phase evidence."""

from __future__ import annotations

from dataclasses import dataclass, field

from cactus.domain.models import TraceEvent


@dataclass
class ExecutionState:
    phase: str = "localize"
    modified_paths: set[str] = field(default_factory=set)
    failure_text: str = ""
    read_counts: dict[str, int] = field(default_factory=dict)
    last_event_id: str | None = None


class StateBuilder:
    def __init__(self) -> None:
        self.state = ExecutionState()

    def apply(self, event: TraceEvent) -> ExecutionState:
        payload = event.payload
        if event.event_type == "model_call":
            self.state.phase = "modify" if payload.get("proposed_edit") else self.state.phase
        elif event.event_type in {"test_failure", "diagnostic"}:
            self.state.phase = "verify"
            self.state.failure_text = str(payload.get("text", ""))
        elif event.event_type == "file_read":
            path = str(payload.get("path", ""))
            self.state.read_counts[path] = self.state.read_counts.get(path, 0) + 1
        elif event.event_type in {"file_edit", "patch_applied"}:
            path = str(payload.get("path", ""))
            if path:
                self.state.modified_paths.add(path)
            self.state.phase = "verify"
        self.state.last_event_id = event.event_id
        return self.state

    def consume(self, events: list[TraceEvent]) -> ExecutionState:
        for event in events:
            self.apply(event)
        return self.state
