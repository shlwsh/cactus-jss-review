"""Context action space with hard-ACE safety constraints."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from cactus.domain.models import ACEItem, ContextUnit


ACTIONS = ("keep_raw", "delta", "summary", "reference", "drop")


def legal_actions(unit: ContextUnit, ace_items: Sequence[ACEItem]) -> tuple[str, ...]:
    hard = any(item.hard and item.unit_id == unit.unit_id for item in ace_items)
    return ("keep_raw", "delta") if hard else ACTIONS


def choose_actions(units: Sequence[ContextUnit], scores: Mapping[str, float], ace_items: Sequence[ACEItem], budget: int) -> dict[str, str]:
    if budget < 0:
        raise ValueError("budget must be non-negative")
    choices: dict[str, str] = {}
    remaining = budget
    for unit in sorted(units, key=lambda item: (-(scores.get(item.unit_id, 0.0) / max(1, item.token_count)), item.unit_id)):
        allowed = legal_actions(unit, ace_items)
        if "keep_raw" in allowed and unit.token_count <= remaining:
            choices[unit.unit_id] = "keep_raw"
            remaining -= unit.token_count
        elif any(item.hard and item.unit_id == unit.unit_id for item in ace_items) and "delta" in allowed and remaining >= 1:
            choices[unit.unit_id] = "delta"
            remaining -= 1
        elif "reference" in allowed and remaining >= 1:
            choices[unit.unit_id] = "reference"
            remaining -= 1
        else:
            choices[unit.unit_id] = "budget_infeasible" if any(item.hard and item.unit_id == unit.unit_id for item in ace_items) else "drop"
    return choices
