"""Deterministic multi-bucket scheduler for task, ACE, and code budgets."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from cactus.domain.models import ACEItem, ContextUnit


@dataclass(frozen=True, slots=True)
class BucketBudget:
    task: int
    ace: int
    code: int


@dataclass(frozen=True, slots=True)
class MultiBucketPlan:
    selected_unit_ids: tuple[str, ...]
    deferred_unit_ids: tuple[str, ...]
    dropped_unit_ids: tuple[str, ...]
    used: BucketBudget
    status: str


def _bucket(unit: ContextUnit, ace_ids: set[str]) -> str:
    if unit.unit_id in ace_ids or unit.kind in {"ace", "failure_evidence"}:
        return "ace"
    if unit.kind in {"code", "symbol", "delta", "reference"}:
        return "code"
    return "task"


def schedule_multi_bucket(
    units: Sequence[ContextUnit],
    scores: Mapping[str, float],
    ace_items: Sequence[ACEItem],
    budget: BucketBudget,
) -> MultiBucketPlan:
    """Select high-value units while keeping each bucket independently bounded."""
    if min(budget.task, budget.ace, budget.code) < 0:
        raise ValueError("bucket budgets must be non-negative")
    ace_ids = {item.unit_id for item in ace_items}
    remaining = {"task": budget.task, "ace": budget.ace, "code": budget.code}
    selected: list[str] = []
    deferred: list[str] = []
    dropped: list[str] = []
    ordered = sorted(units, key=lambda u: (-(scores.get(u.unit_id, 0.0) / max(1, u.token_count)), u.unit_id))
    for unit in ordered:
        bucket = _bucket(unit, ace_ids)
        if unit.token_count <= remaining[bucket]:
            selected.append(unit.unit_id)
            remaining[bucket] -= unit.token_count
        elif unit.unit_id in ace_ids:
            deferred.append(unit.unit_id)
        else:
            dropped.append(unit.unit_id)
    used = BucketBudget(
        budget.task - remaining["task"],
        budget.ace - remaining["ace"],
        budget.code - remaining["code"],
    )
    return MultiBucketPlan(tuple(selected), tuple(deferred), tuple(dropped), used, "ok")
