"""Hot/Warm/Cold context lifecycle and reacquisition risk estimates."""

from __future__ import annotations

from collections.abc import Mapping


def classify_lifecycle(*, age_turns: int, changed: bool, failure_referenced: bool) -> str:
    if changed or failure_referenced or age_turns <= 0:
        return "hot"
    if age_turns <= 2:
        return "warm"
    return "cold"


def reacquisition_risk(*, lifecycle: str, read_count: int, excluded_count: int) -> float:
    base = {"hot": .05, "warm": .15, "cold": .30}.get(lifecycle, .5)
    history = min(.5, read_count * .1)
    exclusion = min(.4, excluded_count * .1)
    return min(1.0, base + history + exclusion)


def cache_accounting(*, logical_input_tokens: int, cached_input_tokens: int, cache_write_tokens: int = 0) -> dict[str, int]:
    if min(logical_input_tokens, cached_input_tokens, cache_write_tokens) < 0:
        raise ValueError("cache token counts cannot be negative")
    if cached_input_tokens > logical_input_tokens:
        raise ValueError("cached tokens cannot exceed logical input tokens")
    return {"logical_input_tokens": logical_input_tokens, "cached_input_tokens": cached_input_tokens, "uncached_input_tokens": logical_input_tokens - cached_input_tokens, "cache_write_tokens": cache_write_tokens}
