"""Deterministic ACE-first greedy budget scheduler."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from cactus.ace.guardian import ACEGuardian
from cactus.domain.models import ACEItem, ContextUnit, SelectionPlan


class BudgetScheduler:
    def select(self, turn_id: str, units: Sequence[ContextUnit], scores: Mapping[str, float], ace_items: Sequence[ACEItem], budget: int) -> SelectionPlan:
        by_id = {unit.unit_id: unit for unit in units}
        protected = sorted(ACEGuardian.protected_unit_ids(ace_items))
        missing = [unit_id for unit_id in protected if unit_id not in by_id]
        protected_tokens = sum(by_id[unit_id].token_count for unit_id in protected if unit_id in by_id)
        if missing or protected_tokens > budget:
            return SelectionPlan(turn_id, budget, (), tuple(unit.unit_id for unit in units), dict(scores), 0, tuple(protected), "budget_infeasible")
        selected = list(protected)
        remaining = budget - protected_tokens
        selected_set = set(selected)
        candidates = sorted((u for u in units if u.unit_id not in selected_set), key=lambda u: (-(scores.get(u.unit_id, 0.0) / max(1, u.token_count)), u.unit_id))
        for unit in candidates:
            if unit.token_count <= remaining:
                selected.append(unit.unit_id)
                remaining -= unit.token_count
        selected_set = set(selected)
        return SelectionPlan(turn_id, budget, tuple(selected), tuple(u.unit_id for u in units if u.unit_id not in selected_set), dict(scores), budget - remaining, tuple(protected), "ok")
