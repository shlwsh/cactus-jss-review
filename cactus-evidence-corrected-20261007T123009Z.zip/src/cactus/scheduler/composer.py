"""Provenance-preserving context composition."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from cactus.domain.models import ContextUnit, SelectionPlan


def compose(plan: SelectionPlan, units: Sequence[ContextUnit], *, header: str = "") -> str:
    by_id = {unit.unit_id: unit for unit in units}
    chunks = [header] if header else []
    for unit_id in plan.selected_unit_ids:
        unit = by_id[unit_id]
        if unit.start_line is not None and unit.end_line is not None:
            start_line, end_line = unit.start_line, unit.end_line
        elif unit.kind == "file":
            start_line, end_line = 1, max(1, len(unit.text.splitlines()))
        else:
            start_line = end_line = None
        line_info = (
            f" lines:{start_line}-{end_line} hunk:@@ -{start_line},{end_line - start_line + 1} @@"
            if start_line is not None and end_line is not None
            else ""
        )
        chunks.append(f"<!-- cactus-unit:{unit.unit_id} path:{unit.path}{line_info} kind:{unit.kind} -->\n{unit.text}")
    return "\n\n".join(chunks)
