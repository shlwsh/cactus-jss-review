"""Policy-derived result registry primitives."""

from .store import Registry

__all__ = ["Registry"]
