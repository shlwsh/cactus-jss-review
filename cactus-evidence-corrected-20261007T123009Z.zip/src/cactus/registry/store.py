"""Append-only JSONL registry; claim status is derived from evidence policy."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from cactus.governance.policy import derive_claim_status


class Registry:
    def __init__(self, path: Path) -> None:
        self.path = path

    def add(self, record: dict[str, Any], *, requested_status: str = "supporting") -> dict[str, Any]:
        if "claim_status" in record:
            raise ValueError("claim_status is derived and cannot be supplied")
        evidence = record.get("evidence", {})
        status, reasons = derive_claim_status(evidence, requested=requested_status)
        enriched = dict(record)
        enriched["publication"] = {"claim_status": status, "policy_reasons": reasons, "policy_version": "2.0"}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(enriched, ensure_ascii=False, sort_keys=True) + "\n")
        return enriched

    def read(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        return [json.loads(line) for line in self.path.read_text(encoding="utf-8").splitlines() if line.strip()]
