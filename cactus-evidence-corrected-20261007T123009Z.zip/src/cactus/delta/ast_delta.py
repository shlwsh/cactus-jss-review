"""AST-level entity delta with a safe text fallback.

Python source uses the standard-library AST parser. Other languages are
returned as a deterministic line-level delta and explicitly marked as a
fallback, avoiding a hidden dependency on an unavailable parser runtime.
"""

from __future__ import annotations

import ast
import hashlib
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class EntityDelta:
    added: tuple[str, ...]
    removed: tuple[str, ...]
    changed: tuple[str, ...]
    parser: str
    source_hash: str


def _python_entities(text: str) -> dict[str, str]:
    tree = ast.parse(text)
    entities: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            key = f"{type(node).__name__}:{node.name}"
            entities[key] = ast.dump(node, annotate_fields=True, include_attributes=False)
    return entities


def entity_delta(previous: str, current: str, language: str = "python") -> EntityDelta:
    """Compare named entities and report parser provenance."""
    digest = hashlib.sha256(current.encode("utf-8")).hexdigest()
    if language.lower() in {"python", "py"}:
        old, new = _python_entities(previous), _python_entities(current)
        common = old.keys() & new.keys()
        changed = tuple(sorted(name for name in common if old[name] != new[name]))
        return EntityDelta(tuple(sorted(new.keys() - old.keys())), tuple(sorted(old.keys() - new.keys())), changed, "python-ast", digest)
    old_lines, new_lines = set(previous.splitlines()), set(current.splitlines())
    return EntityDelta(tuple(sorted(new_lines - old_lines)), tuple(sorted(old_lines - new_lines)), (), "line-fallback", digest)
