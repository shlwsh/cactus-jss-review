"""Snapshot and semantic delta operations."""

from .semantic import semantic_delta
from .ast_delta import EntityDelta, entity_delta

__all__ = ["EntityDelta", "entity_delta", "semantic_delta"]
