"""Hash- and line-aware semantic delta renderer."""

from __future__ import annotations

import difflib
import hashlib

from cactus.domain.models import ContextUnit


def semantic_delta(previous: ContextUnit, current: ContextUnit) -> ContextUnit:
    if previous.snapshot_hash == current.snapshot_hash and previous.text == current.text:
        return ContextUnit(current.unit_id, "reference", current.path, 1, f"UNCHANGED {current.unit_id}", current.symbol_id, current.start_line, current.end_line, current.snapshot_hash, {"base_hash": previous.snapshot_hash})
    diff = "\n".join(difflib.unified_diff(previous.text.splitlines(), current.text.splitlines(), lineterm=""))
    digest = hashlib.sha256(current.text.encode("utf-8")).hexdigest()
    return ContextUnit(current.unit_id, "delta", current.path, len(diff.split()), diff, current.symbol_id, current.start_line, current.end_line, digest, {"base_hash": previous.snapshot_hash, "target_hash": digest})
