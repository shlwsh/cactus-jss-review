"""CACTUS research prototype.

Failure-aware Budget-constrained Context Optimization for LLM-based Microservice Code Repair.
"""

from __future__ import annotations

__version__ = "0.2.0"

try:
    from graph.dependency_graph import MicroserviceDependencyGraph
    from graph.parser import MicroserviceParser
    from context_optimizer.selector import MarginalUtilitySelector
    from context_optimizer.utility import UtilityModel
    from context_optimizer.budget import BudgetController
    from failure_engine.classifier import FailureClassifier
    from failure_engine.adapter import ContextAdaptiveEngine
    from repair.patch_manager import PatchManager
    from repair.llm_client import LLMRepairClient
    from evaluation.benchmark import MicroserviceBenchmarkRunner
except ImportError:
    pass
