"""Fail-closed retry policy for infrastructure and evaluator failures."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class ErrorCode(StrEnum):
    REPO_CHECKOUT = "E01_REPO_CHECKOUT"
    DEPENDENCY_SETUP = "E02_DEPENDENCY_SETUP"
    CONTAINER_BUILD = "E03_CONTAINER_BUILD"
    CONTAINER_RUNTIME = "E04_CONTAINER_RUNTIME"
    MODEL_GATEWAY = "E05_MODEL_GATEWAY"
    MODEL_TIMEOUT = "E06_MODEL_TIMEOUT"
    PATCH_PARSE = "E07_PATCH_PARSE"
    PATCH_APPLY = "E08_PATCH_APPLY"
    TEST_DISCOVERY = "E09_TEST_DISCOVERY"
    TEST_RUNTIME = "E10_TEST_RUNTIME"
    EVALUATOR_INTERNAL = "E11_EVALUATOR_INTERNAL"
    BILLING_RECORD = "E12_BILLING_RECORD"
    CLEANUP = "E13_CLEANUP"
    UNKNOWN = "E14_UNKNOWN"


RETRYABLE = frozenset({ErrorCode.CONTAINER_BUILD, ErrorCode.CONTAINER_RUNTIME, ErrorCode.MODEL_GATEWAY, ErrorCode.MODEL_TIMEOUT, ErrorCode.TEST_DISCOVERY, ErrorCode.TEST_RUNTIME, ErrorCode.EVALUATOR_INTERNAL, ErrorCode.BILLING_RECORD})


@dataclass(frozen=True, slots=True)
class RetryDecision:
    retry: bool
    attempt_number: int
    backoff_seconds: int
    canonical_outcome: str
    reason: str


class RetryStateMachine:
    def __init__(self, *, max_attempts: int = 3, backoff_seconds: tuple[int, ...] = (30, 120)) -> None:
        if max_attempts < 1 or any(value < 0 for value in backoff_seconds):
            raise ValueError("invalid retry policy")
        self.max_attempts = max_attempts
        self.backoff_seconds = backoff_seconds

    def decide(self, *, attempt_number: int, error_code: ErrorCode | str | None, valid_resolution: bool = False) -> RetryDecision:
        if attempt_number < 1 or attempt_number > self.max_attempts:
            raise ValueError("attempt_number outside configured range")
        if valid_resolution:
            return RetryDecision(False, attempt_number, 0, "VALID_RESOLVED", "valid resolution")
        if error_code is None:
            return RetryDecision(False, attempt_number, 0, "VALID_UNRESOLVED", "valid evaluator outcome")
        code = ErrorCode(error_code)
        retry = code in RETRYABLE and attempt_number < self.max_attempts
        delay = self.backoff_seconds[min(attempt_number - 1, len(self.backoff_seconds) - 1)] if retry and self.backoff_seconds else 0
        return RetryDecision(retry, attempt_number, delay, "INVALID_EVALUATION" if code not in {ErrorCode.PATCH_PARSE, ErrorCode.PATCH_APPLY} else "VALID_UNRESOLVED", "retryable infrastructure/evaluator failure" if retry else "terminal failure")
