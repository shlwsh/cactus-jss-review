"""Hard-fail on publication rendering defects using Poppler text/bbox output."""
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET


def text_errors(text: str):
    patterns = [r"DataValue", r"Q\s*=\s*Q\s*=", r"p\s*=\s*p\s*=", r"%\s*%", r"\bP0-\d", r"(?:\?\?)+"]
    return ["rendered forbidden token: " + pattern for pattern in patterns if re.search(pattern, text)]


def check(pdf: Path, log: Path | None = None):
    extracted = subprocess.run(["pdftotext", "-layout", str(pdf), "-"], check=True, capture_output=True).stdout.decode("utf-8")
    errors = text_errors(extracted)
    if log and log.is_file():
        content = log.read_text(encoding="utf-8", errors="replace")
        for marker in [r"Overfull \\[hv]box", r"Undefined control sequence", r"LaTeX Warning:.*undefined", r"There were undefined references"]:
            if re.search(marker, content):
                errors.append("LaTeX rendering defect: " + marker)
    bbox = subprocess.run(["pdftotext", "-bbox", str(pdf), "-"], check=True, capture_output=True).stdout
    tree = ET.fromstring(bbox)
    pages = list(tree.iter("{http://www.w3.org/1999/xhtml}page"))
    for index, page in enumerate(pages, 1):
        width, height = float(page.attrib["width"]), float(page.attrib["height"])
        for word in page.iter("{http://www.w3.org/1999/xhtml}word"):
            if float(word.attrib["xMin"]) < 0 or float(word.attrib["yMin"]) < 0 or float(word.attrib["xMax"]) > width + .1 or float(word.attrib["yMax"]) > height + .1:
                errors.append(f"text outside page boundary: page {index}")
                break
    if errors:
        raise ValueError("; ".join(errors))
    return {"status": "PASS", "pages": len(pages), "checks": ["forbidden tokens", "unresolved references", "overfull boxes", "text page bounds"],
            "limitation": "table/figure visual layout additionally requires rendered-page inspection"}
