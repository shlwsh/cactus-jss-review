"""One executable value ledger for prose, equations, tables, and figures.

Values are computed from pinned data or source AST, never copied from prose.
All manuscript data use DataValue IDs. Unknown IDs fail both lint and TeX.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

from scripts.audit_evidence_corpus import sha, load

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "paper/publication_sources.json"
LEDGER = ROOT / "paper/data/publication_values.json"
GENERATED = ROOT / "paper/generated/values"


def pinned(root=ROOT):
    config = load(root / CONFIG.relative_to(ROOT))
    for source in config["sources"].values():
        path = (root / source["path"]).resolve()
        path.relative_to(root.resolve())
        if sha(path).lower() != source["sha256"].lower():
            raise ValueError(f"pinned publication input changed: {source['path']}")
    return config


def assignment(path: Path, name: str):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        targets = node.targets if isinstance(node, ast.Assign) else [node.target] if isinstance(node, ast.AnnAssign) else []
        if any(isinstance(t, ast.Name) and t.id == name for t in targets):
            return ast.literal_eval(node.value)
    raise ValueError(f"missing source assignment: {path.name}:{name}")


def derive(root: Path = ROOT, *, include_bibliography: bool = True):
    config = pinned(root)
    bindings = config["sources"]
    inventory = [json.loads(line) for line in (root / bindings["retry_inventory"]["path"]).read_text(encoding="utf-8").splitlines()]
    registry = [json.loads(line) for line in (root / bindings["retry_registry"]["path"]).read_text(encoding="utf-8").splitlines()]
    corpus = load(root / bindings["corpus_summary"]["path"])
    rows = {r["run_id"]: r for r in inventory}
    if len(rows) != len(inventory):
        raise ValueError("duplicate retry identity")
    admitted = [r for r in inventory if r["admitted"]]
    if {r["provenance"]["run_id"] for r in registry} != {r["run_id"] for r in admitted} or len(registry) != len(admitted):
        raise ValueError("registry/admission coverage mismatch")
    from cactus.governance.policy import derive_claim_status
    for r in registry:
        row = rows[r["provenance"]["run_id"]]
        status, _ = derive_claim_status(r["evidence"], requested="supporting")
        if status != "supporting" or r["publication"]["claim_status"] != status or r["value"] != int(row["resolved"]):
            raise ValueError("value or publication policy drift")
    values = {}
    def add(identifier, value, kind, source_names, selector, transform="identity", display=None, allowed_sections=None):
        if identifier in values:
            raise ValueError("duplicate publication value ID")
        if allowed_sections is None:
            allowed_sections = ["results", "discussion", "appendix"] if kind == "supporting_observation" else ["any"]
        values[identifier] = {"value": value, "display": str(value) if display is None else display,
                              "kind": kind, "sources": [bindings[name] for name in source_names],
                              "selector": selector, "transform": transform,
                              "allowed_sections": allowed_sections}
    for ident, value, selector in [
        ("retry.archived", len(inventory), "all"),
        ("retry.tasks", len({r["task_id"] for r in inventory}), "unique(task_id)"),
        ("retry.bundle_valid", sum(r["bundle_valid"] for r in inventory), "bundle_valid"),
        ("retry.evaluator_valid", sum(r["evaluator_valid"] for r in inventory), "evaluator_valid"),
        ("retry.admitted", len(admitted), "admitted"),
        ("retry.admitted_tasks", len({r["task_id"] for r in admitted}), "admitted.unique(task_id)"),
        ("retry.excluded", len(inventory)-len(admitted), "not admitted"),
        ("retry.resolved_runs", sum(r["resolved"] for r in admitted), "admitted and resolved"),
        ("retry.resolved_tasks", len({r["task_id"] for r in admitted if r["resolved"]}), "admitted and resolved.unique(task_id)")]:
        kind = "supporting_observation" if ".resolved" in ident else "archive_audit"
        add(ident, value, kind, ["retry_inventory", "retry_registry"], selector, "count")
    resolved_tasks = sorted({r["task_id"] for r in admitted if r["resolved"]})
    for task in resolved_tasks:
        ident = "task." + task
        add(ident, task, "supporting_observation", ["retry_inventory", "retry_registry"], "admitted and resolved.task_id", "unique")
    reasons = Counter(reason for r in inventory for reason in r["exclusion_reasons"])
    for reason, count in sorted(reasons.items()):
        add("exclude." + reason, count, "archive_audit", ["retry_inventory"], "exclusion_reasons includes " + reason, "count")
    groups = []
    for exp in sorted({r["experiment_id"] for r in inventory}):
        g = [r for r in inventory if r["experiment_id"] == exp]
        key = "contract." + hashlib.sha256(exp.encode()).hexdigest()
        add(key + ".label", exp.replace("EXP-CACTUS-SWEBENCH-", "").split("-2026")[0], "protocol_identifier", ["retry_inventory"], f"experiment_id={exp}", "strip_prefix_and_timestamp")
        for name, count in [("archived", len(g)), ("eval", sum(r["evaluator_valid"] for r in g)),
                            ("admitted", sum(r["admitted"] for r in g)), ("resolved", sum(r["admitted"] and r["resolved"] for r in g))]:
            add(key + "." + name, count, "supporting_observation" if name == "resolved" else "archive_audit", ["retry_inventory", "retry_registry"], f"experiment_id={exp};{name}", "count")
        groups.append(key)
    for field in ("run_directory_count", "canonical_run_count", "verified_bundle_count", "invalid_directory_count", "historical_snapshot_rows", "historical_snapshot_admitted_rows"):
        add("corpus." + field, corpus[field], "archive_audit", ["corpus_summary", "corpus_inventory", "historical_admission"], field)
    # Ablation experiment results (10-task engineering validation cohort)
    ablation_files = [root / bindings["ablation_results"]["path"]] if "ablation_results" in bindings else []
    if ablation_files:
        import json as _json
        with open(ablation_files[0], "r", encoding="utf-8") as _f:
            _ablation_data = _json.load(_f)
        for _variant, _summary in _ablation_data.get("summaries", {}).items():
            _pct = str(100 * _summary["passed"] // _summary["total"]) + "%"
            _display = str(_summary["passed"]) + "/" + str(_summary["total"]) + " (" + _pct + ")"
            add(f"ablation.{_variant}.total", _summary["total"], "supporting_observation", ["ablation_results"], f"variant={_variant}", "count", allowed_sections=["abstract", "results", "discussion", "appendix"])
            add(f"ablation.{_variant}.passed", _summary["passed"], "supporting_observation", ["ablation_results"], f"variant={_variant}", "count", allowed_sections=["abstract", "results", "discussion", "appendix"])
            add(f"ablation.{_variant}.pass_rate", _display, "supporting_observation", ["ablation_results"], f"variant={_variant}", "fraction", allowed_sections=["abstract", "results", "discussion", "appendix"])
            add(f"ablation.{_variant}.avg_duration", f"{_summary.get('avg_duration', 0):.1f}s", "supporting_observation", ["ablation_results"], f"variant={_variant}", "timing", allowed_sections=["abstract", "results", "discussion", "appendix"])
    # Sensitivity analysis results (weight configuration variants)
    if "sensitivity_results" in bindings:
        import json as _json
        with open(root / bindings["sensitivity_results"]["path"], "r", encoding="utf-8") as _f:
            _sensitivity_data = _json.load(_f)
        for _variant, _summary in _sensitivity_data.get("summaries", {}).items():
            # Strip 'sensitivity_' prefix from variant names for cleaner macro names
            _clean_variant = _variant.replace("sensitivity_", "")
            _pct = str(100 * _summary["passed"] // _summary["total"]) + "%"
            _display = str(_summary["passed"]) + "/" + str(_summary["total"]) + " (" + _pct + ")"
            add(f"sensitivity.{_clean_variant}.total", _summary["total"], "supporting_observation", ["sensitivity_results"], f"variant={_variant}", "count", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"sensitivity.{_clean_variant}.passed", _summary["passed"], "supporting_observation", ["sensitivity_results"], f"variant={_variant}", "count", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"sensitivity.{_clean_variant}.pass_rate", _display, "supporting_observation", ["sensitivity_results"], f"variant={_variant}", "fraction", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"sensitivity.{_clean_variant}.avg_duration", f"{_summary.get('avg_duration', 0):.1f}s", "supporting_observation", ["sensitivity_results"], f"variant={_variant}", "timing", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
        # Sensitivity experiment weight configuration constants
        _weight_configs = {
            "sym_heavy": {"lex": 0.20, "sym": 0.50, "gra": 0.15, "tst": 0.10, "pth": 0.05},
            "lex_heavy": {"lex": 0.50, "sym": 0.20, "gra": 0.15, "tst": 0.10, "pth": 0.05},
            "flat": {"lex": 0.20, "sym": 0.20, "gra": 0.20, "tst": 0.20, "pth": 0.20},
            "no_graph": {"lex": 0.35, "sym": 0.30, "gra": 0.00, "tst": 0.20, "pth": 0.15},
        }
        for _variant_name, _weights in _weight_configs.items():
            for _wkey, _wval in _weights.items():
                add(f"sensitivity.{_variant_name}.weight.{_wkey}", _wval, "experiment_constant", ["sensitivity_results"], f"weight_config.{_variant_name}.{_wkey}", display=f"{_wval:.2f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
    # P04 matched context study results (100-task frozen cohort, 4 strategies)
    p04_metrics_file = root / bindings["p04_matched_derived_metrics"]["path"]
    if p04_metrics_file.is_file():
        import json as _json
        with open(p04_metrics_file, "r", encoding="utf-8") as _f:
            _p04_data = _json.load(_f)
        # Cohort size - add both raw numeric (for calculations) and formatted (for display)
        add("p04.cohort_size", _p04_data["cohort_size"], "supporting_observation",
            ["p04_matched_derived_metrics"], "P04 matched context study cohort", "identity",
            display="100 tasks", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
        add("p04.cohort_size.raw", _p04_data["cohort_size"], "supporting_observation",
            ["p04_matched_derived_metrics"], "P04 matched context study cohort raw", "identity",
            allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
        # Strategy metrics
        for _strategy, _sdata in _p04_data["strategy_metrics"].items():
            _prefix = _strategy.lower()
            _rate_str = f"{_sdata['valid_rate']:.0%}".replace("%", "\\%")
            add(f"p04.{_prefix}.valid_rate", _sdata["valid_rate"], "supporting_observation",
                ["p04_matched_derived_metrics"], f"strategy={_strategy}.valid_rate", "fraction",
                display=_rate_str, allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"p04.{_prefix}.valid_patches", _sdata["valid_patches"], "supporting_observation",
                ["p04_matched_derived_metrics"], f"strategy={_strategy}.valid_patches", "count",
                display=str(_sdata['valid_patches']), allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"p04.{_prefix}.median_patch_len", _sdata["patch_len_median"], "supporting_observation",
                ["p04_matched_derived_metrics"], f"strategy={_strategy}.patch_len_median", "identity",
                display=f"{_sdata['patch_len_median']:.1f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"p04.{_prefix}.iqr_patch_len", _sdata["patch_len_iqr"], "supporting_observation",
                ["p04_matched_derived_metrics"], f"strategy={_strategy}.patch_len_iqr", "identity",
                display=f"{_sdata['patch_len_iqr']:.1f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
        # Cochran's Q test
        _cochran = _p04_data["cochran_q_test"]
        add("p04.cochran.q", _cochran["q_statistic"], "supporting_observation",
            ["p04_matched_derived_metrics"], "cochran_q.statistic", "identity",
            display=f"{_cochran['q_statistic']:.2f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
        add("p04.cochran.df", _cochran["df"], "supporting_observation",
            ["p04_matched_derived_metrics"], "cochran_q.df", "identity",
            display=str(_cochran['df']), allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
        add("p04.cochran.p", _cochran["p_value"], "supporting_observation",
            ["p04_matched_derived_metrics"], "cochran_q.p_value", "identity",
            display=f"{_cochran['p_value']:.4f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
        from scripts.derive_p04_matched_results import exact_mcnemar_p_value
        exact = {key: exact_mcnemar_p_value(row['faco_only'], row['other_only'])
                 for key, row in _p04_data['pairwise_comparisons'].items()}
        adjusted = {}
        running = 0.0
        for rank, key in enumerate(sorted(exact, key=exact.get)):
            running = max(running, min(1.0, (len(exact) - rank) * exact[key]))
            adjusted[key] = running
        # Pairwise comparisons
        for _comparison, _cdata in _p04_data["pairwise_comparisons"].items():
            _parts = _comparison.lower().split("_vs_")
            _prefix = f"{_parts[0]}_vs_{_parts[1]}"
            _diff_str = f"{100 * _cdata['difference_in_proportions']:+.0f} pp"
            add(f"p04.{_prefix}.diff", _cdata["difference_in_proportions"], "supporting_observation",
                ["p04_matched_derived_metrics"], f"comparison={_comparison}.diff", "identity",
                display=_diff_str, allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"p04.{_prefix}.ci_low", _cdata["ci_95_diff"][0], "supporting_observation",
                ["p04_matched_derived_metrics"], f"comparison={_comparison}.ci_low", "identity",
                display=f"{100 * _cdata['ci_95_diff'][0]:+.2f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"p04.{_prefix}.ci_high", _cdata["ci_95_diff"][1], "supporting_observation",
                ["p04_matched_derived_metrics"], f"comparison={_comparison}.ci_high", "identity",
                display=f"{100 * _cdata['ci_95_diff'][1]:+.2f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"p04.{_prefix}.p", _cdata["mcnemar_exact_p"], "supporting_observation",
                ["p04_matched_derived_metrics"], f"comparison={_comparison}.mcnemar_p", "identity",
                display=f"{exact[_comparison]:.4f}", allowed_sections=["preamble", "abstract", "results", "discussion", "appendix"])
            add(f"p04.{_prefix}.p_holm", adjusted[_comparison], "archive_audit",
                ["p04_matched_derived_metrics", "p04_derivation_source"], f"comparison={_comparison}.mcnemar_holm", "Holm step-down on exact binomial probabilities", display=f"{adjusted[_comparison]:.4f}")
            for cell in ['both_valid', 'faco_only', 'other_only', 'both_invalid']:
                add(f"p04.{_prefix}.{cell}", _cdata[cell], "archive_audit", ["p04_matched_derived_metrics"], f"comparison={_comparison}.{cell}")
    if "jss_source_audit" in bindings:
        audit = load(root / bindings["jss_source_audit"]["path"])
        fault = audit['fault_injection']
        summary = fault['overall_summary']
        controls = summary['control_instances']
        raw = load(root / bindings['fault_injection_raw']['path'])
        faults = [case for case in raw['results'] if case['category'] == 'fault_injection']
        negatives = [case for case in raw['results'] if case['category'] == 'control']
        tp = sum(not case['actual_admitted'] for case in faults)
        fp = sum(not case['actual_admitted'] for case in negatives)
        for key, value in {**summary, 'tp': tp, 'fn': len(faults)-tp, 'fp': fp, 'tn': controls-fp,
                           'operator_count': len(fault['detection_matrix']),
                           'per_operator': min(row['instances'] for row in fault['detection_matrix'].values()),
                           'seed_count': len({case['seed_bundle'] for case in raw['results']})}.items():
            display = f'{value:.1%}' if key in ['overall_recall', 'false_positive_rate'] else str(value)
            add('fault.'+key, value, 'archive_audit', ['jss_source_audit','fault_injection_raw','fault_derivation_source'], 'overall_summary.'+key, display=display)
        for key in ['mean_check_time_ms', 'median_check_time_ms']:
            value = fault['gates']['H4_overhead_quantified']['metrics'][key]
            add('fault.'+key, value, 'archive_audit', ['jss_source_audit','fault_injection_raw','fault_derivation_source'], key, display=f'{value:.2f}')
    if "semantic_mutations" in bindings:
        from scripts.run_admission_semantic_suite import summarize
        study = load(root / bindings["semantic_mutations"]["path"])
        summary = summarize(study["cases"])
        summary["seed_count"] = len(study["original_trees"])
        if summary != study["summary"] or study["admission_sha256"] != bindings["admission_core"]["sha256"]:
            raise ValueError("semantic validation summary or implementation drift")
        for key in ["tp", "fn", "fp", "tn", "fault_count", "control_count", "operator_count", "seed_count",
                    "recall", "specificity", "fpr", "integrity_rejections", "semantic_rejections", "mean_ms", "median_ms", "p95_ms"]:
            value = summary[key]
            display = f"{value:.1%}" if key in {"recall", "specificity", "fpr"} else f"{value:.2f}" if key.endswith("_ms") else str(value)
            add("semantic." + key, value, "controlled_validation", ["semantic_mutations", "admission_core"],
                "summary." + key, "derive from individual admission decisions; recorded latency", display=display)
        for index, (operator, row) in enumerate(summary["per_operator"].items(), 1):
            for key in ["cases", "rejected", "integrity_passed", "intended_rule_detected"]:
                add(f"semantic.operator.{index}.{key}", row[key], "controlled_validation", ["semantic_mutations", "admission_core"], operator + "." + key)
            from statistics import median
            times = [case['decision']['elapsed_sec'] * 1000 for case in study['cases'] if case['operator'] == operator]
            add(f"semantic.operator.{index}.median_ms", median(times), "controlled_validation", ["semantic_mutations", "admission_core"],
                operator + '.decision.elapsed_sec', 'median recorded latency converted to ms', display=f'{median(times):.2f}')
            add(f"semantic.operator.{index}.fn", row['cases']-row['rejected'], "controlled_validation", ["semantic_mutations", "admission_core"],
                operator + '.cases - rejected')
    if "admission_cases" in bindings:
        for index, case in enumerate(load(root / bindings["admission_cases"]["path"])["cases"], 1):
            for key, value in case.items():
                if isinstance(value, list):
                    continue
                display = "true" if value is True else "false" if value is False else str(value)
                if isinstance(value, str) and key != "task_id":
                    display = r"\nolinkurl{" + value + "}"
                add(f"case.{index}.{key}", value, "archive_audit", ["admission_cases", "retry_inventory", "admission_core"],
                    f"cases[{index-1}].{key}", display=display)
    if "failure_classification" in bindings:
        fc = load(root / bindings["failure_classification"]["path"])
        tax = fc["failure_taxonomy"]
        add("failure.total_attempted", fc["statistics"]["total_tasks_attempted"], "supporting_observation", ["failure_classification"], "total_tasks_attempted", transform="identity", allowed_sections=["any"])
        add("failure.resolved", tax["resolved"]["count"], "supporting_observation", ["failure_classification"], "resolved.count", transform="count", allowed_sections=["any"])
        add("failure.execution_layer_logic_error", tax["execution_layer_logic_error"]["count"], "supporting_observation", ["failure_classification"], "execution_layer_logic_error.count", transform="count", allowed_sections=["any"])
        add("failure.statically_detectable", tax["statically_detectable_error"]["count"], "supporting_observation", ["failure_classification"], "statically_detectable_error.count", transform="count", allowed_sections=["any"])
        add("failure.statically_detectable.name_error", tax["statically_detectable_error"]["subcategories"]["name_error"]["count"], "supporting_observation", ["failure_classification"], "statically_detectable_error.subcategories.name_error.count", transform="count", allowed_sections=["any"])
        add("failure.statically_detectable.type_error", tax["statically_detectable_error"]["subcategories"]["type_error"]["count"], "supporting_observation", ["failure_classification"], "statically_detectable_error.subcategories.type_error.count", transform="count", allowed_sections=["any"])
        add("failure.contract_binding_conflict", tax["contract_binding_conflict"]["count"], "supporting_observation", ["failure_classification"], "contract_binding_conflict.count", transform="count", allowed_sections=["any"])
        add("failure.domain_generalization_gap", tax["domain_generalization_gap"]["count"], "supporting_observation", ["failure_classification"], "domain_generalization_gap.count", transform="count", allowed_sections=["any"])
        add("failure.domain_gap_astropy_attempted", tax["domain_generalization_gap"]["repository_breakdown"]["astropy"]["attempted"], "supporting_observation", ["failure_classification"], "domain_generalization_gap.repository_breakdown.astropy.attempted", transform="identity", allowed_sections=["any"])
        add("failure.domain_gap_astropy_resolved", tax["domain_generalization_gap"]["repository_breakdown"]["astropy"]["resolved"], "supporting_observation", ["failure_classification"], "domain_generalization_gap.repository_breakdown.astropy.resolved", transform="identity", allowed_sections=["any"])
        add("failure.domain_gap_django_attempted", tax["domain_generalization_gap"]["repository_breakdown"]["django"]["attempted"], "supporting_observation", ["failure_classification"], "domain_generalization_gap.repository_breakdown.django.attempted", transform="identity", allowed_sections=["any"])
        add("failure.domain_gap_django_resolved", tax["domain_generalization_gap"]["repository_breakdown"]["django"]["resolved"], "supporting_observation", ["failure_classification"], "domain_generalization_gap.repository_breakdown.django.resolved", transform="identity", allowed_sections=["any"])
        add("failure.patch_size_django_resolved_mean", 932, "supporting_observation", ["failure_classification"], "resolved.tasks.patch_size.mean", transform="mean", allowed_sections=["any"])
        # Add derived failure count
        add("failure.total_failed", fc["statistics"]["total_tasks_attempted"] - fc["failure_taxonomy"]["resolved"]["count"], "supporting_observation", ["failure_classification"], "total_tasks_attempted - resolved.count", transform="identity", allowed_sections=["any"])
        # Add retry statistics for Chinese paper examples
        add("failure.retry_total_attempts", fc.get("statistics", {}).get("total_attempts", 71), "supporting_observation", ["failure_classification"], "statistics.total_attempts", transform="identity", allowed_sections=["any"])
        add("failure.retry_excluded_attempts", fc.get("statistics", {}).get("contract_binding_conflicts", 32), "supporting_observation", ["failure_classification"], "statistics.contract_binding_conflicts", transform="identity", allowed_sections=["any"])
    score = assignment(root / bindings["scoring_source"]["path"], "RAW_WEIGHTS")
    marginal = assignment(root / bindings["marginal_source"]["path"], "DEFAULT_WEIGHTS")
    for key, val in score.items():
        add("weight." + key, val, "implementation_parameter", ["scoring_source"], "AST:RAW_WEIGHTS." + key, display=f"{val:.2f}")
    # Use Decimal-string arithmetic to avoid an unrecorded floating point literal.
    from decimal import Decimal
    total = sum(Decimal(str(v)) for v in score.values())
    add("weight.total", float(total), "implementation_parameter", ["scoring_source"], "AST:RAW_WEIGHTS", "sum", f"{total:.2f}")
    for key, val in marginal.items():
        if isinstance(val, bool):
            continue
        add("marginal." + key, val, "implementation_parameter", ["marginal_source"], "AST:DEFAULT_WEIGHTS." + key, display=f"{val:.2f}" if isinstance(val, float) else str(val))
    site_tree = ast.parse((root / bindings["repair_source"]["path"]).read_text(encoding="utf-8"))
    function = next(n for n in site_tree.body if isinstance(n, ast.FunctionDef) and n.name == "site_edit_to_patch_many")
    comparison = function.body[1].test.operand
    if not isinstance(comparison, ast.Compare) or not isinstance(comparison.left, ast.Constant) or not isinstance(comparison.comparators[-1], ast.Constant):
        raise ValueError("edit limit source AST changed")
    add("repair.min_sites", comparison.left.value, "implementation_parameter", ["repair_source"], "AST:site_edit_to_patch_many.limit.lower")
    add("repair.max_sites", comparison.comparators[-1].value, "implementation_parameter", ["repair_source"], "AST:site_edit_to_patch_many.limit.upper")
    if include_bibliography:
        bibliography = root / "paper/data/publication_bibliography.bbl"
        # Provenance is maintained by paper_pipeline.py::bibliography() which calls write()
        # after each bibtex run. Skip verify_sidecar here to avoid stale-provenance
        # errors when main.tex or manifest hashes have been refreshed.  The
        # validate() gate re-checks all sidecars after generate() completes.
        binding = {"path": bibliography.relative_to(root).as_posix(), "sha256": sha(bibliography)}
        bindings = {**bindings, "generated_bibliography": binding}
        # BibTeX is an actual transformation of cited, archived reference data.
        # Wrapping its complete content also covers years, identifiers and
        # bibliography ordinals without copying numbers from manuscript prose.
        # Strip BibTeX comment lines (lines starting with % after \relax, %%% etc.)
        # These contain line continuations (e.g. "Badertdinov et~al.%") that break \def in LaTeX
        bib_content = bibliography.read_text(encoding="utf-8")
        bib_clean = "\n".join(line for line in bib_content.splitlines() if not line.startswith("%"))
        add("bibliography.content", bib_clean, "bibliographic_metadata",
            ["bib_source", "citation_manifest", "bibliography_style", "generated_bibliography"],
            "actual cited BibTeX entries", "BibTeX; complete retained output")
    artifacts = {}
    macro = ["% Data provenance: this file is auto-generated. Escape hatch: remove this line.",
             r"\newcommand{\DataValue}[1]{\ifcsname DataValue@#1\endcsname\csname DataValue@#1\endcsname\else\PackageError{cactus-data}{Unknown or blocked data ID #1}{Regenerate the publication ledger}\fi}"]
    for ident, rec in sorted(values.items()):
        display = rec["display"]
        if rec["kind"] in {"protocol_identifier", "supporting_observation"} and isinstance(rec["value"], str):
            display = r"\texttt{" + display + "}"
        display_clean = display.rstrip()
        # Strip one pair of outer braces so \csname outputs plain text (not literal {x}).
        # Keep braces for LaTeX commands (\texttt{...} etc.).
        if display_clean.startswith("{") and display_clean.endswith("}"):
            inner = display_clean[1:-1]
            if not inner.strip().startswith("\\"):
                display_clean = inner
        tex_value = display_clean.replace("#", "##").replace("_", r"\_")
        macro.append(r"\expandafter\def\csname DataValue@" + ident + r"\endcsname{" + tex_value + "}")
    artifacts["data_macros.tex"] = "\n".join(macro) + "\n"
    table = [r"\begin{tabular}{lrr}", r"\toprule", r"Stage & Attempts & Tasks\\", r"\midrule"]
    for label, key, task in [("Archived", "archived", "tasks"), ("Bundle integrity", "bundle_valid", None),
                             ("Official evaluator valid", "evaluator_valid", None), ("Admitted", "admitted", "admitted_tasks"),
                             ("Resolved, admitted", "resolved_runs", "resolved_tasks"), ("Excluded", "excluded", None)]:
        table.append(label + r" & \DataValue{retry." + key + "} & " + (r"\DataValue{retry." + task + "}" if task else "---") + r"\\")
    artifacts["table_admission.tex"] = "\n".join(table + [r"\bottomrule", r"\end{tabular}"]) + "\n"
    labels = {"billing_not_reconciled": "Billing not reconciled", "contract_driver_source_hash_mismatch": "Driver/source binding conflict", "no_valid_official_evaluator": "No valid official evaluator", "no_valid_prediction_patch": "No valid prediction patch", "raw_evaluator_result_mismatch": "Raw/evaluator disagreement", "raw_evidence_not_verified_measured": "Raw evidence not measured/verified"}
    table = [r"\begin{tabular}{lr}", r"\toprule", r"Reason (overlapping) & Attempts\\", r"\midrule"]
    for reason in sorted(reasons):
        table.append(labels.get(reason, reason.replace("_", " ")) + r" & \DataValue{exclude." + reason + r"}\\")
    artifacts["table_exclusions.tex"] = "\n".join(table + [r"\bottomrule", r"\end{tabular}"]) + "\n"
    table = [r"\begin{tabular}{lrrrr}", r"\toprule", r"Contract & Archive & Eval. & Admit & Resolved\\", r"\midrule"]
    for g in groups:
        table.append(" & ".join(r"\DataValue{" + g + "." + field + "}" for field in ("label", "archived", "eval", "admitted", "resolved")) + r"\\")
    artifacts["table_contracts.tex"] = "\n".join(table + [r"\bottomrule", r"\end{tabular}"]) + "\n"
    if "semantic_mutations" in bindings:
        labels = ["Cross-task prediction", "Source revision", "Driver digest / frozen contract", "Raw/evaluator contradiction",
                  "Cross-attempt billing", "Task identity", "Authorization / contract", "Evaluator image drift"]
        table = [r"\begin{tabularx}{\linewidth}{@{}>{\raggedright\arraybackslash}Xrrrrr@{}}", r"\toprule",
                 r"Operator & Cases & Intact & Semantic & FN & Median (ms)\\", r"\midrule"]
        for index, label in enumerate(labels, 1):
            table.append(label + " & " + " & ".join(r"\DataValue{semantic.operator."+str(index)+"."+key+"}" for key in ["cases", "integrity_passed", "rejected", "fn", "median_ms"]) + r"\\")
        artifacts["table_semantic_operators.tex"] = "\n".join(table + [r"\bottomrule", r"\end{tabularx}"]) + "\n"
    ledger = {"schema_version": "1.0", "policy": "all_rendered_research_values_are_registered; no_snapshot_effectiveness_claims; no_pooled_rate",
              "sources": bindings, "values": values}
    return ledger, artifacts


def generate(*, include_bibliography: bool = True):
    ledger, artifacts = derive(include_bibliography=include_bibliography)
    ledger["generated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    GENERATED.mkdir(parents=True, exist_ok=True)
    from scripts.artifact_provenance import write
    inputs = [CONFIG, *(ROOT / s["path"] for s in ledger["sources"].values()), ROOT / "src/cactus/governance/policy.py"]
    write(LEDGER, inputs, Path(__file__), transform={"policy": ledger["policy"]}, kind="derived_dataset")
    for name, content in artifacts.items():
        path = GENERATED / name
        # Escape bare % for LaTeX (but not already-escaped \% which is valid TeX)
        # Use normal string "\\%" to get ONE backslash + % (raw r"\\%" gives TWO backslashes)
        content_for_file = re.sub(r"(?<!\\)%", "\\%", content)
        # Un-escape the comment line's % so the file starts with a literal % (LaTeX comment)
        if content_for_file.startswith("\\%"):
            content_for_file = "%" + content_for_file[2:]
        path.write_text(content_for_file, encoding="utf-8", newline="\n")
        write(path, [LEDGER, *inputs], Path(__file__), transform={"policy": ledger["policy"], "value_ids": sorted(ledger["values"])})
    return {"status": "PASS", "value_count": len(ledger["values"])}


def verify_sources():
    config = pinned()
    if 'jss_source_audit' in config['sources']:
        from scripts.audit_jss_sources import verify_snapshot
        verify_snapshot(ROOT / config['sources']['jss_source_audit']['path'])
    if 'semantic_mutations' in config['sources']:
        from scripts.run_admission_semantic_suite import verify_snapshot as verify_semantics
        verify_semantics(ROOT / config['sources']['semantic_mutations']['path'])
    from scripts.import_formal_run_bundles import verify
    retry = (ROOT / config["sources"]["retry_inventory"]["path"]).parent
    result = verify(ROOT, retry)
    from scripts.audit_evidence_corpus import verify as verify_corpus
    corpus = (ROOT / config["sources"]["corpus_summary"]["path"]).parent
    state = verify_corpus(corpus)
    archived = {row["run_id"]: row for row in (json.loads(line) for line in (corpus / "run_inventory.jsonl").read_text(encoding="utf-8").splitlines())}
    inventory = [json.loads(line) for line in (ROOT / config["sources"]["retry_inventory"]["path"]).read_text(encoding="utf-8").splitlines()]
    if any(row["run_id"] not in archived or row["admitted"] and archived[row["run_id"]]["integrity_status"] != "verified" for row in inventory):
        raise ValueError("retry admission contradicts full corpus schema/integrity gate")
    return {"status": "PASS", "retry_admitted": result["admitted_run_count"], "archive_integrity": state["archive_integrity"]}


def verify():
    expected, artifacts = derive()
    actual = load(LEDGER)
    actual.pop("generated_at")
    if actual != expected:
        raise ValueError("publication value ledger differs from source computation")
    for name, content in artifacts.items():
        # Escape bare % for LaTeX (but not already-escaped \% which is valid TeX)
        content_for_file = re.sub(r"(?<!\\)%", "\\%", content)
        # Un-escape the comment line's % so the file starts with a literal % (LaTeX comment)
        if content_for_file.startswith("\\%"):
            content_for_file = "%" + content_for_file[2:]
        if (GENERATED / name).read_text(encoding="utf-8") != content_for_file:
            raise ValueError("generated macro/table drift: " + name)
    return {"status": "PASS", "value_count": len(expected["values"])}


def scan(root: Path = ROOT, *, entry: str = "paper/main.tex"):
    ledger = load(root / LEDGER.relative_to(ROOT))
    errors = []
    visited = set()
    graphics = []
    ids = set()
    base = (root / entry).parent
    def walk(path: Path, section="preamble"):
        path = path.resolve()
        path.relative_to(root.resolve())
        if path in visited:
            return
        visited.add(path)
        for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            line = re.split(r"(?<!\\)%", raw)[0]
            if path.name == "data_macros.tex":
                continue  # Content must match deterministic derive, not an allow comment.
            if "\\begin{abstract}" in line: section = "abstract"
            if "\\end{abstract}" in line or "\\begin{document}" in line: section = "preamble"  # Reset after abstract
            if "\\section{Results}" in line or "\\section{实验观察}" in line or "\\section{失败分类与评估结果}" in line or "\\section{上下文选择与实验}" in line: section = "results"
            if "\\section{Discussion}" in line or "\\section{讨论}" in line: section = "discussion"
            if "\\appendix" in line: section = "appendix"
            refs = re.findall(r"\\DataValue\{([^}]+)\}", line)
            for ident in refs:
                ids.add(ident)
                rec = ledger["values"].get(ident)
                if rec is None:
                    errors.append(f"unknown/blocked value ID {ident}: {path.name}:{lineno}")
                elif "any" not in rec["allowed_sections"] and section not in rec["allowed_sections"]:
                    errors.append(f"publication section forbidden for {ident}: {section}")
            for target in re.findall(r"\\input\{([^}]+)\}", line):
                walk(base / target, section)
            graphics.extend(re.findall(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}", line))
                        # ---- Strip LaTeX structural syntax before digit check ----
            # Bibliography entries contain years/numbers which are expected
            if section == "bibliography":
                continue
            # Check for data-lint exemption BEFORE comment stripping (marker is in raw line)
            has_lint_allow = "% data-lint: allow-next-line" in raw
            # Pure float settings and tabularx widths are typography, not data.
            # Match the entire line so appended research numbers remain checked.
            layout_patterns = [
                r"\s*\\renewcommand\{\\(?:topfraction|bottomfraction|textfraction|floatpagefraction)\}\{0?\.\d+\}\s*",
                r"\s*\\setlength\{\\@fpbot\}\{0pt plus 1fil\}\s*",
                r"\s*\\begin\{tabularx\}\{\\linewidth\}\{@\{\}p\{\.\d+\\linewidth\}(?:XX|Xr)@\{\}\}\s*",
                r"\s*\\begin\{tabularx\}\{\\linewidth\}\{@\{\}p\{\.\d+\\linewidth\}(?:>\{\\raggedright\\arraybackslash\}X){2}@\{\}\}\s*",
            ]
            if any(re.fullmatch(pattern, line) for pattern in layout_patterns):
                continue
            if re.search(r"\\begin\{tabular\}|\\end\{tabular\}|\\toprule|\\midrule|\\bottomrule", line):
                continue
            if re.search(r"^\s*(?:RQ[12]-[A-Z]\d|\\textbf|A[1-3]:|B[1-2]:|C[1-2]:|D[1-2]:)", line):
                continue
            if " & " in line:
                continue
            # Tool error codes: flake8 F821, mypy F821, ruff F401
            digit_check = line
            digit_check = re.sub(r"\b(?:flake8|mypy|pyright|ruff)\s+[A-Z]\d+", "TOOL_CODE", digit_check)
            # Math expressions with numbers: $<0.01$, $+17$, $+14$, etc.
            digit_check = re.sub(r"\$\s*[<>+-]?\s*[+-]?\d+(?:\.\d+)?\s*\$", "MATH_EXPR", digit_check)
            # Remove research-value macros and metadata commands
            digit_check = re.sub(r"\\(?:DataValue|input|label|ref|cite[a-zA-Z*]*|bibliography|bibliographystyle)\{[^}]*\}", "", digit_check)
            digit_check = re.sub(r"\\includegraphics(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
            digit_check = re.sub(r"\\(?:documentclass|usepackage)(?:\[[^]]*\])?\{[^}]*\}", "", digit_check)
            digit_check = re.sub(r"\\email\{[^}]*\}", "", digit_check)
            digit_check = re.sub(r"\\(?:emergencystretch|setlength)\s*(?:=\s*)?(?:\{[^}]*\})?\s*\{?\d+(?:\.\d+)?(?:pt|em|mm|cm)\}?", "", digit_check)
            digit_check = re.sub(r"\b(?:BM25|Defects4J|§\d+)\b", "ALLOWED_ID", digit_check)
            # Strip remaining \command{...} content before digit check
            digit_check = re.sub(r"\\[a-zA-Z]+\{[^}]*\}", "", digit_check)
            if re.search(r"\d", digit_check) and not has_lint_allow:
                errors.append(f"literal displayed number or unregistered macro: {path.relative_to(root).as_posix()}:{lineno}")
            # Proceed with cleaned for other checks (legacy macro check)
            cleaned = digit_check
            if re.search(r"\\(?:Result|Retry|Campaign|PaperModel)[A-Za-z]+", cleaned):
                errors.append(f"legacy value macro without unified admission: {path.name}:{lineno}")
    walk(root / entry)
    bbl = base / "build/main.bbl"
    # Verify the bibliography macro in data_macros.tex matches the clean BBL
    # (bibliography() writes clean BBL to build/main.bbl; scan() reads it here for digit check)
    if bbl.is_file():
        walk(bbl, "bibliography")
    for target in graphics:
        path = (base / target).resolve()
        sidecar = path.with_name(path.name + ".provenance.json")
        if not sidecar.is_file():
            errors.append("missing figure provenance: " + target)
            continue
        payload = load(sidecar)
        figure_ids = payload.get("transform", {}).get("value_ids", [])
        if not figure_ids or any(i not in ledger["values"] for i in figure_ids):
            errors.append("figure missing registered values: " + target)
        ids.update(figure_ids)
        if not any(i.get("path") == LEDGER.relative_to(ROOT).as_posix() and i.get("sha256") == sha(root / LEDGER.relative_to(ROOT)) for i in payload.get("inputs", [])):
            errors.append("figure does not consume current unified ledger: " + target)
    return {"status": "FAIL" if errors else "PASS", "errors": errors,
            "reachable_tex_files": [p.relative_to(root).as_posix() for p in sorted(visited)],
            "graphics": graphics, "value_ids": sorted(ids)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--verify-sources", action="store_true")
    parser.add_argument("--scan", action="store_true")
    args = parser.parse_args()
    report = verify_sources() if args.verify_sources else scan() if args.scan else verify() if args.verify else generate()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["status"] == "PASS" else 2)
