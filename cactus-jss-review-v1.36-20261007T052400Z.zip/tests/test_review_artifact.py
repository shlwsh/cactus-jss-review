"""Review reproduction must reject changed inputs before regeneration."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from scripts import reproduce_review_artifact as artifact


class ReviewArtifactTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root/'input.txt').write_text('bound bytes',encoding='utf-8')
        self.manifest={'schema_version':'1.0','input_hashes':{
            'input.txt':hashlib.sha256((self.root/'input.txt').read_bytes()).hexdigest()}}
        self.binding=patch.object(artifact,'ROOT',self.root)
        self.binding.start(); self.addCleanup(self.binding.stop)
        self.save()

    def save(self):
        (self.root/'artifact_manifest.json').write_text(json.dumps(self.manifest),encoding='utf-8')

    def test_valid_package(self):
        self.assertEqual(artifact.verify_package(),self.manifest)

    def test_changed_input_fails_before_regeneration(self):
        (self.root/'input.txt').write_text('changed bytes',encoding='utf-8')
        with patch.object(artifact,'run') as run:
            with self.assertRaisesRegex(ValueError,'input changed'):
                artifact.reproduce('all')
            run.assert_not_called()

    def test_path_escape_fails(self):
        self.manifest['input_hashes']={'../outside.txt':'a'*64}; self.save()
        with self.assertRaises(ValueError): artifact.verify_package()

    def test_empty_bindings_are_not_verified(self):
        self.manifest['input_hashes']={}; self.save()
        with self.assertRaisesRegex(ValueError,'invalid review artifact manifest'):
            artifact.verify_package()

    def test_non_sha256_binding_fails(self):
        self.manifest['input_hashes']['input.txt']='abc'; self.save()
        with self.assertRaisesRegex(ValueError,'invalid input digest'):
            artifact.verify_package()


if __name__=='__main__': unittest.main()
