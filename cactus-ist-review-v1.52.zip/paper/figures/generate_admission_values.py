"""Render a modern stepped admission funnel solely from registered ledger values."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from plot_style import apply_style, COLORS, TINTS
from scripts.artifact_provenance import write


def generate():
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt
    from matplotlib.patches import FancyBboxPatch, Polygon

    apply_style()
    source = ROOT / "paper/data/publication_values.json"
    values = json.loads(source.read_text(encoding="utf-8"))["values"]
    identifiers = ["retry.archived", "retry.bundle_valid", "retry.evaluator_valid", "retry.admitted"]
    labels = ["Archived attempts", "Bundle integrity (I)", "Official evaluator valid", "Admitted evidence (I ∧ S)"]
    amounts = [values[key]["value"] for key in identifiers]
    displays = [values[key]["display"] for key in identifiers]
    bar_colors = [COLORS["error"], COLORS["method_light"], COLORS["method"], COLORS["resolved"]]

    fig, ax = plt.subplots(figsize=(5.6, 2.35))
    ax.set_xlim(0, 10.2)
    ax.set_ylim(-0.35, 4.35)
    ax.axis("off")

    max_amt = max(amounts)
    center_x = 5.95
    max_w = 5.4
    bar_h = 0.62
    ys = [3.35, 2.28, 1.21, 0.14]

    widths = [max_w * (a / max_amt) for a in amounts]

    # Subtle funnel transition ribbons between stages
    for i in range(len(ys) - 1):
        w_top = widths[i]
        w_bot = widths[i + 1]
        y_top = ys[i]
        y_bot = ys[i + 1] + bar_h
        poly = Polygon(
            [
                (center_x - w_top / 2, y_top),
                (center_x + w_top / 2, y_top),
                (center_x + w_bot / 2, y_bot),
                (center_x - w_bot / 2, y_bot),
            ],
            closed=True,
            facecolor="#E2E8F0",
            edgecolor="none",
            alpha=0.55,
            zorder=1,
        )
        ax.add_patch(poly)

    # Rounded stage bars with centered white ledger values and crisp left labels
    for y, w, lbl, disp, col in zip(ys, widths, labels, displays, bar_colors):
        x0 = center_x - w / 2
        ax.add_patch(FancyBboxPatch(
            (x0 + 0.04, y - 0.04), w, bar_h,
            boxstyle="round,pad=0.02,rounding_size=0.14",
            facecolor="#CBD5E1", edgecolor="none", alpha=0.45, zorder=2,
        ))
        ax.add_patch(FancyBboxPatch(
            (x0, y), w, bar_h,
            boxstyle="round,pad=0.02,rounding_size=0.14",
            facecolor=col, edgecolor="#FFFFFF", linewidth=1.1, zorder=3,
        ))
        ax.text(center_x, y + bar_h / 2, disp, ha="center", va="center", fontsize=9.2, fontweight="bold", color="#FFFFFF", zorder=4)
        ax.text(3.05, y + bar_h / 2, lbl, ha="right", va="center", fontsize=8.3, fontweight="bold" if col == COLORS["resolved"] else "normal", color=COLORS["text"], zorder=4)
        # Dotted leader line from label to funnel edge
        ax.plot([3.16, x0 - 0.10], [y + bar_h / 2, y + bar_h / 2], color="#CBD5E1", linestyle=":", linewidth=1.0, zorder=2)

    ax.text(center_x, 4.18, "Successive Admission Funnel (Attempt Counts)", ha="center", va="center", fontsize=8.8, fontweight="bold", color=COLORS["text"])
    ax.text(center_x, -0.22, "Every count is rendered directly from the unified value ledger", ha="center", va="center", fontsize=7.2, color=COLORS["subtext"])

    fig.tight_layout(pad=0.2)
    out = ROOT / "paper/figures/output"
    out.mkdir(parents=True, exist_ok=True)
    for suffix in ("pdf", "png", "svg"):
        path = out / ("fig_admission_values." + suffix)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        write(
            path,
            [source, Path(__file__).with_name("plot_style.py")],
            Path(__file__),
            transform={"value_ids": identifiers, "numeric_ticks": "none", "numeric_annotations": "ledger.display"},
            kind="figure",
        )
    plt.close(fig)


if __name__ == "__main__":
    generate()
