"""Generate a modern swimlane architecture diagram for CACTUS evidence flow."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import FancyBboxPatch
from plot_style import apply_style, COLORS, TINTS, draw_card, draw_flow_arrow, draw_pill
from scripts.artifact_provenance import write


def generate_figure():
    apply_style()
    fig, ax = plt.subplots(figsize=(7.2, 2.75))
    ax.set_xlim(0, 10.6)
    ax.set_ylim(0, 4.15)
    ax.axis("off")

    # Subtle swimlane backdrop for the main governance pipeline
    ax.add_patch(FancyBboxPatch(
        (0.12, 1.88), 10.36, 2.10,
        boxstyle="round,pad=0.05,rounding_size=0.18",
        facecolor="#F8FAFC", edgecolor="#CBD5E1", linewidth=0.9, linestyle="-", zorder=0,
    ))
    ax.text(0.28, 3.82, "MAIN GOVERNANCE PIPELINE", fontsize=7.0, fontweight="bold", color=COLORS["error"], va="center")

    # Three numbered stage cards
    draw_card(
        ax, 0.28, 2.08, 2.95, 1.48,
        "Retained Evidence",
        "Task spec & candidate patch\nOfficial evaluator report\nRaw runner & usage record",
        COLORS["method"], TINTS["blue"], badge="01", title_size=8.4, body_size=7.6,
    )
    draw_card(
        ax, 3.82, 2.08, 2.95, 1.48,
        "Admission Core (I ∧ S)",
        "Bundle integrity checks (I)\nCross-object semantic rules (S)\nFail-closed read-only verdict",
        COLORS["baseline"], TINTS["teal"], badge="02", title_size=8.4, body_size=7.6,
    )
    draw_card(
        ax, 7.36, 2.08, 2.95, 1.48,
        "Publication Gate",
        "Single-source value ledger\nMacro, table & figure sidecars\nLayout & hash verification",
        COLORS["accent"], TINTS["amber"], badge="03", title_size=8.4, body_size=7.6,
    )

    draw_flow_arrow(ax, (3.30, 2.82), (3.76, 2.82), color=COLORS["method"], lw=1.7)
    draw_flow_arrow(ax, (6.84, 2.82), (7.30, 2.82), color=COLORS["baseline"], lw=1.7)

    # Lower support strip: audited upstream & independent trust anchors
    draw_card(
        ax, 0.28, 0.20, 2.95, 1.24,
        "Audited Upstream",
        "Context selector & edit renderer\n(supplies task-bound predictions)",
        COLORS["error"], TINTS["slate"], stripe="left", title_size=8.2, body_size=7.3,
    )
    draw_card(
        ax, 3.82, 0.20, 2.95, 1.24,
        "Independent Trust Anchors",
        "Frozen contract & authorization\nGit history bytes & billing logs",
        COLORS["violet"], TINTS["violet"], stripe="left", title_size=8.2, body_size=7.3,
    )
    draw_card(
        ax, 7.36, 0.20, 2.95, 1.24,
        "Release Outputs",
        "Admitted tables, figures & PDF\nExcluded runs retained for audit",
        COLORS["resolved"], TINTS["green"], stripe="left", title_size=8.2, body_size=7.3,
    )

    draw_flow_arrow(ax, (1.76, 1.50), (1.76, 2.02), color=COLORS["error"], ls="--", lw=1.35)
    draw_flow_arrow(ax, (5.30, 1.50), (5.30, 2.02), color=COLORS["violet"], lw=1.6)
    draw_flow_arrow(ax, (8.84, 2.02), (8.84, 1.50), color=COLORS["resolved"], lw=1.6)

    draw_pill(ax, 5.30, 1.75, "external lookup", COLORS["violet"], "#FFFFFF", fontsize=6.6)

    identifiers = ["weight.total", "marginal.relevance", "marginal.coverage_alpha"]
    stem = "fig_system_overview"
    source = ROOT / "paper/data/publication_values.json"
    out = ROOT / "paper/figures/output"
    fig.tight_layout(pad=0.2)
    for suffix in ["pdf", "png"]:
        path = out / (stem + "." + suffix)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        write(
            path,
            [source, Path(__file__).with_name("plot_style.py")],
            Path(__file__),
            transform={"value_ids": identifiers, "numeric_annotations": "none; conceptual diagram"},
            kind="figure",
        )
    plt.close(fig)


if __name__ == "__main__":
    generate_figure()
