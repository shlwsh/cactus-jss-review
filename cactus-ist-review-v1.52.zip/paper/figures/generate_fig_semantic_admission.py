"""Render modern two-stage semantic validation and dual-source conflict diagrams."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch
from plot_style import apply_style, COLORS, TINTS, draw_card, draw_flow_arrow, draw_pill
from scripts.artifact_provenance import write


def generate_figure():
    apply_style()
    fig, ax = plt.subplots(figsize=(7.2, 3.05))
    ax.set_xlim(0, 10.6)
    ax.set_ylim(0, 4.65)
    ax.axis("off")

    # Left input cards
    draw_card(
        ax, 0.20, 2.86, 2.65, 1.48,
        "Mutated Copies",
        "Apply semantic operator\nReseal all local hashes\n& checksums",
        COLORS["method"], TINTS["blue"], badge="IN", title_size=8.2, body_size=7.4,
    )
    draw_card(
        ax, 0.20, 0.35, 2.65, 1.48,
        "Controls & Anchors",
        "Intact & near-valid copies\nOriginal RUNs untouched\nFrozen external refs",
        COLORS["error"], TINTS["slate"], stripe="left", title_size=8.1, body_size=7.3,
    )

    # Middle top: Stage 1 Integrity
    draw_card(
        ax, 3.55, 3.02, 3.25, 1.32,
        "Stage 1 · Integrity (I)",
        "Checksums, manifests & schemas\nAll resealed copies pass",
        COLORS["baseline"], TINTS["teal"], badge="S1", title_size=8.2, body_size=7.4,
    )

    # Middle bottom: Stage 2 Semantic Core with 8 predicate chips
    ax.add_patch(FancyBboxPatch(
        (3.60, 0.29), 3.25, 2.02,
        boxstyle="round,pad=0.04,rounding_size=0.14",
        facecolor="#CBD5E1", edgecolor="none", alpha=0.45, zorder=2,
    ))
    ax.add_patch(FancyBboxPatch(
        (3.55, 0.35), 3.25, 2.02,
        boxstyle="round,pad=0.04,rounding_size=0.14",
        facecolor=TINTS["amber"], edgecolor=COLORS["accent"], linewidth=1.35, zorder=3,
    ))
    ax.add_patch(FancyBboxPatch(
        (3.55, 2.00), 3.25, 0.37,
        boxstyle="round,pad=0.04,rounding_size=0.12",
        facecolor=COLORS["accent"], edgecolor="none", zorder=4,
    ))
    ax.text(3.72, 2.185, "S2", ha="left", va="center", fontsize=7.4, fontweight="bold", color="#FFFFFF", zorder=5,
            bbox={"boxstyle": "round,pad=0.14,rounding_size=0.18", "facecolor": "#000000", "alpha": 0.22, "edgecolor": "none"})
    ax.text(4.18, 2.185, "Semantic Core (S)", ha="left", va="center", fontsize=8.2, fontweight="bold", color="#FFFFFF", zorder=5)

    chips = [
        ("Task ID", 4.35, 1.56), ("Source Git", 5.95, 1.56),
        ("Contract", 4.35, 1.12), ("Auth Sign", 5.95, 1.12),
        ("Eval / Raw", 4.35, 0.68), ("Billing / Img", 5.95, 0.68),
    ]
    for label, cx, cy in chips:
        draw_pill(ax, cx, cy, label, COLORS["subtext"], "#FFFFFF", fontsize=6.9, zorder=5)

    # Right outcome cards
    draw_card(
        ax, 7.55, 2.55, 2.85, 1.48,
        "Reject Mutations",
        "Caught at semantic stage\nExact intended reason code",
        COLORS["unresolved"], TINTS["red"], stripe="left", title_size=8.4, body_size=7.4,
    )
    draw_card(
        ax, 7.55, 0.45, 2.85, 1.48,
        "Admit Controls",
        "Intact & near-valid pass\nZero false positives",
        COLORS["resolved"], TINTS["green"], stripe="left", title_size=8.4, body_size=7.4,
    )

    # Connectors
    draw_flow_arrow(ax, (2.92, 3.65), (3.48, 3.65), color=COLORS["method"], lw=1.65)
    draw_flow_arrow(ax, (2.92, 1.15), (3.48, 3.35), color=COLORS["error"], rad=-0.18, ls="--", lw=1.35)
    draw_flow_arrow(ax, (5.18, 2.96), (5.18, 2.43), color=COLORS["baseline"], lw=1.7)
    draw_pill(ax, 5.78, 2.70, "I = PASS", COLORS["resolved"], "#FFFFFF", fontsize=6.6)
    draw_flow_arrow(ax, (6.90, 1.72), (7.48, 3.10), color=COLORS["unresolved"], rad=-0.08, lw=1.7)
    draw_flow_arrow(ax, (6.90, 0.98), (7.48, 1.12), color=COLORS["resolved"], rad=0.04, lw=1.7)

    fig.tight_layout(pad=0.2)
    out = ROOT / "paper/figures/output"
    out.mkdir(parents=True, exist_ok=True)
    for suffix in ("pdf", "png"):
        path = out / ("fig_semantic_admission." + suffix)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        write(
            path,
            [
                ROOT / "paper/data/publication_values.json",
                ROOT / "src/cactus/governance/admission.py",
                Path(__file__).with_name("plot_style.py"),
            ],
            Path(__file__),
            transform={
                "numeric_annotations": "none; staged validation design",
                "value_ids": ["semantic.fault_count", "semantic.control_count"],
            },
            kind="figure",
        )
    plt.close(fig)


def generate_conflict_figure():
    """Show the dual-source conflict decision chain common to both retained cases."""
    source = ROOT / "paper/data/publication_values.json"
    values = json.loads(source.read_text(encoding="utf-8"))["values"]
    identifiers = []
    for case in ("case.1.", "case.2."):
        identifiers.extend(
            case + key
            for key in ("evaluator_valid", "raw_resolved", "admitted", "declared_driver_sha256", "source_driver_sha256")
        )
        if (
            values[case + "evaluator_valid"]["value"] is not True
            or values[case + "raw_resolved"]["value"] is not False
            or values[case + "admitted"]["value"] is not False
            or values[case + "declared_driver_sha256"]["value"] == values[case + "source_driver_sha256"]["value"]
        ):
            raise ValueError("observed evidence-chain figure no longer matches cases")

    apply_style()
    fig, ax = plt.subplots(figsize=(7.2, 2.65))
    ax.set_xlim(0, 10.6)
    ax.set_ylim(0, 3.95)
    ax.axis("off")

    # Left: two competing source-of-truth objects
    draw_card(
        ax, 0.22, 2.28, 2.95, 1.38,
        "Frozen Contract",
        "Declared driver digest\n(pinned in contract JSON)",
        COLORS["method"], TINTS["blue"], stripe="left", title_size=8.4, body_size=7.4,
    )
    draw_card(
        ax, 0.22, 0.28, 2.95, 1.38,
        "Bound Git Revision",
        "Actual driver bytes hashed\ndirectly from Git history",
        COLORS["baseline"], TINTS["teal"], stripe="left", title_size=8.4, body_size=7.4,
    )

    # Center top: conflict comparator badge
    cx, cy = 5.18, 2.85
    ax.add_patch(Circle((cx + 0.05, cy - 0.05), 0.72, facecolor="#CBD5E1", edgecolor="none", alpha=0.45, zorder=2))
    ax.add_patch(Circle((cx, cy), 0.72, facecolor=TINTS["amber"], edgecolor=COLORS["accent"], linewidth=1.7, zorder=3))
    ax.text(cx, cy + 0.14, "≠", ha="center", va="center", fontsize=19, fontweight="bold", color=COLORS["unresolved"], zorder=4)
    ax.text(cx, cy - 0.32, "Digests\ndisagree", ha="center", va="center", fontsize=7.2, fontweight="bold", color=COLORS["text"], linespacing=1.1, zorder=4)

    # Center bottom: orthogonal evaluator verdict
    draw_card(
        ax, 3.72, 0.28, 2.92, 1.38,
        "Official Evaluator",
        "Strictly valid · unresolved\nMatches raw runner output",
        COLORS["resolved"], TINTS["green"], stripe="left", title_size=8.4, body_size=7.4,
    )

    # Right: final verdict card + retention note
    draw_card(
        ax, 7.45, 2.15, 2.95, 1.50,
        "Evidence Excluded",
        "Driver / source conflict\nBlocked from publication",
        COLORS["unresolved"], TINTS["red"], badge="FAIL", title_size=8.4, body_size=7.5,
    )
    draw_card(
        ax, 7.45, 0.28, 2.95, 1.38,
        "Immutable Archive",
        "Both real observations &\nfull digests kept unchanged",
        COLORS["error"], TINTS["slate"], stripe="left", title_size=8.2, body_size=7.3,
    )

    # Arrows
    draw_flow_arrow(ax, (3.24, 2.96), (4.42, 2.96), color=COLORS["method"], lw=1.65)
    draw_flow_arrow(ax, (3.24, 0.98), (4.56, 2.42), color=COLORS["baseline"], rad=-0.16, lw=1.65)
    draw_flow_arrow(ax, (5.18, 1.72), (5.18, 2.08), color=COLORS["resolved"], ls="--", lw=1.45)
    draw_flow_arrow(ax, (5.94, 2.85), (7.38, 2.85), color=COLORS["unresolved"], lw=1.8)
    draw_flow_arrow(ax, (6.70, 0.98), (7.38, 0.98), color=COLORS["error"], ls=":", lw=1.4)

    fig.tight_layout(pad=0.2)
    for suffix in ("pdf", "png"):
        path = ROOT / "paper/figures/output" / ("fig_evidence_conflict." + suffix)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        write(
            path,
            [source, Path(__file__).with_name("plot_style.py")],
            Path(__file__),
            transform={"value_ids": identifiers, "numeric_annotations": "none; observed case-chain predicates"},
            kind="figure",
        )
    plt.close(fig)


if __name__ == "__main__":
    generate_figure()
    generate_conflict_figure()
