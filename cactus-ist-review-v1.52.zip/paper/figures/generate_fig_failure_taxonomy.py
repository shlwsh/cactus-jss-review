"""Draw conceptual task layers (cards) and verified attempt-level exclusions (lollipop chart)."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import FancyBboxPatch
from plot_style import apply_style, COLORS, TINTS, draw_card
from scripts.artifact_provenance import write


def generate():
    apply_style()
    source = ROOT / "paper/data/publication_values.json"
    values = json.loads(source.read_text(encoding="utf-8"))["values"]
    ids = [
        "exclude.no_valid_official_evaluator",
        "exclude.raw_evaluator_result_mismatch",
        "exclude.contract_driver_source_hash_mismatch",
        "exclude.billing_not_reconciled",
    ]
    counts = [values[i]["value"] for i in ids]
    archived_disp = values["retry.archived"]["display"]

    fig, (left, right) = plt.subplots(1, 2, figsize=(7.2, 2.7), gridspec_kw={"width_ratios": [1.05, 1.45]})

    # Left panel: modern stacked conceptual cards
    left.set_xlim(0, 4.2)
    left.set_ylim(0, 4.0)
    left.axis("off")
    left.text(0.05, 3.82, "Task-Level Conceptual Model", fontsize=9.2, fontweight="bold", color=COLORS["text"], va="center")
    draw_card(
        left, 0.05, 2.38, 4.05, 1.12,
        "Layer A · Prediction",
        "Undefined names, syntax errors,\nempty or renderer-rejected edits",
        COLORS["method"], TINTS["blue"], stripe="left", title_size=8.0, body_size=7.3,
    )
    draw_card(
        left, 0.05, 1.02, 4.05, 1.12,
        "Layer B · Functional Repair",
        "Incorrect repair logic or test\nregressions after patch apply",
        COLORS["baseline"], TINTS["teal"], stripe="left", title_size=8.0, body_size=7.3,
    )
    left.add_patch(FancyBboxPatch(
        (0.05, 0.14), 4.05, 0.62,
        boxstyle="round,pad=0.03,rounding_size=0.12",
        facecolor=TINTS["red"], edgecolor=COLORS["unresolved"], linewidth=1.0, linestyle="--",
    ))
    left.text(
        2.075, 0.45,
        "Task-level counts withheld pending\nconsistent ledger & blinded coding",
        ha="center", va="center", fontsize=7.3, fontweight="bold", color=COLORS["unresolved"], linespacing=1.22,
    )

    # Right panel: modern lollipop chart with track background & pill badges
    labels = [
        "C · No valid official report",
        "C · Raw / evaluator conflict",
        "D · Driver / source conflict",
        "D · Billing not reconciled",
    ]
    dot_colors = [COLORS["method"], COLORS["method_light"], COLORS["accent"], COLORS["unresolved"]]
    y_pos = list(range(4))
    max_val = max(counts)

    # Background track bars
    right.barh(y_pos, [max_val * 1.18] * 4, height=0.42, color="#F1F5F9", edgecolor="none", zorder=1)
    # Lollipop stems + heads
    for y, val, col, ident in zip(y_pos, counts, dot_colors, ids):
        right.hlines(y, 0, val, color=col, linewidth=3.4, zorder=2)
        right.scatter([val], [y], color=col, s=82, zorder=3, edgecolors="#FFFFFF", linewidths=1.3)
        right.text(
            val + max_val * 0.06, y, values[ident]["display"],
            va="center", ha="left", fontsize=8.2, fontweight="bold", color=col,
            bbox={"boxstyle": "round,pad=0.18,rounding_size=0.30", "facecolor": "#FFFFFF", "edgecolor": col, "linewidth": 0.9},
            zorder=4,
        )

    right.set_yticks(y_pos, labels, fontsize=8.0, color=COLORS["text"])
    right.invert_yaxis()
    right.set_xlim(0, max_val * 1.28)
    right.set_xticks([])
    right.set_title("Attempt-Level Exclusions (Overlapping)", fontsize=9.2, fontweight="bold", color=COLORS["text"], loc="left", pad=8)
    right.set_xlabel(f"Attempts among {archived_disp} archived retries (do not sum)", fontsize=7.6, color=COLORS["subtext"], labelpad=6)
    for spine in right.spines.values():
        spine.set_visible(False)
    right.tick_params(axis="y", length=0, pad=6)

    fig.tight_layout(pad=0.6, w_pad=1.6)
    out = ROOT / "paper/figures/output"
    for suffix in ["pdf", "png"]:
        path = out / ("fig_failure_taxonomy." + suffix)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        write(
            path,
            [source, Path(__file__).with_name("plot_style.py")],
            Path(__file__),
            transform={"value_ids": ids + ["retry.archived"], "numeric_ticks": "none", "numeric_annotations": "ledger.display"},
            kind="figure",
        )
    plt.close(fig)


if __name__ == "__main__":
    generate()
