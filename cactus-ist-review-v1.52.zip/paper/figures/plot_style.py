"""Shared publication plotting style for the CACTUS/FACO manuscript figures."""

from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch, Polygon

# Modern editorial academic palette (high-contrast, colorblind-aware)
PALETTE = {
    "blue_main": "#1B3B6F",        # Deep cobalt primary
    "blue_secondary": "#2E6F95",   # Steel cyan-blue
    "green_1": "#E6F4EE",
    "green_2": "#9AD1B8",
    "green_3": "#168053",          # Emerald success / admitted
    "red_1": "#FCECEF",
    "red_2": "#EFA5AE",
    "red_strong": "#C83E4D",       # Coral crimson failure / excluded
    "neutral_light": "#F4F6F9",
    "neutral_mid": "#64748B",      # Slate neutral
    "neutral_dark": "#334155",     # Deep slate
    "neutral_black": "#0F172A",    # Ink charcoal
    "gold": "#D97706",             # Warm amber gate / accent
    "teal": "#0D7C85",             # Peacock teal
    "violet": "#5B4B9E",           # Indigo violet
    "grid": "#E2E8F0",
}

TINTS = {
    "blue": "#EEF4FA",
    "teal": "#EAF6F7",
    "amber": "#FEF6E7",
    "green": "#EAF7F1",
    "red": "#FDF0F2",
    "violet": "#F3F1FA",
    "slate": "#F4F6F9",
}

COLORS = {
    "method": PALETTE["blue_main"],
    "method_light": PALETTE["blue_secondary"],
    "baseline": PALETTE["teal"],
    "resolved": PALETTE["green_3"],
    "unresolved": PALETTE["red_strong"],
    "error": PALETTE["neutral_mid"],
    "accent": PALETTE["gold"],
    "violet": PALETTE["violet"],
    "grid": PALETTE["grid"],
    "text": PALETTE["neutral_black"],
    "subtext": PALETTE["neutral_dark"],
}

FONT = "DejaVu Sans"
FONT_FAMILY = ["DejaVu Sans", "Arial", "Helvetica", "sans-serif"]
FONT_SIZES = {
    "base": 8.0,
    "small": 7.5,
    "caption": 7.0,
    "label": 8.0,
    "title": 9.0,
    "pending": 12.0,
}


def apply_style() -> None:
    mpl.rcParams.update({
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "font.family": "sans-serif",
        "font.sans-serif": FONT_FAMILY,
        "font.size": FONT_SIZES["base"],
        "axes.labelsize": FONT_SIZES["label"],
        "axes.titlesize": FONT_SIZES["title"],
        "xtick.labelsize": FONT_SIZES["small"],
        "ytick.labelsize": FONT_SIZES["small"],
        "legend.fontsize": FONT_SIZES["small"],
        "legend.frameon": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.8,
        "axes.edgecolor": PALETTE["neutral_dark"],
        "text.color": PALETTE["neutral_black"],
        "axes.labelcolor": PALETTE["neutral_black"],
        "xtick.color": PALETTE["neutral_dark"],
        "ytick.color": PALETTE["neutral_dark"],
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
    })


def style_axis(axis) -> None:
    axis.tick_params(labelsize=FONT_SIZES["small"], color=PALETTE["neutral_dark"])
    axis.grid(axis="y", color=COLORS["grid"], linewidth=0.6, linestyle="-", zorder=0)
    axis.set_axisbelow(True)


def draw_card(
    ax,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str,
    body: str,
    accent: str,
    tint: str = "#FFFFFF",
    *,
    badge: str | None = None,
    title_size: float = 9.0,
    body_size: float = 7.8,
    stripe: str = "top",
    shadow: bool = True,
    zorder: int = 3,
) -> None:
    """Render a modern editorial card with subtle drop shadow and accent bar."""
    if shadow:
        ax.add_patch(FancyBboxPatch(
            (x + 0.05, y - 0.06), w, h,
            boxstyle="round,pad=0.04,rounding_size=0.14",
            facecolor="#CBD5E1", edgecolor="none", alpha=0.45, zorder=zorder - 1,
        ))
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.04,rounding_size=0.14",
        facecolor=tint, edgecolor=accent, linewidth=1.25, zorder=zorder,
    ))
    if stripe == "top":
        band_h = min(0.36, h * 0.30)
        ax.add_patch(FancyBboxPatch(
            (x, y + h - band_h), w, band_h,
            boxstyle="round,pad=0.04,rounding_size=0.12",
            facecolor=accent, edgecolor="none", zorder=zorder + 1,
        ))
        tx = x + 0.16
        if badge:
            ax.text(
                tx, y + h - band_h / 2, badge,
                ha="left", va="center", fontsize=title_size - 0.8, fontweight="bold",
                color="#FFFFFF", alpha=0.92, zorder=zorder + 2,
                bbox={"boxstyle": "round,pad=0.16,rounding_size=0.18", "facecolor": "#000000", "alpha": 0.22, "edgecolor": "none"},
            )
            tx += 0.48
        ax.text(
            tx, y + h - band_h / 2, title,
            ha="left", va="center", fontsize=title_size, fontweight="bold",
            color="#FFFFFF", zorder=zorder + 2,
        )
        if body:
            ax.text(
                x + w / 2, y + (h - band_h) / 2, body,
                ha="center", va="center", fontsize=body_size, color=COLORS["text"],
                linespacing=1.32, zorder=zorder + 2,
            )
    elif stripe == "left":
        ax.add_patch(FancyBboxPatch(
            (x, y), 0.14, h,
            boxstyle="round,pad=0.04,rounding_size=0.10",
            facecolor=accent, edgecolor="none", zorder=zorder + 1,
        ))
        cx = x + 0.28 + (w - 0.30) / 2
        if body:
            ax.text(cx, y + h * 0.67, title, ha="center", va="center", fontsize=title_size, fontweight="bold", color=accent, zorder=zorder + 2)
            ax.text(cx, y + h * 0.30, body, ha="center", va="center", fontsize=body_size, color=COLORS["text"], linespacing=1.25, zorder=zorder + 2)
        else:
            ax.text(cx, y + h / 2, title, ha="center", va="center", fontsize=title_size, fontweight="bold", color=accent, zorder=zorder + 2)


def draw_pill(
    ax,
    x: float,
    y: float,
    text: str,
    fg: str,
    bg: str,
    *,
    fontsize: float = 7.2,
    ha: str = "center",
    zorder: int = 5,
) -> None:
    ax.text(
        x, y, text, ha=ha, va="center", fontsize=fontsize, fontweight="bold",
        color=fg, zorder=zorder,
        bbox={"boxstyle": "round,pad=0.22,rounding_size=0.35", "facecolor": bg, "edgecolor": fg, "linewidth": 0.8},
    )


def draw_flow_arrow(
    ax,
    start: tuple[float, float],
    end: tuple[float, float],
    *,
    color: str | None = None,
    rad: float = 0.0,
    ls: str = "-",
    lw: float = 1.5,
    zorder: int = 4,
) -> None:
    c = color or PALETTE["neutral_dark"]
    ax.annotate(
        "", xy=end, xytext=start, zorder=zorder,
        arrowprops={
            "arrowstyle": "-|>,head_length=0.45,head_width=0.24",
            "color": c,
            "lw": lw,
            "linestyle": ls,
            "connectionstyle": f"arc3,rad={rad}",
        },
    )


def save(figure, output: Path, stem: str) -> None:
    output.mkdir(parents=True, exist_ok=True)
    figure.savefig(output / f"{stem}.pdf", bbox_inches="tight")
    figure.savefig(output / f"{stem}.svg", bbox_inches="tight")
    figure.savefig(output / f"{stem}.png", dpi=300, bbox_inches="tight")


BAR_COUNT_THRESHOLD = 4


def auto_orient_bars(ax, names: list[str], values: list[float], *, orientation: str = "auto", color=None, width: float = 0.55):
    """Render a bar chart that auto-switches to horizontal bars past BAR_COUNT_THRESHOLD."""
    color = color or COLORS["method"]
    if orientation == "auto":
        orientation = "horizontal" if len(names) >= BAR_COUNT_THRESHOLD else "vertical"
    if orientation == "horizontal":
        labels = names if len(names) < BAR_COUNT_THRESHOLD else [f"task-{i + 1:02d}" for i in range(len(names))]
        bars = ax.barh(labels, values, color=color, edgecolor="none", zorder=2)
        ax.invert_yaxis()
        return bars
    bars = ax.bar(names, values, color=color, width=width, edgecolor="none", zorder=2)
    return bars
