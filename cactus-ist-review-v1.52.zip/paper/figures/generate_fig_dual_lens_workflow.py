"""Generate a modern converge-diverge Dual-Lens decision flow diagram."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import Polygon
from plot_style import apply_style, COLORS, TINTS, draw_card, draw_flow_arrow, draw_pill
from scripts.artifact_provenance import write


def generate_figure():
    apply_style()
    fig, ax = plt.subplots(figsize=(7.2, 2.55))
    ax.set_xlim(0, 10.6)
    ax.set_ylim(0, 3.85)
    ax.axis("off")

    # Left: dual orthogonal lenses
    draw_card(
        ax, 0.22, 2.18, 2.95, 1.38,
        "Algorithm Lens",
        "Candidate patch & source identity\nResolved vs. unresolved repair",
        COLORS["baseline"], TINTS["teal"], stripe="left", title_size=8.6, body_size=7.6,
    )
    draw_card(
        ax, 0.22, 0.28, 2.95, 1.38,
        "Evaluator Lens",
        "Official harness completion\nInfra, empty-patch & error flags",
        COLORS["method"], TINTS["blue"], stripe="left", title_size=8.6, body_size=7.6,
    )

    # Center: prominent hexagonal admission gate
    cx, cy = 5.30, 1.92
    dx, dy = 1.45, 1.02
    hex_pts = [
        (cx - dx, cy),
        (cx - dx * 0.62, cy + dy),
        (cx + dx * 0.62, cy + dy),
        (cx + dx, cy),
        (cx + dx * 0.62, cy - dy),
        (cx - dx * 0.62, cy - dy),
    ]
    shadow_pts = [(px + 0.06, py - 0.06) for px, py in hex_pts]
    ax.add_patch(Polygon(shadow_pts, closed=True, facecolor="#CBD5E1", edgecolor="none", alpha=0.5, zorder=2))
    ax.add_patch(Polygon(hex_pts, closed=True, facecolor=TINTS["amber"], edgecolor=COLORS["accent"], linewidth=1.7, zorder=3))
    ax.text(cx, cy + 0.42, "ADMISSION GATE", ha="center", va="center", fontsize=8.4, fontweight="bold", color=COLORS["accent"], zorder=4)
    ax.text(cx, cy + 0.02, "I ∧ S", ha="center", va="center", fontsize=11.0, fontweight="bold", color=COLORS["text"], zorder=4)
    ax.text(cx, cy - 0.42, "Integrity · Contract\nSource · Billing · Auth", ha="center", va="center", fontsize=7.2, color=COLORS["subtext"], linespacing=1.2, zorder=4)

    # Right: two orthogonal outcomes
    draw_card(
        ax, 7.42, 2.18, 2.95, 1.38,
        "Admitted Observation",
        "Enters publication ledger\nResolved or unresolved outcome",
        COLORS["resolved"], TINTS["green"], stripe="left", title_size=8.6, body_size=7.6,
    )
    draw_card(
        ax, 7.42, 0.28, 2.95, 1.38,
        "Excluded Evidence",
        "Blocked from published claims\nRetained unmodified for audit",
        COLORS["unresolved"], TINTS["red"], stripe="left", title_size=8.6, body_size=7.6,
    )

    # Smooth curved flow connectors
    draw_flow_arrow(ax, (3.24, 2.86), (3.85, 2.15), color=COLORS["baseline"], rad=-0.16, lw=1.65)
    draw_flow_arrow(ax, (3.24, 0.96), (3.85, 1.68), color=COLORS["method"], rad=0.16, lw=1.65)
    draw_flow_arrow(ax, (6.75, 2.15), (7.36, 2.86), color=COLORS["resolved"], rad=-0.16, lw=1.75)
    draw_flow_arrow(ax, (6.75, 1.68), (7.36, 0.96), color=COLORS["unresolved"], rad=0.16, lw=1.75)

    draw_pill(ax, 6.82, 2.90, "PASS", COLORS["resolved"], "#FFFFFF", fontsize=6.5)
    draw_pill(ax, 6.82, 0.94, "FAIL", COLORS["unresolved"], "#FFFFFF", fontsize=6.5)

    identifiers = ["retry.archived", "retry.admitted"]
    stem = "fig_dual_lens_workflow"
    source = ROOT / "paper/data/publication_values.json"
    out = ROOT / "paper/figures/output"
    fig.tight_layout(pad=0.2)
    for suffix in ["pdf", "png"]:
        path = out / (stem + "." + suffix)
        fig.savefig(path, dpi=300, bbox_inches="tight")
        write(
            path,
            [source, Path(__file__).with_name("plot_style.py")],
            Path(__file__),
            transform={"value_ids": identifiers, "numeric_annotations": "none; conceptual diagram"},
            kind="figure",
        )
    plt.close(fig)


if __name__ == "__main__":
    generate_figure()
