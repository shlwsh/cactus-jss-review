# 原始重试证据受控复核说明

> 文档版本 v1.0  
> 制定时间 2026-11-22T14:52:30Z  
> 适用版本 CACTUS IST v1.52

## Reviewer access

Ask the authors for read-only access to the retained research archive and the
matching independent frozen contracts and authorization records. Identify the
manuscript version and the retry inventory in the request. The custodian can
provide a restricted session on an authorized host after checking benchmark
and artifact terms, billing privacy, and the scope of access. The public package
includes the inventory and a verification receipt. Original bundles, approval
text, private endpoints and billing identities stay with their custodian.

On the research checkout documented by the authors, run the following command
from the IST project directory. Supply one or more read-only roots covering
the authorized original RUNs. Preserve the historical Git objects and original
paths used by the checker.

```bash
PYTHONPATH=src python -m scripts.verify_retry_readmission \
  --archive /path/to/authorized/run-archive \
  --output /path/to/new/verification-receipt.json
```

The verifier first compares the frozen driver declarations with historical Git
bytes across the retry inventory. It then compares each available original bundle tree against the full frozen
inventory digest, reads the matching frozen authorization and contract, and
repeats the production admission check. It aborts if a located tree or
recomputed row disagrees with the frozen inventory. The receipt lists verified
decisions and unavailable RUN identifiers, without including raw logs, source
paths or billing details. Compare its coverage and verdicts with the receipt
pinned in `paper/publication_sources.json`. Coverage of both accepted and
excluded examples is needed to assess the two outcomes from originals. Model
and evaluator execution are outside the scope of these read-only steps.
