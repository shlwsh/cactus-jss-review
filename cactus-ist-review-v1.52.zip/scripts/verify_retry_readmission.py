"""Compare retained retry archives with frozen admission rows without modifying inputs."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from cactus.governance.admission import source_hash
from cactus.governance.evidence_locations import sha256
from scripts.import_formal_run_bundles import contracts, inventory_row, tree_hash

ROOT = Path(__file__).resolve().parents[1]


def verify(archives, root=ROOT):
    pins = json.loads((root / "paper/publication_sources.json").read_text())["sources"]
    inventory = root / pins["retry_inventory"]["path"]
    inventory_sha = sha256(inventory)
    if inventory_sha != pins["retry_inventory"]["sha256"]:
        raise ValueError("retry inventory hash drift")
    rows = [json.loads(line) for line in inventory.read_text().splitlines()]
    by_id = {row["run_id"]: row for row in rows}
    if len(by_id) != len(rows):
        raise ValueError("duplicate retry ID")
    contract_paths = sorted({row["contract_path"] for row in rows})
    frozen_contracts = {path: json.loads((root / path).read_text()) for path in contract_paths}
    frozen_hashes = {path: sha256(root / path) for path in contract_paths}
    driver_conflicts = 0
    for row in rows:
        path = row["contract_path"]
        workload = frozen_contracts[path]["workload"]
        observed = source_hash(root, row["source_commit"], workload["driver"])
        conflict = observed != workload["sha256"]
        if (frozen_hashes[path] != row["contract_sha256"]
                or observed != row["source_driver_sha256"]
                or workload["sha256"] != row["declared_driver_sha256"]
                or conflict != ("contract_driver_source_hash_mismatch" in row["exclusion_reasons"])):
            raise ValueError("historical driver binding differs for " + row["run_id"])
        driver_conflicts += conflict
    candidates = {}
    for archive in archives:
        for manifest in archive.rglob("run_manifest.json"):
            run = manifest.parent
            if run.name in by_id:
                candidates.setdefault(run.name, []).append(run)
    if candidates:
        contracts(root, sorted({by_id[run_id]["contract_path"] for run_id in candidates}))
    reproduced = []
    for run_id, paths in sorted(candidates.items()):
        expected = by_id[run_id]
        exact = [path for path in paths if tree_hash(path) == expected["bundle_tree_sha256"]]
        if not exact:
            raise ValueError("no matching original tree for " + run_id)
        contract = root / expected["contract_path"]
        actual = inventory_row(root, exact[0], contract, frozen_contracts[expected["contract_path"]])
        if actual != expected:
            raise ValueError("readmission differs from frozen decision for " + run_id)
        reproduced.append({key: actual[key] for key in (
            "run_id", "task_id", "bundle_tree_sha256", "checksums_sha256",
            "contract_sha256", "source_commit", "evaluator_valid", "resolved",
            "admitted", "exclusion_reasons",
        )})
    return {
        "schema_version": "1.0",
        "generated_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "scope": "read-only production re-admission; each reproduced row matches an original tree and frozen decision",
        "inventory_sha256": inventory_sha,
        "admission_core_sha256": sha256(root / pins["admission_core"]["path"]),
        "recorded_attempts": len(rows),
        "driver_source_recheck": {"checked": len(rows), "conflicts": driver_conflicts},
        "reproduced": reproduced,
        "unavailable_run_ids": sorted(by_id.keys() - candidates.keys()),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if any(not path.is_dir() for path in args.archive):
        parser.error("each --archive must be an existing directory")
    result = verify(args.archive)
    with args.output.open("x", encoding="utf-8") as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(f"Reproduced {len(result['reproduced'])}/{result['recorded_attempts']} decisions")
