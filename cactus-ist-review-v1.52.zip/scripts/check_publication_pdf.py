"""Hard-fail on publication rendering defects using Poppler text/bbox output."""
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET


# Some Poppler versions pass PDF font control codes through to XHTML word text.
XML_CONTROL_BYTES = bytes(code for code in range(32) if code not in (9, 10, 13))


def text_errors(text: str):
    patterns = [r"DataValue", r"Q\s*=\s*Q\s*=", r"p\s*=\s*p\s*=", r"%\s*%", r"\bP0-\d", r"(?:\?\?)+",
                r"Appendix\s+Appendix", r"\b(?:TODO|FIXME|AUTHOR_INPUT_NEEDED)\b",
                r"(?:Contributions|Research standards and scope of inference)\s*\.\.",
                r"diff\s+[\u2013\u2014]git"]
    return ["rendered forbidden token: " + pattern for pattern in patterns if re.search(pattern, text)]


def submission_text_issues(text: str):
    """Scan extracted final text, allowing pending scientific evidence.

    Candidate builds can contain honest unresolved author/release statements.
    The final submission gate must reject them, including across PDF line wraps.
    """
    text = re.sub(r"(?<=\w)-\s*\n\s*(?=\w)", "", text)
    text = re.sub(r"\s+", " ", text)
    patterns = {
        "author": [r"\bmust confirm\b", r"\bawaits? (?:author )?confirmation\b",
                   r"\b(?:roles? |statements? |declarations? )?await confirmation\b",
                   r"\b(?:remains?|remain) required before submission\b",
                   r"\bdoes not assert that those author confirmations\b"],
        "release": [r"\blocal revision candidate\b",
                    r"\b(?:exact (?:version )?DOI|public release verification)\b[^.;]{0,120}\bpending\b"],
        "technical": [r"\b(?:TODO|FIXME|AUTHOR_INPUT_NEEDED|DataValue)\b",
                      r"\bQ\s*=\s*Q\b", r"\bp\s*=\s*p\b",
                      r"\bAppendix\s+Appendix\b", r"\bP0-"],
    }
    return {category: ["final submission text: " + pattern for pattern in rules
                       if re.search(pattern, text, re.I)]
            for category, rules in patterns.items()}


def check(pdf: Path, log: Path | None = None, *, final_submission: bool = False):
    extracted = subprocess.run(["pdftotext", "-layout", str(pdf), "-"], check=True, capture_output=True).stdout.decode("utf-8")
    errors = text_errors(extracted)
    if final_submission:
        errors.extend(issue for issues in submission_text_issues(extracted).values() for issue in issues)
    if log and log.is_file():
        content = log.read_text(encoding="utf-8", errors="replace")
        for marker in [r"Overfull \\[hv]box", r"Undefined control sequence", r"LaTeX Warning:.*undefined", r"There were undefined references"]:
            if re.search(marker, content):
                errors.append("LaTeX rendering defect: " + marker)
    bbox = subprocess.run(["pdftotext", "-bbox", str(pdf), "-"], check=True, capture_output=True).stdout
    tree = ET.fromstring(bbox.translate(None, XML_CONTROL_BYTES))
    pages = list(tree.iter("{http://www.w3.org/1999/xhtml}page"))
    if not pages:
        errors.append("Poppler bounding-box output contains no pages")
    for index, page in enumerate(pages, 1):
        width, height = float(page.attrib["width"]), float(page.attrib["height"])
        for word in page.iter("{http://www.w3.org/1999/xhtml}word"):
            if float(word.attrib["xMin"]) < 0 or float(word.attrib["yMin"]) < 0 or float(word.attrib["xMax"]) > width + .1 or float(word.attrib["yMax"]) > height + .1:
                errors.append(f"text outside page boundary: page {index}")
                break
    if errors:
        raise ValueError("; ".join(errors))
    return {"status": "PASS", "pages": len(pages), "checks": ["forbidden tokens", "unresolved references", "overfull boxes", "text page bounds"],
            "limitation": "table/figure visual layout additionally requires rendered-page inspection"}
